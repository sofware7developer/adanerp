<?php
declare(strict_types=1);

if (PHP_SAPI === 'cli-server') {
    $reqPath = rawurldecode((string)(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/'));
    $staticPath = __DIR__ . $reqPath;
    if ($reqPath !== '/' && is_file($staticPath) && !str_ends_with(strtolower($staticPath), '.php')) {
        return false;
    }
}

require_once __DIR__ . '/app/Core/Autoloader.php';
\App\Core\Autoloader::register(__DIR__);
require_once __DIR__ . '/app/Core/helpers.php';

use App\Controllers\AcademyController;
use App\Controllers\AiStudioController;
use App\Controllers\ApiController;
use App\Controllers\AuthController;
use App\Controllers\BiAiAdminController;
use App\Controllers\ChamberGrowthController;
use App\Controllers\ChamberSecurityBranchController;
use App\Controllers\ChamberStatutoryController;
use App\Controllers\CompetencyController;
use App\Controllers\CorporateController;
use App\Controllers\DashboardController;
use App\Controllers\EvaluationController;
use App\Controllers\EventController;
use App\Controllers\ExamCertController;
use App\Controllers\FinanceController;
use App\Controllers\InstructorController;
use App\Controllers\LmsController;
use App\Controllers\MarketRadarController;
use App\Controllers\NationalInterchangeController;
use App\Controllers\OperationsController;
use App\Controllers\PluginsController;
use App\Controllers\PortalController;
use App\Controllers\PrintCenterController;
use App\Controllers\ResourceResearchController;
use App\Controllers\SystemOpsController;
use App\Controllers\TmsController;
use App\Controllers\VoiceAssistantController;
use App\Controllers\ErpIntelligenceController;
use App\Core\App;
use App\Core\Database;
use App\Core\Router;

App::boot(__DIR__);

// اتصال مستقیم به پایگاه داده MariaDB از طریق config/config.php (راه‌اندازی مستقیم با Import فایل SQL)
Database::ensureImportedOrRenderGuide();

$router = new Router();

// مسیرهای عمومی و احراز هویت
$router->any('', [DashboardController::class, 'index'], ['super_admin', 'training_expert', 'finance_manager', 'crm_manager', 'instructor', 'org_rep', 'learner']);
$router->any('dashboard', [DashboardController::class, 'index'], ['super_admin', 'training_expert', 'finance_manager', 'crm_manager', 'instructor', 'org_rep', 'learner']);
$router->any('login', [AuthController::class, 'login'], [], true);
$router->any('logout', [AuthController::class, 'logout'], [], true);
$router->any('public-home', [PortalController::class, 'publicHome'], [], true);
$router->any('verify', [PortalController::class, 'verify'], [], true);
$router->any('passport', [PortalController::class, 'passport'], [], true);

// وب‌سرویس‌های REST API و وب‌هوک‌ها
$router->any('api/v1/search', [ApiController::class, 'search'], [], true, true);
$router->any('api/v1/copilot', [ApiController::class, 'copilot'], [], true);
$router->any('api/v1/courses', [ApiController::class, 'courses'], [], true, true);
$router->any('api/v1/enrollments', [ApiController::class, 'apiEnroll'], [], true, true);
$router->any('api/v1/telegram-webhook', [ApiController::class, 'telegramWebhook'], [], true, true);
$router->any('api/v1/scorm-cmi', [ApiController::class, 'scormCmi'], [], true, true);
$router->any('api/v1/module-ai', [ApiController::class, 'moduleAi'], [], true, true);
$router->any('api/v1/voice-command', [ApiController::class, 'voiceCommand'], [], true, true);
$router->any('api/v1/voice-transcribe', [ApiController::class, 'voiceTranscribe'], [], true, true);
$router->any('api/v1/quick-theme', [ApiController::class, 'quickTheme'], [], true, true);
$router->any('api/v1/bi-studio', [BiAiAdminController::class, 'biStudioApi'], ['super_admin','training_expert','finance_manager','crm_manager'], false, true);
$router->any('bi-report-print', [BiAiAdminController::class, 'biReportPrint'], ['super_admin','training_expert','finance_manager','crm_manager']);
$router->any('voice-assistant', [VoiceAssistantController::class, 'index'], ['super_admin', 'training_expert', 'finance_manager', 'crm_manager', 'instructor', 'org_rep']);
$router->any('erp-intelligence', [ErpIntelligenceController::class, 'index'], ['super_admin','training_expert','finance_manager','crm_manager']);
$router->any('system-ops', [SystemOpsController::class, 'index'], ['super_admin']);
$router->any('system-settings', [\App\Controllers\EnterpriseAdminSuiteController::class, 'systemSettings'], ['super_admin']);
$router->any('iam-access', [\App\Controllers\EnterpriseAdminSuiteController::class, 'iamAccess'], ['super_admin']);
$router->any('academic-erp-core', [\App\Controllers\EnterpriseAdminSuiteController::class, 'academicErpCore'], ['super_admin', 'training_expert', 'instructor', 'org_rep', 'learner']);
$router->any('transcript-print', [\App\Controllers\EnterpriseAdminSuiteController::class, 'transcriptPrint'], ['super_admin', 'training_expert', 'instructor', 'org_rep', 'learner']);
$router->any('helpdesk-sla', [\App\Controllers\EnterpriseAdminSuiteController::class, 'helpdeskSla'], ['super_admin','training_expert','finance_manager','crm_manager','instructor','org_rep','learner']);
$router->any('microlearning', [\App\Controllers\MicrolearningController::class, 'index'], ['super_admin', 'training_expert', 'learner']);
$router->any('office-automation', [\App\Controllers\OfficeAutomationController::class, 'index'], ['super_admin', 'training_expert', 'finance_manager', 'crm_manager', 'instructor']);
$router->any('letter-print', [\App\Controllers\OfficeAutomationController::class, 'letterPrint'], ['super_admin', 'training_expert', 'finance_manager', 'crm_manager', 'instructor']);
$router->any('help-center', [\App\Controllers\HelpEncyclopediaController::class, 'index'], ['super_admin','training_expert','finance_manager','crm_manager','instructor','org_rep','learner']);
$router->any('help-manual-print', [\App\Controllers\HelpEncyclopediaController::class, 'manualPrint'], [], true);

// قابلیت‌های تکمیلی آموزشگاه
$router->any('virtual-class', [ChamberStatutoryController::class, 'virtualClass'], ['super_admin', 'training_expert', 'instructor', 'learner']);
$router->any('tax-moadian', [ChamberStatutoryController::class, 'taxMoadian'], ['super_admin', 'finance_manager']);
$router->any('iran-messengers', [ChamberStatutoryController::class, 'iranMessengers'], ['super_admin', 'crm_manager']);
$router->any('national-interchange', [NationalInterchangeController::class, 'index'], ['super_admin', 'finance_manager']);

$router->any('iso-qa', [ChamberGrowthController::class, 'isoQa'], ['super_admin','training_expert']);
$router->any('market-radar', [MarketRadarController::class, 'index'], ['super_admin', 'training_expert', 'crm_manager']);
$router->any('job-board', [\App\Controllers\CareerHubController::class, 'index'], ['super_admin', 'crm_manager']);
$router->any('career-hub', [\App\Controllers\CareerHubController::class, 'index'], ['super_admin', 'crm_manager']);
$router->any('cv-print', [\App\Controllers\CareerHubController::class, 'cvPrint'], ['super_admin', 'training_expert', 'finance_manager', 'crm_manager', 'instructor', 'org_rep']);
$router->any('grants-mou', [ChamberGrowthController::class, 'grantsMou'], ['super_admin', 'training_expert', 'finance_manager', 'crm_manager']);
$router->any('alumni-club', [ChamberGrowthController::class, 'alumniClub'], ['super_admin', 'training_expert', 'learner']);

$router->any('sso-pki', [ChamberSecurityBranchController::class, 'ssoPki'], ['super_admin']);
$router->any('proctoring-drm', [ChamberSecurityBranchController::class, 'proctoringDrm'], ['super_admin', 'training_expert']);
// مرکز چاپ اسناد آموزشی و اداری آدان
$router->any('class-card-print', [PrintCenterController::class, 'classCardPrint'], ['super_admin', 'training_expert', 'finance_manager', 'crm_manager', 'instructor', 'org_rep', 'learner']);
$router->any('board-report-print', [PrintCenterController::class, 'boardReportPrint'], ['super_admin','training_expert','finance_manager','crm_manager']);
$router->any('instructor-contract-print', [PrintCenterController::class, 'instructorContractPrint'], ['super_admin','training_expert','finance_manager','instructor']);
$router->any('event-badge-print', [PrintCenterController::class, 'eventBadgePrint'], ['super_admin', 'training_expert', 'finance_manager', 'crm_manager']);
$router->any('contract-print', [PrintCenterController::class, 'contractPrint'], ['super_admin','crm_manager','finance_manager','training_expert','org_rep']);

// بخش‌های سامانه اصلی با کنترل دسترسی سطح مسیر (RBAC)
$router->any('tms', [TmsController::class, 'index'], ['super_admin','training_expert','instructor','finance_manager','org_rep','learner']);
$router->any('competency', [CompetencyController::class, 'index'], ['super_admin','training_expert','instructor','org_rep','learner']);
$router->any('lms', [LmsController::class, 'index'], ['super_admin', 'training_expert', 'instructor', 'learner']);
$router->any('ai-studio', [AiStudioController::class, 'index'], ['super_admin','training_expert','instructor']);

$router->any('instructors', [InstructorController::class, 'index'], ['super_admin', 'training_expert', 'finance_manager']);
$router->any('events', [EventController::class, 'index'], ['super_admin', 'training_expert', 'finance_manager', 'crm_manager', 'org_rep', 'learner']);
$router->any('finance', [FinanceController::class, 'index'], ['super_admin','finance_manager','training_expert','org_rep','learner']);
$router->any('invoice-print', [FinanceController::class, 'printInvoice'], ['super_admin','finance_manager','training_expert','org_rep','learner']);
$router->any('evaluation', [EvaluationController::class, 'index'], ['super_admin','training_expert','instructor','finance_manager']);

$router->any('portal', [PortalController::class, 'index'], ['super_admin', 'training_expert', 'org_rep', 'learner']);
$router->any('crm', [CorporateController::class, 'crm'], ['super_admin', 'training_expert', 'crm_manager']);
$router->any('contracts', [CorporateController::class, 'contracts'], ['super_admin','crm_manager','finance_manager','training_expert','org_rep']);

$router->any('leadership', [AcademyController::class, 'leadership'], ['super_admin', 'training_expert', 'learner']);
$router->any('consulting', [AcademyController::class, 'consulting'], ['super_admin', 'training_expert', 'learner']);
$router->any('exams', [ExamCertController::class, 'index'], ['super_admin','training_expert','instructor','org_rep','learner']);

$router->any('classrooms', [ResourceResearchController::class, 'classrooms'], ['super_admin', 'training_expert']);
$router->any('research', [ResourceResearchController::class, 'research'], ['super_admin', 'training_expert']);
$router->any('library', [ResourceResearchController::class, 'library'], ['super_admin', 'training_expert', 'instructor', 'learner']);
$router->any('internships', [OperationsController::class, 'internships'], ['super_admin', 'training_expert', 'learner']);
$router->any('competitions', [OperationsController::class, 'competitions'], ['super_admin', 'training_expert', 'learner']);

$router->any('hr', [OperationsController::class, 'hr'], ['super_admin','finance_manager']);
$router->any('bpms', [OperationsController::class, 'bpms'], ['super_admin','training_expert','finance_manager','crm_manager']);
$router->any('bi', [BiAiAdminController::class, 'reports'], ['super_admin','training_expert','finance_manager','crm_manager']);
$router->any('ai-governance', [BiAiAdminController::class, 'aiGovernance'], ['super_admin']);
$router->any('digital-twin-bi', [\App\Controllers\ExecutiveBriefingController::class, 'index'], ['super_admin','training_expert','finance_manager','crm_manager']);
$router->any('gamification-analytics', [\App\Controllers\GamificationBehaviorController::class, 'index'], ['super_admin', 'training_expert']);
$router->any('role-workstations', [\App\Controllers\RoleWorkstationController::class, 'index'], ['super_admin', 'learner']);
$router->any('api/v1/gamification-ping', [ApiController::class, 'gamificationPing'], ['super_admin','training_expert','finance_manager','crm_manager','instructor','org_rep','learner']);

// افزونه‌ها و قابلیت‌های سراسری
$router->any('workspace-tools', [PluginsController::class, 'workspaceTools'], ['super_admin', 'finance_manager', 'crm_manager']);
$router->any('portal-builder', [PluginsController::class, 'portalBuilder'], ['super_admin', 'crm_manager']);
$router->any('marketing-intel', [PluginsController::class, 'marketingIntel'], ['super_admin','crm_manager','training_expert']);
$router->any('talent-psych', [PluginsController::class, 'talentPsych'], ['super_admin', 'training_expert', 'learner']);

// مسیرهای معادل برای دسترسی مستقیم و یکپارچه
$router->any('counseling', [AcademyController::class, 'consulting'], ['super_admin','training_expert','instructor','org_rep','learner']);
$router->any('resources', [ResourceResearchController::class, 'classrooms'], ['super_admin','training_expert','instructor']);
$router->any('site-builder', [PluginsController::class, 'portalBuilder'], ['super_admin','training_expert','crm_manager']);
$router->any('marketing', [PluginsController::class, 'marketingIntel'], ['super_admin','crm_manager','training_expert']);
$router->any('market-intel', [PluginsController::class, 'marketingIntel'], ['super_admin','crm_manager','training_expert']);
$router->any('psychometrics', [PluginsController::class, 'talentPsych'], ['super_admin','training_expert','instructor','org_rep','learner']);

$router->dispatch(App::currentRoute());
