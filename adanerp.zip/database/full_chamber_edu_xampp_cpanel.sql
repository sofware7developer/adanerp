-- =====================================================================
--  مؤسسه آموزشی آدان — سامانه جامع آموزش و شهروندی دیجیتال | نسخه مرجع v26.8.2
--  فایل ایمپورت آماده برای cPanel / MySQL / phpMyAdmin
--  178 جدول: هسته ERP + استودیوی گزارش‌ساز صوتی هوشمند + مربی هوشمند یادگیری فراگیر
--  + هوش مصنوعی آفلاین + BI چهارسبکی + TMS/LMS + کمپین‌ساز اجتماعی + دفتر هوشمند
--  + مقرراتی/مالیاتی/عینیاتی + CRM + کمک‌هزینه
--  RBAC سخت‌گیرانه (۷ نقش) + پوسته ساده فراگیر (فقط دوره و موارد مرتبط، AI غیرمدیریتی)
--  + ترمیم خودکار اسکیما (بدون install.php)
--  نحوه استفاده: phpMyAdmin › دیتابیس کاربر › Import › همین فایل (پیشوند dPanel را در cPanel ببینید)
-- =====================================================================
/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.8.6-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: 127.0.0.1    Database: chamber_edu
-- ------------------------------------------------------
-- Server version	11.8.6-MariaDB-0+deb13u1 from Debian

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `academic_attendance_gradebook`
--

DROP TABLE IF EXISTS `academic_attendance_gradebook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `academic_attendance_gradebook` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `record_serial` varchar(45) NOT NULL,
  `term_code` varchar(40) NOT NULL DEFAULT 'TERM-1405-FALL',
  `learner_name` varchar(150) NOT NULL,
  `national_id` varchar(20) NOT NULL DEFAULT '1079025413',
  `course_title` varchar(185) NOT NULL,
  `sessions_total` int(11) NOT NULL DEFAULT 10,
  `sessions_attended` int(11) NOT NULL DEFAULT 9,
  `attendance_pct` int(11) NOT NULL DEFAULT 90,
  `quiz_activity_score` int(11) NOT NULL DEFAULT 88,
  `practical_project_score` int(11) NOT NULL DEFAULT 92,
  `final_exam_score` int(11) NOT NULL DEFAULT 94,
  `weighted_total_score` int(11) NOT NULL DEFAULT 92,
  `academic_standing` varchar(60) NOT NULL DEFAULT 'قبول ممتاز — مجاز به صدور گواهی QR',
  `appeal_status` varchar(80) NOT NULL DEFAULT 'بدون اعتراض',
  `updated_shamsi` varchar(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `record_serial` (`record_serial`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `academic_attendance_gradebook`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `academic_attendance_gradebook` WRITE;
/*!40000 ALTER TABLE `academic_attendance_gradebook` DISABLE KEYS */;
INSERT INTO `academic_attendance_gradebook` VALUES
(1,'GRD-1405-1001','TERM-1405-FALL','مهندس مهرداد شریفی','1079025413','جامع قوانین اینکوترمز ۲۰۲۰، اعتبارات اسنادی UCP600 و حمل بین‌الملل',10,10,100,95,96,94,95,'قبول ممتاز — مجاز به صدور گواهی QR ✅','تأیید نهایی نمره','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(2,'GRD-1405-1002','TERM-1405-FALL','سرکار خانم مهندس پگاه کاظمی','0078912349','جامع ثبت سفارش واردات NTSW، ارز نیمایی و اظهار گمرک EPL',10,9,90,90,94,92,92,'قبول ممتاز — مجاز به صدور گواهی QR ✅','تأیید نهایی نمره','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(3,'GRD-1405-1003','TERM-1405-FALL','جناب آقای نیما فرهادی','0491234567','تهیه و تنظیم قراردادهای تجاری بین‌المللی (CISG)',10,8,80,78,84,81,81,'قبول — مجاز به صدور گواهی QR ✅','درخواست بازبینی برگه عملی ثبت شد','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(4,'GRD-1405-1004','TERM-1405-FALL','جناب آقای کامیار رضوانی','1289043211','آموزش الزامی متقاضیان صدور کارت بازرگانی',10,6,60,74,70,72,72,'توقف صدور گواهی ⛔ (حضور ۶۰٪ کمتر از حدنصاب ۸۰٪)','نیازمند شرکت در ۲ جلسه جبرانی','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `academic_attendance_gradebook` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `academic_prereq_waitlist`
--

DROP TABLE IF EXISTS `academic_prereq_waitlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `academic_prereq_waitlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rule_or_queue_code` varchar(45) NOT NULL,
  `target_course_title` varchar(185) NOT NULL,
  `prerequisite_course_title` varchar(185) NOT NULL,
  `rule_type` varchar(40) NOT NULL DEFAULT 'پیش‌نیاز الزامی',
  `waitlist_applicant_name` varchar(150) NOT NULL,
  `applicant_priority_score` int(11) NOT NULL DEFAULT 90,
  `queue_status` varchar(50) NOT NULL DEFAULT 'در صف انتظار ظرفیت',
  `created_shamsi` varchar(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `rule_or_queue_code` (`rule_or_queue_code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `academic_prereq_waitlist`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `academic_prereq_waitlist` WRITE;
/*!40000 ALTER TABLE `academic_prereq_waitlist` DISABLE KEYS */;
INSERT INTO `academic_prereq_waitlist` VALUES
(1,'PRQ-1405-01','قراردادهای پیشرفته صادراتی و داوری بین‌المللی اتاق ICC','جامع قوانین اینکوترمز ۲۰۲۰ و UCP600','پیش‌نیاز الزامی سیستمی','مهندس امیرحسین تابش (فولاد زاگرس)',96,'نفر اول صف انتظار — آماده ارتقا به ثبت‌نام قطعی','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(2,'PRQ-1405-02','دادرسی مالیاتی پیشرفته و استرداد ارزش افزوده صادرات','کارگاه عملی سامانه مؤدیان و پایانه‌های فروشگاهی','پیش‌نیاز الزامی سیستمی','سرکار خانم سارا مرادی (صنایع غذایی بهاران)',91,'در صف انتظار ظرفیت','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(3,'PRQ-1405-03','مذاکره تجاری انگلیسی سطح پیشرفته در نمایشگاه‌های خارجی','تعیین سطح زبان تجاری حداقل B2 در مرکز آزمون اتاق','شرط امتیاز آزمون تعیین سطح','جناب آقای فرهاد کریمی',88,'ارتقایافته به ثبت‌نام قطعی ✅','۱۴۰۵/۰۷/۲۹','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `academic_prereq_waitlist` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `academic_terms_calendar`
--

DROP TABLE IF EXISTS `academic_terms_calendar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `academic_terms_calendar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `term_code` varchar(40) NOT NULL,
  `term_title` varchar(160) NOT NULL,
  `registration_window` varchar(90) NOT NULL,
  `add_drop_deadline` varchar(90) NOT NULL,
  `exams_window` varchar(90) NOT NULL,
  `target_capacity` int(11) NOT NULL DEFAULT 650,
  `term_status` varchar(30) NOT NULL DEFAULT 'در حال ثبت‌نام و اجرا',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_code` (`term_code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `academic_terms_calendar`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `academic_terms_calendar` WRITE;
/*!40000 ALTER TABLE `academic_terms_calendar` DISABLE KEYS */;
INSERT INTO `academic_terms_calendar` VALUES
(1,'TERM-1405-FALL','نیمسال اول (پاییز ۱۴۰۵) — دوره‌های تخصصی صادرات، گمرک و کارت بازرگانی','۱۴۰۵/۰۶/۲۰ لغایت ۱۴۰۵/۰۷/۱۵','تا ۷۲ ساعت پیش از جلسه اول هر کد دوره','۱۴۰۵/۰۹/۲۰ لغایت ۱۴۰۵/۰۹/۳۰',850,'فعال — در حال برگزاری کلاس‌ها','2026-10-23 21:48:59'),
(2,'TERM-1405-WINTER','نیمسال دوم (زمستان ۱۴۰۵) — هوش مصنوعی تجاری، سامانه مؤدیان و قراردادهای اوراسیا','۱۴۰۵/۰۹/۱۵ لغایت ۱۴۰۵/۱۰/۱۰','تا ۱۴۰۵/۱۰/۱۴ بدون کسر کارمزد','۱۴۰۵/۱۲/۱۰ لغایت ۱۴۰۵/۱۲/۲۲',920,'پیش‌ثبت‌نام سازمانی باز است','2026-10-23 21:48:59'),
(3,'TERM-1406-SPRING','ترم بهار ۱۴۰۶ — مدرسه عالی مدیران صنعتی و دیپلماسی تجاری اتاق','۱۴۰۵/۱۲/۱۵ لغایت ۱۴۰۶/۰۱/۲۰','تا ۱۴۰۶/۰۱/۲۵','۱۴۰۶/۰۳/۲۰ لغایت ۱۴۰۶/۰۳/۳۱',700,'در حال تدوین تقویم مصوب','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `academic_terms_calendar` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `accounting_vouchers`
--

DROP TABLE IF EXISTS `accounting_vouchers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounting_vouchers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `voucher_no` varchar(40) NOT NULL,
  `voucher_shamsi` varchar(25) NOT NULL,
  `group_code` varchar(40) NOT NULL,
  `kol_account` varchar(90) NOT NULL,
  `moein_account` varchar(120) NOT NULL,
  `tafsili_entity` varchar(150) NOT NULL,
  `debit_rial` bigint(20) NOT NULL DEFAULT 0,
  `credit_rial` bigint(20) NOT NULL DEFAULT 0,
  `voucher_desc` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `voucher_no` (`voucher_no`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounting_vouchers`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `accounting_vouchers` WRITE;
/*!40000 ALTER TABLE `accounting_vouchers` DISABLE KEYS */;
INSERT INTO `accounting_vouchers` VALUES
(1,'VCH-1405-401','۱۴۰۵/۰۷/۲۸','۱-دارایی جاری','۱۱۱۰-موجودی نقد و بانک','۱۱۱۰۲-بانک ملت جاری آموزش','تفصیلی ۹۰۰۱ - درگاه شاپرک',420000000,420000000,'سند دوبل تراز وصول شهریه قرارداد آموزشی صنایع فولاد (بدهکار بانک / بستانکار درآمد خدمات آموزشی)','2026-10-23 21:48:59'),
(2,'VCH-1405-402','۱۴۰۵/۰۷/۳۰','۶-هزینه‌های عملیاتی','۶۱۲۰-حق‌التدریس اساتید','۶۱۲۰۱-حق‌التدریس کارگاه تخصصی','تفصیلی ۳۰۱۲ - دکتر نیکزاد (پس از کسر ماده ۸۶)',136000000,136000000,'سند دوبل تراز تسویه حق‌التدریس و مالیات تکلیفی ماده ۸۶ خزانه‌داری کل','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `accounting_vouchers` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `adaptive_cat_sessions`
--

DROP TABLE IF EXISTS `adaptive_cat_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `adaptive_cat_sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_code` varchar(40) NOT NULL,
  `candidate_name` varchar(140) NOT NULL,
  `domain_title` varchar(160) NOT NULL,
  `questions_administered` int(11) DEFAULT 6,
  `final_difficulty_level` int(11) DEFAULT 4,
  `theta_ability` decimal(4,2) DEFAULT 1.85,
  `cefr_or_mastery_band` varchar(90) NOT NULL,
  `tab_switches_detected` int(11) DEFAULT 0,
  `collusion_similarity_pct` int(11) DEFAULT 4,
  `integrity_score` int(11) DEFAULT 98,
  `completed_shamsi` varchar(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `session_code` (`session_code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adaptive_cat_sessions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `adaptive_cat_sessions` WRITE;
/*!40000 ALTER TABLE `adaptive_cat_sessions` DISABLE KEYS */;
INSERT INTO `adaptive_cat_sessions` VALUES
(1,'CAT-1405-71','مهندس آرش کاظمی','آزمون تطبیقی حقوق تجارت بین‌الملل و اینکوترمز ۲۰۲۰',6,5,2.35,'سطح ۵ خبره ارشد (Master — Top 5%)',0,3,99,'۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59'),
(2,'CAT-1405-72','نگین شریعتی','آزمون تطبیقی تعیین سطح انگلیسی تجاری (Adaptive BEC)',6,4,1.62,'سطح C1 Advanced (مذاکره‌کننده مستقل)',1,6,94,'۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59'),
(3,'CAT-1405-73','پویا مرادی','آزمون جامع مقررات گمرکی و سامانه جامع تجارت',6,2,-0.45,'سطح B1 کاربردی پایه — نیازمند کارگاه عملی EPL',4,41,61,'۱۴۰۵/۰۷/۲۹','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `adaptive_cat_sessions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `ai_content_versions`
--

DROP TABLE IF EXISTS `ai_content_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_content_versions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ai_content_id` int(11) NOT NULL,
  `version_no` int(11) NOT NULL DEFAULT 1,
  `editor_id` int(11) NOT NULL,
  `change_note` varchar(255) DEFAULT 'نسخه اولیه پیش‌نویس هوش مصنوعی',
  `body_snapshot` longtext NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ai_content_versions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `ai_content_versions` WRITE;
/*!40000 ALTER TABLE `ai_content_versions` DISABLE KEYS */;
INSERT INTO `ai_content_versions` VALUES
(1,1,1,2,'تولید اولیه توسط استودیوی AI','پیش‌نویس اولیه دوره CBAM در ۴ سرفصل کلی','2026-10-23 21:48:59'),
(2,1,2,1,'بازبینی انسانی توسط مدیر آموزش و افزودن کارگاه محاسبه بهای تمام‌شده','نسخه بازبینی و تأیید شده انسانی آماده انتشار در کاتالوگ','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `ai_content_versions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `ai_contents`
--

DROP TABLE IF EXISTS `ai_contents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_contents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) DEFAULT NULL,
  `creator_id` int(11) NOT NULL,
  `content_kind` enum('course_draft','lesson_plan','quiz','microlearning','slides','summary') NOT NULL,
  `title` varchar(220) NOT NULL,
  `source_excerpt` longtext DEFAULT NULL,
  `current_version` int(11) DEFAULT 1,
  `body_markdown` longtext NOT NULL,
  `model_used` varchar(80) DEFAULT 'ai/gpt-4o-mini',
  `review_status` enum('ai_draft','in_review','human_approved','published') DEFAULT 'ai_draft',
  `approved_by` int(11) DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ai_contents`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `ai_contents` WRITE;
/*!40000 ALTER TABLE `ai_contents` DISABLE KEYS */;
INSERT INTO `ai_contents` VALUES
(1,6,2,'course_draft','سرفصل پیشنهادی کارگاه مقررات کربن مرزی اتحادیه اروپا (CBAM)','مستخرج از بخشنامه اتحادیه اروپا ۲۰۲۶ ویژه صنایع فولاد، آلومینیوم، سیمان و کود شیمیایی',2,'## ساختار پیشنهادی دوره ۱۶ ساعته CBAM\n1. **مبانی حقوقی CBAM و تقویم اجرایی ۲۰۲۶-۲۰۳۰**\n2. **روش‌شناسی محاسبه انتشار مستقیم و غیرمستقیم گازهای گلخانه‌ای**\n3. **نحوه تکمیل گزارش فصلی برای واردکننده اروپایی**\n4. **کارگاه عملی محاسبه هزینه گواهی کربن بر قیمت تمام‌شده صادراتی**','ai/gpt-4o-mini','human_approved',1,'2026-10-23 21:48:59','2026-10-23 21:48:59'),
(2,3,2,'quiz','بانک سؤالات آزمون هوش مصنوعی در بازاریابی صادراتی (پیش‌نویس AI)','فصل ۱ تا ۳ جزوه دوره AID-301',1,'### سؤال ۱ (چهارگزینه‌ای)\nکدام شاخص برای اولویت‌بندی بازار هدف صادراتی در تحلیل داده‌محور اهمیت بالاتری دارد؟\n- الف) صرفاً فاصله جغرافیایی\n- ب) نرخ رشد واردات ۵ ساله کد تعرفه HS شش‌رقمی و نرخ تعرفه ترجیحی *(پاسخ صحیح)*\n- ج) جمعیت کل کشور مقصد\n- د) تعداد رقبا بدون توجه به تعرفه','ai/gpt-4o-mini','ai_draft',NULL,NULL,'2026-10-23 21:48:59');
/*!40000 ALTER TABLE `ai_contents` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `ai_cv_match_interviews`
--

DROP TABLE IF EXISTS `ai_cv_match_interviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_cv_match_interviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `match_code` varchar(40) NOT NULL,
  `candidate_name` varchar(150) NOT NULL,
  `target_company` varchar(160) NOT NULL,
  `target_role` varchar(160) NOT NULL,
  `verified_certs_summary` varchar(220) NOT NULL,
  `vector_similarity_pct` int(11) NOT NULL DEFAULT 91,
  `generated_interview_guide` text NOT NULL,
  `matched_shamsi` varchar(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `match_code` (`match_code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ai_cv_match_interviews`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `ai_cv_match_interviews` WRITE;
/*!40000 ALTER TABLE `ai_cv_match_interviews` DISABLE KEYS */;
INSERT INTO `ai_cv_match_interviews` VALUES
(1,'CVM-1405-701','مهندس مهرداد شریفی','مجتمع پتروشیمی و پلیمر استان','کارشناس ارشد قراردادهای بین‌المللی و اعتبارات اسنادی','گواهی جامع Incoterms 2020 + نمره ۹۴ آزمایشگاه اسناد UCP600 + سطح C1 انگلیسی تجاری',96,'سؤال ۱: نحوه اصلاح اختلاف تاریخ حمل بارنامه با شرایط L/C در ماده ۱۴ UCP600؟ | سؤال ۲: دلیل انتخاب CIP به جای CIF در حمل کانتینری پتروشیمی؟ | سؤال ۳: مدیریت سقف خسارت تأخیر فورس‌ماژور.','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `ai_cv_match_interviews` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `ai_prompts`
--

DROP TABLE IF EXISTS `ai_prompts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_prompts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(60) NOT NULL,
  `title` varchar(180) NOT NULL,
  `module_name` varchar(80) NOT NULL,
  `system_prompt` text NOT NULL,
  `temperature` decimal(3,2) DEFAULT 0.40,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ai_prompts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `ai_prompts` WRITE;
/*!40000 ALTER TABLE `ai_prompts` DISABLE KEYS */;
INSERT INTO `ai_prompts` VALUES
(1,'SYLLABUS_GEN','طراح سرفصل استاندارد دوره‌های مؤسسه آموزشی آدان','AI Studio','تو طراح ارشد آموزشی مؤسسه آموزشی آدان هستی. خروجی را کاملاً کاربردی، بومی‌سازی‌شده با قوانین تجاری و گمرکی ایران و نیاز بنگاه‌های صادراتی به صورت پیش‌نویس ساختارمند فارسی بنویس.',0.45),
(2,'TNA_GAP_ADVISOR','تحلیل‌گر شکاف شایستگی و پیشنهاد مسیر یادگیری','Competency TNA','بر اساس ماتریس سطح فعلی و سطح هدف شایستگی‌های بازرگانی و مدیریتی، مهم‌ترین شکاف‌ها را اولویت‌بندی کن و دوره دقیق متناظر از کاتالوگ مؤسسه آموزشی آدان پیشنهاد بده.',0.30),
(3,'BI_EXECUTIVE_ANALYST','مشاور هوش تجاری هیئت رئیسه مؤسسه آموزشی آدان','BI & Reports','داده‌های مالی، ثبت‌نام و اثربخشی کرکپاتریک واحد آموزش را تحلیل کن و ۳ تصمیم اجرایی مشخص برای افزایش اثرگذاری استانی پیشنهاد بده.',0.35);
/*!40000 ALTER TABLE `ai_prompts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `ai_schedule_optimizations`
--

DROP TABLE IF EXISTS `ai_schedule_optimizations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_schedule_optimizations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course_code` varchar(40) NOT NULL,
  `course_title` varchar(200) NOT NULL,
  `instructor_name` varchar(140) NOT NULL,
  `classroom_name` varchar(140) NOT NULL,
  `assigned_slot` varchar(90) NOT NULL,
  `predicted_learners` int(11) DEFAULT 22,
  `room_capacity` int(11) DEFAULT 25,
  `utilization_pct` int(11) DEFAULT 88,
  `conflict_status` varchar(80) DEFAULT 'بدون تداخل (بهینه ۱۰۰٪)',
  `generated_shamsi` varchar(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ai_schedule_optimizations`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `ai_schedule_optimizations` WRITE;
/*!40000 ALTER TABLE `ai_schedule_optimizations` DISABLE KEYS */;
INSERT INTO `ai_schedule_optimizations` VALUES
(1,'TRD-101','جامع اینکوترمز ۲۰۲۰، اعتبارات اسنادی UCP600 و قراردادهای بین‌المللی','دکتر کامران فرهمند','تالار بین‌المللی خلیج فارس','شنبه‌ها و دوشنبه‌ها — ۱۴:۰۰ تا ۱۸:۰۰',28,30,93,'بدون تداخل استاد و سالن (بهینه ۹۳٪)','۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59'),
(2,'CC-201','بسته الزامی متقاضیان صدور و تمدید کارت بازرگانی (نسخه ۱۴۰۵)','مهندس الهام شریفی','سایت کامپیوتر و شبیه‌ساز گمرک','یکشنبه‌ها و سه‌شنبه‌ها — ۰۸:۳۰ تا ۱۲:۳۰',23,25,92,'تطبیق ۱۰۰٪ با تجهیزات کارگاهی NTSW','۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59'),
(3,'FIN-305','سامانه مؤدیان، پایانه‌های فروشگاهی و دادرسی مالیاتی صنایع','دکتر بهزاد نوری','کلاس هوشمند امیرکبیر','چهارشنبه‌ها — ۱۳:۳۰ تا ۱۹:۳۰',19,20,95,'حداکثر بهره‌وری صندلی (۹۵٪)','۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `ai_schedule_optimizations` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `ai_skill_job_matches`
--

DROP TABLE IF EXISTS `ai_skill_job_matches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_skill_job_matches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `candidate_name` varchar(140) NOT NULL,
  `psychometric_badge` varchar(120) NOT NULL,
  `target_company` varchar(180) NOT NULL,
  `job_role_title` varchar(180) NOT NULL,
  `match_score_pct` int(11) DEFAULT 91,
  `verified_skills` varchar(240) NOT NULL,
  `recommended_gap_course` varchar(190) NOT NULL,
  `status` varchar(60) DEFAULT 'معرفی‌شده هوشمند به صنعت',
  `matched_shamsi` varchar(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ai_skill_job_matches`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `ai_skill_job_matches` WRITE;
/*!40000 ALTER TABLE `ai_skill_job_matches` DISABLE KEYS */;
INSERT INTO `ai_skill_job_matches` VALUES
(1,'مهندس آرش کاظمی','ENTJ | زبان تجاری C1','مجتمع فولاد و ذوب‌آهن زاگرس','مدیر قراردادها و صادرات بازار اوراسیا',95,'گواهی اینکوترمز ۲۰۲۰ + نمره ۹۲ آزمون UCP600 + تیپ فرمانده ENTJ','گزارش‌دهی کربن مرزی اروپا (EU CBAM)','معرفی‌شده جهت مصاحبه نهایی','۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59'),
(2,'سارا محمدی‌پور','ECS هالند | DISC: نفوذگر (I)','گروه صنعتی خشکبار زرین‌صادر','کارشناس ارشد مذاکرات بین‌الملل و نمایشگاه‌ها',91,'تسلط انگلیسی C1 + کارنامه برتر شبیه‌ساز مذاکره تجاری','حقوق داوری مرجع بین‌المللی ICC ICC','تأیید اولیه کارفرما','۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59'),
(3,'امیرحسین رضایی','ISTJ | دقت تحلیلی ۹۴٪','شرکت پتروشیمی و پلیمر تابان','مسئول ثبت سفارش NTSW، اظهار EPL و رفع تعهد ارزی',89,'گواهی الزامی کارت بازرگانی + تسلط کامل محاسبه حقوق گمرکی','کارگاه پیشرفته تهاتر ارزی صادراتی','آماده معرفی فوری','۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `ai_skill_job_matches` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `ai_usage_logs`
--

DROP TABLE IF EXISTS `ai_usage_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_usage_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `module_name` varchar(80) NOT NULL,
  `provider` varchar(50) DEFAULT 'AI',
  `model_name` varchar(80) NOT NULL,
  `prompt_tokens` int(11) DEFAULT 0,
  `completion_tokens` int(11) DEFAULT 0,
  `latency_ms` int(11) DEFAULT 0,
  `execution_mode` enum('live_api','simulation_fallback') DEFAULT 'simulation_fallback',
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ai_usage_logs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `ai_usage_logs` WRITE;
/*!40000 ALTER TABLE `ai_usage_logs` DISABLE KEYS */;
INSERT INTO `ai_usage_logs` VALUES
(1,1,'AI Studio','AI','gpt-4o-mini',640,920,840,'simulation_fallback','2026-10-23 21:48:59'),
(2,2,'Competency TNA','AI','gpt-4o-mini',490,610,690,'simulation_fallback','2026-10-23 21:48:59'),
(3,1,'BI Report Narrative','AI','gpt-4o-mini',530,480,620,'simulation_fallback','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `ai_usage_logs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `alumni_network_posts`
--

DROP TABLE IF EXISTS `alumni_network_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `alumni_network_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `author_name` varchar(160) NOT NULL,
  `company_and_role` varchar(180) NOT NULL,
  `graduated_course` varchar(180) NOT NULL,
  `collaboration_type` enum('کنسرسیوم صادراتی','تأمین مواد اولیه','همرسانی حمل‌ونقل','پرسش تخصصی همتایان') DEFAULT 'کنسرسیوم صادراتی',
  `proposal_body` text NOT NULL,
  `responses_count` int(11) DEFAULT 4,
  `posted_shamsi` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alumni_network_posts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `alumni_network_posts` WRITE;
/*!40000 ALTER TABLE `alumni_network_posts` DISABLE KEYS */;
INSERT INTO `alumni_network_posts` VALUES
(1,'مهندس امیرحسین کاظمی','مدیر صادرات کاشی کویر','آکادمی جامع مدیریت صادرات اتاق','کنسرسیوم صادراتی','پیشنهاد تشکیل کنسرسیوم مشترک ارسال کانتینر ترکیبی (LCL) مصالح ساختمانی استان به بندر صحار عمان برای کاهش ۴۰٪ هزینه حمل.',7,'۱۴۰۵/۰۷/۲۶');
/*!40000 ALTER TABLE `alumni_network_posts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `user_role` varchar(50) DEFAULT NULL,
  `module` varchar(80) NOT NULL,
  `action` varchar(120) NOT NULL,
  `entity_type` varchar(80) DEFAULT NULL,
  `entity_id` int(11) DEFAULT NULL,
  `details_json` longtext DEFAULT NULL,
  `ip_address` varchar(64) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_audit_mod` (`module`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `b2b_account_touchpoints`
--

DROP TABLE IF EXISTS `b2b_account_touchpoints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `b2b_account_touchpoints` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `proposal_code` varchar(45) NOT NULL,
  `company_name` varchar(160) NOT NULL,
  `channel_source` varchar(90) NOT NULL,
  `contact_summary` varchar(230) NOT NULL,
  `proposed_package_rial` bigint(20) NOT NULL DEFAULT 680000000,
  `win_probability_pct` int(11) NOT NULL DEFAULT 78,
  `next_followup_shamsi` varchar(40) DEFAULT '۱۴۰۵/۰۸/۰۵',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `proposal_code` (`proposal_code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `b2b_account_touchpoints`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `b2b_account_touchpoints` WRITE;
/*!40000 ALTER TABLE `b2b_account_touchpoints` DISABLE KEYS */;
INSERT INTO `b2b_account_touchpoints` VALUES
(1,'PRP-1405-501','مجتمع پتروشیمی و پلیمر استان','بازوی رسمی بله + همایش صادرات','ارسال پروپوزال اختصاصی آموزش ۳۵ کارشناس بازرگانی خارجی و گمرک با مشوق سازمانی',890000000,84,'۱۴۰۵/۰۸/۰۴','2026-10-23 21:48:59'),
(2,'PRP-1405-502','گروه صنایع غذایی بهاران','رهیاب هوشمند پورتال عمومی','جلسه آنلاین با مدیر منابع انسانی جهت فعال‌سازی سهمیه قرارداد سالانه',420000000,76,'۱۴۰۵/۰۸/۰۶','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `b2b_account_touchpoints` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `b2b_matchmaking_slots`
--

DROP TABLE IF EXISTS `b2b_matchmaking_slots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `b2b_matchmaking_slots` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mission_id` int(11) NOT NULL DEFAULT 1,
  `slot_time` varchar(40) NOT NULL,
  `table_no` varchar(25) NOT NULL,
  `iranian_company` varchar(190) NOT NULL,
  `foreign_counterpart` varchar(190) NOT NULL,
  `product_hs_focus` varchar(150) NOT NULL,
  `interpreter_lang` varchar(50) DEFAULT 'عربی / انگلیسی',
  `outcome_status` varchar(60) DEFAULT 'برنامه‌ریزی شده',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `b2b_matchmaking_slots`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `b2b_matchmaking_slots` WRITE;
/*!40000 ALTER TABLE `b2b_matchmaking_slots` DISABLE KEYS */;
INSERT INTO `b2b_matchmaking_slots` VALUES
(1,1,'۱۰:۰۰ تا ۱۰:۳۰','میز B2B-01','شرکت پسته رفسنجان گستر','Al-Noor Hypermarkets LLC (مسقط)','پسته اکبری بسته‌بندی خرده‌فروشی (0802.52)','عربی تجاری','پیش‌نویس تفاهم‌نامه ۵۰ هزار دلاری','2026-10-23 21:48:59'),
(2,1,'۱۰:۳۵ تا ۱۱:۰۵','میز B2B-04','کارخانجات کاشی کویر استان','Gulf Ceramic Projects (دبی)','اسلب پرسلانی ساختمانی (6907.21)','انگلیسی','ارسال نمونه کانتینری','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `b2b_matchmaking_slots` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `b2b_quota_burn_alerts`
--

DROP TABLE IF EXISTS `b2b_quota_burn_alerts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `b2b_quota_burn_alerts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `org_name` varchar(180) NOT NULL,
  `contract_title` varchar(190) NOT NULL,
  `elapsed_year_pct` int(11) DEFAULT 68,
  `quota_used_pct` int(11) DEFAULT 31,
  `burn_status` varchar(90) NOT NULL,
  `auto_triggered_offer` varchar(230) NOT NULL,
  `monitored_shamsi` varchar(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `b2b_quota_burn_alerts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `b2b_quota_burn_alerts` WRITE;
/*!40000 ALTER TABLE `b2b_quota_burn_alerts` DISABLE KEYS */;
INSERT INTO `b2b_quota_burn_alerts` VALUES
(1,'صنایع غذایی و لبنی بهاران استان','قرارداد سالانه آموزش مدیران میانی و صادرات',72,28,'بحران کم‌مصرفی سهمیه (خطر عدم تمدید سال بعد)','ارسال خودکار دعوت‌نامه اختصاصی کارگاه عملی اوراسیا برای ۱۲ نفر بدون هزینه اضافه','۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59'),
(2,'مجتمع فولاد و ذوب‌آهن زاگرس','قرارداد جامع توانمندسازی فنی و بازرگانی ۱۴۰۵',65,89,'مصرف عالی — آماده پیشنهاد الحاقیه افزایش سقف','ارسال خودکار پیش‌نویس الحاقیه ۵۰ نفر-دوره جدید با ۱۵٪ مشوق وفاداری','۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `b2b_quota_burn_alerts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `bi_custom_reports`
--

DROP TABLE IF EXISTS `bi_custom_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bi_custom_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `report_code` varchar(50) NOT NULL,
  `title` varchar(200) NOT NULL,
  `category` varchar(80) NOT NULL DEFAULT 'گزارش مدیریتی',
  `dataset_key` varchar(60) NOT NULL DEFAULT 'courses_mart',
  `dimension_field` varchar(60) NOT NULL DEFAULT 'level',
  `metric_field` varchar(60) NOT NULL DEFAULT 'tuition_rial',
  `secondary_metric` varchar(60) NOT NULL DEFAULT 'duration_hours',
  `agg_func` varchar(20) NOT NULL DEFAULT 'SUM',
  `filter_field` varchar(60) NOT NULL DEFAULT '',
  `filter_op` varchar(20) NOT NULL DEFAULT '=',
  `filter_val` varchar(120) NOT NULL DEFAULT '',
  `sort_dir` varchar(10) NOT NULL DEFAULT 'DESC',
  `row_limit` int(11) NOT NULL DEFAULT 25,
  `chart_type` varchar(30) NOT NULL DEFAULT 'bar',
  `natural_query_text` varchar(255) NOT NULL DEFAULT '',
  `ai_narrative` text DEFAULT NULL,
  `created_via` varchar(30) NOT NULL DEFAULT 'click',
  `created_by_name` varchar(120) NOT NULL DEFAULT 'مدیرکل آموزش',
  `created_shamsi` varchar(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `report_code` (`report_code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bi_custom_reports`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `bi_custom_reports` WRITE;
/*!40000 ALTER TABLE `bi_custom_reports` DISABLE KEYS */;
INSERT INTO `bi_custom_reports` VALUES
(1,'RPT-BI-101','تحلیل جامع ظرفیت درآمدی دوره‌ها به تفکیک شیوه برگزاری','آموزش و برنامه‌ریزی','courses_mart','delivery_mode','tuition_rial','duration_hours','SUM','','=','','DESC',25,'bar','مجموع شهریه و ساعت دوره‌ها به تفکیک شیوه برگزاری با نمودار ستونی','دوره‌های حضوری-کارگاهی و آنلاین همزمان بیشترین سهم ارزش ریالی کاتالوگ را به خود اختصاص داده‌اند؛ پیشنهاد می‌شود ظرفیت کارگاه‌های عملی صادرات ۲۰٪ افزایش یابد.','click','دکتر کیارش رادمهر','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(2,'RPT-BI-102','گزارش ارزش قیف فروش سازمانی به تفکیک مرحله مذاکره','فروش سازمانی و CRM','crm_mart','stage','estimated_value_rial','probability_pct','SUM','','=','','DESC',25,'funnel','قیف فروش سازمانی و مبلغ قراردادهای پیشنهادی بر اساس مرحله مذاکره','تمرکز پیگیری تلفنی و جلسه حضوری بر پرونده‌های مرحله ارسال پیش‌فاکتور، نرخ تبدیل قراردادهای سالانه B2B را به شکل محسوسی ارتقا می‌دهد.','drag_drop','مدیر CRM سازمانی','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(3,'RPT-BI-103','پایش مصرف سهمیه آموزشی شرکت‌های عضو به تفکیک صنعت','امور بنگاه‌ها','orgs_mart','industry','used_quota_hours','annual_quota_hours','SUM','','=','','DESC',25,'radar','مقایسه ساعات سهمیه مصرف‌شده صنایع عضو به تفکیک بخش صنعتی','صنایع فولاد، پلیمر و غذایی بیشترین نرخ بهره‌برداری از سهمیه آموزشی اتاق را ثبت کرده‌اند؛ ارسال بسته پیشنهادی اختصاصی برای سایر صنایع توصیه می‌شود.','text','مهندس پگاه کاظمی','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(4,'RPT-BI-104','تحلیل بار ترافیکی مکاتبات دبیرخانه بر اساس سطح فوریت','اتوماسیون اداری','oa_mart','priority_level','id','id','COUNT','','=','','DESC',25,'donut','تعداد نامه‌های اتوماسیون اداری به تفکیک فوریت','بخش قابل توجهی از مکاتبات دارای قید فوری/آنی هستند؛ فعال‌سازی امضای دیجیتال مستقیم زمان گردش مکاتبات را به کمتر از ۴ ساعت رسانده است.','voice','مسئول دبیرخانه','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `bi_custom_reports` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `bi_dashboard_widgets`
--

DROP TABLE IF EXISTS `bi_dashboard_widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bi_dashboard_widgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dashboard_id` int(11) NOT NULL DEFAULT 1,
  `widget_code` varchar(50) NOT NULL,
  `title` varchar(180) NOT NULL,
  `subtitle` varchar(220) NOT NULL DEFAULT '',
  `dataset_key` varchar(60) NOT NULL DEFAULT 'courses_mart',
  `dimension_field` varchar(60) NOT NULL DEFAULT 'level',
  `metric_field` varchar(60) NOT NULL DEFAULT 'tuition_rial',
  `agg_func` varchar(20) NOT NULL DEFAULT 'SUM',
  `filter_field` varchar(60) NOT NULL DEFAULT '',
  `filter_op` varchar(20) NOT NULL DEFAULT '=',
  `filter_val` varchar(120) NOT NULL DEFAULT '',
  `chart_type` varchar(30) NOT NULL DEFAULT 'bar',
  `col_span` int(11) NOT NULL DEFAULT 6,
  `sort_order` int(11) NOT NULL DEFAULT 10,
  `color_palette` varchar(30) NOT NULL DEFAULT 'indigo',
  `created_via` varchar(30) NOT NULL DEFAULT 'drag_drop',
  `updated_shamsi` varchar(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `widget_code` (`widget_code`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bi_dashboard_widgets`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `bi_dashboard_widgets` WRITE;
/*!40000 ALTER TABLE `bi_dashboard_widgets` DISABLE KEYS */;
INSERT INTO `bi_dashboard_widgets` VALUES
(1,1,'WDG-EXEC-01','ترکیب شهریه دوره‌ها به تفکیک سطح تخصصی','مقایسه حجم ریالی کاتالوگ دوره‌های مقدماتی، میانی و پیشرفته','courses_mart','level','tuition_rial','SUM','','=','','bar',6,10,'indigo','drag_drop','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(2,1,'WDG-EXEC-02','قیف فروش سازمانی و ارزش فرصت‌های CRM','توزیع ریالی مذاکرات و قراردادهای سازمانی در مراحل فروش','crm_mart','stage','estimated_value_rial','SUM','','=','','funnel',6,20,'emerald','click','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(3,1,'WDG-EXEC-03','سهم وضعیت صورت‌حساب‌ها و وصولی خزانه','نسبت فاکتورهای پرداخت‌شده، اقساطی و در انتظار تسویه','invoices_mart','status','total_rial','SUM','','=','','donut',4,30,'amber','text','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(4,1,'WDG-EXEC-04','عملکرد بودجه و تربیت فراگیر در دفاتر شهرستان‌ها','مقایسه چندبعدی عملکرد شعب شهرستانی استان','branches_mart','county_name','spent_budget_rial','SUM','','=','','radar',4,40,'violet','voice','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(5,1,'WDG-EXEC-05','پایش وضعیت نامه‌های رسمی اتوماسیون اداری','توزیع مکاتبات دبیرخانه بر پایه نوع نامه','oa_mart','letter_type','id','COUNT','','=','','hbar',4,50,'cyan','drag_drop','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(6,1,'WDG-EXEC-06','ماتریس حرارتی پیشرفت و نمره ثبت‌نام‌کنندگان','میانگین نمره نهایی فراگیران به تفکیک کانال جذب','enrollments_mart','source','final_score','AVG','','=','','line',12,60,'indigo','click','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(7,2,'WDG-FIN-01','گردش بدهکار اسناد حسابداری ۴ سطحی به تفکیک حساب کل','توازن حساب‌های کل در دفتر روزنامه و کل','vouchers_mart','kol_account','debit_rial','SUM','','=','','bar',6,10,'emerald','drag_drop','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(8,2,'WDG-FIN-02','ترکیب روش‌های پرداخت در صورت‌حساب‌های صادره','نقدی، اقساطی و سهمیه سازمانی','invoices_mart','payment_mode','total_rial','SUM','','=','','donut',6,20,'amber','click','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(9,3,'WDG-ACA-01','وضعیت احراز صلاحیت پرونده‌های کارت بازرگانی','تفکیک پرونده‌های تأییدشده و در جریان آموزش الزامی','cards_mart','clearance_status','exam_score','AVG','','=','','bar',6,10,'indigo','voice','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(10,3,'WDG-ACA-02','تقاضای استخدام صنایع عضو در تابلوی کاریابی','تعداد متقاضیان جذب‌شده به تفکیک شهر صنعتی','career_mart','city_location','applicants_count','SUM','','=','','hbar',6,20,'violet','text','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `bi_dashboard_widgets` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `bi_dashboards`
--

DROP TABLE IF EXISTS `bi_dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bi_dashboards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slug` varchar(70) NOT NULL,
  `title` varchar(180) NOT NULL,
  `subtitle` varchar(255) NOT NULL DEFAULT '',
  `category` varchar(80) NOT NULL DEFAULT 'مدیریت کلان',
  `accent_color` varchar(20) NOT NULL DEFAULT '#4f46e5',
  `layout_density` varchar(30) NOT NULL DEFAULT 'balanced',
  `created_via` varchar(30) NOT NULL DEFAULT 'click',
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `created_by_name` varchar(120) NOT NULL DEFAULT 'مدیرکل آموزش',
  `updated_shamsi` varchar(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bi_dashboards`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `bi_dashboards` WRITE;
/*!40000 ALTER TABLE `bi_dashboards` DISABLE KEYS */;
INSERT INTO `bi_dashboards` VALUES
(1,'executive_command','داشبورد جامع فرماندهی و هیئت‌رییسه اتاق','نمای ۳۶۰ درجه درآمد، قیف فروش سازمانی، دوره‌ها، شعب شهرستان‌ها و مکاتبات اداری','مدیریت کلان','#4f46e5','balanced','click',1,'دکتر کیارش رادمهر','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(2,'finance_revenue_board','داشبورد تخصصی مالی، صورت‌حساب‌ها و اسناد حسابداری','پایش زنده تحقق درآمد، مالیات بر ارزش افزوده، اسناد ۴ سطحی و بودجه دفاتر','مالی و بودجه','#0f766e','compact','drag_drop',0,'مدیر امور مالی','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(3,'academic_operations_board','داشبورد عملیات آموزشی، کارت بازرگانی و اشتغال','تحلیل ثبت‌نام، نمرات، پرونده‌های کارت بازرگانی، کاریابی و کارتابل اداری','آموزش و عملیات','#d97706','spacious','voice',0,'مهندس پگاه کاظمی','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `bi_dashboards` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `bi_goals_okrs`
--

DROP TABLE IF EXISTS `bi_goals_okrs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bi_goals_okrs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goal_code` varchar(50) NOT NULL,
  `title` varchar(200) NOT NULL,
  `department_owner` varchar(120) NOT NULL DEFAULT 'معاونت آموزش',
  `horizon_label` varchar(70) NOT NULL DEFAULT 'نیمسال دوم ۱۴۰۵',
  `live_metric_source` varchar(60) NOT NULL DEFAULT 'invoices_total_rial',
  `baseline_value` double NOT NULL DEFAULT 0,
  `manual_boost_value` double NOT NULL DEFAULT 0,
  `target_value` double NOT NULL DEFAULT 100,
  `unit_label` varchar(40) NOT NULL DEFAULT 'ریال',
  `weight_pct` int(11) NOT NULL DEFAULT 20,
  `alert_threshold_pct` int(11) NOT NULL DEFAULT 70,
  `key_results_note` varchar(255) NOT NULL DEFAULT '',
  `created_via` varchar(30) NOT NULL DEFAULT 'click',
  `updated_shamsi` varchar(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `goal_code` (`goal_code`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bi_goals_okrs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `bi_goals_okrs` WRITE;
/*!40000 ALTER TABLE `bi_goals_okrs` DISABLE KEYS */;
INSERT INTO `bi_goals_okrs` VALUES
(1,'OKR-1405-01','تحقق درآمد وصولی و صورت‌حساب‌های آموزشی نیمسال','مدیریت امور مالی','نیمسال دوم ۱۴۰۵','invoices_total_rial',0,185000000,450000000,'ریال',25,70,'افزایش قراردادهای سازمانی صنایع بزرگ و تسویه بهنگام اقساط','click','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(2,'OKR-1405-02','گسترش ارزش پایپ‌لاین قراردادهای سازمانی (B2B CRM)','واحد توسعه بازار و CRM','سال مالی ۱۴۰۵','crm_pipeline_rial',0,120000000,1500000000,'ریال',20,65,'جذب ۱۵ واحد صنعتی جدید از شهرک‌های صنعتی استان','drag_drop','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(3,'OKR-1405-03','ارتقای میانگین امتیاز رضایت کیفی فراگیران از دوره‌ها','معاونت آموزش و کیفیت','فصل پاییز ۱۴۰۵','courses_avg_rating_pct',82,0,96,'درصد',15,85,'ارزشیابی مستمر اساتید و بازنگری کارگاه‌های کاربردی','text','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(4,'OKR-1405-04','توسعه پوشش تربیت مهارت‌آموختگان در دفاتر شهرستان‌ها','امور شعب شهرستانی','سال ۱۴۰۵','branches_learners_sum',0,40,650,'نفر',15,70,'اجرای دوره‌های مشترک صادرات و مالیات در تمام شهرستان‌ها','voice','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(5,'OKR-1405-05','شتاب‌بخشی به ثبت و امضای مکاتبات رسمی بدون کاغذ','دبیرخانه و اتوماسیون اداری','پاییز ۱۴۰۵','oa_letters_count',0,14,25,'فقره نامه',10,60,'گذار ۱۰۰ درصدی مکاتبات واحدها به کارتابل دیجیتال','click','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(6,'OKR-1405-06','تکمیل جذب متقاضیان معرفی‌شده به فرصت‌های شغلی اعضا','مرکز کاریابی و اشتغال','نیمسال دوم ۱۴۰۵','career_applicants_sum',0,15,120,'متقاضی',15,65,'اتصال مستقیم کارنامه نفرات برتر دوره‌ها به کارفرمایان عضو','text','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `bi_goals_okrs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `bi_report_schedules`
--

DROP TABLE IF EXISTS `bi_report_schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bi_report_schedules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `schedule_code` varchar(50) NOT NULL,
  `report_title` varchar(190) NOT NULL,
  `dataset_key` varchar(60) NOT NULL DEFAULT 'invoices_mart',
  `frequency_label` varchar(70) NOT NULL DEFAULT 'هفتگی — شنبه‌ها ساعت ۰۸:۰۰',
  `cron_expr` varchar(50) NOT NULL DEFAULT '0 8 * * 6',
  `delivery_channel` varchar(80) NOT NULL DEFAULT 'کارتابل مدیریتی + ایمیل + پیام‌رسان',
  `recipients_list` varchar(220) NOT NULL DEFAULT 'هیئت رئیسه، مدیرکل آموزش، مدیر مالی',
  `export_format` varchar(30) NOT NULL DEFAULT 'CSV + PDF A4',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `last_run_shamsi` varchar(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `schedule_code` (`schedule_code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bi_report_schedules`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `bi_report_schedules` WRITE;
/*!40000 ALTER TABLE `bi_report_schedules` DISABLE KEYS */;
INSERT INTO `bi_report_schedules` VALUES
(1,'SCH-BI-01','خلاصه مدیریتی درآمد، وصولی و انحراف بودجه هفتگی','invoices_mart','هفتگی — شنبه‌ها ساعت ۰۷:۳۰','30 7 * * 6','کارتابل اتوماسیون + ایمیل سازمانی','مدیریت مؤسسه آدان، دبیرکل، مدیرکل آموزش، مدیر مالی','PDF A4 + Excel',1,'۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(2,'SCH-BI-02','پایش قیف قراردادهای سازمانی و سهمیه مصرفی اعضا','crm_mart','دو هفته یک‌بار — دوشنبه‌ها ساعت ۰۹:۰۰','0 9 * * 1','کارتابل مدیریتی + پیام‌رسان بومی','واحد CRM، معاونت آموزش','CSV UTF-8',1,'۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(3,'SCH-BI-03','کارنامه عملکرد دفاتر شهرستان‌ها و پرونده‌های کارت بازرگانی','branches_mart','ماهانه — یکم هر ماه ساعت ۰۸:۰۰','0 8 1 * *','کارتابل اتوماسیون اداری','مسئولان شعب شهرستان‌ها، واحد نظارت','PDF A4',1,'۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `bi_report_schedules` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `bi_whatif_scenarios`
--

DROP TABLE IF EXISTS `bi_whatif_scenarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bi_whatif_scenarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `scenario_code` varchar(50) NOT NULL,
  `title` varchar(190) NOT NULL,
  `tuition_delta_pct` int(11) NOT NULL DEFAULT 10,
  `enrollment_growth_pct` int(11) NOT NULL DEFAULT 25,
  `b2b_conversion_pct` int(11) NOT NULL DEFAULT 20,
  `cost_change_pct` int(11) NOT NULL DEFAULT -5,
  `projected_revenue_rial` bigint(20) NOT NULL DEFAULT 0,
  `projected_surplus_rial` bigint(20) NOT NULL DEFAULT 0,
  `ai_recommendation` text DEFAULT NULL,
  `created_by_name` varchar(120) NOT NULL DEFAULT 'مدیرکل آموزش',
  `created_shamsi` varchar(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `scenario_code` (`scenario_code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bi_whatif_scenarios`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `bi_whatif_scenarios` WRITE;
/*!40000 ALTER TABLE `bi_whatif_scenarios` DISABLE KEYS */;
INSERT INTO `bi_whatif_scenarios` VALUES
(1,'SCN-BI-01','سناریوی توسعه دوره‌های صادراتی اوراسیا با تخفیف گروهی اعضا',10,35,30,-8,685000000,294000000,'افزایش ۳۵ درصدی ظرفیت به همراه بهینه‌سازی ۸ درصدی هزینه‌های اجرایی از طریق کلاس‌های ترکیبی، حاشیه مازاد عملیاتی را ۴۲٪ ارتقا می‌دهد.','دکتر کیارش رادمهر','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(2,'SCN-BI-02','سناریوی تثبیت شهریه فعلی با تمرکز بر قراردادهای B2B شهرک‌ها',0,20,45,-5,590000000,241000000,'تثبیت شهریه در کنار نرخ تبدیل ۴۵٪ مذاکرات سازمانی، ریسک ریزش متقاضیان آزاد را به حداقل می‌رساند.','مدیر امور مالی','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `bi_whatif_scenarios` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `bizsim_league_rounds`
--

DROP TABLE IF EXISTS `bizsim_league_rounds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bizsim_league_rounds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `round_code` varchar(40) NOT NULL,
  `team_name` varchar(150) NOT NULL,
  `quarter_label` varchar(50) NOT NULL,
  `export_pricing_usd` decimal(10,2) NOT NULL DEFAULT 1250.00,
  `fx_hedge_ratio_pct` int(11) NOT NULL DEFAULT 60,
  `rnd_investment_pct` int(11) NOT NULL DEFAULT 12,
  `simulated_ebitda_usd` bigint(20) NOT NULL DEFAULT 185000,
  `elo_rating` int(11) NOT NULL DEFAULT 1620,
  `ai_referee_note` varchar(255) NOT NULL,
  `played_shamsi` varchar(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `round_code` (`round_code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bizsim_league_rounds`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `bizsim_league_rounds` WRITE;
/*!40000 ALTER TABLE `bizsim_league_rounds` DISABLE KEYS */;
INSERT INTO `bizsim_league_rounds` VALUES
(1,'SIM-Q3-101','تیم صادراتی پیشگامان فولاد زاگرس','فصل سوم (Q3 — جهش بازار اوراسیا)',1340.00,75,14,248500,1745,'پوشش ۷۵٪ ریسک ارزی همراه با ۱۴٪ سرمایه‌گذاری تحقیق و توسعه بالاترین سود عملیاتی دلاری را ثبت کرد.','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(2,'SIM-Q3-102','تیم بازرگانی خشکبار زرین پارس','فصل سوم (Q3 — ورود به خلیج فارس)',1190.00,55,11,204000,1680,'استراتژی نفوذ قیمتی سهم بازار امارات را ۲۲٪ افزایش داد اما پوشش ارزی نیازمند تقویت است.','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `bizsim_league_rounds` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `bpms_process_mining`
--

DROP TABLE IF EXISTS `bpms_process_mining`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bpms_process_mining` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stage_code` varchar(40) NOT NULL,
  `department_stage` varchar(160) NOT NULL,
  `active_cases_count` int(11) DEFAULT 12,
  `avg_dwell_hours` decimal(5,1) DEFAULT 6.5,
  `sla_target_hours` int(11) DEFAULT 12,
  `bottleneck_severity` varchar(140) DEFAULT 'سبز — داخل SLA',
  `auto_escalation_rule` varchar(220) NOT NULL,
  `mined_shamsi` varchar(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `stage_code` (`stage_code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bpms_process_mining`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `bpms_process_mining` WRITE;
/*!40000 ALTER TABLE `bpms_process_mining` DISABLE KEYS */;
INSERT INTO `bpms_process_mining` VALUES
(1,'STG-ADM-01','پذیرش و کنترل مدارک هویتی / کد ملی متقاضی',19,2.4,8,'سبز — بسیار سریع (۳۰٪ سقف SLA)','تأیید خودکار آنی در صورت صحت کنترل رقم کد ملی و شبا','۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59'),
(2,'STG-FIN-02','تأیید خزانه‌داری، استعلام چک صیادی و صدور فاکتور',14,18.6,12,'بحرانی — گلوگاه اصلی (+۶.۶ ساعت تأخیر SLA)','ارجاع خودکار به مدیر مالی پس از ۱۲ ساعت + همگام‌سازی خودکار OCR','۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59'),
(3,'STG-EDU-03','ممیزی حضور ۸۰٪، نمره آزمون ۷۰ و صدور گواهی QR',22,1.2,6,'سبز — تمام‌خودکار (زنجیره BPMS)','صدور آنی گواهی دیجیتال بدون توقف انسانی پس از قبولی آزمون','۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `bpms_process_mining` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `bpms_routing_rules`
--

DROP TABLE IF EXISTS `bpms_routing_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bpms_routing_rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rule_name` varchar(180) NOT NULL,
  `process_key` varchar(60) NOT NULL,
  `condition_expr` varchar(200) NOT NULL,
  `routing_mode` enum('sequential','parallel','conditional') DEFAULT 'conditional',
  `target_roles` varchar(160) NOT NULL,
  `sla_hours` int(11) DEFAULT 24,
  `is_active` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bpms_routing_rules`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `bpms_routing_rules` WRITE;
/*!40000 ALTER TABLE `bpms_routing_rules` DISABLE KEYS */;
INSERT INTO `bpms_routing_rules` VALUES
(1,'شرط سقف ریالی قرارداد سازمانی بالای ۱ میلیارد ریال','CONTRACT_DISCOUNT','amount_rial > 1000000000','parallel','finance_manager + super_admin',48,1),
(2,'مسیر شرطی تخفیف ویژه اعضای طلایی بالای ۲۵٪','COURSE_APPROVAL','discount_pct > 25','conditional','super_admin',24,1),
(3,'مسیر موازی تجهیز کارگاه و تأیید بودجه','EQUIPMENT_PURCHASE','budget_category = IT_LAB','parallel','training_expert + finance_manager',36,1);
/*!40000 ALTER TABLE `bpms_routing_rules` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `bpms_workflows`
--

DROP TABLE IF EXISTS `bpms_workflows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bpms_workflows` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `process_key` varchar(60) NOT NULL,
  `process_title` varchar(200) NOT NULL,
  `subject_label` varchar(220) NOT NULL,
  `initiator_id` int(11) NOT NULL,
  `current_step` varchar(140) NOT NULL,
  `assigned_role` varchar(60) NOT NULL,
  `sla_hours` int(11) DEFAULT 48,
  `elapsed_hours` int(11) DEFAULT 14,
  `status` enum('running','approved','rejected') DEFAULT 'running',
  `history_json` longtext NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bpms_workflows`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `bpms_workflows` WRITE;
/*!40000 ALTER TABLE `bpms_workflows` DISABLE KEYS */;
INSERT INTO `bpms_workflows` VALUES
(1,'COURSE_APPROVAL','فرایند بررسی و تصویب دوره آموزشی جدید','برنامه عالی توسعه رهبری مدیران صنایع (LDR-401)',2,'تأیید نهایی کمیته علمی و مدیر آموزش','super_admin',48,31,'running','[{\"step\":\"ثبت توسط کارشناس آموزش\",\"by\":\"مهندس سارا فرهمند\",\"time\":\"۱۴۰۵/۰۷/۲۸ ۱۰:۱۵\"},{\"step\":\"تأیید بودجه و تعرفه توسط مالی\",\"by\":\"حسین کاظمی‌نژاد\",\"time\":\"۱۴۰۵/۰۷/۲۹ ۱۱:۴۰\"}]','2026-10-23 21:48:59'),
(2,'INSTRUCTOR_PAYOUT','فرایند تسویه حق‌التدریس مدرس','حق‌التدریس دوره جامع صادرات (RUN-1405-01) - دکتر نیکزاد',2,'تأیید و دستور پرداخت مدیر مالی','finance_manager',24,29,'running','[{\"step\":\"ثبت کارکرد ۲۴ ساعت تدریس\",\"by\":\"مهندس سارا فرهمند\",\"time\":\"۱۴۰۵/۰۷/۲۹ ۰۹:۰۰\"}]','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `bpms_workflows` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `business_clinic_cases`
--

DROP TABLE IF EXISTS `business_clinic_cases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `business_clinic_cases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `org_name` varchar(180) NOT NULL,
  `industry_sector` varchar(120) NOT NULL,
  `era_production_score` int(11) DEFAULT 70,
  `era_packaging_score` int(11) DEFAULT 55,
  `era_marketing_score` int(11) DEFAULT 45,
  `era_finance_legal_score` int(11) DEFAULT 60,
  `total_era_index` int(11) DEFAULT 58,
  `main_bottleneck` varchar(220) NOT NULL,
  `prescribed_pack` varchar(240) NOT NULL,
  `diagnosed_shamsi` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `business_clinic_cases`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `business_clinic_cases` WRITE;
/*!40000 ALTER TABLE `business_clinic_cases` DISABLE KEYS */;
INSERT INTO `business_clinic_cases` VALUES
(1,'مجتمع صنایع غذایی بهاران استان','صنایع تبدیلی و خشکبار',85,48,42,65,60,'عدم انطباق لیبلینگ و بسته‌بندی خرده‌فروشی با استاندارد بازار خلیج فارس','مشاوره طراحی بسته‌بندی صادراتی + دوره بازاریابی بین‌الملل و نمایشگاه‌ها','۱۴۰۵/۰۷/۲۴'),
(2,'کارخانه قطعات دقیق پارس صنعت','قطعات صنعتی و ماشین‌آلات',88,76,52,44,65,'ضعف در تنظیم قراردادهای فروش بین‌المللی و تضامین بانکی','کلینیک حقوقی قراردادهای بین‌المللی + آکادمی اینکوترمز ۲۰۲۰','۱۴۰۵/۰۷/۲۷');
/*!40000 ALTER TABLE `business_clinic_cases` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `career_ats_applications`
--

DROP TABLE IF EXISTS `career_ats_applications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `career_ats_applications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tracking_code` varchar(45) NOT NULL,
  `job_ad_id` int(11) NOT NULL,
  `job_title_snapshot` varchar(190) NOT NULL,
  `company_snapshot` varchar(165) NOT NULL,
  `candidate_name` varchar(150) NOT NULL,
  `ats_stage` varchar(45) NOT NULL DEFAULT 'ai_screened',
  `ai_match_score_pct` int(11) NOT NULL DEFAULT 93,
  `skill_gap_prescription` varchar(240) NOT NULL,
  `candidate_note` varchar(240) DEFAULT 'دارای گواهی رسمی QR اتاق و نمونه پرونده عملی صادراتی',
  `applied_shamsi` varchar(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `tracking_code` (`tracking_code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `career_ats_applications`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `career_ats_applications` WRITE;
/*!40000 ALTER TABLE `career_ats_applications` DISABLE KEYS */;
INSERT INTO `career_ats_applications` VALUES
(1,'APP-1405-7701',1,'مدیر صادرات و قراردادهای بین‌المللی','مجتمع فولاد و ذوب‌آهن زاگرس','مهندس مهرداد شریفی','interview',96,'تطابق کامل (۹۶٪) — پیشنهاد مرور ۲ ساعته بسته قراردادهای تعرفه‌صفر اوراسیا پیش از مصاحبه نهایی.','دارای گواهی QR معتبر و توصیه‌نامه رسمی استاد','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(2,'APP-1405-7702',2,'کارشناس ارشد ثبت سفارش NTSW و گمرک','مجتمع پتروشیمی و پلیمر استان','مهندس پگاه کاظمی','offer_sent',94,'تطابق عالی (۹۴٪) — تسلط عملی بر اظهار EPL و کدهای تعرفه پتروشیمی احراز شد.','سابقه ترخیص بیش از ۸۰ محموله صنعتی بدون جریمه گمرکی','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(3,'APP-1405-7703',4,'کارشناس بازاریابی بین‌الملل با هوش مصنوعی','تجهیز دقیق اسپادانا','نیما فرهادی','ai_screened',87,'شکاف جزئی در UCP600 — پیشنهاد گذراندن میکروکارگاه ۴ ساعته اسناد حمل اتاق.','نمونه‌کار استخراج ۵۰ خریدار واقعی از TradeMap پیوست است','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(4,'APP-1405-7704',3,'رئیس حسابداری مالیاتی و سامانه مؤدیان','گروه صنایع غذایی بهاران','پریسا سلیمانی','hired',97,'استخدام قطعی شد — تکمیل دوره مؤدیان اتاق با نمره ۹۵.','معرفی‌شده از کارتابل نماینده سازمان','۱۴۰۵/۰۷/۲۸','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `career_ats_applications` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `career_candidate_profiles`
--

DROP TABLE IF EXISTS `career_candidate_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `career_candidate_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `full_name` varchar(150) NOT NULL,
  `headline_title` varchar(190) NOT NULL,
  `experience_years` int(11) NOT NULL DEFAULT 5,
  `expected_salary_million` int(11) NOT NULL DEFAULT 55,
  `city_preference` varchar(110) NOT NULL DEFAULT 'مرکز استان / هیبرید',
  `availability_status` varchar(90) NOT NULL DEFAULT 'آماده شروع فوری',
  `foreign_languages` varchar(190) NOT NULL DEFAULT 'انگلیسی تجاری C1 (BEC) | عربی بازرگانی B2',
  `core_skills_csv` varchar(250) NOT NULL,
  `synced_certs_summary` varchar(240) NOT NULL,
  `work_style_nonclinical` varchar(180) NOT NULL DEFAULT 'تیپ تحلیلی-نتیجه‌گرا (ENTJ — ارزیابی غیربالینی شغلی)',
  `gamification_xp_badge` varchar(120) NOT NULL DEFAULT 'سطح ۸ — سفیر طلایی صادرات (۴,۸۹۰ XP)',
  `updated_shamsi` varchar(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `career_candidate_profiles`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `career_candidate_profiles` WRITE;
/*!40000 ALTER TABLE `career_candidate_profiles` DISABLE KEYS */;
INSERT INTO `career_candidate_profiles` VALUES
(1,7,'مهندس مهرداد شریفی','کارشناس ارشد بازرگانی خارجی، اعتبارات اسنادی UCP600 و لجستیک صادرات',6,62,'مرکز استان / شهرک صنعتی','آماده شروع از ۱۵ آبان','انگلیسی تجاری C1 (BEC) | عربی بازرگانی B2','Incoterms 2020, UCP 600, سامانه جامع تجارت NTSW, مذاکره B2B, TradeMap','گواهی QR جامع تجارت بین‌الملل (CERT-ADN-1405-9001) + تأییدیه استاد دکتر رستگار','تیپ تحلیلی-راهبردی ENTJ (ارزیابی غیربالینی محیط کار)','سطح ۸ — سفیر طلایی صادرات (۴,۸۹۰ XP)','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(2,2,'مهندس پگاه کاظمی','متخصص ترخیص کالا، تعرفه‌گذاری HS و ثبت سفارش صنعتی',5,54,'مرکز استان','آماده شروع فوری','انگلیسی B2 | ترکی استانبولی تجاری B2','EPL گمرک, NTSW, گواهی مبدأ اوراسیا CT-3, بیمه باربری کلوز A','گواهی رسمی عملیات گمرکی و ثبت سفارش مؤسسه آموزشی آدان','تیپ دقیق و ساختارمند ISTJ (ارزیابی غیربالینی محیط کار)','سطح ۶ — متخصص ارشد گمرک (۳,۶۸۰ XP)','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `career_candidate_profiles` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `career_interview_schedules`
--

DROP TABLE IF EXISTS `career_interview_schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `career_interview_schedules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `interview_code` varchar(45) NOT NULL,
  `candidate_name` varchar(150) NOT NULL,
  `company_name` varchar(165) NOT NULL,
  `job_title` varchar(190) NOT NULL,
  `interview_mode` varchar(80) NOT NULL DEFAULT 'آنلاین (اتاق اختصاصی اسکای‌روم)',
  `scheduled_shamsi` varchar(70) NOT NULL,
  `interviewer_panel` varchar(160) NOT NULL,
  `ai_tailored_questions` text NOT NULL,
  `technical_score` int(11) DEFAULT 91,
  `interview_outcome` varchar(90) DEFAULT 'تأیید فنی — ارسال به مرحله پیشنهاد حقوق',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `interview_code` (`interview_code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `career_interview_schedules`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `career_interview_schedules` WRITE;
/*!40000 ALTER TABLE `career_interview_schedules` DISABLE KEYS */;
INSERT INTO `career_interview_schedules` VALUES
(1,'INT-1405-510','مهندس مهرداد شریفی','مجتمع فولاد و ذوب‌آهن زاگرس','مدیر صادرات و قراردادهای بین‌المللی','حضوری در دفتر مرکزی کارخانه','یکشنبه ۱۴۰۵/۰۸/۰۴ ساعت ۱۰:۳۰','مدیرعامل + مدیر بازرگانی خارجی','۱) مدیریت ریسک نوسان نرخ تسعیر در قرارداد ۶ ماهه CIS؟ | ۲) راهکار حذف مغایرت بارنامه کانتینری در ماده ۱۴ UCP600؟ | ۳) نحوه پوشش تعرفه کربن CBAM اروپا؟',95,'تأیید ممتاز فنی — ارجاع جهت صدور نامه پیشنهاد حقوق','2026-10-23 21:48:59'),
(2,'INT-1405-511','نیما فرهادی','تجهیز دقیق اسپادانا','کارشناس بازاریابی بین‌الملل با هوش مصنوعی','آنلاین (اتاق اسکای‌روم کاریابی اتاق)','سه‌شنبه ۱۴۰۵/۰۸/۰۶ ساعت ۱۵:۰۰','مدیر توسعه بازار بین‌الملل','۱) نحوه اعتبارسنجی خریدار خارجی پیش از ارسال پیش‌فاکتور؟ | ۲) تحلیل حاشیه سود DDP در برابر FCA؟',88,'دعوت‌نامه پیامکی و لینک جلسه ارسال شد','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `career_interview_schedules` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `career_job_ads`
--

DROP TABLE IF EXISTS `career_job_ads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `career_job_ads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ad_code` varchar(45) NOT NULL,
  `company_name` varchar(165) NOT NULL,
  `is_verified_member` tinyint(1) NOT NULL DEFAULT 1,
  `job_title` varchar(190) NOT NULL,
  `category_slug` varchar(70) NOT NULL DEFAULT 'export_trade',
  `cooperation_type` varchar(70) NOT NULL DEFAULT 'تمام‌وقت',
  `seniority_level` varchar(70) NOT NULL DEFAULT 'کارشناس ارشد',
  `city_location` varchar(110) NOT NULL DEFAULT 'شهرک صنعتی بزرگ استان',
  `salary_min_million` int(11) NOT NULL DEFAULT 42,
  `salary_max_million` int(11) NOT NULL DEFAULT 65,
  `perks_badges` varchar(240) NOT NULL DEFAULT 'بیمه تکمیلی، پورسانت ارزی صادرات، ناهار و سرویس',
  `required_skills_tags` varchar(240) NOT NULL,
  `required_chamber_cert` varchar(190) NOT NULL,
  `job_description_ai` text NOT NULL,
  `is_urgent` tinyint(1) NOT NULL DEFAULT 0,
  `views_count` int(11) NOT NULL DEFAULT 140,
  `applicants_count` int(11) NOT NULL DEFAULT 6,
  `ad_status` varchar(40) NOT NULL DEFAULT 'active',
  `posted_shamsi` varchar(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ad_code` (`ad_code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `career_job_ads`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `career_job_ads` WRITE;
/*!40000 ALTER TABLE `career_job_ads` DISABLE KEYS */;
INSERT INTO `career_job_ads` VALUES
(1,'JOB-1405-901','مجتمع فولاد و ذوب‌آهن زاگرس',1,'مدیر صادرات و قراردادهای بین‌المللی (بازار اوراسیا و خلیج فارس)','export_trade','تمام‌وقت','مدیر میانی / سرپرست','شهرک صنعتی اول',65,92,'پورسانت ارزی دلاری، بیمه تکمیلی طلایی، خودرو سازمانی، وام مسکن','Incoterms 2020, UCP 600, مذاکره تجاری انگلیسی/روسی, رفع تعهد ارزی نیما','گواهی جامع آکادمی تجارت بین‌الملل اتاق','مسئولیت کامل تدوین استراتژی فروش صادراتی، مذاکره با خریداران عمده در روسیه و امارات، تنظیم قراردادهای منطبق بر قواعد ICC و نظارت بر اسناد حمل و اعتبارات اسنادی.',1,342,9,'active','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(2,'JOB-1405-902','مجتمع پتروشیمی و پلیمر استان',1,'کارشناس ارشد ثبت سفارش NTSW، ترخیص و امور گمرکی EPL','customs_logistics','تمام‌وقت','کارشناس ارشد','مرکز استان',48,66,'بیمه تکمیلی، پاداش ترخیص سریع بدون دموراژ، ناهار گرم، کمک‌هزینه آموزش آدان','سامانه جامع تجارت NTSW, اظهار گمرکی EPL, تعیین تعرفه HS Code, حمل چندوجهی','گواهی جامع سامانه جامع تجارت و گمرک EPL','مدیریت صفر تا صد پرونده‌های ثبت سفارش مواد اولیه، اخذ مجوزهای فنی و ارزی، اظهار در سامانه EPL و کاهش زمان توقف کانتینر در مبادی گمرکی.',1,278,12,'active','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(3,'JOB-1405-903','گروه صنایع غذایی و لبنی بهاران',1,'رئیس حسابداری مالیاتی، سامانه مؤدیان و بهای تمام‌شده صادراتی','finance_tax','تمام‌وقت / هیبرید','سرپرست','شهرک صنعتی دوم',52,74,'پاداش عملکرد فصلی، بیمه تکمیلی خانواده، ساعت کاری منعطف','سامانه مؤدیان مالیاتی, ماده ۱۶۹ و استرداد ارزش افزوده صادرات, سپیدار و همکاران سیستم','گواهی تخصصی سامانه مؤدیان و دادرسی مالیاتی','ارسال بی‌نقص صورت‌حساب‌های الکترونیکی، پیگیری پرونده‌های استرداد مالیات بر ارزش افزوده کالاهای صادراتی و تهیه گزارش‌های تحلیلی بهای تمام‌شده.',0,215,7,'active','۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59'),
(4,'JOB-1405-904','شرکت دانش‌بنیان تجهیز دقیق اسپادانا',1,'کارشناس بازاریابی بین‌الملل و کشف خریدار خارجی با هوش مصنوعی','ai_marketing','دورکاری / هیبرید','کارشناس','مرکز استان / دورکاری',38,54,'پورسانت دلاری از هر پیش‌فاکتور صادراتی، ساعت کاری شناور، بودجه ابزارهای هوش مصنوعی','ITC TradeMap, LinkedIn B2B Outreach, هوش مصنوعی تجاری, مکاتبات انگلیسی BEC','گواهی بازاریابی صادراتی با هوش مصنوعی اتاق','تحلیل داده‌های واردات جهانی در TradeMap، استخراج فهرست تصمیم‌گیرندگان خرید در بازار هدف و اجرای کمپین‌های مذاکره B2B.',1,419,15,'active','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `career_job_ads` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `career_job_fair_booths`
--

DROP TABLE IF EXISTS `career_job_fair_booths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `career_job_fair_booths` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `booth_code` varchar(40) NOT NULL,
  `company_name` varchar(165) NOT NULL,
  `industry_sector` varchar(120) NOT NULL,
  `open_positions_count` int(11) NOT NULL DEFAULT 4,
  `speed_interview_slots_left` int(11) NOT NULL DEFAULT 7,
  `featured_roles` varchar(220) NOT NULL,
  `fair_date_shamsi` varchar(60) DEFAULT 'چهارشنبه ۱۴۰۵/۰۸/۱۴ — تالار بزرگ مؤسسه آموزشی آدان',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `booth_code` (`booth_code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `career_job_fair_booths`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `career_job_fair_booths` WRITE;
/*!40000 ALTER TABLE `career_job_fair_booths` DISABLE KEYS */;
INSERT INTO `career_job_fair_booths` VALUES
(1,'BOOTH-A01','مجتمع فولاد و ذوب‌آهن زاگرس','فلزات اساسی و فولاد صادراتی',5,6,'مدیر صادرات، کارشناس L/C، کارشناس لجستیک ریلی','چهارشنبه ۱۴۰۵/۰۸/۱۴ — تالار بزرگ مؤسسه آموزشی آدان','2026-10-23 21:48:59'),
(2,'BOOTH-A02','مجتمع پتروشیمی و پلیمر استان','پتروشیمی و پلیمر',4,5,'متخصص NTSW، حسابدار ارشد ارزی، کارشناس فروش خلیج فارس','چهارشنبه ۱۴۰۵/۰۸/۱۴ — تالار بزرگ مؤسسه آموزشی آدان','2026-10-23 21:48:59'),
(3,'BOOTH-B04','گروه صنایع غذایی و لبنی بهاران','صنایع غذایی صادرات‌محور',6,9,'مدیر فروش عراق و اوراسیا، کارشناس استاندارد و قرنطینه','چهارشنبه ۱۴۰۵/۰۸/۱۴ — تالار بزرگ مؤسسه آموزشی آدان','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `career_job_fair_booths` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `career_job_offers`
--

DROP TABLE IF EXISTS `career_job_offers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `career_job_offers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `offer_serial` varchar(45) NOT NULL,
  `candidate_name` varchar(150) NOT NULL,
  `company_name` varchar(165) NOT NULL,
  `position_title` varchar(190) NOT NULL,
  `base_monthly_million` int(11) NOT NULL DEFAULT 58,
  `export_commission_note` varchar(160) NOT NULL DEFAULT '۱.۵٪ پورسانت دلاری وصول ارزی صادرات + بیمه تکمیلی طلایی',
  `start_date_shamsi` varchar(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۱۵',
  `offer_status` varchar(70) NOT NULL DEFAULT 'ارسال‌شده به کارجو — منتظر امضا',
  `created_shamsi` varchar(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `offer_serial` (`offer_serial`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `career_job_offers`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `career_job_offers` WRITE;
/*!40000 ALTER TABLE `career_job_offers` DISABLE KEYS */;
INSERT INTO `career_job_offers` VALUES
(1,'OFR-1405-301','مهندس پگاه کاظمی','مجتمع پتروشیمی و پلیمر استان','کارشناس ارشد ثبت سفارش NTSW و امور گمرکی',62,'پاداش ترخیص سریع + بیمه تکمیلی طلایی + سهمیه رایگان دوره‌های حسابداری','۱۴۰۵/۰۸/۱۵','پذیرفته‌شده و امضاشده توسط کارجو ✅','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `career_job_offers` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `career_salary_benchmarks`
--

DROP TABLE IF EXISTS `career_salary_benchmarks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `career_salary_benchmarks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_family` varchar(165) NOT NULL,
  `min_million` int(11) NOT NULL,
  `median_million` int(11) NOT NULL,
  `max_top_decile_million` int(11) NOT NULL,
  `market_demand_index` int(11) NOT NULL DEFAULT 92,
  `top_value_cert` varchar(190) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `career_salary_benchmarks`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `career_salary_benchmarks` WRITE;
/*!40000 ALTER TABLE `career_salary_benchmarks` DISABLE KEYS */;
INSERT INTO `career_salary_benchmarks` VALUES
(1,'مدیر صادرات و توسعه بازار بین‌الملل',60,78,115,97,'آکادمی جامع تجارت بین‌الملل و UCP600 (+۲۸٪ جهش حقوق)','2026-10-23 21:48:59'),
(2,'رئیس حسابداری مالیاتی و سامانه مؤدیان',48,64,88,94,'دوره عملی سامانه مؤدیان و استرداد مالیات صادرات (+۲۲٪)','2026-10-23 21:48:59'),
(3,'کارشناس ارشد ثبت سفارش NTSW و ترخیص گمرکی',42,56,76,95,'کارگاه عملی NTSW و اظهار گمرکی EPL (+۲۵٪)','2026-10-23 21:48:59'),
(4,'کارشناس بازاریابی صادراتی با هوش مصنوعی',35,49,68,91,'شکار خریداران خارجی با AI و TradeMap (+۲۴٪)','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `career_salary_benchmarks` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `certificates`
--

DROP TABLE IF EXISTS `certificates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `certificates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `serial_code` varchar(80) NOT NULL,
  `user_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `issue_shamsi` varchar(30) NOT NULL,
  `grade_label` varchar(50) DEFAULT 'عالی (A)',
  `hours_completed` int(11) DEFAULT 16,
  `status` enum('valid','revoked') DEFAULT 'valid',
  `revoked_reason` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `serial_code` (`serial_code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `certificates`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `certificates` WRITE;
/*!40000 ALTER TABLE `certificates` DISABLE KEYS */;
INSERT INTO `certificates` VALUES
(1,'CERT-ADN-1405-9001',7,1,'۱۴۰۵/۰۷/۲۸','عالی (۹۴ از ۱۰۰)',24,'valid',NULL,'2026-10-23 21:48:59'),
(2,'CERT-ADN-1405-9002',7,4,'۱۴۰۵/۰۷/۱۸','عالی (۹۱ از ۱۰۰)',12,'valid',NULL,'2026-10-23 21:48:59'),
(3,'CERT-ADN-1405-8100',8,4,'۱۴۰۵/۰۶/۳۰','مردود / ابطال اصلاحی',12,'revoked','ابطال سیستمی جهت صدور مجدد به دلیل اصلاح کد ملی در پرونده آموزشی','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `certificates` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `chamber_commissions`
--

DROP TABLE IF EXISTS `chamber_commissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chamber_commissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `commission_name` varchar(180) NOT NULL,
  `chairperson_name` varchar(150) NOT NULL,
  `resolution_title` varchar(240) NOT NULL,
  `requested_course_topic` varchar(220) NOT NULL,
  `priority_level` enum('فوری استانی','اولویت فصلی','برنامه سالانه') DEFAULT 'فوری استانی',
  `converted_to_tms` tinyint(1) DEFAULT 0,
  `session_shamsi` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chamber_commissions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `chamber_commissions` WRITE;
/*!40000 ALTER TABLE `chamber_commissions` DISABLE KEYS */;
INSERT INTO `chamber_commissions` VALUES
(1,'کمیسیون توسعه صادرات غیرنفتی و گمرک','مهندس فرهاد نیک‌نژاد','مصوبه جلسه ۱۴: الزام آموزش رفع تعهد ارزی نیما و مرکز مبادله برای صادرکنندگان نوپا','کارگاه عملی رفع تعهد ارزی صادرکنندگان ۱۴۰۵','فوری استانی',1,'۱۴۰۵/۰۷/۲۲'),
(2,'کمیسیون صنعت، معدن و انرژی','دکتر منصور بهرامی','مصوبه جلسه ۹: توانمندسازی مدیران انرژی کارخانجات در مدیریت بهینه بار و پنل خورشیدی صنعتی','مدیریت بهینه‌سازی مصرف انرژی و نیروگاه خورشیدی صنایع','اولویت فصلی',0,'۱۴۰۵/۰۷/۲۸');
/*!40000 ALTER TABLE `chamber_commissions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `class_runbook_checklists`
--

DROP TABLE IF EXISTS `class_runbook_checklists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `class_runbook_checklists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `run_code` varchar(45) NOT NULL,
  `course_title` varchar(190) NOT NULL,
  `skyroom_link_ready` tinyint(1) NOT NULL DEFAULT 1,
  `slides_uploaded` tinyint(1) NOT NULL DEFAULT 1,
  `sms_24h_sent` tinyint(1) NOT NULL DEFAULT 0,
  `hall_catering_ok` tinyint(1) NOT NULL DEFAULT 1,
  `bulk_enrolled_count` int(11) NOT NULL DEFAULT 18,
  `readiness_pct` int(11) NOT NULL DEFAULT 75,
  `updated_shamsi` varchar(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `run_code` (`run_code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `class_runbook_checklists`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `class_runbook_checklists` WRITE;
/*!40000 ALTER TABLE `class_runbook_checklists` DISABLE KEYS */;
INSERT INTO `class_runbook_checklists` VALUES
(1,'RUN-1405-A1','جامع اینکوترمز ۲۰۲۰ و اعتبارات اسنادی UCP600',1,1,0,1,26,75,'۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(2,'RUN-1405-B4','کارگاه عملی سامانه مؤدیان و پایانه‌های فروشگاهی',1,1,1,1,31,100,'۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `class_runbook_checklists` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `classroom_bookings`
--

DROP TABLE IF EXISTS `classroom_bookings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `classroom_bookings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `classroom_id` int(11) NOT NULL,
  `booked_by` int(11) NOT NULL,
  `purpose` varchar(200) NOT NULL,
  `booking_date` date NOT NULL,
  `booking_shamsi` varchar(30) NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `catering_request` varchar(200) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_room_slot` (`classroom_id`,`booking_date`,`start_time`,`end_time`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classroom_bookings`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `classroom_bookings` WRITE;
/*!40000 ALTER TABLE `classroom_bookings` DISABLE KEYS */;
INSERT INTO `classroom_bookings` VALUES
(1,1,2,'اجرای جلسه سوم دوره اینکوترمز ۲۰۲۰ (TRD-101)','2026-11-01','۱۴۰۵/۰۸/۱۰','14:00:00','18:00:00','پذیرایی میان‌وعده ۳۰ نفر + آب معدنی میز استاد','2026-10-23 21:48:59'),
(2,2,2,'کارگاه عملی هوش مصنوعی در بازاریابی صادراتی','2026-11-03','۱۴۰۵/۰۸/۱۲','09:00:00','13:00:00','چای و نسکافه ۲۸ نفر','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `classroom_bookings` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `classrooms`
--

DROP TABLE IF EXISTS `classrooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `classrooms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `capacity` int(11) NOT NULL DEFAULT 35,
  `equipment` varchar(300) DEFAULT 'ویدئوپروژکتور لیزری، سیستم کنفرانس، ضبط تصویر، اینترنت فیبر نوری',
  `hourly_fee_rial` bigint(20) DEFAULT 8500000,
  `maintenance_status` enum('ready','service_needed') DEFAULT 'ready',
  `maintenance_note` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classrooms`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `classrooms` WRITE;
/*!40000 ALTER TABLE `classrooms` DISABLE KEYS */;
INSERT INTO `classrooms` VALUES
(1,'تالار خلیج فارس (طبقه دوم اتاق)',45,'ویدئوپروژکتور لیزری 4K، میکروفون کنفرانسی، ضبط خودکار کلاس، فیبر نوری',9500000,'ready',NULL),
(2,'کارگاه هوشمند دیجیتال و کامپیوتر ابوریحان',28,'۲۸ سیستم مجهز، نمایشگر لمسی تعاملی ۸۶ اینچ، نرم‌افزارهای شبیه‌ساز تجاری',11000000,'ready',NULL),
(3,'سالن VIP مذاکرات بین‌الملل نقش‌جهان',20,'سیستم ترجمه همزمان ۳ زبانه، ویدئوکنفرانس، پذیرایی تشریفات',15000000,'service_needed','میکروفون شماره ۴ میز کنفرانس نیازمند تعویض باتری و کالیبراسیون صوتی است');
/*!40000 ALTER TABLE `classrooms` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `commercial_card_cases`
--

DROP TABLE IF EXISTS `commercial_card_cases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `commercial_card_cases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tracking_code` varchar(50) NOT NULL,
  `applicant_name` varchar(180) NOT NULL,
  `national_or_legal_id` varchar(30) NOT NULL,
  `card_request_type` enum('صدور اولیه حقیقی','صدور اولیه حقوقی','تمدید کارت بازرگانی') DEFAULT 'صدور اولیه حقوقی',
  `attendance_pct` int(11) DEFAULT 0,
  `exam_score` decimal(5,2) DEFAULT 0.00,
  `aml_declaration` tinyint(1) DEFAULT 1,
  `clearance_status` enum('در حال گذراندن دوره','تأیید نهایی واحد آموزش','نیازمند آزمون مجدد') DEFAULT 'در حال گذراندن دوره',
  `clearance_code` varchar(70) DEFAULT NULL,
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `tracking_code` (`tracking_code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commercial_card_cases`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `commercial_card_cases` WRITE;
/*!40000 ALTER TABLE `commercial_card_cases` DISABLE KEYS */;
INSERT INTO `commercial_card_cases` VALUES
(1,'CC-1405-1001','مهندس بهرام کیانی (مدیرعامل کشت‌وصنعت زاگرس)','14008811220','صدور اولیه حقوقی',92,86.50,1,'تأیید نهایی واحد آموزش','CLR-CARD-1405-9821','2026-10-23 21:48:59'),
(2,'CC-1405-1002','سرکار خانم سمانه رضوی','0071928374','صدور اولیه حقیقی',65,58.00,1,'در حال گذراندن دوره',NULL,'2026-10-23 21:48:59'),
(3,'CC-1405-1003','شرکت بازرگانی سپهر لجستیک پارس','10105544332','تمدید کارت بازرگانی',100,91.00,1,'تأیید نهایی واحد آموزش','CLR-CARD-1405-9940','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `commercial_card_cases` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `commission_policy_briefs`
--

DROP TABLE IF EXISTS `commission_policy_briefs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `commission_policy_briefs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `brief_code` varchar(40) NOT NULL,
  `commission_name` varchar(160) NOT NULL,
  `recipient_authority` varchar(160) NOT NULL,
  `issue_summary` varchar(240) NOT NULL,
  `legal_citation` varchar(220) NOT NULL,
  `formal_letter_body` text NOT NULL,
  `status` varchar(60) DEFAULT 'آماده امضای مدیر مؤسسه آدان استان',
  `created_shamsi` varchar(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `brief_code` (`brief_code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commission_policy_briefs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `commission_policy_briefs` WRITE;
/*!40000 ALTER TABLE `commission_policy_briefs` DISABLE KEYS */;
INSERT INTO `commission_policy_briefs` VALUES
(1,'POL-1405-11','کمیسیون توسعه صادرات غیرنفتی و گمرک','مقام عالی وزارت صنعت، معدن و تجارت / کل گمرک ایران','رفع ایستایی ثبت سفارش مواد اولیه واحدهای تولیدی صادرات‌محور و تمدید مهلت رفع تعهد ارزی','استناد به مواد ۲، ۳ و ۲۴ قانون بهبود مستمر محیط کسب‌وکار و ماده ۱۲ قانون احکام دائمی','احتراماً به پیوست جمع‌بندی کارشناسی جلسه فوق‌العاده کمیسیون توسعه صادرات مؤسسه آموزشی آدان در خصوص توقف خطوط تولید ناشی از تأخیر تخصیص ارز مواد اولیه ایفاد می‌گردد. پیشنهاد مشخص بخش خصوصی: ۱) تنفس ۹۰ روزه رفع تعهد ارزی برای صادرکنندگان خوش‌حساب تولیدی؛ ۲) ایجاد مسیر سبز گمرکی ویژه واحدهای دارای گواهی انطباق اتاق استان.','آماده امضای مدیر مؤسسه آدان استان','۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `commission_policy_briefs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `competencies`
--

DROP TABLE IF EXISTS `competencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `competencies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(40) NOT NULL,
  `title` varchar(180) NOT NULL,
  `domain` enum('تجارت بین‌الملل','مدیریت و رهبری','مالی و گمرکی','تحول دیجیتال و AI','مذاکره و حقوق تجاری') DEFAULT 'تجارت بین‌الملل',
  `recommended_course_id` int(11) DEFAULT NULL,
  `weight` int(11) DEFAULT 3,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `competencies`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `competencies` WRITE;
/*!40000 ALTER TABLE `competencies` DISABLE KEYS */;
INSERT INTO `competencies` VALUES
(1,'CMP-EXP-01','تسلط بر قواعد تحویل کالا و اسناد حمل بین‌المللی (Incoterms)','تجارت بین‌الملل',1,5,'توانایی تنظیم شرایط تحویل در قراردادهای صادراتی و وارداتی بدون ریسک حقوقی'),
(2,'CMP-FX-02','مدیریت تعهدات ارزی و ابزارهای پوشش نوسان ارز','مالی و گمرکی',2,5,'مدیریت چرخه نقدینگی ارزی، سامانه نیما و تهاتر واردات در قبال صادرات'),
(3,'CMP-AI-03','تحلیل هوشمند بازارهای صادراتی با هوش مصنوعی','تحول دیجیتال و AI',3,4,'استخراج داده‌های تقاضای جهانی و خودکارسازی مذاکرات تجاری'),
(4,'CMP-CBAM-04','انطباق زیست‌محیطی و استاندارد کربن اتحادیه اروپا (CBAM)','تجارت بین‌الملل',6,4,'گزارش‌دهی کربن نهفته محصولات صنعتی صادراتی به بازار اروپا'),
(5,'CMP-LDR-05','رهبری استراتژیک و تصمیم‌گیری مبتنی بر داده در شرایط عدم قطعیت','مدیریت و رهبری',5,5,'مدیریت پرتفوی ریسک بنگاه اقتصادی و هم‌راستاسازی تیم‌های اجرایی');
/*!40000 ALTER TABLE `competencies` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `competency_assessments`
--

DROP TABLE IF EXISTS `competency_assessments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `competency_assessments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `competency_id` int(11) NOT NULL,
  `target_role_title` varchar(150) DEFAULT 'مدیر صادرات',
  `current_level` tinyint(4) NOT NULL DEFAULT 2,
  `target_level` tinyint(4) NOT NULL DEFAULT 4,
  `priority` enum('عادی','مهم','حیاتی') DEFAULT 'مهم',
  `ai_recommendation` varchar(500) DEFAULT NULL,
  `assessed_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `competency_assessments`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `competency_assessments` WRITE;
/*!40000 ALTER TABLE `competency_assessments` DISABLE KEYS */;
INSERT INTO `competency_assessments` VALUES
(1,7,1,'مدیر صادرات منطقه‌ای',3,5,'حیاتی','گذراندن کارگاه عملی UCP600 و شبیه‌ساز CIF در آکادمی تجارت بین‌الملل','2026-10-23 21:48:59'),
(2,7,2,'مدیر صادرات منطقه‌ای',2,5,'حیاتی','ثبت‌نام فوری در دوره مدیریت ریسک ارزی (TRD-204) به دلیل شکاف ۳ واحدی','2026-10-23 21:48:59'),
(3,7,4,'مدیر صادرات منطقه‌ای',1,4,'مهم','ضروری برای تداوم صادرات مقاطع فولادی به اتحادیه اروپا در سال ۲۰۲۶','2026-10-23 21:48:59'),
(4,8,3,'مسئول توسعه بازار اروپا',2,5,'حیاتی','تکمیل دوره هوش مصنوعی در بازاریابی صادراتی (AID-301)','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `competency_assessments` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `competitions`
--

DROP TABLE IF EXISTS `competitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `competitions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `current_round` varchar(80) DEFAULT 'راند دوم - نیمه‌نهایی استانی',
  `team_name` varchar(140) NOT NULL,
  `weighted_criteria_json` longtext NOT NULL,
  `jury_score` decimal(5,2) DEFAULT 91.20,
  `judge_comment` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `competitions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `competitions` WRITE;
/*!40000 ALTER TABLE `competitions` DISABLE KEYS */;
INSERT INTO `competitions` VALUES
(1,'لیگ استانی شبیه‌ساز مذاکره تجاری و مدیریت بحران صادراتی جام مؤسسه آموزشی آدان','راند دوم - نیمه‌نهایی','تیم پیشگامان تجارت پارس','{\"استراتژی قیمت‌گذاری ارزی\":30,\"تکنیک‌های مذاکره برد-برد\":30,\"مدیریت ریسک حقوقی قرارداد\":25,\"ارائه تیمی\":15}',92.40,'مدیریت هوشمندانه شرط تعدیل قیمت ارزی در برابر هیئت داوران'),
(2,'لیگ استانی شبیه‌ساز مذاکره تجاری و مدیریت بحران صادراتی جام مؤسسه آموزشی آدان','راند دوم - نیمه‌نهایی','تیم صادرات هوشمند زاگرس','{\"استراتژی قیمت‌گذاری ارزی\":30,\"تکنیک‌های مذاکره برد-برد\":30,\"مدیریت ریسک حقوقی قرارداد\":25,\"ارائه تیمی\":15}',88.90,'تسلط دقیق بر اینکوترمز CIP و بیمه باربری');
/*!40000 ALTER TABLE `competitions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `consulting_sessions`
--

DROP TABLE IF EXISTS `consulting_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `consulting_sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `consultant_id` int(11) NOT NULL,
  `client_user_id` int(11) NOT NULL,
  `topic` varchar(200) NOT NULL,
  `slot_label` varchar(120) NOT NULL,
  `status` enum('requested','confirmed','completed','cancelled') DEFAULT 'confirmed',
  `agenda` text DEFAULT NULL,
  `confidential_note` text DEFAULT NULL,
  `action_items` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consulting_sessions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `consulting_sessions` WRITE;
/*!40000 ALTER TABLE `consulting_sessions` DISABLE KEYS */;
INSERT INTO `consulting_sessions` VALUES
(1,5,7,'بازنگری قرارداد نمایندگی انحصاری توزیع در بازار عراق و امارات','چهارشنبه ۱۴۰۵/۰۸/۰۶ - ساعت ۱۶:۰۰ الی ۱۷:۳۰','confirmed','بررسی شرط داوری مرجع بین‌المللی ICC، سقف تضمین حداقل فروش سالانه و نحوه تسویه ارزی','یادداشت محرمانه مشاور: شرکت مراجع در قرارداد قبلی حق فسخ یک‌طرفه را پیش‌بینی نکرده که ریسک حقوقی بالایی دارد؛ اصلاح بند ۱۴ ضروری است.','ارسال پیش‌نویس اصلاحیه بند داوری و شرط فورس‌ماژور تا یکشنبه آینده','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `consulting_sessions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `content_friction_heatmaps`
--

DROP TABLE IF EXISTS `content_friction_heatmaps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `content_friction_heatmaps` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course_title` varchar(190) NOT NULL,
  `lesson_segment` varchar(160) NOT NULL,
  `avg_rewind_count` decimal(4,1) NOT NULL DEFAULT 3.2,
  `dropoff_rate_pct` int(11) NOT NULL DEFAULT 28,
  `quiz_error_rate_pct` int(11) NOT NULL DEFAULT 35,
  `ai_pedagogical_fix` varchar(240) NOT NULL,
  `analyzed_shamsi` varchar(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content_friction_heatmaps`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `content_friction_heatmaps` WRITE;
/*!40000 ALTER TABLE `content_friction_heatmaps` DISABLE KEYS */;
INSERT INTO `content_friction_heatmaps` VALUES
(1,'جامع ثبت سفارش NTSW و اظهار گمرکی EPL','درس ۲ — دقیقه ۱۸:۴۰ (فرمول محاسبه ارزش سیف و مأخذ ترکیبی)',4.6,39,48,'نقطه گلوگاه شدید! پیشنهاد AI: افزودن حل مثال عددی گام‌به‌گام ۲ دقیقه‌ای و پیوست اکسل فرموله‌شده آماده.','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(2,'اعتبارات اسنادی UCP 600 و ضمانت‌نامه‌های بانکی','درس ۴ — دقیقه ۲۶:۱۰ (ماده ۱۴ استاندارد بررسی اسناد)',3.8,27,36,'بازپخش بالا توسط فراگیران؛ پیشنهاد AI: درج اینفوگرافیک مقایسه‌ای ۵ روز کاری بانک عامل در کنار ویدئو.','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(3,'سامانه مؤدیان و پایانه‌های فروشگاهی','درس ۳ — دقیقه ۱۱:۱۵ (ارسال صورت‌حساب اصلاحی و ابطالی)',2.1,11,14,'روان و اثربخش — نرخ تکمیل ۸۹٪ (الگوی برتر طراحی آموزشی برای سایر اساتید).','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `content_friction_heatmaps` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `corporate_contracts`
--

DROP TABLE IF EXISTS `corporate_contracts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `corporate_contracts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contract_no` varchar(60) NOT NULL,
  `org_id` int(11) NOT NULL,
  `title` varchar(220) NOT NULL,
  `total_amount_rial` bigint(20) NOT NULL,
  `paid_amount_rial` bigint(20) DEFAULT 0,
  `seat_quota` int(11) NOT NULL DEFAULT 50,
  `seats_used` int(11) DEFAULT 0,
  `start_shamsi` varchar(30) NOT NULL,
  `end_shamsi` varchar(30) NOT NULL,
  `approval_stage` enum('draft','legal_review','finance_review','approved_active','expired') DEFAULT 'approved_active',
  `deliverables_summary` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `contract_no` (`contract_no`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `corporate_contracts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `corporate_contracts` WRITE;
/*!40000 ALTER TABLE `corporate_contracts` DISABLE KEYS */;
INSERT INTO `corporate_contracts` VALUES
(1,'CNT-1405-401',1,'قرارداد جامع توانمندسازی مدیران و کارشناسان صادرات فولاد زاگرس',2400000000,1800000000,60,44,'۱۴۰۵/۰۱/۱۵','۱۴۰۵/۱۲/۲۹','approved_active','شامل ۶ دوره تخصصی تجارت خارجی، کارگاه CBAM و گواهی‌نامه‌های دوزبانه مؤسسه آموزشی آدان','2026-10-23 21:48:59'),
(2,'CNT-1405-409',2,'قرارداد آموزشی بسته‌بندی، استانداردهای غذایی اروپا و بازاریابی صادراتی',1120000000,560000000,35,16,'۱۴۰۵/۰۶/۰۱','۱۴۰۶/۰۵/۳۱','approved_active','ویژه تیم فروش بین‌الملل و کنترل کیفیت صادراتی','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `corporate_contracts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `county_branches`
--

DROP TABLE IF EXISTS `county_branches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `county_branches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `county_name` varchar(120) NOT NULL,
  `branch_manager` varchar(150) NOT NULL,
  `active_courses_count` int(11) DEFAULT 4,
  `trained_learners_count` int(11) DEFAULT 120,
  `annual_budget_rial` bigint(20) DEFAULT 1200000000,
  `spent_budget_rial` bigint(20) DEFAULT 680000000,
  `key_specialty` varchar(180) NOT NULL,
  `status` varchar(40) DEFAULT 'فعال',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `county_branches`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `county_branches` WRITE;
/*!40000 ALTER TABLE `county_branches` DISABLE KEYS */;
INSERT INTO `county_branches` VALUES
(1,'دفتر نمایندگی شهرستان ویژه صنعتی شمال استان','مهندس سعید جعفری',6,215,1800000000,940000000,'قطعات صنعتی، نساجی و ایمنی کارگاه‌ها','فعال'),
(2,'دفتر نمایندگی شهرستان مرزی و گمرکی غرب استان','دکتر لیلا نادری',5,178,1500000000,810000000,'ترخیص کالا، ترانزیت جاده‌ای و تجارت مرزی','فعال'),
(3,'دفتر نمایندگی قطب کشاورزی جنوب استان','مهندس رضا شریفی',4,142,1100000000,530000000,'صادرات محصولات گلخانه‌ای، سردخانه و سورتینگ','فعال');
/*!40000 ALTER TABLE `county_branches` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `county_economic_clusters`
--

DROP TABLE IF EXISTS `county_economic_clusters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `county_economic_clusters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `county_name` varchar(120) NOT NULL,
  `dominant_cluster` varchar(160) NOT NULL,
  `active_industrial_units` int(11) DEFAULT 140,
  `skill_gap_index` int(11) DEFAULT 76,
  `prescribed_mobile_workshop` varchar(210) NOT NULL,
  `recommended_budget_share_pct` int(11) DEFAULT 22,
  `projected_export_boost_usd` bigint(20) DEFAULT 850000,
  `analyzed_shamsi` varchar(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `county_economic_clusters`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `county_economic_clusters` WRITE;
/*!40000 ALTER TABLE `county_economic_clusters` DISABLE KEYS */;
INSERT INTO `county_economic_clusters` VALUES
(1,'قطب صنعتی شمال استان (شهرک صنعتی شماره ۱ و ۲)','قطعات خودرو، ماشین‌سازی و فلزات اساسی',310,81,'تور کارگاهی استاندارد کربن مرزی اروپا (EU CBAM) و قراردادهای تأمین OEM',32,1650000,'۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59'),
(2,'قطب کشاورزی و فرآوری شرق استان','پسته، زعفران، گیاهان دارویی و صنایع تبدیلی',195,86,'کلینیک سیار بسته‌بندی خرده‌فروشی صادراتی، کد بهداشتی و فروش در اوراسیا',28,1420000,'۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59'),
(3,'قطب معدنی و سرامیک جنوب استان','فرآوری سنگ تزئینی، کاشی پرسلان و کانی‌های فلزی',160,78,'کارگاه لجستیک کانتینری، تهاتر ارزی و بازاریابی پروژه‌های عمرانی عراق و عمان',24,1180000,'۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `county_economic_clusters` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `course_categories`
--

DROP TABLE IF EXISTS `course_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `course_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(160) NOT NULL,
  `slug` varchar(160) NOT NULL,
  `icon` varchar(40) DEFAULT 'briefcase',
  `color` varchar(30) DEFAULT '#0f766e',
  `description` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_categories`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `course_categories` WRITE;
/*!40000 ALTER TABLE `course_categories` DISABLE KEYS */;
INSERT INTO `course_categories` VALUES
(1,'تجارت بین‌الملل و صادرات','international-trade','globe','#0d9488','اینکوترمز، حمل‌ونقل، گمرک، قراردادهای بین‌المللی و ارز'),
(2,'مدیریت اجرایی و رهبری (MBA)','leadership-mba','award','#1d4ed8','توسعه مدیران ارشد بنگاه‌های اقتصادی و حکمرانی شرکتی'),
(3,'مالی، مالیاتی و قوانین کسب‌وکار','finance-tax','briefcase','#b45309','سامانه مؤدیان، ارزش افزوده، استانداردهای حسابداری و تأمین مالی'),
(4,'هوش مصنوعی و تحول دیجیتال تجاری','ai-digital-trade','cpu','#7c3aed','کاربرد هوش مصنوعی مولد در بازاریابی صادراتی، زنجیره تأمین و تحلیل بازار');
/*!40000 ALTER TABLE `course_categories` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `course_proposals`
--

DROP TABLE IF EXISTS `course_proposals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `course_proposals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `org_id` int(11) DEFAULT NULL,
  `proposed_title` varchar(220) NOT NULL,
  `target_audience` varchar(180) DEFAULT NULL,
  `estimated_learners` int(11) DEFAULT 15,
  `business_problem` text DEFAULT NULL,
  `votes_count` int(11) DEFAULT 1,
  `status` enum('pending','ai_analyzed','approved','converted_to_course','rejected') DEFAULT 'pending',
  `ai_analysis_note` text DEFAULT NULL,
  `reviewer_comment` varchar(400) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_proposals`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `course_proposals` WRITE;
/*!40000 ALTER TABLE `course_proposals` DISABLE KEYS */;
INSERT INTO `course_proposals` VALUES
(1,6,1,'کارگاه عملی لجستیک کریدور شمال-جنوب و صادرات به اتحادیه اوراسیا','مدیران بازرگانی و لجستیک صنایع استان',34,'افزایش هزینه حمل دریایی و نیاز به بهره‌برداری از موافقت‌نامه تجارت آزاد ایران و اوراسیا',19,'ai_analyzed','تحلیل AI: هم‌پوشانی بالا با نیاز ۶۲٪ صادرکنندگان صنعتی استان؛ پیشنهاد تدوین دوره ۱۶ ساعته حضوری-کارگاهی.',NULL,'2026-10-23 21:48:59');
/*!40000 ALTER TABLE `course_proposals` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `course_runs`
--

DROP TABLE IF EXISTS `course_runs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `course_runs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) NOT NULL,
  `instructor_id` int(11) DEFAULT NULL,
  `classroom_id` int(11) DEFAULT NULL,
  `run_code` varchar(60) NOT NULL,
  `term_label` varchar(100) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `start_shamsi` varchar(30) NOT NULL,
  `schedule_text` varchar(180) NOT NULL,
  `capacity` int(11) NOT NULL DEFAULT 30,
  `enrolled_count` int(11) NOT NULL DEFAULT 0,
  `status` enum('planning','registration','running','completed','cancelled') DEFAULT 'registration',
  `execution_report` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `run_code` (`run_code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_runs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `course_runs` WRITE;
/*!40000 ALTER TABLE `course_runs` DISABLE KEYS */;
INSERT INTO `course_runs` VALUES
(1,1,5,1,'RUN-1405-01','پاییز ۱۴۰۵ - کد الف','2026-10-25','2026-11-18','۱۴۰۵/۰۸/۰۳','یکشنبه‌ها و سه‌شنبه‌ها ۱۴:۰۰ تا ۱۸:۰۰',30,28,'running','دو جلسه نخست با رضایت ۹۶ درصدی برگزار شد؛ مطالعه موردی اسناد حمل دریایی بندرعباس انجام گرفت.','2026-10-23 21:48:59'),
(2,2,5,1,'RUN-1405-02','آبان ۱۴۰۵ - ویژه صادرکنندگان','2026-11-01','2026-11-15','۱۴۰۵/۰۸/۱۰','دوشنبه‌ها و چهارشنبه‌ها ۱۵:۰۰ تا ۱۹:۰۰',25,25,'registration','ظرفیت اصلی تکمیل شد؛ ثبت‌نام‌های جدید به صورت خودکار وارد فهرست انتظار می‌شوند.','2026-10-23 21:48:59'),
(3,3,5,2,'RUN-1405-03','آذر ۱۴۰۵ - آنلاین و کارگاهی','2026-11-22','2026-12-10','۱۴۰۵/۰۹/۰۱','پنجشنبه‌ها ۰۹:۰۰ تا ۱۳:۰۰',35,19,'registration',NULL,'2026-10-23 21:48:59'),
(4,4,5,1,'RUN-1405-04','مهر ۱۴۰۵ - تکمیل شده','2026-09-26','2026-10-12','۱۴۰۵/۰۷/۰۴','شنبه‌ها و چهارشنبه‌ها ۱۴:۰۰ تا ۱۸:۰۰',40,38,'completed','میانگین نمره پس‌آزمون ۸۷.۴ از ۱۰۰ ثبت شد و ۳۶ گواهی‌نامه دارای QR صادر گردید.','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `course_runs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `course_sessions`
--

DROP TABLE IF EXISTS `course_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `course_sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `run_id` int(11) NOT NULL,
  `session_number` int(11) NOT NULL DEFAULT 1,
  `title` varchar(200) NOT NULL,
  `session_date` date NOT NULL,
  `session_shamsi` varchar(30) NOT NULL,
  `start_time` varchar(10) DEFAULT '14:00',
  `end_time` varchar(10) DEFAULT '18:00',
  `room_or_link` varchar(255) DEFAULT 'سالن خلیج فارس - طبقه دوم اتاق',
  `is_held` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_sessions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `course_sessions` WRITE;
/*!40000 ALTER TABLE `course_sessions` DISABLE KEYS */;
INSERT INTO `course_sessions` VALUES
(1,1,1,'تحلیل ساختار یازده قاعده Incoterms 2020 و تفکیک ریسک از هزینه','2026-10-25','۱۴۰۵/۰۸/۰۳','14:00','18:00','تالار خلیج فارس',1),
(2,1,2,'بررسی عملی قواعد دریایی FOB، CFR و CIF در صادرات صنعتی','2026-10-27','۱۴۰۵/۰۸/۰۵','14:00','18:00','تالار خلیج فارس',1),
(3,1,3,'اعتبارات اسنادی UCP600، بارنامه دریایی و بیمه‌نامه باربری','2026-11-01','۱۴۰۵/۰۸/۱۰','14:00','18:00','تالار خلیج فارس',0),
(4,2,1,'آخرین ضوابط بازگشت ارز حاصل از صادرات و کوتاژهای گمرکی','2026-11-02','۱۴۰۵/۰۸/۱۱','15:00','19:00','تالار خلیج فارس',0);
/*!40000 ALTER TABLE `course_sessions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `courses`
--

DROP TABLE IF EXISTS `courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `courses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `title` varchar(220) NOT NULL,
  `level` enum('مقدماتی','میانی','پیشرفته','مدیریتی ویژه') DEFAULT 'میانی',
  `delivery_mode` enum('حضوری','آنلاین همزمان','ترکیبی','خودآموز LMS') DEFAULT 'ترکیبی',
  `duration_hours` int(11) NOT NULL DEFAULT 16,
  `tuition_rial` bigint(20) NOT NULL DEFAULT 0,
  `member_discount_pct` int(11) DEFAULT 20,
  `prerequisite_text` varchar(255) DEFAULT 'ندارد',
  `workflow_status` enum('draft','under_review','approved','published','archived') DEFAULT 'published',
  `reviewer_note` varchar(500) DEFAULT NULL,
  `approved_by` int(11) DEFAULT NULL,
  `summary` text DEFAULT NULL,
  `rating` decimal(3,2) DEFAULT 4.80,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `idx_course_status` (`workflow_status`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `courses`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `courses` WRITE;
/*!40000 ALTER TABLE `courses` DISABLE KEYS */;
INSERT INTO `courses` VALUES
(1,1,'TRD-101','دوره جامع مدیریت صادرات، اینکوترمز ۲۰۲۰ و اسناد حمل بین‌المللی','پیشرفته','ترکیبی',24,68000000,25,'آشنایی مقدماتی با بازرگانی خارجی','published','تأیید کمیته علمی تجارت خارجی اتاق',1,'تسلط کاربردی بر قواعد Incoterms 2020، اعتبارات اسنادی UCP600، بارنامه‌ها و پوشش ریسک حمل.',4.92,'2026-10-23 21:48:59'),
(2,1,'TRD-204','مدیریت ریسک ارزی، پیمان‌سپاری و رفع تعهد ارزی صادرکنندگان','پیشرفته','حضوری',16,54000000,20,'فعالیت صادراتی یا مالی','published','منطبق با آخرین بخشنامه‌های بانک مرکزی ۱۴۰۵',1,'بررسی عملی سامانه نیما/مرکز مبادله، تهاتر ارزی، کوتاژهای صادراتی و جرائم مالیاتی مرتبط.',4.88,'2026-10-23 21:48:59'),
(3,4,'AID-301','هوش مصنوعی کاربردی در بازاریابی صادراتی و کشف خریداران خارجی','میانی','آنلاین همزمان',20,59000000,20,'ندارد','published','طراحی شده با همکاری استودیوی هوشمند AI',1,'استفاده از مدل‌های زبانی، تحلیل تعرفه‌های HS Code و اتوماسیون مکاتبات تجاری بین‌المللی.',4.95,'2026-10-23 21:48:59'),
(4,3,'TAX-110','کارگاه جامع سامانه مؤدیان، پایانه‌های فروشگاهی و مالیات ارزش افزوده','میانی','حضوری',12,42000000,15,'ندارد','published','پرمتقاضی‌ترین دوره واحدهای مالی فراگیران آدان',1,'آموزش گام‌به‌گام ارسال صورتحساب الکترونیکی نوع ۱ و ۲، اصلاح، ابطال و رسیدگی مالیاتی.',4.79,'2026-10-23 21:48:59'),
(5,2,'LDR-401','برنامه عالی توسعه رهبری و تصمیم‌گیری استراتژیک مدیران صنایع','مدیریتی ویژه','حضوری',40,145000000,30,'حداقل ۳ سال سابقه مدیریت','under_review','نیازمند تکمیل پیوست شبیه‌ساز تصمیم‌گیری فاز دوم',NULL,'ویژه مدیران عامل و اعضای هیئت‌مدیره شرکت‌های طرف قرارداد مؤسسه آموزشی آدان استان.',4.90,'2026-10-23 21:48:59'),
(6,1,'TRD-309','مقررات مکانیسم تعدیل کربن مرزی اتحادیه اروپا (CBAM) برای صادرکنندگان فولاد و سیمان','پیشرفته','ترکیبی',16,72000000,25,'صادرکنندگان صنعتی به اروپا','approved','تأیید کمیته علمی - آماده زمان‌بندی اجرا',1,'محاسبه ردپای کربن محصولات صادراتی و الزامات گزارش‌دهی گمرکی اتحادیه اروپا.',4.85,'2026-10-23 21:48:59');
/*!40000 ALTER TABLE `courses` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `crm_contacts`
--

DROP TABLE IF EXISTS `crm_contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `crm_contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `org_id` int(11) DEFAULT NULL,
  `full_name` varchar(160) NOT NULL,
  `position_title` varchar(120) DEFAULT 'مدیر آموزش و توسعه سرمایه انسانی',
  `phone` varchar(40) DEFAULT NULL,
  `email` varchar(160) DEFAULT NULL,
  `lead_score` int(11) DEFAULT 75,
  `last_interaction` varchar(255) DEFAULT 'تماس کارشناسی معرفی تقویم آموزشی پاییز',
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_contacts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `crm_contacts` WRITE;
/*!40000 ALTER TABLE `crm_contacts` DISABLE KEYS */;
INSERT INTO `crm_contacts` VALUES
(1,1,'پریسا بهرامی','مدیر آموزش و توسعه منابع انسانی','09121001006','hr@zagros-steel.ir',94,'درخواست برگزاری دوره اختصاصی CBAM برای ۱۲ نفر از مدیران فروش صادراتی','2026-10-23 21:48:59'),
(2,3,'مهندس کاوه دریادل','قائم‌مقام مدیرعامل لجستیک دریاپیما','09123334455','kaveh@daryapeyma.ir',86,'مذاکره قرارداد سالانه آموزش ترخیص‌کاران و کارشناسان حمل ترکیبی','2026-10-23 21:48:59'),
(3,4,'دکتر مریم شکیبا','مدیر تحقیق و توسعه پلیمر سپهر','09132221100','r_d@sepehr-poly.ir',79,'استعلام تعرفه بسته آموزشی هوش مصنوعی و بازاریابی بین‌الملل','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `crm_contacts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `crm_deals`
--

DROP TABLE IF EXISTS `crm_deals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `crm_deals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `org_id` int(11) NOT NULL,
  `title` varchar(220) NOT NULL,
  `estimated_value_rial` bigint(20) NOT NULL DEFAULT 850000000,
  `stage` enum('lead','qualified','proposal','negotiation','won','lost') DEFAULT 'proposal',
  `probability_pct` int(11) DEFAULT 60,
  `next_followup_shamsi` varchar(30) DEFAULT '۱۴۰۵/۰۸/۰۵',
  `owner_user_id` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_deals`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `crm_deals` WRITE;
/*!40000 ALTER TABLE `crm_deals` DISABLE KEYS */;
INSERT INTO `crm_deals` VALUES
(1,1,'قرارداد بسته جامع CBAM و صادرات سبز فولاد زاگرس',1450000000,'negotiation',85,'۱۴۰۵/۰۸/۰۴',4,'پیش‌نویس مالی ارسال شده و آماده امضای نهایی است','2026-10-23 21:48:59'),
(2,3,'تفاهم‌نامه آموزش ۴۰ کارشناس حمل‌ونقل بین‌المللی دریاپیما',920000000,'proposal',65,'۱۴۰۵/۰۸/۰۷',4,'ارسال سیلابس اختصاصی با تخفیف ۲۰٪ اعضای نقره‌ای اتاق','2026-10-23 21:48:59'),
(3,4,'دوره سازمانی هوش مصنوعی در بازرگانی پلیمر سپهر',780000000,'qualified',50,'۱۴۰۵/۰۸/۱۲',4,'نیازسنجی اولیه انجام شد','2026-10-23 21:48:59'),
(4,2,'تمدید قرارداد آموزشی سالانه زعفران تابان',1120000000,'won',100,'۱۴۰۵/۰۸/۰۱',4,'قرارداد امضا و پیش‌پرداخت وصول گردید','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `crm_deals` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `crm_rfm_scores`
--

DROP TABLE IF EXISTS `crm_rfm_scores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `crm_rfm_scores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `org_id` int(11) NOT NULL,
  `org_name` varchar(180) NOT NULL,
  `recency_days` int(11) DEFAULT 18,
  `frequency_count` int(11) DEFAULT 4,
  `monetary_rial` bigint(20) DEFAULT 180000000,
  `rfm_composite` int(11) DEFAULT 85,
  `segment_label` varchar(80) NOT NULL,
  `churn_probability_pct` int(11) DEFAULT 12,
  `next_best_course` varchar(200) NOT NULL,
  `prescribed_discount_pct` int(11) DEFAULT 10,
  `updated_shamsi` varchar(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_rfm_scores`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `crm_rfm_scores` WRITE;
/*!40000 ALTER TABLE `crm_rfm_scores` DISABLE KEYS */;
INSERT INTO `crm_rfm_scores` VALUES
(1,1,'مجتمع فولاد و ذوب‌آهن زاگرس',9,8,920000000,96,'قهرمان وفادار استراتژیک (Champions)',6,'استاندارد کربن مرزی اتحادیه اروپا (EU CBAM) ویژه صنایع فلزی',15,'۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59'),
(2,2,'گروه صنعتی پسته و خشکبار زرین‌صادر',21,5,540000000,84,'مشتری وفادار صادراتی (Loyal)',14,'شکار خریداران خارجی با هوش مصنوعی و ITC TradeMap',10,'۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59'),
(3,3,'شرکت پتروشیمی و پلیمر تابان',58,3,390000000,62,'نیازمند مراقبت و فعال‌سازی سهمیه',43,'قراردادهای تجارت متقابل، تهاتر ارزی و تسویه بین‌المللی',15,'۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59'),
(4,4,'صنایع غذایی و لبنی بهاران استان',104,2,210000000,39,'در معرض ریزش فوری (At-Risk VIP)',74,'کارگاه عملیاتی موافقت‌نامه تجارت آزاد اوراسیا (EAEU)',25,'۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `crm_rfm_scores` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `discount_codes`
--

DROP TABLE IF EXISTS `discount_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `discount_codes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `discount_pct` int(11) NOT NULL DEFAULT 15,
  `max_uses` int(11) DEFAULT 100,
  `used_count` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discount_codes`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `discount_codes` WRITE;
/*!40000 ALTER TABLE `discount_codes` DISABLE KEYS */;
INSERT INTO `discount_codes` VALUES
(1,'CHAMBER25',25,200,46,1),
(2,'EXPORT1405',15,100,19,1);
/*!40000 ALTER TABLE `discount_codes` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `documents`
--

DROP TABLE IF EXISTS `documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `doc_category` varchar(80) DEFAULT 'اسناد رسمی و بخشنامه‌ها',
  `file_name` varchar(200) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `uploaded_by` int(11) NOT NULL,
  `access_scope` enum('public','staff','org_only') DEFAULT 'staff',
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `documents` WRITE;
/*!40000 ALTER TABLE `documents` DISABLE KEYS */;
INSERT INTO `documents` VALUES
(1,'تقویم جامع آموزشی پاییز و زمستان ۱۴۰۵ مؤسسه آموزشی آدان','تقویم و بخشنامه‌ها','calendar_1405_chamber.txt','storage/uploads/docs/calendar_1405_chamber.txt',1,'public','2026-10-23 21:48:59'),
(2,'فرم استاندارد قرارداد آموزشی بنگاه‌های اقتصادی دانش‌پذیر آدان','قراردادها و حقوقی','corporate_contract_template.txt','storage/uploads/docs/corporate_contract_template.txt',1,'staff','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `documents` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `dynamic_forms`
--

DROP TABLE IF EXISTS `dynamic_forms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `dynamic_forms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `slug` varchar(120) NOT NULL,
  `purpose` varchar(150) DEFAULT 'نظرسنجی و گردآوری داده پژوهشی',
  `fields_json` longtext NOT NULL,
  `submissions_count` int(11) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dynamic_forms`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `dynamic_forms` WRITE;
/*!40000 ALTER TABLE `dynamic_forms` DISABLE KEYS */;
INSERT INTO `dynamic_forms` VALUES
(1,'فرم نیازسنجی مهارت‌های صادراتی و هوش مصنوعی صنایع استان (۱۴۰۵)','export-tna-1405','پژوهش آموزشی و نیازسنجی سالانه اعضا','[{\"name\":\"company_name\",\"label\":\"نام شرکت / واحد صنعتی\",\"type\":\"text\"},{\"name\":\"export_target\",\"label\":\"مهم‌ترین بازار هدف صادراتی\",\"type\":\"select\",\"options\":[\"عراق و همسایگان\",\"امارات و خلیج فارس\",\"اتحادیه اوراسیا و روسیه\",\"اتحادیه اروپا\",\"چین و شرق آسیا\"]},{\"name\":\"priority_skill\",\"label\":\"اولویت اول آموزشی سال ۱۴۰۵\",\"type\":\"select\",\"options\":[\"اینکوترمز ۲۰۲۰ و قراردادها\",\"رفع تعهد ارزی و بانکی\",\"هوش مصنوعی در صادرات\",\"مالیات و سامانه مؤدیان\",\"استاندارد CBAM اروپا\"]},{\"name\":\"notes\",\"label\":\"چالش اصلی بازرگانی شرکت شما\",\"type\":\"textarea\"}]',28,'2026-10-23 21:48:59');
/*!40000 ALTER TABLE `dynamic_forms` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `enrollments`
--

DROP TABLE IF EXISTS `enrollments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `enrollments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `run_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `org_id` int(11) DEFAULT NULL,
  `source` enum('web','bulk_org','api','admin') DEFAULT 'web',
  `status` enum('active','waitlist','completed','cancelled') DEFAULT 'active',
  `attendance_pct` int(11) DEFAULT 100,
  `progress_pct` int(11) DEFAULT 0,
  `final_score` decimal(5,2) DEFAULT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_run_user` (`run_id`,`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enrollments`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `enrollments` WRITE;
/*!40000 ALTER TABLE `enrollments` DISABLE KEYS */;
INSERT INTO `enrollments` VALUES
(1,1,7,1,'bulk_org','active',100,67,91.50,1,'2026-10-23 21:48:59'),
(2,1,8,2,'web','active',100,34,NULL,2,'2026-10-23 21:48:59'),
(3,2,8,2,'api','waitlist',0,0,NULL,NULL,'2026-10-23 21:48:59'),
(4,4,7,1,'bulk_org','completed',100,100,94.00,1,'2026-10-23 21:48:59');
/*!40000 ALTER TABLE `enrollments` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `erp_admin_requests_templates`
--

DROP TABLE IF EXISTS `erp_admin_requests_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `erp_admin_requests_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entry_code` varchar(45) NOT NULL,
  `record_category` varchar(30) NOT NULL DEFAULT 'student_request',
  `applicant_or_event` varchar(175) NOT NULL,
  `request_type_or_channel` varchar(120) NOT NULL,
  `body_or_template` text NOT NULL,
  `approval_state` varchar(60) NOT NULL DEFAULT 'تأیید و صادرشده ✅',
  `updated_shamsi` varchar(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `entry_code` (`entry_code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `erp_admin_requests_templates`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `erp_admin_requests_templates` WRITE;
/*!40000 ALTER TABLE `erp_admin_requests_templates` DISABLE KEYS */;
INSERT INTO `erp_admin_requests_templates` VALUES
(1,'ADM-REQ-801','student_request','مهندس مهرداد شریفی','گواهی اشتغال به تحصیل/دوره رسمی جهت کارفرما','بدین‌وسیله گواهی می‌شود نامبرده در دوره ۸۰ ساعته تجارت بین‌الملل مرکز آموزش مؤسسه آموزشی آدان مشغول به تحصیل می‌باشد.','تأیید و صادرشده ✅','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(2,'ADM-REQ-802','student_request','جناب آقای کامیار رضوانی','درخواست شرکت در جلسه جبرانی غیبت موجه','ارائه گواهی مأموریت گمرکی بندرعباس جهت جبران ۲ جلسه غیبت دوره کارت بازرگانی.','در انتظار تأیید کارشناس آموزش','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(3,'TPL-SMS-101','notif_template','رویداد: ثبت‌نام قطعی در دوره آموزشی','پیامک خدماتی + بازوی بله','فراگیر گرامی {full_name}؛ ثبت‌نام شما در دوره «{course_title}» قطعی شد. شروع کلاس: {class_date} — مرکز آموزش مؤسسه آموزشی آدان.','قالب فعال سیستمی ✅','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(4,'TPL-SMS-102','notif_template','رویداد: اعلام نمره نهایی و صدور گواهی QR','پیامک خدماتی + ایمیل رسمی','تبریک {full_name} عزیز! نمره نهایی شما ({score}/100) ثبت و گواهی رسمی با سریال {cert_serial} آماده دریافت است.','قالب فعال سیستمی ✅','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `erp_admin_requests_templates` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `erp_automation_rules`
--

DROP TABLE IF EXISTS `erp_automation_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `erp_automation_rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rule_code` varchar(40) NOT NULL,
  `rule_title` varchar(200) NOT NULL,
  `source_module` varchar(80) NOT NULL,
  `trigger_condition` varchar(220) NOT NULL,
  `target_modules` varchar(180) NOT NULL,
  `autonomous_action` varchar(255) NOT NULL,
  `executions_count` int(11) DEFAULT 0,
  `last_triggered_shamsi` varchar(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `rule_code` (`rule_code`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `erp_automation_rules`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `erp_automation_rules` WRITE;
/*!40000 ALTER TABLE `erp_automation_rules` DISABLE KEYS */;
INSERT INTO `erp_automation_rules` VALUES
(1,'AUTO-ERP-01','تجویز خودکار بسته آموزشی و یارانه پس از عارضه‌یابی کلینیک صنعت','کلینیک عارضه‌یابی (۳۱)','امتیاز آمادگی صادرات کارخانه کمتر از ۶۵٪','CRM (۱۰) + یارانه‌ها (۳۳) + TMS (۱)','ایجاد سرنخ سازمانی داغ + اختصاص بن ۳۰٪ یارانه SME + ثبت پیش‌فاکتور گروهی',14,'۱۴۰۵/۰۷/۳۰',1,'2026-10-23 21:48:59'),
(2,'AUTO-ERP-02','گشایش خودکار پرونده اقدام اصلاحی ایزو (CAPA) در افت کیفیت دوره','ارزشیابی کرکپاتریک (۸)','افت شاخص رضایت یا یادگیری زیر ۷۸ امتیاز','تضمین کیفیت ایزو (۳۰) + BPMS (۲۲)','ثبت عدم انطباق ایزو ۲۱۰۰۱ + بازنگری طرح درس استاد در کارتابل BPMS',5,'۱۴۰۵/۰۷/۲۹',1,'2026-10-23 21:48:59'),
(3,'AUTO-ERP-03','هشدار پیش‌بینانه ۹۰ روزه انقضای کارت بازرگانی و ثبت‌نام تمدید','کارت بازرگانی (۲۵)','باقی‌ماندن کمتر از ۶۰ روز تا انقضای اعتبار کارت','پیام‌رسان بومی (۳۷) + پرتال اعضا (۹)','ارسال اخطار رسمی در بله/ایتا و پیامک + رزرو خودکار کلاس الزامی تمدید',29,'۱۴۰۵/۰۷/۳۰',1,'2026-10-23 21:48:59'),
(4,'AUTO-ERP-04','اتصال خودکار فارغ‌التحصیل ممتاز به بازارگاه اشتغال و کنسرسیوم','آزمون‌ها و گواهی (۱۵)','کسب نمره بالای ۸۵ + تکمیل کارنامه MBTI/CEFR','کاریابی صنعتی (۳۲) + گذرنامه مهارتی','به‌روزرسانی گذرنامه مهارتی + معرفی خودکار به ۳ کارخانه دارای موقعیت باز',21,'۱۴۰۵/۰۷/۳۰',1,'2026-10-23 21:48:59'),
(5,'AUTO-ERP-05','سپر محافظ ریسک نقدینگی، سررسید چک صیادی و نقطه سربه‌سر کلاس','امور مالی و صیاد (۷)','تکمیل ظرفیت کمتر از ۷۰٪ در ۷۲ ساعت مانده یا سررسید چک','هوش بازاریابی + خزانه‌داری + CRM','فعال‌سازی کمپین تخفیف لحظه آخری ۲۰٪ برای تکمیل صندلی خالی + هشدار خزانه',9,'۱۴۰۵/۰۷/۳۰',1,'2026-10-23 21:48:59');
/*!40000 ALTER TABLE `erp_automation_rules` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `erp_help_custom_notes`
--

DROP TABLE IF EXISTS `erp_help_custom_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `erp_help_custom_notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `route_key` varchar(90) NOT NULL,
  `local_sop_title` varchar(185) NOT NULL,
  `local_sop_body` text NOT NULL,
  `contact_extension` varchar(80) NOT NULL DEFAULT 'داخلی ۲۱۰ — واحد راهبری سیستم',
  `video_guide_url` varchar(255) DEFAULT '',
  `updated_by` varchar(120) DEFAULT 'مدیرکل آموزش',
  `updated_shamsi` varchar(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `route_key` (`route_key`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `erp_help_custom_notes`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `erp_help_custom_notes` WRITE;
/*!40000 ALTER TABLE `erp_help_custom_notes` DISABLE KEYS */;
INSERT INTO `erp_help_custom_notes` VALUES
(1,'dashboard','دستورالعمل روزانه بررسی شاخص‌های کلیدی فرماندهی','مدیران محترم در ابتدای هر روز کاری ابتدا کارت هشدارهای هوشمند، وضعیت تراز حسابداری (صفر ریال مغایرت) و کارتابل امضاهای منتظر اقدام را بازبینی نمایند.','داخلی ۱۰۱ — دفتر مدیرکل آموزش','','دکتر کیارش رادمهر','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(2,'career-hub','ضابطه تأیید آگهی‌های شغلی کارخانجات دانش‌پذیر آدان','پیش از فعال‌سازی نشان «کارفرمای همکار آدان»، اطلاعات سازمان، راه ارتباطی و سابقه همکاری آموزشی بررسی گردد.','داخلی ۲۴۵ — واحد اشتغال و صنعت','','کارشناس مسئول کاریابی','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(3,'finance','الزام کنترل تراز آزمایشی پیش از ارسال به سامانه مؤدیان','کلیه اسناد استرداد شهریه و کسور مالیات تکلیفی ماده ۸۶ اساتید باید پیش از بستن دوره ماهانه دارای اختلاف تراز دقیق صفر ریال باشند.','داخلی ۳۱۰ — مدیریت مالی آموزش','','مدیر امور مالی','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `erp_help_custom_notes` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `erp_help_feedback_logs`
--

DROP TABLE IF EXISTS `erp_help_feedback_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `erp_help_feedback_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `route_key` varchar(90) NOT NULL,
  `user_fullname` varchar(150) NOT NULL,
  `is_helpful` tinyint(1) NOT NULL DEFAULT 1,
  `suggestion_note` varchar(240) NOT NULL DEFAULT 'راهنمای گام‌به‌گام کاملاً شفاف و کاربردی بود',
  `created_shamsi` varchar(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `erp_help_feedback_logs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `erp_help_feedback_logs` WRITE;
/*!40000 ALTER TABLE `erp_help_feedback_logs` DISABLE KEYS */;
INSERT INTO `erp_help_feedback_logs` VALUES
(1,'microlearning','مهندس مهرداد شریفی',1,'توضیح الگوریتم مرور فاصله‌دار لایتنر SM-2 بسیار دقیق و راهگشا بود.','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(2,'system-settings','سرکار خانم مهندس پگاه کاظمی',1,'بخش پیش‌نمایش زنده فونت و پالت رنگی بدون رفرش عالی توضیح داده شده است.','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(3,'iam-access','دکتر کیارش رادمهر',1,'راهنمای تفاوت سطح دید داده شعبه‌ای و شرکتی بسیار شفاف است.','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `erp_help_feedback_logs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `erp_helpdesk_tickets`
--

DROP TABLE IF EXISTS `erp_helpdesk_tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `erp_helpdesk_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_no` varchar(45) NOT NULL,
  `requester_name` varchar(150) NOT NULL,
  `requester_role` varchar(60) NOT NULL DEFAULT 'فراگیر دانش‌پذیر آدان',
  `department_unit` varchar(90) NOT NULL,
  `priority_level` varchar(25) NOT NULL DEFAULT 'بالا (فوری)',
  `sla_hours` int(11) NOT NULL DEFAULT 4,
  `subject_line` varchar(200) NOT NULL,
  `official_reply` text DEFAULT NULL,
  `ticket_status` varchar(40) NOT NULL DEFAULT 'در انتظار پاسخ کارشناس',
  `created_shamsi` varchar(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ticket_no` (`ticket_no`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `erp_helpdesk_tickets`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `erp_helpdesk_tickets` WRITE;
/*!40000 ALTER TABLE `erp_helpdesk_tickets` DISABLE KEYS */;
INSERT INTO `erp_helpdesk_tickets` VALUES
(1,'TKT-1405-401','مهندس مهرداد شریفی','فراگیر دانش‌پذیر آدان','امتحانات و صدور گواهی QR','عادی',8,'درخواست صدور نسخه انگلیسی دوزبانه گواهی دوره اینکوترمز جهت ضمیمه پرونده اتاق مشترک','نسخه دوزبانه انگلیسی-فارسی با کد QR معتبر صادر و در کارتابل شما فعال شد.','پاسخ داده و بسته شد ✅','۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59'),
(2,'TKT-1405-402','نماینده آموزش فولاد زاگرس','نماینده کارخانه (org_rep)','امور مالی و فاکتور رسمی مؤدیان','بالا (فوری)',4,'درخواست ثبت کد یکتای ۲۲ رقمی مالیاتی روی فاکتور ثبت‌نام گروهی ۱۲ نفره',NULL,'در انتظار پاسخ کارشناس','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(3,'TKT-1405-403','جناب آقای نیما فرهادی','فراگیر دانش‌پذیر آدان','پشتیبانی فنی کلاس آنلاین اسکای‌روم','متوسط',6,'دسترسی به ویدئوی ضبط‌شده کارگاه عملی تنظیم قرارداد CISG جلسه چهارم','لینک بازپخش امن با واترمارک اختصاصی در بخش LMS شما فعال گردید.','پاسخ داده و بسته شد ✅','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `erp_helpdesk_tickets` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `erp_smart_alerts`
--

DROP TABLE IF EXISTS `erp_smart_alerts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `erp_smart_alerts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `alert_code` varchar(40) NOT NULL,
  `severity` varchar(20) NOT NULL DEFAULT 'warning',
  `module_route` varchar(80) NOT NULL,
  `alert_title` varchar(210) NOT NULL,
  `ai_diagnosis` text NOT NULL,
  `prescribed_action` varchar(240) NOT NULL,
  `financial_impact_rial` bigint(20) DEFAULT 0,
  `status` varchar(30) DEFAULT 'open',
  `resolved_shamsi` varchar(30) DEFAULT '',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `alert_code` (`alert_code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `erp_smart_alerts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `erp_smart_alerts` WRITE;
/*!40000 ALTER TABLE `erp_smart_alerts` DISABLE KEYS */;
INSERT INTO `erp_smart_alerts` VALUES
(1,'ALT-1405-01','critical','crm','خطر ریزش ۲ بنگاه بزرگ عضو طلایی (احتمال ریزش ۷۴٪ در مدل RFM)','شرکت صنایع غذایی بهاران و نساجی کویر بیش از ۹۵ روز ثبت‌نام جدید نداشته‌اند و ۴۲٪ سهمیه قرارداد سالانه‌شان بدون استفاده مانده است.','ارسال بسته اختصاصی کارگاه EU CBAM و اینکوترمز با ۱۵٪ مشوق تمدید قرارداد B2B',640000000,'open','','2026-10-23 21:48:59'),
(2,'ALT-1405-02','opportunity','market-radar','شکاف درآمدی ۸۹۶ میلیون ریالی در دوره عملیاتی NTSW و اظهار EPL',' تقاضای جست‌وجوی استان ۹۶ از ۱۰۰ است اما ظرفیت دوره عملیاتی سامانه جامع تجارت در تقویم آبان تکمیل شده و لیست انتظار ۱۸ نفره شکل گرفته است.','افتتاح خودکار گروه دوم دوره در تالار خلیج فارس (چهارشنبه‌ها ۱۴ تا ۱۸)',896000000,'open','','2026-10-23 21:48:59'),
(3,'ALT-1405-03','warning','finance','نزدیک‌شدن سررسید چک صیادی ۲۴۰ میلیون ریالی در خزانه آموزش','یک فقره چک صیادی بابت قسط دوم قرارداد آموزشی سازمانی طی ۵ روز آینده سررسید می‌شود.','ارسال یادآور خودکار خزانه‌داری و آماده‌سازی سند تسویه ۴ سطحی',240000000,'open','','2026-10-23 21:48:59'),
(4,'ALT-1405-04','warning','lms','هشدار زودهنگام افت پیشرفت ۳ فراگیر کارت بازرگانی در محتوای SCORM','نرخ تماشای ویدئو و تعامل ۳ متقاضی در هفته جاری زیر ۴۰٪ بوده و احتمال مردودی در آزمون پایانی ۶۸٪ برآورد می‌شود.','ارسال میکروجزوه جبرانی هوشمند + یادآور پشتیبان آموزشی در پرتال',135000000,'open','','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `erp_smart_alerts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `erp_system_settings`
--

DROP TABLE IF EXISTS `erp_system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `erp_system_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_group` varchar(50) NOT NULL,
  `setting_key` varchar(90) NOT NULL,
  `setting_label` varchar(180) NOT NULL,
  `setting_value` text NOT NULL,
  `input_type` varchar(30) NOT NULL DEFAULT 'text',
  `updated_by` varchar(120) DEFAULT 'مدیرکل آموزش',
  `updated_shamsi` varchar(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `erp_system_settings`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `erp_system_settings` WRITE;
/*!40000 ALTER TABLE `erp_system_settings` DISABLE KEYS */;
INSERT INTO `erp_system_settings` VALUES
(1,'academic','min_attendance_pct','حداقل درصد حضور الزامی جهت مجوز صدور گواهی QR (٪)','80','number','مدیرکل آموزش','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(2,'academic','passing_grade_min','حداقل نمره قبولی استاندارد دوره‌های تخصصی (از ۱۰۰)','70','number','مدیرکل آموزش','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(3,'academic','certificate_serial_prefix','الگوی پیشوند شماره سریال رسمی گواهی‌نامه‌ها','CERT-ADN-1405-','text','مدیرکل آموزش','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(4,'academic','add_drop_hours_limit','مهلت انصراف و جابه‌جایی بدون کسر جریمه (ساعت قبل از شروع)','72','number','کارشناس مسئول آموزش','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(5,'finance','vat_rate_pct','نرخ قانونی مالیات بر ارزش افزوده صورت‌حساب‌ها (٪)','10','number','مدیر مالی آموزش','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(6,'finance','instructor_tax_art86_pct','نرخ کسور مالیات تکلیفی حق‌التدریس اساتید ماده ۸۶ (٪)','10','number','مدیر مالی آموزش','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(7,'finance','max_installments_count','حداکثر تعداد اقساط مجاز شهریه قراردادهای سازمانی','4','number','مدیر مالی آموزش','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(8,'finance','default_payment_gateway','درگاه پرداخت اینترنتی پیش‌فرض (شاپرک / بانکی)','به‌پرداخت بانک ملت + زرین‌پال (حالت شبیه‌ساز امن تا ثبت مرچنت)','text','مدیر مالی آموزش','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(9,'ai_integrations','ai_base_url','آدرس پایه وب‌سرویس هوش مصنوعی AI','https://api.openai.com/v1','text','مدیرکل آموزش','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(10,'ai_integrations','ai_default_model','مدل پیش‌فرض تحلیل آموزشی و مشاور هوشمند','gpt-4o-mini','text','مدیرکل آموزش','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(11,'ai_integrations','enforce_pii_masking','ماسک خودکار کد ملی و موبایل پیش از ارسال به هوش مصنوعی','فعال و اجباری (PII Shield Active)','text','مدیرکل آموزش','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(12,'ai_integrations','sms_messenger_gateway','خط خدماتی پیامک و بازوهای پیام‌رسان بومی (بله / ایتا)','خط خدماتی ۹۰۰۰۱۲۳۴ + بازوی رسمی بله و ایتا','text','مدیر CRM','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(13,'security','session_timeout_minutes','زمان قفل و خروج خودکار نشست کاربری در صورت عدم فعالیت (دقیقه)','45','number','مدیرکل آموزش','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(14,'security','max_failed_logins','حداکثر تلاش ناموفق ورود پیش از فعال‌سازی قفل ضد Brute-Force','5','number','مدیرکل آموزش','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(15,'security','require_human_approval_ai','الزام تأیید نهایی انسانی پیش از انتشار خروجی‌های AI و کمپین‌ها','اجباری طبق ضوابط حکمرانی مؤسسه','text','مدیرکل آموزش','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `erp_system_settings` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `erp_ui_theme_profiles`
--

DROP TABLE IF EXISTS `erp_ui_theme_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `erp_ui_theme_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `theme_slug` varchar(60) NOT NULL,
  `theme_title` varchar(150) NOT NULL,
  `color_mode` varchar(15) NOT NULL DEFAULT 'light',
  `primary_hex` varchar(16) NOT NULL DEFAULT '#0f766e',
  `gold_accent_hex` varchar(16) NOT NULL DEFAULT '#c99227',
  `sidebar_bg_hex` varchar(16) NOT NULL DEFAULT '#0b1f3a',
  `font_family_key` varchar(40) NOT NULL DEFAULT 'Vazirmatn',
  `base_font_px` int(11) NOT NULL DEFAULT 14,
  `line_height_val` varchar(10) NOT NULL DEFAULT '1.75',
  `border_radius_px` int(11) NOT NULL DEFAULT 16,
  `ui_density` varchar(20) NOT NULL DEFAULT 'comfortable',
  `brand_org_title` varchar(190) NOT NULL DEFAULT 'مؤسسه آموزشی آدان',
  `brand_unit_subtitle` varchar(190) NOT NULL DEFAULT 'آموزش تخصصی حسابداری و امور مالی',
  `brand_monogram` varchar(16) NOT NULL DEFAULT 'ناب',
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `updated_shamsi` varchar(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `theme_slug` (`theme_slug`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `erp_ui_theme_profiles`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `erp_ui_theme_profiles` WRITE;
/*!40000 ALTER TABLE `erp_ui_theme_profiles` DISABLE KEYS */;
INSERT INTO `erp_ui_theme_profiles` VALUES
(1,'modern_indigo','نیلی مدرن سازمانی با قلم وزیرمتن (پوسته مدرن پیش‌فرض)','light','#4f46e5','#d97706','#0f172a','Vazirmatn',14,'1.75',16,'comfortable','مؤسسه آموزشی آدان','آموزش تخصصی حسابداری و امور مالی','ناب',1,'۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(2,'emerald_gold','زمردی و طلایی مؤسسه آموزشی آدان (پالت رسمی کلاسیک)','light','#0f766e','#d97706','#0b192c','Shabnam_Modern',14,'1.75',16,'comfortable','مؤسسه آموزشی آدان','آموزش تخصصی حسابداری و امور مالی','ناب',0,'۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(3,'ocean_sahel','آبی اقیانوسی با قلم ساحل (ویژه مطالعه و مستندات)','light','#0284c7','#0d9488','#0c192c','Sahel_Modern',15,'1.85',18,'spacious','مؤسسه آموزشی آدان','آموزش تخصصی حسابداری و امور مالی','ناب',0,'۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(4,'midnight_executive','حالت شب مدرن ابسیدین (Executive Dark Mode)','dark','#6366f1','#fbbf24','#090d16','Vazirmatn',14,'1.75',16,'comfortable','مؤسسه آموزشی آدان','آموزش تخصصی حسابداری و امور مالی','ناب',0,'۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(5,'amethyst_academy','بنفش نوآوری با قلم صمیم (ویژه پژوهش و هوش مصنوعی)','light','#7c3aed','#ec4899','#130f26','Samim_Editorial',14,'1.80',18,'comfortable','مؤسسه آموزشی آدان','آموزش تخصصی حسابداری و امور مالی','ناب',0,'۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(6,'gov_compact_tahoma','لاجوردی فشرده پرتراکم با قلم تاهوما (ویژه جداول مالی)','light','#2563eb','#d97706','#111827','Tahoma_Formal',13,'1.65',10,'compact','مؤسسه آموزشی آدان','آموزش تخصصی حسابداری و امور مالی','ناب',0,'۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `erp_ui_theme_profiles` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `evaluations`
--

DROP TABLE IF EXISTS `evaluations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `evaluations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) NOT NULL,
  `evaluator_id` int(11) NOT NULL,
  `kirkpatrick_l1_reaction` decimal(4,2) DEFAULT 4.60,
  `pre_test_score` decimal(5,2) DEFAULT 48.00,
  `post_test_score` decimal(5,2) DEFAULT 86.00,
  `kirkpatrick_l3_behavior` decimal(4,2) DEFAULT 4.20,
  `transfer_notes` varchar(350) DEFAULT NULL,
  `program_cost_rial` bigint(20) DEFAULT 450000000,
  `estimated_benefit_rial` bigint(20) DEFAULT 1150000000,
  `feedback_360_summary` varchar(400) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evaluations`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `evaluations` WRITE;
/*!40000 ALTER TABLE `evaluations` DISABLE KEYS */;
INSERT INTO `evaluations` VALUES
(1,4,2,4.78,44.50,87.40,4.35,'کاهش خطای ثبت صورتحساب‌های الکترونیکی در واحد مالی شرکت‌های شرکت‌کننده پس از ۶۰ روز به میزان ۷۲٪',245000000,1360000000,'همسویی امتیاز خودارزیابی (۴.۴) با ارزیابی مدیر مستقیم (۴.۵) در شاخص انطباق مالیاتی','2026-10-23 21:48:59'),
(2,1,2,4.92,51.00,89.50,4.50,'اصلاح ترم تحویل در ۸ قرارداد صادراتی واقعی شرکت‌های عضو و جلوگیری از جریمه دموراژ کانتینر',390000000,1480000000,'رشد چشمگیر مهارت مذاکره قرارداد بین‌المللی طبق نظر مدیر بازرگانی','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `evaluations` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `event_tickets`
--

DROP TABLE IF EXISTS `event_tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `ticket_code` varchar(80) NOT NULL,
  `paid_status` enum('free','paid_invoice') DEFAULT 'free',
  `checked_in_at` datetime DEFAULT NULL,
  `feedback_score` tinyint(4) DEFAULT NULL,
  `feedback_comment` varchar(300) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ticket_code` (`ticket_code`),
  UNIQUE KEY `uq_event_user` (`event_id`,`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_tickets`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `event_tickets` WRITE;
/*!40000 ALTER TABLE `event_tickets` DISABLE KEYS */;
INSERT INTO `event_tickets` VALUES
(1,1,7,'TKT-ADN-1405-7001','free','2026-10-23 21:48:59',5,'تمرین ثبت اسناد و چرخه حسابداری کاربردی بود.','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `event_tickets` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `title` varchar(220) NOT NULL,
  `event_type` enum('همایش استانی','نشست هیئت تجاری','سمینار تخصصی','کارگاه رایگان اعضا','کارگاه آموزشی','نشست تخصصی','جلسه رفع اشکال') DEFAULT 'کارگاه آموزشی',
  `speakers` varchar(350) NOT NULL,
  `event_date` date NOT NULL,
  `event_shamsi` varchar(30) NOT NULL,
  `venue` varchar(200) DEFAULT 'آموزشگاه حسابداری آدان',
  `capacity` int(11) NOT NULL DEFAULT 150,
  `registered_count` int(11) DEFAULT 0,
  `price_rial` bigint(20) NOT NULL DEFAULT 0,
  `estimated_cost_rial` bigint(20) DEFAULT 0,
  `sms_reminder_status` enum('sandbox_queued','sandbox_sent','disabled') DEFAULT 'sandbox_queued',
  `status` enum('open','sold_out','closed') DEFAULT 'open',
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `events`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
INSERT INTO `events` VALUES
(1,'EVT-FREE-01','نشست تخصصی فرصت‌های صادراتی موافقت‌نامه تجارت آزاد ایران و اوراسیا (ویژه اعضا - رایگان)','نشست هیئت تجاری','مدیر مؤسسه آموزشی آدان استان، رایزن بازرگانی اوراسیا، دکتر امیرحسین نیکزاد','2026-11-05','۱۴۰۵/۰۸/۱۴','مرکز همایش‌های بین‌المللی مؤسسه آموزشی آدان',180,112,0,280000000,'sandbox_queued','open','2026-10-23 21:48:59'),
(2,'EVT-PAID-02','همایش سالانه مدیران مالی و چشم‌انداز اقتصادی و ارزی ۱۴۰۶ (دارای تعرفه ثبت‌نام)','همایش استانی','اعضای مدیریت مؤسسه آدان، اساتید اقتصاد کلان و مدیران ارشد بانکی','2026-11-26','۱۴۰۵/۰۹/۰۵','تالار بزرگ همایش‌های اتاق',250,94,35000000,1200000000,'sandbox_queued','open','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `exam_attempts`
--

DROP TABLE IF EXISTS `exam_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `exam_attempts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `exam_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `attempt_no` int(11) NOT NULL DEFAULT 1,
  `auto_score` decimal(5,2) DEFAULT 0.00,
  `descriptive_score` decimal(5,2) DEFAULT NULL,
  `descriptive_answer` text DEFAULT NULL,
  `status` enum('auto_graded','pending_descriptive_review','finalized') DEFAULT 'auto_graded',
  `submitted_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exam_attempts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `exam_attempts` WRITE;
/*!40000 ALTER TABLE `exam_attempts` DISABLE KEYS */;
INSERT INTO `exam_attempts` VALUES
(1,1,7,1,70.00,24.00,'در حمل کانتینری محموله چند روز پیش از بارگیری در CY تحویل خط کشتیرانی می‌شود؛ لذا در FCA ریسک از لحظه تحویل به حمل‌کننده منتقل می‌گردد.','finalized','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `exam_attempts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `exam_questions`
--

DROP TABLE IF EXISTS `exam_questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `exam_questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `exam_id` int(11) NOT NULL,
  `question_type` enum('mcq','descriptive') DEFAULT 'mcq',
  `question_text` text NOT NULL,
  `option_a` varchar(255) DEFAULT NULL,
  `option_b` varchar(255) DEFAULT NULL,
  `option_c` varchar(255) DEFAULT NULL,
  `option_d` varchar(255) DEFAULT NULL,
  `correct_option` char(1) DEFAULT NULL,
  `points` decimal(5,2) DEFAULT 25.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exam_questions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `exam_questions` WRITE;
/*!40000 ALTER TABLE `exam_questions` DISABLE KEYS */;
INSERT INTO `exam_questions` VALUES
(1,1,'mcq','طبق قواعد Incoterms 2020، در کدام قاعده فروشنده موظف به تهیه بیمه‌نامه باربری با حداکثر پوشش (کلوز A انستیتو بیمه لندن) به نفع خریدار است؟','CIF','CIP','CFR','DAP','B',35.00),
(2,1,'mcq','در قاعده FOB بندرعباس (Incoterms 2020)، نقطه دقیق انتقال ریسک خسارت کالا از فروشنده به خریدار کجاست؟','تحویل کالا در انبار کارخانه فروشنده','تحویل به حمل‌کننده در ترمینال خشکی','قرار گرفتن کالا روی عرشه کشتی تعیین‌شده در بندرعباس','تخلیه کالا در بندر مقصد خریدار','C',35.00),
(3,1,'descriptive','تفاوت کاربردی FOB و FCA را برای حمل کانتینری صادراتی در ۴ سطر تحلیل نمایید و بنویسید چرا مرجع بین‌المللی ICC FCA را توصیه می‌کند.',NULL,NULL,NULL,NULL,NULL,30.00);
/*!40000 ALTER TABLE `exam_questions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `exams`
--

DROP TABLE IF EXISTS `exams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `exams` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `duration_minutes` int(11) NOT NULL DEFAULT 20,
  `max_attempts` int(11) NOT NULL DEFAULT 2,
  `pass_score` decimal(5,2) NOT NULL DEFAULT 70.00,
  `is_active` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exams`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `exams` WRITE;
/*!40000 ALTER TABLE `exams` DISABLE KEYS */;
INSERT INTO `exams` VALUES
(1,1,'آزمون پایانی استاندارد دوره جامع مدیریت صادرات و اینکوترمز ۲۰۲۰',25,3,70.00,1);
/*!40000 ALTER TABLE `exams` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `executive_signoff_queue`
--

DROP TABLE IF EXISTS `executive_signoff_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `executive_signoff_queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `doc_ref_no` varchar(45) NOT NULL,
  `doc_category` varchar(120) NOT NULL,
  `subject_title` varchar(210) NOT NULL,
  `amount_or_impact` varchar(140) NOT NULL,
  `sign_status` varchar(50) NOT NULL DEFAULT 'pending',
  `signature_sha256` char(64) DEFAULT NULL,
  `signed_by_name` varchar(140) DEFAULT NULL,
  `signed_shamsi` varchar(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `doc_ref_no` (`doc_ref_no`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `executive_signoff_queue`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `executive_signoff_queue` WRITE;
/*!40000 ALTER TABLE `executive_signoff_queue` DISABLE KEYS */;
INSERT INTO `executive_signoff_queue` VALUES
(1,'EXEC-SIG-401','قرارداد کلان سازمانی B2B','الحاقیه قرارداد توانمندسازی صادراتی مجتمع فولاد زاگرس (۶۰ نفر-دوره)','۱,۴۸۰,۰۰۰,۰۰۰ ریال','pending',NULL,NULL,'۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(2,'EXEC-SIG-402','نامه رسمی کمیسیون صادرات','پیشنهاد اصلاح مهلت رفع تعهد ارزی صادرکنندگان ماشین‌آلات به وزیر صمت','اثر ملی — ۱۲۰ واحد صنعتی','pending',NULL,NULL,'۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(3,'EXEC-SIG-403','صدور دسته‌جمعی گواهی QR','تأیید نهایی ۲۴ فقره گواهی دوره جامع سامانه جامع تجارت NTSW','۲۴ گواهی رسمی دارای QR','signed','8f434346648f6b96df89dda901c5176b10a6d83961dd3c1ac88b59b2dc327aa4','دکتر کیارش رادمهر','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `executive_signoff_queue` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `executive_warroom_simulations`
--

DROP TABLE IF EXISTS `executive_warroom_simulations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `executive_warroom_simulations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sim_code` varchar(40) NOT NULL,
  `ceo_participant` varchar(140) NOT NULL,
  `shock_scenario` varchar(190) NOT NULL,
  `chosen_strategy` varchar(220) NOT NULL,
  `cashflow_runway_months` decimal(4,1) DEFAULT 9.5,
  `export_share_retention_pct` int(11) DEFAULT 88,
  `resilience_score` int(11) DEFAULT 90,
  `board_ai_critique` text NOT NULL,
  `simulated_shamsi` varchar(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `sim_code` (`sim_code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `executive_warroom_simulations`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `executive_warroom_simulations` WRITE;
/*!40000 ALTER TABLE `executive_warroom_simulations` DISABLE KEYS */;
INSERT INTO `executive_warroom_simulations` VALUES
(1,'WAR-1405-01','مهندس بهرام رادمهر (مدیرعامل فولاد زاگرس)','شوک جهش ۳۵٪ نرخ ارز نیمایی هم‌زمان با اعمال تعرفه کربن مرزی اروپا (EU CBAM)','پوشش ریسک با قرارداد سلف ارزی + تغییر سبد صادراتی ۴۰٪ به بازار تعرفه‌صفر اوراسیا + ممیزی فوری انرژی',11.4,92,94,'تصمیم درجه الف هیئت‌مدیره: تنوع‌بخشی جغرافیایی به اوراسیا ریسک تمرکز بازار اروپا را خنثی کرده و جریان نقدی شرکت را ۱۱.۴ ماه تضمین می‌کند.','۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59'),
(2,'WAR-1405-02','دکتر مریم کاویانی (مدیرعامل خشکبار زرین)','اختلال زنجیره سرد کشتیرانی و افزایش ۴۰٪ کرایه حمل دریایی کانتینری','تغییر ترم فروش از CIF به FCA پایانه + قرارداد حمل ریلی ترکیبی کریدور شمال-جنوب',9.2,87,89,'مدیریت هوشمند ریسک لجستیک: انتقال ریسک کرایه دریایی نوسانی از طریق ترم FCA حاشیه سود ناخالص دلاری را حفظ کرده است.','۱۴۰۵/۰۷/۲۹','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `executive_warroom_simulations` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `export_consortium_groups`
--

DROP TABLE IF EXISTS `export_consortium_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `export_consortium_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `consortium_code` varchar(40) NOT NULL,
  `consortium_title` varchar(200) NOT NULL,
  `target_market` varchar(100) NOT NULL,
  `hs_code_cluster` varchar(80) NOT NULL,
  `lead_producer_org` varchar(160) NOT NULL,
  `packaging_logistics_org` varchar(160) NOT NULL,
  `trading_house_org` varchar(160) NOT NULL,
  `synergy_score_pct` int(11) DEFAULT 92,
  `annual_target_usd` bigint(20) DEFAULT 1200000,
  `status` varchar(80) DEFAULT 'پیش‌نویس اساسنامه کنسرسیوم آماده امضا',
  `created_shamsi` varchar(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `consortium_code` (`consortium_code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `export_consortium_groups`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `export_consortium_groups` WRITE;
/*!40000 ALTER TABLE `export_consortium_groups` DISABLE KEYS */;
INSERT INTO `export_consortium_groups` VALUES
(1,'CNS-EAEU-01','کنسرسیوم صادراتی خشکبار و فرآورده‌های غذایی ممتاز به اتحادیه اوراسیا','روسیه و قزاقستان (تعرفه صفر EAEU)','HS 0802 / 2008 (پسته، کشمش و فرآورده)','کشت و صنعت زرین‌صادر استان','صنایع بسته‌بندی نفیس‌پک پارس','شرکت مدیریت صادرات (EMC) دروازه خزر',95,2400000,'تفاهم‌نامه سه‌جانبه آماده امضا در اتاق','۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59'),
(2,'CNS-GCC-02','کنسرسیوم مصالح ساختمانی، کاشی، سرامیک و کلینکر خلیج فارس','عمان، امارات و عراق','HS 6907 / 2523 (سرامیک پرسلان و سیمان)','مجتمع کاشی و سرامیک کویر','حمل‌ونقل بین‌المللی و کانتینری دریاپیما','هلدینگ بازرگانی بین‌الملل پارس‌تجارت',91,3100000,'در حال ثبت رسمی شخصیت حقوقی کنسرسیوم','۱۴۰۵/۰۷/۲۹','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `export_consortium_groups` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `factory_prescriptions`
--

DROP TABLE IF EXISTS `factory_prescriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `factory_prescriptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rx_code` varchar(40) NOT NULL,
  `factory_name` varchar(180) NOT NULL,
  `sector` varchar(100) NOT NULL,
  `prod_score` int(11) DEFAULT 70,
  `energy_cbam_score` int(11) DEFAULT 55,
  `export_fx_score` int(11) DEFAULT 62,
  `working_cap_score` int(11) DEFAULT 68,
  `b2b_brand_score` int(11) DEFAULT 58,
  `hr_skill_score` int(11) DEFAULT 64,
  `ai_digital_score` int(11) DEFAULT 50,
  `overall_health_idx` int(11) DEFAULT 61,
  `primary_bottleneck` varchar(220) NOT NULL,
  `roadmap_180d` text NOT NULL,
  `assigned_consultant` varchar(140) NOT NULL,
  `approved_subsidy_pct` int(11) DEFAULT 30,
  `created_shamsi` varchar(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `rx_code` (`rx_code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `factory_prescriptions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `factory_prescriptions` WRITE;
/*!40000 ALTER TABLE `factory_prescriptions` DISABLE KEYS */;
INSERT INTO `factory_prescriptions` VALUES
(1,'RX-IND-401','مجتمع فولاد و نورد زاگرس','فلزات اساسی و آلیاژی',84,42,71,76,65,70,58,67,'عدم انطباق گزارش ردپای کربن با مقررات مرزی اتحادیه اروپا (EU CBAM)','ماه ۱-۲: ممیزی انرژی و آموزش استاندارد Scope 1&2 | ماه ۳-۴: استقرار سامانه گزارش XML کربن | ماه ۵-۶: اخذ گواهی سبز صادراتی','دکتر فرهاد سلیمانی (مشاور ارشد انرژی و CBAM)',35,'۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59'),
(2,'RX-IND-402','کشت و صنعت پسته و زعفران زرین','کشاورزی و صنایع غذایی صادراتی',79,74,58,66,46,62,49,62,'ضعف شدید در بسته‌بندی خرده‌فروشی چندزبانه و کانال فروش مستقیم B2B (خام‌فروشی)','ماه ۱-۲: کارگاه طراحی بسته‌بندی استاندارد اروپا و خلیج فارس | ماه ۳-۴: راه‌اندازی شکار خریدار با AI و TradeMap | ماه ۵-۶: حضور در میز B2B مسقط و دبی','مهندس نازنین کاوه (مشاور برندینگ صادراتی)',40,'۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `factory_prescriptions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `form_submissions`
--

DROP TABLE IF EXISTS `form_submissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `form_submissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `form_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `payload_json` longtext NOT NULL,
  `submitted_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form_submissions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `form_submissions` WRITE;
/*!40000 ALTER TABLE `form_submissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `form_submissions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `gamification_quests`
--

DROP TABLE IF EXISTS `gamification_quests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `gamification_quests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quest_code` varchar(40) NOT NULL,
  `title` varchar(190) NOT NULL,
  `target_module_route` varchar(80) NOT NULL,
  `difficulty_tier` varchar(50) NOT NULL DEFAULT 'حرفه‌ای',
  `xp_reward` int(11) NOT NULL DEFAULT 250,
  `coin_reward` int(11) NOT NULL DEFAULT 120,
  `progress_pct` int(11) NOT NULL DEFAULT 80,
  `is_claimed` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `quest_code` (`quest_code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gamification_quests`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `gamification_quests` WRITE;
/*!40000 ALTER TABLE `gamification_quests` DISABLE KEYS */;
INSERT INTO `gamification_quests` VALUES
(1,'QST-UCP-01','شکارچی مغایرت اسنادی: کشف ۳ مغایرت بارنامه در آزمایشگاه UCP 600','trade-academy','حرفه‌ای',350,180,100,0,'2026-10-23 21:48:59'),
(2,'QST-STRK-02','قهرمان پیوستگی: ثبت ۷ روز مطالعه مستمر بدون وقفه در کلاس LMS','lms','متوسط',250,130,100,0,'2026-10-23 21:48:59'),
(3,'QST-CAT-03','تسلط تطبیقی: کسب توانمندی θ بالای +1.8 در آزمون هوشمند اینکوترمز','exams','پیشرفته',420,220,85,0,'2026-10-23 21:48:59'),
(4,'QST-CLN-04','مشارکت صنعتی: تکمیل خودارزیابی ۳۶۰ درجه کلینیک صادرات برای بنگاه','business-clinic','سازمانی B2B',500,260,100,0,'2026-10-23 21:48:59');
/*!40000 ALTER TABLE `gamification_quests` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `gamification_reward_store`
--

DROP TABLE IF EXISTS `gamification_reward_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `gamification_reward_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reward_code` varchar(40) NOT NULL,
  `reward_title` varchar(190) NOT NULL,
  `category_label` varchar(90) NOT NULL,
  `coin_cost` int(11) NOT NULL DEFAULT 800,
  `stock_remaining` int(11) NOT NULL DEFAULT 15,
  `redeemed_count` int(11) NOT NULL DEFAULT 3,
  `last_voucher_serial` varchar(80) DEFAULT 'VCH-GAM-1405-INIT',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `reward_code` (`reward_code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gamification_reward_store`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `gamification_reward_store` WRITE;
/*!40000 ALTER TABLE `gamification_reward_store` DISABLE KEYS */;
INSERT INTO `gamification_reward_store` VALUES
(1,'RWD-DISC-25','کد تخفیف ۲۵٪ ثبت‌نام دوره‌های تخصصی آکادمی تجارت بین‌الملل','مشوق آموزشی',650,24,9,'VCH-GAM-1405-4410','2026-10-23 21:48:59'),
(2,'RWD-MENTOR-1H','۱ جلسه مشاوره اختصاصی رایگان با مشاور ارشد گمرک/مالیات اتاق','کلینیک VIP',1100,10,5,'VCH-GAM-1405-7192','2026-10-23 21:48:59'),
(3,'RWD-SUMMIT-VIP','جایگاه ویژه (VIP Pass) همایش سالانه مدیران صادراتی استان','تشریفات اتاق',1450,8,4,'VCH-GAM-1405-8803','2026-10-23 21:48:59'),
(4,'RWD-B2B-DESK','اولویت رزرو میز مذاکره مستقیم B2B با هیئت‌های تجاری خارجی','دیپلماسی تجاری',2200,5,2,'VCH-GAM-1405-9315','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `gamification_reward_store` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `gamification_wallets`
--

DROP TABLE IF EXISTS `gamification_wallets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `gamification_wallets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `learner_name` varchar(150) NOT NULL,
  `org_name` varchar(160) NOT NULL,
  `xp_points` int(11) NOT NULL DEFAULT 1200,
  `chamber_coins` int(11) NOT NULL DEFAULT 450,
  `level_num` int(11) NOT NULL DEFAULT 4,
  `rank_title` varchar(120) NOT NULL DEFAULT 'کارشناس ارشد تجارت',
  `streak_days` int(11) NOT NULL DEFAULT 7,
  `badges_count` int(11) NOT NULL DEFAULT 4,
  `updated_shamsi` varchar(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gamification_wallets`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `gamification_wallets` WRITE;
/*!40000 ALTER TABLE `gamification_wallets` DISABLE KEYS */;
INSERT INTO `gamification_wallets` VALUES
(1,1,'دکتر کیارش رادمهر','مدیریت کل آموزش مؤسسه آموزشی آدان',5420,1950,9,'معمار ارشد زیست‌بوم تجارت',16,9,'۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(2,7,'مهندس مهرداد شریفی','مجتمع فولاد و ذوب‌آهن زاگرس',4890,1640,8,'سفیر طلایی صادرات استان',12,8,'۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(3,6,'سارا نیک‌نژاد','مجتمع فولاد و ذوب‌آهن زاگرس',4150,1280,7,'استراتژیست قراردادهای B2B',9,6,'۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(4,2,'مهندس پگاه کاظمی','پتروشیمی و پلیمر استان',3680,1090,6,'متخصص ارشد گمرک و لجستیک',8,5,'۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(5,4,'نیما فرهادی','صنایع غذایی و لبنی بهاران',2740,790,5,'تحلیلگر بازارهای صادراتی',5,4,'۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `gamification_wallets` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `grants_and_mous`
--

DROP TABLE IF EXISTS `grants_and_mous`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `grants_and_mous` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `record_category` enum('تفاهم‌نامه همکاری','یارانه آموزشی SME','حامی مالی همایش') DEFAULT 'یارانه آموزشی SME',
  `partner_organization` varchar(200) NOT NULL,
  `title` varchar(220) NOT NULL,
  `subsidy_percent` int(11) DEFAULT 50,
  `allocated_budget_rial` bigint(20) DEFAULT 500000000,
  `utilized_rial` bigint(20) DEFAULT 180000000,
  `expiry_shamsi` varchar(30) NOT NULL,
  `status` varchar(50) DEFAULT 'فعال و قابل تخصیص',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grants_and_mous`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `grants_and_mous` WRITE;
/*!40000 ALTER TABLE `grants_and_mous` DISABLE KEYS */;
INSERT INTO `grants_and_mous` VALUES
(1,'یارانه آموزشی SME','شرکت شهرک‌های صنعتی استان','طرح حمایت ۵۰ درصدی شهریه دوره‌های صادراتی ویژه واحدهای صنعتی کوچک مستقر در شهرک‌ها',50,1500000000,620000000,'۱۴۰۵/۱۲/۲۹','فعال و قابل تخصیص'),
(2,'تفاهم‌نامه همکاری','دانشگاه صنعتی استان','تفاهم‌نامه اجرای مشترک طرح پویش، کارآموزی هدفمند و پایان‌نامه‌های تقاضامحور صنعتی',40,800000000,290000000,'۱۴۰۶/۰۶/۳۱','فعال و قابل تخصیص');
/*!40000 ALTER TABLE `grants_and_mous` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `hr_records`
--

DROP TABLE IF EXISTS `hr_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `hr_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_user_id` int(11) NOT NULL,
  `record_type` enum('task','leave_request','periodic_eval','succession','payslip_note') NOT NULL,
  `title` varchar(200) NOT NULL,
  `details` varchar(400) DEFAULT NULL,
  `kpi_score` int(11) DEFAULT NULL,
  `status` enum('open','approved','rejected','done') DEFAULT 'open',
  `created_shamsi` varchar(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hr_records`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `hr_records` WRITE;
/*!40000 ALTER TABLE `hr_records` DISABLE KEYS */;
INSERT INTO `hr_records` VALUES
(1,2,'periodic_eval','ارزیابی عملکرد سه‌ماهه تابستان ۱۴۰۵ کارشناس مسئول آموزش','اجرای منظم ۱۴ دوره آموزشی با شاخص رضایت ۹۴.۲٪ و راه‌اندازی ثبت‌نام گروهی سازمانی',95,'approved','۱۴۰۵/۰۷/۱۰'),
(2,2,'leave_request','درخواست مرخصی روزانه - ۲ روز در نیمه دوم آبان ۱۴۰۵','هماهنگی جایگزینی جلسات با کارشناس اجرای کلاس انجام شده است',NULL,'open','۱۴۰۵/۰۷/۲۹'),
(3,2,'succession','برنامه جانشین‌پروری سمت معاون اجرایی مرکز آموزش','تکمیل ۸۵٪ شایستگی‌های رهبری آموزشی و مدیریت بودجه',85,'open','۱۴۰۵/۰۷/۱۵');
/*!40000 ALTER TABLE `hr_records` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `iam_custom_roles`
--

DROP TABLE IF EXISTS `iam_custom_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `iam_custom_roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_slug` varchar(60) NOT NULL,
  `role_title_fa` varchar(160) NOT NULL,
  `data_scope` varchar(40) NOT NULL DEFAULT 'global_province',
  `badge_color` varchar(20) NOT NULL DEFAULT 'info',
  `is_system_builtin` tinyint(1) NOT NULL DEFAULT 1,
  `description_note` varchar(240) NOT NULL DEFAULT '',
  `created_shamsi` varchar(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_slug` (`role_slug`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `iam_custom_roles`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `iam_custom_roles` WRITE;
/*!40000 ALTER TABLE `iam_custom_roles` DISABLE KEYS */;
INSERT INTO `iam_custom_roles` VALUES
(1,'super_admin','مدیرکل آموزش مؤسسه آموزشی آدان (دسترسی کامل کل سامانه)','global_province','gold',1,'دسترسی کامل به هر بخش‌های سامانه، توشیح اسناد، تنظیمات هسته و ماتریس امنیتی','۱۴۰۵/۰۱/۰۱','2026-10-23 21:48:59'),
(2,'training_expert','کارشناس مسئول برنامه‌ریزی و اجرای آموزش','global_province','success',1,'مدیریت دوره‌ها، تقویم آموزشی، حضور و غیاب، آزمون، گواهی QR و میز خدمت','۱۴۰۵/۰۱/۰۱','2026-10-23 21:48:59'),
(3,'finance_manager','مدیر امور مالی، خزانه‌داری و سامانه مؤدیان','global_province','info',1,'دفترکل ۴ سطحی، فاکتور رسمی، استرداد آیین‌نامه‌ای، حق‌التدریس ماده ۸۶ و خروجی سپیدار','۱۴۰۵/۰۱/۰۱','2026-10-23 21:48:59'),
(4,'crm_manager','مدیر بازاریابی، ارتباط با اعضا (CRM) و کاریابی','global_province','warning',1,'مدیریت قیف فروش B2B، قراردادهای سازمانی، کمپین‌ها، رویدادها و نمایشگاه کار','۱۴۰۵/۰۱/۰۱','2026-10-23 21:48:59'),
(5,'instructor','مدرس، مشاور صنعتی و ارزیاب رسمی آدان','own_records','info',1,'مدیریت کلاس آنلاین، تولید محتوا با AI، ثبت نمرات و حضور و غیاب و صدور توصیه‌نامه','۱۴۰۵/۰۱/۰۱','2026-10-23 21:48:59'),
(6,'org_rep','نماینده آموزش شرکت / کارخانه دانش‌پذیر آدان','organization_only','gold',1,'سهمیه قرارداد شرکت، معرفی کارکنان، انتشار آگهی استخدام و پایپ‌لاین ATS شرکت خود (بدون دسترسی به کمپین CRM)','۱۴۰۵/۰۱/۰۱','2026-10-23 21:48:59'),
(7,'learner','فراگیر، کارجو و بازرگان دانش‌پذیر آدان','own_records','success',1,'پرونده آموزشی، آزمون، گواهی QR، کارنامه، رزومه‌ساز رسمی، ارسال رزومه و تیکت پشتیبانی','۱۴۰۵/۰۱/۰۱','2026-10-23 21:48:59'),
(8,'exam_proctor_officer','بازرس قرنطینه آزمون و کنترل اصالت گواهی (نقش سفارشی)','branch_only','danger',0,'نظارت سلامت آزمون، استعلام گروهی QR و بررسی اعتراض به نمرات بدون دسترسی به اسناد مالی','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(9,'branch_director','رئیس اداره آموزش دفتر نمایندگی شهرستان (نقش سفارشی)','branch_only','info',0,'مدیریت ثبت‌نام، کلاس‌ها و گزارش عملکرد شعبه شهرستان مربوطه','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `iam_custom_roles` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `iam_role_permissions`
--

DROP TABLE IF EXISTS `iam_role_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `iam_role_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_slug` varchar(60) NOT NULL,
  `module_domain` varchar(80) NOT NULL,
  `module_label_fa` varchar(160) NOT NULL,
  `can_view` tinyint(1) NOT NULL DEFAULT 1,
  `can_create` tinyint(1) NOT NULL DEFAULT 0,
  `can_edit` tinyint(1) NOT NULL DEFAULT 0,
  `can_delete` tinyint(1) NOT NULL DEFAULT 0,
  `can_approve` tinyint(1) NOT NULL DEFAULT 0,
  `can_export` tinyint(1) NOT NULL DEFAULT 0,
  `updated_shamsi` varchar(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_role_domain` (`role_slug`,`module_domain`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `iam_role_permissions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `iam_role_permissions` WRITE;
/*!40000 ALTER TABLE `iam_role_permissions` DISABLE KEYS */;
INSERT INTO `iam_role_permissions` VALUES
(1,'super_admin','academic_tms_lms','مدیریت دوره‌ها، تقویم آموزشی، حضور و غیاب و کارنامه',1,1,1,1,1,1,'۱۴۰۵/۰۸/۰۱'),
(2,'super_admin','finance_tax_ledger','امور مالی، دفترکل ۴ سطحی، استرداد و سامانه مؤدیان',1,1,1,1,1,1,'۱۴۰۵/۰۸/۰۱'),
(3,'super_admin','exams_certificates_qr','بانک سؤالات، قرنطینه آزمون و صدور/ابطال گواهی QR',1,1,1,1,1,1,'۱۴۰۵/۰۸/۰۱'),
(4,'super_admin','crm_campaigns_contracts','CRM سازمانی، قراردادها و کمپین‌های بازاریابی',1,1,1,1,1,1,'۱۴۰۵/۰۸/۰۱'),
(5,'super_admin','career_ats_recruitment','کاریابی جامع، انتشار آگهی، پایپ‌لاین ATS و نامه پیشنهاد شغلی',1,1,1,1,1,1,'۱۴۰۵/۰۸/۰۱'),
(6,'super_admin','system_theme_iam_security','تنظیمات هسته ERP، تم و فونت، کاربران و ماتریس سطح دسترسی',1,1,1,1,1,1,'۱۴۰۵/۰۸/۰۱'),
(7,'training_expert','academic_tms_lms','مدیریت دوره‌ها، تقویم آموزشی، حضور و غیاب و کارنامه',1,1,1,0,1,1,'۱۴۰۵/۰۸/۰۱'),
(8,'training_expert','finance_tax_ledger','امور مالی، دفترکل ۴ سطحی، استرداد و سامانه مؤدیان',1,0,0,0,0,1,'۱۴۰۵/۰۸/۰۱'),
(9,'training_expert','exams_certificates_qr','بانک سؤالات، قرنطینه آزمون و صدور/ابطال گواهی QR',1,1,1,0,1,1,'۱۴۰۵/۰۸/۰۱'),
(10,'finance_manager','finance_tax_ledger','امور مالی، دفترکل ۴ سطحی، استرداد و سامانه مؤدیان',1,1,1,0,1,1,'۱۴۰۵/۰۸/۰۱'),
(11,'org_rep','crm_campaigns_contracts','CRM سازمانی، قراردادها و کمپین‌های بازاریابی',1,0,0,0,0,0,'۱۴۰۵/۰۸/۰۱'),
(12,'org_rep','career_ats_recruitment','کاریابی جامع، انتشار آگهی، پایپ‌لاین ATS و نامه پیشنهاد شغلی',0,0,0,0,0,0,'۱۴۰۵/۰۸/۰۱'),
(13,'learner','academic_tms_lms','مدیریت دوره‌ها، تقویم آموزشی، حضور و غیاب و کارنامه',1,1,0,0,0,1,'۱۴۰۵/۰۸/۰۱'),
(14,'learner','career_ats_recruitment','کاریابی جامع، انتشار آگهی، پایپ‌لاین ATS و نامه پیشنهاد شغلی',0,0,0,0,0,0,'۱۴۰۵/۰۸/۰۱');
/*!40000 ALTER TABLE `iam_role_permissions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `iam_user_overrides`
--

DROP TABLE IF EXISTS `iam_user_overrides`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `iam_user_overrides` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_fullname` varchar(150) NOT NULL,
  `route_or_perm` varchar(90) NOT NULL,
  `effect_type` varchar(15) NOT NULL DEFAULT 'allow',
  `reason_note` varchar(220) NOT NULL,
  `expires_shamsi` varchar(40) DEFAULT '۱۴۰۵/۱۲/۲۹',
  `granted_by` varchar(120) DEFAULT 'مدیرکل آموزش',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `iam_user_overrides`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `iam_user_overrides` WRITE;
/*!40000 ALTER TABLE `iam_user_overrides` DISABLE KEYS */;
INSERT INTO `iam_user_overrides` VALUES
(1,2,'سرکار خانم مهندس پگاه کاظمی (کارشناس آموزش)','national-interchange','deny','قفل موقت هیئت‌رئیسه: مسدودسازی تبادل برخط با سامانه‌های ملی تا پایان ممیزی امنیتی (نمونه استثنای Deny سطح کاربر)','۱۴۰۵/۰۹/۳۰','دکتر کیارش رادمهر','2026-10-23 21:48:59'),
(2,6,'نماینده آموزش فولاد زاگرس (org_rep)','marketing-intel','deny','قفل امنیتی مصوب اتاق: عدم دسترسی نماینده شرکت‌ها به کمپین‌های انبوه بازاریابی','دائمی','سیاست امنیتی هسته','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `iam_user_overrides` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `instructor_availability_endorsements`
--

DROP TABLE IF EXISTS `instructor_availability_endorsements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `instructor_availability_endorsements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `record_code` varchar(45) NOT NULL,
  `instructor_name` varchar(150) NOT NULL,
  `free_weekly_slots` varchar(190) NOT NULL,
  `endorsed_learner_name` varchar(150) NOT NULL,
  `endorsed_skill_badge` varchar(180) NOT NULL,
  `recommendation_note` varchar(240) NOT NULL,
  `created_shamsi` varchar(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `record_code` (`record_code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instructor_availability_endorsements`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `instructor_availability_endorsements` WRITE;
/*!40000 ALTER TABLE `instructor_availability_endorsements` DISABLE KEYS */;
INSERT INTO `instructor_availability_endorsements` VALUES
(1,'END-1405-301','دکتر فرهاد رستگار (مدرس ارشد تجارت بین‌الملل)','دوشنبه‌ها و چهارشنبه‌ها ۱۶ الی ۲۰','مهندس مهرداد شریفی','تأییدیه تخصصی استاد در بررسی اسناد UCP 600','تسلط کم‌نظیر در کشف مغایرت‌های بارنامه و کلوزهای بیمه‌ای در کارگاه عملی؛ کاملاً آماده سرپرستی واحد صادرات.','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `instructor_availability_endorsements` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `instructor_impact_scores`
--

DROP TABLE IF EXISTS `instructor_impact_scores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `instructor_impact_scores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `instructor_name` varchar(140) NOT NULL,
  `kirkpatrick_avg` decimal(3,2) DEFAULT 4.75,
  `exam_pass_rate_pct` int(11) DEFAULT 92,
  `repeat_retention_pct` int(11) DEFAULT 84,
  `sla_punctuality_pct` int(11) DEFAULT 96,
  `composite_impact_score` int(11) DEFAULT 91,
  `academic_tier_badge` varchar(80) NOT NULL,
  `suggested_hourly_rial` bigint(20) DEFAULT 6500000,
  `evaluated_shamsi` varchar(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instructor_impact_scores`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `instructor_impact_scores` WRITE;
/*!40000 ALTER TABLE `instructor_impact_scores` DISABLE KEYS */;
INSERT INTO `instructor_impact_scores` VALUES
(1,'دکتر کامران فرهمند',4.92,95,89,98,96,'استاد ممتاز الف-ویژه (رتبه ۱ مرجعیت)',8500000,'۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59'),
(2,'مهندس الهام شریفی',4.81,91,84,96,92,'استاد ممتاز الف (کارگاه‌های عملی NTSW)',7200000,'۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59'),
(3,'دکتر بهزاد نوری',4.68,88,79,94,88,'استاد ارشد الف (مالیات و مؤدیان)',6400000,'۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `instructor_impact_scores` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `instructor_payouts`
--

DROP TABLE IF EXISTS `instructor_payouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `instructor_payouts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `instructor_user_id` int(11) NOT NULL,
  `run_id` int(11) DEFAULT NULL,
  `hours_taught` int(11) NOT NULL DEFAULT 16,
  `gross_amount_rial` bigint(20) NOT NULL,
  `tax_deduction_rial` bigint(20) NOT NULL DEFAULT 0,
  `net_amount_rial` bigint(20) NOT NULL,
  `status` enum('draft','verified','approved_finance','paid') DEFAULT 'verified',
  `payment_ref` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instructor_payouts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `instructor_payouts` WRITE;
/*!40000 ALTER TABLE `instructor_payouts` DISABLE KEYS */;
INSERT INTO `instructor_payouts` VALUES
(1,5,4,12,180000000,18000000,162000000,'paid','PAY-1405-7781','2026-10-23 21:48:59'),
(2,5,1,24,360000000,36000000,324000000,'verified',NULL,'2026-10-23 21:48:59');
/*!40000 ALTER TABLE `instructor_payouts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `instructor_profiles`
--

DROP TABLE IF EXISTS `instructor_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `instructor_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `degree` varchar(120) DEFAULT 'دکتری تخصصی مدیریت بازرگانی',
  `specialties` varchar(350) NOT NULL,
  `teaching_years` int(11) DEFAULT 8,
  `hourly_rate_rial` bigint(20) DEFAULT 12000000,
  `avg_rating` decimal(3,2) DEFAULT 4.85,
  `qualification_status` enum('pending','committee_approved','conditional','suspended') DEFAULT 'committee_approved',
  `availability_slots` varchar(255) DEFAULT 'دوشنبه و چهارشنبه ۱۴ الی ۲۰ | پنجشنبه ۹ الی ۱۳',
  `portfolio_url` varchar(255) DEFAULT NULL,
  `bio` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instructor_profiles`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `instructor_profiles` WRITE;
/*!40000 ALTER TABLE `instructor_profiles` DISABLE KEYS */;
INSERT INTO `instructor_profiles` VALUES
(1,5,'دکتری مدیریت بازرگانی بین‌الملل - داور مؤسسه آموزشی آدان','اینکوترمز ۲۰۲۰، قراردادهای صادراتی، اعتبارات اسنادی، مذاکرات تجاری، CBAM',14,15000000,4.93,'committee_approved','یکشنبه و سه‌شنبه ۱۴-۲۰ | چهارشنبه ۱۵-۱۹','https://chamber-edu.ir/instructors/dr-nikzad','بیش از ۱۴۰ دوره تخصصی در مؤسسات آموزشی سراسر کشور و مشاور صادراتی ۲۵ واحد صنعتی نمونه.');
/*!40000 ALTER TABLE `instructor_profiles` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `internships`
--

DROP TABLE IF EXISTS `internships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `internships` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `program_title` varchar(200) NOT NULL,
  `host_org_id` int(11) NOT NULL,
  `intern_user_id` int(11) NOT NULL,
  `team_name` varchar(120) DEFAULT 'تیم توسعه صادرات الف',
  `milestone_stage` varchar(120) DEFAULT 'تحویل فاز دوم: تحلیل بازار هدف',
  `deliverable_file` varchar(255) DEFAULT NULL,
  `rubric_score_json` longtext DEFAULT NULL,
  `total_score` decimal(5,2) DEFAULT 88.50,
  `status` enum('applied','active','evaluated') DEFAULT 'active',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `internships`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `internships` WRITE;
/*!40000 ALTER TABLE `internships` DISABLE KEYS */;
INSERT INTO `internships` VALUES
(1,'طرح ملی پویش؛ تربیت دستیار صادرات در صنایع برتر استان',1,7,'تیم صادرات صنعتی زاگرس','تدوین پرونده بازاریابی ۵ خریدار در عمان و قزاقستان','zagros_oman_market_study.pdf','{\"تحلیل داده بازار\":24,\"تسلط بر قوانین گمرکی\":22,\"کیفیت مستندسازی تجاری\":22,\"کار تیمی و نظم حرفه‌ای\":21}',89.00,'active');
/*!40000 ALTER TABLE `internships` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `invoice_installments`
--

DROP TABLE IF EXISTS `invoice_installments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoice_installments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `installment_no` int(11) NOT NULL DEFAULT 1,
  `due_shamsi` varchar(30) NOT NULL,
  `amount_rial` bigint(20) NOT NULL,
  `status` enum('pending','paid','overdue') DEFAULT 'pending',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice_installments`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `invoice_installments` WRITE;
/*!40000 ALTER TABLE `invoice_installments` DISABLE KEYS */;
INSERT INTO `invoice_installments` VALUES
(1,2,1,'۱۴۰۵/۰۷/۲۵',29920000,'paid'),
(2,2,2,'۱۴۰۵/۰۸/۲۵',29920000,'pending');
/*!40000 ALTER TABLE `invoice_installments` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `invoices`
--

DROP TABLE IF EXISTS `invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(60) NOT NULL,
  `user_id` int(11) NOT NULL,
  `org_id` int(11) DEFAULT NULL,
  `item_description` varchar(255) NOT NULL,
  `subtotal_rial` bigint(20) NOT NULL,
  `discount_rial` bigint(20) DEFAULT 0,
  `vat_rial` bigint(20) DEFAULT 0,
  `total_rial` bigint(20) NOT NULL,
  `payment_mode` enum('cash_gateway_sim','installment','corporate_contract') DEFAULT 'cash_gateway_sim',
  `status` enum('unpaid','partial','paid','refund_requested','refunded') DEFAULT 'unpaid',
  `refund_reason` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `event_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoice_number` (`invoice_number`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoices`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `invoices` WRITE;
/*!40000 ALTER TABLE `invoices` DISABLE KEYS */;
INSERT INTO `invoices` VALUES
(1,'INV-1405-1001',6,1,'ثبت‌نام گروهی کارشناسان فولاد زاگرس - دوره جامع مدیریت صادرات (TRD-101)',204000000,51000000,15300000,168300000,'corporate_contract','paid',NULL,'2026-10-23 21:48:59',NULL),
(2,'INV-1405-1002',8,2,'ثبت‌نام انفرادی - دوره جامع مدیریت صادرات (TRD-101) به صورت اقساطی',68000000,13600000,5440000,59840000,'installment','partial',NULL,'2026-10-23 21:48:59',NULL);
/*!40000 ALTER TABLE `invoices` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `iran_messenger_dispatches`
--

DROP TABLE IF EXISTS `iran_messenger_dispatches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `iran_messenger_dispatches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `channel` enum('کاوه‌نگار SMS','ملی‌پیامک SMS','بازوی بله (Bale)','بازوی ایتا (Eitaa)') DEFAULT 'کاوه‌نگار SMS',
  `recipient_group` varchar(160) NOT NULL,
  `message_text` text NOT NULL,
  `delivery_mode` varchar(50) DEFAULT 'ثبت محلی - ارسال نشده',
  `sent_count` int(11) DEFAULT 0,
  `sent_shamsi` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `iran_messenger_dispatches`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `iran_messenger_dispatches` WRITE;
/*!40000 ALTER TABLE `iran_messenger_dispatches` DISABLE KEYS */;
INSERT INTO `iran_messenger_dispatches` VALUES
(1,'کاوه‌نگار SMS','فراگیران دوره اینکوترمز ۲۰۲۰','یادآوری جلسه سوم کارگاه عملی اینکوترمز — یکشنبه ساعت ۱۴ سالن خلیج فارس مؤسسه آموزشی آدان.','ثبت محلی - ارسال نشده',0,'۱۴۰۵/۰۷/۲۹'),
(2,'بازوی بله (Bale)','مدیران عامل عضو کمیسیون صادرات','فایل گزارش تحلیلی بخشنامه جدید ارزی و لینک ثبت‌نام همایش پاییزه مؤسسه آموزشی آدان ارسال شد.','ثبت محلی - ارسال نشده',0,'۱۴۰۵/۰۷/۳۰');
/*!40000 ALTER TABLE `iran_messenger_dispatches` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `iso_qa_records`
--

DROP TABLE IF EXISTS `iso_qa_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `iso_qa_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `standard_code` varchar(60) DEFAULT 'ISO 21001:2018',
  `clause_title` varchar(200) NOT NULL,
  `finding_type` enum('انطباق کامل','عدم انطباق جزئی','فرصت بهبود') DEFAULT 'انطباق کامل',
  `capa_action` text NOT NULL,
  `owner_unit` varchar(120) NOT NULL,
  `status` enum('باز','اقدام اصلاحی انجام شد','تأیید ممیز نهایی') DEFAULT 'تأیید ممیز نهایی',
  `audit_shamsi` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `iso_qa_records`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `iso_qa_records` WRITE;
/*!40000 ALTER TABLE `iso_qa_records` DISABLE KEYS */;
INSERT INTO `iso_qa_records` VALUES
(1,'ISO 21001:2018','بند ۸.۵ — کنترل کیفیت طراحی سرفصل و بازنگری سالانه محتوا','انطباق کامل','ثبت چرخه بازبینی کمیته علمی و تأیید انسانی تولیدات AI در سامانه','واحد برنامه‌ریزی آموزش','تأیید ممیز نهایی','۱۴۰۵/۰۷/۱۵'),
(2,'ISO 10015:2019','بند ۴.۴ — ارزیابی اثربخشی انتقال یادگیری ۳ ماه پس از دوره','فرصت بهبود','تکمیل فرم پیگیری سطح ۳ کرکپاتریک از مدیران مستقیم صنایع عضو','واحد ارزیابی و کیفیت','اقدام اصلاحی انجام شد','۱۴۰۵/۰۷/۲۰');
/*!40000 ALTER TABLE `iso_qa_records` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `job_board_listings`
--

DROP TABLE IF EXISTS `job_board_listings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_board_listings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `org_name` varchar(180) NOT NULL,
  `job_title` varchar(180) NOT NULL,
  `required_cert_code` varchar(80) NOT NULL,
  `city` varchar(80) DEFAULT 'مرکز استان',
  `salary_range` varchar(100) DEFAULT 'توافقی + بیمه تکمیلی',
  `matched_candidates` int(11) DEFAULT 3,
  `status` enum('فعال','در مرحله مصاحبه','جذب شد') DEFAULT 'فعال',
  `posted_shamsi` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_board_listings`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `job_board_listings` WRITE;
/*!40000 ALTER TABLE `job_board_listings` DISABLE KEYS */;
INSERT INTO `job_board_listings` VALUES
(1,'شرکت فولاد زاگرس پارس','کارشناس ارشد بازرگانی خارجی و سفارشات گمرکی','TRD-101 (گواهی معتبر اینکوترمز اتاق)','مرکز استان','۳۵ تا ۴۸ میلیون تومان + پاداش صادراتی',5,'در مرحله مصاحبه','۱۴۰۵/۰۷/۲۵'),
(2,'گروه صادراتی زعفران و پسته آریا','مسئول حسابداری مالیاتی و سامانه مؤدیان','FIN-202 (گواهی مالیاتی اتاق)','شهرک صنعتی شماره ۲','۲۸ تا ۳۶ میلیون تومان',4,'فعال','۱۴۰۵/۰۷/۲۹');
/*!40000 ALTER TABLE `job_board_listings` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `leadership_programs`
--

DROP TABLE IF EXISTS `leadership_programs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `leadership_programs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `cohort_name` varchar(100) DEFAULT 'دوره چهارم مدیران عامل استان',
  `participants_count` int(11) DEFAULT 24,
  `criteria_weights_json` longtext NOT NULL,
  `mentoring_assignment` varchar(350) NOT NULL,
  `avg_360_score` decimal(4,2) DEFAULT 4.45,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leadership_programs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `leadership_programs` WRITE;
/*!40000 ALTER TABLE `leadership_programs` DISABLE KEYS */;
INSERT INTO `leadership_programs` VALUES
(1,'آکادمی رهبران آینده صنعت و تجارت استان (Executive Mini-MBA)','نسل چهارم مدیران ارشد ۱۴۰۵',24,'{\"بازده اقتصادی و سودآوری\":35,\"مدیریت ریسک ارزی و زنجیره تأمین\":25,\"توسعه بازار صادراتی پایدار\":25,\"چابکی سازمانی و نگهداشت استعداد\":15}','تدوین برنامه تحول صادراتی ۹۰ روزه بنگاه اقتصادی با همراهی منتور منتور ارشد مؤسسه آموزشی آدان',4.52);
/*!40000 ALTER TABLE `leadership_programs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `learner_ai_telemetry`
--

DROP TABLE IF EXISTS `learner_ai_telemetry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `learner_ai_telemetry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `feature_key` varchar(60) NOT NULL,
  `ref_label` varchar(240) NOT NULL DEFAULT '',
  `score_value` int(11) NOT NULL DEFAULT 0,
  `detail_json` text DEFAULT NULL,
  `created_shamsi` varchar(40) NOT NULL DEFAULT '۱۴۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_lat_user` (`user_id`,`id`),
  KEY `idx_lat_feature` (`feature_key`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `learner_ai_telemetry`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `learner_ai_telemetry` WRITE;
/*!40000 ALTER TABLE `learner_ai_telemetry` DISABLE KEYS */;
/*!40000 ALTER TABLE `learner_ai_telemetry` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `learner_behavior_events`
--

DROP TABLE IF EXISTS `learner_behavior_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `learner_behavior_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT 1,
  `learner_name` varchar(150) NOT NULL,
  `module_route` varchar(80) NOT NULL,
  `action_verb` varchar(90) NOT NULL,
  `dwell_seconds` int(11) NOT NULL DEFAULT 180,
  `scroll_depth_pct` int(11) NOT NULL DEFAULT 85,
  `focus_index_pct` int(11) NOT NULL DEFAULT 92,
  `study_hour_band` varchar(50) DEFAULT '۱۹:۰۰ تا ۲۲:۰۰ (اوج تمرکز)',
  `xp_awarded` int(11) NOT NULL DEFAULT 25,
  `created_shamsi` varchar(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `learner_behavior_events`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `learner_behavior_events` WRITE;
/*!40000 ALTER TABLE `learner_behavior_events` DISABLE KEYS */;
INSERT INTO `learner_behavior_events` VALUES
(1,7,'مهندس مهرداد شریفی','lms','تکمیل بی‌وقفه ویدئوی اینکوترمز + یادداشت ثانیه‌ای',1640,98,96,'۲۰:۰۰ تا ۲۲:۰۰ (اوج تمرکز شبانه)',85,'۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(2,7,'مهندس مهرداد شریفی','trade-academy','شبیه‌سازی نردبان قیمت صادراتی EXW→DDP',920,94,93,'۱۰:۰۰ تا ۱۲:۰۰ (کارگاهی)',60,'۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(3,6,'سارا نیک‌نژاد (نماینده فولاد زاگرس)','exams','تصحیح آزمون تطبیقی CAT با θ=+2.3',1180,100,95,'۱۶:۰۰ تا ۱۸:۰۰ (عصرگاهی)',120,'۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(4,1,'دکتر کیارش رادمهر','digital-twin-bi','بررسی بولتن صوتی و جست‌وجوی مواد قانونی RAG',540,91,97,'۰۸:۰۰ تا ۱۰:۰۰ (مدیریتی صبحگاهی)',45,'۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `learner_behavior_events` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `learner_dropout_predictions`
--

DROP TABLE IF EXISTS `learner_dropout_predictions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `learner_dropout_predictions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `learner_name` varchar(150) NOT NULL,
  `org_name` varchar(160) NOT NULL,
  `enrolled_course` varchar(190) NOT NULL,
  `learning_persona` varchar(120) NOT NULL,
  `engagement_score` int(11) NOT NULL DEFAULT 72,
  `dropout_risk_pct` int(11) NOT NULL DEFAULT 24,
  `last_login_days_ago` int(11) NOT NULL DEFAULT 2,
  `ai_intervention_status` varchar(220) NOT NULL,
  `updated_shamsi` varchar(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `learner_dropout_predictions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `learner_dropout_predictions` WRITE;
/*!40000 ALTER TABLE `learner_dropout_predictions` DISABLE KEYS */;
INSERT INTO `learner_dropout_predictions` VALUES
(1,'کامران توکلی','صنایع غذایی و لبنی بهاران','جامع ثبت سفارش NTSW و اظهار گمرکی EPL','فراگیر پراکنده با خطر رهاسازی (At-Risk)',34,81,13,'هشدار قرمز: ۱۳ روز عدم ورود + توقف در دقیقه ۱۸ درس دوم — آماده ارسال مداخله انگیزشی','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(2,'نازنین فرهمند','نساجی زرین نخ کویر','سامانه مؤدیان و پایانه‌های فروشگاهی','فراگیر شب‌خوان فشرده (Crammer)',52,63,8,'هشدار زرد: افت تمرکز ویدئو به ۵۴٪ — پیشنهاد تبدیل درس بلند به ۳ میکروویدئوی ۶ دقیقه‌ای','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(3,'مهندس مهرداد شریفی','مجتمع فولاد و ذوب‌آهن زاگرس','آکادمی جامع تجارت بین‌الملل و UCP600','کاوشگر عمیق پروژه‌محور (Deep Mastery)',96,4,0,'وضعیت طلایی: پیوستگی ۱۲ روزه — واجد شرایط معرفی به عنوان منتور همتای کارگاه','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(4,'امیرحسین رضایی','پتروشیمی و پلیمر استان','قراردادهای تجاری بین‌المللی (کد ۶۵)','عمل‌گرای تعاملی (Interactive Solver)',88,9,1,'پایدار عالی: نرخ مشارکت بالا در شبیه‌سازها و بانک سؤالات','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `learner_dropout_predictions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `learner_personal_idp_steps`
--

DROP TABLE IF EXISTS `learner_personal_idp_steps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `learner_personal_idp_steps` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT 7,
  `learner_name` varchar(150) NOT NULL,
  `step_order` int(11) NOT NULL DEFAULT 1,
  `milestone_title` varchar(200) NOT NULL,
  `source_diagnostic` varchar(150) NOT NULL,
  `xp_bonus` int(11) NOT NULL DEFAULT 50,
  `is_done` tinyint(1) NOT NULL DEFAULT 0,
  `target_shamsi` varchar(40) DEFAULT '۱۴۰۵/۰۸/۱۵',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `learner_personal_idp_steps`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `learner_personal_idp_steps` WRITE;
/*!40000 ALTER TABLE `learner_personal_idp_steps` DISABLE KEYS */;
INSERT INTO `learner_personal_idp_steps` VALUES
(1,7,'مهندس مهرداد شریفی',1,'تکمیل شبیه‌ساز محاسبه حقوق ورودی گمرک در بخش تخصصی','خروجی آزمون استاندارد Incoterms Pro',50,1,'۱۴۰۵/۰۸/۰۳','2026-10-23 21:48:59'),
(2,7,'مهندس مهرداد شریفی',2,'مرور ۶ فلش‌کارت تقویتی کلوز A بیمه حمل کانتینری CIP','هم‌درس هوشمند کنار ویدئو (AI Co-Tutor)',65,0,'۱۴۰۵/۰۸/۰۷','2026-10-23 21:48:59'),
(3,7,'مهندس مهرداد شریفی',3,'ارسال گذرنامه مهارت OpenBadges برای موقعیت شغلی فولاد زاگرس','همرسان برداری بازارگاه اشتغال (تطابق ۹۶٪)',80,0,'۱۴۰۵/۰۸/۱۲','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `learner_personal_idp_steps` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `ledger_entries`
--

DROP TABLE IF EXISTS `ledger_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ledger_entries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entry_date` date NOT NULL,
  `entry_shamsi` varchar(30) NOT NULL,
  `account_head` varchar(140) NOT NULL,
  `entry_type` enum('revenue','expense','budget_alloc','refund') NOT NULL,
  `course_id` int(11) DEFAULT NULL,
  `debit_rial` bigint(20) DEFAULT 0,
  `credit_rial` bigint(20) DEFAULT 0,
  `description` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ledger_entries`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `ledger_entries` WRITE;
/*!40000 ALTER TABLE `ledger_entries` DISABLE KEYS */;
INSERT INTO `ledger_entries` VALUES
(1,'2026-10-01','۱۴۰۵/۰۷/۰۹','بودجه مصوب نیمسال دوم واحد آموزش','budget_alloc',NULL,0,5000000000,'ابلاغ بودجه مصوب هیئت رئیسه مؤسسه آموزشی آدان'),
(2,'2026-10-12','۱۴۰۵/۰۷/۲۰','درآمد شهریه دوره‌های آموزشی','revenue',1,0,980000000,'تحقق درآمد ثبت‌نام‌های سازمانی و آزاد دوره TRD-101'),
(3,'2026-10-15','۱۴۰۵/۰۷/۲۳','درآمد کارگاه سامانه مؤدیان','revenue',4,0,1360000000,'تسویه کامل ۳۸ فراگیر دوره TAX-110'),
(4,'2026-10-18','۱۴۰۵/۰۷/۲۶','هزینه حق‌التدریس و پذیرایی آموزشی','expense',4,245000000,0,'حق‌التدریس استاد، پکیج آموزشی و پذیرایی ۴ جلسه');
/*!40000 ALTER TABLE `ledger_entries` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `library_items`
--

DROP TABLE IF EXISTS `library_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `library_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(220) NOT NULL,
  `authors` varchar(180) NOT NULL,
  `category` varchar(100) DEFAULT 'گزارش بازار و تجارت خارجی',
  `license_type` varchar(100) DEFAULT 'دسترسی آزاد فراگیران آدان',
  `edition` varchar(40) DEFAULT 'ویرایش ۱۴۰۵',
  `course_id` int(11) DEFAULT NULL,
  `downloads_count` int(11) DEFAULT 42,
  `available_copies` int(11) DEFAULT 3,
  `abstract_text` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `library_items`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `library_items` WRITE;
/*!40000 ALTER TABLE `library_items` DISABLE KEYS */;
INSERT INTO `library_items` VALUES
(1,'راهنمای کاربردی مؤسسه آموزشی آدان برای انطباق با مکانیسم تعدیل کربن مرزی اروپا (CBAM)','معاونت بین‌الملل و واحد آموزش مؤسسه آموزشی آدان','گزارش راهبردی صادرات','دسترسی آزاد فراگیران آدان','ویرایش پاییز ۱۴۰۵',6,148,4,'این راهنما نحوه محاسبه انتشار کربن مستقیم و غیرمستقیم در صنایع فولاد، سیمان، آلومینیوم و کود شیمیایی و نحوه تنظیم گزارش فصلی برای خریداران اروپایی را تشریح می‌کند.'),
(2,'مرجع کامل قواعد Incoterms 2020 و چک‌لیست اسناد حمل و اعتبارات اسنادی UCP600','دکتر امیرحسین نیکزاد','کتاب آموزشی تخصصی','مجوز مطالعه اعضای پورتال','چاپ چهارم ۱۴۰۵',1,312,2,'بررسی تطبیقی قواعد یازده‌گانه تحویل کالا، نمونه کلوزهای قراردادی، بارنامه دریایی، راهنامه جاده‌ای CMR و مدیریت مغایرت اسناد بانکی.');
/*!40000 ALTER TABLE `library_items` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `library_loans`
--

DROP TABLE IF EXISTS `library_loans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `library_loans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `loan_shamsi` varchar(30) NOT NULL,
  `due_shamsi` varchar(30) NOT NULL,
  `returned_at` datetime DEFAULT NULL,
  `review_note` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `library_loans`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `library_loans` WRITE;
/*!40000 ALTER TABLE `library_loans` DISABLE KEYS */;
INSERT INTO `library_loans` VALUES
(1,2,7,'۱۴۰۵/۰۷/۲۰','۱۴۰۵/۰۸/۰۵',NULL,'منبع فوق‌العاده کاربردی برای تنظیم پیش‌فاکتورهای صادراتی.');
/*!40000 ALTER TABLE `library_loans` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `lms_adaptive_paths`
--

DROP TABLE IF EXISTS `lms_adaptive_paths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lms_adaptive_paths` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `learner_name` varchar(140) NOT NULL,
  `course_title` varchar(190) NOT NULL,
  `lesson_timestamp` varchar(30) DEFAULT '۱۲:۴۰',
  `learner_question` varchar(255) NOT NULL,
  `ai_timestamp_answer` text NOT NULL,
  `quiz_diagnostic_pct` int(11) DEFAULT 62,
  `injected_remedial_micro` varchar(220) NOT NULL,
  `spaced_repetition_cards` int(11) DEFAULT 5,
  `created_shamsi` varchar(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lms_adaptive_paths`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `lms_adaptive_paths` WRITE;
/*!40000 ALTER TABLE `lms_adaptive_paths` DISABLE KEYS */;
INSERT INTO `lms_adaptive_paths` VALUES
(1,'امیرحسین رضایی','جامع اینکوترمز ۲۰۲۰ و اعتبارات اسنادی','۱۴:۲۰','تفاوت دقیق انتقال ریسک در FOB و FCA برای حمل کانتینری چیست؟','در دقیقه ۱۴:۲۰ استاد توضیح می‌دهند که در حمل کانتینری نباید از FOB استفاده شود چون تحویل در ترمینال قبل از عرشه کشتی انجام می‌شود؛ لذا FCA (تحویل در پایانه کانتینری با بارنامه On-Board) ریسک آسیب در محوطه بندر را از دوش صادرکننده برمی‌دارد.',64,'میکروویدئوی تقویتی ۶ دقیقه‌ای: خطاهای رایج ترم FOB در کانتینر + ۵ فلش‌کارت مرور لایتنر',5,'۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59'),
(2,'نگین شریعتی','آموزش الزامی کارت بازرگانی و سامانه NTSW','۰۸:۵۵','مهلت قانونی ایفای تعهد ارزی صادراتی به چه صورت محاسبه می‌شود؟','مطابق بخشنامه بانک مرکزی که در دقیقه ۰۸:۵۵ تشریح شد، صادرکنندگان مکلف‌اند ظرف مهلت مقرر از تاریخ کوتاژ صادراتی نسبت به عرضه ارز در سامانه نیما/مرکز مبادله یا واردات در مقابل صادرات اقدام نمایند.',88,'تسلط کامل — بازگشایی مستقیم سناریوی پیشرفته اظهار EPL',4,'۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `lms_adaptive_paths` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `lms_ai_study_cards`
--

DROP TABLE IF EXISTS `lms_ai_study_cards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lms_ai_study_cards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) NOT NULL DEFAULT 1,
  `lesson_id` int(11) NOT NULL DEFAULT 1,
  `card_type` varchar(50) NOT NULL DEFAULT 'summary',
  `title` varchar(190) NOT NULL,
  `content_body` text NOT NULL,
  `mastery_tag` varchar(80) NOT NULL DEFAULT 'تسلط مفهومی و کاربردی',
  `created_by_name` varchar(120) NOT NULL DEFAULT 'دستیار هوشمند LMS',
  `created_shamsi` varchar(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lms_ai_study_cards`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `lms_ai_study_cards` WRITE;
/*!40000 ALTER TABLE `lms_ai_study_cards` DISABLE KEYS */;
INSERT INTO `lms_ai_study_cards` VALUES
(1,1,1,'summary','چکیده طلایی ۱ دقیقه‌ای تفاوت‌های کلیدی اینکوترمز ۲۰۲۰','• گروه E و F: کرایه حمل اصلی با خریدار است (EXW, FCA, FAS, FOB).\n• گروه C: کرایه حمل با فروشنده است ولی ریسک در مبدأ منتقل می‌شود (CFR, CIF, CPT, CIP).\n• گروه D: هم هزینه و هم ریسک تا نقطه مقصد بر عهده فروشنده است (DAP, DPU, DDP).','مرور سریع شب امتحان','معلم هوشمند LMS','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(2,1,1,'case_study','کیس عملی استان: خطای رایج صادرکننده کاشی و سرامیک در ترم FOB بندرعباس','یک واحد تولیدی محموله ۲۰ کانتینری خود را در ترمینال بندرعباس تحویل داد و پیش از بارگیری روی عرشه، یک کانتینر در محوطه آسیب دید. به دلیل درج FOB به جای FCA، خسارت ۴۸ هزار دلاری بر عهده فروشنده ماند!','پرونده واقعی صادراتی','معلم هوشمند LMS','۱۴۰۵/۰۸/۰۲','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `lms_ai_study_cards` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `lms_assignments`
--

DROP TABLE IF EXISTS `lms_assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lms_assignments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `submission_text` text DEFAULT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `grade` decimal(5,2) DEFAULT NULL,
  `feedback` varchar(400) DEFAULT NULL,
  `status` enum('submitted','graded','revision_needed') DEFAULT 'submitted',
  `submitted_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lms_assignments`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `lms_assignments` WRITE;
/*!40000 ALTER TABLE `lms_assignments` DISABLE KEYS */;
INSERT INTO `lms_assignments` VALUES
(1,1,7,'تدوین پیش‌نویس ماده شرایط تحویل و اسناد حمل برای صادرات ۵۰۰ تن میلگرد','ترم پیشنهادی: CFR Jebel Ali Port Incoterms 2020 به همراه سیاهه تجاری گواهی‌شده توسط مؤسسه آموزشی آدان و گواهی مبدأ.',NULL,95.00,'عالی و دقیق؛ صرفاً شماره نسخه Incoterms 2020 در متن انگلیسی قرارداد نیز صراحتاً قید شود.','graded','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `lms_assignments` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `lms_chapters`
--

DROP TABLE IF EXISTS `lms_chapters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lms_chapters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) NOT NULL,
  `sort_order` int(11) DEFAULT 1,
  `title` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lms_chapters`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `lms_chapters` WRITE;
/*!40000 ALTER TABLE `lms_chapters` DISABLE KEYS */;
INSERT INTO `lms_chapters` VALUES
(1,1,1,'فصل اول: مبانی حقوقی و ساختار قواعد یازده‌گانه Incoterms 2020'),
(2,1,2,'فصل دوم: اسناد حمل، بیمه‌نامه باربری و بسته تعاملی SCORM');
/*!40000 ALTER TABLE `lms_chapters` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `lms_discussions`
--

DROP TABLE IF EXISTS `lms_discussions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lms_discussions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) NOT NULL,
  `lesson_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `instructor_reply` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lms_discussions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `lms_discussions` WRITE;
/*!40000 ALTER TABLE `lms_discussions` DISABLE KEYS */;
INSERT INTO `lms_discussions` VALUES
(1,1,1,7,'استاد محترم، برای صادرات کانتینری به بندر هامبورگ آیا FOB مناسب‌تر است یا FCA؟','پاسخ دکتر نیکزاد: برای حمل کانتینری اکیداً طبق توصیه مرجع بین‌المللی ICC (ICC) از FCA به جای FOB استفاده کنید تا ریسک ترمینال کانتینری پیش از بارگیری روی کشتی پوشش داده شود.','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `lms_discussions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `lms_interactive_quizzes`
--

DROP TABLE IF EXISTS `lms_interactive_quizzes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lms_interactive_quizzes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lesson_id` int(11) NOT NULL DEFAULT 1,
  `appear_at_sec` int(11) NOT NULL DEFAULT 180,
  `timestamp_label` varchar(20) NOT NULL DEFAULT '03:00',
  `question_text` varchar(255) NOT NULL,
  `opt_a` varchar(190) NOT NULL,
  `opt_b` varchar(190) NOT NULL,
  `opt_c` varchar(190) NOT NULL,
  `opt_d` varchar(190) NOT NULL,
  `correct_opt` char(1) NOT NULL DEFAULT 'B',
  `ai_explanation` text DEFAULT NULL,
  `xp_reward` int(11) NOT NULL DEFAULT 50,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lms_interactive_quizzes`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `lms_interactive_quizzes` WRITE;
/*!40000 ALTER TABLE `lms_interactive_quizzes` DISABLE KEYS */;
INSERT INTO `lms_interactive_quizzes` VALUES
(1,1,145,'02:25','در قاعده CIP ویرایش ۲۰۲۰ اینکوترمز، فروشنده مکلف به تهیه چه سطح پوششی از بیمه باربری بین‌المللی است؟','حداقل پوشش کلوز C انستیتو لندن','حداکثر پوشش تمام‌خطر کلوز A انستیتو بیمه لندن','صرفاً بیمه آتش‌سوزی انبار مبدأ','فروشنده هیچ تعهد بیمه‌ای ندارد','B','در بازنگری ۲۰۲۰ مرجع بین‌المللی ICC (ICC)، سطح پوشش بیمه الزامی در ترم CIP به کلوز A (تمام‌خطر) ارتقا یافت، اما در CIF همچنان کلوز C باقی ماند.',60,'2026-10-23 21:48:59'),
(2,1,320,'05:20','در حمل کانتینری صادرات خشکبار از کارخانه داخل کشور، کدام ترم جایگزین حرفه‌ای و کم‌ریسک‌تر به جای FOB سنتی است؟','EXW بدون بارگیری','FCA (تحویل به حمل‌کننده در ترمینال کانتینری)','FAS کنار کشتی فله‌بر','DDP با ترخیص گمرک مقصد','B','طبق توصیه صریح ICC، برای محموله‌های کانتینری که پیش از عرشه کشتی به ترمینال تحویل داده می‌شوند، FCA ریسک خاکستری آسیب در محوطه بندری را حذف می‌کند.',60,'2026-10-23 21:48:59'),
(3,2,210,'03:30','حداکثر مهلت بانک گشایش‌کننده اعتبار اسنادی برای اعلام مغایرت اسناد طبق ماده ۱۴ مقررات UCP 600 چند روز است؟','۵ روز کاری بانکی پس از روز ارائه اسناد','۲۱ روز تقویمی از تاریخ بارنامه','۱۰ روز کاری پس از رسیدن کشتی','۴۸ ساعت از تاریخ صدور گواهی مبدأ','A','ماده ۱۴ بند ب UCP 600 صراحتاً سقف زمانی بررسی ظاهر اسناد توسط بانک را حداکثر ۵ روز بانکی متعاقب روز ارائه تعیین کرده است.',60,'2026-10-23 21:48:59');
/*!40000 ALTER TABLE `lms_interactive_quizzes` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `lms_learner_notes`
--

DROP TABLE IF EXISTS `lms_learner_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lms_learner_notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `lesson_id` int(11) NOT NULL,
  `video_timestamp` varchar(16) DEFAULT '00:00',
  `note_body` text NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lms_learner_notes`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `lms_learner_notes` WRITE;
/*!40000 ALTER TABLE `lms_learner_notes` DISABLE KEYS */;
INSERT INTO `lms_learner_notes` VALUES
(1,7,1,'07:12','در اینکوترمز ۲۰۲۰، با CIF هزینه و ریسک حمل تا بندر مقصد با فروشنده است، اما بیمه فقط حداقل پوشش (Institute Cargo Clauses C) است؛ برای کالای حساس باید پوشش All Risks را جداگانه درخواست کنم.','2026-10-23 21:48:59'),
(2,7,1,'18:40','نکته آزمون: در EXW انتقال ریسک در محل فروشنده اتفاق می‌افتد، پس ترخیص خروجی هم با خریدار است — این قلاب پرتکرار را در سؤالات تطبیق فراموش نکنم.','2026-10-23 21:48:59'),
(3,7,2,'05:25','مبنای حق‌الوکاله کارگزاری: درصدی از ارزش CIF به‌همراه هزینه‌های جانبی؛ در پرونده قبلی هزینه انبارش را جدا محاسبه کردند، باید آن را در چک‌لیست مذاکره بیاورم.','2026-10-23 21:48:59'),
(4,7,3,'11:05','در اعتبار اسنادی، تطابق اسناد حداکثر پنج روز کاری بررسی می‌شود؛ تاریخ سررسید سند را در تقویم شمسی ثبت می‌کنم تا پشت‌افتادگی پیدا نشود.','2026-10-23 21:48:59'),
(5,8,2,'03:50','خلاصه شخصی من: در FOB، هزینه بارگیری و ریسک تا روی عرشه با فروشنده است و بیمه دریایی از همان لحظه به خریدار منتقل می‌شود.','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `lms_learner_notes` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `lms_lessons`
--

DROP TABLE IF EXISTS `lms_lessons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lms_lessons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `chapter_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `sort_order` int(11) DEFAULT 1,
  `title` varchar(220) NOT NULL,
  `content_type` enum('video','audio','pdf','scorm','article') DEFAULT 'video',
  `estimated_minutes` int(11) DEFAULT 25,
  `sequential_lock` tinyint(1) DEFAULT 1,
  `media_url` varchar(300) DEFAULT NULL,
  `scorm_manifest_path` varchar(300) DEFAULT NULL,
  `scorm_version` varchar(40) DEFAULT NULL,
  `body_html` longtext DEFAULT NULL,
  `attachment_name` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lms_lessons`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `lms_lessons` WRITE;
/*!40000 ALTER TABLE `lms_lessons` DISABLE KEYS */;
INSERT INTO `lms_lessons` VALUES
(1,1,1,1,'درس ۱: تفاوت کلیدی انتقال ریسک (Risk) و انتقال هزینه (Cost)','video',30,0,'https://chamber-cdn.local/videos/incoterms-intro.mp4',NULL,NULL,'<p>در قراردادهای صادراتی مؤسسه آموزشی آدان، رایج‌ترین خطای بازرگانان اشتباه گرفتن نقطه پایان هزینه با نقطه انتقال ریسک در قواعد گروه C مانند <strong>CFR</strong> و <strong>CIF</strong> است. در این قواعد ریسک به محض بارگیری روی عرشه کشتی در بندر مبدأ به خریدار منتقل می‌شود اما فروشنده کرایه حمل تا بندر مقصد را می‌پردازد.</p>',NULL),
(2,1,1,2,'درس ۲: راهنمای جامع انتخاب EXW، FCA، FOB و CIF (جزوه PDF)','pdf',25,1,'storage/docs/incoterms2020_chart.pdf',NULL,NULL,'<p>جدول مقایسه‌ای تعهدات ده‌گانه فروشنده (A1-A10) و خریدار (B1-B10) همراه با چک‌لیست ترخیص صادراتی گمرکات کشور.</p>',NULL),
(3,2,1,3,'درس ۳: شبیه‌ساز تعاملی بررسی مغایرت اسناد حمل (بسته SCORM)','scorm',40,1,NULL,'storage/uploads/scorm/demo_ucp600/imsmanifest.xml','SCORM 1.2 (Manifest Verified)','<p>بسته استاندارد SCORM بارگذاری و مانیفست آن استخراج شده است. توجه: ردیابی کامل Runtime استاندارد CMI در محیط عملیاتی منوط به تأیید نهایی پلیر SCORM است.</p>',NULL);
/*!40000 ALTER TABLE `lms_lessons` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `lms_progress`
--

DROP TABLE IF EXISTS `lms_progress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lms_progress` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `lesson_id` int(11) NOT NULL,
  `is_completed` tinyint(1) DEFAULT 0,
  `spent_minutes` int(11) DEFAULT 0,
  `completed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_user_lesson` (`user_id`,`lesson_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lms_progress`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `lms_progress` WRITE;
/*!40000 ALTER TABLE `lms_progress` DISABLE KEYS */;
INSERT INTO `lms_progress` VALUES
(1,7,1,1,32,'2026-10-23 21:48:59'),
(2,7,2,1,27,'2026-10-23 21:48:59'),
(3,8,1,1,29,'2026-10-23 21:48:59');
/*!40000 ALTER TABLE `lms_progress` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `login_attempts`
--

DROP TABLE IF EXISTS `login_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `login_attempts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `identifier` varchar(190) NOT NULL,
  `ip_address` varchar(64) NOT NULL,
  `attempted_at` datetime DEFAULT current_timestamp(),
  `is_success` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_login_ident` (`identifier`,`attempted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_attempts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `login_attempts` WRITE;
/*!40000 ALTER TABLE `login_attempts` DISABLE KEYS */;
/*!40000 ALTER TABLE `login_attempts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `market_intel`
--

DROP TABLE IF EXISTS `market_intel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `market_intel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `region` enum('ایران','اتحادیه اروپا','خلیج فارس و اوراسیا') DEFAULT 'اتحادیه اروپا',
  `competitor_or_source` varchar(200) NOT NULL,
  `source_url` varchar(255) NOT NULL,
  `trend_topic` varchar(220) NOT NULL,
  `ai_gap_summary` text NOT NULL,
  `last_checked_shamsi` varchar(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `market_intel`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `market_intel` WRITE;
/*!40000 ALTER TABLE `market_intel` DISABLE KEYS */;
INSERT INTO `market_intel` VALUES
(1,'اتحادیه اروپا','ICC Academy & European Chambers (Eurochambres)','https://iccwbo.org/academy','گزارش‌دهی الزامی کربن مرزی (CBAM) و زنجیره تأمین پایدار سبز ۲۰۲۶','پیشنهاد AI: مؤسسات آموزشی اروپا دوره‌های عملی محاسبه کربن فولاد، سیمان و آلومینیوم را الزامی کرده‌اند؛ اجرای فوری دوره TRD-309 مزیت رقابتی ممتاز در کشور ایجاد می‌کند.','۱۴۰۵/۰۷/۳۰'),
(2,'ایران','پایش مراکز آموزشی بازرگانی و صنعتی کشور','https://chamber-intel.local/iran-trends-1405','افزایش ۱۸۰ درصدی تقاضای کارگاه‌های عملی هوش مصنوعی در مکاتبات تجاری و تهاتر ارزی','پیشنهاد AI: ترکیب دوره آنلاین همزمان با کلینیک مشاوره اختصاصی پس از دوره، نرخ ثبت‌نام سازمانی را تا ۴۰٪ افزایش می‌دهد.','۱۴۰۵/۰۷/۲۹');
/*!40000 ALTER TABLE `market_intel` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `market_surveys_insights`
--

DROP TABLE IF EXISTS `market_surveys_insights`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `market_surveys_insights` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `insight_code` varchar(50) NOT NULL,
  `research_title` varchar(190) NOT NULL,
  `industry_segment` varchar(120) NOT NULL DEFAULT 'صنایع غذایی، فولاد و بازرگانی خارجی',
  `social_source` varchar(90) NOT NULL DEFAULT 'لینکدین + تلگرام + نظرسنجی بنگاه‌ها',
  `sample_size_orgs` int(11) NOT NULL DEFAULT 84,
  `demand_urgency_pct` int(11) NOT NULL DEFAULT 91,
  `positive_sentiment_pct` int(11) NOT NULL DEFAULT 84,
  `willingness_to_pay_rial` bigint(20) NOT NULL DEFAULT 52000000,
  `tam_provincial_rial` bigint(20) NOT NULL DEFAULT 48000000000,
  `sam_reachable_rial` bigint(20) NOT NULL DEFAULT 14500000000,
  `som_target_rial` bigint(20) NOT NULL DEFAULT 4200000000,
  `key_pain_point` text NOT NULL,
  `ai_gtm_strategy` text NOT NULL,
  `launched_to_tms` tinyint(1) NOT NULL DEFAULT 0,
  `created_shamsi` varchar(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `insight_code` (`insight_code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `market_surveys_insights`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `market_surveys_insights` WRITE;
/*!40000 ALTER TABLE `market_surveys_insights` DISABLE KEYS */;
INSERT INTO `market_surveys_insights` VALUES
(1,'MRK-INS-01','نیازسنجی میدانی و شنود شبکه‌های اجتماعی درباره «هوش مصنوعی در صادرات و تحلیل گمرکی»','صادرکنندگان مواد غذایی، کاشی، پلیمر و خشکبار','لینکدین (۴۲٪) + تلگرام تخصصی (۳۵٪) + پرسشنامه اعضا (۲۳٪)',112,94,88,54000000,62000000000,19500000000,5800000000,'عدم آشنایی تیم‌های فروش خارجی کارخانجات با ابزارهای هوش مصنوعی شناسایی خریدار، مکاتبه چندزبانه و تحلیل داده‌های گمرکی رقبا.','اجرای کارگاه عملی ۲۴ ساعته با لپ‌تاپ در مؤسسه آموزشی آدان + کمپین ویدئویی Reels اینستاگرام و مقاله تخصصی لینکدین برای مدیران بازرگانی.',0,'۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(2,'MRK-INS-02','پیمایش حساسیت قیمتی و تقاضای بنگاه‌ها برای «مدیریت جریان نقدینگی و تأمین مالی زنجیره تأمین (SCF)»','واحدهای تولیدی شهرک‌های صنعتی استان','لینکدین مدیران مالی + کانال تلگرام + مصاحبه عمیق',86,89,82,62000000,54000000000,16800000000,4900000000,'فشار سرمایه در گردش و عدم بهره‌گیری از ابزارهای نوین برات الکترونیکی، اوراق گام و تأمین مالی زنجیره‌ای بانک‌ها.','طراحی سمینار مدیریتی ۱ روزه ویژه مدیران‌عامل + کارگاه عملی ۲ روزه مدیران مالی با تبلیغ مستقیم در لینکدین و پیامک VIP اعضا.',0,'۱۴۰۵/۰۸/۰۲','2026-10-23 21:48:59'),
(3,'MRK-INS-03','تحلیل شکاف مهارتی تجارت با اوراسیا، روسیه و تسویه ارزی برون‌مرزی جدید','بازرگانان کالاهای کشاورزی، صنعتی و لجستیک','کانال‌های تلگرامی صادرات + اینستاگرام + کمیسیون تجارت',95,91,86,58000000,49000000000,15200000000,4400000000,'اجرایی‌شدن موافقت‌نامه تجارت آزاد ایران و اوراسیا (صفر شدن تعرفه ۸۷٪ کالاها) ولی ضعف شدید صادرکنندگان در قرارداد و لجستیک مسیر شمال.','پرتاب فوری دوره کاربردی تجارت آزاد اوراسیا هم‌زمان با کمپین مشترک تلگرام، لینکدین و ایتا برای اعضای دارای کارت بازرگانی فعال.',0,'۱۴۰۵/۰۸/۰۳','2026-10-23 21:48:59'),
(4,'MRK-INS-04','پژوهش تقاضاسنجی بازاریابی دیجیتال صنعتی و تولید محتوای صادراتی در لینکدین و اینستاگرام','واحدهای صنعتی، معدنی و دانش‌بنیان صادرات‌محور','شنود اینستاگرام بیزینس + لینکدین + پنل فراگیران آدان',104,93,90,51000000,57000000000,18400000000,5300000000,'ضعف شدید برندینگ دیجیتال کارخانجات ایرانی در لینکدین و یوتیوب برای جذب خریداران عمده منطقه‌ای در خلیج فارس و عراق.','برگزاری بوت‌کمپ کمپین‌سازی بین‌المللی شبکه‌های اجتماعی B2B همراه با کلینیک عملی ساخت پیج و قیف جذب سرنخ صادراتی.',0,'۱۴۰۵/۰۸/۰۴','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `market_surveys_insights` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `marketing_campaigns`
--

DROP TABLE IF EXISTS `marketing_campaigns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `marketing_campaigns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `segment_name` varchar(140) NOT NULL,
  `channel` enum('sms_sandbox','email_sandbox','telegram_sandbox') DEFAULT 'sms_sandbox',
  `variant_a_text` varchar(400) NOT NULL,
  `variant_b_text` varchar(400) NOT NULL,
  `human_approved` tinyint(1) DEFAULT 0,
  `scheduled_shamsi` varchar(40) DEFAULT '۱۴۰۵/۰۸/۰۳ ساعت ۱۰:۰۰',
  `conversion_a_pct` decimal(4,1) DEFAULT NULL,
  `conversion_b_pct` decimal(4,1) DEFAULT NULL,
  `status` enum('draft','awaiting_approval','scheduled','sent_simulated') DEFAULT 'awaiting_approval',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marketing_campaigns`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `marketing_campaigns` WRITE;
/*!40000 ALTER TABLE `marketing_campaigns` DISABLE KEYS */;
INSERT INTO `marketing_campaigns` VALUES
(1,'کمپین معرفی کارگاه رفع تعهد ارزی صادرکنندگان','صادرکنندگان دارای کارت بازرگانی فعال (رضایت‌نامه تأییدشده)','sms_sandbox','نسخه A: صادرکننده گرامی، ظرفیت کارگاه تخصصی رفع تعهد ارزی مؤسسه آموزشی آدان رو به تکمیل است. ثبت‌نام با ۲۰٪ تخفیف اعضا.','نسخه B: با تسلط بر ضوابط جدید ارزی ۱۴۰۵ از جرائم مالیاتی پیشگیری کنید؛ کارگاه کاربردی مؤسسه آموزشی آدان با تدریس دکتر نیکزاد.',1,'۱۴۰۵/۰۸/۰۲ ساعت ۱۰:۰۰',13.8,21.4,'scheduled'),
(2,'کمپین معرفی دوره هوش مصنوعی در صادرات','مدیران بازرگانی خارجی شرکت‌های صنعتی','email_sandbox','نسخه A: دوره کاربردی هوش مصنوعی در بازاریابی بین‌الملل در مؤسسه آموزشی آدان.','نسخه B: چگونه با هوش مصنوعی در ۳۰ دقیقه خریداران واقعی کد تعرفه HS محصول خود را بیابید؟',0,'۱۴۰۵/۰۸/۰۸ ساعت ۰۹:۳۰',0.0,0.0,'awaiting_approval');
/*!40000 ALTER TABLE `marketing_campaigns` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `micro_capsule_progress`
--

DROP TABLE IF EXISTS `micro_capsule_progress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `micro_capsule_progress` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `capsule_id` int(11) NOT NULL,
  `selected_opt` char(1) NOT NULL,
  `is_mastered` tinyint(1) NOT NULL DEFAULT 1,
  `xp_earned` int(11) NOT NULL DEFAULT 35,
  `completed_shamsi` varchar(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `micro_capsule_progress`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `micro_capsule_progress` WRITE;
/*!40000 ALTER TABLE `micro_capsule_progress` DISABLE KEYS */;
/*!40000 ALTER TABLE `micro_capsule_progress` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `micro_daily_challenges`
--

DROP TABLE IF EXISTS `micro_daily_challenges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `micro_daily_challenges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `challenge_code` varchar(45) NOT NULL,
  `scenario_title` varchar(195) NOT NULL,
  `scenario_case` text NOT NULL,
  `option_1` varchar(170) NOT NULL,
  `option_2` varchar(170) NOT NULL,
  `option_3` varchar(170) NOT NULL,
  `correct_choice` int(11) NOT NULL DEFAULT 2,
  `explanation_key` text NOT NULL,
  `bonus_xp` int(11) NOT NULL DEFAULT 50,
  `participants_today` int(11) NOT NULL DEFAULT 68,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `challenge_code` (`challenge_code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `micro_daily_challenges`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `micro_daily_challenges` WRITE;
/*!40000 ALTER TABLE `micro_daily_challenges` DISABLE KEYS */;
INSERT INTO `micro_daily_challenges` VALUES
(1,'DCH-1405-0801','چالش ۶۰ ثانیه‌ای امروز مدیران: مغایرت تاریخ بارنامه در اعتبار اسنادی!','خریدار خارجی برای شما L/C گشایش کرده که آخرین مهلت حمل آن ۳۰ مهر است. کشتی در تاریخ ۲۹ مهر بارگیری شده اما تاریخ صدور بارنامه ۲ آبان درج گردیده و یادداشت On-Board مورخ ۲۹ مهر روی آن ممهور شده است. آیا اسناد دارای مغایرت (Discrepancy) است؟','بله، تاریخ صدور بارنامه ملاک است و بانک اسناد را رد می‌کند.','خیر! طبق ماده ۲۰ UCP 600، تاریخ درج‌شده در یادداشت ممهور On-Board (۲۹ مهر) تاریخ واقعی حمل تلقی می‌شود و کاملاً معتبر است.','بارنامه باید به کلی باطل و قرارداد فسخ شود.',2,'✅ آفرین! طبق بند a ماده ۲۰ مقررات UCP 600، هنگامی که بارنامه حاوی یادداشت تاریخ‌دار On-Board باشد، همان تاریخ بارگیری ملاک تاریخ حمل است نه تاریخ صدور سند.',50,84,'2026-10-23 21:48:59');
/*!40000 ALTER TABLE `micro_daily_challenges` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `micro_job_aids`
--

DROP TABLE IF EXISTS `micro_job_aids`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `micro_job_aids` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `aid_code` varchar(45) NOT NULL,
  `aid_title` varchar(185) NOT NULL,
  `target_desk` varchar(95) NOT NULL,
  `format_type` varchar(55) NOT NULL DEFAULT 'چک‌لیست رومیزی ۱ صفحه‌ای',
  `key_steps_summary` text NOT NULL,
  `audio_script_summary` text NOT NULL,
  `downloads_count` int(11) NOT NULL DEFAULT 115,
  `created_shamsi` varchar(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `aid_code` (`aid_code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `micro_job_aids`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `micro_job_aids` WRITE;
/*!40000 ALTER TABLE `micro_job_aids` DISABLE KEYS */;
INSERT INTO `micro_job_aids` VALUES
(1,'AID-EXP-01','چک‌لیست ۷ گامی کنترل اسناد حمل پیش از تحویل به بانک ارزی','میز کارشناس بازرگانی خارجی','تقلب‌نامه ۱ صفحه‌ای PDF/Print','۱. تطبیق دقیق نگارش نام خریدار | ۲. کنترل مهلت ارائه ۲۱ روزه | ۳. مهر On-Board بارنامه | ۴. پوشش ۱۱۰٪ بیمه کلوز A | ۵. گواهی مبدأ صادره از مرجع مجاز | ۶. امضای سیاهه تجاری | ۷. تطبیق وزن ناخالص در همه اسناد.','پادکست ۱۸۰ ثانیه‌ای: قبل از ارسال مدارک به بانک عامل، این هفت مورد حیاتی را در سه دقیقه کنترل کنید تا حتی یک دلار کارمزد مغایرت اسنادی نپردازید.',214,'۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(2,'AID-FIN-02','جدول سریع مهلت‌ها و جرایم بخشش‌پذیر سامانه مؤدیان و ماده ۱۶۹','میز حسابدار ارشد و مدیر مالی','اینفوگرافیک رومیزی مدیریتی','کنترل تطبیق شناسه کالا/خدمت ۱۳ رقمی، تفکیک فروش نقدی و نسیه، ثبت صورت‌حساب اصلاحی/ابطالی و استرداد مالیات صادرات.','پادکست ۱۵۰ ثانیه‌ای: خلاصه اجرایی ضوابط ثبت صورت‌حساب اصلاحی و برگشت از فروش در کارپوشه مالیاتی شرکت‌های تولیدی.',179,'۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `micro_job_aids` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `micro_learning_capsules`
--

DROP TABLE IF EXISTS `micro_learning_capsules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `micro_learning_capsules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `capsule_code` varchar(45) NOT NULL,
  `title` varchar(190) NOT NULL,
  `topic_domain` varchar(80) NOT NULL,
  `duration_seconds` int(11) NOT NULL DEFAULT 180,
  `difficulty_tag` varchar(40) NOT NULL DEFAULT 'کاربردی مدیران',
  `slide_1_hook` text NOT NULL,
  `slide_2_rule` text NOT NULL,
  `slide_3_example` text NOT NULL,
  `quiz_question` varchar(240) NOT NULL,
  `quiz_opt_a` varchar(160) NOT NULL,
  `quiz_opt_b` varchar(160) NOT NULL,
  `quiz_opt_c` varchar(160) NOT NULL,
  `correct_opt` char(1) NOT NULL DEFAULT 'B',
  `xp_reward` int(11) NOT NULL DEFAULT 35,
  `completions_count` int(11) NOT NULL DEFAULT 42,
  `created_shamsi` varchar(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `capsule_code` (`capsule_code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `micro_learning_capsules`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `micro_learning_capsules` WRITE;
/*!40000 ALTER TABLE `micro_learning_capsules` DISABLE KEYS */;
INSERT INTO `micro_learning_capsules` VALUES
(1,'MIC-INC-01','تفاوت حیاتی FCA و FOB در حمل کانتینری (Incoterms 2020)','تجارت بین‌الملل',180,'ویژه مدیران صادرات','⚠️ خطای میلیون‌دلاری رایج: استفاده از قاعده FOB برای کالاهای کانتینری باعث می‌شود فروشنده تا لحظه عبور کانتینر از نرده کشتی مسئول خسارات محوطه کانتینری (CY) بماند، در حالی که کنترلی بر اپراتور بندر ندارد!','✅ قاعده طلایی مرجع بین‌المللی ICC (ICC): برای هرگونه حمل کانتینری به جای FOB از FCA (تحویل در ترمینال کانتینری) استفاده کنید؛ طبق تبصره جدید ۲۰۲۰ خریدار می‌تواند به حمل‌کننده دستور صدور بارنامه On-Board بدهد.','📦 مثال واقعی کارخانه کاشی استان: تحویل ۲۰ کانتینر در ترمینال بندرعباس با قاعده FCA ریسک توقف و ضربه‌خوردگی جرثقیل بندر را ۱۰۰٪ از دوش صادرکننده برداشت.','در حمل کانتینری صادراتی، کدام قاعده اینکوترمز ۲۰۲۰ جایگزین اصولی و کم‌ریسک FOB محسوب می‌شود؟','قاعده EXW درب کارخانه بدون استثنا','قاعده FCA تحویل به حمل‌کننده در ترمینال + شرط بارنامه On-Board','قاعده CIF صرفاً بدون بیمه','B',35,148,'۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(2,'MIC-TAX-02','مهلت طلایی ارسال صورت‌حساب الکترونیکی در سامانه مؤدیان','مالیات و مؤدیان',150,'ویژه مدیران مالی','⏱️ تأخیر حتی ۱ روز پس از مهلت مجاز ارسال صورت‌حساب الکترونیکی در کارپوشه مؤدیان، موجب عدم پذیرش اعتبار مالیات بر ارزش افزوده خریدار و جریمه ماده ۲۲ می‌گردد!','✅ قانون عملیاتی: تاریخ صدور صورت‌حساب باید دقیقاً منطبق بر رویداد مالی باشد و حداکثر ظرف مهلت مق قانونی سازمان امور مالیاتی در درگاه ثبت و کد یکتای ۲۲ رقمی دریافت شود.','🧾 مثال عملیاتی: اتصال مستقیم ERP به پایانه فروشگاهی باعث صدور آنی شناسه یکتای ۲۲ رقمی در همان دقیقه تسویه فاکتور شد.','شناسه اختصاصی معتبر هر صورت‌حساب رسمی در سامانه مؤدیان چند کاراکتر/رقم است؟','۸ رقم','۲۲ کاراکتر یکتا (TaxID)','۱۰ رقم کد پستی','B',30,119,'۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(3,'MIC-NTSW-03','رفع خطای عدم تطابق کد تعرفه HS در ثبت سفارش NTSW و EPL','گمرک و لجستیک',210,'ویژه بازرگانان و ترخیص','🚢 مغایرت بین شرح تجاری پیش‌فاکتور (Proforma) و ردیف تعرفه ۸ رقمی کتاب مقررات صادرات و واردات، اصلی‌ترین علت قفل شدن پرونده در کارتابل کارشناس گمرک است.','✅ فرمول ۳ مرحله‌ای: ۱) استعلام سابقه ارزش TSC در سامانه، ۲) تطبیق دقیق واحد اندازه‌گیری متعارف، ۳) درج دقیق شماره استاندارد اجباری پیش از تخصیص ارز.','🏭 نتیجه در مجتمع پلیمر: کاهش زمان اخذ مجوز ثبت سفارش و ترخیص از ۱۴ روز به ۳ روز کاری.','پیش از ثبت نهایی سفارش در سامانه NTSW، کدام بررسی از توقف پرونده در گمرک EPL جلوگیری می‌کند؟','تطبیق ردیف تعرفه ۸ رقمی HS، سابقه ارزش TSC و مجوز استاندارد','صرفاً ترجمه غیررسمی کاتالوگ','حذف شماره پیش‌فاکتور','A',40,96,'۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(4,'MIC-AI-04','فرمول پرامپت ۳ لایه برای شکار خریدار خارجی در بازار اوراسیا','هوش مصنوعی تجاری',180,'مهارت دیجیتال روز','🤖 ارسال ایمیل سرد عمومی به لیست‌های قدیمی نمایشگاهی نرخ پاسخ زیر ۰.۵٪ دارد؛ ترکیب داده‌های گمرکی TradeMap با تحلیل هوش مصنوعی نرخ مذاکره واقعی را ۶ برابر می‌کند.','✅ ساختار پرامپت استاندارد: [نقش تحلیلگر صادرات + کد HS دقیق ۶ رقمی] + [کشور هدف و حجم واردات سالانه] + [جدول مزیت رقابتی تحویل و تعرفه ترجیحی ایران-اوراسیا].','📈 خروجی واقعی: شناسایی ۱۲ واردکننده فعال پلی‌اتیلن در قزاقستان و روسیه در کمتر از ۱۵ دقیقه.','در نگارش پرامپت حرفه‌ای تحلیل بازار صادراتی، کلیدی‌ترین شناسه فنی کالا چیست؟','نام کلی صنف','کد بین‌المللی ۶ رقمی سیستم هماهنگ‌شده (HS Code)','شماره تلفن داخلی کارخانه','B',35,134,'۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `micro_learning_capsules` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `micro_skill_gap_links`
--

DROP TABLE IF EXISTS `micro_skill_gap_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `micro_skill_gap_links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `prescription_code` varchar(45) NOT NULL,
  `detected_gap_topic` varchar(175) NOT NULL,
  `source_module` varchar(85) NOT NULL DEFAULT 'آزمون استاندارد / پایپ‌لاین ATS',
  `prescribed_capsule_code` varchar(45) NOT NULL,
  `estimated_fix_minutes` int(11) NOT NULL DEFAULT 4,
  `impact_note` varchar(210) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `prescription_code` (`prescription_code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `micro_skill_gap_links`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `micro_skill_gap_links` WRITE;
/*!40000 ALTER TABLE `micro_skill_gap_links` DISABLE KEYS */;
INSERT INTO `micro_skill_gap_links` VALUES
(1,'GAP-FIX-01','شکاف جزئی در تطبیق اسناد حمل و اینکوترمز کانتینری','پایپ‌لاین استخدام ATS (پرونده APP-1405-7703)','MIC-INC-01',3,'افزایش امتیاز آمادگی مصاحبه شغلی از ۸۷٪ به ۹۵٪ تنها با ۳ دقیقه مطالعه هدفمند','2026-10-23 21:48:59'),
(2,'GAP-FIX-02','نیاز به مرور شناسه یکتای صورت‌حساب الکترونیکی','ارزیابی شایستگی واحد مالی','MIC-TAX-02',3,'رفع کامل خطای ثبت فاکتور رسمی پیش از آزمون پایانی دوره','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `micro_skill_gap_links` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `micro_spaced_flashcards`
--

DROP TABLE IF EXISTS `micro_spaced_flashcards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `micro_spaced_flashcards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `card_code` varchar(45) NOT NULL,
  `deck_category` varchar(90) NOT NULL,
  `front_prompt` text NOT NULL,
  `back_answer` text NOT NULL,
  `leitner_box` int(11) NOT NULL DEFAULT 1,
  `ease_factor` decimal(4,2) NOT NULL DEFAULT 2.50,
  `interval_days` int(11) NOT NULL DEFAULT 1,
  `next_review_label` varchar(60) NOT NULL DEFAULT 'موعد مرور: امروز ?',
  `reviews_count` int(11) NOT NULL DEFAULT 0,
  `owner_user_id` int(11) DEFAULT NULL,
  `source_kind` varchar(30) NOT NULL DEFAULT 'catalog',
  `source_ref` varchar(190) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `card_code` (`card_code`),
  KEY `idx_msf_owner` (`owner_user_id`,`leitner_box`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `micro_spaced_flashcards`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `micro_spaced_flashcards` WRITE;
/*!40000 ALTER TABLE `micro_spaced_flashcards` DISABLE KEYS */;
INSERT INTO `micro_spaced_flashcards` VALUES
(1,'FC-UCP-101','اعتبارات اسنادی UCP 600','طبق ماده ۱۴ UCP 600، بانک‌ها حداکثر چند روز کاری بانکی برای بررسی مطابقت اسناد حمل فرصت دارند؟','حداکثر ۵ روز کاری بانکی پس از روز ارائه اسناد (Maximum 5 Banking Days following the day of presentation).',2,2.50,4,'موعد مرور: امروز 🔥',3,NULL,'catalog',NULL,'2026-10-23 21:48:59'),
(2,'FC-CBAM-102','مقررات کربن مرزی اروپا CBAM','کدام صنایع صادراتی در فاز نخست مشمول گزارش‌دهی الزامی انتشار کربن مرزی اتحادیه اروپا (CBAM) هستند؟','۶ صنعت کلیدی: فولاد و آهن، آلومینیوم، سیمان، کودهای شیمیایی، برق و هیدروژن.',1,2.35,1,'موعد مرور: امروز 🔥',2,NULL,'catalog',NULL,'2026-10-23 21:48:59'),
(3,'FC-TAX-103','مالیات تکلیفی ماده ۸۶','نرخ کسر مالیات تکلیفی حق‌التدریس و حق‌المشاوره اساتید مدعو خارج از رابطه استخدامی در قراردادهای آموزشی چقدر است؟','۱۰ درصد مقطوع که توسط پرداخت‌کننده کسر و به حساب سازمان امور مالیاتی واریز و گواهی آن صادر می‌گردد.',4,2.75,12,'مرور بعدی: ۱۲ روز دیگر ✅',6,NULL,'catalog',NULL,'2026-10-23 21:48:59'),
(4,'FC-EUR-104','توافق تجارت آزاد ایران و اوراسیا','گواهی مبدأ ویژه بهره‌مندی از تعرفه صفر یا ترجیحی در صادرات کالا به اتحادیه اقتصادی اوراسیا چه نام دارد؟','گواهی مبدأ فرم CT-3 صادره توسط مؤسسه آموزشی آدان.',3,2.60,7,'مرور بعدی: ۷ روز دیگر',4,NULL,'catalog',NULL,'2026-10-23 21:48:59');
/*!40000 ALTER TABLE `micro_spaced_flashcards` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `national_bus_inquiries`
--

DROP TABLE IF EXISTS `national_bus_inquiries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `national_bus_inquiries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trace_code` varchar(45) NOT NULL,
  `target_system` varchar(140) NOT NULL,
  `identifier_queried` varchar(90) NOT NULL,
  `math_checksum_valid` tinyint(1) NOT NULL DEFAULT 0,
  `gateway_execution_mode` varchar(90) DEFAULT 'پیش‌نمایش محلی - استعلام انجام نشده',
  `response_summary` varchar(255) NOT NULL,
  `customs_duty_pct` int(11) DEFAULT NULL,
  `inquired_shamsi` varchar(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `trace_code` (`trace_code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `national_bus_inquiries`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `national_bus_inquiries` WRITE;
/*!40000 ALTER TABLE `national_bus_inquiries` DISABLE KEYS */;
INSERT INTO `national_bus_inquiries` VALUES
(1,'LOCAL-SEED-1','سامانه جامع تجارت (NTSW) — اتصال فعال نیست','ذخیره نشد (حریم خصوصی)',1,'پیش‌نمایش محلی - استعلام انجام نشده','قالب نمونه از نظر رقم کنترل محلی معتبر است؛ هویت یا وضعیت پرونده استعلام نشده است.',NULL,'۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(2,'LOCAL-SEED-2','ثبت شرکت‌ها (SSAA) — اتصال فعال نیست','ذخیره نشد (حریم خصوصی)',1,'پیش‌نمایش محلی - استعلام انجام نشده','قالب نمونه از نظر رقم کنترل محلی معتبر است؛ وضعیت ثبتی شرکت استعلام نشده است.',NULL,'۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(3,'LOCAL-SEED-3','سامانه امور گمرکی (EPL) — اتصال فعال نیست','ذخیره نشد (حریم خصوصی)',1,'پیش‌نمایش محلی - استعلام انجام نشده','قالب هشت‌رقمی نمونه پذیرفته شد؛ کد تعرفه یا شرایط گمرکی استعلام نشده است.',NULL,'۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `national_bus_inquiries` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `target_role` varchar(50) DEFAULT NULL,
  `title` varchar(200) NOT NULL,
  `body` text DEFAULT NULL,
  `type` enum('info','success','warning','urgent') DEFAULT 'info',
  `link` varchar(255) DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES
(1,NULL,'super_admin','۳ پیش‌نویس محتوای هوش مصنوعی در انتظار تأیید انسانی','خروجی‌های استودیوی AI پیش از انتشار در LMS نیازمند بررسی کارشناسی و تأیید انسانی هستند.','warning','ai-studio',0,'2026-10-23 21:48:59'),
(2,NULL,'super_admin','قرارداد آموزشی فولاد زاگرس به ۷۴٪ ظرفیت رسید','پیشنهاد الحاقیه تمدید سقف نفر-ساعت در کارتابل قراردادهای سازمانی ثبت شد.','info','contracts',0,'2026-10-23 21:48:59'),
(3,7,'learner','صدور گواهی‌نامه معتبر با کد QR','گواهی دوره جامع اینکوترمز ۲۰۲۰ و اسناد حمل برای شما صادر و در گذرنامه مهارت ثبت شد.','success','exams',0,'2026-10-23 21:48:59');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `oa_admin_requests`
--

DROP TABLE IF EXISTS `oa_admin_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oa_admin_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `req_code` varchar(45) NOT NULL,
  `requester_name` varchar(130) NOT NULL,
  `unit_name` varchar(120) NOT NULL,
  `req_category` varchar(80) NOT NULL DEFAULT 'مرخصی استحقاقی / ساعتی',
  `date_range_or_amount` varchar(120) NOT NULL,
  `description_note` varchar(255) NOT NULL,
  `approval_status` varchar(60) NOT NULL DEFAULT 'منتظر تأیید مدیریت',
  `approver_note` varchar(180) DEFAULT '—',
  `created_shamsi` varchar(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `requester_user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `req_code` (`req_code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oa_admin_requests`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `oa_admin_requests` WRITE;
/*!40000 ALTER TABLE `oa_admin_requests` DISABLE KEYS */;
INSERT INTO `oa_admin_requests` VALUES
(1,'OA-REQ-401','مهندس پگاه کاظمی','واحد برنامه‌ریزی آموزش','حکم مأموریت اداری','۱۴۰۵/۰۸/۰۶ لغایت ۱۴۰۵/۰۸/۰۷ (۲ روز)','اعزام به مرکز آموزشی همکار شهرستان جهت نظارت بر برگزاری آزمون حسابداری','تأیید نهایی مدیریت','با پرداخت حق مأموریت طبق آیین‌نامه موافقت شد.','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59',NULL),
(2,'OA-REQ-402','مهندس سامان فرهادی','واحد سمعی‌بصری و تالارها','درخواست تنخواه و تدارکات','۱۸,۵۰۰,۰۰۰ ریال','تهیه ملزومات پذیرایی و بسته‌های آموزشی دوره حسابداری روز چهارشنبه','منتظر تأیید مدیریت','—','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59',NULL),
(3,'OA-REQ-403','سرکار خانم مریم رضایی','دبیرخانه و پذیرش','مرخصی استحقاقی / ساعتی','پنج‌شنبه ۱۴۰۵/۰۸/۰۸ (۱ روز)','مرخصی استحقاقی روزانه با هماهنگی جانشین میز پذیرش','منتظر تأیید مدیریت','—','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59',NULL);
/*!40000 ALTER TABLE `oa_admin_requests` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `oa_letter_referrals`
--

DROP TABLE IF EXISTS `oa_letter_referrals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oa_letter_referrals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `letter_id` int(11) NOT NULL,
  `from_person` varchar(120) NOT NULL,
  `to_person_unit` varchar(140) NOT NULL,
  `action_command` varchar(90) NOT NULL DEFAULT 'جهت اقدام مقتضی',
  `paraph_margin_note` varchar(255) NOT NULL,
  `deadline_shamsi` varchar(40) DEFAULT '۱۴۰۵/۰۸/۰۵',
  `referral_status` varchar(60) NOT NULL DEFAULT 'در دست اقدام',
  `created_shamsi` varchar(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `from_user_id` int(11) DEFAULT NULL,
  `to_user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_oa_referrals_assignee` (`to_user_id`,`referral_status`),
  KEY `idx_oa_referrals_letter` (`letter_id`,`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oa_letter_referrals`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `oa_letter_referrals` WRITE;
/*!40000 ALTER TABLE `oa_letter_referrals` DISABLE KEYS */;
INSERT INTO `oa_letter_referrals` VALUES
(1,2,'دکتر کیارش رادمهر (مدیرکل آموزش)','مهندس پگاه کاظمی — واحد برنامه‌ریزی آموزش','جهت اقدام فوری','لطفاً ظرفیت کلاس بررسی و پیش‌نویس تقویم اجرایی ظرف ۴۸ ساعت به شرکت همکار اعلام شود.','۱۴۰۵/۰۸/۰۳','در دست اقدام','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59',NULL,NULL),
(2,3,'مهندس پگاه کاظمی (واحد آموزش)','جناب آقای بهمنی — مدیریت امور مالی','جهت صدور دستور پرداخت','کارکرد ساعات تدریس و حدنصاب رضایت‌سنجی بالای ۹۲٪ مورد تأیید واحد آموزش می‌باشد.','۱۴۰۵/۰۸/۰۵','در دست اقدام','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59',NULL,NULL),
(3,1,'دبیرخانه مؤسسه آدان','بایگانی مکاتبات اداری','بایگانی در پرونده','نسخه چاپی ممهور از طریق پیک ارسال و رسید تحویل ثبت گردید.','۱۴۰۵/۰۸/۰۲','اقدام و مختومه شد','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59',NULL,NULL);
/*!40000 ALTER TABLE `oa_letter_referrals` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `oa_letters`
--

DROP TABLE IF EXISTS `oa_letters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oa_letters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `indicator_no` varchar(50) NOT NULL,
  `letter_type` varchar(30) NOT NULL DEFAULT 'داخلی',
  `priority_level` varchar(30) NOT NULL DEFAULT 'عادی',
  `confidentiality` varchar(30) NOT NULL DEFAULT 'عادی',
  `sender_unit` varchar(140) NOT NULL,
  `recipient_org` varchar(160) NOT NULL,
  `subject_title` varchar(220) NOT NULL,
  `letter_body` text NOT NULL,
  `attachment_note` varchar(160) DEFAULT 'ندارد',
  `signatory_name` varchar(120) NOT NULL DEFAULT 'دکتر کیارش رادمهر — مدیرکل آموزش',
  `sign_status` varchar(60) NOT NULL DEFAULT 'امضاشده و ثبت در دبیرخانه',
  `qr_verify_code` varchar(60) NOT NULL,
  `created_shamsi` varchar(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `sender_user_id` int(11) DEFAULT NULL,
  `recipient_user_id` int(11) DEFAULT NULL,
  `reply_to_letter_id` int(11) DEFAULT NULL,
  `recipient_status` varchar(40) NOT NULL DEFAULT 'خوانده‌نشده',
  `read_at` datetime DEFAULT NULL,
  `archived_at` datetime DEFAULT NULL,
  `external_recipient` varchar(160) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_oa_letters_recipient_inbox` (`recipient_user_id`,`archived_at`,`id`),
  KEY `idx_oa_letters_sender_outbox` (`sender_user_id`,`id`),
  UNIQUE KEY `indicator_no` (`indicator_no`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oa_letters`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `oa_letters` WRITE;
/*!40000 ALTER TABLE `oa_letters` DISABLE KEYS */;
INSERT INTO `oa_letters` VALUES
(1,'۱۴۰۵/د/۱۰۴۱','صادره','فوری','عادی','مدیریت آموزش و پژوهش مؤسسه آموزشی آدان','اداره کل گمرکات استان — معاونت امور بازرگانی','معرفی دانش‌آموختگان دوره جامع قوانین گمرکی و سامانه جامع تجارت','با سلام و احترام؛\nبدین‌وسیله فهرست اسامی ۳۲ نفر از مدیران بازرگانی واحدهای تولیدی و صادراتی دانش‌پذیر آدان که دوره تخصصی «مقررات گمرکی، ثبت سفارش و اسناد حمل بین‌المللی» را با موفقیت به پایان رسانده‌اند، جهت استحضار و بهره‌برداری قانونی در فرآیندهای ترخیص ایفاد می‌گردد.','فهرست اسامی ممهور (۲ برگ)','دکتر کیارش رادمهر — مدیرکل آموزش','امضاشده و ثبت در دبیرخانه','OA-VERIFY-1405-1041','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59',NULL,NULL,NULL,'خوانده‌نشده',NULL,NULL,NULL),
(2,'۱۴۰۵/د/۱۰۴۲','وارده','آنی','عادی','شرکت مجتمع فولاد و ذوب‌آهن زاگرس (دبیرخانه)','ریاست محترم واحد آموزش مؤسسه آموزشی آدان','درخواست برگزاری دوره اختصاصی اعتبارات اسنادی برای کارشناسان بازرگانی خارجی','با سلام و احترام؛\nپیرو قرارداد سالانه توانمندسازی سرمایه انسانی، خواهشمند است دستور فرمایید نسبت به برنامه‌ریزی و اعلام تقویم کارگاه عملی «اعتبارات اسنادی و ضمانت‌نامه‌های ارزی» ویژه ۱۸ نفر از کارشناسان بازرگانی خارجی این مجتمع اقدام لازم صورت پذیرد.','فرم نیازسنجی پرسنل','مهندس کامران بهرامی — مدیر آموزش فولاد زاگرس','ثبت وارده — ارجاع‌شده','OA-VERIFY-1405-1042','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59',NULL,NULL,NULL,'خوانده‌نشده',NULL,NULL,NULL),
(3,'۱۴۰۵/د/۱۰۴۳','داخلی','عادی','محرمانه','واحد برنامه‌ریزی و امتحانات','مدیریت مالی مؤسسه آدان','درخواست تسویه حق‌التدریس اساتید مدعو نیمسال پاییز پس از کسر مالیات ماده ۸۶','احتراماً به پیوست خلاصه کارکرد آموزشی و فرم ارزشیابی اساتید مدعو کارگاه‌های مهرماه ایفاد می‌گردد. خواهشمند است دستور فرمایید پس از اعمال کسور قانونی ماده ۸۶، نسبت به صدور حواله بانکی اقدام گردد.','خلاصه ساعت تدریس تأییدشده','مهندس پگاه کاظمی — کارشناس مسئول آموزش','پیش‌نویس منتظر امضا','OA-VERIFY-1405-1043','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59',NULL,NULL,NULL,'خوانده‌نشده',NULL,NULL,NULL);
/*!40000 ALTER TABLE `oa_letters` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `oa_meeting_minutes`
--

DROP TABLE IF EXISTS `oa_meeting_minutes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oa_meeting_minutes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `minute_code` varchar(45) NOT NULL,
  `meeting_title` varchar(200) NOT NULL,
  `chairperson` varchar(120) NOT NULL,
  `attendees_summary` varchar(240) NOT NULL,
  `key_resolutions` text NOT NULL,
  `responsible_owner` varchar(120) NOT NULL,
  `due_shamsi` varchar(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۱۵',
  `execution_status` varchar(60) NOT NULL DEFAULT 'ابلاغ‌شده — در حال پیگیری',
  `created_shamsi` varchar(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `minute_code` (`minute_code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oa_meeting_minutes`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `oa_meeting_minutes` WRITE;
/*!40000 ALTER TABLE `oa_meeting_minutes` DISABLE KEYS */;
INSERT INTO `oa_meeting_minutes` VALUES
(1,'MIN-1405-101','جلسه شورای راهبری آموزش و توانمندسازی صادرکنندگان استان','دکتر کیارش رادمهر','مدیرکل آموزش، مدیر مالی، رئیس کمیسیون صادرات، نماینده واحد صنعت (۷ نفر)','۱. تصویب تقویم ۱۲ کارگاه عملی تجارت خارجی نیمسال دوم | ۲. اختصاص ۲۰٪ تخفیف ویژه واحدهای تولیدی شهرک‌های صنعتی | ۳. اتصال مستقیم کارنامه قبول‌شدگان به بانک رزومه کاریابی.','واحد برنامه‌ریزی آموزش','۱۴۰۵/۰۸/۱۵','ابلاغ‌شده — در حال پیگیری','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(2,'MIN-1405-102','کمیته کنترل کیفی و انضباط مالی دوره‌های سازمانی','مدیر امور مالی اتاق','مدیر مالی، کارشناس مسئول قراردادها، بازرس داخلی اتاق (۴ نفر)','۱. الزام تسویه قسط اول پیش از صدور کارت ورود به جلسه | ۲. ارسال خودکار صورت‌حساب الکترونیکی در پایان هر ماه.','مدیریت امور مالی','۱۴۰۵/۰۸/۱۰','اجرا و مختومه شد','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `oa_meeting_minutes` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `ocr_financial_scans`
--

DROP TABLE IF EXISTS `ocr_financial_scans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ocr_financial_scans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `scan_code` varchar(40) NOT NULL,
  `doc_type` varchar(60) NOT NULL,
  `raw_extracted_text` text NOT NULL,
  `detected_amount_rial` bigint(20) NOT NULL DEFAULT 0,
  `detected_sayad_or_ref` varchar(40) NOT NULL,
  `detected_iban` varchar(34) DEFAULT '',
  `checksum_verified` tinyint(1) DEFAULT 0,
  `moadian_vat_status` varchar(120) DEFAULT 'پیش‌نویس محلی - وضعیت مالیاتی بررسی نشده/ارسال نشده',
  `booked_voucher_no` varchar(40) NOT NULL DEFAULT '',
  `scanned_shamsi` varchar(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `scan_code` (`scan_code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ocr_financial_scans`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `ocr_financial_scans` WRITE;
/*!40000 ALTER TABLE `ocr_financial_scans` DISABLE KEYS */;
INSERT INTO `ocr_financial_scans` VALUES
(1,'OCR-9501','برگه چک صیادی بنفش','چک صیادی شناسه 1094827165039281 مبلغ 340,000,000 ریال در وجه مؤسسه آموزشی آدان شبا IR160170000000319845120001 بانک ملی',340000000,'1094827165039281','IR160170000000319845120001',1,'معاف از ارزش افزوده (بند ۱۲ ماده ۱۲ آموزش)','VCH-OCR-881','۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59'),
(2,'OCR-9502','رسید حواله پایا / ساتنا سازمانی','واریز پایا مبلغ 185,000,000 ریال کد پیگیری 994827162 بابت شهریه دوره جامع صادرات شرکت پتروشیمی تابان',185000000,'REF-994827162','IR062960000000100324200001',1,'الگوی اول صورت‌حساب الکترونیکی مؤدیان تأیید شد','VCH-OCR-882','۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `ocr_financial_scans` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `org_employee_training_requests`
--

DROP TABLE IF EXISTS `org_employee_training_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `org_employee_training_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `req_code` varchar(45) NOT NULL,
  `org_name` varchar(160) NOT NULL,
  `employee_fullname` varchar(150) NOT NULL,
  `department_unit` varchar(120) NOT NULL,
  `requested_course` varchar(190) NOT NULL,
  `hr_approval_status` varchar(60) NOT NULL DEFAULT 'در انتظار تأیید نماینده سازمان',
  `contract_quota_deducted` tinyint(1) NOT NULL DEFAULT 0,
  `requested_shamsi` varchar(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `req_code` (`req_code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `org_employee_training_requests`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `org_employee_training_requests` WRITE;
/*!40000 ALTER TABLE `org_employee_training_requests` DISABLE KEYS */;
INSERT INTO `org_employee_training_requests` VALUES
(1,'ORQ-1405-601','مجتمع فولاد و ذوب‌آهن زاگرس','مهندس آرش کاویانی','واحد سفارشات خارجی','جامع اینکوترمز ۲۰۲۰ و حمل چندوجهی','در انتظار تأیید نماینده سازمان',0,'۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(2,'ORQ-1405-602','مجتمع فولاد و ذوب‌آهن زاگرس','پریسا سلیمانی','واحد حسابداری مالیاتی','سامانه مؤدیان و صورت‌حساب الکترونیکی نوع دوم','تأیید شده و کسر از سهمیه قرارداد',1,'۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `org_employee_training_requests` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `organizations`
--

DROP TABLE IF EXISTS `organizations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `organizations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `chamber_member_code` varchar(80) DEFAULT NULL,
  `national_id` varchar(30) DEFAULT NULL,
  `industry` varchar(120) DEFAULT 'صنعت و بازرگانی',
  `membership_tier` enum('gold','silver','standard','non_member') DEFAULT 'gold',
  `city` varchar(100) DEFAULT 'مرکز استان',
  `annual_quota_hours` int(11) DEFAULT 200,
  `used_quota_hours` int(11) DEFAULT 0,
  `contact_phone` varchar(40) DEFAULT NULL,
  `status` enum('active','pending','suspended') DEFAULT 'active',
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `chamber_member_code` (`chamber_member_code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organizations`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `organizations` WRITE;
/*!40000 ALTER TABLE `organizations` DISABLE KEYS */;
INSERT INTO `organizations` VALUES
(1,'گروه صنعتی و صادراتی فولاد زاگرس','CH-8801','10102938471','فلزات اساسی و صادرات صنعتی','gold','مرکز استان',320,148,'021-88901122','active','2026-10-23 21:48:59'),
(2,'شرکت کشت و صنعت و بازرگانی زعفران تابان','CH-8842','10861192034','کشاورزی و صادرات مواد غذایی','gold','شهرک صنعتی اول',240,96,'051-37654321','active','2026-10-23 21:48:59'),
(3,'هلدینگ لجستیک و حمل‌ونقل بین‌المللی دریاپیما','CH-8910','14005928311','حمل‌ونقل ترکیبی و گمرک','silver','منطقه ویژه اقتصادی',180,64,'021-44556677','active','2026-10-23 21:48:59'),
(4,'شرکت دانش‌بنیان پلیمر و پتروشیمی سپهر','CH-9025','14008821905','پلیمر و صنایع شیمیایی','gold','شهرک علمی و تحقیقاتی',300,112,'031-33991100','active','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `organizations` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `payment_transactions`
--

DROP TABLE IF EXISTS `payment_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `authority_code` varchar(80) NOT NULL,
  `ref_id` varchar(80) NOT NULL,
  `amount_rial` bigint(20) NOT NULL,
  `gateway_mode` varchar(50) DEFAULT 'sandbox_hmac_signed',
  `hmac_signature` varchar(128) NOT NULL,
  `is_reconciled` tinyint(1) DEFAULT 0,
  `reconciled_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_transactions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `payment_transactions` WRITE;
/*!40000 ALTER TABLE `payment_transactions` DISABLE KEYS */;
INSERT INTO `payment_transactions` VALUES
(1,1,'AUTH-CHB-990101','SHAPARAK-SANDBOX-778811',57200000,'sandbox_hmac_signed','9b8c7d6e5f4a3b2c1d0e9f8a7b6c5d4e',0,NULL,'2026-10-23 21:48:59');
/*!40000 ALTER TABLE `payment_transactions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `pooyesh_stipend_claims`
--

DROP TABLE IF EXISTS `pooyesh_stipend_claims`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pooyesh_stipend_claims` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `claim_code` varchar(40) NOT NULL,
  `host_company` varchar(160) NOT NULL,
  `intern_fullname` varchar(140) NOT NULL,
  `duration_months` int(11) NOT NULL DEFAULT 4,
  `monthly_stipend_rial` bigint(20) NOT NULL DEFAULT 95000000,
  `total_paid_rial` bigint(20) NOT NULL DEFAULT 380000000,
  `tax_credit_approved_rial` bigint(20) NOT NULL DEFAULT 380000000,
  `statutory_clause` varchar(180) DEFAULT 'ماده ۱۱ قانون جهش تولید دانش‌بنیان (اعتبار مالیاتی طرح پویش)',
  `created_shamsi` varchar(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `claim_code` (`claim_code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pooyesh_stipend_claims`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `pooyesh_stipend_claims` WRITE;
/*!40000 ALTER TABLE `pooyesh_stipend_claims` DISABLE KEYS */;
INSERT INTO `pooyesh_stipend_claims` VALUES
(1,'POY-1405-401','مجتمع فولاد و ذوب‌آهن زاگرس','مهندس سارا محمدی (دانشجوی ارشد بازرگانی)',4,110000000,440000000,440000000,'ماده ۱۱ قانون جهش تولید دانش‌بنیان — ۱۰۰٪ اعتبار مالیاتی دستمزد کارآموز پویش','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(2,'POY-1405-402','شرکت فرآورده‌های غذایی بهاران','امیرحسین رضایی (کارآموز لجستیک صادرات)',3,90000000,270000000,270000000,'ماده ۱۱ قانون جهش تولید دانش‌بنیان — صدور گواهی کسر از مالیات عملکرد','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `pooyesh_stipend_claims` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `portal_pages`
--

DROP TABLE IF EXISTS `portal_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `portal_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slug` varchar(80) NOT NULL,
  `version_no` int(11) NOT NULL DEFAULT 1,
  `hero_title` varchar(240) NOT NULL,
  `hero_subtitle` varchar(400) NOT NULL,
  `announcement_bar` varchar(255) DEFAULT NULL,
  `featured_boxes_json` longtext NOT NULL,
  `is_published` tinyint(1) DEFAULT 0,
  `edited_by` int(11) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portal_pages`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `portal_pages` WRITE;
/*!40000 ALTER TABLE `portal_pages` DISABLE KEYS */;
INSERT INTO `portal_pages` VALUES
(1,'home',1,'پورتال آموزش حسابداری آدان (نسخه اولیه)','آموزش کاربردی حسابداری و امور مالی در مسیر بازار کار','آغاز ثبت‌نام دوره‌های پاییزه','[\"کاتالوگ دوره‌ها\",\"استعلام گواهی‌نامه\"]',0,2,'2026-10-23 21:48:59'),
(2,'home',2,'آموزشگاه حسابداری آدان','آموزش کاربردی حسابداری، مالیات، حقوق و دستمزد و نرم‌افزارهای مالی؛ از مبانی تا ورود مطمئن به بازار کار.','ثبت‌نام ترم پاییز ۱۴۰۵ آغاز شد | ۲۵٪ تخفیف ویژه ثبت‌نام گروهی دوره‌های حسابداری','[\"آکادمی تجارت بین‌الملل و CBAM\",\"استعلام برخط اصالت گواهی‌نامه با QR\",\"پورتال اختصاصی سازمان‌ها و قراردادها\",\"همراه هوشمند آموزشی مبتنی بر AI\"]',1,1,'2026-10-23 21:48:59');
/*!40000 ALTER TABLE `portal_pages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `proctoring_events`
--

DROP TABLE IF EXISTS `proctoring_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `proctoring_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_full_name` varchar(160) NOT NULL,
  `exam_or_lesson_title` varchar(200) NOT NULL,
  `event_type` enum('تغییر تب مرورگر','خروج از تمام‌صفحه','تغییر آدرس IP','فعال‌سازی واترمارک پویا') DEFAULT 'تغییر تب مرورگر',
  `risk_level` enum('کم','متوسط','شدید - بازبینی کمیته') DEFAULT 'کم',
  `watermark_stamp` varchar(140) NOT NULL,
  `reviewer_decision` varchar(80) DEFAULT 'تأیید سلامت آزمون',
  `logged_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proctoring_events`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `proctoring_events` WRITE;
/*!40000 ALTER TABLE `proctoring_events` DISABLE KEYS */;
INSERT INTO `proctoring_events` VALUES
(1,'مهندس نیما فرهادی','آزمون جامع اینکوترمز ۲۰۲۰','فعال‌سازی واترمارک پویا','کم','NID:0079988776 | IP:185.143.x.x','تأیید سلامت آزمون','2026-10-23 21:48:59'),
(2,'سارا محمدی','آزمون جامع اینکوترمز ۲۰۲۰','تغییر تب مرورگر','متوسط','NID:0081122334 | ۲ مرتبه خروج موقت از تب','تذکر سیستمی - بدون تخلف','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `proctoring_events` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `psychometric_results`
--

DROP TABLE IF EXISTS `psychometric_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `psychometric_results` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `test_name` varchar(160) DEFAULT 'سنجش سبک مذاکره تجاری و شایستگی رفتاری (نسخه قطعی)',
  `analytical_score` int(11) NOT NULL,
  `collaborative_score` int(11) NOT NULL,
  `decisive_score` int(11) NOT NULL,
  `resilience_score` int(11) NOT NULL,
  `dominant_style` varchar(140) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `psychometric_results`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `psychometric_results` WRITE;
/*!40000 ALTER TABLE `psychometric_results` DISABLE KEYS */;
INSERT INTO `psychometric_results` VALUES
(1,7,'سنجش سبک مذاکره تجاری و شایستگی رفتاری (نمره‌دهی قطعی)',88,84,76,81,'مذاکره‌گر تحلیلی - برد/برد (مناسب قراردادهای بلندمدت بین‌المللی)','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `psychometric_results` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `public_ai_pathfinder_leads`
--

DROP TABLE IF EXISTS `public_ai_pathfinder_leads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `public_ai_pathfinder_leads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `visitor_fullname` varchar(140) NOT NULL,
  `visitor_mobile` varchar(30) NOT NULL,
  `visitor_goal` varchar(160) NOT NULL,
  `industry_field` varchar(120) NOT NULL,
  `recommended_roadmap` varchar(240) NOT NULL,
  `estimated_90d_roi` varchar(140) NOT NULL,
  `synced_crm_status` varchar(80) DEFAULT 'ثبت خودکار سرنخ داغ در CRM',
  `captured_shamsi` varchar(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `student_admissions`
--

DROP TABLE IF EXISTS `student_admissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `student_admissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(160) NOT NULL,
  `mobile` varchar(30) NOT NULL,
  `course_id` int(11) NOT NULL,
  `prior_education` varchar(255) DEFAULT NULL,
  `status` enum('submitted','contacted','accepted','rejected','enrolled') DEFAULT 'submitted',
  `review_note` varchar(500) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `enrollment_id` int(11) DEFAULT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `submitted_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_admission_status` (`status`,`submitted_at`),
  KEY `idx_admission_course` (`course_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `public_ai_pathfinder_leads`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `public_ai_pathfinder_leads` WRITE;
/*!40000 ALTER TABLE `public_ai_pathfinder_leads` DISABLE KEYS */;
INSERT INTO `public_ai_pathfinder_leads` VALUES
(1,'مهندس فرشاد نیک‌پی','09123456789','شروع اولین صادرات رسمی محصول تولیدی','تولیدکننده شیرآلات صنعتی','گام ۱: دوره الزامی کارت بازرگانی | گام ۲: کارگاه قیمت‌گذاری صادراتی و TradeMap | گام ۳: میز B2B عراق','اولین پیش‌فاکتور صادراتی ظرف ۹۰ روز','ثبت خودکار سرنخ داغ در CRM (امتیاز ۹۲)','۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `public_ai_pathfinder_leads` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `rag_documents`
--

DROP TABLE IF EXISTS `rag_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `rag_documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `category` varchar(80) DEFAULT 'دستورالعمل آموزشی مؤسسه آدان',
  `keywords` varchar(255) NOT NULL,
  `chunk_text` longtext NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rag_documents`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `rag_documents` WRITE;
/*!40000 ALTER TABLE `rag_documents` DISABLE KEYS */;
INSERT INTO `rag_documents` VALUES
(1,'آیین‌نامه تخفیفات آموزشی فراگیران آدان استان','آیین‌نامه مالی و ثبت‌نام','تخفیف عضویت کارت بازرگانی طلایی گروهی سازمانی','دارندگان کارت عضویت معتبر مؤسسه آموزشی آدان مشمول ۱۵ تا ۳۰ درصد تخفیف سازمانی در دوره‌های تخصصی هستند و شرکت‌های دارای قرارداد سالانه می‌توانند به صورت اقساطی یا از محل اعتبار قرارداد ثبت‌نام نمایند.','2026-10-23 21:48:59'),
(2,'ضوابط حضور و ارزیابی دوره‌های آدان','آیین‌نامه آموزشی','گواهی حضور غیاب نمره قبولی آزمون QR','برای دریافت گواهی پایان دورهٔ آموزشگاه آدان، حضور حداقل ۸۰ درصد ساعات دوره و کسب حداقل نمرهٔ قبولی ۷۰ از ۱۰۰ لازم است. وضعیت گواهی فقط در سوابق داخلی آموزشگاه قابل مشاهده است و این گواهی جایگزین مجوز یا تأییدیهٔ مرجع رسمی نیست.','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `rag_documents` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `rag_knowledge_chunks`
--

DROP TABLE IF EXISTS `rag_knowledge_chunks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `rag_knowledge_chunks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `doc_code` varchar(40) NOT NULL,
  `source_authority` varchar(160) NOT NULL,
  `clause_reference` varchar(140) NOT NULL,
  `topic_keywords` varchar(220) NOT NULL,
  `chunk_text` text NOT NULL,
  `updated_shamsi` varchar(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `doc_code` (`doc_code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rag_knowledge_chunks`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `rag_knowledge_chunks` WRITE;
/*!40000 ALTER TABLE `rag_knowledge_chunks` DISABLE KEYS */;
INSERT INTO `rag_knowledge_chunks` VALUES
(1,'LAW-VAT-12','سازمان امور مالیاتی کشور — قانون مالیات بر ارزش افزوده','بند ۱۲ ماده ۱۲ (معافیت خدمات آموزشی)','معافیت مالیات ارزش افزوده آموزش دوره سمینار مؤدیان فاکتور','مطابق بند ۱۲ ماده ۱۲ قانون دائمی مالیات بر ارزش افزوده، کلیه خدمات آموزشی، پژوهشی و ورزشی دارای مجوز رسمی از مراجع ذی‌صلاح و مؤسسات آموزشی از پرداخت مالیات و عوارض ارزش افزوده معاف بوده و در سامانه مؤدیان با نرخ صفر/معاف ثبت می‌گردند.','۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59'),
(2,'LAW-BUS-2-3','مجلس شورای اسلامی — قانون بهبود مستمر محیط کسب‌وکار','مواد ۲، ۳ و ۵ (الزام نظرخواهی از مؤسسه آموزشی آدان)','بخشنامه خلق الساعه گمرک بانک مرکزی صادرات کمیسیون نظرخواهی','به موجب مواد ۲ و ۳ قانون بهبود مستمر محیط کسب‌وکار، کلیه دستگاه‌های اجرایی مکلف‌اند پیش از وضع یا تغییر هرگونه مقررات، بخشنامه و دستورالعمل مؤثر بر تولید، تجارت و سرمایه‌گذاری، نظر مشورتی کتبی مؤسسه آموزشی آدان را اخذ و در متن مصوبه لحاظ نمایند.','۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59'),
(3,'REG-CARD-80','آیین‌نامه اجرایی صدور و تمدید کارت بازرگانی ۱۴۰۵','ضوابط آموزشی واحد آموزش آدان ایران','کارت بازرگانی حضور ۸۰ نمره ۷۰ صدور تمدید متقاضی','متقاضیان صدور بار اول کارت بازرگانی حقیقی و حقوقی ملزم به گذراندن حداقل ۸۰٪ ساعات کلاس‌های آموزشی الزامی و کسب حداقل نمره قبولی ۷۰ از ۱۰۰ در آزمون جامع استاندارد مؤسسه آموزشی آدان پیش از صدور کد رهگیری تأییدیه می‌باشند.','۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59'),
(4,'ICC-INC-2020','مرجع بین‌المللی ICC پاریس (ICC)','مقررات رسمی Incoterms® 2020 — تفاوت CIF و CIP','اینکوترمز بیمه کلوز A کلوز C کانتینر حمل بارنامه','در ویرایش ۲۰۲۰ اینکوترمز، قاعده CIF صرفاً مخصوص حمل دریایی و آبراه‌های داخلی با حداقل پوشش بیمه کلوز C است؛ برای حمل کانتینری و چندوجهی باید از قاعده CIP با الزام پوشش بیمه تمام‌خطر کلوز A به نفع خریدار استفاده شود.','۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `rag_knowledge_chunks` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `rd_competitor_courses`
--

DROP TABLE IF EXISTS `rd_competitor_courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `rd_competitor_courses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `competitor_id` int(11) NOT NULL,
  `course_title` varchar(220) NOT NULL,
  `duration_hours` int(11) DEFAULT 24,
  `tuition_rial` bigint(20) DEFAULT 45000000,
  `delivery_format` varchar(60) DEFAULT 'آنلاین / حضوری',
  `source_url` varchar(500) DEFAULT '',
  `our_catalog_status` varchar(90) DEFAULT 'شکاف کاتالوگ (اقیانوس آبی)',
  `captured_shamsi` varchar(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rd_competitor_courses`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `rd_competitor_courses` WRITE;
/*!40000 ALTER TABLE `rd_competitor_courses` DISABLE KEYS */;
INSERT INTO `rd_competitor_courses` VALUES
(1,1,'جامع ثبت سفارش واردات در سامانه NTSW، تخصیص ارز نیمایی و اظهار از راه دور گمرک (EPL)',32,109000000,'آنلاین تعاملی','https://itecc.ir/','شکاف طلایی کاتالوگ (اقیانوس آبی)','۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59'),
(2,2,'شناسایی کالاها و بازارهای برتر صادراتی ایران با هوش مصنوعی و ابزارهای ITC TradeMap',12,19000000,'آنلاین کاربردی','https://ibtc.ir/courses','شکاف طلایی کاتالوگ (اقیانوس آبی)','۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59'),
(3,1,'رویه صادرات قطعی کالا و قوانین برگشت و رفع تعهد ارز حاصل از صادرات',8,19000000,'حضوری / آنلاین','https://itecc.ir/','شکاف طلایی کاتالوگ (اقیانوس آبی)','۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59'),
(4,2,'سامانه جامع تجارت داخلی، انبارها و رهگیری کد نقش',36,119000000,'حضوری','https://ibtc.ir/courses','شکاف طلایی کاتالوگ (اقیانوس آبی)','۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59'),
(5,1,'تهیه و تنظیم قراردادهای تجاری بین‌المللی (منطبق با کنوانسیون وین CISG)',24,74000000,'مجازی','https://itecc.tccim.ir/','پوشش نسبی در کاتالوگ فعلی','۱۴۰۵/۰۷/۲۹','2026-10-23 21:48:59'),
(6,4,'دوره جامع بازرگانی بین‌الملل (بسته ITP)',60,210000000,'حضوری / آنلاین','https://mftmirdamad.com/','پوشش کامل با قیمت رقابتی‌تر در اتاق','۱۴۰۵/۰۷/۲۹','2026-10-23 21:48:59'),
(7,2,'اصول حرفه‌ای مذاکره تجاری و غرفه‌داری در نمایشگاه‌های بین‌المللی',12,33000000,'حضوری کارگاهی','https://ibtc.ir/courses','شکاف طلایی کاتالوگ (اقیانوس آبی)','۱۴۰۵/۰۷/۲۸','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `rd_competitor_courses` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `rd_competitors`
--

DROP TABLE IF EXISTS `rd_competitors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `rd_competitors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(180) NOT NULL,
  `category` varchar(90) NOT NULL,
  `website_url` varchar(255) NOT NULL,
  `city_scope` varchar(80) DEFAULT 'ملی / آنلاین',
  `avg_hourly_rate_rial` bigint(20) DEFAULT 3000000,
  `delivery_model` varchar(90) DEFAULT 'حضوری و آنلاین هم‌زمان',
  `key_strengths` text DEFAULT NULL,
  `key_weaknesses` text DEFAULT NULL,
  `last_crawled_at` varchar(40) DEFAULT '۱۴۰۵/۰۷/۳۰',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rd_competitors`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `rd_competitors` WRITE;
/*!40000 ALTER TABLE `rd_competitors` DISABLE KEYS */;
INSERT INTO `rd_competitors` VALUES
(1,'مؤسسه آموزش و توسعه منابع انسانی مؤسسه آموزشی آدان تهران (ITECC)','مؤسسه آموزشی آدان مرجع','https://itecc.tccim.ir','تهران / آنلاین سراسری',3450000,'حضوری و آنلاین هم‌زمان','برند معتبر اتاق تهران، دوره‌های به‌روز رفع تعهد ارزی، NTSW و قراردادهای بین‌المللی','تمرکز بر پایتخت، شهریه بالا برای SMEهای شهرستانی و عدم اتصال به پرونده کارت بازرگانی استان','۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59'),
(2,'مرکز آموزش بازرگانی وزارت صمت (IBTC)','مرکز تخصصی دولتی-بازرگانی','https://ibtc.ir/courses','تهران / آنلاین',2950000,'حضوری و مجازی','پوشش دقیق کدهای عملیاتی سامانه جامع تجارت، اظهار از راه دور EPL و ابزارهای ITC','فرمت کلاسیک‌تر و نبود زنجیره خودکار منتورینگ و کلینیک صنعتی','۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59'),
(3,'سازمان مدیریت صنعتی (IMI)','مدرسه عالی مدیریت','https://imiesf.org','مراکز استان‌ها',3150000,'حضوری کارگاهی بلندمدت','دوره‌های جامع ۹۸ ساعته مهارت‌های بازرگانی بین‌الملل و شبکه اساتید باسابقه','طولانی بودن دوره (۹۸ ساعت) برای مدیران پرمشغله صادراتی','۱۴۰۵/۰۷/۲۹','2026-10-23 21:48:59'),
(4,'مجتمع فنی تهران — دپارتمان بازرگانی (MFT)','مؤسسه آموزشی خصوصی','https://mftmirdamad.com','سراسری',3650000,'حضوری و آنلاین','بسته جامع ITP و تبلیغات گسترده در فضای وب','شهریه سنگین (۲۱۰ میلیون ریال) و عدم تمرکز اختصاصی بر فراگیران آدان','۱۴۰۵/۰۷/۲۹','2026-10-23 21:48:59'),
(5,'آکادمی مرجع بین‌المللی ICC (ICC Academy)','مرجع بین‌المللی پاریس/سنگاپور','https://icc.academy','بین‌المللی (آنلاین)',9800000,'تمام‌الکترونیکی انگلیسی','گواهی جهانی GTCP و استاندارد مرجع Incoterms 2020 و UCP 600','زبان صرفاً انگلیسی و دشواری پرداخت ارزی برای بنگاه‌های داخلی','۱۴۰۵/۰۷/۲۸','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `rd_competitors` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `rd_course_proposals`
--

DROP TABLE IF EXISTS `rd_course_proposals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `rd_course_proposals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `proposal_code` varchar(40) NOT NULL,
  `proposed_title` varchar(220) NOT NULL,
  `target_audience` varchar(180) NOT NULL,
  `recommended_hours` int(11) DEFAULT 24,
  `competitor_avg_rial` bigint(20) DEFAULT 68000000,
  `suggested_tuition_rial` bigint(20) DEFAULT 58000000,
  `breakeven_learners` int(11) DEFAULT 9,
  `projected_net_rial` bigint(20) DEFAULT 620000000,
  `strategic_rationale` text NOT NULL,
  `syllabus_outline` text NOT NULL,
  `ai_confidence_score` int(11) DEFAULT 92,
  `status` varchar(70) DEFAULT 'آماده طرح در شورای R&D',
  `launched_course_id` int(11) DEFAULT NULL,
  `created_shamsi` varchar(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `proposal_code` (`proposal_code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rd_course_proposals`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `rd_course_proposals` WRITE;
/*!40000 ALTER TABLE `rd_course_proposals` DISABLE KEYS */;
INSERT INTO `rd_course_proposals` VALUES
(1,'RD-1405-101','کارگاه جامع عملیاتی سامانه جامع تجارت (NTSW)، اظهار EPL گمرکی و رفع تعهد ارزی صادرکنندگان','مدیران بازرگانی، ترخیص‌کاران و متقاضیان کارت بازرگانی استان',24,109000000,68000000,8,896000000,'در رصد زنده رقبا، اتاق تهران و IBTC این عنوان را بین ۱۰۹ تا ۱۱۹ میلیون ریال عرضه می‌کنند در حالی که در کاتالوگ فعلی اتاق استان خالی است. عرضه ۲۴ ساعته کارگاهی با شهریه رقابتی ۶۸ میلیون ریال (۳۷٪ مزیت قیمتی برای فراگیران آدان) بالاترین نرخ تکمیل ظرفیت را ایجاد می‌کند.','۱. معماری سامانه NTSW و ثبت سفارش | ۲. تخصیص و نیمایی/تالار ارز تجاری | ۳. تشریفات اظهار از راه دور EPL | ۴. پیمانسپاری و رفع تعهد ارزی صادراتی | ۵. مدیریت ریسک جرایم گمرکی | ۶. کارگاه عملی روی پرونده واقعی',96,'آماده طرح در شورای R&D',NULL,'۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59'),
(2,'RD-1405-102','هوش مصنوعی عملیاتی در صادرات: شکار خریداران خارجی با TradeMap، تحلیل داده و اتوماسیون مذاکره','مدیران صادرات، واحدهای بازاریابی بین‌الملل و شرکت‌های دانش‌بنیان',16,48000000,39000000,7,512000000,'ترند شماره ۱ جست‌وجوی وب در ۱۴۰۵ با کمترین اشباع رقبا (۲۲٪). ترکیب ابزارهای ITC TradeMap با پرامپت‌نویسی تجاری AI مزیت منحصربه‌فردی نسبت به دوره‌های تئوری رقبا ایجاد می‌کند.','۱. استخراج تقاضای جهانی با ITC TradeMap و MacMap | ۲. اعتبارسنجی خریداران خارجی با OSINT و AI | ۳. تولید کاتالوگ و پروفرمای هوشمند چندزبانه | ۴. اتوماسیون مکاتبات و لینکدین B2B | ۵. شبیه‌ساز مذاکره تجاری با AI | ۶. پروژه عملی صادرات محصول کارخانه عضو',95,'آماده طرح در شورای R&D',NULL,'۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59'),
(3,'RD-1405-103','استاندارد کربن مرزی اتحادیه اروپا (EU CBAM) و گزارش‌دهی ردپای کربن صنایع صادراتی استان','مدیران عامل، مدیران انرژی/کیفیت و صادرات صنایع فولاد، سیمان، کاشی و پتروشیمی',16,89000000,64000000,6,740000000,'اقیانوس آبی مطلق (اشباع رقبا زیر ۱۵٪) با حاشیه سود B2B بسیار بالا برای قراردادهای سازمانی کارخانجات بزرگ استان.','۱. الزامات قانونی مقررات نهایی CBAM در ۲۰۲۶ | ۲. محاسبه انتشار مستقیم و غیرمستقیم (Scope 1 & 2) | ۳. تکمیل گزارش فصلی XML برای خریدار اروپایی | ۴. ممیزی و گواهی کربن | ۵. استراتژی کاهش جریمه کربنی | ۶. مطالعه موردی صنایع معدنی و فلزی',94,'آماده طرح در شورای R&D',NULL,'۱۴۰۵/۰۷/۲۹','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `rd_course_proposals` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `rd_web_signals`
--

DROP TABLE IF EXISTS `rd_web_signals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `rd_web_signals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `keyword_query` varchar(160) NOT NULL,
  `signal_title` varchar(255) NOT NULL,
  `source_engine` varchar(70) DEFAULT 'DuckDuckGo Live Web',
  `source_url` varchar(600) DEFAULT '',
  `demand_score` int(11) DEFAULT 88,
  `competition_saturation` int(11) DEFAULT 35,
  `opportunity_index` int(11) DEFAULT 82,
  `catalog_gap_status` varchar(90) DEFAULT 'شکاف طلایی کاتالوگ (پیشنهاد ساخت)',
  `discovered_shamsi` varchar(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rd_web_signals`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `rd_web_signals` WRITE;
/*!40000 ALTER TABLE `rd_web_signals` DISABLE KEYS */;
INSERT INTO `rd_web_signals` VALUES
(1,'ثبت سفارش NTSW و رفع تعهد ارزی صادرات','جهش تقاضای مدیران بازرگانی برای کارگاه عملی سامانه جامع تجارت (NTSW)، تالار ارز تجاری و اظهار EPL گمرک','کاوشگر زنده وب فارسی','https://itecc.ir/',96,28,92,'شکاف طلایی کاتالوگ (پیشنهاد فوری ساخت)','۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59'),
(2,'هوش مصنوعی در صادرات و بازارشناسی ITC','ترند اول آموزش‌های نوین مؤسسات آموزشی: کاربرد هوش مصنوعی و TradeMap در کشف خریداران خارجی واقعی','کاوشگر زنده وب فارسی','https://ibtc.ir/courses',94,22,94,'شکاف طلایی کاتالوگ (پیشنهاد فوری ساخت)','۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59'),
(3,'مالیات کربن مرزی اتحادیه اروپا CBAM صنایع فولاد و پتروشیمی','الزام جدید گزارش‌دهی کربن مرزی اروپا (EU CBAM) برای صادرکنندگان فولاد، سیمان، آلومینیوم و کود شیمیایی','Google News RSS Global','https://taxation-customs.ec.europa.eu/carbon-border-adjustment-mechanism_en',91,15,95,'اقیانوس آبی مطلق در استان (بدون رقیب)','۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59'),
(4,'تهاتر ارزی، تسویه درهمی/یوانی و قراردادهای تجارت متقابل','نیاز حاد صادرکنندگان به راهکارهای حقوقی-مالی تسویه بین‌المللی و فین‌تک‌های فرامرزی در شرایط تحریم','کاوشگر زنده وب فارسی','https://news.tccim.ir/',93,30,89,'شکاف طلایی کاتالوگ (پیشنهاد فوری ساخت)','۱۴۰۵/۰۷/۲۹','2026-10-23 21:48:59'),
(5,'موافقت‌نامه تجارت آزاد ایران و اتحادیه اقتصادی اوراسیا (EAEU)','صفر شدن تعرفه گمرکی ۸۷٪ کالاها با روسیه، قزاقستان و ارمنستان — جهش تقاضای کارگاه صادرات به اوراسیا','کاوشگر زنده وب فارسی','https://ibtc.ir/',89,34,83,'پوشش نسبی — نیازمند نسخه پیشرفته عملیاتی','۱۴۰۵/۰۷/۲۹','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `rd_web_signals` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `research_peer_reviews`
--

DROP TABLE IF EXISTS `research_peer_reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `research_peer_reviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `reviewer_alias` varchar(90) NOT NULL,
  `scientific_score` int(11) DEFAULT 85,
  `applicability_score` int(11) DEFAULT 90,
  `recommendation` varchar(60) DEFAULT 'تأیید و آزادسازی قسط بودجه',
  `review_comment` text DEFAULT NULL,
  `reviewed_shamsi` varchar(25) DEFAULT '',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `research_peer_reviews`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `research_peer_reviews` WRITE;
/*!40000 ALTER TABLE `research_peer_reviews` DISABLE KEYS */;
INSERT INTO `research_peer_reviews` VALUES
(1,1,'داور ناشناس کد DR-104 (استاد اقتصاد بین‌الملل)',91,94,'تأیید و آزادسازی قسط دوم بودجه','جامعه آماری واحدهای صادراتی استان کاملاً معرف است و پیشنهادهای سیاستی قابلیت طرح در شورای گفت‌وگوی دولت و بخش خصوصی را دارد.','۱۴۰۵/۰۷/۲۷','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `research_peer_reviews` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `research_projects`
--

DROP TABLE IF EXISTS `research_projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `research_projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(220) NOT NULL,
  `lead_researcher` varchar(150) NOT NULL,
  `methodology` varchar(150) DEFAULT 'پیمایشی - مصاحبه عمیق با صادرکنندگان نمونه',
  `budget_rial` bigint(20) DEFAULT 650000000,
  `progress_pct` int(11) DEFAULT 65,
  `form_id` int(11) DEFAULT NULL,
  `publication_summary` text DEFAULT NULL,
  `status` enum('proposal','fieldwork','published') DEFAULT 'fieldwork',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `research_projects`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `research_projects` WRITE;
/*!40000 ALTER TABLE `research_projects` DISABLE KEYS */;
INSERT INTO `research_projects` VALUES
(1,'اطلس نیازسنجی مهارت‌های صادراتی و هوش مصنوعی ۵۰۰ بنگاه صنعتی استان در افق ۱۴۰۷','دکتر امیرحسین نیکزاد و گروه پژوهش اتاق','ترکیبی (پیمایش کمّی فرم‌ساز + ۲۴ مصاحبه عمیق با صادرکنندگان نمونه)',780000000,78,1,'یافته کلیدی: ۷۴٪ واحدهای صنعتی استان کمبود نیروی مسلط به مذاکره انگلیسی تجاری، CBAM و تحلیل بازار با AI را مهم‌ترین مانع توسعه صادرات اعلام کردند.','fieldwork');
/*!40000 ALTER TABLE `research_projects` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `saved_reports`
--

DROP TABLE IF EXISTS `saved_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `saved_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(180) NOT NULL,
  `dataset_key` varchar(60) NOT NULL,
  `filter_expr` varchar(120) DEFAULT NULL,
  `cron_schedule` varchar(60) DEFAULT '0 7 * * 6',
  `ai_insight` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saved_reports`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `saved_reports` WRITE;
/*!40000 ALTER TABLE `saved_reports` DISABLE KEYS */;
INSERT INTO `saved_reports` VALUES
(1,'گزارش عملکرد ثبت‌نام و ظرفیت دوره‌های فعال پاییز ۱۴۰۵','courses_summary','published','0 8 * * 6','تحلیل هوشمند: دوره‌های حوزه صادرات و سامانه مؤدیان بالاترین نرخ تکمیل ظرفیت (۹۳٪) و بیشترین حاشیه سود خالص را در سبد آموزشی آدان دارند.',1,'2026-10-23 21:48:59'),
(2,'گزارش قیف فروش قراردادهای سازمانی بالای ۵۰۰ میلیون ریال','crm_pipeline','all','0 9 1 * *','تحلیل هوشمند: با نهایی‌سازی ۲ پرونده در مرحله مذاکره نهایی، ۲.۳۷ میلیارد ریال به درآمد قطعی آبان‌ماه افزوده می‌شود.',4,'2026-10-23 21:48:59');
/*!40000 ALTER TABLE `saved_reports` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sayad_cheques`
--

DROP TABLE IF EXISTS `sayad_cheques`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sayad_cheques` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sayad_16digit` varchar(20) NOT NULL,
  `drawer_company` varchar(190) NOT NULL,
  `bank_name` varchar(90) NOT NULL,
  `amount_rial` bigint(20) NOT NULL DEFAULT 0,
  `due_shamsi` varchar(20) NOT NULL,
  `inquiry_color` varchar(40) DEFAULT 'سفید - بدون چک برگشتی',
  `clearance_status` varchar(40) DEFAULT 'در جریان وصول',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `sayad_16digit` (`sayad_16digit`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sayad_cheques`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sayad_cheques` WRITE;
/*!40000 ALTER TABLE `sayad_cheques` DISABLE KEYS */;
INSERT INTO `sayad_cheques` VALUES
(1,'1045998877665544','شرکت صنایع فولاد کاوه (دانش‌پذیر آدان)','بانک ملت',420000000,'۱۴۰۵/۰۸/۱۵','سفید - خوش‌حساب','در جریان وصول','2026-10-23 21:48:59'),
(2,'2098112233445566','گروه بازرگانی خشکبار زرین','بانک سامان',185000000,'۱۴۰۵/۰۷/۲۵','سفید - خوش‌حساب','وصول شده به دفترکل','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `sayad_cheques` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `scorm_cmi_tracks`
--

DROP TABLE IF EXISTS `scorm_cmi_tracks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scorm_cmi_tracks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `lesson_id` int(11) NOT NULL DEFAULT 1,
  `sco_identifier` varchar(120) DEFAULT 'INCOTERMS_2020_SCO_01',
  `lesson_status` varchar(40) DEFAULT 'incomplete',
  `score_raw` decimal(6,2) DEFAULT 0.00,
  `score_max` decimal(6,2) DEFAULT 100.00,
  `session_time` varchar(30) DEFAULT '00:05:12',
  `lesson_location` varchar(120) DEFAULT 'slide_1',
  `suspend_data` text DEFAULT NULL,
  `cmi_json` longtext DEFAULT NULL,
  `commit_count` int(11) DEFAULT 1,
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_scorm_user_lesson` (`user_id`,`lesson_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scorm_cmi_tracks`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `scorm_cmi_tracks` WRITE;
/*!40000 ALTER TABLE `scorm_cmi_tracks` DISABLE KEYS */;
INSERT INTO `scorm_cmi_tracks` VALUES
(1,1,3,'INCOTERMS_2020_SCO_01','incomplete',60.00,100.00,'00:08:45','slide_2','{\"step\":2,\"selected\":\"FOB\"}',NULL,2,'2026-10-23 21:48:59'),
(2,7,3,'INCOTERMS_2020_SCO_01','completed',100.00,100.00,'00:19:20','slide_3','{\"step\":3,\"selected\":\"CIF\"}',NULL,4,'2026-10-23 21:48:59');
/*!40000 ALTER TABLE `scorm_cmi_tracks` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `security_soc_telemetry`
--

DROP TABLE IF EXISTS `security_soc_telemetry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `security_soc_telemetry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_code` varchar(40) NOT NULL,
  `actor_username` varchar(100) NOT NULL,
  `client_ip` varchar(60) NOT NULL,
  `geo_and_device` varchar(160) NOT NULL,
  `risk_score` int(11) NOT NULL DEFAULT 12,
  `threat_classification` varchar(160) NOT NULL,
  `mitigation_action` varchar(160) NOT NULL,
  `detected_shamsi` varchar(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `event_code` (`event_code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_soc_telemetry`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `security_soc_telemetry` WRITE;
/*!40000 ALTER TABLE `security_soc_telemetry` DISABLE KEYS */;
INSERT INTO `security_soc_telemetry` VALUES
(1,'SOC-9001','admin','185.143.233.12','تهران — مرورگر سازمانی تأییدشده (TLS 1.3)',8,'نشست ایمن و مورد تأیید (Zero-Trust Verified)','مجوز کامل دسترسی صادر شد','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(2,'SOC-9002','unknown_probe','91.214.124.88','تلاش ۶ بار رمز اشتباه در ۲۰ ثانیه — آی‌پی ناشناس',88,'تلاش نفوذ Brute-Force روی حساب سازمانی','مسدودسازی خودکار ۱۵ دقیقه‌ای IP و ثبت در ممیزی امنیتی','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `security_soc_telemetry` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `session_attendance`
--

DROP TABLE IF EXISTS `session_attendance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `session_attendance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` enum('present','absent','late','excused') DEFAULT 'present',
  `note` varchar(200) DEFAULT NULL,
  `recorded_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_sess_user` (`session_id`,`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `session_attendance`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `session_attendance` WRITE;
/*!40000 ALTER TABLE `session_attendance` DISABLE KEYS */;
INSERT INTO `session_attendance` VALUES
(1,1,7,'present','حضور کامل و مشارکت در کارگاه','2026-10-23 21:48:59'),
(2,1,8,'present','حضور به‌موقع','2026-10-23 21:48:59'),
(3,2,7,'present','ارائه پرونده واقعی صادراتی','2026-10-23 21:48:59'),
(4,2,8,'late','۱۵ دقیقه تأخیر به دلیل پرواز استانی','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `session_attendance` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sme_subsidy_allocations`
--

DROP TABLE IF EXISTS `sme_subsidy_allocations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sme_subsidy_allocations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `alloc_code` varchar(40) NOT NULL,
  `sme_company_name` varchar(180) NOT NULL,
  `employees_count` int(11) DEFAULT 45,
  `export_readiness_idx` int(11) DEFAULT 72,
  `requested_subsidy_pct` int(11) DEFAULT 50,
  `ai_approved_subsidy_pct` int(11) DEFAULT 38,
  `economic_roi_multiplier` decimal(4,2) DEFAULT 4.20,
  `priority_rank_label` varchar(90) NOT NULL,
  `allocated_shamsi` varchar(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `alloc_code` (`alloc_code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sme_subsidy_allocations`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sme_subsidy_allocations` WRITE;
/*!40000 ALTER TABLE `sme_subsidy_allocations` DISABLE KEYS */;
INSERT INTO `sme_subsidy_allocations` VALUES
(1,'SUB-AI-301','شرکت دانش‌بنیان تجهیز دقیق اسپادانا',62,86,50,45,5.40,'اولویت اول طلایی (ضریب بازگشت اقتصادی ۵.۴ برابر)','۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59'),
(2,'SUB-AI-302','واحد تولیدی فرآورده‌های کنجدی کویر',38,74,45,35,4.15,'اولویت دوم (صادرات‌اول با اشتغال بالا)','۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59'),
(3,'SUB-AI-303','کارگاه بسته‌بندی کارتن نفیس شرق',24,65,40,28,3.20,'اولویت سوم (تکمیل‌کننده زنجیره تأمین صادراتی)','۱۴۰۵/۰۷/۲۹','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `sme_subsidy_allocations` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `social_media_posts`
--

DROP TABLE IF EXISTS `social_media_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `social_media_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_code` varchar(50) NOT NULL,
  `campaign_id` int(11) DEFAULT 1,
  `platform` varchar(40) NOT NULL DEFAULT 'instagram',
  `content_format` varchar(60) NOT NULL DEFAULT 'پست اسلایدی (Carousel)',
  `target_course_title` varchar(190) NOT NULL,
  `hook_headline` varchar(220) NOT NULL,
  `caption_body` text NOT NULL,
  `hashtags` varchar(255) NOT NULL DEFAULT '#آموزش_حسابداری_آدان #آموزش_صادرات #تجارت_بین_الملل',
  `utm_url` varchar(255) NOT NULL DEFAULT 'https://chamber.ir/tms?utm_source=instagram&utm_medium=social',
  `promo_code` varchar(40) NOT NULL DEFAULT 'ADN-INSTA20',
  `scheduled_shamsi` varchar(60) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۶ — ساعت ۱۹:۳۰',
  `impressions_count` int(11) NOT NULL DEFAULT 0,
  `engagements_count` int(11) NOT NULL DEFAULT 0,
  `clicks_count` int(11) NOT NULL DEFAULT 0,
  `leads_generated` int(11) NOT NULL DEFAULT 0,
  `enrollments_converted` int(11) NOT NULL DEFAULT 0,
  `spend_rial` bigint(20) NOT NULL DEFAULT 0,
  `revenue_rial` bigint(20) NOT NULL DEFAULT 0,
  `publish_status` varchar(30) NOT NULL DEFAULT 'scheduled_local',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `post_code` (`post_code`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `social_media_posts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `social_media_posts` WRITE;
/*!40000 ALTER TABLE `social_media_posts` DISABLE KEYS */;
INSERT INTO `social_media_posts` VALUES
(1,'SOC-IG-101',1,'instagram','پست اسلایدی ۸ برگی (Carousel)','جامع کاربردی اینکوترمز ۲۰۲۰ و اسناد حمل','۳ اشتباه مرگبار در قراردادهای صادراتی که سود یک سال کارخانه را می‌بلعد!','ورق بزنید 👉 در اسلاید ۴ واقعی‌ترین پرونده خسارت بندرعباس را باز کردیم!\nاگر مدیر بازرگانی یا صادرکننده هستید، انتخاب اشتباه بین FOB و FCA می‌تواند هزاران دلار ریسک بیمه‌نشده روی دست شما بگذارد.\n✅ کارگاه عملی ۲۴ ساعته مرکز آموزش مؤسسه آموزشی آدان با گواهی رسمی دوزبانه QR\n🎁 ۲۵٪ تخفیف ویژه فراگیران آدان با کد ADN-INSTA25','#آموزش_حسابداری_آدان #صادرات #اینکوترمز #بازرگانی_خارجی #گمرک #مدیران_صنعت','https://chamber.ir/tms?utm_source=instagram&utm_campaign=incoterms1405','ADN-INSTA25','۱۴۰۵/۰۸/۰۵ — ساعت ۲۰:۰۰ (ساعت طلایی)',28400,2690,940,76,19,45000000,893000000,'published','2026-10-23 21:48:59'),
(2,'SOC-LI-102',1,'linkedin','مقاله تحلیلی مدیریتی B2B','مقررات مکانیسم تعدیل کربن مرزی اتحادیه اروپا (CBAM)','هشدار استراتژیک به مدیران‌عامل صنایع فولاد، سیمان، آلومینیوم و پتروشیمی استان','از ژانویه ۲۰۲۶ واردکنندگان اروپایی بدون گزارش ردپای کربن تأییدشده (EU CBAM) امکان ترخیص محموله‌های صنعتی را ندارند.\nواحد آموزش مؤسسه آموزشی آدان برای نخستین‌بار در استان، کارگاه تخصصی «ممیزی و گزارش‌دهی عملی CBAM» را با حضور اساتید بین‌المللی برگزار می‌کند.\n🔗 رزرو سهمیه سازمانی ویژه کارخانجات در لینک کامنت اول.','#EUCBAM #صادرات_صنعتی #فولاد #سیمان #مدیریت_ارشد #آموزش_حسابداری_آدان','https://chamber.ir/tms?utm_source=linkedin&utm_campaign=cbam_exec','B2B-LINKEDIN','۱۴۰۵/۰۸/۰۶ — ساعت ۰۹:۳۰ صبح کاری',16900,1420,680,54,16,30000000,1152000000,'published','2026-10-23 21:48:59'),
(3,'SOC-TG-103',1,'telegram','پست کانال فوری + دکمه شیشه‌ای ثبت‌نام','قوانین سامانه مؤدیان و دفاعیه مالیاتی','🚨 ظرفیت باقی‌مانده فقط ۶ صندلی | کارگاه عملی لایحه‌نویسی و سامانه مؤدیان','📊 همکاران مالی و حسابداران ارشد واحدهای تولیدی:\nصفر تا صد رفع مغایرت کارپوشه مؤدیان، معافیت‌های ماده ۱۲ و تنظیم لایحه دفاعیه هیئت حل اختلاف در ۱۶ ساعت کارگاه عملی روی پرونده واقعی!\n👇 ثبت‌نام آنی با تخفیف ویژه کانال رسمی آموزشی آدان:','#سامانه_مودیان #مالیات #حسابداری #مدیر_مالی #آموزش_حسابداری_آدان','https://chamber.ir/tms?utm_source=telegram&utm_campaign=tax_pro','TG-VIP15','۱۴۰۵/۰۸/۰۷ — ساعت ۱۱:۰۰ صبح',22100,1850,810,62,17,22000000,697000000,'published','2026-10-23 21:48:59'),
(4,'SOC-ET-104',1,'eitaa','اطلاعیه رسمی کانال ایتا و بله اعضا','آموزش متقاضیان صدور و تمدید کارت بازرگانی','تقویم جدید کلاس‌های الزامی صدور و تمدید کارت بازرگانی (پاییز ۱۴۰۵) منتشر شد','به اطلاع متقاضیان محترم صدور و تمدید کارت بازرگانی استان می‌رساند ثبت‌نام گروه جدید دوره‌های آموزشی الزامی با برگزاری ترکیبی و صدور گواهی آنی آغاز گردید.','#کارت_بازرگانی #تاجران #آموزش_حسابداری_آدان','https://chamber.ir/commercial-card?utm_source=eitaa&utm_campaign=card1405','CARD-1405','۱۴۰۵/۰۸/۰۸ — ساعت ۱۰:۰۰ صبح',19300,1340,720,68,24,12000000,768000000,'scheduled','2026-10-23 21:48:59'),
(5,'SOC-YT-105',1,'youtube','ویدئو کوتاه آموزشی (Shorts / آپارات)','هوش مصنوعی در شکار خریدار خارجی و بازاریابی B2B','چطور با هوش مصنوعی در ۱۰ دقیقه لیست ۵۰ واردکننده واقعی کالای خود در عراق و عمان را پیدا کنیم؟','در این ویدئوی ۹۰ ثانیه‌ای ۳ پرامپت طلایی تحلیل کد تعرفه HS Code و استخراج خریداران خارجی را نشان دادیم! نسخه کامل در کارگاه عملی هفته آینده مؤسسه آموزشی آدان.','#هوش_مصنوعی #صادرات_عراق #بازاریابی_بین_المللی #HSCode','https://chamber.ir/tms?utm_source=youtube&utm_campaign=ai_export','YT-AI20','۱۴۰۵/۰۸/۰۹ — ساعت ۲۱:۰۰',34800,3920,1120,89,21,28000000,966000000,'scheduled','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `social_media_posts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sso_pki_logs`
--

DROP TABLE IF EXISTS `sso_pki_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sso_pki_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_full_name` varchar(160) NOT NULL,
  `national_code` varchar(20) NOT NULL,
  `mobile_number` varchar(20) NOT NULL,
  `shahkar_status` varchar(100) DEFAULT 'شبیه‌سازی محلی - اتصال شاهکار انجام نشده',
  `document_title` varchar(200) NOT NULL,
  `pki_hash_sha256` varchar(128) NOT NULL,
  `signed_shamsi` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sso_pki_logs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sso_pki_logs` WRITE;
/*!40000 ALTER TABLE `sso_pki_logs` DISABLE KEYS */;
INSERT INTO `sso_pki_logs` VALUES
(1,'دکتر کیارش رادمهر','0061234567','09121112233','تطبیق هویت شبیه‌ساز تأیید شد','قرارداد آموزشی سازمانی فولاد زاگرس (CTR-1405-01)','7f83b1657ff1fc53b92dc18148a1d65dfc2d4b1fa3d677284addd200126d9069','۱۴۰۵/۰۷/۲۸ ساعت ۱۰:۱۵');
/*!40000 ALTER TABLE `sso_pki_logs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `standard_test_catalog`
--

DROP TABLE IF EXISTS `standard_test_catalog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `standard_test_catalog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `test_code` varchar(40) NOT NULL,
  `category_key` varchar(40) NOT NULL,
  `category_label` varchar(90) NOT NULL,
  `title_fa` varchar(200) NOT NULL,
  `standard_ref` varchar(120) NOT NULL,
  `duration_min` int(11) DEFAULT 10,
  `items_count` int(11) DEFAULT 6,
  `scale_type` varchar(40) DEFAULT 'psychometric',
  `summary_text` varchar(255) NOT NULL,
  `recommended_course` varchar(190) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `test_code` (`test_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `standard_test_catalog`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `standard_test_catalog` WRITE;
/*!40000 ALTER TABLE `standard_test_catalog` DISABLE KEYS */;
/*!40000 ALTER TABLE `standard_test_catalog` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `standard_test_results`
--

DROP TABLE IF EXISTS `standard_test_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `standard_test_results` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `report_code` varchar(45) NOT NULL,
  `user_id` int(11) NOT NULL,
  `test_code` varchar(40) NOT NULL,
  `test_title` varchar(200) NOT NULL,
  `result_badge` varchar(140) NOT NULL,
  `score_pct` int(11) DEFAULT 85,
  `interpretation_text` text NOT NULL,
  `recommended_course` varchar(190) NOT NULL,
  `dimensions_json` text DEFAULT NULL,
  `completed_shamsi` varchar(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `report_code` (`report_code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `standard_test_results`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `standard_test_results` WRITE;
/*!40000 ALTER TABLE `standard_test_results` DISABLE KEYS */;
INSERT INTO `standard_test_results` VALUES
(1,'STR-1405-901',7,'MBTI','تیپ‌شناسی شخصیت مایرز-بریگز (MBTI)','ENTJ — فرمانده و استراتژیست سازمانی',88,'گرایش بارز به تصمیم‌گیری تحلیلی، برنامه‌ریزی کلان و هدایت مذاکرات بین‌المللی؛ پیشنهاد تقویت شنیدن فعال در جلسات تیمی.','برنامه عالی توسعه رهبری مدیران صنایع','{\"برون‌گرایی (E)\":82,\"شهود راهبردی (N)\":78,\"منطق تحلیلی (T)\":91,\"ساختارمندی (J)\":86}','۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59'),
(2,'STR-1405-902',8,'CEFR_EN','تعیین سطح استاندارد زبان انگلیسی (CEFR A1–C2)','سطح C1 Advanced (پیشرفته تجاری)',86,'تسلط عالی بر ساختارهای پیشرفته، درک متون حقوقی-تجاری و مکاتبات بین‌المللی؛ آماده ورود مستقیم به کارگاه قراردادهای انگلیسی.','تنظیم قراردادهای تجاری بین‌المللی به زبان انگلیسی','{\"گرامر پیشرفته\":90,\"واژگان آکادمیک و تجاری\":85,\"درک مطلب تحلیلی\":84,\"کاربرد اصطلاحی\":85}','۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59'),
(3,'STR-1405-903',7,'HOLLAND','رغبت‌سنج و استعدادیابی شغلی جان هالند (RIASEC)','کد شغلی ECS — مدیریت بازرگانی، مذاکره و مالی',91,'بالاترین تناسب با سمت‌های مدیر صادرات، توسعه بازار بین‌الملل، مدیریت فروش سازمانی B2B و تحلیلگر بازرگانی.','دوره جامع مدیریت صادرات و اینکوترمز ۲۰۲۰','{\"متهور/مدیر (E)\":94,\"قراردادی/مالی (C)\":88,\"اجتماعی/مذاکره (S)\":82,\"جست‌وجوگر (I)\":74}','۱۴۰۵/۰۷/۲۹','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `standard_test_results` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `support_tickets`
--

DROP TABLE IF EXISTS `support_tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `support_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `subject` varchar(200) NOT NULL,
  `department` varchar(80) DEFAULT 'آموزش و گواهی‌نامه‌ها',
  `message` text NOT NULL,
  `reply_text` text DEFAULT NULL,
  `status` enum('open','answered','closed') DEFAULT 'open',
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_tickets`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `support_tickets` WRITE;
/*!40000 ALTER TABLE `support_tickets` DISABLE KEYS */;
INSERT INTO `support_tickets` VALUES
(1,6,'درخواست افزودن ۴ نفر جدید به فهرست ثبت‌نام گروهی فولاد زاگرس','قراردادهای سازمانی','سلام، لطفاً سهمیه ۴ کارشناس جدید واحد صادرات شرکت را در اجرای آبان‌ماه فعال فرمایید.','با سلام، سهمیه از محل قرارداد CNT-1405-401 تأیید و فعال گردید.','answered','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `support_tickets` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `system_settings`
--

DROP TABLE IF EXISTS `system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_settings` (
  `setting_key` varchar(120) NOT NULL,
  `setting_value` longtext DEFAULT NULL,
  `category` varchar(60) DEFAULT 'general',
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_settings`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `system_settings` WRITE;
/*!40000 ALTER TABLE `system_settings` DISABLE KEYS */;
INSERT INTO `system_settings` VALUES
('active_ai_provider','ai','ai','2026-10-23 21:48:59'),
('ai_api_key','','ai','2026-10-23 21:48:59'),
('ai_base_url','https://api.openai.com/v1','ai','2026-10-23 21:48:59'),
('ai_default_model','gpt-4o-mini','ai','2026-10-23 21:48:59'),
('chamber_name','مؤسسه آموزشی آدان','general','2026-10-23 21:48:59'),
('enrollment_api_token','','integration','2026-10-23 21:48:59'),
('fiscal_year','۱۴۰۵','finance','2026-10-23 21:48:59'),
('ollama_base_url','http://127.0.0.1:11434/v1','ai','2026-10-23 21:48:59'),
('search_api_key','','integration','2026-10-23 21:48:59'),
('telegram_bot_username','@ChamberEduSmartBot','integration','2026-10-23 21:48:59'),
('unit_name','آموزش تخصصی حسابداری و امور مالی','general','2026-10-23 21:48:59'),
('vat_percent','10','finance','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `system_settings` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tax_moadian_packets`
--

DROP TABLE IF EXISTS `tax_moadian_packets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tax_moadian_packets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `tax_unique_id_22` varchar(30) NOT NULL,
  `invoice_pattern` varchar(60) DEFAULT 'الگوی اول - فروش خدمات آموزشی',
  `accounting_target` enum('سپیدار همکاران','همکاران سیستم','هلو','محک') DEFAULT 'سپیدار همکاران',
  `payload_sha256` varchar(128) NOT NULL,
  `submission_status` varchar(60) DEFAULT 'پیش‌نویس محلی - ارسال نشده',
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tax_moadian_packets`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tax_moadian_packets` WRITE;
/*!40000 ALTER TABLE `tax_moadian_packets` DISABLE KEYS */;
INSERT INTO `tax_moadian_packets` VALUES
(1,1,'','الگوی اول - فروش خدمات آموزشی','سپیدار همکاران','e3b0c44298fc1c149afbf4c8996fb92427ae41e4','پیش‌نویس محلی - ارسال نشده','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `tax_moadian_packets` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tms_dynamic_pricing_rules`
--

DROP TABLE IF EXISTS `tms_dynamic_pricing_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tms_dynamic_pricing_rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course_code` varchar(40) NOT NULL,
  `course_title` varchar(200) NOT NULL,
  `base_tuition_rial` bigint(20) NOT NULL,
  `seat_fill_pct` int(11) DEFAULT 78,
  `days_to_start` int(11) DEFAULT 6,
  `ai_pricing_tier` varchar(110) NOT NULL,
  `dynamic_tuition_rial` bigint(20) NOT NULL,
  `projected_revenue_gain_pct` int(11) DEFAULT 18,
  `updated_shamsi` varchar(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tms_dynamic_pricing_rules`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tms_dynamic_pricing_rules` WRITE;
/*!40000 ALTER TABLE `tms_dynamic_pricing_rules` DISABLE KEYS */;
INSERT INTO `tms_dynamic_pricing_rules` VALUES
(1,'TRD-101','جامع اینکوترمز ۲۰۲۰ و اعتبارات اسنادی UCP600',52000000,94,4,'تقاضای اوج (Surge) — افتتاح خودکار گروه دوم بدون تخفیف',56000000,24,'۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59'),
(2,'TAX-204','سامانه مؤدیان و دادرسی مالیاتی صنایع',38000000,56,3,'بسته تکمیل صندلی ۷۲ ساعت پایانی (B2B Last-Minute -18%)',31160000,19,'۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59'),
(3,'AI-EXP-09','شکار خریداران خارجی با هوش مصنوعی و TradeMap',44000000,32,21,'نرخ تشویقی ثبت‌نام زودهنگام (Early-Bird -15%)',37400000,15,'۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `tms_dynamic_pricing_rules` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tms_learning_paths`
--

DROP TABLE IF EXISTS `tms_learning_paths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tms_learning_paths` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `path_code` varchar(50) NOT NULL,
  `title` varchar(190) NOT NULL,
  `target_persona` varchar(150) NOT NULL DEFAULT 'مدیران بازرگانی و صادرات',
  `level_badge` varchar(60) NOT NULL DEFAULT 'دیپلم جامع حرفه‌ای',
  `courses_json` text NOT NULL,
  `total_hours` int(11) NOT NULL DEFAULT 48,
  `bundle_tuition_rial` bigint(20) NOT NULL DEFAULT 95000000,
  `discount_pct` int(11) NOT NULL DEFAULT 22,
  `enrolled_learners` int(11) NOT NULL DEFAULT 18,
  `ai_roadmap_summary` text DEFAULT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'active',
  `created_shamsi` varchar(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `path_code` (`path_code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tms_learning_paths`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tms_learning_paths` WRITE;
/*!40000 ALTER TABLE `tms_learning_paths` DISABLE KEYS */;
INSERT INTO `tms_learning_paths` VALUES
(1,'PATH-EXP-01','دیپلم جامع مدیریت صادرات، اینکوترمز ۲۰۲۰ و رفع تعهد ارزی','مدیران بازرگانی خارجی و صادرکنندگان نمونه','دیپلم عالی ۳ مرحله‌ای','[\"جامع کاربردی اینکوترمز ۲۰۲۰ و اسناد حمل\",\"مقررات مکانیسم تعدیل کربن مرزی اتحادیه اروپا (CBAM)\",\"اعتبارات اسنادی UCP 600 و بانکداری بین‌الملل\"]',56,128000000,25,29,'طراحی‌شده بر اساس بیشترین شکاف مهارتی واحدهای صادراتی استان؛ تکمیل هر ۳ گام منجر به صدور گواهینامه جامع دوزبانه QR می‌شود.','active','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(2,'PATH-FIN-02','مسیر خبرگی مالیات ستانی نوین، سامانه مؤدیان و دفاعیه مالیاتی','مدیران مالی و حسابداران ارشد صنایع','گواهینامه تخصصی ۲ مرحله‌ای','[\"قوانین سامانه مؤدیان و پایانه‌های فروشگاهی\",\"دادرسی مالیاتی و لایحه‌نویسی هیئت‌های حل اختلاف\"]',36,82000000,20,34,'پوشش صددرصدی نیازهای اجرایی واحدهای مالی کارخانجات دانش‌پذیر آدان.','active','۱۴۰۵/۰۸/۰۲','2026-10-23 21:48:59'),
(3,'PATH-AI-03','آکادمی تحول دیجیتال و هوش مصنوعی کاربردی در صنعت و بازرگانی','مدیران‌عامل، مدیران R&D و فروش سازمانی','مسیر ویژه مدیران آینده','[\"هوش مصنوعی در شکار خریدار خارجی و بازاریابی B2B\",\"اتوماسیون فرایندهای بازرگانی و تحلیل داده گمرکی\"]',40,96000000,22,22,'مسیر پیشرو اقیانوس آبی با بالاترین نرخ رضایت و بازگشت سرمایه سریع برای بنگاه‌ها.','active','۱۴۰۵/۰۸/۰۳','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `tms_learning_paths` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tms_pricing_scenarios`
--

DROP TABLE IF EXISTS `tms_pricing_scenarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tms_pricing_scenarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `scenario_code` varchar(50) NOT NULL,
  `course_title` varchar(190) NOT NULL,
  `base_tuition_rial` bigint(20) NOT NULL DEFAULT 48000000,
  `member_discount_pct` int(11) NOT NULL DEFAULT 25,
  `early_bird_pct` int(11) NOT NULL DEFAULT 10,
  `instructor_total_cost_rial` bigint(20) NOT NULL DEFAULT 180000000,
  `venue_ops_cost_rial` bigint(20) NOT NULL DEFAULT 65000000,
  `predicted_enrollments` int(11) NOT NULL DEFAULT 26,
  `breakeven_seats` int(11) NOT NULL DEFAULT 7,
  `projected_net_profit_rial` bigint(20) NOT NULL DEFAULT 690000000,
  `created_shamsi` varchar(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `scenario_code` (`scenario_code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tms_pricing_scenarios`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tms_pricing_scenarios` WRITE;
/*!40000 ALTER TABLE `tms_pricing_scenarios` DISABLE KEYS */;
INSERT INTO `tms_pricing_scenarios` VALUES
(1,'PRC-1405-01','جامع کاربردی اینکوترمز ۲۰۲۰ و اسناد حمل بین‌المللی',52000000,25,10,190000000,68000000,28,7,834000000,'۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(2,'PRC-1405-02','مقررات مکانیسم کربن مرزی اروپا (EU CBAM) ویژه صنایع',72000000,25,15,240000000,75000000,24,6,981000000,'۱۴۰۵/۰۸/۰۲','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `tms_pricing_scenarios` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `trade_contract_redlines`
--

DROP TABLE IF EXISTS `trade_contract_redlines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `trade_contract_redlines` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `audit_code` varchar(40) NOT NULL,
  `contract_title` varchar(190) NOT NULL,
  `counterparty_country` varchar(80) NOT NULL,
  `submitted_clause` text NOT NULL,
  `safety_score_pct` int(11) DEFAULT 54,
  `detected_traps` varchar(255) NOT NULL,
  `icc_protective_rewrite` text NOT NULL,
  `audited_shamsi` varchar(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `audit_code` (`audit_code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trade_contract_redlines`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `trade_contract_redlines` WRITE;
/*!40000 ALTER TABLE `trade_contract_redlines` DISABLE KEYS */;
INSERT INTO `trade_contract_redlines` VALUES
(1,'RED-1405-01','قرارداد فروش ۴۰۰ تن پسته صادراتی (CIF Dubai)','امارات متحده عربی','Payment 100% Open Account 90 days after arrival; Buyer courts have exclusive jurisdiction; Delivery CIF Jebel Ali without edition year.',38,'۳ تله حقوقی خطرناک: ۱) پرداخت ۱۰۰٪ حساب باز بدون تضمین بانکی | ۲) صلاحیت انحصاری دادگاه کشور خریدار | ۳) عدم قید ویرایش Incoterms 2020','1) Payment: 30% Advance T/T + 70% Irrevocable Confirmed Sight L/C subject to UCP 600. 2) Delivery: CIF Jebel Ali Port (Incoterms® 2020). 3) Dispute Resolution: ICC Arbitration Rules (Seat: Istanbul/Tehran), English language.','۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59'),
(2,'RED-1405-02','قرارداد تأمین کاشی پرسلان ساختمانی (FCA Factory)','قزاقستان (اوراسیا)','Seller pays all destination customs delays and unlimited penalty of 2% per day without cap.',46,'۲ تله پرریسک: ۱) جریمه تأخیر روزانه ۲٪ بدون سقف (Uncapped Liquidated Damages) | ۲) تحمیل ریسک گمرک مقصد به فروشنده در ترم FCA','Liquidated damages for delay solely attributable to Seller shall be 0.5% per completed week of delay up to a maximum aggregate cap of 5% of delayed shipment value (ICC Model Clause).','۱۴۰۵/۰۷/۲۹','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `trade_contract_redlines` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `trade_doc_submissions`
--

DROP TABLE IF EXISTS `trade_doc_submissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `trade_doc_submissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `doc_type` varchar(70) NOT NULL,
  `hs_code` varchar(25) NOT NULL,
  `incoterm_rule` varchar(20) NOT NULL,
  `currency_amount` varchar(60) NOT NULL,
  `destination_port` varchar(120) NOT NULL,
  `compliance_score` int(11) DEFAULT 100,
  `audit_feedback` text DEFAULT NULL,
  `submitted_shamsi` varchar(25) DEFAULT '',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trade_doc_submissions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `trade_doc_submissions` WRITE;
/*!40000 ALTER TABLE `trade_doc_submissions` DISABLE KEYS */;
INSERT INTO `trade_doc_submissions` VALUES
(1,7,'Proforma Invoice (پیش‌فاکتور صادراتی)','0802.51.00','CIF Jebel Ali','48,500 USD','بندر جبل‌علی امارات',95,'منطبق با UCP 600 — کد تعرفه پسته با پوست، بندر مقصد و ارز تسویه دقیق است.','۱۴۰۵/۰۷/۲۸','2026-10-23 21:48:59'),
(2,6,'Certificate of Origin (گواهی مبدأ صادره از مرجع مجاز)','6907.21.00','FCA Bandar Abbas','31,200 EUR','بندر صحار عمان',90,'تأیید بخش اسناد تجاری مؤسسه آموزشی آدان — وزن خالص و ناخالص با پکینگ‌لیست هم‌خوانی دارد.','۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `trade_doc_submissions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `trade_missions`
--

DROP TABLE IF EXISTS `trade_missions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `trade_missions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mission_code` varchar(40) NOT NULL,
  `title` varchar(220) NOT NULL,
  `mission_type` enum('هیئت تجاری اعزامی','هیئت تجاری پذیرشی','تور بازدید صنعتی استان') DEFAULT 'هیئت تجاری اعزامی',
  `target_country_or_city` varchar(100) NOT NULL,
  `sector_focus` varchar(150) NOT NULL,
  `shamsi_dates` varchar(80) NOT NULL,
  `delegates_count` int(11) DEFAULT 12,
  `b2b_meetings_count` int(11) DEFAULT 35,
  `mou_value_usd` bigint(20) DEFAULT 0,
  `status` varchar(50) DEFAULT 'در حال ثبت‌نام اعضا',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trade_missions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `trade_missions` WRITE;
/*!40000 ALTER TABLE `trade_missions` DISABLE KEYS */;
INSERT INTO `trade_missions` VALUES
(1,'MSN-OMN-1405','هیئت تجاری و آموزشی صادرکنندگان صنایع غذایی و ساختمانی به مسقط','هیئت تجاری اعزامی','عمان — مسقط','صنایع غذایی، خشکبار و مصالح ساختمانی','۱۴ تا ۱۸ آذر ۱۴۰۵',18,64,1450000,'در حال ثبت‌نام اعضا'),
(2,'MSN-EUR-1405','پذیرش هیئت خریداران اتحادیه اقتصادی اوراسیا در اتاق استان','هیئت تجاری پذیرشی','روسیه و قزاقستان','محصولات پتروشیمی، پلیمری و کشاورزی','۲۵ آبان ۱۴۰۵',24,90,2100000,'تکمیل ظرفیت B2B'),
(3,'MSN-IND-1405','تور یادگیری کارخانه‌ای: خط تولید هوشمند فولاد و لجستیک خشک','تور بازدید صنعتی استان','شهرک صنعتی بزرگ استان','مدیران تولید و تعالی سازمانی','۸ آذر ۱۴۰۵',30,12,0,'در حال ثبت‌نام اعضا');
/*!40000 ALTER TABLE `trade_missions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `trade_negotiation_turns`
--

DROP TABLE IF EXISTS `trade_negotiation_turns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `trade_negotiation_turns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `scenario_lang` varchar(30) DEFAULT 'fa',
  `buyer_persona` varchar(140) DEFAULT 'واردکننده عمده خشکبار در دبی',
  `exporter_message` text NOT NULL,
  `ai_counter_offer` text NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trade_negotiation_turns`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `trade_negotiation_turns` WRITE;
/*!40000 ALTER TABLE `trade_negotiation_turns` DISABLE KEYS */;
INSERT INTO `trade_negotiation_turns` VALUES
(1,7,'انگلیسی تجاری (EN)','مدیر خرید زنجیره فروشگاهی امارات (Al-Maya Group)','We propose CIF Jebel Ali at $8.40/kg with 30% advance T/T and 70% against scanned Bill of Lading.','پیشنهاد شما حرفه‌ای است؛ اما به عنوان خریدار اماراتی تقاضای تخفیف ۳٪ برای سفارش ۳ کانتینر ۲۰ فوت و پرداخت ۷۰٪ به صورت LC دیداری (Irrevocable Sight LC) تحت UCP 600 بانک امارات NBD داریم. پاسخ مذاکراتی شما چیست؟','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `trade_negotiation_turns` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `trade_paths`
--

DROP TABLE IF EXISTS `trade_paths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `trade_paths` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `target_market` varchar(120) DEFAULT 'اتحادیه اروپا، خلیج فارس و اوراسیا',
  `steps_json` longtext NOT NULL,
  `scenario_title` varchar(220) NOT NULL,
  `scenario_prompt` text NOT NULL,
  `optimal_incoterm` varchar(40) DEFAULT 'CIF / CIP Incoterms 2020',
  `badge_title` varchar(140) DEFAULT 'متخصص ارشد صادرات مؤسسه آموزشی آدان',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trade_paths`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `trade_paths` WRITE;
/*!40000 ALTER TABLE `trade_paths` DISABLE KEYS */;
INSERT INTO `trade_paths` VALUES
(1,'مسیر جامع معمار صادرات صنعتی به اتحادیه اروپا و اوراسیا','اتحادیه اروپا و اتحادیه اقتصادی اوراسیا','[\"گام ۱: دوره جامع اینکوترمز ۲۰۲۰ و اسناد حمل (TRD-101)\",\"گام ۲: مدیریت ریسک ارزی و رفع تعهد (TRD-204)\",\"گام ۳: انطباق کربن مرزی اروپا CBAM (TRD-309)\",\"گام ۴: هوش مصنوعی در کشف خریداران خارجی (AID-301)\"]','سناریوی تصمیم‌گیری صادرات ۲۰ کانتینر محصول صنعتی به هامبورگ','خریدار آلمانی پیشنهاد خرید با ترم DDP Hamburg داده است، در حالی که شرکت شما شخصیت حقوقی ثبت‌شده برای ترخیص وارداتی و پرداخت VAT در گمرک آلمان ندارد. بهترین جایگزین استاندارد ICC چیست؟','CIP Hamburg / DAP Terminal (Incoterms 20','گواهی عالی معمار تجارت بین‌الملل مؤسسه آموزشی آدان');
/*!40000 ALTER TABLE `trade_paths` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tuition_refund_requests`
--

DROP TABLE IF EXISTS `tuition_refund_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tuition_refund_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `refund_code` varchar(45) NOT NULL,
  `applicant_name` varchar(150) NOT NULL,
  `course_title` varchar(190) NOT NULL,
  `paid_tuition_rial` bigint(20) NOT NULL DEFAULT 52000000,
  `hours_before_start` int(11) NOT NULL DEFAULT 48,
  `deduction_pct` int(11) NOT NULL DEFAULT 15,
  `net_refund_rial` bigint(20) NOT NULL DEFAULT 44200000,
  `reversal_voucher_no` varchar(45) NOT NULL,
  `processed_shamsi` varchar(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `refund_code` (`refund_code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tuition_refund_requests`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tuition_refund_requests` WRITE;
/*!40000 ALTER TABLE `tuition_refund_requests` DISABLE KEYS */;
INSERT INTO `tuition_refund_requests` VALUES
(1,'RFD-1405-201','شرکت بازرگانی سپهر گستر','کارگاه قراردادهای بین‌المللی کد ۶۵',69000000,96,0,69000000,'VCH-RFD-9001','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(2,'RFD-1405-202','مهندس بهزاد نوری','جامع ثبت سفارش NTSW و اظهار گمرک',52000000,36,15,44200000,'VCH-RFD-9002','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `tuition_refund_requests` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `user_badges`
--

DROP TABLE IF EXISTS `user_badges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_badges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `badge_code` varchar(60) NOT NULL,
  `badge_title` varchar(160) NOT NULL,
  `skill_domain` varchar(120) NOT NULL,
  `issued_shamsi` varchar(30) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `badge_code` (`badge_code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_badges`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `user_badges` WRITE;
/*!40000 ALTER TABLE `user_badges` DISABLE KEYS */;
INSERT INTO `user_badges` VALUES
(1,7,'BDG-INCO-2026','متخصص تاییدشده Incoterms 2020','تجارت بین‌الملل','۱۴۰۵/۰۷/۲۸'),
(2,7,'BDG-TAX-2026','کارشناس رسمی سامانه مؤدیان مالیاتی','مالی و مالیاتی','۱۴۰۵/۰۷/۱۸');
/*!40000 ALTER TABLE `user_badges` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `org_id` int(11) DEFAULT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(190) NOT NULL,
  `mobile` varchar(25) DEFAULT NULL,
  `national_code` varchar(20) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `full_name` varchar(180) NOT NULL,
  `role` varchar(60) NOT NULL DEFAULT 'learner',
  `job_title` varchar(150) DEFAULT 'کارشناس',
  `avatar_initials` varchar(10) DEFAULT 'ک',
  `public_passport_slug` varchar(120) DEFAULT NULL,
  `passport_is_public` tinyint(1) DEFAULT 0,
  `marketing_opt_in` tinyint(1) DEFAULT 1,
  `telegram_chat_id` varchar(60) DEFAULT NULL,
  `daily_ai_token_limit` int(11) DEFAULT 25000,
  `status` enum('active','locked','inactive') DEFAULT 'active',
  `last_login_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `public_passport_slug` (`public_passport_slug`),
  KEY `idx_users_org` (`org_id`),
  KEY `idx_users_role` (`role`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,NULL,'admin','admin@chamber-edu.ir','09121001001','0071234567','$2y$12$gCJgIqk5SGohiQq0ujT4g.eAa1t7RT1wOhww1P2aMeWXgB3S.sMNy','دکتر کیارش رادمهر','super_admin','مدیر واحد آموزش مؤسسه آموزشی آدان','کر','kiarash-radmehr',1,1,NULL,100000,'active',NULL,'2026-10-23 21:48:59'),
(2,NULL,'expert','expert@chamber-edu.ir','09121001002','0082345678','$2y$12$gCJgIqk5SGohiQq0ujT4g.eAa1t7RT1wOhww1P2aMeWXgB3S.sMNy','مهندس سارا فرهمند','training_expert','کارشناس مسئول برنامه‌ریزی و اجرای آموزش','سف','sara-farahmand',1,1,NULL,50000,'active',NULL,'2026-10-23 21:48:59'),
(3,NULL,'finance','finance@chamber-edu.ir','09121001003','0063456789','$2y$12$gCJgIqk5SGohiQq0ujT4g.eAa1t7RT1wOhww1P2aMeWXgB3S.sMNy','حسین کاظمی‌نژاد','finance_manager','رئیس حسابداری و مالی آموزش','حک','hossein-kazemi',0,1,NULL,25000,'active',NULL,'2026-10-23 21:48:59'),
(4,NULL,'crm','crm@chamber-edu.ir','09121001004','0054567890','$2y$12$gCJgIqk5SGohiQq0ujT4g.eAa1t7RT1wOhww1P2aMeWXgB3S.sMNy','نگین محتشم','crm_manager','مسئول توسعه بازار و ارتباط با اعضا','نم','negin-mohtasham',1,1,NULL,40000,'active',NULL,'2026-10-23 21:48:59'),
(5,NULL,'instructor','dr.nikzad@chamber-edu.ir','09121001005','0045678901','$2y$12$gCJgIqk5SGohiQq0ujT4g.eAa1t7RT1wOhww1P2aMeWXgB3S.sMNy','دکتر امیرحسین نیکزاد','instructor','استاد تجارت بین‌الملل و مشاور ارشد صادرات','ان','amir-nikzad',1,1,NULL,50000,'active',NULL,'2026-10-23 21:48:59'),
(6,1,'orgrep','hr@zagros-steel.ir','09121001006','1286789012','$2y$12$gCJgIqk5SGohiQq0ujT4g.eAa1t7RT1wOhww1P2aMeWXgB3S.sMNy','پریسا بهرامی','org_rep','مدیر آموزش گروه صنعتی فولاد زاگرس','پب','parisa-bahrami',1,1,NULL,20000,'active',NULL,'2026-10-23 21:48:59'),
(7,1,'learner','export@zagros-steel.ir','09121001007','1297890123','$2y$12$gCJgIqk5SGohiQq0ujT4g.eAa1t7RT1wOhww1P2aMeWXgB3S.sMNy','مهرداد شریفی','learner','کارشناس ارشد بازرگانی خارجی','مش','mehrdad-sharifi',1,1,NULL,15000,'active',NULL,'2026-10-23 21:48:59'),
(8,2,'learner2','trade@taban-saffron.ir','09121001008','0938901234','$2y$12$gCJgIqk5SGohiQq0ujT4g.eAa1t7RT1wOhww1P2aMeWXgB3S.sMNy','الهام رضوانی','learner','مسئول صادرات اتحادیه اروپا','ار','elham-rezvani',1,0,NULL,15000,'active',NULL,'2026-10-23 21:48:59');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `verifiable_credential_blocks`
--

DROP TABLE IF EXISTS `verifiable_credential_blocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `verifiable_credential_blocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `block_height` int(11) NOT NULL,
  `cert_or_badge_code` varchar(60) NOT NULL,
  `holder_fullname` varchar(150) NOT NULL,
  `prev_block_hash` char(64) NOT NULL,
  `block_sha256_hash` char(64) NOT NULL,
  `w3c_standard_version` varchar(60) DEFAULT 'چکیده محلی؛ استاندارد یا امضای W3C تأیید نشده',
  `sealed_shamsi` varchar(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `verifiable_credential_blocks`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `verifiable_credential_blocks` WRITE;
/*!40000 ALTER TABLE `verifiable_credential_blocks` DISABLE KEYS */;
INSERT INTO `verifiable_credential_blocks` VALUES
(1,1001,'CERT-ADN-1405-9001','مهندس مهرداد شریفی','0000000000000000000000000000000000000000000000000000000000000000','9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08','چکیده محلی؛ استاندارد یا امضای W3C تأیید نشده','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59'),
(2,1002,'BADGE-TRD-ELITE-01','مهندس مهرداد شریفی','9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08','4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a','چکیده محلی؛ استاندارد یا امضای W3C تأیید نشده','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `verifiable_credential_blocks` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `virtual_class_rooms`
--

DROP TABLE IF EXISTS `virtual_class_rooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `virtual_class_rooms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `run_id` int(11) NOT NULL DEFAULT 1,
  `provider` enum('Skyroom','BigBlueButton','AdobeConnect') DEFAULT 'Skyroom',
  `room_title` varchar(200) NOT NULL,
  `sso_slug` varchar(120) NOT NULL,
  `online_participants` int(11) DEFAULT 0,
  `synced_attendance_count` int(11) DEFAULT 0,
  `recording_url` varchar(255) DEFAULT NULL,
  `connection_mode` varchar(40) DEFAULT 'not_configured',
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `virtual_class_rooms`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `virtual_class_rooms` WRITE;
/*!40000 ALTER TABLE `virtual_class_rooms` DISABLE KEYS */;
INSERT INTO `virtual_class_rooms` VALUES
(1,1,'Skyroom','کلاس زنده جامع اینکوترمز ۲۰۲۰ و اسناد حمل','incoterms-live-1405',0,0,NULL,'not_configured','2026-10-23 21:48:59'),
(2,2,'BigBlueButton','وبینار تخصصی سامانه مؤدیان و پایانه‌های فروشگاهی','tax-moadian-live',0,0,NULL,'not_configured','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `virtual_class_rooms` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `voice_command_logs`
--

DROP TABLE IF EXISTS `voice_command_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `voice_command_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT 1,
  `spoken_text` varchar(500) NOT NULL,
  `detected_intent` varchar(50) NOT NULL,
  `target_route` varchar(80) DEFAULT '',
  `action_summary` varchar(255) NOT NULL,
  `spoken_response` text NOT NULL,
  `created_shamsi` varchar(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `voice_command_logs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `voice_command_logs` WRITE;
/*!40000 ALTER TABLE `voice_command_logs` DISABLE KEYS */;
INSERT INTO `voice_command_logs` VALUES
(1,1,'گزارش کامل مالی و وضعیت تراز حسابداری چهار سطحی رو بگو','LIVE_REPORT','finance','گزارش زنده دفترکل، چک صیادی و اسناد دوبل استخراج شد','گزارش زنده مالی آماده شد: جمع درآمد ثبت‌شده دفترکل بیش از چهار میلیارد ریال و اختلاف تراز اسناد چهارسطحی دقیقاً صفر ریال است.','۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59'),
(2,1,'برو به رادار بازار و تحلیل رقبا','NAVIGATION','market-radar','هدایت صوتی به بخش تخصصی (رادار هوشمند بازار و R&D)','در حال انتقال شما به ماژول سی و نهم، رادار هوشمند بازار آموزش و کالبدشکافی زنده رقبا.','۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59'),
(3,1,'آزمون شخصیت شناسی MBTI رو اجرا کن و کارنامه بده','EXECUTE_ACTION','exams','صدور خودکار کارنامه رسمی MBTI در جدول standard_test_results','آزمون شخصیت‌شناسی مایرز بریگز اجرا و کارنامه تحلیلی تیپ شخصیتی در پرونده آموزشی ثبت شد.','۱۴۰۵/۰۷/۳۰','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `voice_command_logs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `voice_report_archive`
--

DROP TABLE IF EXISTS `voice_report_archive`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `voice_report_archive` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `report_code` varchar(45) NOT NULL,
  `report_kind` varchar(60) NOT NULL,
  `audience_role` varchar(30) NOT NULL DEFAULT 'super_admin',
  `user_id` int(11) NOT NULL,
  `user_name` varchar(150) NOT NULL DEFAULT 'سامانه',
  `report_title` varchar(240) NOT NULL,
  `narrative_text` mediumtext NOT NULL,
  `speech_text` mediumtext NOT NULL,
  `metrics_json` text DEFAULT NULL,
  `speech_chars` int(11) NOT NULL DEFAULT 0,
  `est_duration_sec` int(11) NOT NULL DEFAULT 60,
  `delivery_mode` varchar(30) NOT NULL DEFAULT 'browser_tts',
  `visibility_scope` varchar(30) NOT NULL DEFAULT 'own_role',
  `created_shamsi` varchar(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۱',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `report_code` (`report_code`),
  KEY `idx_vra_role` (`audience_role`,`id`),
  KEY `idx_vra_user` (`user_id`,`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `voice_report_archive`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `voice_report_archive` WRITE;
/*!40000 ALTER TABLE `voice_report_archive` DISABLE KEYS */;
INSERT INTO `voice_report_archive` VALUES
(1,'VRA-SEED-01','daily_digest','super_admin',1,'دبیرخانه هوشمند','گزارش نمونه بایگانی‌شده استودیوی گزارش صوتی','این یک گزارش نمونه است تا ساختار بایگانی استودیوی گزارش صوتی در نصب تازه خالی نباشد؛ با نخستین تولید گزارش، گزارش‌های واقعی جای آن را می‌گیرند.','گزارش نمونه استودیوی گزارش صوتی مؤسسه آموزشی آدان. سامانه آماده تولید گزارش‌های زنده است.','{\"نمونه\":\"فعال\"}',92,22,'browser_tts','own_role','۱۴۰۵/۰۸/۰۱','2026-10-23 21:48:59');
/*!40000 ALTER TABLE `voice_report_archive` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `webhooks_and_jobs`
--

DROP TABLE IF EXISTS `webhooks_and_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `webhooks_and_jobs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entry_kind` enum('webhook','queue_job') DEFAULT 'webhook',
  `name` varchar(160) NOT NULL,
  `target_url_or_handler` varchar(255) NOT NULL,
  `event_trigger` varchar(80) DEFAULT 'enrollment.created',
  `status` enum('active','queued','completed','failed','draft_local') DEFAULT 'draft_local',
  `last_response` varchar(255) DEFAULT 'پیش‌نویس محلی؛ ارسال بیرونی فعال نیست',
  `last_run_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webhooks_and_jobs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `webhooks_and_jobs` WRITE;
/*!40000 ALTER TABLE `webhooks_and_jobs` DISABLE KEYS */;
INSERT INTO `webhooks_and_jobs` VALUES
(1,'webhook','پیش‌نویس محلی رویداد ثبت‌نام','https://example.invalid/adan-webhook','enrollment.created','draft_local','پیش‌نویس محلی؛ هیچ درخواست بیرونی ارسال نشده',NULL,'2026-10-23 21:48:59'),
(2,'queue_job','تولید گزارش میانگین نمره به تفکیک کانال جذب','BiScheduledReportJob::handle','cron.weekly','queued','در صف اجرا؛ ارسال بیرونی انجام نمی‌شود',NULL,'2026-10-23 21:48:59');
/*!40000 ALTER TABLE `webhooks_and_jobs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Dumping events for database 'chamber_edu'
--

--
-- Dumping routines for database 'chamber_edu'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-10-23 21:49:00
