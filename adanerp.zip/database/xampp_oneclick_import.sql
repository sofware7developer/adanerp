-- =============================================================================
-- سامانه جامع آموزش، اتوماسیون اداری، هوش تجاری و استودیوی گزارش صوتی مؤسسه آموزشی آدان (نسخه مرجع 26.8.2-VoicePlaybackAndServiceWorkerFix)
-- فایل ایمپورت یک‌کلیکی مستقیم در XAMPP phpMyAdmin (ایجاد خودکار دیتابیس adanerpdb)
-- شامل 178 جدول MariaDB + سید کامل فارسی + ترمیم خودکار اسکیما (بدون install.php)
-- =============================================================================

CREATE DATABASE IF NOT EXISTS `adanerpdb` CHARACTER SET utf8mb4 COLLATE utf8mb4_persian_ci;
USE `adanerpdb`;

-- =============================================================================
-- سامانه جامع هوشمند آموزش مؤسسه آموزشی آدان (Adan Accounting Education ERP + LMS + AI)
-- سازگار با MariaDB 10.3 / 10.4 / 10.6 / 11.x در XAMPP و cPanel (phpMyAdmin)
-- معماری: Pure PHP MVC + AI Gateway
-- =============================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ۱. سازمان‌ها و بنگاه‌های دانش‌پذیر آدان
CREATE TABLE IF NOT EXISTS organizations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    chamber_member_code VARCHAR(80) UNIQUE,
    national_id VARCHAR(30),
    industry VARCHAR(120) DEFAULT 'صنعت و بازرگانی',
    membership_tier ENUM('gold','silver','standard','non_member') DEFAULT 'gold',
    city VARCHAR(100) DEFAULT 'مرکز استان',
    annual_quota_hours INT DEFAULT 200,
    used_quota_hours INT DEFAULT 0,
    contact_phone VARCHAR(40),
    status ENUM('active','pending','suspended') DEFAULT 'active',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۲. کاربران، نقش‌ها، گذرنامه استعداد و تنظیمات رضایت ارتباطی
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    org_id INT NULL,
    username VARCHAR(100) NOT NULL UNIQUE,
    email VARCHAR(190) NOT NULL UNIQUE,
    mobile VARCHAR(25),
    national_code VARCHAR(20),
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(180) NOT NULL,
    role VARCHAR(60) NOT NULL DEFAULT 'learner',
    job_title VARCHAR(150) DEFAULT 'کارشناس',
    avatar_initials VARCHAR(10) DEFAULT 'ک',
    public_passport_slug VARCHAR(120) UNIQUE,
    passport_is_public TINYINT(1) DEFAULT 0,
    marketing_opt_in TINYINT(1) DEFAULT 1,
    telegram_chat_id VARCHAR(60) NULL,
    daily_ai_token_limit INT DEFAULT 25000,
    status ENUM('active','locked','inactive') DEFAULT 'active',
    last_login_at DATETIME NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_users_org (org_id),
    INDEX idx_users_role (role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۳. قفل موقت ورود (Brute-Force Protection)
CREATE TABLE IF NOT EXISTS login_attempts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    identifier VARCHAR(190) NOT NULL,
    ip_address VARCHAR(64) NOT NULL,
    attempted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    is_success TINYINT(1) DEFAULT 0,
    INDEX idx_login_ident (identifier, attempted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۴. لاگ ممیزی امنیتی و عملیاتی (Audit Log)
CREATE TABLE IF NOT EXISTS audit_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    user_role VARCHAR(50),
    module VARCHAR(80) NOT NULL,
    action VARCHAR(120) NOT NULL,
    entity_type VARCHAR(80),
    entity_id INT NULL,
    details_json LONGTEXT,
    ip_address VARCHAR(64),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_audit_mod (module, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۵. تنظیمات سراسری سامانه و کلیدهای سمت سرور
CREATE TABLE IF NOT EXISTS system_settings (
    setting_key VARCHAR(120) PRIMARY KEY,
    setting_value LONGTEXT,
    category VARCHAR(60) DEFAULT 'general',
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۶. اعلان‌های نقش‌محور و فردی
CREATE TABLE IF NOT EXISTS notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    target_role VARCHAR(50) NULL,
    title VARCHAR(200) NOT NULL,
    body TEXT,
    type ENUM('info','success','warning','urgent') DEFAULT 'info',
    link VARCHAR(255) NULL,
    is_read TINYINT(1) DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۷. دسته‌بندی دوره‌ها (TMS)
CREATE TABLE IF NOT EXISTS course_categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(160) NOT NULL,
    slug VARCHAR(160) NOT NULL UNIQUE,
    icon VARCHAR(40) DEFAULT 'briefcase',
    color VARCHAR(30) DEFAULT '#0f766e',
    description VARCHAR(500)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۸. کاتالوگ دوره‌ها و گردش تصویب (TMS)
CREATE TABLE IF NOT EXISTS courses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT NOT NULL,
    code VARCHAR(50) NOT NULL UNIQUE,
    title VARCHAR(220) NOT NULL,
    level ENUM('مقدماتی','میانی','پیشرفته','مدیریتی ویژه') DEFAULT 'میانی',
    delivery_mode ENUM('حضوری','آنلاین همزمان','ترکیبی','خودآموز LMS') DEFAULT 'ترکیبی',
    duration_hours INT NOT NULL DEFAULT 16,
    tuition_rial BIGINT NOT NULL DEFAULT 0,
    member_discount_pct INT DEFAULT 20,
    prerequisite_text VARCHAR(255) DEFAULT 'ندارد',
    workflow_status ENUM('draft','under_review','approved','published','archived') DEFAULT 'published',
    reviewer_note VARCHAR(500) NULL,
    approved_by INT NULL,
    summary TEXT,
    rating DECIMAL(3,2) DEFAULT 4.80,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_course_status (workflow_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۹. اجراها / ترم‌های دوره (TMS)
CREATE TABLE IF NOT EXISTS course_runs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_id INT NOT NULL,
    instructor_id INT NULL,
    classroom_id INT NULL,
    run_code VARCHAR(60) NOT NULL UNIQUE,
    term_label VARCHAR(100) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    start_shamsi VARCHAR(30) NOT NULL,
    schedule_text VARCHAR(180) NOT NULL,
    capacity INT NOT NULL DEFAULT 30,
    enrolled_count INT NOT NULL DEFAULT 0,
    status ENUM('planning','registration','running','completed','cancelled') DEFAULT 'registration',
    execution_report TEXT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۱۰. جلسات کلاسی هر اجرا (TMS)
CREATE TABLE IF NOT EXISTS course_sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    run_id INT NOT NULL,
    session_number INT NOT NULL DEFAULT 1,
    title VARCHAR(200) NOT NULL,
    session_date DATE NOT NULL,
    session_shamsi VARCHAR(30) NOT NULL,
    start_time VARCHAR(10) DEFAULT '14:00',
    end_time VARCHAR(10) DEFAULT '18:00',
    room_or_link VARCHAR(255) DEFAULT 'سالن خلیج فارس - طبقه دوم اتاق',
    is_held TINYINT(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۱۱. ثبت‌نام‌ها و فهرست انتظار (تکی / گروهی سازمانی / API)
CREATE TABLE IF NOT EXISTS enrollments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    run_id INT NOT NULL,
    user_id INT NOT NULL,
    org_id INT NULL,
    source ENUM('web','bulk_org','api','admin') DEFAULT 'web',
    status ENUM('active','waitlist','completed','cancelled') DEFAULT 'active',
    attendance_pct INT DEFAULT 100,
    progress_pct INT DEFAULT 0,
    final_score DECIMAL(5,2) NULL,
    invoice_id INT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_run_user (run_id, user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۱۲. حضور و غیاب جلسه‌ای
CREATE TABLE IF NOT EXISTS session_attendance (
    id INT AUTO_INCREMENT PRIMARY KEY,
    session_id INT NOT NULL,
    user_id INT NOT NULL,
    status ENUM('present','absent','late','excused') DEFAULT 'present',
    note VARCHAR(200) NULL,
    recorded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_sess_user (session_id, user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۱۳. بانک شایستگی‌ها (TNA)
CREATE TABLE IF NOT EXISTS competencies (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(40) NOT NULL UNIQUE,
    title VARCHAR(180) NOT NULL,
    domain ENUM('تجارت بین‌الملل','مدیریت و رهبری','مالی و گمرکی','تحول دیجیتال و AI','مذاکره و حقوق تجاری') DEFAULT 'تجارت بین‌الملل',
    recommended_course_id INT NULL,
    weight INT DEFAULT 3,
    description TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۱۴. ماتریس ارزیابی سطح فعلی و هدف شایستگی
CREATE TABLE IF NOT EXISTS competency_assessments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    competency_id INT NOT NULL,
    target_role_title VARCHAR(150) DEFAULT 'مدیر صادرات',
    current_level TINYINT NOT NULL DEFAULT 2,
    target_level TINYINT NOT NULL DEFAULT 4,
    priority ENUM('عادی','مهم','حیاتی') DEFAULT 'مهم',
    ai_recommendation VARCHAR(500) NULL,
    assessed_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۱۵. پیشنهاد دوره توسط اعضا و نظرسنجی نیازسنجی
CREATE TABLE IF NOT EXISTS course_proposals (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    org_id INT NULL,
    proposed_title VARCHAR(220) NOT NULL,
    target_audience VARCHAR(180),
    estimated_learners INT DEFAULT 15,
    business_problem TEXT,
    votes_count INT DEFAULT 1,
    status ENUM('pending','ai_analyzed','approved','converted_to_course','rejected') DEFAULT 'pending',
    ai_analysis_note TEXT NULL,
    reviewer_comment VARCHAR(400) NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۱۶. فصل‌های آموزشی LMS 
CREATE TABLE IF NOT EXISTS lms_chapters (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_id INT NOT NULL,
    sort_order INT DEFAULT 1,
    title VARCHAR(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۱۷. درس‌ها، محتوای چندرسانه‌ای و بسته SCORM 
CREATE TABLE IF NOT EXISTS lms_lessons (
    id INT AUTO_INCREMENT PRIMARY KEY,
    chapter_id INT NOT NULL,
    course_id INT NOT NULL,
    sort_order INT DEFAULT 1,
    title VARCHAR(220) NOT NULL,
    content_type ENUM('video','audio','pdf','scorm','article') DEFAULT 'video',
    estimated_minutes INT DEFAULT 25,
    sequential_lock TINYINT(1) DEFAULT 1,
    media_url VARCHAR(300) NULL,
    scorm_manifest_path VARCHAR(300) NULL,
    scorm_version VARCHAR(40) NULL,
    body_html LONGTEXT,
    attachment_name VARCHAR(200) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۱۸. پیشرفت و زمان مطالعه LMS
CREATE TABLE IF NOT EXISTS lms_progress (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    lesson_id INT NOT NULL,
    is_completed TINYINT(1) DEFAULT 0,
    spent_minutes INT DEFAULT 0,
    completed_at DATETIME NULL,
    UNIQUE KEY uq_user_lesson (user_id, lesson_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۱۹. گفت‌وگوی کلاسی LMS
CREATE TABLE IF NOT EXISTS lms_discussions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_id INT NOT NULL,
    lesson_id INT NULL,
    user_id INT NOT NULL,
    message TEXT NOT NULL,
    instructor_reply TEXT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۲۰. تکالیف و فایل‌های ارسالی LMS
CREATE TABLE IF NOT EXISTS lms_assignments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_id INT NOT NULL,
    user_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    submission_text TEXT,
    file_path VARCHAR(255) NULL,
    grade DECIMAL(5,2) NULL,
    feedback VARCHAR(400) NULL,
    status ENUM('submitted','graded','revision_needed') DEFAULT 'submitted',
    submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۲۱. استودیوی تولید محتوا با AI و بازبینی انسانی 
CREATE TABLE IF NOT EXISTS ai_contents (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_id INT NULL,
    creator_id INT NOT NULL,
    content_kind ENUM('course_draft','lesson_plan','quiz','microlearning','slides','summary') NOT NULL,
    title VARCHAR(220) NOT NULL,
    source_excerpt LONGTEXT NULL,
    current_version INT DEFAULT 1,
    body_markdown LONGTEXT NOT NULL,
    model_used VARCHAR(80) DEFAULT 'ai/gpt-4o-mini',
    review_status ENUM('ai_draft','in_review','human_approved','published') DEFAULT 'ai_draft',
    approved_by INT NULL,
    approved_at DATETIME NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۲۲. تاریخچه نسخه‌های استودیوی AI
CREATE TABLE IF NOT EXISTS ai_content_versions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ai_content_id INT NOT NULL,
    version_no INT NOT NULL DEFAULT 1,
    editor_id INT NOT NULL,
    change_note VARCHAR(255) DEFAULT 'نسخه اولیه پیش‌نویس هوش مصنوعی',
    body_snapshot LONGTEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۲۳. پرونده بانک مدرسان 
CREATE TABLE IF NOT EXISTS instructor_profiles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,
    degree VARCHAR(120) DEFAULT 'دکتری تخصصی مدیریت بازرگانی',
    specialties VARCHAR(350) NOT NULL,
    teaching_years INT DEFAULT 8,
    hourly_rate_rial BIGINT DEFAULT 12000000,
    avg_rating DECIMAL(3,2) DEFAULT 4.85,
    qualification_status ENUM('pending','committee_approved','conditional','suspended') DEFAULT 'committee_approved',
    availability_slots VARCHAR(255) DEFAULT 'دوشنبه و چهارشنبه ۱۴ الی ۲۰ | پنجشنبه ۹ الی ۱۳',
    portfolio_url VARCHAR(255) NULL,
    bio TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۲۴. گردش پرداخت حق‌التدریس مدرسان 
CREATE TABLE IF NOT EXISTS instructor_payouts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    instructor_user_id INT NOT NULL,
    run_id INT NULL,
    hours_taught INT NOT NULL DEFAULT 16,
    gross_amount_rial BIGINT NOT NULL,
    tax_deduction_rial BIGINT NOT NULL DEFAULT 0,
    net_amount_rial BIGINT NOT NULL,
    status ENUM('draft','verified','approved_finance','paid') DEFAULT 'verified',
    payment_ref VARCHAR(100) NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۲۵. کارگاه‌ها، نشست‌ها و برنامه‌های آموزشی
CREATE TABLE IF NOT EXISTS events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(50) NOT NULL UNIQUE,
    title VARCHAR(220) NOT NULL,
    event_type ENUM('همایش استانی','نشست هیئت تجاری','سمینار تخصصی','کارگاه رایگان اعضا','کارگاه آموزشی','نشست تخصصی','جلسه رفع اشکال') DEFAULT 'کارگاه آموزشی',
    speakers VARCHAR(350) NOT NULL,
    event_date DATE NOT NULL,
    event_shamsi VARCHAR(30) NOT NULL,
    venue VARCHAR(200) DEFAULT 'آموزشگاه حسابداری آدان',
    capacity INT NOT NULL DEFAULT 150,
    registered_count INT DEFAULT 0,
    price_rial BIGINT NOT NULL DEFAULT 0,
    estimated_cost_rial BIGINT DEFAULT 0,
    sms_reminder_status ENUM('sandbox_queued','sandbox_sent','disabled') DEFAULT 'sandbox_queued',
    status ENUM('open','sold_out','closed') DEFAULT 'open',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۲۶. بلیت‌ها و ثبت ورود QR رویدادها 
CREATE TABLE IF NOT EXISTS event_tickets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    event_id INT NOT NULL,
    user_id INT NOT NULL,
    ticket_code VARCHAR(80) NOT NULL UNIQUE,
    paid_status ENUM('free','paid_invoice') DEFAULT 'free',
    checked_in_at DATETIME NULL,
    feedback_score TINYINT NULL,
    feedback_comment VARCHAR(300) NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_event_user (event_id, user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۲۷. کدهای تخفیف (مالی)
CREATE TABLE IF NOT EXISTS discount_codes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(50) NOT NULL UNIQUE,
    discount_pct INT NOT NULL DEFAULT 15,
    max_uses INT DEFAULT 100,
    used_count INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۲۸. فاکتورها، مالیات بر ارزش افزوده و استرداد 
CREATE TABLE IF NOT EXISTS invoices (
    id INT AUTO_INCREMENT PRIMARY KEY,
    invoice_number VARCHAR(60) NOT NULL UNIQUE,
    user_id INT NOT NULL,
    org_id INT NULL,
    item_description VARCHAR(255) NOT NULL,
    subtotal_rial BIGINT NOT NULL,
    discount_rial BIGINT DEFAULT 0,
    vat_rial BIGINT DEFAULT 0,
    total_rial BIGINT NOT NULL,
    payment_mode ENUM('cash_gateway_sim','installment','corporate_contract') DEFAULT 'cash_gateway_sim',
    status ENUM('unpaid','partial','paid','refund_requested','refunded') DEFAULT 'unpaid',
    refund_reason VARCHAR(255) NULL,
    payment_reference VARCHAR(100) NULL,
    refund_payment_reference VARCHAR(100) NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_invoice_payment_reference (payment_reference),
    UNIQUE KEY uq_invoice_refund_payment_reference (refund_payment_reference)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۲۹. تقسیط شهریه 
CREATE TABLE IF NOT EXISTS invoice_installments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    invoice_id INT NOT NULL,
    installment_no INT NOT NULL DEFAULT 1,
    due_shamsi VARCHAR(30) NOT NULL,
    amount_rial BIGINT NOT NULL,
    status ENUM('pending','paid','overdue') DEFAULT 'pending',
    payment_reference VARCHAR(100) NULL,
    UNIQUE KEY uq_installment_payment_reference (payment_reference)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۳۰. دفترکل مالی، هزینه‌ها و بودجه واحد آموزش 
CREATE TABLE IF NOT EXISTS ledger_entries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    entry_date DATE NOT NULL,
    entry_shamsi VARCHAR(30) NOT NULL,
    account_head VARCHAR(140) NOT NULL,
    entry_type ENUM('revenue','expense','budget_alloc','refund') NOT NULL,
    course_id INT NULL,
    debit_rial BIGINT DEFAULT 0,
    credit_rial BIGINT DEFAULT 0,
    description VARCHAR(300)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۳۱. ارزیابی اثربخشی کرکپاتریک، پیش/پس‌آزمون، ۳۶۰ و ROI 
CREATE TABLE IF NOT EXISTS evaluations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_id INT NOT NULL,
    evaluator_id INT NOT NULL,
    kirkpatrick_l1_reaction DECIMAL(4,2) DEFAULT 4.60,
    pre_test_score DECIMAL(5,2) DEFAULT 48.00,
    post_test_score DECIMAL(5,2) DEFAULT 86.00,
    kirkpatrick_l3_behavior DECIMAL(4,2) DEFAULT 4.20,
    transfer_notes VARCHAR(350) NULL,
    program_cost_rial BIGINT DEFAULT 450000000,
    estimated_benefit_rial BIGINT DEFAULT 1150000000,
    feedback_360_summary VARCHAR(400) NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۳۲. مخاطبان و سرنخ‌های CRM آموزشی 
CREATE TABLE IF NOT EXISTS crm_contacts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    org_id INT NULL,
    full_name VARCHAR(160) NOT NULL,
    position_title VARCHAR(120) DEFAULT 'مدیر آموزش و توسعه سرمایه انسانی',
    phone VARCHAR(40),
    email VARCHAR(160),
    lead_score INT DEFAULT 75,
    last_interaction VARCHAR(255) DEFAULT 'تماس کارشناسی معرفی تقویم آموزشی پاییز',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۳۳. فرصت‌های فروش و قیف CRM 
CREATE TABLE IF NOT EXISTS crm_deals (
    id INT AUTO_INCREMENT PRIMARY KEY,
    org_id INT NOT NULL,
    title VARCHAR(220) NOT NULL,
    estimated_value_rial BIGINT NOT NULL DEFAULT 850000000,
    stage ENUM('lead','qualified','proposal','negotiation','won','lost') DEFAULT 'proposal',
    probability_pct INT DEFAULT 60,
    next_followup_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۸/۰۵',
    owner_user_id INT NULL,
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۳۴. قراردادهای سازمانی 
CREATE TABLE IF NOT EXISTS corporate_contracts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    contract_no VARCHAR(60) NOT NULL UNIQUE,
    org_id INT NOT NULL,
    title VARCHAR(220) NOT NULL,
    total_amount_rial BIGINT NOT NULL,
    paid_amount_rial BIGINT DEFAULT 0,
    seat_quota INT NOT NULL DEFAULT 50,
    seats_used INT DEFAULT 0,
    start_shamsi VARCHAR(30) NOT NULL,
    end_shamsi VARCHAR(30) NOT NULL,
    approval_stage ENUM('draft','legal_review','finance_review','approved_active','expired') DEFAULT 'approved_active',
    deliverables_summary TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۳۵. مسیرها و سناریوهای آکادمی تجارت بین‌الملل 
CREATE TABLE IF NOT EXISTS trade_paths (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    target_market VARCHAR(120) DEFAULT 'اتحادیه اروپا، خلیج فارس و اوراسیا',
    steps_json LONGTEXT NOT NULL,
    scenario_title VARCHAR(220) NOT NULL,
    scenario_prompt TEXT NOT NULL,
    optimal_incoterm VARCHAR(40) DEFAULT 'CIF / CIP Incoterms 2020',
    badge_title VARCHAR(140) DEFAULT 'متخصص ارشد صادرات مؤسسه آموزشی آدان'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۳۶. برنامه‌های توسعه رهبری و شبیه‌ساز تصمیم‌گیری وزن‌دار 
CREATE TABLE IF NOT EXISTS leadership_programs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    cohort_name VARCHAR(100) DEFAULT 'دوره چهارم مدیران عامل استان',
    participants_count INT DEFAULT 24,
    criteria_weights_json LONGTEXT NOT NULL,
    mentoring_assignment VARCHAR(350) NOT NULL,
    avg_360_score DECIMAL(4,2) DEFAULT 4.45
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۳۷. جلسات مشاوره و منتورینگ + یادداشت محرمانه 
CREATE TABLE IF NOT EXISTS consulting_sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    consultant_id INT NOT NULL,
    client_user_id INT NOT NULL,
    topic VARCHAR(200) NOT NULL,
    slot_label VARCHAR(120) NOT NULL,
    status ENUM('requested','confirmed','completed','cancelled') DEFAULT 'confirmed',
    agenda TEXT,
    confidential_note TEXT NULL,
    action_items TEXT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۳۸. آزمون‌ها و بانک سؤال 
CREATE TABLE IF NOT EXISTS exams (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    duration_minutes INT NOT NULL DEFAULT 20,
    max_attempts INT NOT NULL DEFAULT 2,
    pass_score DECIMAL(5,2) NOT NULL DEFAULT 70.00,
    is_active TINYINT(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS exam_questions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    exam_id INT NOT NULL,
    question_type ENUM('mcq','descriptive') DEFAULT 'mcq',
    question_text TEXT NOT NULL,
    option_a VARCHAR(255) NULL,
    option_b VARCHAR(255) NULL,
    option_c VARCHAR(255) NULL,
    option_d VARCHAR(255) NULL,
    correct_option CHAR(1) NULL,
    points DECIMAL(5,2) DEFAULT 25.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS exam_attempts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    exam_id INT NOT NULL,
    user_id INT NOT NULL,
    attempt_no INT NOT NULL DEFAULT 1,
    auto_score DECIMAL(5,2) DEFAULT 0,
    descriptive_score DECIMAL(5,2) NULL,
    descriptive_answer TEXT NULL,
    status ENUM('auto_graded','pending_descriptive_review','finalized') DEFAULT 'auto_graded',
    submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۳۹. گواهی‌نامه‌های رسمی قابل استعلام با QR و ابطال‌پذیر 
CREATE TABLE IF NOT EXISTS certificates (
    id INT AUTO_INCREMENT PRIMARY KEY,
    serial_code VARCHAR(80) NOT NULL UNIQUE,
    user_id INT NOT NULL,
    course_id INT NOT NULL,
    issue_shamsi VARCHAR(30) NOT NULL,
    grade_label VARCHAR(50) DEFAULT 'عالی (A)',
    hours_completed INT DEFAULT 16,
    status ENUM('valid','revoked') DEFAULT 'valid',
    revoked_reason VARCHAR(255) NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۴۰. کلاس‌ها، تجهیزات، رزرو بدون تداخل و اعلام خرابی 
CREATE TABLE IF NOT EXISTS classrooms (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    capacity INT NOT NULL DEFAULT 35,
    equipment VARCHAR(300) DEFAULT 'ویدئوپروژکتور لیزری، سیستم کنفرانس، ضبط تصویر، اینترنت فیبر نوری',
    hourly_fee_rial BIGINT DEFAULT 8500000,
    maintenance_status ENUM('ready','service_needed') DEFAULT 'ready',
    maintenance_note VARCHAR(255) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS classroom_bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    classroom_id INT NOT NULL,
    booked_by INT NOT NULL,
    purpose VARCHAR(200) NOT NULL,
    booking_date DATE NOT NULL,
    booking_shamsi VARCHAR(30) NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    catering_request VARCHAR(200) NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_room_slot (classroom_id, booking_date, start_time, end_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۴۱. پژوهش آموزشی، کتابخانه دانشی و امانت (بخش تخصصی و ۱۸)
CREATE TABLE IF NOT EXISTS research_projects (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(220) NOT NULL,
    lead_researcher VARCHAR(150) NOT NULL,
    methodology VARCHAR(150) DEFAULT 'پیمایشی - مصاحبه عمیق با صادرکنندگان نمونه',
    budget_rial BIGINT DEFAULT 650000000,
    progress_pct INT DEFAULT 65,
    form_id INT NULL,
    publication_summary TEXT,
    status ENUM('proposal','fieldwork','published') DEFAULT 'fieldwork'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS library_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(220) NOT NULL,
    authors VARCHAR(180) NOT NULL,
    category VARCHAR(100) DEFAULT 'گزارش بازار و تجارت خارجی',
    license_type VARCHAR(100) DEFAULT 'دسترسی آزاد فراگیران آدان',
    edition VARCHAR(40) DEFAULT 'ویرایش ۱۴۰۵',
    course_id INT NULL,
    downloads_count INT DEFAULT 42,
    available_copies INT DEFAULT 3,
    abstract_text TEXT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS library_loans (
    id INT AUTO_INCREMENT PRIMARY KEY,
    item_id INT NOT NULL,
    user_id INT NOT NULL,
    loan_shamsi VARCHAR(30) NOT NULL,
    due_shamsi VARCHAR(30) NOT NULL,
    returned_at DATETIME NULL,
    review_note VARCHAR(300) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۴۲. کارآموزی، مسابقات، منابع انسانی داخلی و موتور BPMS (بخش تخصصی، ۲۰، ۲۱، ۲۲)
CREATE TABLE IF NOT EXISTS internships (
    id INT AUTO_INCREMENT PRIMARY KEY,
    program_title VARCHAR(200) NOT NULL,
    host_org_id INT NOT NULL,
    intern_user_id INT NOT NULL,
    team_name VARCHAR(120) DEFAULT 'تیم توسعه صادرات الف',
    milestone_stage VARCHAR(120) DEFAULT 'تحویل فاز دوم: تحلیل بازار هدف',
    deliverable_file VARCHAR(255) NULL,
    rubric_score_json LONGTEXT NULL,
    total_score DECIMAL(5,2) DEFAULT 88.50,
    status ENUM('applied','active','evaluated') DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS competitions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    current_round VARCHAR(80) DEFAULT 'راند دوم - نیمه‌نهایی استانی',
    team_name VARCHAR(140) NOT NULL,
    weighted_criteria_json LONGTEXT NOT NULL,
    jury_score DECIMAL(5,2) DEFAULT 91.20,
    judge_comment VARCHAR(300) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS hr_records (
    id INT AUTO_INCREMENT PRIMARY KEY,
    staff_user_id INT NOT NULL,
    record_type ENUM('task','leave_request','periodic_eval','succession','payslip_note') NOT NULL,
    title VARCHAR(200) NOT NULL,
    details VARCHAR(400),
    kpi_score INT NULL,
    status ENUM('open','approved','rejected','done') DEFAULT 'open',
    created_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bpms_workflows (
    id INT AUTO_INCREMENT PRIMARY KEY,
    process_key VARCHAR(60) NOT NULL,
    process_title VARCHAR(200) NOT NULL,
    subject_label VARCHAR(220) NOT NULL,
    initiator_id INT NOT NULL,
    current_step VARCHAR(140) NOT NULL,
    assigned_role VARCHAR(60) NOT NULL,
    sla_hours INT DEFAULT 48,
    elapsed_hours INT DEFAULT 14,
    status ENUM('running','approved','rejected') DEFAULT 'running',
    history_json LONGTEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۴۳. گزارش‌ساز BI، مدیریت AI، RAG، وب‌هوک‌ها و افزونه‌های سراسری (بخش تخصصی، ۲۴ و پلاگین‌ها)
CREATE TABLE IF NOT EXISTS saved_reports (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(180) NOT NULL,
    dataset_key VARCHAR(60) NOT NULL,
    filter_expr VARCHAR(120) NULL,
    cron_schedule VARCHAR(60) DEFAULT '0 7 * * 6',
    ai_insight TEXT NULL,
    created_by INT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ai_prompts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(60) NOT NULL UNIQUE,
    title VARCHAR(180) NOT NULL,
    module_name VARCHAR(80) NOT NULL,
    system_prompt TEXT NOT NULL,
    temperature DECIMAL(3,2) DEFAULT 0.40
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ai_usage_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    module_name VARCHAR(80) NOT NULL,
    provider VARCHAR(50) DEFAULT 'AI',
    model_name VARCHAR(80) NOT NULL,
    prompt_tokens INT DEFAULT 0,
    completion_tokens INT DEFAULT 0,
    latency_ms INT DEFAULT 0,
    execution_mode ENUM('live_api','simulation_fallback') DEFAULT 'simulation_fallback',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS rag_documents (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    category VARCHAR(80) DEFAULT 'دستورالعمل آموزشی مؤسسه آدان',
    keywords VARCHAR(255) NOT NULL,
    chunk_text LONGTEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS webhooks_and_jobs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    entry_kind ENUM('webhook','queue_job') DEFAULT 'webhook',
    name VARCHAR(160) NOT NULL,
    target_url_or_handler VARCHAR(255) NOT NULL,
    event_trigger VARCHAR(80) DEFAULT 'enrollment.created',
    status ENUM('active','queued','completed','failed','draft_local') DEFAULT 'draft_local',
    last_response VARCHAR(255) DEFAULT 'پیش‌نویس محلی؛ ارسال بیرونی فعال نیست',
    last_run_at DATETIME NULL DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS documents (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    doc_category VARCHAR(80) DEFAULT 'اسناد رسمی و بخشنامه‌ها',
    file_name VARCHAR(200) NOT NULL,
    file_path VARCHAR(255) NOT NULL,
    uploaded_by INT NOT NULL,
    access_scope ENUM('public','staff','org_only') DEFAULT 'staff',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS dynamic_forms (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    slug VARCHAR(120) NOT NULL UNIQUE,
    purpose VARCHAR(150) DEFAULT 'نظرسنجی و گردآوری داده پژوهشی',
    fields_json LONGTEXT NOT NULL,
    submissions_count INT DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS form_submissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    form_id INT NOT NULL,
    user_id INT NULL,
    payload_json LONGTEXT NOT NULL,
    submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS portal_pages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    slug VARCHAR(80) NOT NULL,
    version_no INT NOT NULL DEFAULT 1,
    hero_title VARCHAR(240) NOT NULL,
    hero_subtitle VARCHAR(400) NOT NULL,
    announcement_bar VARCHAR(255) NULL,
    featured_boxes_json LONGTEXT NOT NULL,
    is_published TINYINT(1) DEFAULT 0,
    edited_by INT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS marketing_campaigns (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    segment_name VARCHAR(140) NOT NULL,
    channel ENUM('sms_sandbox','email_sandbox','telegram_sandbox') DEFAULT 'sms_sandbox',
    variant_a_text VARCHAR(400) NOT NULL,
    variant_b_text VARCHAR(400) NOT NULL,
    human_approved TINYINT(1) DEFAULT 0,
    scheduled_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۳ ساعت ۱۰:۰۰',
    conversion_a_pct DECIMAL(4,1) DEFAULT NULL,
    conversion_b_pct DECIMAL(4,1) DEFAULT NULL,
    status ENUM('draft','awaiting_approval','scheduled','sent_simulated') DEFAULT 'awaiting_approval'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS market_intel (
    id INT AUTO_INCREMENT PRIMARY KEY,
    region ENUM('ایران','اتحادیه اروپا','خلیج فارس و اوراسیا') DEFAULT 'اتحادیه اروپا',
    competitor_or_source VARCHAR(200) NOT NULL,
    source_url VARCHAR(255) NOT NULL,
    trend_topic VARCHAR(220) NOT NULL,
    ai_gap_summary TEXT NOT NULL,
    last_checked_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS psychometric_results (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    test_name VARCHAR(160) DEFAULT 'سنجش سبک مذاکره تجاری و شایستگی رفتاری (نسخه قطعی)',
    analytical_score INT NOT NULL,
    collaborative_score INT NOT NULL,
    decisive_score INT NOT NULL,
    resilience_score INT NOT NULL,
    dominant_style VARCHAR(140) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS user_badges (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    badge_code VARCHAR(60) NOT NULL UNIQUE,
    badge_title VARCHAR(160) NOT NULL,
    skill_domain VARCHAR(120) NOT NULL,
    issued_shamsi VARCHAR(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS support_tickets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    subject VARCHAR(200) NOT NULL,
    department VARCHAR(80) DEFAULT 'آموزش و گواهی‌نامه‌ها',
    message TEXT NOT NULL,
    reply_text TEXT NULL,
    status ENUM('open','answered','closed') DEFAULT 'open',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bpms_routing_rules (
    id INT AUTO_INCREMENT PRIMARY KEY,
    rule_name VARCHAR(180) NOT NULL,
    process_key VARCHAR(60) NOT NULL,
    condition_expr VARCHAR(200) NOT NULL,
    routing_mode ENUM('sequential','parallel','conditional') DEFAULT 'conditional',
    target_roles VARCHAR(160) NOT NULL,
    sla_hours INT DEFAULT 24,
    is_active TINYINT(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE invoices ADD COLUMN IF NOT EXISTS event_id INT NULL;

CREATE TABLE IF NOT EXISTS scorm_cmi_tracks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    lesson_id INT NOT NULL DEFAULT 1,
    sco_identifier VARCHAR(120) DEFAULT 'INCOTERMS_2020_SCO_01',
    lesson_status VARCHAR(40) DEFAULT 'incomplete',
    score_raw DECIMAL(6,2) DEFAULT 0.00,
    score_max DECIMAL(6,2) DEFAULT 100.00,
    session_time VARCHAR(30) DEFAULT '00:05:12',
    lesson_location VARCHAR(120) DEFAULT 'slide_1',
    suspend_data TEXT NULL,
    cmi_json LONGTEXT NULL,
    commit_count INT DEFAULT 1,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_scorm_user_lesson (user_id, lesson_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS payment_transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    invoice_id INT NOT NULL,
    authority_code VARCHAR(80) NOT NULL,
    ref_id VARCHAR(80) NOT NULL,
    amount_rial BIGINT NOT NULL,
    gateway_mode VARCHAR(50) DEFAULT 'sandbox_hmac_signed',
    hmac_signature VARCHAR(128) NOT NULL,
    is_reconciled TINYINT(1) DEFAULT 0,
    reconciled_at DATETIME NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==================== فازهای ۷ تا ۱۰: بخش‌های سامانه راهبردی مؤسسه آموزشی آدان (ماژول‌های ۲۵ تا ۳۸) ====================

-- آموزش‌های الزامی متقاضیان صدور و تمدید کارت بازرگانی
CREATE TABLE IF NOT EXISTS commercial_card_cases (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tracking_code VARCHAR(50) NOT NULL UNIQUE,
    applicant_name VARCHAR(180) NOT NULL,
    national_or_legal_id VARCHAR(30) NOT NULL,
    card_request_type ENUM('صدور اولیه حقیقی','صدور اولیه حقوقی','تمدید کارت بازرگانی') DEFAULT 'صدور اولیه حقوقی',
    attendance_pct INT DEFAULT 0,
    exam_score DECIMAL(5,2) DEFAULT 0.00,
    aml_declaration TINYINT(1) DEFAULT 1,
    clearance_status ENUM('در حال گذراندن دوره','تأیید نهایی واحد آموزش','نیازمند آزمون مجدد') DEFAULT 'در حال گذراندن دوره',
    clearance_code VARCHAR(70) NULL,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- کلاس آنلاین زنده و وبینار (اسکای‌روم / ادوبی‌کانکت / BBB)
CREATE TABLE IF NOT EXISTS virtual_class_rooms (
    id INT AUTO_INCREMENT PRIMARY KEY,
    run_id INT NOT NULL DEFAULT 1,
    provider ENUM('Skyroom','BigBlueButton','AdobeConnect') DEFAULT 'Skyroom',
    room_title VARCHAR(200) NOT NULL,
    sso_slug VARCHAR(120) NOT NULL,
    online_participants INT DEFAULT 0,
    synced_attendance_count INT DEFAULT 0,
    recording_url VARCHAR(255) NULL,
    connection_mode VARCHAR(40) DEFAULT 'not_configured',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- سامانه مؤدیان مالیاتی و پل نرم‌افزارهای حسابداری ایران
CREATE TABLE IF NOT EXISTS tax_moadian_packets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    invoice_id INT NOT NULL,
    tax_unique_id_22 VARCHAR(30) NOT NULL,
    invoice_pattern VARCHAR(60) DEFAULT 'الگوی اول - فروش خدمات آموزشی',
    accounting_target ENUM('سپیدار همکاران','همکاران سیستم','هلو','محک') DEFAULT 'سپیدار همکاران',
    payload_sha256 VARCHAR(128) NOT NULL,
    submission_status VARCHAR(60) DEFAULT 'پیش‌نویس محلی - ارسال نشده',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- هیئت‌های تجاری اعزامی/پذیرشی و تورهای صنعتی
CREATE TABLE IF NOT EXISTS trade_missions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    mission_code VARCHAR(40) NOT NULL,
    title VARCHAR(220) NOT NULL,
    mission_type ENUM('هیئت تجاری اعزامی','هیئت تجاری پذیرشی','تور بازدید صنعتی استان') DEFAULT 'هیئت تجاری اعزامی',
    target_country_or_city VARCHAR(100) NOT NULL,
    sector_focus VARCHAR(150) NOT NULL,
    shamsi_dates VARCHAR(80) NOT NULL,
    delegates_count INT DEFAULT 12,
    b2b_meetings_count INT DEFAULT 35,
    mou_value_usd BIGINT DEFAULT 0,
    status VARCHAR(50) DEFAULT 'در حال ثبت‌نام اعضا'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- کمیسیون‌های تخصصی، تشکل‌های صادراتی و اتاق‌های مشترک
CREATE TABLE IF NOT EXISTS chamber_commissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    commission_name VARCHAR(180) NOT NULL,
    chairperson_name VARCHAR(150) NOT NULL,
    resolution_title VARCHAR(240) NOT NULL,
    requested_course_topic VARCHAR(220) NOT NULL,
    priority_level ENUM('فوری استانی','اولویت فصلی','برنامه سالانه') DEFAULT 'فوری استانی',
    converted_to_tms TINYINT(1) DEFAULT 0,
    session_shamsi VARCHAR(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- تضمین کیفیت، ممیزی استاندارد ISO 21001 / ISO 10015 و CAPA
CREATE TABLE IF NOT EXISTS iso_qa_records (
    id INT AUTO_INCREMENT PRIMARY KEY,
    standard_code VARCHAR(60) DEFAULT 'ISO 21001:2018',
    clause_title VARCHAR(200) NOT NULL,
    finding_type ENUM('انطباق کامل','عدم انطباق جزئی','فرصت بهبود') DEFAULT 'انطباق کامل',
    capa_action TEXT NOT NULL,
    owner_unit VARCHAR(120) NOT NULL,
    status ENUM('باز','اقدام اصلاحی انجام شد','تأیید ممیز نهایی') DEFAULT 'تأیید ممیز نهایی',
    audit_shamsi VARCHAR(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- کلینیک عارضه‌یابی صنعتی و سنجش آمادگی صادراتی (ERA)
CREATE TABLE IF NOT EXISTS business_clinic_cases (
    id INT AUTO_INCREMENT PRIMARY KEY,
    org_name VARCHAR(180) NOT NULL,
    industry_sector VARCHAR(120) NOT NULL,
    era_production_score INT DEFAULT 70,
    era_packaging_score INT DEFAULT 55,
    era_marketing_score INT DEFAULT 45,
    era_finance_legal_score INT DEFAULT 60,
    total_era_index INT DEFAULT 58,
    main_bottleneck VARCHAR(220) NOT NULL,
    prescribed_pack VARCHAR(240) NOT NULL,
    diagnosed_shamsi VARCHAR(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بازارگاه اشتغال تخصصی و همرسانی نیروی ماهر به صنایع عضو
CREATE TABLE IF NOT EXISTS job_board_listings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    org_name VARCHAR(180) NOT NULL,
    job_title VARCHAR(180) NOT NULL,
    required_cert_code VARCHAR(80) NOT NULL,
    city VARCHAR(80) DEFAULT 'مرکز استان',
    salary_range VARCHAR(100) DEFAULT 'توافقی + بیمه تکمیلی',
    matched_candidates INT DEFAULT 3,
    status ENUM('فعال','در مرحله مصاحبه','جذب شد') DEFAULT 'فعال',
    posted_shamsi VARCHAR(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- تفاهم‌نامه‌ها (MoU)، یارانه‌های آموزشی SMEها و اسپانسرینگ
CREATE TABLE IF NOT EXISTS grants_and_mous (
    id INT AUTO_INCREMENT PRIMARY KEY,
    record_category ENUM('تفاهم‌نامه همکاری','یارانه آموزشی SME','حامی مالی همایش') DEFAULT 'یارانه آموزشی SME',
    partner_organization VARCHAR(200) NOT NULL,
    title VARCHAR(220) NOT NULL,
    subsidy_percent INT DEFAULT 50,
    allocated_budget_rial BIGINT DEFAULT 500000000,
    utilized_rial BIGINT DEFAULT 180000000,
    expiry_shamsi VARCHAR(30) NOT NULL,
    status VARCHAR(50) DEFAULT 'فعال و قابل تخصیص'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- احراز هویت یکپارچه کشوری، شاهکار، OTP و امضای دیجیتال اسناد
CREATE TABLE IF NOT EXISTS sso_pki_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_full_name VARCHAR(160) NOT NULL,
    national_code VARCHAR(20) NOT NULL,
    mobile_number VARCHAR(20) NOT NULL,
    shahkar_status VARCHAR(100) DEFAULT 'شبیه‌سازی محلی - اتصال شاهکار انجام نشده',
    document_title VARCHAR(200) NOT NULL,
    pki_hash_sha256 VARCHAR(128) NOT NULL,
    signed_shamsi VARCHAR(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- نظارت هوشمند آزمون (Proctoring) و حفاظت محتوا (DRM Watermark)
CREATE TABLE IF NOT EXISTS proctoring_events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_full_name VARCHAR(160) NOT NULL,
    exam_or_lesson_title VARCHAR(200) NOT NULL,
    event_type ENUM('تغییر تب مرورگر','خروج از تمام‌صفحه','تغییر آدرس IP','فعال‌سازی واترمارک پویا') DEFAULT 'تغییر تب مرورگر',
    risk_level ENUM('کم','متوسط','شدید - بازبینی کمیته') DEFAULT 'کم',
    watermark_stamp VARCHAR(140) NOT NULL,
    reviewer_decision VARCHAR(80) DEFAULT 'تأیید سلامت آزمون',
    logged_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- باشگاه دانش‌آموختگان و شبکه‌سازی مدیران اتاق
CREATE TABLE IF NOT EXISTS alumni_network_posts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    author_name VARCHAR(160) NOT NULL,
    company_and_role VARCHAR(180) NOT NULL,
    graduated_course VARCHAR(180) NOT NULL,
    collaboration_type ENUM('کنسرسیوم صادراتی','تأمین مواد اولیه','همرسانی حمل‌ونقل','پرسش تخصصی همتایان') DEFAULT 'کنسرسیوم صادراتی',
    proposal_body TEXT NOT NULL,
    responses_count INT DEFAULT 4,
    posted_shamsi VARCHAR(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- درگاه پیامک ایرانی و بازوهای پیام‌رسان بومی (بله و ایتا)
CREATE TABLE IF NOT EXISTS iran_messenger_dispatches (
    id INT AUTO_INCREMENT PRIMARY KEY,
    channel ENUM('کاوه‌نگار SMS','ملی‌پیامک SMS','بازوی بله (Bale)','بازوی ایتا (Eitaa)') DEFAULT 'کاوه‌نگار SMS',
    recipient_group VARCHAR(160) NOT NULL,
    message_text TEXT NOT NULL,
    delivery_mode VARCHAR(50) DEFAULT 'ثبت محلی - ارسال نشده',
    sent_count INT DEFAULT 0,
    sent_shamsi VARCHAR(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- دفاتر نمایندگی شهرستان‌ها و مدیریت چندشعبه‌ای استان
CREATE TABLE IF NOT EXISTS county_branches (
    id INT AUTO_INCREMENT PRIMARY KEY,
    county_name VARCHAR(120) NOT NULL,
    branch_manager VARCHAR(150) NOT NULL,
    active_courses_count INT DEFAULT 4,
    trained_learners_count INT DEFAULT 120,
    annual_budget_rial BIGINT DEFAULT 1200000000,
    spent_budget_rial BIGINT DEFAULT 680000000,
    key_specialty VARCHAR(180) NOT NULL,
    status VARCHAR(40) DEFAULT 'فعال'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- فازهای ۱۱ تا ۱۳: جداول تکمیلی عمیق هسته عملیاتی (یادداشت ثانیه‌ای، چک‌های صیادی ۱۶ رقمی، آزمایشگاه اسناد بازرگانی و داوری همتای پژوهش)
CREATE TABLE IF NOT EXISTS lms_learner_notes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    lesson_id INT NOT NULL,
    video_timestamp VARCHAR(16) DEFAULT '00:00',
    note_body TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ★ v26.8 — یادداشت‌های ثانیه‌ای نمونه فراگیر (خوراک «کارت‌سازی خودکار از یادداشت‌ها» در مربی هوشمند)
INSERT IGNORE INTO lms_learner_notes (id, user_id, lesson_id, video_timestamp, note_body) VALUES
(1, 7, 1, '07:12', 'در اینکوترمز ۲۰۲۰، با CIF هزینه و ریسک حمل تا بندر مقصد با فروشنده است، اما بیمه فقط حداقل پوشش (Institute Cargo Clauses C) است؛ برای کالای حساس باید پوشش All Risks را جداگانه درخواست کنم.'),
(2, 7, 1, '18:40', 'نکته آزمون: در EXW انتقال ریسک در محل فروشنده اتفاق می‌افتد، پس ترخیص خروجی هم با خریدار است — این قلاب پرتکرار را در سؤالات تطبیق فراموش نکنم.'),
(3, 7, 2, '05:25', 'مبنای حق‌الوکاله کارگزاری: درصدی از ارزش CIF به‌همراه هزینه‌های جانبی؛ در پرونده قبلی هزینه انبارش را جدا محاسبه کردند، باید آن را در چک‌لیست مذاکره بیاورم.'),
(4, 7, 3, '11:05', 'در اعتبار اسنادی، تطابق اسناد حداکثر پنج روز کاری بررسی می‌شود؛ تاریخ سررسید سند را در تقویم شمسی ثبت می‌کنم تا پشت‌افتادگی پیدا نشود.'),
(5, 8, 2, '03:50', 'خلاصه شخصی من: در FOB، هزینه بارگیری و ریسک تا روی عرشه با فروشنده است و بیمه دریایی از همان لحظه به خریدار منتقل می‌شود.');

CREATE TABLE IF NOT EXISTS sayad_cheques (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sayad_16digit VARCHAR(20) NOT NULL UNIQUE,
    drawer_company VARCHAR(190) NOT NULL,
    bank_name VARCHAR(90) NOT NULL,
    amount_rial BIGINT NOT NULL DEFAULT 0,
    due_shamsi VARCHAR(20) NOT NULL,
    inquiry_color VARCHAR(40) DEFAULT 'سفید - بدون چک برگشتی',
    clearance_status VARCHAR(40) DEFAULT 'در جریان وصول',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS trade_doc_submissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    doc_type VARCHAR(70) NOT NULL,
    hs_code VARCHAR(25) NOT NULL,
    incoterm_rule VARCHAR(20) NOT NULL,
    currency_amount VARCHAR(60) NOT NULL,
    destination_port VARCHAR(120) NOT NULL,
    compliance_score INT DEFAULT 100,
    audit_feedback TEXT,
    submitted_shamsi VARCHAR(25) DEFAULT '',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS research_peer_reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL,
    reviewer_alias VARCHAR(90) NOT NULL,
    scientific_score INT DEFAULT 85,
    applicability_score INT DEFAULT 90,
    recommendation VARCHAR(60) DEFAULT 'تأیید و آزادسازی قسط بودجه',
    review_comment TEXT,
    reviewed_shamsi VARCHAR(25) DEFAULT '',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- محورهای ۳، ۴ و ۸ نسخه v8.0: جداول اسلات مذاکرات B2B، سند حسابداری ۴ سطحی دوبل و گفت‌وگوی چندنوبته مذاکره تجاری
CREATE TABLE IF NOT EXISTS b2b_matchmaking_slots (
    id INT AUTO_INCREMENT PRIMARY KEY,
    mission_id INT NOT NULL DEFAULT 1,
    slot_time VARCHAR(40) NOT NULL,
    table_no VARCHAR(25) NOT NULL,
    iranian_company VARCHAR(190) NOT NULL,
    foreign_counterpart VARCHAR(190) NOT NULL,
    product_hs_focus VARCHAR(150) NOT NULL,
    interpreter_lang VARCHAR(50) DEFAULT 'عربی / انگلیسی',
    outcome_status VARCHAR(60) DEFAULT 'برنامه‌ریزی شده',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS accounting_vouchers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    voucher_no VARCHAR(40) NOT NULL UNIQUE,
    voucher_shamsi VARCHAR(25) NOT NULL,
    group_code VARCHAR(40) NOT NULL,
    kol_account VARCHAR(90) NOT NULL,
    moein_account VARCHAR(120) NOT NULL,
    tafsili_entity VARCHAR(150) NOT NULL,
    debit_rial BIGINT NOT NULL DEFAULT 0,
    credit_rial BIGINT NOT NULL DEFAULT 0,
    voucher_desc VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS trade_negotiation_turns (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    scenario_lang VARCHAR(30) DEFAULT 'fa',
    buyer_persona VARCHAR(140) DEFAULT 'واردکننده عمده خشکبار در دبی',
    exporter_message TEXT NOT NULL,
    ai_counter_offer TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- رادار هوشمند بازار آموزش، پایش زنده رقبا در وب و تحقیق و توسعه (Market Radar & R&D Intelligence)
CREATE TABLE IF NOT EXISTS rd_competitors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(180) NOT NULL,
    category VARCHAR(90) NOT NULL,
    website_url VARCHAR(255) NOT NULL,
    city_scope VARCHAR(80) DEFAULT 'ملی / آنلاین',
    avg_hourly_rate_rial BIGINT DEFAULT 3000000,
    delivery_model VARCHAR(90) DEFAULT 'حضوری و آنلاین هم‌زمان',
    key_strengths TEXT,
    key_weaknesses TEXT,
    last_crawled_at VARCHAR(40) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS rd_competitor_courses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    competitor_id INT NOT NULL,
    course_title VARCHAR(220) NOT NULL,
    duration_hours INT DEFAULT 24,
    tuition_rial BIGINT DEFAULT 45000000,
    delivery_format VARCHAR(60) DEFAULT 'آنلاین / حضوری',
    source_url VARCHAR(500) DEFAULT '',
    our_catalog_status VARCHAR(90) DEFAULT 'شکاف کاتالوگ (اقیانوس آبی)',
    captured_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS rd_web_signals (
    id INT AUTO_INCREMENT PRIMARY KEY,
    keyword_query VARCHAR(160) NOT NULL,
    signal_title VARCHAR(255) NOT NULL,
    source_engine VARCHAR(70) DEFAULT 'DuckDuckGo Live Web',
    source_url VARCHAR(600) DEFAULT '',
    demand_score INT DEFAULT 88,
    competition_saturation INT DEFAULT 35,
    opportunity_index INT DEFAULT 82,
    catalog_gap_status VARCHAR(90) DEFAULT 'شکاف طلایی کاتالوگ (پیشنهاد ساخت)',
    discovered_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS rd_course_proposals (
    id INT AUTO_INCREMENT PRIMARY KEY,
    proposal_code VARCHAR(40) NOT NULL UNIQUE,
    proposed_title VARCHAR(220) NOT NULL,
    target_audience VARCHAR(180) NOT NULL,
    recommended_hours INT DEFAULT 24,
    competitor_avg_rial BIGINT DEFAULT 68000000,
    suggested_tuition_rial BIGINT DEFAULT 58000000,
    breakeven_learners INT DEFAULT 9,
    projected_net_rial BIGINT DEFAULT 620000000,
    strategic_rationale TEXT NOT NULL,
    syllabus_outline TEXT NOT NULL,
    ai_confidence_score INT DEFAULT 92,
    status VARCHAR(70) DEFAULT 'آماده طرح در شورای R&D',
    launched_course_id INT DEFAULT NULL,
    created_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- آرشیو نتایج آزمون‌های استاندارد روان‌شناختی، شغلی، زبان و صلاحیت حرفه‌ای
CREATE TABLE IF NOT EXISTS standard_test_catalog (
    id INT AUTO_INCREMENT PRIMARY KEY,
    test_code VARCHAR(40) NOT NULL UNIQUE,
    category_key VARCHAR(40) NOT NULL,
    category_label VARCHAR(90) NOT NULL,
    title_fa VARCHAR(200) NOT NULL,
    standard_ref VARCHAR(120) NOT NULL,
    duration_min INT DEFAULT 10,
    items_count INT DEFAULT 6,
    scale_type VARCHAR(40) DEFAULT 'psychometric',
    summary_text VARCHAR(255) NOT NULL,
    recommended_course VARCHAR(190) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS standard_test_results (
    id INT AUTO_INCREMENT PRIMARY KEY,
    report_code VARCHAR(45) NOT NULL UNIQUE,
    user_id INT NOT NULL,
    test_code VARCHAR(40) NOT NULL,
    test_title VARCHAR(200) NOT NULL,
    result_badge VARCHAR(140) NOT NULL,
    score_pct INT DEFAULT 85,
    interpretation_text TEXT NOT NULL,
    recommended_course VARCHAR(190) NOT NULL,
    dimensions_json TEXT,
    completed_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- مرکز فرماندهی صوتی سراسری، مفسر زبان طبیعی فارسی و عامل اقدام‌گر (Global Voice Action OS)
CREATE TABLE IF NOT EXISTS voice_command_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL DEFAULT 1,
    spoken_text VARCHAR(500) NOT NULL,
    detected_intent VARCHAR(50) NOT NULL,
    target_route VARCHAR(80) DEFAULT '',
    action_summary VARCHAR(255) NOT NULL,
    spoken_response TEXT NOT NULL,
    created_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- هسته مرکزی ERP هوشمند، قوانین خودران میان‌ماژولی، پیش‌بینی RFM، زمان‌بند محدودیت‌محور و تطبیق مهارت-صنعت (جداول ۹۶ تا ۱۰۰)
CREATE TABLE IF NOT EXISTS erp_automation_rules (
    id INT AUTO_INCREMENT PRIMARY KEY,
    rule_code VARCHAR(40) NOT NULL UNIQUE,
    rule_title VARCHAR(200) NOT NULL,
    source_module VARCHAR(80) NOT NULL,
    trigger_condition VARCHAR(220) NOT NULL,
    target_modules VARCHAR(180) NOT NULL,
    autonomous_action VARCHAR(255) NOT NULL,
    executions_count INT DEFAULT 0,
    last_triggered_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS erp_smart_alerts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    alert_code VARCHAR(40) NOT NULL UNIQUE,
    severity VARCHAR(20) NOT NULL DEFAULT 'warning',
    module_route VARCHAR(80) NOT NULL,
    alert_title VARCHAR(210) NOT NULL,
    ai_diagnosis TEXT NOT NULL,
    prescribed_action VARCHAR(240) NOT NULL,
    financial_impact_rial BIGINT DEFAULT 0,
    status VARCHAR(30) DEFAULT 'open',
    resolved_shamsi VARCHAR(30) DEFAULT '',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS crm_rfm_scores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    org_id INT NOT NULL,
    org_name VARCHAR(180) NOT NULL,
    recency_days INT DEFAULT 18,
    frequency_count INT DEFAULT 4,
    monetary_rial BIGINT DEFAULT 180000000,
    rfm_composite INT DEFAULT 85,
    segment_label VARCHAR(80) NOT NULL,
    churn_probability_pct INT DEFAULT 12,
    next_best_course VARCHAR(200) NOT NULL,
    prescribed_discount_pct INT DEFAULT 10,
    updated_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ai_schedule_optimizations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_code VARCHAR(40) NOT NULL,
    course_title VARCHAR(200) NOT NULL,
    instructor_name VARCHAR(140) NOT NULL,
    classroom_name VARCHAR(140) NOT NULL,
    assigned_slot VARCHAR(90) NOT NULL,
    predicted_learners INT DEFAULT 22,
    room_capacity INT DEFAULT 25,
    utilization_pct INT DEFAULT 88,
    conflict_status VARCHAR(80) DEFAULT 'بدون تداخل (بهینه ۱۰۰٪)',
    generated_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ai_skill_job_matches (
    id INT AUTO_INCREMENT PRIMARY KEY,
    candidate_name VARCHAR(140) NOT NULL,
    psychometric_badge VARCHAR(120) NOT NULL,
    target_company VARCHAR(180) NOT NULL,
    job_role_title VARCHAR(180) NOT NULL,
    match_score_pct INT DEFAULT 91,
    verified_skills VARCHAR(240) NOT NULL,
    recommended_gap_course VARCHAR(190) NOT NULL,
    status VARCHAR(60) DEFAULT 'معرفی‌شده هوشمند به صنعت',
    matched_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- نسخه مرجع v12.0: مجموعه عمیق‌سازی تخصصی ماژول‌های صنعتی، مالیاتی، تطبیقی CAT، کنسرسیوم صادراتی و کمیسیون‌ها (جداول ۱۰۱ تا ۱۰۵)
CREATE TABLE IF NOT EXISTS factory_prescriptions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    rx_code VARCHAR(40) NOT NULL UNIQUE,
    factory_name VARCHAR(180) NOT NULL,
    sector VARCHAR(100) NOT NULL,
    prod_score INT DEFAULT 70,
    energy_cbam_score INT DEFAULT 55,
    export_fx_score INT DEFAULT 62,
    working_cap_score INT DEFAULT 68,
    b2b_brand_score INT DEFAULT 58,
    hr_skill_score INT DEFAULT 64,
    ai_digital_score INT DEFAULT 50,
    overall_health_idx INT DEFAULT 61,
    primary_bottleneck VARCHAR(220) NOT NULL,
    roadmap_180d TEXT NOT NULL,
    assigned_consultant VARCHAR(140) NOT NULL,
    approved_subsidy_pct INT DEFAULT 30,
    created_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS adaptive_cat_sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    session_code VARCHAR(40) NOT NULL UNIQUE,
    candidate_name VARCHAR(140) NOT NULL,
    domain_title VARCHAR(160) NOT NULL,
    questions_administered INT DEFAULT 6,
    final_difficulty_level INT DEFAULT 4,
    theta_ability DECIMAL(4,2) DEFAULT 1.85,
    cefr_or_mastery_band VARCHAR(90) NOT NULL,
    tab_switches_detected INT DEFAULT 0,
    collusion_similarity_pct INT DEFAULT 4,
    integrity_score INT DEFAULT 98,
    completed_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ocr_financial_scans (
    id INT AUTO_INCREMENT PRIMARY KEY,
    scan_code VARCHAR(40) NOT NULL UNIQUE,
    doc_type VARCHAR(60) NOT NULL,
    raw_extracted_text TEXT NOT NULL,
    detected_amount_rial BIGINT NOT NULL DEFAULT 0,
    detected_sayad_or_ref VARCHAR(40) NOT NULL,
    detected_iban VARCHAR(34) DEFAULT '',
    checksum_verified TINYINT(1) DEFAULT 0,
    moadian_vat_status VARCHAR(120) DEFAULT 'پیش‌نویس محلی - وضعیت مالیاتی بررسی نشده/ارسال نشده',
    booked_voucher_no VARCHAR(40) NOT NULL DEFAULT '',
    scanned_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS export_consortium_groups (
    id INT AUTO_INCREMENT PRIMARY KEY,
    consortium_code VARCHAR(40) NOT NULL UNIQUE,
    consortium_title VARCHAR(200) NOT NULL,
    target_market VARCHAR(100) NOT NULL,
    hs_code_cluster VARCHAR(80) NOT NULL,
    lead_producer_org VARCHAR(160) NOT NULL,
    packaging_logistics_org VARCHAR(160) NOT NULL,
    trading_house_org VARCHAR(160) NOT NULL,
    synergy_score_pct INT DEFAULT 92,
    annual_target_usd BIGINT DEFAULT 1200000,
    status VARCHAR(80) DEFAULT 'پیش‌نویس اساسنامه کنسرسیوم آماده امضا',
    created_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS commission_policy_briefs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    brief_code VARCHAR(40) NOT NULL UNIQUE,
    commission_name VARCHAR(160) NOT NULL,
    recipient_authority VARCHAR(160) NOT NULL,
    issue_summary VARCHAR(240) NOT NULL,
    legal_citation VARCHAR(220) NOT NULL,
    formal_letter_body TEXT NOT NULL,
    status VARCHAR(60) DEFAULT 'آماده امضای مدیر مؤسسه آدان استان',
    created_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- نسخه مرجع نهایی v13.0: قله نهایی هوشمندی صددرصدی تمام ماژول‌ها (یادگیری تطبیقی LMS، ممیزی قرارداد صادراتی، مرجعیت اساتید، معدن‌کاوی BPMS و آمایش شهرستان‌ها — جداول ۱۰۶ تا ۱۱۰)
CREATE TABLE IF NOT EXISTS lms_adaptive_paths (
    id INT AUTO_INCREMENT PRIMARY KEY,
    learner_name VARCHAR(140) NOT NULL,
    course_title VARCHAR(190) NOT NULL,
    lesson_timestamp VARCHAR(30) DEFAULT '۱۲:۴۰',
    learner_question VARCHAR(255) NOT NULL,
    ai_timestamp_answer TEXT NOT NULL,
    quiz_diagnostic_pct INT DEFAULT 62,
    injected_remedial_micro VARCHAR(220) NOT NULL,
    spaced_repetition_cards INT DEFAULT 5,
    created_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS trade_contract_redlines (
    id INT AUTO_INCREMENT PRIMARY KEY,
    audit_code VARCHAR(40) NOT NULL UNIQUE,
    contract_title VARCHAR(190) NOT NULL,
    counterparty_country VARCHAR(80) NOT NULL,
    submitted_clause TEXT NOT NULL,
    safety_score_pct INT DEFAULT 54,
    detected_traps VARCHAR(255) NOT NULL,
    icc_protective_rewrite TEXT NOT NULL,
    audited_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS instructor_impact_scores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    instructor_name VARCHAR(140) NOT NULL,
    kirkpatrick_avg DECIMAL(3,2) DEFAULT 4.75,
    exam_pass_rate_pct INT DEFAULT 92,
    repeat_retention_pct INT DEFAULT 84,
    sla_punctuality_pct INT DEFAULT 96,
    composite_impact_score INT DEFAULT 91,
    academic_tier_badge VARCHAR(80) NOT NULL,
    suggested_hourly_rial BIGINT DEFAULT 6500000,
    evaluated_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bpms_process_mining (
    id INT AUTO_INCREMENT PRIMARY KEY,
    stage_code VARCHAR(40) NOT NULL UNIQUE,
    department_stage VARCHAR(160) NOT NULL,
    active_cases_count INT DEFAULT 12,
    avg_dwell_hours DECIMAL(5,1) DEFAULT 6.5,
    sla_target_hours INT DEFAULT 12,
    bottleneck_severity VARCHAR(140) DEFAULT 'سبز — داخل SLA',
    auto_escalation_rule VARCHAR(220) NOT NULL,
    mined_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS county_economic_clusters (
    id INT AUTO_INCREMENT PRIMARY KEY,
    county_name VARCHAR(120) NOT NULL,
    dominant_cluster VARCHAR(160) NOT NULL,
    active_industrial_units INT DEFAULT 140,
    skill_gap_index INT DEFAULT 76,
    prescribed_mobile_workshop VARCHAR(210) NOT NULL,
    recommended_budget_share_pct INT DEFAULT 22,
    projected_export_boost_usd BIGINT DEFAULT 850000,
    analyzed_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- نسخه مرجع فوق‌پیشرفته v14.0: اتاق جنگ مدیران عامل، بهینه‌ساز یارانه SME، قیمت‌گذاری پویا، پایش سوخت سهمیه B2B، مسیریاب عمومی و جست‌وجوی معنایی RAG (جداول ۱۱۱ تا ۱۱۶)
CREATE TABLE IF NOT EXISTS executive_warroom_simulations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sim_code VARCHAR(40) NOT NULL UNIQUE,
    ceo_participant VARCHAR(140) NOT NULL,
    shock_scenario VARCHAR(190) NOT NULL,
    chosen_strategy VARCHAR(220) NOT NULL,
    cashflow_runway_months DECIMAL(4,1) DEFAULT 9.5,
    export_share_retention_pct INT DEFAULT 88,
    resilience_score INT DEFAULT 90,
    board_ai_critique TEXT NOT NULL,
    simulated_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS sme_subsidy_allocations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    alloc_code VARCHAR(40) NOT NULL UNIQUE,
    sme_company_name VARCHAR(180) NOT NULL,
    employees_count INT DEFAULT 45,
    export_readiness_idx INT DEFAULT 72,
    requested_subsidy_pct INT DEFAULT 50,
    ai_approved_subsidy_pct INT DEFAULT 38,
    economic_roi_multiplier DECIMAL(4,2) DEFAULT 4.20,
    priority_rank_label VARCHAR(90) NOT NULL,
    allocated_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS tms_dynamic_pricing_rules (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_code VARCHAR(40) NOT NULL,
    course_title VARCHAR(200) NOT NULL,
    base_tuition_rial BIGINT NOT NULL,
    seat_fill_pct INT DEFAULT 78,
    days_to_start INT DEFAULT 6,
    ai_pricing_tier VARCHAR(110) NOT NULL,
    dynamic_tuition_rial BIGINT NOT NULL,
    projected_revenue_gain_pct INT DEFAULT 18,
    updated_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS b2b_quota_burn_alerts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    org_name VARCHAR(180) NOT NULL,
    contract_title VARCHAR(190) NOT NULL,
    elapsed_year_pct INT DEFAULT 68,
    quota_used_pct INT DEFAULT 31,
    burn_status VARCHAR(90) NOT NULL,
    auto_triggered_offer VARCHAR(230) NOT NULL,
    monitored_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS public_ai_pathfinder_leads (
    id INT AUTO_INCREMENT PRIMARY KEY,
    visitor_fullname VARCHAR(140) NOT NULL,
    visitor_mobile VARCHAR(30) NOT NULL,
    visitor_goal VARCHAR(160) NOT NULL,
    industry_field VARCHAR(120) NOT NULL,
    recommended_roadmap VARCHAR(240) NOT NULL,
    estimated_90d_roi VARCHAR(140) NOT NULL,
    synced_crm_status VARCHAR(80) DEFAULT 'ثبت خودکار سرنخ داغ در CRM',
    captured_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS student_admissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(160) NOT NULL,
    mobile VARCHAR(30) NOT NULL,
    course_id INT NOT NULL,
    prior_education VARCHAR(255) NULL,
    status ENUM('submitted','contacted','accepted','rejected','enrolled') DEFAULT 'submitted',
    review_note VARCHAR(500) NULL,
    user_id INT NULL,
    enrollment_id INT NULL,
    invoice_id INT NULL,
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_admission_status (status, submitted_at),
    INDEX idx_admission_course (course_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS rag_knowledge_chunks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    doc_code VARCHAR(40) NOT NULL UNIQUE,
    source_authority VARCHAR(160) NOT NULL,
    clause_reference VARCHAR(140) NOT NULL,
    topic_keywords VARCHAR(220) NOT NULL,
    chunk_text TEXT NOT NULL,
    updated_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==================== نسخه v15.0: زنجیره هش ضدجعل گواهی، لیگ شبیه‌ساز، SOC امنیتی، اعتبار مالیاتی پویش، همرسان رزومه و گذرگاه ملی NIX ====================
CREATE TABLE IF NOT EXISTS verifiable_credential_blocks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    block_height INT NOT NULL,
    cert_or_badge_code VARCHAR(60) NOT NULL,
    holder_fullname VARCHAR(150) NOT NULL,
    prev_block_hash CHAR(64) NOT NULL,
    block_sha256_hash CHAR(64) NOT NULL,
    w3c_standard_version VARCHAR(60) DEFAULT 'چکیده محلی؛ استاندارد یا امضای W3C تأیید نشده',
    sealed_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bizsim_league_rounds (
    id INT AUTO_INCREMENT PRIMARY KEY,
    round_code VARCHAR(40) NOT NULL UNIQUE,
    team_name VARCHAR(150) NOT NULL,
    quarter_label VARCHAR(50) NOT NULL,
    export_pricing_usd DECIMAL(10,2) NOT NULL DEFAULT 1250.00,
    fx_hedge_ratio_pct INT NOT NULL DEFAULT 60,
    rnd_investment_pct INT NOT NULL DEFAULT 12,
    simulated_ebitda_usd BIGINT NOT NULL DEFAULT 185000,
    elo_rating INT NOT NULL DEFAULT 1620,
    ai_referee_note VARCHAR(255) NOT NULL,
    played_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS security_soc_telemetry (
    id INT AUTO_INCREMENT PRIMARY KEY,
    event_code VARCHAR(40) NOT NULL UNIQUE,
    actor_username VARCHAR(100) NOT NULL,
    client_ip VARCHAR(60) NOT NULL,
    geo_and_device VARCHAR(160) NOT NULL,
    risk_score INT NOT NULL DEFAULT 12,
    threat_classification VARCHAR(160) NOT NULL,
    mitigation_action VARCHAR(160) NOT NULL,
    detected_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS pooyesh_stipend_claims (
    id INT AUTO_INCREMENT PRIMARY KEY,
    claim_code VARCHAR(40) NOT NULL UNIQUE,
    host_company VARCHAR(160) NOT NULL,
    intern_fullname VARCHAR(140) NOT NULL,
    duration_months INT NOT NULL DEFAULT 4,
    monthly_stipend_rial BIGINT NOT NULL DEFAULT 95000000,
    total_paid_rial BIGINT NOT NULL DEFAULT 380000000,
    tax_credit_approved_rial BIGINT NOT NULL DEFAULT 380000000,
    statutory_clause VARCHAR(180) DEFAULT 'ماده ۱۱ قانون جهش تولید دانش‌بنیان (اعتبار مالیاتی طرح پویش)',
    created_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ai_cv_match_interviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    match_code VARCHAR(40) NOT NULL UNIQUE,
    candidate_name VARCHAR(150) NOT NULL,
    target_company VARCHAR(160) NOT NULL,
    target_role VARCHAR(160) NOT NULL,
    verified_certs_summary VARCHAR(220) NOT NULL,
    vector_similarity_pct INT NOT NULL DEFAULT 91,
    generated_interview_guide TEXT NOT NULL,
    matched_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS national_bus_inquiries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    trace_code VARCHAR(45) NOT NULL UNIQUE,
    target_system VARCHAR(140) NOT NULL,
    identifier_queried VARCHAR(90) NOT NULL,
    math_checksum_valid TINYINT(1) NOT NULL DEFAULT 0,
    gateway_execution_mode VARCHAR(90) DEFAULT 'پیش‌نمایش محلی - استعلام انجام نشده',
    response_summary VARCHAR(255) NOT NULL,
    customs_duty_pct INT DEFAULT NULL,
    inquired_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==================== نسخه v16.0: تحلیل رفتار فراگیران (xAPI / LBA) و موتور گیمیفیکیشن سراسری کل سامانه ====================
CREATE TABLE IF NOT EXISTS learner_behavior_events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL DEFAULT 1,
    learner_name VARCHAR(150) NOT NULL,
    module_route VARCHAR(80) NOT NULL,
    action_verb VARCHAR(90) NOT NULL,
    dwell_seconds INT NOT NULL DEFAULT 180,
    scroll_depth_pct INT NOT NULL DEFAULT 85,
    focus_index_pct INT NOT NULL DEFAULT 92,
    study_hour_band VARCHAR(50) DEFAULT '۱۹:۰۰ تا ۲۲:۰۰ (اوج تمرکز)',
    xp_awarded INT NOT NULL DEFAULT 25,
    created_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS learner_dropout_predictions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    learner_name VARCHAR(150) NOT NULL,
    org_name VARCHAR(160) NOT NULL,
    enrolled_course VARCHAR(190) NOT NULL,
    learning_persona VARCHAR(120) NOT NULL,
    engagement_score INT NOT NULL DEFAULT 72,
    dropout_risk_pct INT NOT NULL DEFAULT 24,
    last_login_days_ago INT NOT NULL DEFAULT 2,
    ai_intervention_status VARCHAR(220) NOT NULL,
    updated_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS gamification_wallets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,
    learner_name VARCHAR(150) NOT NULL,
    org_name VARCHAR(160) NOT NULL,
    xp_points INT NOT NULL DEFAULT 1200,
    chamber_coins INT NOT NULL DEFAULT 450,
    level_num INT NOT NULL DEFAULT 4,
    rank_title VARCHAR(120) NOT NULL DEFAULT 'کارشناس ارشد تجارت',
    streak_days INT NOT NULL DEFAULT 7,
    badges_count INT NOT NULL DEFAULT 4,
    updated_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS gamification_quests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    quest_code VARCHAR(40) NOT NULL UNIQUE,
    title VARCHAR(190) NOT NULL,
    target_module_route VARCHAR(80) NOT NULL,
    difficulty_tier VARCHAR(50) NOT NULL DEFAULT 'حرفه‌ای',
    xp_reward INT NOT NULL DEFAULT 250,
    coin_reward INT NOT NULL DEFAULT 120,
    progress_pct INT NOT NULL DEFAULT 80,
    is_claimed TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS gamification_reward_store (
    id INT AUTO_INCREMENT PRIMARY KEY,
    reward_code VARCHAR(40) NOT NULL UNIQUE,
    reward_title VARCHAR(190) NOT NULL,
    category_label VARCHAR(90) NOT NULL,
    coin_cost INT NOT NULL DEFAULT 800,
    stock_remaining INT NOT NULL DEFAULT 15,
    redeemed_count INT NOT NULL DEFAULT 3,
    last_voucher_serial VARCHAR(80) DEFAULT 'VCH-GAM-1405-INIT',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS content_friction_heatmaps (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_title VARCHAR(190) NOT NULL,
    lesson_segment VARCHAR(160) NOT NULL,
    avg_rewind_count DECIMAL(4,1) NOT NULL DEFAULT 3.2,
    dropoff_rate_pct INT NOT NULL DEFAULT 28,
    quiz_error_rate_pct INT NOT NULL DEFAULT 35,
    ai_pedagogical_fix VARCHAR(240) NOT NULL,
    analyzed_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==================== نسخه v17.0: پیشخوان‌های اختصاصی نقش‌محور ۸گانه و موتور عملیاتی هر نقش (Role-Personalized Cockpits) ====================
CREATE TABLE IF NOT EXISTS executive_signoff_queue (
    id INT AUTO_INCREMENT PRIMARY KEY,
    doc_ref_no VARCHAR(45) NOT NULL UNIQUE,
    doc_category VARCHAR(120) NOT NULL,
    subject_title VARCHAR(210) NOT NULL,
    amount_or_impact VARCHAR(140) NOT NULL,
    sign_status VARCHAR(50) NOT NULL DEFAULT 'pending',
    signature_sha256 CHAR(64) DEFAULT NULL,
    signed_by_name VARCHAR(140) DEFAULT NULL,
    signed_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS class_runbook_checklists (
    id INT AUTO_INCREMENT PRIMARY KEY,
    run_code VARCHAR(45) NOT NULL UNIQUE,
    course_title VARCHAR(190) NOT NULL,
    skyroom_link_ready TINYINT(1) NOT NULL DEFAULT 1,
    slides_uploaded TINYINT(1) NOT NULL DEFAULT 1,
    sms_24h_sent TINYINT(1) NOT NULL DEFAULT 0,
    hall_catering_ok TINYINT(1) NOT NULL DEFAULT 1,
    bulk_enrolled_count INT NOT NULL DEFAULT 18,
    readiness_pct INT NOT NULL DEFAULT 75,
    updated_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS tuition_refund_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    refund_code VARCHAR(45) NOT NULL UNIQUE,
    applicant_name VARCHAR(150) NOT NULL,
    course_title VARCHAR(190) NOT NULL,
    paid_tuition_rial BIGINT NOT NULL DEFAULT 52000000,
    hours_before_start INT NOT NULL DEFAULT 48,
    deduction_pct INT NOT NULL DEFAULT 15,
    net_refund_rial BIGINT NOT NULL DEFAULT 44200000,
    reversal_voucher_no VARCHAR(45) NOT NULL,
    processed_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS b2b_account_touchpoints (
    id INT AUTO_INCREMENT PRIMARY KEY,
    proposal_code VARCHAR(45) NOT NULL UNIQUE,
    company_name VARCHAR(160) NOT NULL,
    channel_source VARCHAR(90) NOT NULL,
    contact_summary VARCHAR(230) NOT NULL,
    proposed_package_rial BIGINT NOT NULL DEFAULT 680000000,
    win_probability_pct INT NOT NULL DEFAULT 78,
    next_followup_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۵',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS instructor_availability_endorsements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    record_code VARCHAR(45) NOT NULL UNIQUE,
    instructor_name VARCHAR(150) NOT NULL,
    free_weekly_slots VARCHAR(190) NOT NULL,
    endorsed_learner_name VARCHAR(150) NOT NULL,
    endorsed_skill_badge VARCHAR(180) NOT NULL,
    recommendation_note VARCHAR(240) NOT NULL,
    created_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS org_employee_training_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    req_code VARCHAR(45) NOT NULL UNIQUE,
    org_name VARCHAR(160) NOT NULL,
    employee_fullname VARCHAR(150) NOT NULL,
    department_unit VARCHAR(120) NOT NULL,
    requested_course VARCHAR(190) NOT NULL,
    hr_approval_status VARCHAR(60) NOT NULL DEFAULT 'در انتظار تأیید نماینده سازمان',
    contract_quota_deducted TINYINT(1) NOT NULL DEFAULT 0,
    requested_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS learner_personal_idp_steps (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL DEFAULT 7,
    learner_name VARCHAR(150) NOT NULL,
    step_order INT NOT NULL DEFAULT 1,
    milestone_title VARCHAR(200) NOT NULL,
    source_diagnostic VARCHAR(150) NOT NULL,
    xp_bonus INT NOT NULL DEFAULT 50,
    is_done TINYINT(1) NOT NULL DEFAULT 0,
    target_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۱۵',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==================== نسخه v18.0: ماژول جامع کاریابی، استودیو هوشمند انتشار آگهی، رزومه‌ساز تاییدشده و پایپ‌لاین ATS ====================
CREATE TABLE IF NOT EXISTS career_job_ads (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ad_code VARCHAR(45) NOT NULL UNIQUE,
    company_name VARCHAR(165) NOT NULL,
    is_verified_member TINYINT(1) NOT NULL DEFAULT 1,
    job_title VARCHAR(190) NOT NULL,
    category_slug VARCHAR(70) NOT NULL DEFAULT 'export_trade',
    cooperation_type VARCHAR(70) NOT NULL DEFAULT 'تمام‌وقت',
    seniority_level VARCHAR(70) NOT NULL DEFAULT 'کارشناس ارشد',
    city_location VARCHAR(110) NOT NULL DEFAULT 'شهرک صنعتی بزرگ استان',
    salary_min_million INT NOT NULL DEFAULT 42,
    salary_max_million INT NOT NULL DEFAULT 65,
    perks_badges VARCHAR(240) NOT NULL DEFAULT 'بیمه تکمیلی، پورسانت ارزی صادرات، ناهار و سرویس',
    required_skills_tags VARCHAR(240) NOT NULL,
    required_chamber_cert VARCHAR(190) NOT NULL,
    job_description_ai TEXT NOT NULL,
    is_urgent TINYINT(1) NOT NULL DEFAULT 0,
    views_count INT NOT NULL DEFAULT 140,
    applicants_count INT NOT NULL DEFAULT 6,
    ad_status VARCHAR(40) NOT NULL DEFAULT 'active',
    posted_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS career_candidate_profiles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,
    full_name VARCHAR(150) NOT NULL,
    headline_title VARCHAR(190) NOT NULL,
    experience_years INT NOT NULL DEFAULT 5,
    expected_salary_million INT NOT NULL DEFAULT 55,
    city_preference VARCHAR(110) NOT NULL DEFAULT 'مرکز استان / هیبرید',
    availability_status VARCHAR(90) NOT NULL DEFAULT 'آماده شروع فوری',
    foreign_languages VARCHAR(190) NOT NULL DEFAULT 'انگلیسی تجاری C1 (BEC) | عربی بازرگانی B2',
    core_skills_csv VARCHAR(250) NOT NULL,
    synced_certs_summary VARCHAR(240) NOT NULL,
    work_style_nonclinical VARCHAR(180) NOT NULL DEFAULT 'تیپ تحلیلی-نتیجه‌گرا (ENTJ — ارزیابی غیربالینی شغلی)',
    gamification_xp_badge VARCHAR(120) NOT NULL DEFAULT 'سطح ۸ — سفیر طلایی صادرات (۴,۸۹۰ XP)',
    updated_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS career_ats_applications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tracking_code VARCHAR(45) NOT NULL UNIQUE,
    job_ad_id INT NOT NULL,
    job_title_snapshot VARCHAR(190) NOT NULL,
    company_snapshot VARCHAR(165) NOT NULL,
    candidate_name VARCHAR(150) NOT NULL,
    ats_stage VARCHAR(45) NOT NULL DEFAULT 'ai_screened',
    ai_match_score_pct INT NOT NULL DEFAULT 93,
    skill_gap_prescription VARCHAR(240) NOT NULL,
    candidate_note VARCHAR(240) DEFAULT 'دارای گواهی رسمی QR اتاق و نمونه پرونده عملی صادراتی',
    applied_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS career_interview_schedules (
    id INT AUTO_INCREMENT PRIMARY KEY,
    interview_code VARCHAR(45) NOT NULL UNIQUE,
    candidate_name VARCHAR(150) NOT NULL,
    company_name VARCHAR(165) NOT NULL,
    job_title VARCHAR(190) NOT NULL,
    interview_mode VARCHAR(80) NOT NULL DEFAULT 'آنلاین (اتاق اختصاصی اسکای‌روم)',
    scheduled_shamsi VARCHAR(70) NOT NULL,
    interviewer_panel VARCHAR(160) NOT NULL,
    ai_tailored_questions TEXT NOT NULL,
    technical_score INT DEFAULT 91,
    interview_outcome VARCHAR(90) DEFAULT 'تأیید فنی — ارسال به مرحله پیشنهاد حقوق',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS career_job_offers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    offer_serial VARCHAR(45) NOT NULL UNIQUE,
    candidate_name VARCHAR(150) NOT NULL,
    company_name VARCHAR(165) NOT NULL,
    position_title VARCHAR(190) NOT NULL,
    base_monthly_million INT NOT NULL DEFAULT 58,
    export_commission_note VARCHAR(160) NOT NULL DEFAULT '۱.۵٪ پورسانت دلاری وصول ارزی صادرات + بیمه تکمیلی طلایی',
    start_date_shamsi VARCHAR(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۱۵',
    offer_status VARCHAR(70) NOT NULL DEFAULT 'ارسال‌شده به کارجو — منتظر امضا',
    created_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS career_salary_benchmarks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    role_family VARCHAR(165) NOT NULL,
    min_million INT NOT NULL,
    median_million INT NOT NULL,
    max_top_decile_million INT NOT NULL,
    market_demand_index INT NOT NULL DEFAULT 92,
    top_value_cert VARCHAR(190) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS career_job_fair_booths (
    id INT AUTO_INCREMENT PRIMARY KEY,
    booth_code VARCHAR(40) NOT NULL UNIQUE,
    company_name VARCHAR(165) NOT NULL,
    industry_sector VARCHAR(120) NOT NULL,
    open_positions_count INT NOT NULL DEFAULT 4,
    speed_interview_slots_left INT NOT NULL DEFAULT 7,
    featured_roles VARCHAR(220) NOT NULL,
    fair_date_shamsi VARCHAR(60) DEFAULT 'چهارشنبه ۱۴۰۵/۰۸/۱۴ — تالار بزرگ مؤسسه آموزشی آدان',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================================
-- v19.0 ENTERPRISE SETTINGS, LIVE THEME & FONT STUDIO, GRANULAR IAM/RBAC & ACADEMIC ERP CORE (#143 - #152)
-- =====================================================================

CREATE TABLE IF NOT EXISTS erp_ui_theme_profiles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    theme_slug VARCHAR(60) NOT NULL UNIQUE,
    theme_title VARCHAR(150) NOT NULL,
    color_mode VARCHAR(15) NOT NULL DEFAULT 'light',
    primary_hex VARCHAR(16) NOT NULL DEFAULT '#0f766e',
    gold_accent_hex VARCHAR(16) NOT NULL DEFAULT '#c99227',
    sidebar_bg_hex VARCHAR(16) NOT NULL DEFAULT '#0b1f3a',
    font_family_key VARCHAR(40) NOT NULL DEFAULT 'Vazirmatn',
    base_font_px INT NOT NULL DEFAULT 14,
    line_height_val VARCHAR(10) NOT NULL DEFAULT '1.75',
    border_radius_px INT NOT NULL DEFAULT 16,
    ui_density VARCHAR(20) NOT NULL DEFAULT 'comfortable',
    brand_org_title VARCHAR(190) NOT NULL DEFAULT 'مؤسسه آموزشی آدان',
    brand_unit_subtitle VARCHAR(190) NOT NULL DEFAULT 'آموزش تخصصی حسابداری و امور مالی',
    brand_monogram VARCHAR(16) NOT NULL DEFAULT 'ناب',
    is_active TINYINT(1) NOT NULL DEFAULT 0,
    updated_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS erp_system_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_group VARCHAR(50) NOT NULL,
    setting_key VARCHAR(90) NOT NULL UNIQUE,
    setting_label VARCHAR(180) NOT NULL,
    setting_value TEXT NOT NULL,
    input_type VARCHAR(30) NOT NULL DEFAULT 'text',
    updated_by VARCHAR(120) DEFAULT 'مدیرکل آموزش',
    updated_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS iam_custom_roles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    role_slug VARCHAR(60) NOT NULL UNIQUE,
    role_title_fa VARCHAR(160) NOT NULL,
    data_scope VARCHAR(40) NOT NULL DEFAULT 'global_province',
    badge_color VARCHAR(20) NOT NULL DEFAULT 'info',
    is_system_builtin TINYINT(1) NOT NULL DEFAULT 1,
    description_note VARCHAR(240) NOT NULL DEFAULT '',
    created_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS iam_role_permissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    role_slug VARCHAR(60) NOT NULL,
    module_domain VARCHAR(80) NOT NULL,
    module_label_fa VARCHAR(160) NOT NULL,
    can_view TINYINT(1) NOT NULL DEFAULT 1,
    can_create TINYINT(1) NOT NULL DEFAULT 0,
    can_edit TINYINT(1) NOT NULL DEFAULT 0,
    can_delete TINYINT(1) NOT NULL DEFAULT 0,
    can_approve TINYINT(1) NOT NULL DEFAULT 0,
    can_export TINYINT(1) NOT NULL DEFAULT 0,
    updated_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    UNIQUE KEY uq_role_domain (role_slug, module_domain)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS iam_user_overrides (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    user_fullname VARCHAR(150) NOT NULL,
    route_or_perm VARCHAR(90) NOT NULL,
    effect_type VARCHAR(15) NOT NULL DEFAULT 'allow',
    reason_note VARCHAR(220) NOT NULL,
    expires_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۱۲/۲۹',
    granted_by VARCHAR(120) DEFAULT 'مدیرکل آموزش',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS academic_terms_calendar (
    id INT AUTO_INCREMENT PRIMARY KEY,
    term_code VARCHAR(40) NOT NULL UNIQUE,
    term_title VARCHAR(160) NOT NULL,
    registration_window VARCHAR(90) NOT NULL,
    add_drop_deadline VARCHAR(90) NOT NULL,
    exams_window VARCHAR(90) NOT NULL,
    target_capacity INT NOT NULL DEFAULT 650,
    term_status VARCHAR(30) NOT NULL DEFAULT 'در حال ثبت‌نام و اجرا',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS academic_attendance_gradebook (
    id INT AUTO_INCREMENT PRIMARY KEY,
    record_serial VARCHAR(45) NOT NULL UNIQUE,
    term_code VARCHAR(40) NOT NULL DEFAULT 'TERM-1405-FALL',
    learner_name VARCHAR(150) NOT NULL,
    national_id VARCHAR(20) NOT NULL DEFAULT '1079025413',
    course_title VARCHAR(185) NOT NULL,
    sessions_total INT NOT NULL DEFAULT 10,
    sessions_attended INT NOT NULL DEFAULT 9,
    attendance_pct INT NOT NULL DEFAULT 90,
    quiz_activity_score INT NOT NULL DEFAULT 88,
    practical_project_score INT NOT NULL DEFAULT 92,
    final_exam_score INT NOT NULL DEFAULT 94,
    weighted_total_score INT NOT NULL DEFAULT 92,
    academic_standing VARCHAR(60) NOT NULL DEFAULT 'قبول ممتاز — مجاز به صدور گواهی QR',
    appeal_status VARCHAR(80) NOT NULL DEFAULT 'بدون اعتراض',
    updated_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS academic_prereq_waitlist (
    id INT AUTO_INCREMENT PRIMARY KEY,
    rule_or_queue_code VARCHAR(45) NOT NULL UNIQUE,
    target_course_title VARCHAR(185) NOT NULL,
    prerequisite_course_title VARCHAR(185) NOT NULL,
    rule_type VARCHAR(40) NOT NULL DEFAULT 'پیش‌نیاز الزامی',
    waitlist_applicant_name VARCHAR(150) NOT NULL,
    applicant_priority_score INT NOT NULL DEFAULT 90,
    queue_status VARCHAR(50) NOT NULL DEFAULT 'در صف انتظار ظرفیت',
    created_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS erp_helpdesk_tickets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ticket_no VARCHAR(45) NOT NULL UNIQUE,
    requester_name VARCHAR(150) NOT NULL,
    requester_role VARCHAR(60) NOT NULL DEFAULT 'فراگیر دانش‌پذیر آدان',
    department_unit VARCHAR(90) NOT NULL,
    priority_level VARCHAR(25) NOT NULL DEFAULT 'بالا (فوری)',
    sla_hours INT NOT NULL DEFAULT 4,
    subject_line VARCHAR(200) NOT NULL,
    official_reply TEXT DEFAULT NULL,
    ticket_status VARCHAR(40) NOT NULL DEFAULT 'در انتظار پاسخ کارشناس',
    created_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS erp_admin_requests_templates (
    id INT AUTO_INCREMENT PRIMARY KEY,
    entry_code VARCHAR(45) NOT NULL UNIQUE,
    record_category VARCHAR(30) NOT NULL DEFAULT 'student_request',
    applicant_or_event VARCHAR(175) NOT NULL,
    request_type_or_channel VARCHAR(120) NOT NULL,
    body_or_template TEXT NOT NULL,
    approval_state VARCHAR(60) NOT NULL DEFAULT 'تأیید و صادرشده ✅',
    updated_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================================
-- v20.0 ENTERPRISE MICROLEARNING, SPACED REPETITION (SM-2 / LEITNER) & AI MICRO-CAPSULE STUDIO (#153 - #158)
-- =====================================================================

CREATE TABLE IF NOT EXISTS micro_learning_capsules (
    id INT AUTO_INCREMENT PRIMARY KEY,
    capsule_code VARCHAR(45) NOT NULL UNIQUE,
    title VARCHAR(190) NOT NULL,
    topic_domain VARCHAR(80) NOT NULL,
    duration_seconds INT NOT NULL DEFAULT 180,
    difficulty_tag VARCHAR(40) NOT NULL DEFAULT 'کاربردی مدیران',
    slide_1_hook TEXT NOT NULL,
    slide_2_rule TEXT NOT NULL,
    slide_3_example TEXT NOT NULL,
    quiz_question VARCHAR(240) NOT NULL,
    quiz_opt_a VARCHAR(160) NOT NULL,
    quiz_opt_b VARCHAR(160) NOT NULL,
    quiz_opt_c VARCHAR(160) NOT NULL,
    correct_opt CHAR(1) NOT NULL DEFAULT 'B',
    xp_reward INT NOT NULL DEFAULT 35,
    completions_count INT NOT NULL DEFAULT 42,
    created_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS micro_capsule_progress (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    capsule_id INT NOT NULL,
    selected_opt CHAR(1) NOT NULL,
    is_mastered TINYINT(1) NOT NULL DEFAULT 1,
    xp_earned INT NOT NULL DEFAULT 35,
    completed_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS micro_spaced_flashcards (
    id INT AUTO_INCREMENT PRIMARY KEY,
    card_code VARCHAR(45) NOT NULL UNIQUE,
    deck_category VARCHAR(90) NOT NULL,
    front_prompt TEXT NOT NULL,
    back_answer TEXT NOT NULL,
    leitner_box INT NOT NULL DEFAULT 1,
    ease_factor DECIMAL(4,2) NOT NULL DEFAULT 2.50,
    interval_days INT NOT NULL DEFAULT 1,
    next_review_label VARCHAR(60) NOT NULL DEFAULT 'موعد مرور: امروز 🔥',
    reviews_count INT NOT NULL DEFAULT 0,
    owner_user_id INT NULL DEFAULT NULL,
    source_kind VARCHAR(30) NOT NULL DEFAULT 'catalog',
    source_ref VARCHAR(190) NULL DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY idx_msf_owner (owner_user_id, leitner_box)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS micro_daily_challenges (
    id INT AUTO_INCREMENT PRIMARY KEY,
    challenge_code VARCHAR(45) NOT NULL UNIQUE,
    scenario_title VARCHAR(195) NOT NULL,
    scenario_case TEXT NOT NULL,
    option_1 VARCHAR(170) NOT NULL,
    option_2 VARCHAR(170) NOT NULL,
    option_3 VARCHAR(170) NOT NULL,
    correct_choice INT NOT NULL DEFAULT 2,
    explanation_key TEXT NOT NULL,
    bonus_xp INT NOT NULL DEFAULT 50,
    participants_today INT NOT NULL DEFAULT 68,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS micro_job_aids (
    id INT AUTO_INCREMENT PRIMARY KEY,
    aid_code VARCHAR(45) NOT NULL UNIQUE,
    aid_title VARCHAR(185) NOT NULL,
    target_desk VARCHAR(95) NOT NULL,
    format_type VARCHAR(55) NOT NULL DEFAULT 'چک‌لیست رومیزی ۱ صفحه‌ای',
    key_steps_summary TEXT NOT NULL,
    audio_script_summary TEXT NOT NULL,
    downloads_count INT NOT NULL DEFAULT 115,
    created_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS micro_skill_gap_links (
    id INT AUTO_INCREMENT PRIMARY KEY,
    prescription_code VARCHAR(45) NOT NULL UNIQUE,
    detected_gap_topic VARCHAR(175) NOT NULL,
    source_module VARCHAR(85) NOT NULL DEFAULT 'آزمون استاندارد / پایپ‌لاین ATS',
    prescribed_capsule_code VARCHAR(45) NOT NULL,
    estimated_fix_minutes INT NOT NULL DEFAULT 4,
    impact_note VARCHAR(210) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================================
-- v21.0 CONTEXTUAL PER-PAGE HELP ENGINE (77 UNIQUE GUIDES) & MASTER ERP ENCYCLOPEDIA (#159 - #160)
-- =====================================================================

CREATE TABLE IF NOT EXISTS erp_help_custom_notes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    route_key VARCHAR(90) NOT NULL UNIQUE,
    local_sop_title VARCHAR(185) NOT NULL,
    local_sop_body TEXT NOT NULL,
    contact_extension VARCHAR(80) NOT NULL DEFAULT 'داخلی ۲۱۰ — واحد راهبری سیستم',
    video_guide_url VARCHAR(255) DEFAULT '',
    updated_by VARCHAR(120) DEFAULT 'مدیرکل آموزش',
    updated_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS erp_help_feedback_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    route_key VARCHAR(90) NOT NULL,
    user_fullname VARCHAR(150) NOT NULL,
    is_helpful TINYINT(1) NOT NULL DEFAULT 1,
    suggestion_note VARCHAR(240) NOT NULL DEFAULT 'راهنمای گام‌به‌گام کاملاً شفاف و کاربردی بود',
    created_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================================
-- ENTERPRISE OFFICE AUTOMATION & E-CORRESPONDENCE SUBSYSTEM (#161 - #164)
-- =====================================================================

CREATE TABLE IF NOT EXISTS oa_letters (
    id INT AUTO_INCREMENT PRIMARY KEY,
    indicator_no VARCHAR(50) NOT NULL UNIQUE,
    letter_type VARCHAR(30) NOT NULL DEFAULT 'داخلی',
    priority_level VARCHAR(30) NOT NULL DEFAULT 'عادی',
    confidentiality VARCHAR(30) NOT NULL DEFAULT 'عادی',
    sender_unit VARCHAR(140) NOT NULL,
    recipient_org VARCHAR(160) NOT NULL,
    subject_title VARCHAR(220) NOT NULL,
    letter_body TEXT NOT NULL,
    attachment_note VARCHAR(160) DEFAULT 'ندارد',
    signatory_name VARCHAR(120) NOT NULL DEFAULT 'دکتر کیارش رادمهر — مدیرکل آموزش',
    sign_status VARCHAR(60) NOT NULL DEFAULT 'امضاشده و ثبت در دبیرخانه',
    qr_verify_code VARCHAR(60) NOT NULL,
    created_shamsi VARCHAR(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    sender_user_id INT NULL,
    recipient_user_id INT NULL,
    reply_to_letter_id INT NULL,
    recipient_status VARCHAR(40) NOT NULL DEFAULT 'خوانده‌نشده',
    read_at DATETIME NULL,
    archived_at DATETIME NULL,
    external_recipient VARCHAR(160) NULL,
    INDEX idx_oa_letters_recipient_inbox (recipient_user_id, archived_at, id),
    INDEX idx_oa_letters_sender_outbox (sender_user_id, id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS oa_letter_referrals (
    id INT AUTO_INCREMENT PRIMARY KEY,
    letter_id INT NOT NULL,
    from_person VARCHAR(120) NOT NULL,
    to_person_unit VARCHAR(140) NOT NULL,
    action_command VARCHAR(90) NOT NULL DEFAULT 'جهت اقدام مقتضی',
    paraph_margin_note VARCHAR(255) NOT NULL,
    deadline_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۵',
    referral_status VARCHAR(60) NOT NULL DEFAULT 'در دست اقدام',
    created_shamsi VARCHAR(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    from_user_id INT NULL,
    to_user_id INT NULL,
    INDEX idx_oa_referrals_assignee (to_user_id, referral_status),
    INDEX idx_oa_referrals_letter (letter_id, id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS oa_admin_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    req_code VARCHAR(45) NOT NULL UNIQUE,
    requester_name VARCHAR(130) NOT NULL,
    unit_name VARCHAR(120) NOT NULL,
    req_category VARCHAR(80) NOT NULL DEFAULT 'مرخصی استحقاقی / ساعتی',
    date_range_or_amount VARCHAR(120) NOT NULL,
    description_note VARCHAR(255) NOT NULL,
    approval_status VARCHAR(60) NOT NULL DEFAULT 'منتظر تأیید مدیریت',
    approver_note VARCHAR(180) DEFAULT '—',
    created_shamsi VARCHAR(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    requester_user_id INT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS oa_meeting_minutes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    minute_code VARCHAR(45) NOT NULL UNIQUE,
    meeting_title VARCHAR(200) NOT NULL,
    chairperson VARCHAR(120) NOT NULL,
    attendees_summary VARCHAR(240) NOT NULL,
    key_resolutions TEXT NOT NULL,
    responsible_owner VARCHAR(120) NOT NULL,
    due_shamsi VARCHAR(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۱۵',
    execution_status VARCHAR(60) NOT NULL DEFAULT 'ابلاغ‌شده — در حال پیگیری',
    created_shamsi VARCHAR(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================================
-- ENTERPRISE BUSINESS INTELLIGENCE, REPORT BUILDER, DASHBOARD STUDIO & OKR (#165 - #170)
-- =====================================================================

CREATE TABLE IF NOT EXISTS bi_dashboards (
    id INT AUTO_INCREMENT PRIMARY KEY,
    slug VARCHAR(70) NOT NULL UNIQUE,
    title VARCHAR(180) NOT NULL,
    subtitle VARCHAR(255) NOT NULL DEFAULT '',
    category VARCHAR(80) NOT NULL DEFAULT 'مدیریت کلان',
    accent_color VARCHAR(20) NOT NULL DEFAULT '#4f46e5',
    layout_density VARCHAR(30) NOT NULL DEFAULT 'balanced',
    created_via VARCHAR(30) NOT NULL DEFAULT 'click',
    is_default TINYINT(1) NOT NULL DEFAULT 0,
    created_by_name VARCHAR(120) NOT NULL DEFAULT 'مدیرکل آموزش',
    updated_shamsi VARCHAR(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bi_dashboard_widgets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    dashboard_id INT NOT NULL DEFAULT 1,
    widget_code VARCHAR(50) NOT NULL UNIQUE,
    title VARCHAR(180) NOT NULL,
    subtitle VARCHAR(220) NOT NULL DEFAULT '',
    dataset_key VARCHAR(60) NOT NULL DEFAULT 'courses_mart',
    dimension_field VARCHAR(60) NOT NULL DEFAULT 'level',
    metric_field VARCHAR(60) NOT NULL DEFAULT 'tuition_rial',
    agg_func VARCHAR(20) NOT NULL DEFAULT 'SUM',
    filter_field VARCHAR(60) NOT NULL DEFAULT '',
    filter_op VARCHAR(20) NOT NULL DEFAULT '=',
    filter_val VARCHAR(120) NOT NULL DEFAULT '',
    chart_type VARCHAR(30) NOT NULL DEFAULT 'bar',
    col_span INT NOT NULL DEFAULT 6,
    sort_order INT NOT NULL DEFAULT 10,
    color_palette VARCHAR(30) NOT NULL DEFAULT 'indigo',
    created_via VARCHAR(30) NOT NULL DEFAULT 'drag_drop',
    updated_shamsi VARCHAR(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bi_custom_reports (
    id INT AUTO_INCREMENT PRIMARY KEY,
    report_code VARCHAR(50) NOT NULL UNIQUE,
    title VARCHAR(200) NOT NULL,
    category VARCHAR(80) NOT NULL DEFAULT 'گزارش مدیریتی',
    dataset_key VARCHAR(60) NOT NULL DEFAULT 'courses_mart',
    dimension_field VARCHAR(60) NOT NULL DEFAULT 'level',
    metric_field VARCHAR(60) NOT NULL DEFAULT 'tuition_rial',
    secondary_metric VARCHAR(60) NOT NULL DEFAULT 'duration_hours',
    agg_func VARCHAR(20) NOT NULL DEFAULT 'SUM',
    filter_field VARCHAR(60) NOT NULL DEFAULT '',
    filter_op VARCHAR(20) NOT NULL DEFAULT '=',
    filter_val VARCHAR(120) NOT NULL DEFAULT '',
    sort_dir VARCHAR(10) NOT NULL DEFAULT 'DESC',
    row_limit INT NOT NULL DEFAULT 25,
    chart_type VARCHAR(30) NOT NULL DEFAULT 'bar',
    natural_query_text VARCHAR(255) NOT NULL DEFAULT '',
    ai_narrative TEXT,
    created_via VARCHAR(30) NOT NULL DEFAULT 'click',
    created_by_name VARCHAR(120) NOT NULL DEFAULT 'مدیرکل آموزش',
    created_shamsi VARCHAR(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bi_goals_okrs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    goal_code VARCHAR(50) NOT NULL UNIQUE,
    title VARCHAR(200) NOT NULL,
    department_owner VARCHAR(120) NOT NULL DEFAULT 'معاونت آموزش',
    horizon_label VARCHAR(70) NOT NULL DEFAULT 'نیمسال دوم ۱۴۰۵',
    live_metric_source VARCHAR(60) NOT NULL DEFAULT 'invoices_total_rial',
    baseline_value DOUBLE NOT NULL DEFAULT 0,
    manual_boost_value DOUBLE NOT NULL DEFAULT 0,
    target_value DOUBLE NOT NULL DEFAULT 100,
    unit_label VARCHAR(40) NOT NULL DEFAULT 'ریال',
    weight_pct INT NOT NULL DEFAULT 20,
    alert_threshold_pct INT NOT NULL DEFAULT 70,
    key_results_note VARCHAR(255) NOT NULL DEFAULT '',
    created_via VARCHAR(30) NOT NULL DEFAULT 'click',
    updated_shamsi VARCHAR(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bi_whatif_scenarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    scenario_code VARCHAR(50) NOT NULL UNIQUE,
    title VARCHAR(190) NOT NULL,
    tuition_delta_pct INT NOT NULL DEFAULT 10,
    enrollment_growth_pct INT NOT NULL DEFAULT 25,
    b2b_conversion_pct INT NOT NULL DEFAULT 20,
    cost_change_pct INT NOT NULL DEFAULT -5,
    projected_revenue_rial BIGINT NOT NULL DEFAULT 0,
    projected_surplus_rial BIGINT NOT NULL DEFAULT 0,
    ai_recommendation TEXT,
    created_by_name VARCHAR(120) NOT NULL DEFAULT 'مدیرکل آموزش',
    created_shamsi VARCHAR(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bi_report_schedules (
    id INT AUTO_INCREMENT PRIMARY KEY,
    schedule_code VARCHAR(50) NOT NULL UNIQUE,
    report_title VARCHAR(190) NOT NULL,
    dataset_key VARCHAR(60) NOT NULL DEFAULT 'invoices_mart',
    frequency_label VARCHAR(70) NOT NULL DEFAULT 'هفتگی — شنبه‌ها ساعت ۰۸:۰۰',
    cron_expr VARCHAR(50) NOT NULL DEFAULT '0 8 * * 6',
    delivery_channel VARCHAR(80) NOT NULL DEFAULT 'کارتابل مدیریتی + ایمیل + پیام‌رسان',
    recipients_list VARCHAR(220) NOT NULL DEFAULT 'هیئت رئیسه، مدیرکل آموزش، مدیر مالی',
    export_format VARCHAR(30) NOT NULL DEFAULT 'CSV + PDF A4',
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    last_run_shamsi VARCHAR(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================================
-- v26.0 NEXT-GEN WOW TMS, INTERACTIVE LMS, OMNI-CHANNEL SOCIAL CAMPAIGNS & AI MARKET RESEARCH (#171 - #176)
-- =====================================================================

CREATE TABLE IF NOT EXISTS tms_learning_paths (
    id INT AUTO_INCREMENT PRIMARY KEY,
    path_code VARCHAR(50) NOT NULL UNIQUE,
    title VARCHAR(190) NOT NULL,
    target_persona VARCHAR(150) NOT NULL DEFAULT 'مدیران بازرگانی و صادرات',
    level_badge VARCHAR(60) NOT NULL DEFAULT 'دیپلم جامع حرفه‌ای',
    courses_json TEXT NOT NULL,
    total_hours INT NOT NULL DEFAULT 48,
    bundle_tuition_rial BIGINT NOT NULL DEFAULT 95000000,
    discount_pct INT NOT NULL DEFAULT 22,
    enrolled_learners INT NOT NULL DEFAULT 18,
    ai_roadmap_summary TEXT,
    status VARCHAR(30) NOT NULL DEFAULT 'active',
    created_shamsi VARCHAR(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS tms_pricing_scenarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    scenario_code VARCHAR(50) NOT NULL UNIQUE,
    course_title VARCHAR(190) NOT NULL,
    base_tuition_rial BIGINT NOT NULL DEFAULT 48000000,
    member_discount_pct INT NOT NULL DEFAULT 25,
    early_bird_pct INT NOT NULL DEFAULT 10,
    instructor_total_cost_rial BIGINT NOT NULL DEFAULT 180000000,
    venue_ops_cost_rial BIGINT NOT NULL DEFAULT 65000000,
    predicted_enrollments INT NOT NULL DEFAULT 26,
    breakeven_seats INT NOT NULL DEFAULT 7,
    projected_net_profit_rial BIGINT NOT NULL DEFAULT 690000000,
    created_shamsi VARCHAR(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS lms_interactive_quizzes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    lesson_id INT NOT NULL DEFAULT 1,
    appear_at_sec INT NOT NULL DEFAULT 180,
    timestamp_label VARCHAR(20) NOT NULL DEFAULT '03:00',
    question_text VARCHAR(255) NOT NULL,
    opt_a VARCHAR(190) NOT NULL,
    opt_b VARCHAR(190) NOT NULL,
    opt_c VARCHAR(190) NOT NULL,
    opt_d VARCHAR(190) NOT NULL,
    correct_opt CHAR(1) NOT NULL DEFAULT 'B',
    ai_explanation TEXT,
    xp_reward INT NOT NULL DEFAULT 50,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS lms_ai_study_cards (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_id INT NOT NULL DEFAULT 1,
    lesson_id INT NOT NULL DEFAULT 1,
    card_type VARCHAR(50) NOT NULL DEFAULT 'summary',
    title VARCHAR(190) NOT NULL,
    content_body TEXT NOT NULL,
    mastery_tag VARCHAR(80) NOT NULL DEFAULT 'تسلط مفهومی و کاربردی',
    created_by_name VARCHAR(120) NOT NULL DEFAULT 'دستیار هوشمند LMS',
    created_shamsi VARCHAR(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS social_media_posts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    post_code VARCHAR(50) NOT NULL UNIQUE,
    campaign_id INT DEFAULT 1,
    platform VARCHAR(40) NOT NULL DEFAULT 'instagram',
    content_format VARCHAR(60) NOT NULL DEFAULT 'پست اسلایدی (Carousel)',
    target_course_title VARCHAR(190) NOT NULL,
    hook_headline VARCHAR(220) NOT NULL,
    caption_body TEXT NOT NULL,
    hashtags VARCHAR(255) NOT NULL DEFAULT '#آموزش_حسابداری_آدان #آموزش_صادرات #تجارت_بین_الملل',
    utm_url VARCHAR(255) NOT NULL DEFAULT 'https://chamber.ir/tms?utm_source=instagram&utm_medium=social',
    promo_code VARCHAR(40) NOT NULL DEFAULT 'ADN-INSTA20',
    scheduled_shamsi VARCHAR(60) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۶ — ساعت ۱۹:۳۰',
    impressions_count INT NOT NULL DEFAULT 0,
    engagements_count INT NOT NULL DEFAULT 0,
    clicks_count INT NOT NULL DEFAULT 0,
    leads_generated INT NOT NULL DEFAULT 0,
    enrollments_converted INT NOT NULL DEFAULT 0,
    spend_rial BIGINT NOT NULL DEFAULT 0,
    revenue_rial BIGINT NOT NULL DEFAULT 0,
    publish_status VARCHAR(30) NOT NULL DEFAULT 'scheduled_local',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS market_surveys_insights (
    id INT AUTO_INCREMENT PRIMARY KEY,
    insight_code VARCHAR(50) NOT NULL UNIQUE,
    research_title VARCHAR(190) NOT NULL,
    industry_segment VARCHAR(120) NOT NULL DEFAULT 'صنایع غذایی، فولاد و بازرگانی خارجی',
    social_source VARCHAR(90) NOT NULL DEFAULT 'لینکدین + تلگرام + نظرسنجی بنگاه‌ها',
    sample_size_orgs INT NOT NULL DEFAULT 84,
    demand_urgency_pct INT NOT NULL DEFAULT 91,
    positive_sentiment_pct INT NOT NULL DEFAULT 84,
    willingness_to_pay_rial BIGINT NOT NULL DEFAULT 52000000,
    tam_provincial_rial BIGINT NOT NULL DEFAULT 48000000000,
    sam_reachable_rial BIGINT NOT NULL DEFAULT 14500000000,
    som_target_rial BIGINT NOT NULL DEFAULT 4200000000,
    key_pain_point TEXT NOT NULL,
    ai_gtm_strategy TEXT NOT NULL,
    launched_to_tms TINYINT(1) NOT NULL DEFAULT 0,
    created_shamsi VARCHAR(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

-- =====================================================================
-- ★ v26.8 — استودیوی گزارش‌ساز صوتی هوشمند (بایگانی گزارش‌های سخنگو)
-- =====================================================================
CREATE TABLE IF NOT EXISTS voice_report_archive (
    id INT AUTO_INCREMENT PRIMARY KEY,
    report_code VARCHAR(45) NOT NULL UNIQUE,
    report_kind VARCHAR(60) NOT NULL,
    audience_role VARCHAR(30) NOT NULL DEFAULT 'super_admin',
    user_id INT NOT NULL,
    user_name VARCHAR(150) NOT NULL DEFAULT 'سامانه',
    report_title VARCHAR(240) NOT NULL,
    narrative_text MEDIUMTEXT NOT NULL,
    speech_text MEDIUMTEXT NOT NULL,
    metrics_json TEXT NULL,
    speech_chars INT NOT NULL DEFAULT 0,
    est_duration_sec INT NOT NULL DEFAULT 60,
    delivery_mode VARCHAR(30) NOT NULL DEFAULT 'browser_tts',
    visibility_scope VARCHAR(30) NOT NULL DEFAULT 'own_role',
    created_shamsi VARCHAR(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY idx_vra_role (audience_role, id),
    KEY idx_vra_user (user_id, id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================================
-- ★ v26.8 — تله‌متری قابلیت‌های هوشمند فضای یادگیری فراگیر (نرخ پذیرش برای مدیران)
-- =====================================================================
CREATE TABLE IF NOT EXISTS learner_ai_telemetry (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    feature_key VARCHAR(60) NOT NULL,
    ref_label VARCHAR(240) NOT NULL DEFAULT '',
    score_value INT NOT NULL DEFAULT 0,
    detail_json TEXT NULL,
    created_shamsi VARCHAR(40) NOT NULL DEFAULT '۱۴۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY idx_lat_user (user_id, id),
    KEY idx_lat_feature (feature_key, id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO voice_report_archive
    (report_code, report_kind, audience_role, user_id, user_name, report_title, narrative_text, speech_text, metrics_json, speech_chars, est_duration_sec, delivery_mode, visibility_scope, created_shamsi)
VALUES
    ('VRA-SEED-01', 'daily_digest', 'super_admin', 1, 'دبیرخانه هوشمند',
     'گزارش نمونه بایگانی‌شده استودیوی گزارش صوتی',
     'این یک گزارش نمونه است تا ساختار بایگانی استودیوی گزارش صوتی در نصب تازه خالی نباشد؛ با نخستین تولید گزارش، گزارش‌های واقعی جای آن را می‌گیرند.',
     'گزارش نمونه استودیوی گزارش صوتی مؤسسه آموزشی آدان. سامانه آماده تولید گزارش‌های زنده است.',
     '{"نمونه":"فعال"}', 92, 22, 'browser_tts', 'own_role', '۱۴۰۵/۰۸/۰۱');


-- ═══════════════ داده‌های نمونه (seed) ═══════════════

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

INSERT IGNORE INTO system_settings (setting_key, setting_value, category) VALUES
("chamber_name", "مؤسسه آموزشی آدان", "general"),
("unit_name", "آموزش تخصصی حسابداری و امور مالی", "general"),
("fiscal_year", "۱۴۰۵", "finance"),
("vat_percent", "10", "finance"),
("ai_base_url", "https://api.openai.com/v1", "ai"),
("ai_api_key", "", "ai"),
("ai_default_model", "gpt-4o-mini", "ai"),
("ollama_base_url", "http://127.0.0.1:11434/v1", "ai"),
("active_ai_provider", "ai", "ai"),
("enrollment_api_token", "", "integration"),
("telegram_bot_username", "@ChamberEduSmartBot", "integration"),
("search_api_key", "", "integration");

INSERT IGNORE INTO organizations (id, name, chamber_member_code, national_id, industry, membership_tier, city, annual_quota_hours, used_quota_hours, contact_phone) VALUES
(1, "گروه صنعتی و صادراتی فولاد زاگرس", "CH-8801", "10102938471", "فلزات اساسی و صادرات صنعتی", "gold", "مرکز استان", 320, 148, "021-88901122"),
(2, "شرکت کشت و صنعت و بازرگانی زعفران تابان", "CH-8842", "10861192034", "کشاورزی و صادرات مواد غذایی", "gold", "شهرک صنعتی اول", 240, 96, "051-37654321"),
(3, "هلدینگ لجستیک و حمل‌ونقل بین‌المللی دریاپیما", "CH-8910", "14005928311", "حمل‌ونقل ترکیبی و گمرک", "silver", "منطقه ویژه اقتصادی", 180, 64, "021-44556677"),
(4, "شرکت دانش‌بنیان پلیمر و پتروشیمی سپهر", "CH-9025", "14008821905", "پلیمر و صنایع شیمیایی", "gold", "شهرک علمی و تحقیقاتی", 300, 112, "031-33991100");

INSERT IGNORE INTO users (id, org_id, username, email, mobile, national_code, password_hash, full_name, role, job_title, avatar_initials, public_passport_slug, passport_is_public, marketing_opt_in, daily_ai_token_limit) VALUES
(1, NULL, "admin", "admin@chamber-edu.ir", "09121001001", "0071234567", "$2y$12$gCJgIqk5SGohiQq0ujT4g.eAa1t7RT1wOhww1P2aMeWXgB3S.sMNy", "دکتر کیارش رادمهر", "super_admin", "مدیر واحد آموزش مؤسسه آموزشی آدان", "کر", "kiarash-radmehr", 1, 1, 100000),
(2, NULL, "expert", "expert@chamber-edu.ir", "09121001002", "0082345678", "$2y$12$gCJgIqk5SGohiQq0ujT4g.eAa1t7RT1wOhww1P2aMeWXgB3S.sMNy", "مهندس سارا فرهمند", "training_expert", "کارشناس مسئول برنامه‌ریزی و اجرای آموزش", "سف", "sara-farahmand", 1, 1, 50000),
(3, NULL, "finance", "finance@chamber-edu.ir", "09121001003", "0063456789", "$2y$12$gCJgIqk5SGohiQq0ujT4g.eAa1t7RT1wOhww1P2aMeWXgB3S.sMNy", "حسین کاظمی‌نژاد", "finance_manager", "رئیس حسابداری و مالی آموزش", "حک", "hossein-kazemi", 0, 1, 25000),
(4, NULL, "crm", "crm@chamber-edu.ir", "09121001004", "0054567890", "$2y$12$gCJgIqk5SGohiQq0ujT4g.eAa1t7RT1wOhww1P2aMeWXgB3S.sMNy", "نگین محتشم", "crm_manager", "مسئول توسعه بازار و ارتباط با اعضا", "نم", "negin-mohtasham", 1, 1, 40000),
(5, NULL, "instructor", "dr.nikzad@chamber-edu.ir", "09121001005", "0045678901", "$2y$12$gCJgIqk5SGohiQq0ujT4g.eAa1t7RT1wOhww1P2aMeWXgB3S.sMNy", "دکتر امیرحسین نیکزاد", "instructor", "استاد تجارت بین‌الملل و مشاور ارشد صادرات", "ان", "amir-nikzad", 1, 1, 50000),
(6, 1, "orgrep", "hr@zagros-steel.ir", "09121001006", "1286789012", "$2y$12$gCJgIqk5SGohiQq0ujT4g.eAa1t7RT1wOhww1P2aMeWXgB3S.sMNy", "پریسا بهرامی", "org_rep", "مدیر آموزش گروه صنعتی فولاد زاگرس", "پب", "parisa-bahrami", 1, 1, 20000),
(7, 1, "learner", "export@zagros-steel.ir", "09121001007", "1297890123", "$2y$12$gCJgIqk5SGohiQq0ujT4g.eAa1t7RT1wOhww1P2aMeWXgB3S.sMNy", "مهرداد شریفی", "learner", "کارشناس ارشد بازرگانی خارجی", "مش", "mehrdad-sharifi", 1, 1, 15000),
(8, 2, "learner2", "trade@taban-saffron.ir", "09121001008", "0938901234", "$2y$12$gCJgIqk5SGohiQq0ujT4g.eAa1t7RT1wOhww1P2aMeWXgB3S.sMNy", "الهام رضوانی", "learner", "مسئول صادرات اتحادیه اروپا", "ار", "elham-rezvani", 1, 0, 15000);

INSERT IGNORE INTO notifications (user_id, target_role, title, body, type, link) VALUES
(NULL, "super_admin", "۳ پیش‌نویس محتوای هوش مصنوعی در انتظار تأیید انسانی", "خروجی‌های استودیوی AI پیش از انتشار در LMS نیازمند بررسی کارشناسی و تأیید انسانی هستند.", "warning", "ai-studio"),
(NULL, "super_admin", "قرارداد آموزشی فولاد زاگرس به ۷۴٪ ظرفیت رسید", "پیشنهاد الحاقیه تمدید سقف نفر-ساعت در کارتابل قراردادهای سازمانی ثبت شد.", "info", "contracts"),
(7, "learner", "صدور گواهی‌نامه معتبر با کد QR", "گواهی دوره جامع اینکوترمز ۲۰۲۰ و اسناد حمل برای شما صادر و در گذرنامه مهارت ثبت شد.", "success", "exams");

INSERT IGNORE INTO course_categories (id, title, slug, icon, color, description) VALUES
(1, "تجارت بین‌الملل و صادرات", "international-trade", "globe", "#0d9488", "اینکوترمز، حمل‌ونقل، گمرک، قراردادهای بین‌المللی و ارز"),
(2, "مدیریت اجرایی و رهبری (MBA)", "leadership-mba", "award", "#1d4ed8", "توسعه مدیران ارشد بنگاه‌های اقتصادی و حکمرانی شرکتی"),
(3, "مالی، مالیاتی و قوانین کسب‌وکار", "finance-tax", "briefcase", "#b45309", "سامانه مؤدیان، ارزش افزوده، استانداردهای حسابداری و تأمین مالی"),
(4, "هوش مصنوعی و تحول دیجیتال تجاری", "ai-digital-trade", "cpu", "#7c3aed", "کاربرد هوش مصنوعی مولد در بازاریابی صادراتی، زنجیره تأمین و تحلیل بازار");

INSERT IGNORE INTO courses (id, category_id, code, title, level, delivery_mode, duration_hours, tuition_rial, member_discount_pct, prerequisite_text, workflow_status, reviewer_note, approved_by, summary, rating) VALUES
(1, 1, "TRD-101", "دوره جامع مدیریت صادرات، اینکوترمز ۲۰۲۰ و اسناد حمل بین‌المللی", "پیشرفته", "ترکیبی", 24, 68000000, 25, "آشنایی مقدماتی با بازرگانی خارجی", "published", "تأیید کمیته علمی تجارت خارجی اتاق", 1, "تسلط کاربردی بر قواعد Incoterms 2020، اعتبارات اسنادی UCP600، بارنامه‌ها و پوشش ریسک حمل.", 4.92),
(2, 1, "TRD-204", "مدیریت ریسک ارزی، پیمان‌سپاری و رفع تعهد ارزی صادرکنندگان", "پیشرفته", "حضوری", 16, 54000000, 20, "فعالیت صادراتی یا مالی", "published", "منطبق با آخرین بخشنامه‌های بانک مرکزی ۱۴۰۵", 1, "بررسی عملی سامانه نیما/مرکز مبادله، تهاتر ارزی، کوتاژهای صادراتی و جرائم مالیاتی مرتبط.", 4.88),
(3, 4, "AID-301", "هوش مصنوعی کاربردی در بازاریابی صادراتی و کشف خریداران خارجی", "میانی", "آنلاین همزمان", 20, 59000000, 20, "ندارد", "published", "طراحی شده با همکاری استودیوی هوشمند AI", 1, "استفاده از مدل‌های زبانی، تحلیل تعرفه‌های HS Code و اتوماسیون مکاتبات تجاری بین‌المللی.", 4.95),
(4, 3, "TAX-110", "کارگاه جامع سامانه مؤدیان، پایانه‌های فروشگاهی و مالیات ارزش افزوده", "میانی", "حضوری", 12, 42000000, 15, "ندارد", "published", "پرمتقاضی‌ترین دوره واحدهای مالی فراگیران آدان", 1, "آموزش گام‌به‌گام ارسال صورتحساب الکترونیکی نوع ۱ و ۲، اصلاح، ابطال و رسیدگی مالیاتی.", 4.79),
(5, 2, "LDR-401", "برنامه عالی توسعه رهبری و تصمیم‌گیری استراتژیک مدیران صنایع", "مدیریتی ویژه", "حضوری", 40, 145000000, 30, "حداقل ۳ سال سابقه مدیریت", "under_review", "نیازمند تکمیل پیوست شبیه‌ساز تصمیم‌گیری فاز دوم", NULL, "ویژه مدیران عامل و اعضای هیئت‌مدیره شرکت‌های طرف قرارداد مؤسسه آموزشی آدان استان.", 4.90),
(6, 1, "TRD-309", "مقررات مکانیسم تعدیل کربن مرزی اتحادیه اروپا (CBAM) برای صادرکنندگان فولاد و سیمان", "پیشرفته", "ترکیبی", 16, 72000000, 25, "صادرکنندگان صنعتی به اروپا", "approved", "تأیید کمیته علمی - آماده زمان‌بندی اجرا", 1, "محاسبه ردپای کربن محصولات صادراتی و الزامات گزارش‌دهی گمرکی اتحادیه اروپا.", 4.85);

INSERT IGNORE INTO classrooms (id, name, capacity, equipment, hourly_fee_rial, maintenance_status, maintenance_note) VALUES
(1, "تالار خلیج فارس (طبقه دوم اتاق)", 45, "ویدئوپروژکتور لیزری 4K، میکروفون کنفرانسی، ضبط خودکار کلاس، فیبر نوری", 9500000, "ready", NULL),
(2, "کارگاه هوشمند دیجیتال و کامپیوتر ابوریحان", 28, "۲۸ سیستم مجهز، نمایشگر لمسی تعاملی ۸۶ اینچ، نرم‌افزارهای شبیه‌ساز تجاری", 11000000, "ready", NULL),
(3, "سالن VIP مذاکرات بین‌الملل نقش‌جهان", 20, "سیستم ترجمه همزمان ۳ زبانه، ویدئوکنفرانس، پذیرایی تشریفات", 15000000, "service_needed", "میکروفون شماره ۴ میز کنفرانس نیازمند تعویض باتری و کالیبراسیون صوتی است");

INSERT IGNORE INTO course_runs (id, course_id, instructor_id, classroom_id, run_code, term_label, start_date, end_date, start_shamsi, schedule_text, capacity, enrolled_count, status, execution_report) VALUES
(1, 1, 5, 1, "RUN-1405-01", "پاییز ۱۴۰۵ - کد الف", "2026-10-25", "2026-11-18", "۱۴۰۵/۰۸/۰۳", "یکشنبه‌ها و سه‌شنبه‌ها ۱۴:۰۰ تا ۱۸:۰۰", 30, 28, "running", "دو جلسه نخست با رضایت ۹۶ درصدی برگزار شد؛ مطالعه موردی اسناد حمل دریایی بندرعباس انجام گرفت."),
(2, 2, 5, 1, "RUN-1405-02", "آبان ۱۴۰۵ - ویژه صادرکنندگان", "2026-11-01", "2026-11-15", "۱۴۰۵/۰۸/۱۰", "دوشنبه‌ها و چهارشنبه‌ها ۱۵:۰۰ تا ۱۹:۰۰", 25, 25, "registration", "ظرفیت اصلی تکمیل شد؛ ثبت‌نام‌های جدید به صورت خودکار وارد فهرست انتظار می‌شوند."),
(3, 3, 5, 2, "RUN-1405-03", "آذر ۱۴۰۵ - آنلاین و کارگاهی", "2026-11-22", "2026-12-10", "۱۴۰۵/۰۹/۰۱", "پنجشنبه‌ها ۰۹:۰۰ تا ۱۳:۰۰", 35, 19, "registration", NULL),
(4, 4, 5, 1, "RUN-1405-04", "مهر ۱۴۰۵ - تکمیل شده", "2026-09-26", "2026-10-12", "۱۴۰۵/۰۷/۰۴", "شنبه‌ها و چهارشنبه‌ها ۱۴:۰۰ تا ۱۸:۰۰", 40, 38, "completed", "میانگین نمره پس‌آزمون ۸۷.۴ از ۱۰۰ ثبت شد و ۳۶ گواهی‌نامه دارای QR صادر گردید.");

INSERT IGNORE INTO course_sessions (id, run_id, session_number, title, session_date, session_shamsi, start_time, end_time, room_or_link, is_held) VALUES
(1, 1, 1, "تحلیل ساختار یازده قاعده Incoterms 2020 و تفکیک ریسک از هزینه", "2026-10-25", "۱۴۰۵/۰۸/۰۳", "14:00", "18:00", "تالار خلیج فارس", 1),
(2, 1, 2, "بررسی عملی قواعد دریایی FOB، CFR و CIF در صادرات صنعتی", "2026-10-27", "۱۴۰۵/۰۸/۰۵", "14:00", "18:00", "تالار خلیج فارس", 1),
(3, 1, 3, "اعتبارات اسنادی UCP600، بارنامه دریایی و بیمه‌نامه باربری", "2026-11-01", "۱۴۰۵/۰۸/۱۰", "14:00", "18:00", "تالار خلیج فارس", 0),
(4, 2, 1, "آخرین ضوابط بازگشت ارز حاصل از صادرات و کوتاژهای گمرکی", "2026-11-02", "۱۴۰۵/۰۸/۱۱", "15:00", "19:00", "تالار خلیج فارس", 0);

INSERT IGNORE INTO enrollments (id, run_id, user_id, org_id, source, status, attendance_pct, progress_pct, final_score, invoice_id) VALUES
(1, 1, 7, 1, "bulk_org", "active", 100, 67, 91.50, 1),
(2, 1, 8, 2, "web", "active", 100, 34, NULL, 2),
(3, 2, 8, 2, "api", "waitlist", 0, 0, NULL, NULL),
(4, 4, 7, 1, "bulk_org", "completed", 100, 100, 94.00, 1);

INSERT IGNORE INTO session_attendance (session_id, user_id, status, note) VALUES
(1, 7, "present", "حضور کامل و مشارکت در کارگاه"),
(1, 8, "present", "حضور به‌موقع"),
(2, 7, "present", "ارائه پرونده واقعی صادراتی"),
(2, 8, "late", "۱۵ دقیقه تأخیر به دلیل پرواز استانی");

INSERT IGNORE INTO competencies (id, code, title, domain, recommended_course_id, weight, description) VALUES
(1, "CMP-EXP-01", "تسلط بر قواعد تحویل کالا و اسناد حمل بین‌المللی (Incoterms)", "تجارت بین‌الملل", 1, 5, "توانایی تنظیم شرایط تحویل در قراردادهای صادراتی و وارداتی بدون ریسک حقوقی"),
(2, "CMP-FX-02", "مدیریت تعهدات ارزی و ابزارهای پوشش نوسان ارز", "مالی و گمرکی", 2, 5, "مدیریت چرخه نقدینگی ارزی، سامانه نیما و تهاتر واردات در قبال صادرات"),
(3, "CMP-AI-03", "تحلیل هوشمند بازارهای صادراتی با هوش مصنوعی", "تحول دیجیتال و AI", 3, 4, "استخراج داده‌های تقاضای جهانی و خودکارسازی مذاکرات تجاری"),
(4, "CMP-CBAM-04", "انطباق زیست‌محیطی و استاندارد کربن اتحادیه اروپا (CBAM)", "تجارت بین‌الملل", 6, 4, "گزارش‌دهی کربن نهفته محصولات صنعتی صادراتی به بازار اروپا"),
(5, "CMP-LDR-05", "رهبری استراتژیک و تصمیم‌گیری مبتنی بر داده در شرایط عدم قطعیت", "مدیریت و رهبری", 5, 5, "مدیریت پرتفوی ریسک بنگاه اقتصادی و هم‌راستاسازی تیم‌های اجرایی");

INSERT IGNORE INTO competency_assessments (user_id, competency_id, target_role_title, current_level, target_level, priority, ai_recommendation) VALUES
(7, 1, "مدیر صادرات منطقه‌ای", 3, 5, "حیاتی", "گذراندن کارگاه عملی UCP600 و شبیه‌ساز CIF در آکادمی تجارت بین‌الملل"),
(7, 2, "مدیر صادرات منطقه‌ای", 2, 5, "حیاتی", "ثبت‌نام فوری در دوره مدیریت ریسک ارزی (TRD-204) به دلیل شکاف ۳ واحدی"),
(7, 4, "مدیر صادرات منطقه‌ای", 1, 4, "مهم", "ضروری برای تداوم صادرات مقاطع فولادی به اتحادیه اروپا در سال ۲۰۲۶"),
(8, 3, "مسئول توسعه بازار اروپا", 2, 5, "حیاتی", "تکمیل دوره هوش مصنوعی در بازاریابی صادراتی (AID-301)");

INSERT IGNORE INTO course_proposals (user_id, org_id, proposed_title, target_audience, estimated_learners, business_problem, votes_count, status, ai_analysis_note) VALUES
(6, 1, "کارگاه عملی لجستیک کریدور شمال-جنوب و صادرات به اتحادیه اوراسیا", "مدیران بازرگانی و لجستیک صنایع استان", 34, "افزایش هزینه حمل دریایی و نیاز به بهره‌برداری از موافقت‌نامه تجارت آزاد ایران و اوراسیا", 19, "ai_analyzed", "تحلیل AI: هم‌پوشانی بالا با نیاز ۶۲٪ صادرکنندگان صنعتی استان؛ پیشنهاد تدوین دوره ۱۶ ساعته حضوری-کارگاهی.");

INSERT IGNORE INTO lms_chapters (id, course_id, sort_order, title) VALUES
(1, 1, 1, "فصل اول: مبانی حقوقی و ساختار قواعد یازده‌گانه Incoterms 2020"),
(2, 1, 2, "فصل دوم: اسناد حمل، بیمه‌نامه باربری و بسته تعاملی SCORM");

INSERT IGNORE INTO lms_lessons (id, chapter_id, course_id, sort_order, title, content_type, estimated_minutes, sequential_lock, media_url, scorm_manifest_path, scorm_version, body_html) VALUES
(1, 1, 1, 1, "درس ۱: تفاوت کلیدی انتقال ریسک (Risk) و انتقال هزینه (Cost)", "video", 30, 0, "https://chamber-cdn.local/videos/incoterms-intro.mp4", NULL, NULL, "<p>در قراردادهای صادراتی مؤسسه آموزشی آدان، رایج‌ترین خطای بازرگانان اشتباه گرفتن نقطه پایان هزینه با نقطه انتقال ریسک در قواعد گروه C مانند <strong>CFR</strong> و <strong>CIF</strong> است. در این قواعد ریسک به محض بارگیری روی عرشه کشتی در بندر مبدأ به خریدار منتقل می‌شود اما فروشنده کرایه حمل تا بندر مقصد را می‌پردازد.</p>"),
(2, 1, 1, 2, "درس ۲: راهنمای جامع انتخاب EXW، FCA، FOB و CIF (جزوه PDF)", "pdf", 25, 1, "storage/docs/incoterms2020_chart.pdf", NULL, NULL, "<p>جدول مقایسه‌ای تعهدات ده‌گانه فروشنده (A1-A10) و خریدار (B1-B10) همراه با چک‌لیست ترخیص صادراتی گمرکات کشور.</p>"),
(3, 2, 1, 3, "درس ۳: شبیه‌ساز تعاملی بررسی مغایرت اسناد حمل (بسته SCORM)", "scorm", 40, 1, NULL, "storage/uploads/scorm/demo_ucp600/imsmanifest.xml", "SCORM 1.2 (Manifest Verified)", "<p>بسته استاندارد SCORM بارگذاری و مانیفست آن استخراج شده است. توجه: ردیابی کامل Runtime استاندارد CMI در محیط عملیاتی منوط به تأیید نهایی پلیر SCORM است.</p>");

INSERT IGNORE INTO lms_progress (user_id, lesson_id, is_completed, spent_minutes, completed_at) VALUES
(7, 1, 1, 32, NOW()),
(7, 2, 1, 27, NOW()),
(8, 1, 1, 29, NOW());

INSERT IGNORE INTO lms_discussions (course_id, lesson_id, user_id, message, instructor_reply) VALUES
(1, 1, 7, "استاد محترم، برای صادرات کانتینری به بندر هامبورگ آیا FOB مناسب‌تر است یا FCA؟", "پاسخ دکتر نیکزاد: برای حمل کانتینری اکیداً طبق توصیه مرجع بین‌المللی ICC (ICC) از FCA به جای FOB استفاده کنید تا ریسک ترمینال کانتینری پیش از بارگیری روی کشتی پوشش داده شود.");

INSERT IGNORE INTO lms_assignments (course_id, user_id, title, submission_text, grade, feedback, status) VALUES
(1, 7, "تدوین پیش‌نویس ماده شرایط تحویل و اسناد حمل برای صادرات ۵۰۰ تن میلگرد", "ترم پیشنهادی: CFR Jebel Ali Port Incoterms 2020 به همراه سیاهه تجاری گواهی‌شده توسط مؤسسه آموزشی آدان و گواهی مبدأ.", 95.00, "عالی و دقیق؛ صرفاً شماره نسخه Incoterms 2020 در متن انگلیسی قرارداد نیز صراحتاً قید شود.", "graded");

INSERT IGNORE INTO ai_contents (id, course_id, creator_id, content_kind, title, source_excerpt, current_version, body_markdown, model_used, review_status, approved_by, approved_at) VALUES
(1, 6, 2, "course_draft", "سرفصل پیشنهادی کارگاه مقررات کربن مرزی اتحادیه اروپا (CBAM)", "مستخرج از بخشنامه اتحادیه اروپا ۲۰۲۶ ویژه صنایع فولاد، آلومینیوم، سیمان و کود شیمیایی", 2, "## ساختار پیشنهادی دوره ۱۶ ساعته CBAM
1. **مبانی حقوقی CBAM و تقویم اجرایی ۲۰۲۶-۲۰۳۰**
2. **روش‌شناسی محاسبه انتشار مستقیم و غیرمستقیم گازهای گلخانه‌ای**
3. **نحوه تکمیل گزارش فصلی برای واردکننده اروپایی**
4. **کارگاه عملی محاسبه هزینه گواهی کربن بر قیمت تمام‌شده صادراتی**", "ai/gpt-4o-mini", "human_approved", 1, NOW()),
(2, 3, 2, "quiz", "بانک سؤالات آزمون هوش مصنوعی در بازاریابی صادراتی (پیش‌نویس AI)", "فصل ۱ تا ۳ جزوه دوره AID-301", 1, "### سؤال ۱ (چهارگزینه‌ای)
کدام شاخص برای اولویت‌بندی بازار هدف صادراتی در تحلیل داده‌محور اهمیت بالاتری دارد؟
- الف) صرفاً فاصله جغرافیایی
- ب) نرخ رشد واردات ۵ ساله کد تعرفه HS شش‌رقمی و نرخ تعرفه ترجیحی *(پاسخ صحیح)*
- ج) جمعیت کل کشور مقصد
- د) تعداد رقبا بدون توجه به تعرفه", "ai/gpt-4o-mini", "ai_draft", NULL, NULL);

INSERT IGNORE INTO ai_content_versions (ai_content_id, version_no, editor_id, change_note, body_snapshot) VALUES
(1, 1, 2, "تولید اولیه توسط استودیوی AI", "پیش‌نویس اولیه دوره CBAM در ۴ سرفصل کلی"),
(1, 2, 1, "بازبینی انسانی توسط مدیر آموزش و افزودن کارگاه محاسبه بهای تمام‌شده", "نسخه بازبینی و تأیید شده انسانی آماده انتشار در کاتالوگ");

INSERT IGNORE INTO instructor_profiles (user_id, degree, specialties, teaching_years, hourly_rate_rial, avg_rating, qualification_status, availability_slots, portfolio_url, bio) VALUES
(5, "دکتری مدیریت بازرگانی بین‌الملل - داور مؤسسه آموزشی آدان", "اینکوترمز ۲۰۲۰، قراردادهای صادراتی، اعتبارات اسنادی، مذاکرات تجاری، CBAM", 14, 15000000, 4.93, "committee_approved", "یکشنبه و سه‌شنبه ۱۴-۲۰ | چهارشنبه ۱۵-۱۹", "https://chamber-edu.ir/instructors/dr-nikzad", "بیش از ۱۴۰ دوره تخصصی در مؤسسات آموزشی سراسر کشور و مشاور صادراتی ۲۵ واحد صنعتی نمونه.");

INSERT IGNORE INTO instructor_payouts (instructor_user_id, run_id, hours_taught, gross_amount_rial, tax_deduction_rial, net_amount_rial, status, payment_ref) VALUES
(5, 4, 12, 180000000, 18000000, 162000000, "paid", "PAY-1405-7781"),
(5, 1, 24, 360000000, 36000000, 324000000, "verified", NULL);

INSERT IGNORE INTO events (id, code, title, event_type, speakers, event_date, event_shamsi, venue, capacity, registered_count, price_rial, estimated_cost_rial, sms_reminder_status, status) VALUES
(1, "EVT-ADN-FREE-01", "کارگاه رایگان ثبت اسناد و چرخه حسابداری", "کارگاه آموزشی", "مدرس حسابداری آدان", "2026-11-20", "۱۴۰۵/۰۸/۲۹", "آموزشگاه حسابداری آدان", 30, 1, 0, 0, "disabled", "open"),
(2, "EVT-ADN-PAID-02", "نشست تخصصی حسابداری و گزارشگری مالی", "نشست تخصصی", "مدرسان و کارشناسان حسابداری", "2026-11-26", "۱۴۰۵/۰۹/۰۵", "آموزشگاه حسابداری آدان", 30, 0, 35000000, 0, "disabled", "open");

INSERT IGNORE INTO event_tickets (event_id, user_id, ticket_code, paid_status, checked_in_at, feedback_score, feedback_comment) VALUES
(1, 7, "TKT-ADN-1405-7001", "free", NOW(), 5, "تمرین ثبت اسناد و چرخه حسابداری کاربردی بود.");

INSERT IGNORE INTO discount_codes (code, discount_pct, max_uses, used_count, is_active) VALUES
("CHAMBER25", 25, 200, 46, 1),
("EXPORT1405", 15, 100, 19, 1);

INSERT IGNORE INTO invoices (id, invoice_number, user_id, org_id, item_description, subtotal_rial, discount_rial, vat_rial, total_rial, payment_mode, status) VALUES
(1, "INV-1405-1001", 6, 1, "ثبت‌نام گروهی کارشناسان فولاد زاگرس - دوره جامع مدیریت صادرات (TRD-101)", 204000000, 51000000, 15300000, 168300000, "corporate_contract", "paid"),
(2, "INV-1405-1002", 8, 2, "ثبت‌نام انفرادی - دوره جامع مدیریت صادرات (TRD-101) به صورت اقساطی", 68000000, 13600000, 5440000, 59840000, "installment", "partial");

INSERT IGNORE INTO invoice_installments (invoice_id, installment_no, due_shamsi, amount_rial, status) VALUES
(2, 1, "۱۴۰۵/۰۷/۲۵", 29920000, "paid"),
(2, 2, "۱۴۰۵/۰۸/۲۵", 29920000, "pending");

INSERT IGNORE INTO ledger_entries (entry_date, entry_shamsi, account_head, entry_type, course_id, debit_rial, credit_rial, description) VALUES
("2026-10-01", "۱۴۰۵/۰۷/۰۹", "بودجه مصوب نیمسال دوم واحد آموزش", "budget_alloc", NULL, 0, 5000000000, "ابلاغ بودجه مصوب هیئت رئیسه مؤسسه آموزشی آدان"),
("2026-10-12", "۱۴۰۵/۰۷/۲۰", "درآمد شهریه دوره‌های آموزشی", "revenue", 1, 0, 980000000, "تحقق درآمد ثبت‌نام‌های سازمانی و آزاد دوره TRD-101"),
("2026-10-15", "۱۴۰۵/۰۷/۲۳", "درآمد کارگاه سامانه مؤدیان", "revenue", 4, 0, 1360000000, "تسویه کامل ۳۸ فراگیر دوره TAX-110"),
("2026-10-18", "۱۴۰۵/۰۷/۲۶", "هزینه حق‌التدریس و پذیرایی آموزشی", "expense", 4, 245000000, 0, "حق‌التدریس استاد، پکیج آموزشی و پذیرایی ۴ جلسه");

INSERT IGNORE INTO evaluations (course_id, evaluator_id, kirkpatrick_l1_reaction, pre_test_score, post_test_score, kirkpatrick_l3_behavior, transfer_notes, program_cost_rial, estimated_benefit_rial, feedback_360_summary) VALUES
(4, 2, 4.78, 44.50, 87.40, 4.35, "کاهش خطای ثبت صورتحساب‌های الکترونیکی در واحد مالی شرکت‌های شرکت‌کننده پس از ۶۰ روز به میزان ۷۲٪", 245000000, 1360000000, "همسویی امتیاز خودارزیابی (۴.۴) با ارزیابی مدیر مستقیم (۴.۵) در شاخص انطباق مالیاتی"),
(1, 2, 4.92, 51.00, 89.50, 4.50, "اصلاح ترم تحویل در ۸ قرارداد صادراتی واقعی شرکت‌های عضو و جلوگیری از جریمه دموراژ کانتینر", 390000000, 1480000000, "رشد چشمگیر مهارت مذاکره قرارداد بین‌المللی طبق نظر مدیر بازرگانی");

INSERT IGNORE INTO crm_contacts (org_id, full_name, position_title, phone, email, lead_score, last_interaction) VALUES
(1, "پریسا بهرامی", "مدیر آموزش و توسعه منابع انسانی", "09121001006", "hr@zagros-steel.ir", 94, "درخواست برگزاری دوره اختصاصی CBAM برای ۱۲ نفر از مدیران فروش صادراتی"),
(3, "مهندس کاوه دریادل", "قائم‌مقام مدیرعامل لجستیک دریاپیما", "09123334455", "kaveh@daryapeyma.ir", 86, "مذاکره قرارداد سالانه آموزش ترخیص‌کاران و کارشناسان حمل ترکیبی"),
(4, "دکتر مریم شکیبا", "مدیر تحقیق و توسعه پلیمر سپهر", "09132221100", "r_d@sepehr-poly.ir", 79, "استعلام تعرفه بسته آموزشی هوش مصنوعی و بازاریابی بین‌الملل");

INSERT IGNORE INTO crm_deals (org_id, title, estimated_value_rial, stage, probability_pct, next_followup_shamsi, owner_user_id, notes) VALUES
(1, "قرارداد بسته جامع CBAM و صادرات سبز فولاد زاگرس", 1450000000, "negotiation", 85, "۱۴۰۵/۰۸/۰۴", 4, "پیش‌نویس مالی ارسال شده و آماده امضای نهایی است"),
(3, "تفاهم‌نامه آموزش ۴۰ کارشناس حمل‌ونقل بین‌المللی دریاپیما", 920000000, "proposal", 65, "۱۴۰۵/۰۸/۰۷", 4, "ارسال سیلابس اختصاصی با تخفیف ۲۰٪ اعضای نقره‌ای اتاق"),
(4, "دوره سازمانی هوش مصنوعی در بازرگانی پلیمر سپهر", 780000000, "qualified", 50, "۱۴۰۵/۰۸/۱۲", 4, "نیازسنجی اولیه انجام شد"),
(2, "تمدید قرارداد آموزشی سالانه زعفران تابان", 1120000000, "won", 100, "۱۴۰۵/۰۸/۰۱", 4, "قرارداد امضا و پیش‌پرداخت وصول گردید");

INSERT IGNORE INTO corporate_contracts (contract_no, org_id, title, total_amount_rial, paid_amount_rial, seat_quota, seats_used, start_shamsi, end_shamsi, approval_stage, deliverables_summary) VALUES
("CNT-1405-401", 1, "قرارداد جامع توانمندسازی مدیران و کارشناسان صادرات فولاد زاگرس", 2400000000, 1800000000, 60, 44, "۱۴۰۵/۰۱/۱۵", "۱۴۰۵/۱۲/۲۹", "approved_active", "شامل ۶ دوره تخصصی تجارت خارجی، کارگاه CBAM و گواهی‌نامه‌های دوزبانه مؤسسه آموزشی آدان"),
("CNT-1405-409", 2, "قرارداد آموزشی بسته‌بندی، استانداردهای غذایی اروپا و بازاریابی صادراتی", 1120000000, 560000000, 35, 16, "۱۴۰۵/۰۶/۰۱", "۱۴۰۶/۰۵/۳۱", "approved_active", "ویژه تیم فروش بین‌الملل و کنترل کیفیت صادراتی");

INSERT IGNORE INTO trade_paths (title, target_market, steps_json, scenario_title, scenario_prompt, optimal_incoterm, badge_title) VALUES
("مسیر جامع معمار صادرات صنعتی به اتحادیه اروپا و اوراسیا", "اتحادیه اروپا و اتحادیه اقتصادی اوراسیا", "[\"گام ۱: دوره جامع اینکوترمز ۲۰۲۰ و اسناد حمل (TRD-101)\",\"گام ۲: مدیریت ریسک ارزی و رفع تعهد (TRD-204)\",\"گام ۳: انطباق کربن مرزی اروپا CBAM (TRD-309)\",\"گام ۴: هوش مصنوعی در کشف خریداران خارجی (AID-301)\"]", "سناریوی تصمیم‌گیری صادرات ۲۰ کانتینر محصول صنعتی به هامبورگ", "خریدار آلمانی پیشنهاد خرید با ترم DDP Hamburg داده است، در حالی که شرکت شما شخصیت حقوقی ثبت‌شده برای ترخیص وارداتی و پرداخت VAT در گمرک آلمان ندارد. بهترین جایگزین استاندارد ICC چیست؟", "CIP Hamburg / DAP Terminal (Incoterms 2020)", "گواهی عالی معمار تجارت بین‌الملل مؤسسه آموزشی آدان");

INSERT IGNORE INTO leadership_programs (title, cohort_name, participants_count, criteria_weights_json, mentoring_assignment, avg_360_score) VALUES
("آکادمی رهبران آینده صنعت و تجارت استان (Executive Mini-MBA)", "نسل چهارم مدیران ارشد ۱۴۰۵", 24, "{\"بازده اقتصادی و سودآوری\":35,\"مدیریت ریسک ارزی و زنجیره تأمین\":25,\"توسعه بازار صادراتی پایدار\":25,\"چابکی سازمانی و نگهداشت استعداد\":15}", "تدوین برنامه تحول صادراتی ۹۰ روزه بنگاه اقتصادی با همراهی منتور منتور ارشد مؤسسه آموزشی آدان", 4.52);

INSERT IGNORE INTO consulting_sessions (consultant_id, client_user_id, topic, slot_label, status, agenda, confidential_note, action_items) VALUES
(5, 7, "بازنگری قرارداد نمایندگی انحصاری توزیع در بازار عراق و امارات", "چهارشنبه ۱۴۰۵/۰۸/۰۶ - ساعت ۱۶:۰۰ الی ۱۷:۳۰", "confirmed", "بررسی شرط داوری مرجع بین‌المللی ICC، سقف تضمین حداقل فروش سالانه و نحوه تسویه ارزی", "یادداشت محرمانه مشاور: شرکت مراجع در قرارداد قبلی حق فسخ یک‌طرفه را پیش‌بینی نکرده که ریسک حقوقی بالایی دارد؛ اصلاح بند ۱۴ ضروری است.", "ارسال پیش‌نویس اصلاحیه بند داوری و شرط فورس‌ماژور تا یکشنبه آینده");

INSERT IGNORE INTO exams (id, course_id, title, duration_minutes, max_attempts, pass_score, is_active) VALUES
(1, 1, "آزمون پایانی استاندارد دوره جامع مدیریت صادرات و اینکوترمز ۲۰۲۰", 25, 3, 70.00, 1);

INSERT IGNORE INTO exam_questions (exam_id, question_type, question_text, option_a, option_b, option_c, option_d, correct_option, points) VALUES
(1, "mcq", "طبق قواعد Incoterms 2020، در کدام قاعده فروشنده موظف به تهیه بیمه‌نامه باربری با حداکثر پوشش (کلوز A انستیتو بیمه لندن) به نفع خریدار است؟", "CIF", "CIP", "CFR", "DAP", "B", 35.00),
(1, "mcq", "در قاعده FOB بندرعباس (Incoterms 2020)، نقطه دقیق انتقال ریسک خسارت کالا از فروشنده به خریدار کجاست؟", "تحویل کالا در انبار کارخانه فروشنده", "تحویل به حمل‌کننده در ترمینال خشکی", "قرار گرفتن کالا روی عرشه کشتی تعیین‌شده در بندرعباس", "تخلیه کالا در بندر مقصد خریدار", "C", 35.00),
(1, "descriptive", "تفاوت کاربردی FOB و FCA را برای حمل کانتینری صادراتی در ۴ سطر تحلیل نمایید و بنویسید چرا مرجع بین‌المللی ICC FCA را توصیه می‌کند.", NULL, NULL, NULL, NULL, NULL, 30.00);

INSERT IGNORE INTO exam_attempts (exam_id, user_id, attempt_no, auto_score, descriptive_score, descriptive_answer, status) VALUES
(1, 7, 1, 70.00, 24.00, "در حمل کانتینری محموله چند روز پیش از بارگیری در CY تحویل خط کشتیرانی می‌شود؛ لذا در FCA ریسک از لحظه تحویل به حمل‌کننده منتقل می‌گردد.", "finalized");

INSERT IGNORE INTO certificates (serial_code, user_id, course_id, issue_shamsi, grade_label, hours_completed, status, revoked_reason) VALUES
("CERT-ADN-1405-9001", 7, 1, "۱۴۰۵/۰۷/۲۸", "عالی (۹۴ از ۱۰۰)", 24, "valid", NULL),
("CERT-ADN-1405-9002", 7, 4, "۱۴۰۵/۰۷/۱۸", "عالی (۹۱ از ۱۰۰)", 12, "valid", NULL),
("CERT-ADN-1405-8100", 8, 4, "۱۴۰۵/۰۶/۳۰", "مردود / ابطال اصلاحی", 12, "revoked", "ابطال سیستمی جهت صدور مجدد به دلیل اصلاح کد ملی در پرونده آموزشی");

INSERT IGNORE INTO classroom_bookings (classroom_id, booked_by, purpose, booking_date, booking_shamsi, start_time, end_time, catering_request) VALUES
(1, 2, "اجرای جلسه سوم دوره اینکوترمز ۲۰۲۰ (TRD-101)", "2026-11-01", "۱۴۰۵/۰۸/۱۰", "14:00:00", "18:00:00", "پذیرایی میان‌وعده ۳۰ نفر + آب معدنی میز استاد"),
(2, 2, "کارگاه عملی هوش مصنوعی در بازاریابی صادراتی", "2026-11-03", "۱۴۰۵/۰۸/۱۲", "09:00:00", "13:00:00", "چای و نسکافه ۲۸ نفر");

INSERT IGNORE INTO research_projects (title, lead_researcher, methodology, budget_rial, progress_pct, form_id, publication_summary, status) VALUES
("اطلس نیازسنجی مهارت‌های صادراتی و هوش مصنوعی ۵۰۰ بنگاه صنعتی استان در افق ۱۴۰۷", "دکتر امیرحسین نیکزاد و گروه پژوهش اتاق", "ترکیبی (پیمایش کمّی فرم‌ساز + ۲۴ مصاحبه عمیق با صادرکنندگان نمونه)", 780000000, 78, 1, "یافته کلیدی: ۷۴٪ واحدهای صنعتی استان کمبود نیروی مسلط به مذاکره انگلیسی تجاری، CBAM و تحلیل بازار با AI را مهم‌ترین مانع توسعه صادرات اعلام کردند.", "fieldwork");

INSERT IGNORE INTO library_items (id, title, authors, category, license_type, edition, course_id, downloads_count, available_copies, abstract_text) VALUES
(1, "راهنمای کاربردی مؤسسه آموزشی آدان برای انطباق با مکانیسم تعدیل کربن مرزی اروپا (CBAM)", "معاونت بین‌الملل و واحد آموزش مؤسسه آموزشی آدان", "گزارش راهبردی صادرات", "دسترسی آزاد فراگیران آدان", "ویرایش پاییز ۱۴۰۵", 6, 148, 4, "این راهنما نحوه محاسبه انتشار کربن مستقیم و غیرمستقیم در صنایع فولاد، سیمان، آلومینیوم و کود شیمیایی و نحوه تنظیم گزارش فصلی برای خریداران اروپایی را تشریح می‌کند."),
(2, "مرجع کامل قواعد Incoterms 2020 و چک‌لیست اسناد حمل و اعتبارات اسنادی UCP600", "دکتر امیرحسین نیکزاد", "کتاب آموزشی تخصصی", "مجوز مطالعه اعضای پورتال", "چاپ چهارم ۱۴۰۵", 1, 312, 2, "بررسی تطبیقی قواعد یازده‌گانه تحویل کالا، نمونه کلوزهای قراردادی، بارنامه دریایی، راهنامه جاده‌ای CMR و مدیریت مغایرت اسناد بانکی.");

INSERT IGNORE INTO library_loans (item_id, user_id, loan_shamsi, due_shamsi, returned_at, review_note) VALUES
(2, 7, "۱۴۰۵/۰۷/۲۰", "۱۴۰۵/۰۸/۰۵", NULL, "منبع فوق‌العاده کاربردی برای تنظیم پیش‌فاکتورهای صادراتی.");

INSERT IGNORE INTO internships (program_title, host_org_id, intern_user_id, team_name, milestone_stage, deliverable_file, rubric_score_json, total_score, status) VALUES
("طرح ملی پویش؛ تربیت دستیار صادرات در صنایع برتر استان", 1, 7, "تیم صادرات صنعتی زاگرس", "تدوین پرونده بازاریابی ۵ خریدار در عمان و قزاقستان", "zagros_oman_market_study.pdf", "{\"تحلیل داده بازار\":24,\"تسلط بر قوانین گمرکی\":22,\"کیفیت مستندسازی تجاری\":22,\"کار تیمی و نظم حرفه‌ای\":21}", 89.00, "active");

INSERT IGNORE INTO competitions (title, current_round, team_name, weighted_criteria_json, jury_score, judge_comment) VALUES
("لیگ استانی شبیه‌ساز مذاکره تجاری و مدیریت بحران صادراتی جام مؤسسه آموزشی آدان", "راند دوم - نیمه‌نهایی", "تیم پیشگامان تجارت پارس", "{\"استراتژی قیمت‌گذاری ارزی\":30,\"تکنیک‌های مذاکره برد-برد\":30,\"مدیریت ریسک حقوقی قرارداد\":25,\"ارائه تیمی\":15}", 92.40, "مدیریت هوشمندانه شرط تعدیل قیمت ارزی در برابر هیئت داوران"),
("لیگ استانی شبیه‌ساز مذاکره تجاری و مدیریت بحران صادراتی جام مؤسسه آموزشی آدان", "راند دوم - نیمه‌نهایی", "تیم صادرات هوشمند زاگرس", "{\"استراتژی قیمت‌گذاری ارزی\":30,\"تکنیک‌های مذاکره برد-برد\":30,\"مدیریت ریسک حقوقی قرارداد\":25,\"ارائه تیمی\":15}", 88.90, "تسلط دقیق بر اینکوترمز CIP و بیمه باربری");

INSERT IGNORE INTO hr_records (staff_user_id, record_type, title, details, kpi_score, status, created_shamsi) VALUES
(2, "periodic_eval", "ارزیابی عملکرد سه‌ماهه تابستان ۱۴۰۵ کارشناس مسئول آموزش", "اجرای منظم ۱۴ دوره آموزشی با شاخص رضایت ۹۴.۲٪ و راه‌اندازی ثبت‌نام گروهی سازمانی", 95, "approved", "۱۴۰۵/۰۷/۱۰"),
(2, "leave_request", "درخواست مرخصی روزانه - ۲ روز در نیمه دوم آبان ۱۴۰۵", "هماهنگی جایگزینی جلسات با کارشناس اجرای کلاس انجام شده است", NULL, "open", "۱۴۰۵/۰۷/۲۹"),
(2, "succession", "برنامه جانشین‌پروری سمت معاون اجرایی مرکز آموزش", "تکمیل ۸۵٪ شایستگی‌های رهبری آموزشی و مدیریت بودجه", 85, "open", "۱۴۰۵/۰۷/۱۵");

INSERT IGNORE INTO bpms_workflows (process_key, process_title, subject_label, initiator_id, current_step, assigned_role, sla_hours, elapsed_hours, status, history_json) VALUES
("COURSE_APPROVAL", "فرایند بررسی و تصویب دوره آموزشی جدید", "برنامه عالی توسعه رهبری مدیران صنایع (LDR-401)", 2, "تأیید نهایی کمیته علمی و مدیر آموزش", "super_admin", 48, 31, "running", "[{\"step\":\"ثبت توسط کارشناس آموزش\",\"by\":\"مهندس سارا فرهمند\",\"time\":\"۱۴۰۵/۰۷/۲۸ ۱۰:۱۵\"},{\"step\":\"تأیید بودجه و تعرفه توسط مالی\",\"by\":\"حسین کاظمی‌نژاد\",\"time\":\"۱۴۰۵/۰۷/۲۹ ۱۱:۴۰\"}]"),
("INSTRUCTOR_PAYOUT", "فرایند تسویه حق‌التدریس مدرس", "حق‌التدریس دوره جامع صادرات (RUN-1405-01) - دکتر نیکزاد", 2, "تأیید و دستور پرداخت مدیر مالی", "finance_manager", 24, 29, "running", "[{\"step\":\"ثبت کارکرد ۲۴ ساعت تدریس\",\"by\":\"مهندس سارا فرهمند\",\"time\":\"۱۴۰۵/۰۷/۲۹ ۰۹:۰۰\"}]");

INSERT IGNORE INTO saved_reports (title, dataset_key, filter_expr, cron_schedule, ai_insight, created_by) VALUES
("گزارش عملکرد ثبت‌نام و ظرفیت دوره‌های فعال پاییز ۱۴۰۵", "courses_summary", "published", "0 8 * * 6", "تحلیل هوشمند: دوره‌های حوزه صادرات و سامانه مؤدیان بالاترین نرخ تکمیل ظرفیت (۹۳٪) و بیشترین حاشیه سود خالص را در سبد آموزشی آدان دارند.", 1),
("گزارش قیف فروش قراردادهای سازمانی بالای ۵۰۰ میلیون ریال", "crm_pipeline", "all", "0 9 1 * *", "تحلیل هوشمند: با نهایی‌سازی ۲ پرونده در مرحله مذاکره نهایی، ۲.۳۷ میلیارد ریال به درآمد قطعی آبان‌ماه افزوده می‌شود.", 4);

INSERT IGNORE INTO ai_prompts (code, title, module_name, system_prompt, temperature) VALUES
("SYLLABUS_GEN", "طراح سرفصل استاندارد دوره‌های مؤسسه آموزشی آدان", "AI Studio", "تو طراح ارشد آموزشی مؤسسه آموزشی آدان هستی. خروجی را کاملاً کاربردی، بومی‌سازی‌شده با قوانین تجاری و گمرکی ایران و نیاز بنگاه‌های صادراتی به صورت پیش‌نویس ساختارمند فارسی بنویس.", 0.45),
("TNA_GAP_ADVISOR", "تحلیل‌گر شکاف شایستگی و پیشنهاد مسیر یادگیری", "Competency TNA", "بر اساس ماتریس سطح فعلی و سطح هدف شایستگی‌های بازرگانی و مدیریتی، مهم‌ترین شکاف‌ها را اولویت‌بندی کن و دوره دقیق متناظر از کاتالوگ مؤسسه آموزشی آدان پیشنهاد بده.", 0.30),
("BI_EXECUTIVE_ANALYST", "مشاور هوش تجاری هیئت رئیسه مؤسسه آموزشی آدان", "BI & Reports", "داده‌های مالی، ثبت‌نام و اثربخشی کرکپاتریک واحد آموزش را تحلیل کن و ۳ تصمیم اجرایی مشخص برای افزایش اثرگذاری استانی پیشنهاد بده.", 0.35);

INSERT IGNORE INTO ai_usage_logs (user_id, module_name, provider, model_name, prompt_tokens, completion_tokens, latency_ms, execution_mode) VALUES
(1, "AI Studio", "AI", "gpt-4o-mini", 640, 920, 840, "simulation_fallback"),
(2, "Competency TNA", "AI", "gpt-4o-mini", 490, 610, 690, "simulation_fallback"),
(1, "BI Report Narrative", "AI", "gpt-4o-mini", 530, 480, 620, "simulation_fallback");

INSERT IGNORE INTO rag_documents (title, category, keywords, chunk_text) VALUES
("آیین‌نامه تخفیفات آموزشی فراگیران آدان استان", "آیین‌نامه مالی و ثبت‌نام", "تخفیف عضویت کارت بازرگانی طلایی گروهی سازمانی", "دارندگان کارت عضویت معتبر مؤسسه آموزشی آدان مشمول ۱۵ تا ۳۰ درصد تخفیف سازمانی در دوره‌های تخصصی هستند و شرکت‌های دارای قرارداد سالانه می‌توانند به صورت اقساطی یا از محل اعتبار قرارداد ثبت‌نام نمایند."),
("ضوابط حضور و ارزیابی دوره‌های آدان", "آیین‌نامه آموزشی", "گواهی حضور غیاب نمره قبولی آزمون QR", "برای دریافت گواهی پایان دورهٔ آموزشگاه آدان، حضور حداقل ۸۰ درصد ساعات دوره و کسب حداقل نمرهٔ قبولی ۷۰ از ۱۰۰ لازم است. وضعیت گواهی فقط در سوابق داخلی آموزشگاه قابل مشاهده است و این گواهی جایگزین مجوز یا تأییدیهٔ مرجع رسمی نیست.");

INSERT IGNORE INTO webhooks_and_jobs (entry_kind, name, target_url_or_handler, event_trigger, status, last_response) VALUES
("webhook", "پیش‌نویس محلی رویداد ثبت‌نام", "https://example.invalid/adan-webhook", "enrollment.created", "draft_local", "پیش‌نویس محلی؛ هیچ درخواست بیرونی ارسال نشده"),
("queue_job", "تولید گزارش میانگین نمره به تفکیک کانال جذب", "BiScheduledReportJob::handle", "cron.weekly", "queued", "در صف اجرا؛ ارسال بیرونی انجام نمی‌شود");

INSERT IGNORE INTO documents (title, doc_category, file_name, file_path, uploaded_by, access_scope) VALUES
("تقویم جامع آموزشی پاییز و زمستان ۱۴۰۵ مؤسسه آموزشی آدان", "تقویم و بخشنامه‌ها", "calendar_1405_chamber.txt", "storage/uploads/docs/calendar_1405_chamber.txt", 1, "public"),
("فرم استاندارد قرارداد آموزشی بنگاه‌های اقتصادی دانش‌پذیر آدان", "قراردادها و حقوقی", "corporate_contract_template.txt", "storage/uploads/docs/corporate_contract_template.txt", 1, "staff");

INSERT IGNORE INTO dynamic_forms (id, title, slug, purpose, fields_json, submissions_count) VALUES
(1, "فرم نیازسنجی مهارت‌های صادراتی و هوش مصنوعی صنایع استان (۱۴۰۵)", "export-tna-1405", "پژوهش آموزشی و نیازسنجی سالانه اعضا", "[{\"name\":\"company_name\",\"label\":\"نام شرکت / واحد صنعتی\",\"type\":\"text\"},{\"name\":\"export_target\",\"label\":\"مهم‌ترین بازار هدف صادراتی\",\"type\":\"select\",\"options\":[\"عراق و همسایگان\",\"امارات و خلیج فارس\",\"اتحادیه اوراسیا و روسیه\",\"اتحادیه اروپا\",\"چین و شرق آسیا\"]},{\"name\":\"priority_skill\",\"label\":\"اولویت اول آموزشی سال ۱۴۰۵\",\"type\":\"select\",\"options\":[\"اینکوترمز ۲۰۲۰ و قراردادها\",\"رفع تعهد ارزی و بانکی\",\"هوش مصنوعی در صادرات\",\"مالیات و سامانه مؤدیان\",\"استاندارد CBAM اروپا\"]},{\"name\":\"notes\",\"label\":\"چالش اصلی بازرگانی شرکت شما\",\"type\":\"textarea\"}]", 28);

INSERT IGNORE INTO portal_pages (slug, version_no, hero_title, hero_subtitle, announcement_bar, featured_boxes_json, is_published, edited_by) VALUES
("home", 1, "پورتال آموزش حسابداری آدان (نسخه اولیه)", "آموزش کاربردی حسابداری و امور مالی در مسیر بازار کار", "آغاز ثبت‌نام دوره‌های پاییزه", "[\"کاتالوگ دوره‌ها\",\"استعلام گواهی‌نامه\"]", 0, 2),
("home", 2, "آموزشگاه حسابداری آدان", "آموزش کاربردی حسابداری، مالیات، حقوق و دستمزد و نرم‌افزارهای مالی؛ از مبانی تا ورود مطمئن به بازار کار.", "ثبت‌نام ترم پاییز ۱۴۰۵ آغاز شد | ۲۵٪ تخفیف ویژه ثبت‌نام گروهی دوره‌های حسابداری", "[\"آکادمی تجارت بین‌الملل و CBAM\",\"استعلام برخط اصالت گواهی‌نامه با QR\",\"پورتال اختصاصی سازمان‌ها و قراردادها\",\"همراه هوشمند آموزشی مبتنی بر AI\"]", 1, 1);

INSERT IGNORE INTO marketing_campaigns (title, segment_name, channel, variant_a_text, variant_b_text, human_approved, scheduled_shamsi, conversion_a_pct, conversion_b_pct, status) VALUES
("کمپین معرفی کارگاه رفع تعهد ارزی صادرکنندگان", "صادرکنندگان دارای کارت بازرگانی فعال (رضایت‌نامه تأییدشده)", "sms_sandbox", "نسخه A: صادرکننده گرامی، ظرفیت کارگاه تخصصی رفع تعهد ارزی مؤسسه آموزشی آدان رو به تکمیل است. ثبت‌نام با ۲۰٪ تخفیف اعضا.", "نسخه B: با تسلط بر ضوابط جدید ارزی ۱۴۰۵ از جرائم مالیاتی پیشگیری کنید؛ کارگاه کاربردی مؤسسه آموزشی آدان با تدریس دکتر نیکزاد.", 1, "۱۴۰۵/۰۸/۰۲ ساعت ۱۰:۰۰", 13.8, 21.4, "scheduled"),
("کمپین معرفی دوره هوش مصنوعی در صادرات", "مدیران بازرگانی خارجی شرکت‌های صنعتی", "email_sandbox", "نسخه A: دوره کاربردی هوش مصنوعی در بازاریابی بین‌الملل در مؤسسه آموزشی آدان.", "نسخه B: چگونه با هوش مصنوعی در ۳۰ دقیقه خریداران واقعی کد تعرفه HS محصول خود را بیابید؟", 0, "۱۴۰۵/۰۸/۰۸ ساعت ۰۹:۳۰", 0.0, 0.0, "awaiting_approval");

INSERT IGNORE INTO market_intel (region, competitor_or_source, source_url, trend_topic, ai_gap_summary, last_checked_shamsi) VALUES
("اتحادیه اروپا", "ICC Academy & European Chambers (Eurochambres)", "https://iccwbo.org/academy", "گزارش‌دهی الزامی کربن مرزی (CBAM) و زنجیره تأمین پایدار سبز ۲۰۲۶", "پیشنهاد AI: مؤسسات آموزشی اروپا دوره‌های عملی محاسبه کربن فولاد، سیمان و آلومینیوم را الزامی کرده‌اند؛ اجرای فوری دوره TRD-309 مزیت رقابتی ممتاز در کشور ایجاد می‌کند.", "۱۴۰۵/۰۷/۳۰"),
("ایران", "پایش مراکز آموزشی بازرگانی و صنعتی کشور", "https://chamber-intel.local/iran-trends-1405", "افزایش ۱۸۰ درصدی تقاضای کارگاه‌های عملی هوش مصنوعی در مکاتبات تجاری و تهاتر ارزی", "پیشنهاد AI: ترکیب دوره آنلاین همزمان با کلینیک مشاوره اختصاصی پس از دوره، نرخ ثبت‌نام سازمانی را تا ۴۰٪ افزایش می‌دهد.", "۱۴۰۵/۰۷/۲۹");

INSERT IGNORE INTO psychometric_results (user_id, test_name, analytical_score, collaborative_score, decisive_score, resilience_score, dominant_style) VALUES
(7, "سنجش سبک مذاکره تجاری و شایستگی رفتاری (نمره‌دهی قطعی)", 88, 84, 76, 81, "مذاکره‌گر تحلیلی - برد/برد (مناسب قراردادهای بلندمدت بین‌المللی)");

INSERT IGNORE INTO user_badges (user_id, badge_code, badge_title, skill_domain, issued_shamsi) VALUES
(7, "BDG-INCO-2026", "متخصص تاییدشده Incoterms 2020", "تجارت بین‌الملل", "۱۴۰۵/۰۷/۲۸"),
(7, "BDG-TAX-2026", "کارشناس رسمی سامانه مؤدیان مالیاتی", "مالی و مالیاتی", "۱۴۰۵/۰۷/۱۸");

INSERT IGNORE INTO support_tickets (user_id, subject, department, message, reply_text, status) VALUES
(6, "درخواست افزودن ۴ نفر جدید به فهرست ثبت‌نام گروهی فولاد زاگرس", "قراردادهای سازمانی", "سلام، لطفاً سهمیه ۴ کارشناس جدید واحد صادرات شرکت را در اجرای آبان‌ماه فعال فرمایید.", "با سلام، سهمیه از محل قرارداد CNT-1405-401 تأیید و فعال گردید.", "answered");

INSERT IGNORE INTO bpms_routing_rules (rule_name, process_key, condition_expr, routing_mode, target_roles, sla_hours) VALUES
("شرط سقف ریالی قرارداد سازمانی بالای ۱ میلیارد ریال", "CONTRACT_DISCOUNT", "amount_rial > 1000000000", "parallel", "finance_manager + super_admin", 48),
("مسیر شرطی تخفیف ویژه اعضای طلایی بالای ۲۵٪", "COURSE_APPROVAL", "discount_pct > 25", "conditional", "super_admin", 24),
("مسیر موازی تجهیز کارگاه و تأیید بودجه", "EQUIPMENT_PURCHASE", "budget_category = IT_LAB", "parallel", "training_expert + finance_manager", 36);

INSERT IGNORE INTO scorm_cmi_tracks (user_id, lesson_id, sco_identifier, lesson_status, score_raw, score_max, session_time, lesson_location, suspend_data, commit_count) VALUES
(1, 3, "INCOTERMS_2020_SCO_01", "incomplete", 60.00, 100.00, "00:08:45", "slide_2", "{\"step\":2,\"selected\":\"FOB\"}", 2),
(7, 3, "INCOTERMS_2020_SCO_01", "completed", 100.00, 100.00, "00:19:20", "slide_3", "{\"step\":3,\"selected\":\"CIF\"}", 4);

INSERT IGNORE INTO payment_transactions (id, invoice_id, authority_code, ref_id, amount_rial, gateway_mode, hmac_signature, is_reconciled) VALUES
(1, 1, "AUTH-CHB-990101", "SHAPARAK-SANDBOX-778811", 57200000, "sandbox_hmac_signed", "9b8c7d6e5f4a3b2c1d0e9f8a7b6c5d4e", 0);

INSERT IGNORE INTO commercial_card_cases (id, tracking_code, applicant_name, national_or_legal_id, card_request_type, attendance_pct, exam_score, clearance_status, clearance_code) VALUES
(1, "CC-1405-1001", "مهندس بهرام کیانی (مدیرعامل کشت‌وصنعت زاگرس)", "14008811220", "صدور اولیه حقوقی", 92, 86.50, "تأیید نهایی واحد آموزش", "CLR-CARD-1405-9821"),
(2, "CC-1405-1002", "سرکار خانم سمانه رضوی", "0071928374", "صدور اولیه حقیقی", 65, 58.00, "در حال گذراندن دوره", NULL),
(3, "CC-1405-1003", "شرکت بازرگانی سپهر لجستیک پارس", "10105544332", "تمدید کارت بازرگانی", 100, 91.00, "تأیید نهایی واحد آموزش", "CLR-CARD-1405-9940");

INSERT IGNORE INTO virtual_class_rooms (id, run_id, provider, room_title, sso_slug, online_participants, synced_attendance_count, recording_url) VALUES
(1, 1, "Skyroom", "کلاس زنده جامع اینکوترمز ۲۰۲۰ و اسناد حمل", "incoterms-live-1405", 0, 0, NULL),
(2, 2, "BigBlueButton", "وبینار تخصصی سامانه مؤدیان و پایانه‌های فروشگاهی", "tax-moadian-live", 0, 0, NULL);

INSERT IGNORE INTO tax_moadian_packets (id, invoice_id, tax_unique_id_22, invoice_pattern, accounting_target, payload_sha256, submission_status) VALUES
(1, 1, "", "الگوی اول - فروش خدمات آموزشی", "سپیدار همکاران", "e3b0c44298fc1c149afbf4c8996fb92427ae41e4", "پیش‌نویس محلی - ارسال نشده");

INSERT IGNORE INTO trade_missions (id, mission_code, title, mission_type, target_country_or_city, sector_focus, shamsi_dates, delegates_count, b2b_meetings_count, mou_value_usd, status) VALUES
(1, "MSN-OMN-1405", "هیئت تجاری و آموزشی صادرکنندگان صنایع غذایی و ساختمانی به مسقط", "هیئت تجاری اعزامی", "عمان — مسقط", "صنایع غذایی، خشکبار و مصالح ساختمانی", "۱۴ تا ۱۸ آذر ۱۴۰۵", 18, 64, 1450000, "در حال ثبت‌نام اعضا"),
(2, "MSN-EUR-1405", "پذیرش هیئت خریداران اتحادیه اقتصادی اوراسیا در اتاق استان", "هیئت تجاری پذیرشی", "روسیه و قزاقستان", "محصولات پتروشیمی، پلیمری و کشاورزی", "۲۵ آبان ۱۴۰۵", 24, 90, 2100000, "تکمیل ظرفیت B2B"),
(3, "MSN-IND-1405", "تور یادگیری کارخانه‌ای: خط تولید هوشمند فولاد و لجستیک خشک", "تور بازدید صنعتی استان", "شهرک صنعتی بزرگ استان", "مدیران تولید و تعالی سازمانی", "۸ آذر ۱۴۰۵", 30, 12, 0, "در حال ثبت‌نام اعضا");

INSERT IGNORE INTO chamber_commissions (id, commission_name, chairperson_name, resolution_title, requested_course_topic, priority_level, converted_to_tms, session_shamsi) VALUES
(1, "کمیسیون توسعه صادرات غیرنفتی و گمرک", "مهندس فرهاد نیک‌نژاد", "مصوبه جلسه ۱۴: الزام آموزش رفع تعهد ارزی نیما و مرکز مبادله برای صادرکنندگان نوپا", "کارگاه عملی رفع تعهد ارزی صادرکنندگان ۱۴۰۵", "فوری استانی", 1, "۱۴۰۵/۰۷/۲۲"),
(2, "کمیسیون صنعت، معدن و انرژی", "دکتر منصور بهرامی", "مصوبه جلسه ۹: توانمندسازی مدیران انرژی کارخانجات در مدیریت بهینه بار و پنل خورشیدی صنعتی", "مدیریت بهینه‌سازی مصرف انرژی و نیروگاه خورشیدی صنایع", "اولویت فصلی", 0, "۱۴۰۵/۰۷/۲۸");

INSERT IGNORE INTO iso_qa_records (id, standard_code, clause_title, finding_type, capa_action, owner_unit, status, audit_shamsi) VALUES
(1, "ISO 21001:2018", "بند ۸.۵ — کنترل کیفیت طراحی سرفصل و بازنگری سالانه محتوا", "انطباق کامل", "ثبت چرخه بازبینی کمیته علمی و تأیید انسانی تولیدات AI در سامانه", "واحد برنامه‌ریزی آموزش", "تأیید ممیز نهایی", "۱۴۰۵/۰۷/۱۵"),
(2, "ISO 10015:2019", "بند ۴.۴ — ارزیابی اثربخشی انتقال یادگیری ۳ ماه پس از دوره", "فرصت بهبود", "تکمیل فرم پیگیری سطح ۳ کرکپاتریک از مدیران مستقیم صنایع عضو", "واحد ارزیابی و کیفیت", "اقدام اصلاحی انجام شد", "۱۴۰۵/۰۷/۲۰");

INSERT IGNORE INTO business_clinic_cases (id, org_name, industry_sector, era_production_score, era_packaging_score, era_marketing_score, era_finance_legal_score, total_era_index, main_bottleneck, prescribed_pack, diagnosed_shamsi) VALUES
(1, "مجتمع صنایع غذایی بهاران استان", "صنایع تبدیلی و خشکبار", 85, 48, 42, 65, 60, "عدم انطباق لیبلینگ و بسته‌بندی خرده‌فروشی با استاندارد بازار خلیج فارس", "مشاوره طراحی بسته‌بندی صادراتی + دوره بازاریابی بین‌الملل و نمایشگاه‌ها", "۱۴۰۵/۰۷/۲۴"),
(2, "کارخانه قطعات دقیق پارس صنعت", "قطعات صنعتی و ماشین‌آلات", 88, 76, 52, 44, 65, "ضعف در تنظیم قراردادهای فروش بین‌المللی و تضامین بانکی", "کلینیک حقوقی قراردادهای بین‌المللی + آکادمی اینکوترمز ۲۰۲۰", "۱۴۰۵/۰۷/۲۷");

INSERT IGNORE INTO job_board_listings (id, org_name, job_title, required_cert_code, city, salary_range, matched_candidates, status, posted_shamsi) VALUES
(1, "شرکت فولاد زاگرس پارس", "کارشناس ارشد بازرگانی خارجی و سفارشات گمرکی", "TRD-101 (گواهی معتبر اینکوترمز اتاق)", "مرکز استان", "۳۵ تا ۴۸ میلیون تومان + پاداش صادراتی", 5, "در مرحله مصاحبه", "۱۴۰۵/۰۷/۲۵"),
(2, "گروه صادراتی زعفران و پسته آریا", "مسئول حسابداری مالیاتی و سامانه مؤدیان", "FIN-202 (گواهی مالیاتی اتاق)", "شهرک صنعتی شماره ۲", "۲۸ تا ۳۶ میلیون تومان", 4, "فعال", "۱۴۰۵/۰۷/۲۹");

INSERT IGNORE INTO grants_and_mous (id, record_category, partner_organization, title, subsidy_percent, allocated_budget_rial, utilized_rial, expiry_shamsi, status) VALUES
(1, "یارانه آموزشی SME", "شرکت شهرک‌های صنعتی استان", "طرح حمایت ۵۰ درصدی شهریه دوره‌های صادراتی ویژه واحدهای صنعتی کوچک مستقر در شهرک‌ها", 50, 1500000000, 620000000, "۱۴۰۵/۱۲/۲۹", "فعال و قابل تخصیص"),
(2, "تفاهم‌نامه همکاری", "دانشگاه صنعتی استان", "تفاهم‌نامه اجرای مشترک طرح پویش، کارآموزی هدفمند و پایان‌نامه‌های تقاضامحور صنعتی", 40, 800000000, 290000000, "۱۴۰۶/۰۶/۳۱", "فعال و قابل تخصیص");

INSERT IGNORE INTO sso_pki_logs (id, user_full_name, national_code, mobile_number, shahkar_status, document_title, pki_hash_sha256, signed_shamsi) VALUES
(1, "دکتر کیارش رادمهر", "0061234567", "09121112233", "تطبیق هویت شبیه‌ساز تأیید شد", "قرارداد آموزشی سازمانی فولاد زاگرس (CTR-1405-01)", "7f83b1657ff1fc53b92dc18148a1d65dfc2d4b1fa3d677284addd200126d9069", "۱۴۰۵/۰۷/۲۸ ساعت ۱۰:۱۵");

INSERT IGNORE INTO proctoring_events (id, user_full_name, exam_or_lesson_title, event_type, risk_level, watermark_stamp, reviewer_decision) VALUES
(1, "مهندس نیما فرهادی", "آزمون جامع اینکوترمز ۲۰۲۰", "فعال‌سازی واترمارک پویا", "کم", "NID:0079988776 | IP:185.143.x.x", "تأیید سلامت آزمون"),
(2, "سارا محمدی", "آزمون جامع اینکوترمز ۲۰۲۰", "تغییر تب مرورگر", "متوسط", "NID:0081122334 | ۲ مرتبه خروج موقت از تب", "تذکر سیستمی - بدون تخلف");

INSERT IGNORE INTO alumni_network_posts (id, author_name, company_and_role, graduated_course, collaboration_type, proposal_body, responses_count, posted_shamsi) VALUES
(1, "مهندس امیرحسین کاظمی", "مدیر صادرات کاشی کویر", "آکادمی جامع مدیریت صادرات اتاق", "کنسرسیوم صادراتی", "پیشنهاد تشکیل کنسرسیوم مشترک ارسال کانتینر ترکیبی (LCL) مصالح ساختمانی استان به بندر صحار عمان برای کاهش ۴۰٪ هزینه حمل.", 7, "۱۴۰۵/۰۷/۲۶");

INSERT IGNORE INTO iran_messenger_dispatches (id, channel, recipient_group, message_text, delivery_mode, sent_count, sent_shamsi) VALUES
(1, "کاوه‌نگار SMS", "فراگیران دوره اینکوترمز ۲۰۲۰", "یادآوری جلسه سوم کارگاه عملی اینکوترمز — یکشنبه ساعت ۱۴ سالن خلیج فارس مؤسسه آموزشی آدان.", "ثبت محلی - ارسال نشده", 0, "۱۴۰۵/۰۷/۲۹"),
(2, "بازوی بله (Bale)", "مدیران عامل عضو کمیسیون صادرات", "فایل گزارش تحلیلی بخشنامه جدید ارزی و لینک ثبت‌نام همایش پاییزه مؤسسه آموزشی آدان ارسال شد.", "ثبت محلی - ارسال نشده", 0, "۱۴۰۵/۰۷/۳۰");

INSERT IGNORE INTO county_branches (id, county_name, branch_manager, active_courses_count, trained_learners_count, annual_budget_rial, spent_budget_rial, key_specialty) VALUES
(1, "دفتر نمایندگی شهرستان ویژه صنعتی شمال استان", "مهندس سعید جعفری", 6, 215, 1800000000, 940000000, "قطعات صنعتی، نساجی و ایمنی کارگاه‌ها"),
(2, "دفتر نمایندگی شهرستان مرزی و گمرکی غرب استان", "دکتر لیلا نادری", 5, 178, 1500000000, 810000000, "ترخیص کالا، ترانزیت جاده‌ای و تجارت مرزی"),
(3, "دفتر نمایندگی قطب کشاورزی جنوب استان", "مهندس رضا شریفی", 4, 142, 1100000000, 530000000, "صادرات محصولات گلخانه‌ای، سردخانه و سورتینگ");

INSERT IGNORE INTO lms_learner_notes (id, user_id, lesson_id, video_timestamp, note_body) VALUES
(1, 7, 1, "14:25", "در قاعده CIF اینکوترمز ۲۰۲۰ فروشنده موظف به اخذ بیمه حداقل کلوز C است، اما در CIP بیمه کلوز A الزامی شده است."),
(2, 7, 2, "27:40", "مهلت رفع تعهد ارزی صادرکنندگان در سامانه نیما و استثنائات ماده ۴ آیین‌نامه بانک مرکزی.");

INSERT IGNORE INTO sayad_cheques (id, sayad_16digit, drawer_company, bank_name, amount_rial, due_shamsi, inquiry_color, clearance_status) VALUES
(1, "1045998877665544", "شرکت صنایع فولاد کاوه (دانش‌پذیر آدان)", "بانک ملت", 420000000, "۱۴۰۵/۰۸/۱۵", "سفید - خوش‌حساب", "در جریان وصول"),
(2, "2098112233445566", "گروه بازرگانی خشکبار زرین", "بانک سامان", 185000000, "۱۴۰۵/۰۷/۲۵", "سفید - خوش‌حساب", "وصول شده به دفترکل");

INSERT IGNORE INTO trade_doc_submissions (id, user_id, doc_type, hs_code, incoterm_rule, currency_amount, destination_port, compliance_score, audit_feedback, submitted_shamsi) VALUES
(1, 7, "Proforma Invoice (پیش‌فاکتور صادراتی)", "0802.51.00", "CIF Jebel Ali", "48,500 USD", "بندر جبل‌علی امارات", 95, "منطبق با UCP 600 — کد تعرفه پسته با پوست، بندر مقصد و ارز تسویه دقیق است.", "۱۴۰۵/۰۷/۲۸"),
(2, 6, "Certificate of Origin (گواهی مبدأ صادره از مرجع مجاز)", "6907.21.00", "FCA Bandar Abbas", "31,200 EUR", "بندر صحار عمان", 90, "تأیید بخش اسناد تجاری مؤسسه آموزشی آدان — وزن خالص و ناخالص با پکینگ‌لیست هم‌خوانی دارد.", "۱۴۰۵/۰۷/۳۰");

INSERT IGNORE INTO research_peer_reviews (id, project_id, reviewer_alias, scientific_score, applicability_score, recommendation, review_comment, reviewed_shamsi) VALUES
(1, 1, "داور ناشناس کد DR-104 (استاد اقتصاد بین‌الملل)", 91, 94, "تأیید و آزادسازی قسط دوم بودجه", "جامعه آماری واحدهای صادراتی استان کاملاً معرف است و پیشنهادهای سیاستی قابلیت طرح در شورای گفت‌وگوی دولت و بخش خصوصی را دارد.", "۱۴۰۵/۰۷/۲۷");

INSERT IGNORE INTO b2b_matchmaking_slots (id, mission_id, slot_time, table_no, iranian_company, foreign_counterpart, product_hs_focus, interpreter_lang, outcome_status) VALUES
(1, 1, "۱۰:۰۰ تا ۱۰:۳۰", "میز B2B-01", "شرکت پسته رفسنجان گستر", "Al-Noor Hypermarkets LLC (مسقط)", "پسته اکبری بسته‌بندی خرده‌فروشی (0802.52)", "عربی تجاری", "پیش‌نویس تفاهم‌نامه ۵۰ هزار دلاری"),
(2, 1, "۱۰:۳۵ تا ۱۱:۰۵", "میز B2B-04", "کارخانجات کاشی کویر استان", "Gulf Ceramic Projects (دبی)", "اسلب پرسلانی ساختمانی (6907.21)", "انگلیسی", "ارسال نمونه کانتینری");

INSERT IGNORE INTO accounting_vouchers (id, voucher_no, voucher_shamsi, group_code, kol_account, moein_account, tafsili_entity, debit_rial, credit_rial, voucher_desc) VALUES
(1, "VCH-1405-401", "۱۴۰۵/۰۷/۲۸", "۱-دارایی جاری", "۱۱۱۰-موجودی نقد و بانک", "۱۱۱۰۲-بانک ملت جاری آموزش", "تفصیلی ۹۰۰۱ - درگاه شاپرک", 420000000, 420000000, "سند دوبل تراز وصول شهریه قرارداد آموزشی صنایع فولاد (بدهکار بانک / بستانکار درآمد خدمات آموزشی)"),
(2, "VCH-1405-402", "۱۴۰۵/۰۷/۳۰", "۶-هزینه‌های عملیاتی", "۶۱۲۰-حق‌التدریس اساتید", "۶۱۲۰۱-حق‌التدریس کارگاه تخصصی", "تفصیلی ۳۰۱۲ - دکتر نیکزاد (پس از کسر ماده ۸۶)", 136000000, 136000000, "سند دوبل تراز تسویه حق‌التدریس و مالیات تکلیفی ماده ۸۶ خزانه‌داری کل");

INSERT IGNORE INTO trade_negotiation_turns (id, user_id, scenario_lang, buyer_persona, exporter_message, ai_counter_offer) VALUES
(1, 7, "انگلیسی تجاری (EN)", "مدیر خرید زنجیره فروشگاهی امارات (Al-Maya Group)", "We propose CIF Jebel Ali at $8.40/kg with 30% advance T/T and 70% against scanned Bill of Lading.", "پیشنهاد شما حرفه‌ای است؛ اما به عنوان خریدار اماراتی تقاضای تخفیف ۳٪ برای سفارش ۳ کانتینر ۲۰ فوت و پرداخت ۷۰٪ به صورت LC دیداری (Irrevocable Sight LC) تحت UCP 600 بانک امارات NBD داریم. پاسخ مذاکراتی شما چیست؟");

INSERT IGNORE INTO rd_competitors (id, name, category, website_url, city_scope, avg_hourly_rate_rial, delivery_model, key_strengths, key_weaknesses, last_crawled_at) VALUES
(1, "مؤسسه آموزش و توسعه منابع انسانی مؤسسه آموزشی آدان تهران (ITECC)", "مؤسسه آموزشی آدان مرجع", "https://itecc.tccim.ir", "تهران / آنلاین سراسری", 3450000, "حضوری و آنلاین هم‌زمان", "برند معتبر اتاق تهران، دوره‌های به‌روز رفع تعهد ارزی، NTSW و قراردادهای بین‌المللی", "تمرکز بر پایتخت، شهریه بالا برای SMEهای شهرستانی و عدم اتصال به پرونده کارت بازرگانی استان", "۱۴۰۵/۰۷/۳۰"),
(2, "مرکز آموزش بازرگانی وزارت صمت (IBTC)", "مرکز تخصصی دولتی-بازرگانی", "https://ibtc.ir/courses", "تهران / آنلاین", 2950000, "حضوری و مجازی", "پوشش دقیق کدهای عملیاتی سامانه جامع تجارت، اظهار از راه دور EPL و ابزارهای ITC", "فرمت کلاسیک‌تر و نبود زنجیره خودکار منتورینگ و کلینیک صنعتی", "۱۴۰۵/۰۷/۳۰"),
(3, "سازمان مدیریت صنعتی (IMI)", "مدرسه عالی مدیریت", "https://imiesf.org", "مراکز استان‌ها", 3150000, "حضوری کارگاهی بلندمدت", "دوره‌های جامع ۹۸ ساعته مهارت‌های بازرگانی بین‌الملل و شبکه اساتید باسابقه", "طولانی بودن دوره (۹۸ ساعت) برای مدیران پرمشغله صادراتی", "۱۴۰۵/۰۷/۲۹"),
(4, "مجتمع فنی تهران — دپارتمان بازرگانی (MFT)", "مؤسسه آموزشی خصوصی", "https://mftmirdamad.com", "سراسری", 3650000, "حضوری و آنلاین", "بسته جامع ITP و تبلیغات گسترده در فضای وب", "شهریه سنگین (۲۱۰ میلیون ریال) و عدم تمرکز اختصاصی بر فراگیران آدان", "۱۴۰۵/۰۷/۲۹"),
(5, "آکادمی مرجع بین‌المللی ICC (ICC Academy)", "مرجع بین‌المللی پاریس/سنگاپور", "https://icc.academy", "بین‌المللی (آنلاین)", 9800000, "تمام‌الکترونیکی انگلیسی", "گواهی جهانی GTCP و استاندارد مرجع Incoterms 2020 و UCP 600", "زبان صرفاً انگلیسی و دشواری پرداخت ارزی برای بنگاه‌های داخلی", "۱۴۰۵/۰۷/۲۸");

INSERT IGNORE INTO rd_competitor_courses (id, competitor_id, course_title, duration_hours, tuition_rial, delivery_format, source_url, our_catalog_status, captured_shamsi) VALUES
(1, 1, "جامع ثبت سفارش واردات در سامانه NTSW، تخصیص ارز نیمایی و اظهار از راه دور گمرک (EPL)", 32, 109000000, "آنلاین تعاملی", "https://itecc.ir/", "شکاف طلایی کاتالوگ (اقیانوس آبی)", "۱۴۰۵/۰۷/۳۰"),
(2, 2, "شناسایی کالاها و بازارهای برتر صادراتی ایران با هوش مصنوعی و ابزارهای ITC TradeMap", 12, 19000000, "آنلاین کاربردی", "https://ibtc.ir/courses", "شکاف طلایی کاتالوگ (اقیانوس آبی)", "۱۴۰۵/۰۷/۳۰"),
(3, 1, "رویه صادرات قطعی کالا و قوانین برگشت و رفع تعهد ارز حاصل از صادرات", 8, 19000000, "حضوری / آنلاین", "https://itecc.ir/", "شکاف طلایی کاتالوگ (اقیانوس آبی)", "۱۴۰۵/۰۷/۳۰"),
(4, 2, "سامانه جامع تجارت داخلی، انبارها و رهگیری کد نقش", 36, 119000000, "حضوری", "https://ibtc.ir/courses", "شکاف طلایی کاتالوگ (اقیانوس آبی)", "۱۴۰۵/۰۷/۳۰"),
(5, 1, "تهیه و تنظیم قراردادهای تجاری بین‌المللی (منطبق با کنوانسیون وین CISG)", 24, 74000000, "مجازی", "https://itecc.tccim.ir/", "پوشش نسبی در کاتالوگ فعلی", "۱۴۰۵/۰۷/۲۹"),
(6, 4, "دوره جامع بازرگانی بین‌الملل (بسته ITP)", 60, 210000000, "حضوری / آنلاین", "https://mftmirdamad.com/", "پوشش کامل با قیمت رقابتی‌تر در اتاق", "۱۴۰۵/۰۷/۲۹"),
(7, 2, "اصول حرفه‌ای مذاکره تجاری و غرفه‌داری در نمایشگاه‌های بین‌المللی", 12, 33000000, "حضوری کارگاهی", "https://ibtc.ir/courses", "شکاف طلایی کاتالوگ (اقیانوس آبی)", "۱۴۰۵/۰۷/۲۸");

INSERT IGNORE INTO rd_web_signals (id, keyword_query, signal_title, source_engine, source_url, demand_score, competition_saturation, opportunity_index, catalog_gap_status, discovered_shamsi) VALUES
(1, "ثبت سفارش NTSW و رفع تعهد ارزی صادرات", "جهش تقاضای مدیران بازرگانی برای کارگاه عملی سامانه جامع تجارت (NTSW)، تالار ارز تجاری و اظهار EPL گمرک", "کاوشگر زنده وب فارسی", "https://itecc.ir/", 96, 28, 92, "شکاف طلایی کاتالوگ (پیشنهاد فوری ساخت)", "۱۴۰۵/۰۷/۳۰"),
(2, "هوش مصنوعی در صادرات و بازارشناسی ITC", "ترند اول آموزش‌های نوین مؤسسات آموزشی: کاربرد هوش مصنوعی و TradeMap در کشف خریداران خارجی واقعی", "کاوشگر زنده وب فارسی", "https://ibtc.ir/courses", 94, 22, 94, "شکاف طلایی کاتالوگ (پیشنهاد فوری ساخت)", "۱۴۰۵/۰۷/۳۰"),
(3, "مالیات کربن مرزی اتحادیه اروپا CBAM صنایع فولاد و پتروشیمی", "الزام جدید گزارش‌دهی کربن مرزی اروپا (EU CBAM) برای صادرکنندگان فولاد، سیمان، آلومینیوم و کود شیمیایی", "Google News RSS Global", "https://taxation-customs.ec.europa.eu/carbon-border-adjustment-mechanism_en", 91, 15, 95, "اقیانوس آبی مطلق در استان (بدون رقیب)", "۱۴۰۵/۰۷/۳۰"),
(4, "تهاتر ارزی، تسویه درهمی/یوانی و قراردادهای تجارت متقابل", "نیاز حاد صادرکنندگان به راهکارهای حقوقی-مالی تسویه بین‌المللی و فین‌تک‌های فرامرزی در شرایط تحریم", "کاوشگر زنده وب فارسی", "https://news.tccim.ir/", 93, 30, 89, "شکاف طلایی کاتالوگ (پیشنهاد فوری ساخت)", "۱۴۰۵/۰۷/۲۹"),
(5, "موافقت‌نامه تجارت آزاد ایران و اتحادیه اقتصادی اوراسیا (EAEU)", "صفر شدن تعرفه گمرکی ۸۷٪ کالاها با روسیه، قزاقستان و ارمنستان — جهش تقاضای کارگاه صادرات به اوراسیا", "کاوشگر زنده وب فارسی", "https://ibtc.ir/", 89, 34, 83, "پوشش نسبی — نیازمند نسخه پیشرفته عملیاتی", "۱۴۰۵/۰۷/۲۹");

INSERT IGNORE INTO rd_course_proposals (id, proposal_code, proposed_title, target_audience, recommended_hours, competitor_avg_rial, suggested_tuition_rial, breakeven_learners, projected_net_rial, strategic_rationale, syllabus_outline, ai_confidence_score, status, created_shamsi) VALUES
(1, "RD-1405-101", "کارگاه جامع عملیاتی سامانه جامع تجارت (NTSW)، اظهار EPL گمرکی و رفع تعهد ارزی صادرکنندگان", "مدیران بازرگانی، ترخیص‌کاران و متقاضیان کارت بازرگانی استان", 24, 109000000, 68000000, 8, 896000000, "در رصد زنده رقبا، اتاق تهران و IBTC این عنوان را بین ۱۰۹ تا ۱۱۹ میلیون ریال عرضه می‌کنند در حالی که در کاتالوگ فعلی اتاق استان خالی است. عرضه ۲۴ ساعته کارگاهی با شهریه رقابتی ۶۸ میلیون ریال (۳۷٪ مزیت قیمتی برای فراگیران آدان) بالاترین نرخ تکمیل ظرفیت را ایجاد می‌کند.", "۱. معماری سامانه NTSW و ثبت سفارش | ۲. تخصیص و نیمایی/تالار ارز تجاری | ۳. تشریفات اظهار از راه دور EPL | ۴. پیمانسپاری و رفع تعهد ارزی صادراتی | ۵. مدیریت ریسک جرایم گمرکی | ۶. کارگاه عملی روی پرونده واقعی", 96, "آماده طرح در شورای R&D", "۱۴۰۵/۰۷/۳۰"),
(2, "RD-1405-102", "هوش مصنوعی عملیاتی در صادرات: شکار خریداران خارجی با TradeMap، تحلیل داده و اتوماسیون مذاکره", "مدیران صادرات، واحدهای بازاریابی بین‌الملل و شرکت‌های دانش‌بنیان", 16, 48000000, 39000000, 7, 512000000, "ترند شماره ۱ جست‌وجوی وب در ۱۴۰۵ با کمترین اشباع رقبا (۲۲٪). ترکیب ابزارهای ITC TradeMap با پرامپت‌نویسی تجاری AI مزیت منحصربه‌فردی نسبت به دوره‌های تئوری رقبا ایجاد می‌کند.", "۱. استخراج تقاضای جهانی با ITC TradeMap و MacMap | ۲. اعتبارسنجی خریداران خارجی با OSINT و AI | ۳. تولید کاتالوگ و پروفرمای هوشمند چندزبانه | ۴. اتوماسیون مکاتبات و لینکدین B2B | ۵. شبیه‌ساز مذاکره تجاری با AI | ۶. پروژه عملی صادرات محصول کارخانه عضو", 95, "آماده طرح در شورای R&D", "۱۴۰۵/۰۷/۳۰"),
(3, "RD-1405-103", "استاندارد کربن مرزی اتحادیه اروپا (EU CBAM) و گزارش‌دهی ردپای کربن صنایع صادراتی استان", "مدیران عامل، مدیران انرژی/کیفیت و صادرات صنایع فولاد، سیمان، کاشی و پتروشیمی", 16, 89000000, 64000000, 6, 740000000, "اقیانوس آبی مطلق (اشباع رقبا زیر ۱۵٪) با حاشیه سود B2B بسیار بالا برای قراردادهای سازمانی کارخانجات بزرگ استان.", "۱. الزامات قانونی مقررات نهایی CBAM در ۲۰۲۶ | ۲. محاسبه انتشار مستقیم و غیرمستقیم (Scope 1 & 2) | ۳. تکمیل گزارش فصلی XML برای خریدار اروپایی | ۴. ممیزی و گواهی کربن | ۵. استراتژی کاهش جریمه کربنی | ۶. مطالعه موردی صنایع معدنی و فلزی", 94, "آماده طرح در شورای R&D", "۱۴۰۵/۰۷/۲۹");

INSERT IGNORE INTO standard_test_results (id, report_code, user_id, test_code, test_title, result_badge, score_pct, interpretation_text, recommended_course, dimensions_json, completed_shamsi) VALUES
(1, "STR-1405-901", 7, "MBTI", "تیپ‌شناسی شخصیت مایرز-بریگز (MBTI)", "ENTJ — فرمانده و استراتژیست سازمانی", 88, "گرایش بارز به تصمیم‌گیری تحلیلی، برنامه‌ریزی کلان و هدایت مذاکرات بین‌المللی؛ پیشنهاد تقویت شنیدن فعال در جلسات تیمی.", "برنامه عالی توسعه رهبری مدیران صنایع", '{"برون‌گرایی (E)":82,"شهود راهبردی (N)":78,"منطق تحلیلی (T)":91,"ساختارمندی (J)":86}', "۱۴۰۵/۰۷/۳۰"),
(2, "STR-1405-902", 8, "CEFR_EN", "تعیین سطح استاندارد زبان انگلیسی (CEFR A1–C2)", "سطح C1 Advanced (پیشرفته تجاری)", 86, "تسلط عالی بر ساختارهای پیشرفته، درک متون حقوقی-تجاری و مکاتبات بین‌المللی؛ آماده ورود مستقیم به کارگاه قراردادهای انگلیسی.", "تنظیم قراردادهای تجاری بین‌المللی به زبان انگلیسی", '{"گرامر پیشرفته":90,"واژگان آکادمیک و تجاری":85,"درک مطلب تحلیلی":84,"کاربرد اصطلاحی":85}', "۱۴۰۵/۰۷/۳۰"),
(3, "STR-1405-903", 7, "HOLLAND", "رغبت‌سنج و استعدادیابی شغلی جان هالند (RIASEC)", "کد شغلی ECS — مدیریت بازرگانی، مذاکره و مالی", 91, "بالاترین تناسب با سمت‌های مدیر صادرات، توسعه بازار بین‌الملل، مدیریت فروش سازمانی B2B و تحلیلگر بازرگانی.", "دوره جامع مدیریت صادرات و اینکوترمز ۲۰۲۰", '{"متهور/مدیر (E)":94,"قراردادی/مالی (C)":88,"اجتماعی/مذاکره (S)":82,"جست‌وجوگر (I)":74}', "۱۴۰۵/۰۷/۲۹");

INSERT IGNORE INTO voice_command_logs (id, user_id, spoken_text, detected_intent, target_route, action_summary, spoken_response, created_shamsi) VALUES
(1, 1, "گزارش کامل مالی و وضعیت تراز حسابداری چهار سطحی رو بگو", "LIVE_REPORT", "finance", "گزارش زنده دفترکل، چک صیادی و اسناد دوبل استخراج شد", "گزارش زنده مالی آماده شد: جمع درآمد ثبت‌شده دفترکل بیش از چهار میلیارد ریال و اختلاف تراز اسناد چهارسطحی دقیقاً صفر ریال است.", "۱۴۰۵/۰۷/۳۰"),
(2, 1, "برو به رادار بازار و تحلیل رقبا", "NAVIGATION", "market-radar", "هدایت صوتی به بخش تخصصی (رادار هوشمند بازار و R&D)", "در حال انتقال شما به ماژول سی و نهم، رادار هوشمند بازار آموزش و کالبدشکافی زنده رقبا.", "۱۴۰۵/۰۷/۳۰"),
(3, 1, "آزمون شخصیت شناسی MBTI رو اجرا کن و کارنامه بده", "EXECUTE_ACTION", "exams", "صدور خودکار کارنامه رسمی MBTI در جدول standard_test_results", "آزمون شخصیت‌شناسی مایرز بریگز اجرا و کارنامه تحلیلی تیپ شخصیتی در پرونده آموزشی ثبت شد.", "۱۴۰۵/۰۷/۳۰");

INSERT IGNORE INTO erp_automation_rules (id, rule_code, rule_title, source_module, trigger_condition, target_modules, autonomous_action, executions_count, last_triggered_shamsi, is_active) VALUES
(1, "AUTO-ERP-01", "تجویز خودکار بسته آموزشی و یارانه پس از عارضه‌یابی کلینیک صنعت", "کلینیک عارضه‌یابی (۳۱)", "امتیاز آمادگی صادرات کارخانه کمتر از ۶۵٪", "CRM (۱۰) + یارانه‌ها (۳۳) + TMS (۱)", "ایجاد سرنخ سازمانی داغ + اختصاص بن ۳۰٪ یارانه SME + ثبت پیش‌فاکتور گروهی", 14, "۱۴۰۵/۰۷/۳۰", 1),
(2, "AUTO-ERP-02", "گشایش خودکار پرونده اقدام اصلاحی ایزو (CAPA) در افت کیفیت دوره", "ارزشیابی کرکپاتریک (۸)", "افت شاخص رضایت یا یادگیری زیر ۷۸ امتیاز", "تضمین کیفیت ایزو (۳۰) + BPMS (۲۲)", "ثبت عدم انطباق ایزو ۲۱۰۰۱ + بازنگری طرح درس استاد در کارتابل BPMS", 5, "۱۴۰۵/۰۷/۲۹", 1),
(3, "AUTO-ERP-03", "هشدار پیش‌بینانه ۹۰ روزه انقضای کارت بازرگانی و ثبت‌نام تمدید", "کارت بازرگانی (۲۵)", "باقی‌ماندن کمتر از ۶۰ روز تا انقضای اعتبار کارت", "پیام‌رسان بومی (۳۷) + پرتال اعضا (۹)", "ارسال اخطار رسمی در بله/ایتا و پیامک + رزرو خودکار کلاس الزامی تمدید", 29, "۱۴۰۵/۰۷/۳۰", 1),
(4, "AUTO-ERP-04", "اتصال خودکار فارغ‌التحصیل ممتاز به بازارگاه اشتغال و کنسرسیوم", "آزمون‌ها و گواهی (۱۵)", "کسب نمره بالای ۸۵ + تکمیل کارنامه MBTI/CEFR", "کاریابی صنعتی (۳۲) + گذرنامه مهارتی", "به‌روزرسانی گذرنامه مهارتی + معرفی خودکار به ۳ کارخانه دارای موقعیت باز", 21, "۱۴۰۵/۰۷/۳۰", 1),
(5, "AUTO-ERP-05", "سپر محافظ ریسک نقدینگی، سررسید چک صیادی و نقطه سربه‌سر کلاس", "امور مالی و صیاد (۷)", "تکمیل ظرفیت کمتر از ۷۰٪ در ۷۲ ساعت مانده یا سررسید چک", "هوش بازاریابی + خزانه‌داری + CRM", "فعال‌سازی کمپین تخفیف لحظه آخری ۲۰٪ برای تکمیل صندلی خالی + هشدار خزانه", 9, "۱۴۰۵/۰۷/۳۰", 1);

INSERT IGNORE INTO erp_smart_alerts (id, alert_code, severity, module_route, alert_title, ai_diagnosis, prescribed_action, financial_impact_rial, status) VALUES
(1, "ALT-1405-01", "critical", "crm", "خطر ریزش ۲ بنگاه بزرگ عضو طلایی (احتمال ریزش ۷۴٪ در مدل RFM)", "شرکت صنایع غذایی بهاران و نساجی کویر بیش از ۹۵ روز ثبت‌نام جدید نداشته‌اند و ۴۲٪ سهمیه قرارداد سالانه‌شان بدون استفاده مانده است.", "ارسال بسته اختصاصی کارگاه EU CBAM و اینکوترمز با ۱۵٪ مشوق تمدید قرارداد B2B", 640000000, "open"),
(2, "ALT-1405-02", "opportunity", "market-radar", "شکاف درآمدی ۸۹۶ میلیون ریالی در دوره عملیاتی NTSW و اظهار EPL", " تقاضای جست‌وجوی استان ۹۶ از ۱۰۰ است اما ظرفیت دوره عملیاتی سامانه جامع تجارت در تقویم آبان تکمیل شده و لیست انتظار ۱۸ نفره شکل گرفته است.", "افتتاح خودکار گروه دوم دوره در تالار خلیج فارس (چهارشنبه‌ها ۱۴ تا ۱۸)", 896000000, "open"),
(3, "ALT-1405-03", "warning", "finance", "نزدیک‌شدن سررسید چک صیادی ۲۴۰ میلیون ریالی در خزانه آموزش", "یک فقره چک صیادی بابت قسط دوم قرارداد آموزشی سازمانی طی ۵ روز آینده سررسید می‌شود.", "ارسال یادآور خودکار خزانه‌داری و آماده‌سازی سند تسویه ۴ سطحی", 240000000, "open"),
(4, "ALT-1405-04", "warning", "lms", "هشدار زودهنگام افت پیشرفت ۳ فراگیر کارت بازرگانی در محتوای SCORM", "نرخ تماشای ویدئو و تعامل ۳ متقاضی در هفته جاری زیر ۴۰٪ بوده و احتمال مردودی در آزمون پایانی ۶۸٪ برآورد می‌شود.", "ارسال میکروجزوه جبرانی هوشمند + یادآور پشتیبان آموزشی در پرتال", 135000000, "open");

INSERT IGNORE INTO crm_rfm_scores (id, org_id, org_name, recency_days, frequency_count, monetary_rial, rfm_composite, segment_label, churn_probability_pct, next_best_course, prescribed_discount_pct, updated_shamsi) VALUES
(1, 1, "مجتمع فولاد و ذوب‌آهن زاگرس", 9, 8, 920000000, 96, "قهرمان وفادار استراتژیک (Champions)", 6, "استاندارد کربن مرزی اتحادیه اروپا (EU CBAM) ویژه صنایع فلزی", 15, "۱۴۰۵/۰۷/۳۰"),
(2, 2, "گروه صنعتی پسته و خشکبار زرین‌صادر", 21, 5, 540000000, 84, "مشتری وفادار صادراتی (Loyal)", 14, "شکار خریداران خارجی با هوش مصنوعی و ITC TradeMap", 10, "۱۴۰۵/۰۷/۳۰"),
(3, 3, "شرکت پتروشیمی و پلیمر تابان", 58, 3, 390000000, 62, "نیازمند مراقبت و فعال‌سازی سهمیه", 43, "قراردادهای تجارت متقابل، تهاتر ارزی و تسویه بین‌المللی", 15, "۱۴۰۵/۰۷/۳۰"),
(4, 4, "صنایع غذایی و لبنی بهاران استان", 104, 2, 210000000, 39, "در معرض ریزش فوری (At-Risk VIP)", 74, "کارگاه عملیاتی موافقت‌نامه تجارت آزاد اوراسیا (EAEU)", 25, "۱۴۰۵/۰۷/۳۰");

INSERT IGNORE INTO ai_schedule_optimizations (id, course_code, course_title, instructor_name, classroom_name, assigned_slot, predicted_learners, room_capacity, utilization_pct, conflict_status, generated_shamsi) VALUES
(1, "TRD-101", "جامع اینکوترمز ۲۰۲۰، اعتبارات اسنادی UCP600 و قراردادهای بین‌المللی", "دکتر کامران فرهمند", "تالار بین‌المللی خلیج فارس", "شنبه‌ها و دوشنبه‌ها — ۱۴:۰۰ تا ۱۸:۰۰", 28, 30, 93, "بدون تداخل استاد و سالن (بهینه ۹۳٪)", "۱۴۰۵/۰۷/۳۰"),
(2, "CC-201", "بسته الزامی متقاضیان صدور و تمدید کارت بازرگانی (نسخه ۱۴۰۵)", "مهندس الهام شریفی", "سایت کامپیوتر و شبیه‌ساز گمرک", "یکشنبه‌ها و سه‌شنبه‌ها — ۰۸:۳۰ تا ۱۲:۳۰", 23, 25, 92, "تطبیق ۱۰۰٪ با تجهیزات کارگاهی NTSW", "۱۴۰۵/۰۷/۳۰"),
(3, "FIN-305", "سامانه مؤدیان، پایانه‌های فروشگاهی و دادرسی مالیاتی صنایع", "دکتر بهزاد نوری", "کلاس هوشمند امیرکبیر", "چهارشنبه‌ها — ۱۳:۳۰ تا ۱۹:۳۰", 19, 20, 95, "حداکثر بهره‌وری صندلی (۹۵٪)", "۱۴۰۵/۰۷/۳۰");

INSERT IGNORE INTO ai_skill_job_matches (id, candidate_name, psychometric_badge, target_company, job_role_title, match_score_pct, verified_skills, recommended_gap_course, status, matched_shamsi) VALUES
(1, "مهندس آرش کاظمی", "ENTJ | زبان تجاری C1", "مجتمع فولاد و ذوب‌آهن زاگرس", "مدیر قراردادها و صادرات بازار اوراسیا", 95, "گواهی اینکوترمز ۲۰۲۰ + نمره ۹۲ آزمون UCP600 + تیپ فرمانده ENTJ", "گزارش‌دهی کربن مرزی اروپا (EU CBAM)", "معرفی‌شده جهت مصاحبه نهایی", "۱۴۰۵/۰۷/۳۰"),
(2, "سارا محمدی‌پور", "ECS هالند | DISC: نفوذگر (I)", "گروه صنعتی خشکبار زرین‌صادر", "کارشناس ارشد مذاکرات بین‌الملل و نمایشگاه‌ها", 91, "تسلط انگلیسی C1 + کارنامه برتر شبیه‌ساز مذاکره تجاری", "حقوق داوری مرجع بین‌المللی ICC ICC", "تأیید اولیه کارفرما", "۱۴۰۵/۰۷/۳۰"),
(3, "امیرحسین رضایی", "ISTJ | دقت تحلیلی ۹۴٪", "شرکت پتروشیمی و پلیمر تابان", "مسئول ثبت سفارش NTSW، اظهار EPL و رفع تعهد ارزی", 89, "گواهی الزامی کارت بازرگانی + تسلط کامل محاسبه حقوق گمرکی", "کارگاه پیشرفته تهاتر ارزی صادراتی", "آماده معرفی فوری", "۱۴۰۵/۰۷/۳۰");

INSERT IGNORE INTO factory_prescriptions (id, rx_code, factory_name, sector, prod_score, energy_cbam_score, export_fx_score, working_cap_score, b2b_brand_score, hr_skill_score, ai_digital_score, overall_health_idx, primary_bottleneck, roadmap_180d, assigned_consultant, approved_subsidy_pct, created_shamsi) VALUES
(1, "RX-IND-401", "مجتمع فولاد و نورد زاگرس", "فلزات اساسی و آلیاژی", 84, 42, 71, 76, 65, 70, 58, 67, "عدم انطباق گزارش ردپای کربن با مقررات مرزی اتحادیه اروپا (EU CBAM)", "ماه ۱-۲: ممیزی انرژی و آموزش استاندارد Scope 1&2 | ماه ۳-۴: استقرار سامانه گزارش XML کربن | ماه ۵-۶: اخذ گواهی سبز صادراتی", "دکتر فرهاد سلیمانی (مشاور ارشد انرژی و CBAM)", 35, "۱۴۰۵/۰۷/۳۰"),
(2, "RX-IND-402", "کشت و صنعت پسته و زعفران زرین", "کشاورزی و صنایع غذایی صادراتی", 79, 74, 58, 66, 46, 62, 49, 62, "ضعف شدید در بسته‌بندی خرده‌فروشی چندزبانه و کانال فروش مستقیم B2B (خام‌فروشی)", "ماه ۱-۲: کارگاه طراحی بسته‌بندی استاندارد اروپا و خلیج فارس | ماه ۳-۴: راه‌اندازی شکار خریدار با AI و TradeMap | ماه ۵-۶: حضور در میز B2B مسقط و دبی", "مهندس نازنین کاوه (مشاور برندینگ صادراتی)", 40, "۱۴۰۵/۰۷/۳۰");

INSERT IGNORE INTO adaptive_cat_sessions (id, session_code, candidate_name, domain_title, questions_administered, final_difficulty_level, theta_ability, cefr_or_mastery_band, tab_switches_detected, collusion_similarity_pct, integrity_score, completed_shamsi) VALUES
(1, "CAT-1405-71", "مهندس آرش کاظمی", "آزمون تطبیقی حقوق تجارت بین‌الملل و اینکوترمز ۲۰۲۰", 6, 5, 2.35, "سطح ۵ خبره ارشد (Master — Top 5%)", 0, 3, 99, "۱۴۰۵/۰۷/۳۰"),
(2, "CAT-1405-72", "نگین شریعتی", "آزمون تطبیقی تعیین سطح انگلیسی تجاری (Adaptive BEC)", 6, 4, 1.62, "سطح C1 Advanced (مذاکره‌کننده مستقل)", 1, 6, 94, "۱۴۰۵/۰۷/۳۰"),
(3, "CAT-1405-73", "پویا مرادی", "آزمون جامع مقررات گمرکی و سامانه جامع تجارت", 6, 2, -0.45, "سطح B1 کاربردی پایه — نیازمند کارگاه عملی EPL", 4, 41, 61, "۱۴۰۵/۰۷/۲۹");

INSERT IGNORE INTO ocr_financial_scans (id, scan_code, doc_type, raw_extracted_text, detected_amount_rial, detected_sayad_or_ref, detected_iban, checksum_verified, moadian_vat_status, booked_voucher_no, scanned_shamsi) VALUES
(1, "OCR-9501", "برگه چک صیادی بنفش", "چک صیادی شناسه 1094827165039281 مبلغ 340,000,000 ریال در وجه مؤسسه آموزشی آدان شبا IR160170000000319845120001 بانک ملی", 340000000, "1094827165039281", "IR160170000000319845120001", 1, "معاف از ارزش افزوده (بند ۱۲ ماده ۱۲ آموزش)", "VCH-OCR-881", "۱۴۰۵/۰۷/۳۰"),
(2, "OCR-9502", "رسید حواله پایا / ساتنا سازمانی", "واریز پایا مبلغ 185,000,000 ریال کد پیگیری 994827162 بابت شهریه دوره جامع صادرات شرکت پتروشیمی تابان", 185000000, "REF-994827162", "IR062960000000100324200001", 1, "الگوی اول صورت‌حساب الکترونیکی مؤدیان تأیید شد", "VCH-OCR-882", "۱۴۰۵/۰۷/۳۰");

INSERT IGNORE INTO export_consortium_groups (id, consortium_code, consortium_title, target_market, hs_code_cluster, lead_producer_org, packaging_logistics_org, trading_house_org, synergy_score_pct, annual_target_usd, status, created_shamsi) VALUES
(1, "CNS-EAEU-01", "کنسرسیوم صادراتی خشکبار و فرآورده‌های غذایی ممتاز به اتحادیه اوراسیا", "روسیه و قزاقستان (تعرفه صفر EAEU)", "HS 0802 / 2008 (پسته، کشمش و فرآورده)", "کشت و صنعت زرین‌صادر استان", "صنایع بسته‌بندی نفیس‌پک پارس", "شرکت مدیریت صادرات (EMC) دروازه خزر", 95, 2400000, "تفاهم‌نامه سه‌جانبه آماده امضا در اتاق", "۱۴۰۵/۰۷/۳۰"),
(2, "CNS-GCC-02", "کنسرسیوم مصالح ساختمانی، کاشی، سرامیک و کلینکر خلیج فارس", "عمان، امارات و عراق", "HS 6907 / 2523 (سرامیک پرسلان و سیمان)", "مجتمع کاشی و سرامیک کویر", "حمل‌ونقل بین‌المللی و کانتینری دریاپیما", "هلدینگ بازرگانی بین‌الملل پارس‌تجارت", 91, 3100000, "در حال ثبت رسمی شخصیت حقوقی کنسرسیوم", "۱۴۰۵/۰۷/۲۹");

INSERT IGNORE INTO commission_policy_briefs (id, brief_code, commission_name, recipient_authority, issue_summary, legal_citation, formal_letter_body, status, created_shamsi) VALUES
(1, "POL-1405-11", "کمیسیون توسعه صادرات غیرنفتی و گمرک", "مقام عالی وزارت صنعت، معدن و تجارت / کل گمرک ایران", "رفع ایستایی ثبت سفارش مواد اولیه واحدهای تولیدی صادرات‌محور و تمدید مهلت رفع تعهد ارزی", "استناد به مواد ۲، ۳ و ۲۴ قانون بهبود مستمر محیط کسب‌وکار و ماده ۱۲ قانون احکام دائمی", "احتراماً به پیوست جمع‌بندی کارشناسی جلسه فوق‌العاده کمیسیون توسعه صادرات مؤسسه آموزشی آدان در خصوص توقف خطوط تولید ناشی از تأخیر تخصیص ارز مواد اولیه ایفاد می‌گردد. پیشنهاد مشخص بخش خصوصی: ۱) تنفس ۹۰ روزه رفع تعهد ارزی برای صادرکنندگان خوش‌حساب تولیدی؛ ۲) ایجاد مسیر سبز گمرکی ویژه واحدهای دارای گواهی انطباق اتاق استان.", "آماده امضای مدیر مؤسسه آدان استان", "۱۴۰۵/۰۷/۳۰");

INSERT IGNORE INTO lms_adaptive_paths (id, learner_name, course_title, lesson_timestamp, learner_question, ai_timestamp_answer, quiz_diagnostic_pct, injected_remedial_micro, spaced_repetition_cards, created_shamsi) VALUES
(1, "امیرحسین رضایی", "جامع اینکوترمز ۲۰۲۰ و اعتبارات اسنادی", "۱۴:۲۰", "تفاوت دقیق انتقال ریسک در FOB و FCA برای حمل کانتینری چیست؟", "در دقیقه ۱۴:۲۰ استاد توضیح می‌دهند که در حمل کانتینری نباید از FOB استفاده شود چون تحویل در ترمینال قبل از عرشه کشتی انجام می‌شود؛ لذا FCA (تحویل در پایانه کانتینری با بارنامه On-Board) ریسک آسیب در محوطه بندر را از دوش صادرکننده برمی‌دارد.", 64, "میکروویدئوی تقویتی ۶ دقیقه‌ای: خطاهای رایج ترم FOB در کانتینر + ۵ فلش‌کارت مرور لایتنر", 5, "۱۴۰۵/۰۷/۳۰"),
(2, "نگین شریعتی", "آموزش الزامی کارت بازرگانی و سامانه NTSW", "۰۸:۵۵", "مهلت قانونی ایفای تعهد ارزی صادراتی به چه صورت محاسبه می‌شود؟", "مطابق بخشنامه بانک مرکزی که در دقیقه ۰۸:۵۵ تشریح شد، صادرکنندگان مکلف‌اند ظرف مهلت مقرر از تاریخ کوتاژ صادراتی نسبت به عرضه ارز در سامانه نیما/مرکز مبادله یا واردات در مقابل صادرات اقدام نمایند.", 88, "تسلط کامل — بازگشایی مستقیم سناریوی پیشرفته اظهار EPL", 4, "۱۴۰۵/۰۷/۳۰");

INSERT IGNORE INTO trade_contract_redlines (id, audit_code, contract_title, counterparty_country, submitted_clause, safety_score_pct, detected_traps, icc_protective_rewrite, audited_shamsi) VALUES
(1, "RED-1405-01", "قرارداد فروش ۴۰۰ تن پسته صادراتی (CIF Dubai)", "امارات متحده عربی", "Payment 100% Open Account 90 days after arrival; Buyer courts have exclusive jurisdiction; Delivery CIF Jebel Ali without edition year.", 38, "۳ تله حقوقی خطرناک: ۱) پرداخت ۱۰۰٪ حساب باز بدون تضمین بانکی | ۲) صلاحیت انحصاری دادگاه کشور خریدار | ۳) عدم قید ویرایش Incoterms 2020", "1) Payment: 30% Advance T/T + 70% Irrevocable Confirmed Sight L/C subject to UCP 600. 2) Delivery: CIF Jebel Ali Port (Incoterms® 2020). 3) Dispute Resolution: ICC Arbitration Rules (Seat: Istanbul/Tehran), English language.", "۱۴۰۵/۰۷/۳۰"),
(2, "RED-1405-02", "قرارداد تأمین کاشی پرسلان ساختمانی (FCA Factory)", "قزاقستان (اوراسیا)", "Seller pays all destination customs delays and unlimited penalty of 2% per day without cap.", 46, "۲ تله پرریسک: ۱) جریمه تأخیر روزانه ۲٪ بدون سقف (Uncapped Liquidated Damages) | ۲) تحمیل ریسک گمرک مقصد به فروشنده در ترم FCA", "Liquidated damages for delay solely attributable to Seller shall be 0.5% per completed week of delay up to a maximum aggregate cap of 5% of delayed shipment value (ICC Model Clause).", "۱۴۰۵/۰۷/۲۹");

INSERT IGNORE INTO instructor_impact_scores (id, instructor_name, kirkpatrick_avg, exam_pass_rate_pct, repeat_retention_pct, sla_punctuality_pct, composite_impact_score, academic_tier_badge, suggested_hourly_rial, evaluated_shamsi) VALUES
(1, "دکتر کامران فرهمند", 4.92, 95, 89, 98, 96, "استاد ممتاز الف-ویژه (رتبه ۱ مرجعیت)", 8500000, "۱۴۰۵/۰۷/۳۰"),
(2, "مهندس الهام شریفی", 4.81, 91, 84, 96, 92, "استاد ممتاز الف (کارگاه‌های عملی NTSW)", 7200000, "۱۴۰۵/۰۷/۳۰"),
(3, "دکتر بهزاد نوری", 4.68, 88, 79, 94, 88, "استاد ارشد الف (مالیات و مؤدیان)", 6400000, "۱۴۰۵/۰۷/۳۰");

INSERT IGNORE INTO bpms_process_mining (id, stage_code, department_stage, active_cases_count, avg_dwell_hours, sla_target_hours, bottleneck_severity, auto_escalation_rule, mined_shamsi) VALUES
(1, "STG-ADM-01", "پذیرش و کنترل مدارک هویتی / کد ملی متقاضی", 19, 2.4, 8, "سبز — بسیار سریع (۳۰٪ سقف SLA)", "تأیید خودکار آنی در صورت صحت کنترل رقم کد ملی و شبا", "۱۴۰۵/۰۷/۳۰"),
(2, "STG-FIN-02", "تأیید خزانه‌داری، استعلام چک صیادی و صدور فاکتور", 14, 18.6, 12, "بحرانی — گلوگاه اصلی (+۶.۶ ساعت تأخیر SLA)", "ارجاع خودکار به مدیر مالی پس از ۱۲ ساعت + همگام‌سازی خودکار OCR", "۱۴۰۵/۰۷/۳۰"),
(3, "STG-EDU-03", "ممیزی حضور ۸۰٪، نمره آزمون ۷۰ و صدور گواهی QR", 22, 1.2, 6, "سبز — تمام‌خودکار (زنجیره BPMS)", "صدور آنی گواهی دیجیتال بدون توقف انسانی پس از قبولی آزمون", "۱۴۰۵/۰۷/۳۰");

INSERT IGNORE INTO county_economic_clusters (id, county_name, dominant_cluster, active_industrial_units, skill_gap_index, prescribed_mobile_workshop, recommended_budget_share_pct, projected_export_boost_usd, analyzed_shamsi) VALUES
(1, "قطب صنعتی شمال استان (شهرک صنعتی شماره ۱ و ۲)", "قطعات خودرو، ماشین‌سازی و فلزات اساسی", 310, 81, "تور کارگاهی استاندارد کربن مرزی اروپا (EU CBAM) و قراردادهای تأمین OEM", 32, 1650000, "۱۴۰۵/۰۷/۳۰"),
(2, "قطب کشاورزی و فرآوری شرق استان", "پسته، زعفران، گیاهان دارویی و صنایع تبدیلی", 195, 86, "کلینیک سیار بسته‌بندی خرده‌فروشی صادراتی، کد بهداشتی و فروش در اوراسیا", 28, 1420000, "۱۴۰۵/۰۷/۳۰"),
(3, "قطب معدنی و سرامیک جنوب استان", "فرآوری سنگ تزئینی، کاشی پرسلان و کانی‌های فلزی", 160, 78, "کارگاه لجستیک کانتینری، تهاتر ارزی و بازاریابی پروژه‌های عمرانی عراق و عمان", 24, 1180000, "۱۴۰۵/۰۷/۳۰");

INSERT IGNORE INTO executive_warroom_simulations (id, sim_code, ceo_participant, shock_scenario, chosen_strategy, cashflow_runway_months, export_share_retention_pct, resilience_score, board_ai_critique, simulated_shamsi) VALUES
(1, "WAR-1405-01", "مهندس بهرام رادمهر (مدیرعامل فولاد زاگرس)", "شوک جهش ۳۵٪ نرخ ارز نیمایی هم‌زمان با اعمال تعرفه کربن مرزی اروپا (EU CBAM)", "پوشش ریسک با قرارداد سلف ارزی + تغییر سبد صادراتی ۴۰٪ به بازار تعرفه‌صفر اوراسیا + ممیزی فوری انرژی", 11.4, 92, 94, "تصمیم درجه الف هیئت‌مدیره: تنوع‌بخشی جغرافیایی به اوراسیا ریسک تمرکز بازار اروپا را خنثی کرده و جریان نقدی شرکت را ۱۱.۴ ماه تضمین می‌کند.", "۱۴۰۵/۰۷/۳۰"),
(2, "WAR-1405-02", "دکتر مریم کاویانی (مدیرعامل خشکبار زرین)", "اختلال زنجیره سرد کشتیرانی و افزایش ۴۰٪ کرایه حمل دریایی کانتینری", "تغییر ترم فروش از CIF به FCA پایانه + قرارداد حمل ریلی ترکیبی کریدور شمال-جنوب", 9.2, 87, 89, "مدیریت هوشمند ریسک لجستیک: انتقال ریسک کرایه دریایی نوسانی از طریق ترم FCA حاشیه سود ناخالص دلاری را حفظ کرده است.", "۱۴۰۵/۰۷/۲۹");

INSERT IGNORE INTO sme_subsidy_allocations (id, alloc_code, sme_company_name, employees_count, export_readiness_idx, requested_subsidy_pct, ai_approved_subsidy_pct, economic_roi_multiplier, priority_rank_label, allocated_shamsi) VALUES
(1, "SUB-AI-301", "شرکت دانش‌بنیان تجهیز دقیق اسپادانا", 62, 86, 50, 45, 5.40, "اولویت اول طلایی (ضریب بازگشت اقتصادی ۵.۴ برابر)", "۱۴۰۵/۰۷/۳۰"),
(2, "SUB-AI-302", "واحد تولیدی فرآورده‌های کنجدی کویر", 38, 74, 45, 35, 4.15, "اولویت دوم (صادرات‌اول با اشتغال بالا)", "۱۴۰۵/۰۷/۳۰"),
(3, "SUB-AI-303", "کارگاه بسته‌بندی کارتن نفیس شرق", 24, 65, 40, 28, 3.20, "اولویت سوم (تکمیل‌کننده زنجیره تأمین صادراتی)", "۱۴۰۵/۰۷/۲۹");

INSERT IGNORE INTO tms_dynamic_pricing_rules (id, course_code, course_title, base_tuition_rial, seat_fill_pct, days_to_start, ai_pricing_tier, dynamic_tuition_rial, projected_revenue_gain_pct, updated_shamsi) VALUES
(1, "TRD-101", "جامع اینکوترمز ۲۰۲۰ و اعتبارات اسنادی UCP600", 52000000, 94, 4, "تقاضای اوج (Surge) — افتتاح خودکار گروه دوم بدون تخفیف", 56000000, 24, "۱۴۰۵/۰۷/۳۰"),
(2, "TAX-204", "سامانه مؤدیان و دادرسی مالیاتی صنایع", 38000000, 56, 3, "بسته تکمیل صندلی ۷۲ ساعت پایانی (B2B Last-Minute -18%)", 31160000, 19, "۱۴۰۵/۰۷/۳۰"),
(3, "AI-EXP-09", "شکار خریداران خارجی با هوش مصنوعی و TradeMap", 44000000, 32, 21, "نرخ تشویقی ثبت‌نام زودهنگام (Early-Bird -15%)", 37400000, 15, "۱۴۰۵/۰۷/۳۰");

INSERT IGNORE INTO b2b_quota_burn_alerts (id, org_name, contract_title, elapsed_year_pct, quota_used_pct, burn_status, auto_triggered_offer, monitored_shamsi) VALUES
(1, "صنایع غذایی و لبنی بهاران استان", "قرارداد سالانه آموزش مدیران میانی و صادرات", 72, 28, "بحران کم‌مصرفی سهمیه (خطر عدم تمدید سال بعد)", "ارسال خودکار دعوت‌نامه اختصاصی کارگاه عملی اوراسیا برای ۱۲ نفر بدون هزینه اضافه", "۱۴۰۵/۰۷/۳۰"),
(2, "مجتمع فولاد و ذوب‌آهن زاگرس", "قرارداد جامع توانمندسازی فنی و بازرگانی ۱۴۰۵", 65, 89, "مصرف عالی — آماده پیشنهاد الحاقیه افزایش سقف", "ارسال خودکار پیش‌نویس الحاقیه ۵۰ نفر-دوره جدید با ۱۵٪ مشوق وفاداری", "۱۴۰۵/۰۷/۳۰");

INSERT IGNORE INTO public_ai_pathfinder_leads (id, visitor_fullname, visitor_mobile, visitor_goal, industry_field, recommended_roadmap, estimated_90d_roi, synced_crm_status, captured_shamsi) VALUES
(1, "مهندس فرشاد نیک‌پی", "09123456789", "شروع اولین صادرات رسمی محصول تولیدی", "تولیدکننده شیرآلات صنعتی", "گام ۱: دوره الزامی کارت بازرگانی | گام ۲: کارگاه قیمت‌گذاری صادراتی و TradeMap | گام ۳: میز B2B عراق", "اولین پیش‌فاکتور صادراتی ظرف ۹۰ روز", "ثبت خودکار سرنخ داغ در CRM (امتیاز ۹۲)", "۱۴۰۵/۰۷/۳۰");

INSERT IGNORE INTO rag_knowledge_chunks (id, doc_code, source_authority, clause_reference, topic_keywords, chunk_text, updated_shamsi) VALUES
(1, "LAW-VAT-12", "سازمان امور مالیاتی کشور — قانون مالیات بر ارزش افزوده", "بند ۱۲ ماده ۱۲ (معافیت خدمات آموزشی)", "معافیت مالیات ارزش افزوده آموزش دوره سمینار مؤدیان فاکتور", "مطابق بند ۱۲ ماده ۱۲ قانون دائمی مالیات بر ارزش افزوده، کلیه خدمات آموزشی، پژوهشی و ورزشی دارای مجوز رسمی از مراجع ذی‌صلاح و مؤسسات آموزشی از پرداخت مالیات و عوارض ارزش افزوده معاف بوده و در سامانه مؤدیان با نرخ صفر/معاف ثبت می‌گردند.", "۱۴۰۵/۰۷/۳۰"),
(2, "LAW-BUS-2-3", "مجلس شورای اسلامی — قانون بهبود مستمر محیط کسب‌وکار", "مواد ۲، ۳ و ۵ (الزام نظرخواهی از مؤسسه آموزشی آدان)", "بخشنامه خلق الساعه گمرک بانک مرکزی صادرات کمیسیون نظرخواهی", "به موجب مواد ۲ و ۳ قانون بهبود مستمر محیط کسب‌وکار، کلیه دستگاه‌های اجرایی مکلف‌اند پیش از وضع یا تغییر هرگونه مقررات، بخشنامه و دستورالعمل مؤثر بر تولید، تجارت و سرمایه‌گذاری، نظر مشورتی کتبی مؤسسه آموزشی آدان را اخذ و در متن مصوبه لحاظ نمایند.", "۱۴۰۵/۰۷/۳۰"),
(3, "REG-CARD-80", "آیین‌نامه اجرایی صدور و تمدید کارت بازرگانی ۱۴۰۵", "ضوابط آموزشی واحد آموزش آدان ایران", "کارت بازرگانی حضور ۸۰ نمره ۷۰ صدور تمدید متقاضی", "متقاضیان صدور بار اول کارت بازرگانی حقیقی و حقوقی ملزم به گذراندن حداقل ۸۰٪ ساعات کلاس‌های آموزشی الزامی و کسب حداقل نمره قبولی ۷۰ از ۱۰۰ در آزمون جامع استاندارد مؤسسه آموزشی آدان پیش از صدور کد رهگیری تأییدیه می‌باشند.", "۱۴۰۵/۰۷/۳۰"),
(4, "ICC-INC-2020", "مرجع بین‌المللی ICC پاریس (ICC)", "مقررات رسمی Incoterms® 2020 — تفاوت CIF و CIP", "اینکوترمز بیمه کلوز A کلوز C کانتینر حمل بارنامه", "در ویرایش ۲۰۲۰ اینکوترمز، قاعده CIF صرفاً مخصوص حمل دریایی و آبراه‌های داخلی با حداقل پوشش بیمه کلوز C است؛ برای حمل کانتینری و چندوجهی باید از قاعده CIP با الزام پوشش بیمه تمام‌خطر کلوز A به نفع خریدار استفاده شود.", "۱۴۰۵/۰۷/۳۰");

INSERT IGNORE INTO verifiable_credential_blocks (id, block_height, cert_or_badge_code, holder_fullname, prev_block_hash, block_sha256_hash, w3c_standard_version, sealed_shamsi) VALUES
(1, 1001, "CERT-ADN-1405-9001", "مهندس مهرداد شریفی", "0000000000000000000000000000000000000000000000000000000000000000", "9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08", "چکیده محلی؛ استاندارد یا امضای W3C تأیید نشده", "۱۴۰۵/۰۸/۰۱"),
(2, 1002, "BADGE-TRD-ELITE-01", "مهندس مهرداد شریفی", "9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08", "4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a", "چکیده محلی؛ استاندارد یا امضای W3C تأیید نشده", "۱۴۰۵/۰۸/۰۱");

INSERT IGNORE INTO bizsim_league_rounds (id, round_code, team_name, quarter_label, export_pricing_usd, fx_hedge_ratio_pct, rnd_investment_pct, simulated_ebitda_usd, elo_rating, ai_referee_note, played_shamsi) VALUES
(1, "SIM-Q3-101", "تیم صادراتی پیشگامان فولاد زاگرس", "فصل سوم (Q3 — جهش بازار اوراسیا)", 1340.00, 75, 14, 248500, 1745, "پوشش ۷۵٪ ریسک ارزی همراه با ۱۴٪ سرمایه‌گذاری تحقیق و توسعه بالاترین سود عملیاتی دلاری را ثبت کرد.", "۱۴۰۵/۰۸/۰۱"),
(2, "SIM-Q3-102", "تیم بازرگانی خشکبار زرین پارس", "فصل سوم (Q3 — ورود به خلیج فارس)", 1190.00, 55, 11, 204000, 1680, "استراتژی نفوذ قیمتی سهم بازار امارات را ۲۲٪ افزایش داد اما پوشش ارزی نیازمند تقویت است.", "۱۴۰۵/۰۸/۰۱");

INSERT IGNORE INTO security_soc_telemetry (id, event_code, actor_username, client_ip, geo_and_device, risk_score, threat_classification, mitigation_action, detected_shamsi) VALUES
(1, "SOC-9001", "admin", "185.143.233.12", "تهران — مرورگر سازمانی تأییدشده (TLS 1.3)", 8, "نشست ایمن و مورد تأیید (Zero-Trust Verified)", "مجوز کامل دسترسی صادر شد", "۱۴۰۵/۰۸/۰۱"),
(2, "SOC-9002", "unknown_probe", "91.214.124.88", "تلاش ۶ بار رمز اشتباه در ۲۰ ثانیه — آی‌پی ناشناس", 88, "تلاش نفوذ Brute-Force روی حساب سازمانی", "مسدودسازی خودکار ۱۵ دقیقه‌ای IP و ثبت در ممیزی امنیتی", "۱۴۰۵/۰۸/۰۱");

INSERT IGNORE INTO pooyesh_stipend_claims (id, claim_code, host_company, intern_fullname, duration_months, monthly_stipend_rial, total_paid_rial, tax_credit_approved_rial, statutory_clause, created_shamsi) VALUES
(1, "POY-1405-401", "مجتمع فولاد و ذوب‌آهن زاگرس", "مهندس سارا محمدی (دانشجوی ارشد بازرگانی)", 4, 110000000, 440000000, 440000000, "ماده ۱۱ قانون جهش تولید دانش‌بنیان — ۱۰۰٪ اعتبار مالیاتی دستمزد کارآموز پویش", "۱۴۰۵/۰۸/۰۱"),
(2, "POY-1405-402", "شرکت فرآورده‌های غذایی بهاران", "امیرحسین رضایی (کارآموز لجستیک صادرات)", 3, 90000000, 270000000, 270000000, "ماده ۱۱ قانون جهش تولید دانش‌بنیان — صدور گواهی کسر از مالیات عملکرد", "۱۴۰۵/۰۸/۰۱");

INSERT IGNORE INTO ai_cv_match_interviews (id, match_code, candidate_name, target_company, target_role, verified_certs_summary, vector_similarity_pct, generated_interview_guide, matched_shamsi) VALUES
(1, "CVM-1405-701", "مهندس مهرداد شریفی", "مجتمع پتروشیمی و پلیمر استان", "کارشناس ارشد قراردادهای بین‌المللی و اعتبارات اسنادی", "گواهی جامع Incoterms 2020 + نمره ۹۴ آزمایشگاه اسناد UCP600 + سطح C1 انگلیسی تجاری", 96, "سؤال ۱: نحوه اصلاح اختلاف تاریخ حمل بارنامه با شرایط L/C در ماده ۱۴ UCP600؟ | سؤال ۲: دلیل انتخاب CIP به جای CIF در حمل کانتینری پتروشیمی؟ | سؤال ۳: مدیریت سقف خسارت تأخیر فورس‌ماژور.", "۱۴۰۵/۰۸/۰۱");

INSERT IGNORE INTO national_bus_inquiries (id, trace_code, target_system, identifier_queried, math_checksum_valid, gateway_execution_mode, response_summary, customs_duty_pct, inquired_shamsi) VALUES
(1, "LOCAL-SEED-1", "سامانه جامع تجارت (NTSW) — اتصال فعال نیست", "ذخیره نشد (حریم خصوصی)", 1, "پیش‌نمایش محلی - استعلام انجام نشده", "قالب نمونه از نظر رقم کنترل محلی معتبر است؛ هویت یا وضعیت پرونده استعلام نشده است.", NULL, "۱۴۰۵/۰۸/۰۱"),
(2, "LOCAL-SEED-2", "ثبت شرکت‌ها (SSAA) — اتصال فعال نیست", "ذخیره نشد (حریم خصوصی)", 1, "پیش‌نمایش محلی - استعلام انجام نشده", "قالب نمونه از نظر رقم کنترل محلی معتبر است؛ وضعیت ثبتی شرکت استعلام نشده است.", NULL, "۱۴۰۵/۰۸/۰۱"),
(3, "LOCAL-SEED-3", "سامانه امور گمرکی (EPL) — اتصال فعال نیست", "ذخیره نشد (حریم خصوصی)", 1, "پیش‌نمایش محلی - استعلام انجام نشده", "قالب هشت‌رقمی نمونه پذیرفته شد؛ کد تعرفه یا شرایط گمرکی استعلام نشده است.", NULL, "۱۴۰۵/۰۸/۰۱");

INSERT IGNORE INTO learner_behavior_events (id, user_id, learner_name, module_route, action_verb, dwell_seconds, scroll_depth_pct, focus_index_pct, study_hour_band, xp_awarded, created_shamsi) VALUES
(1, 7, "مهندس مهرداد شریفی", "lms", "تکمیل بی‌وقفه ویدئوی اینکوترمز + یادداشت ثانیه‌ای", 1640, 98, 96, "۲۰:۰۰ تا ۲۲:۰۰ (اوج تمرکز شبانه)", 85, "۱۴۰۵/۰۸/۰۱"),
(2, 7, "مهندس مهرداد شریفی", "trade-academy", "شبیه‌سازی نردبان قیمت صادراتی EXW→DDP", 920, 94, 93, "۱۰:۰۰ تا ۱۲:۰۰ (کارگاهی)", 60, "۱۴۰۵/۰۸/۰۱"),
(3, 6, "سارا نیک‌نژاد (نماینده فولاد زاگرس)", "exams", "تصحیح آزمون تطبیقی CAT با θ=+2.3", 1180, 100, 95, "۱۶:۰۰ تا ۱۸:۰۰ (عصرگاهی)", 120, "۱۴۰۵/۰۸/۰۱"),
(4, 1, "دکتر کیارش رادمهر", "digital-twin-bi", "بررسی بولتن صوتی و جست‌وجوی مواد قانونی RAG", 540, 91, 97, "۰۸:۰۰ تا ۱۰:۰۰ (مدیریتی صبحگاهی)", 45, "۱۴۰۵/۰۸/۰۱");

INSERT IGNORE INTO learner_dropout_predictions (id, learner_name, org_name, enrolled_course, learning_persona, engagement_score, dropout_risk_pct, last_login_days_ago, ai_intervention_status, updated_shamsi) VALUES
(1, "کامران توکلی", "صنایع غذایی و لبنی بهاران", "جامع ثبت سفارش NTSW و اظهار گمرکی EPL", "فراگیر پراکنده با خطر رهاسازی (At-Risk)", 34, 81, 13, "هشدار قرمز: ۱۳ روز عدم ورود + توقف در دقیقه ۱۸ درس دوم — آماده ارسال مداخله انگیزشی", "۱۴۰۵/۰۸/۰۱"),
(2, "نازنین فرهمند", "نساجی زرین نخ کویر", "سامانه مؤدیان و پایانه‌های فروشگاهی", "فراگیر شب‌خوان فشرده (Crammer)", 52, 63, 8, "هشدار زرد: افت تمرکز ویدئو به ۵۴٪ — پیشنهاد تبدیل درس بلند به ۳ میکروویدئوی ۶ دقیقه‌ای", "۱۴۰۵/۰۸/۰۱"),
(3, "مهندس مهرداد شریفی", "مجتمع فولاد و ذوب‌آهن زاگرس", "آکادمی جامع تجارت بین‌الملل و UCP600", "کاوشگر عمیق پروژه‌محور (Deep Mastery)", 96, 4, 0, "وضعیت طلایی: پیوستگی ۱۲ روزه — واجد شرایط معرفی به عنوان منتور همتای کارگاه", "۱۴۰۵/۰۸/۰۱"),
(4, "امیرحسین رضایی", "پتروشیمی و پلیمر استان", "قراردادهای تجاری بین‌المللی (کد ۶۵)", "عمل‌گرای تعاملی (Interactive Solver)", 88, 9, 1, "پایدار عالی: نرخ مشارکت بالا در شبیه‌سازها و بانک سؤالات", "۱۴۰۵/۰۸/۰۱");

INSERT IGNORE INTO gamification_wallets (id, user_id, learner_name, org_name, xp_points, chamber_coins, level_num, rank_title, streak_days, badges_count, updated_shamsi) VALUES
(1, 1, "دکتر کیارش رادمهر", "مدیریت کل آموزش مؤسسه آموزشی آدان", 5420, 1950, 9, "معمار ارشد زیست‌بوم تجارت", 16, 9, "۱۴۰۵/۰۸/۰۱"),
(2, 7, "مهندس مهرداد شریفی", "مجتمع فولاد و ذوب‌آهن زاگرس", 4890, 1640, 8, "سفیر طلایی صادرات استان", 12, 8, "۱۴۰۵/۰۸/۰۱"),
(3, 6, "سارا نیک‌نژاد", "مجتمع فولاد و ذوب‌آهن زاگرس", 4150, 1280, 7, "استراتژیست قراردادهای B2B", 9, 6, "۱۴۰۵/۰۸/۰۱"),
(4, 2, "مهندس پگاه کاظمی", "پتروشیمی و پلیمر استان", 3680, 1090, 6, "متخصص ارشد گمرک و لجستیک", 8, 5, "۱۴۰۵/۰۸/۰۱"),
(5, 4, "نیما فرهادی", "صنایع غذایی و لبنی بهاران", 2740, 790, 5, "تحلیلگر بازارهای صادراتی", 5, 4, "۱۴۰۵/۰۸/۰۱");

INSERT IGNORE INTO gamification_quests (id, quest_code, title, target_module_route, difficulty_tier, xp_reward, coin_reward, progress_pct, is_claimed) VALUES
(1, "QST-UCP-01", "شکارچی مغایرت اسنادی: کشف ۳ مغایرت بارنامه در آزمایشگاه UCP 600", "trade-academy", "حرفه‌ای", 350, 180, 100, 0),
(2, "QST-STRK-02", "قهرمان پیوستگی: ثبت ۷ روز مطالعه مستمر بدون وقفه در کلاس LMS", "lms", "متوسط", 250, 130, 100, 0),
(3, "QST-CAT-03", "تسلط تطبیقی: کسب توانمندی θ بالای +1.8 در آزمون هوشمند اینکوترمز", "exams", "پیشرفته", 420, 220, 85, 0),
(4, "QST-CLN-04", "مشارکت صنعتی: تکمیل خودارزیابی ۳۶۰ درجه کلینیک صادرات برای بنگاه", "business-clinic", "سازمانی B2B", 500, 260, 100, 0);

INSERT IGNORE INTO gamification_reward_store (id, reward_code, reward_title, category_label, coin_cost, stock_remaining, redeemed_count, last_voucher_serial) VALUES
(1, "RWD-DISC-25", "کد تخفیف ۲۵٪ ثبت‌نام دوره‌های تخصصی آکادمی تجارت بین‌الملل", "مشوق آموزشی", 650, 24, 9, "VCH-GAM-1405-4410"),
(2, "RWD-MENTOR-1H", "۱ جلسه مشاوره اختصاصی رایگان با مشاور ارشد گمرک/مالیات اتاق", "کلینیک VIP", 1100, 10, 5, "VCH-GAM-1405-7192"),
(3, "RWD-SUMMIT-VIP", "جایگاه ویژه (VIP Pass) همایش سالانه مدیران صادراتی استان", "تشریفات اتاق", 1450, 8, 4, "VCH-GAM-1405-8803"),
(4, "RWD-B2B-DESK", "اولویت رزرو میز مذاکره مستقیم B2B با هیئت‌های تجاری خارجی", "دیپلماسی تجاری", 2200, 5, 2, "VCH-GAM-1405-9315");

INSERT IGNORE INTO content_friction_heatmaps (id, course_title, lesson_segment, avg_rewind_count, dropoff_rate_pct, quiz_error_rate_pct, ai_pedagogical_fix, analyzed_shamsi) VALUES
(1, "جامع ثبت سفارش NTSW و اظهار گمرکی EPL", "درس ۲ — دقیقه ۱۸:۴۰ (فرمول محاسبه ارزش سیف و مأخذ ترکیبی)", 4.6, 39, 48, "نقطه گلوگاه شدید! پیشنهاد AI: افزودن حل مثال عددی گام‌به‌گام ۲ دقیقه‌ای و پیوست اکسل فرموله‌شده آماده.", "۱۴۰۵/۰۸/۰۱"),
(2, "اعتبارات اسنادی UCP 600 و ضمانت‌نامه‌های بانکی", "درس ۴ — دقیقه ۲۶:۱۰ (ماده ۱۴ استاندارد بررسی اسناد)", 3.8, 27, 36, "بازپخش بالا توسط فراگیران؛ پیشنهاد AI: درج اینفوگرافیک مقایسه‌ای ۵ روز کاری بانک عامل در کنار ویدئو.", "۱۴۰۵/۰۸/۰۱"),
(3, "سامانه مؤدیان و پایانه‌های فروشگاهی", "درس ۳ — دقیقه ۱۱:۱۵ (ارسال صورت‌حساب اصلاحی و ابطالی)", 2.1, 11, 14, "روان و اثربخش — نرخ تکمیل ۸۹٪ (الگوی برتر طراحی آموزشی برای سایر اساتید).", "۱۴۰۵/۰۸/۰۱");

INSERT IGNORE INTO executive_signoff_queue (id, doc_ref_no, doc_category, subject_title, amount_or_impact, sign_status, signature_sha256, signed_by_name, signed_shamsi) VALUES
(1, "EXEC-SIG-401", "قرارداد کلان سازمانی B2B", "الحاقیه قرارداد توانمندسازی صادراتی مجتمع فولاد زاگرس (۶۰ نفر-دوره)", "۱,۴۸۰,۰۰۰,۰۰۰ ریال", "pending", NULL, NULL, "۱۴۰۵/۰۸/۰۱"),
(2, "EXEC-SIG-402", "نامه رسمی کمیسیون صادرات", "پیشنهاد اصلاح مهلت رفع تعهد ارزی صادرکنندگان ماشین‌آلات به وزیر صمت", "اثر ملی — ۱۲۰ واحد صنعتی", "pending", NULL, NULL, "۱۴۰۵/۰۸/۰۱"),
(3, "EXEC-SIG-403", "صدور دسته‌جمعی گواهی QR", "تأیید نهایی ۲۴ فقره گواهی دوره جامع سامانه جامع تجارت NTSW", "۲۴ گواهی رسمی دارای QR", "signed", "8f434346648f6b96df89dda901c5176b10a6d83961dd3c1ac88b59b2dc327aa4", "دکتر کیارش رادمهر", "۱۴۰۵/۰۸/۰۱");

INSERT IGNORE INTO class_runbook_checklists (id, run_code, course_title, skyroom_link_ready, slides_uploaded, sms_24h_sent, hall_catering_ok, bulk_enrolled_count, readiness_pct, updated_shamsi) VALUES
(1, "RUN-1405-A1", "جامع اینکوترمز ۲۰۲۰ و اعتبارات اسنادی UCP600", 1, 1, 0, 1, 26, 75, "۱۴۰۵/۰۸/۰۱"),
(2, "RUN-1405-B4", "کارگاه عملی سامانه مؤدیان و پایانه‌های فروشگاهی", 1, 1, 1, 1, 31, 100, "۱۴۰۵/۰۸/۰۱");

INSERT IGNORE INTO tuition_refund_requests (id, refund_code, applicant_name, course_title, paid_tuition_rial, hours_before_start, deduction_pct, net_refund_rial, reversal_voucher_no, processed_shamsi) VALUES
(1, "RFD-1405-201", "شرکت بازرگانی سپهر گستر", "کارگاه قراردادهای بین‌المللی کد ۶۵", 69000000, 96, 0, 69000000, "VCH-RFD-9001", "۱۴۰۵/۰۸/۰۱"),
(2, "RFD-1405-202", "مهندس بهزاد نوری", "جامع ثبت سفارش NTSW و اظهار گمرک", 52000000, 36, 15, 44200000, "VCH-RFD-9002", "۱۴۰۵/۰۸/۰۱");

INSERT IGNORE INTO b2b_account_touchpoints (id, proposal_code, company_name, channel_source, contact_summary, proposed_package_rial, win_probability_pct, next_followup_shamsi) VALUES
(1, "PRP-1405-501", "مجتمع پتروشیمی و پلیمر استان", "بازوی رسمی بله + همایش صادرات", "ارسال پروپوزال اختصاصی آموزش ۳۵ کارشناس بازرگانی خارجی و گمرک با مشوق سازمانی", 890000000, 84, "۱۴۰۵/۰۸/۰۴"),
(2, "PRP-1405-502", "گروه صنایع غذایی بهاران", "رهیاب هوشمند پورتال عمومی", "جلسه آنلاین با مدیر منابع انسانی جهت فعال‌سازی سهمیه قرارداد سالانه", 420000000, 76, "۱۴۰۵/۰۸/۰۶");

INSERT IGNORE INTO instructor_availability_endorsements (id, record_code, instructor_name, free_weekly_slots, endorsed_learner_name, endorsed_skill_badge, recommendation_note, created_shamsi) VALUES
(1, "END-1405-301", "دکتر فرهاد رستگار (مدرس ارشد تجارت بین‌الملل)", "دوشنبه‌ها و چهارشنبه‌ها ۱۶ الی ۲۰", "مهندس مهرداد شریفی", "تأییدیه تخصصی استاد در بررسی اسناد UCP 600", "تسلط کم‌نظیر در کشف مغایرت‌های بارنامه و کلوزهای بیمه‌ای در کارگاه عملی؛ کاملاً آماده سرپرستی واحد صادرات.", "۱۴۰۵/۰۸/۰۱");

INSERT IGNORE INTO org_employee_training_requests (id, req_code, org_name, employee_fullname, department_unit, requested_course, hr_approval_status, contract_quota_deducted, requested_shamsi) VALUES
(1, "ORQ-1405-601", "مجتمع فولاد و ذوب‌آهن زاگرس", "مهندس آرش کاویانی", "واحد سفارشات خارجی", "جامع اینکوترمز ۲۰۲۰ و حمل چندوجهی", "در انتظار تأیید نماینده سازمان", 0, "۱۴۰۵/۰۸/۰۱"),
(2, "ORQ-1405-602", "مجتمع فولاد و ذوب‌آهن زاگرس", "پریسا سلیمانی", "واحد حسابداری مالیاتی", "سامانه مؤدیان و صورت‌حساب الکترونیکی نوع دوم", "تأیید شده و کسر از سهمیه قرارداد", 1, "۱۴۰۵/۰۸/۰۱");

INSERT IGNORE INTO learner_personal_idp_steps (id, user_id, learner_name, step_order, milestone_title, source_diagnostic, xp_bonus, is_done, target_shamsi) VALUES
(1, 7, "مهندس مهرداد شریفی", 1, "تکمیل شبیه‌ساز محاسبه حقوق ورودی گمرک در بخش تخصصی", "خروجی آزمون استاندارد Incoterms Pro", 50, 1, "۱۴۰۵/۰۸/۰۳"),
(2, 7, "مهندس مهرداد شریفی", 2, "مرور ۶ فلش‌کارت تقویتی کلوز A بیمه حمل کانتینری CIP", "هم‌درس هوشمند کنار ویدئو (AI Co-Tutor)", 65, 0, "۱۴۰۵/۰۸/۰۷"),
(3, 7, "مهندس مهرداد شریفی", 3, "ارسال گذرنامه مهارت OpenBadges برای موقعیت شغلی فولاد زاگرس", "همرسان برداری بازارگاه اشتغال (تطابق ۹۶٪)", 80, 0, "۱۴۰۵/۰۸/۱۲");

INSERT IGNORE INTO career_job_ads (id, ad_code, company_name, is_verified_member, job_title, category_slug, cooperation_type, seniority_level, city_location, salary_min_million, salary_max_million, perks_badges, required_skills_tags, required_chamber_cert, job_description_ai, is_urgent, views_count, applicants_count, ad_status, posted_shamsi) VALUES
(1, "JOB-1405-901", "مجتمع فولاد و ذوب‌آهن زاگرس", 1, "مدیر صادرات و قراردادهای بین‌المللی (بازار اوراسیا و خلیج فارس)", "export_trade", "تمام‌وقت", "مدیر میانی / سرپرست", "شهرک صنعتی اول", 65, 92, "پورسانت ارزی دلاری، بیمه تکمیلی طلایی، خودرو سازمانی، وام مسکن", "Incoterms 2020, UCP 600, مذاکره تجاری انگلیسی/روسی, رفع تعهد ارزی نیما", "گواهی جامع آکادمی تجارت بین‌الملل اتاق", "مسئولیت کامل تدوین استراتژی فروش صادراتی، مذاکره با خریداران عمده در روسیه و امارات، تنظیم قراردادهای منطبق بر قواعد ICC و نظارت بر اسناد حمل و اعتبارات اسنادی.", 1, 342, 9, "active", "۱۴۰۵/۰۸/۰۱"),
(2, "JOB-1405-902", "مجتمع پتروشیمی و پلیمر استان", 1, "کارشناس ارشد ثبت سفارش NTSW، ترخیص و امور گمرکی EPL", "customs_logistics", "تمام‌وقت", "کارشناس ارشد", "مرکز استان", 48, 66, "بیمه تکمیلی، پاداش ترخیص سریع بدون دموراژ، ناهار گرم، کمک‌هزینه آموزش آدان", "سامانه جامع تجارت NTSW, اظهار گمرکی EPL, تعیین تعرفه HS Code, حمل چندوجهی", "گواهی جامع سامانه جامع تجارت و گمرک EPL", "مدیریت صفر تا صد پرونده‌های ثبت سفارش مواد اولیه، اخذ مجوزهای فنی و ارزی، اظهار در سامانه EPL و کاهش زمان توقف کانتینر در مبادی گمرکی.", 1, 278, 12, "active", "۱۴۰۵/۰۸/۰۱"),
(3, "JOB-1405-903", "گروه صنایع غذایی و لبنی بهاران", 1, "رئیس حسابداری مالیاتی، سامانه مؤدیان و بهای تمام‌شده صادراتی", "finance_tax", "تمام‌وقت / هیبرید", "سرپرست", "شهرک صنعتی دوم", 52, 74, "پاداش عملکرد فصلی، بیمه تکمیلی خانواده، ساعت کاری منعطف", "سامانه مؤدیان مالیاتی, ماده ۱۶۹ و استرداد ارزش افزوده صادرات, سپیدار و همکاران سیستم", "گواهی تخصصی سامانه مؤدیان و دادرسی مالیاتی", "ارسال بی‌نقص صورت‌حساب‌های الکترونیکی، پیگیری پرونده‌های استرداد مالیات بر ارزش افزوده کالاهای صادراتی و تهیه گزارش‌های تحلیلی بهای تمام‌شده.", 0, 215, 7, "active", "۱۴۰۵/۰۷/۳۰"),
(4, "JOB-1405-904", "شرکت دانش‌بنیان تجهیز دقیق اسپادانا", 1, "کارشناس بازاریابی بین‌الملل و کشف خریدار خارجی با هوش مصنوعی", "ai_marketing", "دورکاری / هیبرید", "کارشناس", "مرکز استان / دورکاری", 38, 54, "پورسانت دلاری از هر پیش‌فاکتور صادراتی، ساعت کاری شناور، بودجه ابزارهای هوش مصنوعی", "ITC TradeMap, LinkedIn B2B Outreach, هوش مصنوعی تجاری, مکاتبات انگلیسی BEC", "گواهی بازاریابی صادراتی با هوش مصنوعی اتاق", "تحلیل داده‌های واردات جهانی در TradeMap، استخراج فهرست تصمیم‌گیرندگان خرید در بازار هدف و اجرای کمپین‌های مذاکره B2B.", 1, 419, 15, "active", "۱۴۰۵/۰۸/۰۱");

INSERT IGNORE INTO career_candidate_profiles (id, user_id, full_name, headline_title, experience_years, expected_salary_million, city_preference, availability_status, foreign_languages, core_skills_csv, synced_certs_summary, work_style_nonclinical, gamification_xp_badge, updated_shamsi) VALUES
(1, 7, "مهندس مهرداد شریفی", "کارشناس ارشد بازرگانی خارجی، اعتبارات اسنادی UCP600 و لجستیک صادرات", 6, 62, "مرکز استان / شهرک صنعتی", "آماده شروع از ۱۵ آبان", "انگلیسی تجاری C1 (BEC) | عربی بازرگانی B2", "Incoterms 2020, UCP 600, سامانه جامع تجارت NTSW, مذاکره B2B, TradeMap", "گواهی QR جامع تجارت بین‌الملل (CERT-ADN-1405-9001) + تأییدیه استاد دکتر رستگار", "تیپ تحلیلی-راهبردی ENTJ (ارزیابی غیربالینی محیط کار)", "سطح ۸ — سفیر طلایی صادرات (۴,۸۹۰ XP)", "۱۴۰۵/۰۸/۰۱"),
(2, 2, "مهندس پگاه کاظمی", "متخصص ترخیص کالا، تعرفه‌گذاری HS و ثبت سفارش صنعتی", 5, 54, "مرکز استان", "آماده شروع فوری", "انگلیسی B2 | ترکی استانبولی تجاری B2", "EPL گمرک, NTSW, گواهی مبدأ اوراسیا CT-3, بیمه باربری کلوز A", "گواهی رسمی عملیات گمرکی و ثبت سفارش مؤسسه آموزشی آدان", "تیپ دقیق و ساختارمند ISTJ (ارزیابی غیربالینی محیط کار)", "سطح ۶ — متخصص ارشد گمرک (۳,۶۸۰ XP)", "۱۴۰۵/۰۸/۰۱");

INSERT IGNORE INTO career_ats_applications (id, tracking_code, job_ad_id, job_title_snapshot, company_snapshot, candidate_name, ats_stage, ai_match_score_pct, skill_gap_prescription, candidate_note, applied_shamsi) VALUES
(1, "APP-1405-7701", 1, "مدیر صادرات و قراردادهای بین‌المللی", "مجتمع فولاد و ذوب‌آهن زاگرس", "مهندس مهرداد شریفی", "interview", 96, "تطابق کامل (۹۶٪) — پیشنهاد مرور ۲ ساعته بسته قراردادهای تعرفه‌صفر اوراسیا پیش از مصاحبه نهایی.", "دارای گواهی QR معتبر و توصیه‌نامه رسمی استاد", "۱۴۰۵/۰۸/۰۱"),
(2, "APP-1405-7702", 2, "کارشناس ارشد ثبت سفارش NTSW و گمرک", "مجتمع پتروشیمی و پلیمر استان", "مهندس پگاه کاظمی", "offer_sent", 94, "تطابق عالی (۹۴٪) — تسلط عملی بر اظهار EPL و کدهای تعرفه پتروشیمی احراز شد.", "سابقه ترخیص بیش از ۸۰ محموله صنعتی بدون جریمه گمرکی", "۱۴۰۵/۰۸/۰۱"),
(3, "APP-1405-7703", 4, "کارشناس بازاریابی بین‌الملل با هوش مصنوعی", "تجهیز دقیق اسپادانا", "نیما فرهادی", "ai_screened", 87, "شکاف جزئی در UCP600 — پیشنهاد گذراندن میکروکارگاه ۴ ساعته اسناد حمل اتاق.", "نمونه‌کار استخراج ۵۰ خریدار واقعی از TradeMap پیوست است", "۱۴۰۵/۰۸/۰۱"),
(4, "APP-1405-7704", 3, "رئیس حسابداری مالیاتی و سامانه مؤدیان", "گروه صنایع غذایی بهاران", "پریسا سلیمانی", "hired", 97, "استخدام قطعی شد — تکمیل دوره مؤدیان اتاق با نمره ۹۵.", "معرفی‌شده از کارتابل نماینده سازمان", "۱۴۰۵/۰۷/۲۸");

INSERT IGNORE INTO career_interview_schedules (id, interview_code, candidate_name, company_name, job_title, interview_mode, scheduled_shamsi, interviewer_panel, ai_tailored_questions, technical_score, interview_outcome) VALUES
(1, "INT-1405-510", "مهندس مهرداد شریفی", "مجتمع فولاد و ذوب‌آهن زاگرس", "مدیر صادرات و قراردادهای بین‌المللی", "حضوری در دفتر مرکزی کارخانه", "یکشنبه ۱۴۰۵/۰۸/۰۴ ساعت ۱۰:۳۰", "مدیرعامل + مدیر بازرگانی خارجی", "۱) مدیریت ریسک نوسان نرخ تسعیر در قرارداد ۶ ماهه CIS؟ | ۲) راهکار حذف مغایرت بارنامه کانتینری در ماده ۱۴ UCP600؟ | ۳) نحوه پوشش تعرفه کربن CBAM اروپا؟", 95, "تأیید ممتاز فنی — ارجاع جهت صدور نامه پیشنهاد حقوق"),
(2, "INT-1405-511", "نیما فرهادی", "تجهیز دقیق اسپادانا", "کارشناس بازاریابی بین‌الملل با هوش مصنوعی", "آنلاین (اتاق اسکای‌روم کاریابی اتاق)", "سه‌شنبه ۱۴۰۵/۰۸/۰۶ ساعت ۱۵:۰۰", "مدیر توسعه بازار بین‌الملل", "۱) نحوه اعتبارسنجی خریدار خارجی پیش از ارسال پیش‌فاکتور؟ | ۲) تحلیل حاشیه سود DDP در برابر FCA؟", 88, "دعوت‌نامه پیامکی و لینک جلسه ارسال شد");

INSERT IGNORE INTO career_job_offers (id, offer_serial, candidate_name, company_name, position_title, base_monthly_million, export_commission_note, start_date_shamsi, offer_status, created_shamsi) VALUES
(1, "OFR-1405-301", "مهندس پگاه کاظمی", "مجتمع پتروشیمی و پلیمر استان", "کارشناس ارشد ثبت سفارش NTSW و امور گمرکی", 62, "پاداش ترخیص سریع + بیمه تکمیلی طلایی + سهمیه رایگان دوره‌های حسابداری", "۱۴۰۵/۰۸/۱۵", "پذیرفته‌شده و امضاشده توسط کارجو ✅", "۱۴۰۵/۰۸/۰۱");

INSERT IGNORE INTO career_salary_benchmarks (id, role_family, min_million, median_million, max_top_decile_million, market_demand_index, top_value_cert) VALUES
(1, "مدیر صادرات و توسعه بازار بین‌الملل", 60, 78, 115, 97, "آکادمی جامع تجارت بین‌الملل و UCP600 (+۲۸٪ جهش حقوق)"),
(2, "رئیس حسابداری مالیاتی و سامانه مؤدیان", 48, 64, 88, 94, "دوره عملی سامانه مؤدیان و استرداد مالیات صادرات (+۲۲٪)"),
(3, "کارشناس ارشد ثبت سفارش NTSW و ترخیص گمرکی", 42, 56, 76, 95, "کارگاه عملی NTSW و اظهار گمرکی EPL (+۲۵٪)"),
(4, "کارشناس بازاریابی صادراتی با هوش مصنوعی", 35, 49, 68, 91, "شکار خریداران خارجی با AI و TradeMap (+۲۴٪)");

INSERT IGNORE INTO career_job_fair_booths (id, booth_code, company_name, industry_sector, open_positions_count, speed_interview_slots_left, featured_roles, fair_date_shamsi) VALUES
(1, "BOOTH-A01", "مجتمع فولاد و ذوب‌آهن زاگرس", "فلزات اساسی و فولاد صادراتی", 5, 6, "مدیر صادرات، کارشناس L/C، کارشناس لجستیک ریلی", "چهارشنبه ۱۴۰۵/۰۸/۱۴ — تالار بزرگ مؤسسه آموزشی آدان"),
(2, "BOOTH-A02", "مجتمع پتروشیمی و پلیمر استان", "پتروشیمی و پلیمر", 4, 5, "متخصص NTSW، حسابدار ارشد ارزی، کارشناس فروش خلیج فارس", "چهارشنبه ۱۴۰۵/۰۸/۱۴ — تالار بزرگ مؤسسه آموزشی آدان"),
(3, "BOOTH-B04", "گروه صنایع غذایی و لبنی بهاران", "صنایع غذایی صادرات‌محور", 6, 9, "مدیر فروش عراق و اوراسیا، کارشناس استاندارد و قرنطینه", "چهارشنبه ۱۴۰۵/۰۸/۱۴ — تالار بزرگ مؤسسه آموزشی آدان");

-- =====================================================================
-- SEED DATA FOR v19.0: LIVE THEME & FONT STUDIO, SYSTEM SETTINGS, DYNAMIC IAM/RBAC & ACADEMIC ERP CORE (#143 - #152)
-- =====================================================================

INSERT IGNORE INTO erp_ui_theme_profiles
(id, theme_slug, theme_title, color_mode, primary_hex, gold_accent_hex, sidebar_bg_hex, font_family_key, base_font_px, line_height_val, border_radius_px, ui_density, brand_org_title, brand_unit_subtitle, brand_monogram, is_active, updated_shamsi) VALUES
(1, "modern_indigo", "نیلی مدرن سازمانی با قلم وزیرمتن (پوسته مدرن پیش‌فرض)", "light", "#4f46e5", "#d97706", "#0f172a", "Vazirmatn", 14, "1.75", 16, "comfortable", "مؤسسه آموزشی آدان", "آموزش تخصصی حسابداری و امور مالی", "ناب", 1, "۱۴۰۵/۰۸/۰۱"),
(2, "emerald_gold", "زمردی و طلایی مؤسسه آموزشی آدان (پالت رسمی کلاسیک)", "light", "#0f766e", "#d97706", "#0b192c", "Shabnam_Modern", 14, "1.75", 16, "comfortable", "مؤسسه آموزشی آدان", "آموزش تخصصی حسابداری و امور مالی", "ناب", 0, "۱۴۰۵/۰۸/۰۱"),
(3, "ocean_sahel", "آبی اقیانوسی با قلم ساحل (ویژه مطالعه و مستندات)", "light", "#0284c7", "#0d9488", "#0c192c", "Sahel_Modern", 15, "1.85", 18, "spacious", "مؤسسه آموزشی آدان", "آموزش تخصصی حسابداری و امور مالی", "ناب", 0, "۱۴۰۵/۰۸/۰۱"),
(4, "midnight_executive", "حالت شب مدرن ابسیدین (Executive Dark Mode)", "dark", "#6366f1", "#fbbf24", "#090d16", "Vazirmatn", 14, "1.75", 16, "comfortable", "مؤسسه آموزشی آدان", "آموزش تخصصی حسابداری و امور مالی", "ناب", 0, "۱۴۰۵/۰۸/۰۱"),
(5, "amethyst_academy", "بنفش نوآوری با قلم صمیم (ویژه پژوهش و هوش مصنوعی)", "light", "#7c3aed", "#ec4899", "#130f26", "Samim_Editorial", 14, "1.80", 18, "comfortable", "مؤسسه آموزشی آدان", "آموزش تخصصی حسابداری و امور مالی", "ناب", 0, "۱۴۰۵/۰۸/۰۱"),
(6, "gov_compact_tahoma", "لاجوردی فشرده پرتراکم با قلم تاهوما (ویژه جداول مالی)", "light", "#2563eb", "#d97706", "#111827", "Tahoma_Formal", 13, "1.65", 10, "compact", "مؤسسه آموزشی آدان", "آموزش تخصصی حسابداری و امور مالی", "ناب", 0, "۱۴۰۵/۰۸/۰۱");

INSERT IGNORE INTO erp_system_settings (id, setting_group, setting_key, setting_label, setting_value, input_type, updated_by, updated_shamsi) VALUES
(1, "academic", "min_attendance_pct", "حداقل درصد حضور الزامی جهت مجوز صدور گواهی QR (٪)", "80", "number", "مدیرکل آموزش", "۱۴۰۵/۰۸/۰۱"),
(2, "academic", "passing_grade_min", "حداقل نمره قبولی استاندارد دوره‌های تخصصی (از ۱۰۰)", "70", "number", "مدیرکل آموزش", "۱۴۰۵/۰۸/۰۱"),
(3, "academic", "certificate_serial_prefix", "الگوی پیشوند شماره سریال رسمی گواهی‌نامه‌ها", "CERT-ADN-1405-", "text", "مدیرکل آموزش", "۱۴۰۵/۰۸/۰۱"),
(4, "academic", "add_drop_hours_limit", "مهلت انصراف و جابه‌جایی بدون کسر جریمه (ساعت قبل از شروع)", "72", "number", "کارشناس مسئول آموزش", "۱۴۰۵/۰۸/۰۱"),
(5, "finance", "vat_rate_pct", "نرخ قانونی مالیات بر ارزش افزوده صورت‌حساب‌ها (٪)", "10", "number", "مدیر مالی آموزش", "۱۴۰۵/۰۸/۰۱"),
(6, "finance", "instructor_tax_art86_pct", "نرخ کسور مالیات تکلیفی حق‌التدریس اساتید ماده ۸۶ (٪)", "10", "number", "مدیر مالی آموزش", "۱۴۰۵/۰۸/۰۱"),
(7, "finance", "max_installments_count", "حداکثر تعداد اقساط مجاز شهریه قراردادهای سازمانی", "4", "number", "مدیر مالی آموزش", "۱۴۰۵/۰۸/۰۱"),
(8, "finance", "default_payment_gateway", "درگاه پرداخت اینترنتی پیش‌فرض (شاپرک / بانکی)", "به‌پرداخت بانک ملت + زرین‌پال (حالت شبیه‌ساز امن تا ثبت مرچنت)", "text", "مدیر مالی آموزش", "۱۴۰۵/۰۸/۰۱"),
(9, "ai_integrations", "ai_base_url", "آدرس پایه وب‌سرویس هوش مصنوعی AI", "https://api.openai.com/v1", "text", "مدیرکل آموزش", "۱۴۰۵/۰۸/۰۱"),
(10, "ai_integrations", "ai_default_model", "مدل پیش‌فرض تحلیل آموزشی و مشاور هوشمند", "gpt-4o-mini", "text", "مدیرکل آموزش", "۱۴۰۵/۰۸/۰۱"),
(11, "ai_integrations", "enforce_pii_masking", "ماسک خودکار کد ملی و موبایل پیش از ارسال به هوش مصنوعی", "فعال و اجباری (PII Shield Active)", "text", "مدیرکل آموزش", "۱۴۰۵/۰۸/۰۱"),
(12, "ai_integrations", "sms_messenger_gateway", "خط خدماتی پیامک و بازوهای پیام‌رسان بومی (بله / ایتا)", "خط خدماتی ۹۰۰۰۱۲۳۴ + بازوی رسمی بله و ایتا", "text", "مدیر CRM", "۱۴۰۵/۰۸/۰۱"),
(13, "security", "session_timeout_minutes", "زمان قفل و خروج خودکار نشست کاربری در صورت عدم فعالیت (دقیقه)", "45", "number", "مدیرکل آموزش", "۱۴۰۵/۰۸/۰۱"),
(14, "security", "max_failed_logins", "حداکثر تلاش ناموفق ورود پیش از فعال‌سازی قفل ضد Brute-Force", "5", "number", "مدیرکل آموزش", "۱۴۰۵/۰۸/۰۱"),
(15, "security", "require_human_approval_ai", "الزام تأیید نهایی انسانی پیش از انتشار خروجی‌های AI و کمپین‌ها", "اجباری طبق ضوابط حکمرانی مؤسسه", "text", "مدیرکل آموزش", "۱۴۰۵/۰۸/۰۱");

INSERT IGNORE INTO iam_custom_roles (id, role_slug, role_title_fa, data_scope, badge_color, is_system_builtin, description_note, created_shamsi) VALUES
(1, "super_admin", "مدیرکل آموزش مؤسسه آموزشی آدان (دسترسی کامل کل سامانه)", "global_province", "gold", 1, "دسترسی کامل به هر بخش‌های سامانه، توشیح اسناد، تنظیمات هسته و ماتریس امنیتی", "۱۴۰۵/۰۱/۰۱"),
(2, "training_expert", "کارشناس مسئول برنامه‌ریزی و اجرای آموزش", "global_province", "success", 1, "مدیریت دوره‌ها، تقویم آموزشی، حضور و غیاب، آزمون، گواهی QR و میز خدمت", "۱۴۰۵/۰۱/۰۱"),
(3, "finance_manager", "مدیر امور مالی، خزانه‌داری و سامانه مؤدیان", "global_province", "info", 1, "دفترکل ۴ سطحی، فاکتور رسمی، استرداد آیین‌نامه‌ای، حق‌التدریس ماده ۸۶ و خروجی سپیدار", "۱۴۰۵/۰۱/۰۱"),
(4, "crm_manager", "مدیر بازاریابی، ارتباط با اعضا (CRM) و کاریابی", "global_province", "warning", 1, "مدیریت قیف فروش B2B، قراردادهای سازمانی، کمپین‌ها، رویدادها و نمایشگاه کار", "۱۴۰۵/۰۱/۰۱"),
(5, "instructor", "مدرس، مشاور صنعتی و ارزیاب رسمی آدان", "own_records", "info", 1, "مدیریت کلاس آنلاین، تولید محتوا با AI، ثبت نمرات و حضور و غیاب و صدور توصیه‌نامه", "۱۴۰۵/۰۱/۰۱"),
(6, "org_rep", "نماینده آموزش شرکت / کارخانه دانش‌پذیر آدان", "organization_only", "gold", 1, "سهمیه قرارداد شرکت، معرفی کارکنان، انتشار آگهی استخدام و پایپ‌لاین ATS شرکت خود (بدون دسترسی به کمپین CRM)", "۱۴۰۵/۰۱/۰۱"),
(7, "learner", "فراگیر، کارجو و بازرگان دانش‌پذیر آدان", "own_records", "success", 1, "پرونده آموزشی، آزمون، گواهی QR، کارنامه، رزومه‌ساز رسمی، ارسال رزومه و تیکت پشتیبانی", "۱۴۰۵/۰۱/۰۱"),
(8, "exam_proctor_officer", "بازرس قرنطینه آزمون و کنترل اصالت گواهی (نقش سفارشی)", "branch_only", "danger", 0, "نظارت سلامت آزمون، استعلام گروهی QR و بررسی اعتراض به نمرات بدون دسترسی به اسناد مالی", "۱۴۰۵/۰۸/۰۱"),
(9, "branch_director", "رئیس اداره آموزش دفتر نمایندگی شهرستان (نقش سفارشی)", "branch_only", "info", 0, "مدیریت ثبت‌نام، کلاس‌ها و گزارش عملکرد شعبه شهرستان مربوطه", "۱۴۰۵/۰۸/۰۱");

INSERT IGNORE INTO iam_role_permissions (id, role_slug, module_domain, module_label_fa, can_view, can_create, can_edit, can_delete, can_approve, can_export, updated_shamsi) VALUES
(1, "super_admin", "academic_tms_lms", "مدیریت دوره‌ها، تقویم آموزشی، حضور و غیاب و کارنامه", 1, 1, 1, 1, 1, 1, "۱۴۰۵/۰۸/۰۱"),
(2, "super_admin", "finance_tax_ledger", "امور مالی، دفترکل ۴ سطحی، استرداد و سامانه مؤدیان", 1, 1, 1, 1, 1, 1, "۱۴۰۵/۰۸/۰۱"),
(3, "super_admin", "exams_certificates_qr", "بانک سؤالات، قرنطینه آزمون و صدور/ابطال گواهی QR", 1, 1, 1, 1, 1, 1, "۱۴۰۵/۰۸/۰۱"),
(4, "super_admin", "crm_campaigns_contracts", "CRM سازمانی، قراردادها و کمپین‌های بازاریابی", 1, 1, 1, 1, 1, 1, "۱۴۰۵/۰۸/۰۱"),
(5, "super_admin", "career_ats_recruitment", "کاریابی جامع، انتشار آگهی، پایپ‌لاین ATS و نامه پیشنهاد شغلی", 1, 1, 1, 1, 1, 1, "۱۴۰۵/۰۸/۰۱"),
(6, "super_admin", "system_theme_iam_security", "تنظیمات هسته ERP، تم و فونت، کاربران و ماتریس سطح دسترسی", 1, 1, 1, 1, 1, 1, "۱۴۰۵/۰۸/۰۱"),
(7, "training_expert", "academic_tms_lms", "مدیریت دوره‌ها، تقویم آموزشی، حضور و غیاب و کارنامه", 1, 1, 1, 0, 1, 1, "۱۴۰۵/۰۸/۰۱"),
(8, "training_expert", "finance_tax_ledger", "امور مالی، دفترکل ۴ سطحی، استرداد و سامانه مؤدیان", 1, 0, 0, 0, 0, 1, "۱۴۰۵/۰۸/۰۱"),
(9, "training_expert", "exams_certificates_qr", "بانک سؤالات، قرنطینه آزمون و صدور/ابطال گواهی QR", 1, 1, 1, 0, 1, 1, "۱۴۰۵/۰۸/۰۱"),
(10, "finance_manager", "finance_tax_ledger", "امور مالی، دفترکل ۴ سطحی، استرداد و سامانه مؤدیان", 1, 1, 1, 0, 1, 1, "۱۴۰۵/۰۸/۰۱"),
(11, "org_rep", "crm_campaigns_contracts", "CRM سازمانی، قراردادها و کمپین‌های بازاریابی", 1, 0, 0, 0, 0, 0, "۱۴۰۵/۰۸/۰۱"),
(12, "org_rep", "career_ats_recruitment", "کاریابی جامع، انتشار آگهی، پایپ‌لاین ATS و نامه پیشنهاد شغلی", 0, 0, 0, 0, 0, 0, "۱۴۰۵/۰۸/۰۱"),
(13, "learner", "academic_tms_lms", "مدیریت دوره‌ها، تقویم آموزشی، حضور و غیاب و کارنامه", 1, 1, 0, 0, 0, 1, "۱۴۰۵/۰۸/۰۱"),
(14, "learner", "career_ats_recruitment", "کاریابی جامع، انتشار آگهی، پایپ‌لاین ATS و نامه پیشنهاد شغلی", 0, 0, 0, 0, 0, 0, "۱۴۰۵/۰۸/۰۱");

INSERT IGNORE INTO iam_user_overrides (id, user_id, user_fullname, route_or_perm, effect_type, reason_note, expires_shamsi, granted_by) VALUES
(1, 2, "سرکار خانم مهندس پگاه کاظمی (کارشناس آموزش)", "national-interchange", "deny", "قفل موقت هیئت‌رئیسه: مسدودسازی تبادل برخط با سامانه‌های ملی تا پایان ممیزی امنیتی (نمونه استثنای Deny سطح کاربر)", "۱۴۰۵/۰۹/۳۰", "دکتر کیارش رادمهر"),
(2, 6, "نماینده آموزش فولاد زاگرس (org_rep)", "marketing-intel", "deny", "قفل امنیتی مصوب اتاق: عدم دسترسی نماینده شرکت‌ها به کمپین‌های انبوه بازاریابی", "دائمی", "سیاست امنیتی هسته");

INSERT IGNORE INTO academic_terms_calendar (id, term_code, term_title, registration_window, add_drop_deadline, exams_window, target_capacity, term_status) VALUES
(1, "TERM-1405-FALL", "نیمسال اول (پاییز ۱۴۰۵) — دوره‌های تخصصی صادرات، گمرک و کارت بازرگانی", "۱۴۰۵/۰۶/۲۰ لغایت ۱۴۰۵/۰۷/۱۵", "تا ۷۲ ساعت پیش از جلسه اول هر کد دوره", "۱۴۰۵/۰۹/۲۰ لغایت ۱۴۰۵/۰۹/۳۰", 850, "فعال — در حال برگزاری کلاس‌ها"),
(2, "TERM-1405-WINTER", "نیمسال دوم (زمستان ۱۴۰۵) — هوش مصنوعی تجاری، سامانه مؤدیان و قراردادهای اوراسیا", "۱۴۰۵/۰۹/۱۵ لغایت ۱۴۰۵/۱۰/۱۰", "تا ۱۴۰۵/۱۰/۱۴ بدون کسر کارمزد", "۱۴۰۵/۱۲/۱۰ لغایت ۱۴۰۵/۱۲/۲۲", 920, "پیش‌ثبت‌نام سازمانی باز است"),
(3, "TERM-1406-SPRING", "ترم بهار ۱۴۰۶ — مدرسه عالی مدیران صنعتی و دیپلماسی تجاری اتاق", "۱۴۰۵/۱۲/۱۵ لغایت ۱۴۰۶/۰۱/۲۰", "تا ۱۴۰۶/۰۱/۲۵", "۱۴۰۶/۰۳/۲۰ لغایت ۱۴۰۶/۰۳/۳۱", 700, "در حال تدوین تقویم مصوب");

INSERT IGNORE INTO academic_attendance_gradebook
(id, record_serial, term_code, learner_name, national_id, course_title, sessions_total, sessions_attended, attendance_pct, quiz_activity_score, practical_project_score, final_exam_score, weighted_total_score, academic_standing, appeal_status, updated_shamsi) VALUES
(1, "GRD-1405-1001", "TERM-1405-FALL", "مهندس مهرداد شریفی", "1079025413", "جامع قوانین اینکوترمز ۲۰۲۰، اعتبارات اسنادی UCP600 و حمل بین‌الملل", 10, 10, 100, 95, 96, 94, 95, "قبول ممتاز — مجاز به صدور گواهی QR ✅", "تأیید نهایی نمره", "۱۴۰۵/۰۸/۰۱"),
(2, "GRD-1405-1002", "TERM-1405-FALL", "سرکار خانم مهندس پگاه کاظمی", "0078912349", "جامع ثبت سفارش واردات NTSW، ارز نیمایی و اظهار گمرک EPL", 10, 9, 90, 90, 94, 92, 92, "قبول ممتاز — مجاز به صدور گواهی QR ✅", "تأیید نهایی نمره", "۱۴۰۵/۰۸/۰۱"),
(3, "GRD-1405-1003", "TERM-1405-FALL", "جناب آقای نیما فرهادی", "0491234567", "تهیه و تنظیم قراردادهای تجاری بین‌المللی (CISG)", 10, 8, 80, 78, 84, 81, 81, "قبول — مجاز به صدور گواهی QR ✅", "درخواست بازبینی برگه عملی ثبت شد", "۱۴۰۵/۰۸/۰۱"),
(4, "GRD-1405-1004", "TERM-1405-FALL", "جناب آقای کامیار رضوانی", "1289043211", "آموزش الزامی متقاضیان صدور کارت بازرگانی", 10, 6, 60, 74, 70, 72, 72, "توقف صدور گواهی ⛔ (حضور ۶۰٪ کمتر از حدنصاب ۸۰٪)", "نیازمند شرکت در ۲ جلسه جبرانی", "۱۴۰۵/۰۸/۰۱");

INSERT IGNORE INTO academic_prereq_waitlist
(id, rule_or_queue_code, target_course_title, prerequisite_course_title, rule_type, waitlist_applicant_name, applicant_priority_score, queue_status, created_shamsi) VALUES
(1, "PRQ-1405-01", "قراردادهای پیشرفته صادراتی و داوری بین‌المللی اتاق ICC", "جامع قوانین اینکوترمز ۲۰۲۰ و UCP600", "پیش‌نیاز الزامی سیستمی", "مهندس امیرحسین تابش (فولاد زاگرس)", 96, "نفر اول صف انتظار — آماده ارتقا به ثبت‌نام قطعی", "۱۴۰۵/۰۸/۰۱"),
(2, "PRQ-1405-02", "دادرسی مالیاتی پیشرفته و استرداد ارزش افزوده صادرات", "کارگاه عملی سامانه مؤدیان و پایانه‌های فروشگاهی", "پیش‌نیاز الزامی سیستمی", "سرکار خانم سارا مرادی (صنایع غذایی بهاران)", 91, "در صف انتظار ظرفیت", "۱۴۰۵/۰۸/۰۱"),
(3, "PRQ-1405-03", "مذاکره تجاری انگلیسی سطح پیشرفته در نمایشگاه‌های خارجی", "تعیین سطح زبان تجاری حداقل B2 در مرکز آزمون اتاق", "شرط امتیاز آزمون تعیین سطح", "جناب آقای فرهاد کریمی", 88, "ارتقایافته به ثبت‌نام قطعی ✅", "۱۴۰۵/۰۷/۲۹");

INSERT IGNORE INTO erp_helpdesk_tickets
(id, ticket_no, requester_name, requester_role, department_unit, priority_level, sla_hours, subject_line, official_reply, ticket_status, created_shamsi) VALUES
(1, "TKT-1405-401", "مهندس مهرداد شریفی", "فراگیر دانش‌پذیر آدان", "امتحانات و صدور گواهی QR", "عادی", 8, "درخواست صدور نسخه انگلیسی دوزبانه گواهی دوره اینکوترمز جهت ضمیمه پرونده اتاق مشترک", "نسخه دوزبانه انگلیسی-فارسی با کد QR معتبر صادر و در کارتابل شما فعال شد.", "پاسخ داده و بسته شد ✅", "۱۴۰۵/۰۷/۳۰"),
(2, "TKT-1405-402", "نماینده آموزش فولاد زاگرس", "نماینده کارخانه (org_rep)", "امور مالی و فاکتور رسمی مؤدیان", "بالا (فوری)", 4, "درخواست ثبت کد یکتای ۲۲ رقمی مالیاتی روی فاکتور ثبت‌نام گروهی ۱۲ نفره", NULL, "در انتظار پاسخ کارشناس", "۱۴۰۵/۰۸/۰۱"),
(3, "TKT-1405-403", "جناب آقای نیما فرهادی", "فراگیر دانش‌پذیر آدان", "پشتیبانی فنی کلاس آنلاین اسکای‌روم", "متوسط", 6, "دسترسی به ویدئوی ضبط‌شده کارگاه عملی تنظیم قرارداد CISG جلسه چهارم", "لینک بازپخش امن با واترمارک اختصاصی در بخش LMS شما فعال گردید.", "پاسخ داده و بسته شد ✅", "۱۴۰۵/۰۸/۰۱");

INSERT IGNORE INTO erp_admin_requests_templates
(id, entry_code, record_category, applicant_or_event, request_type_or_channel, body_or_template, approval_state, updated_shamsi) VALUES
(1, "ADM-REQ-801", "student_request", "مهندس مهرداد شریفی", "گواهی اشتغال به تحصیل/دوره رسمی جهت کارفرما", "بدین‌وسیله گواهی می‌شود نامبرده در دوره ۸۰ ساعته تجارت بین‌الملل مرکز آموزش مؤسسه آموزشی آدان مشغول به تحصیل می‌باشد.", "تأیید و صادرشده ✅", "۱۴۰۵/۰۸/۰۱"),
(2, "ADM-REQ-802", "student_request", "جناب آقای کامیار رضوانی", "درخواست شرکت در جلسه جبرانی غیبت موجه", "ارائه گواهی مأموریت گمرکی بندرعباس جهت جبران ۲ جلسه غیبت دوره کارت بازرگانی.", "در انتظار تأیید کارشناس آموزش", "۱۴۰۵/۰۸/۰۱"),
(3, "TPL-SMS-101", "notif_template", "رویداد: ثبت‌نام قطعی در دوره آموزشی", "پیامک خدماتی + بازوی بله", "فراگیر گرامی {full_name}؛ ثبت‌نام شما در دوره «{course_title}» قطعی شد. شروع کلاس: {class_date} — مرکز آموزش مؤسسه آموزشی آدان.", "قالب فعال سیستمی ✅", "۱۴۰۵/۰۸/۰۱"),
(4, "TPL-SMS-102", "notif_template", "رویداد: اعلام نمره نهایی و صدور گواهی QR", "پیامک خدماتی + ایمیل رسمی", "تبریک {full_name} عزیز! نمره نهایی شما ({score}/100) ثبت و گواهی رسمی با سریال {cert_serial} آماده دریافت است.", "قالب فعال سیستمی ✅", "۱۴۰۵/۰۸/۰۱");

-- =====================================================================
-- SEED DATA FOR v20.0: MICROLEARNING CAPSULES, SM-2 SPACED REPETITION, 60s CHALLENGES & JOB-AIDS (#153 - #158)
-- =====================================================================

INSERT IGNORE INTO micro_learning_capsules
(id, capsule_code, title, topic_domain, duration_seconds, difficulty_tag, slide_1_hook, slide_2_rule, slide_3_example, quiz_question, quiz_opt_a, quiz_opt_b, quiz_opt_c, correct_opt, xp_reward, completions_count, created_shamsi) VALUES
(1, "MIC-INC-01", "تفاوت حیاتی FCA و FOB در حمل کانتینری (Incoterms 2020)", "تجارت بین‌الملل", 180, "ویژه مدیران صادرات",
 "⚠️ خطای میلیون‌دلاری رایج: استفاده از قاعده FOB برای کالاهای کانتینری باعث می‌شود فروشنده تا لحظه عبور کانتینر از نرده کشتی مسئول خسارات محوطه کانتینری (CY) بماند، در حالی که کنترلی بر اپراتور بندر ندارد!",
 "✅ قاعده طلایی مرجع بین‌المللی ICC (ICC): برای هرگونه حمل کانتینری به جای FOB از FCA (تحویل در ترمینال کانتینری) استفاده کنید؛ طبق تبصره جدید ۲۰۲۰ خریدار می‌تواند به حمل‌کننده دستور صدور بارنامه On-Board بدهد.",
 "📦 مثال واقعی کارخانه کاشی استان: تحویل ۲۰ کانتینر در ترمینال بندرعباس با قاعده FCA ریسک توقف و ضربه‌خوردگی جرثقیل بندر را ۱۰۰٪ از دوش صادرکننده برداشت.",
 "در حمل کانتینری صادراتی، کدام قاعده اینکوترمز ۲۰۲۰ جایگزین اصولی و کم‌ریسک FOB محسوب می‌شود؟",
 "قاعده EXW درب کارخانه بدون استثنا",
 "قاعده FCA تحویل به حمل‌کننده در ترمینال + شرط بارنامه On-Board",
 "قاعده CIF صرفاً بدون بیمه",
 "B", 35, 148, "۱۴۰۵/۰۸/۰۱"),
(2, "MIC-TAX-02", "مهلت طلایی ارسال صورت‌حساب الکترونیکی در سامانه مؤدیان", "مالیات و مؤدیان", 150, "ویژه مدیران مالی",
 "⏱️ تأخیر حتی ۱ روز پس از مهلت مجاز ارسال صورت‌حساب الکترونیکی در کارپوشه مؤدیان، موجب عدم پذیرش اعتبار مالیات بر ارزش افزوده خریدار و جریمه ماده ۲۲ می‌گردد!",
 "✅ قانون عملیاتی: تاریخ صدور صورت‌حساب باید دقیقاً منطبق بر رویداد مالی باشد و حداکثر ظرف مهلت مق قانونی سازمان امور مالیاتی در درگاه ثبت و کد یکتای ۲۲ رقمی دریافت شود.",
 "🧾 مثال عملیاتی: اتصال مستقیم ERP به پایانه فروشگاهی باعث صدور آنی شناسه یکتای ۲۲ رقمی در همان دقیقه تسویه فاکتور شد.",
 "شناسه اختصاصی معتبر هر صورت‌حساب رسمی در سامانه مؤدیان چند کاراکتر/رقم است؟",
 "۸ رقم",
 "۲۲ کاراکتر یکتا (TaxID)",
 "۱۰ رقم کد پستی",
 "B", 30, 119, "۱۴۰۵/۰۸/۰۱"),
(3, "MIC-NTSW-03", "رفع خطای عدم تطابق کد تعرفه HS در ثبت سفارش NTSW و EPL", "گمرک و لجستیک", 210, "ویژه بازرگانان و ترخیص",
 "🚢 مغایرت بین شرح تجاری پیش‌فاکتور (Proforma) و ردیف تعرفه ۸ رقمی کتاب مقررات صادرات و واردات، اصلی‌ترین علت قفل شدن پرونده در کارتابل کارشناس گمرک است.",
 "✅ فرمول ۳ مرحله‌ای: ۱) استعلام سابقه ارزش TSC در سامانه، ۲) تطبیق دقیق واحد اندازه‌گیری متعارف، ۳) درج دقیق شماره استاندارد اجباری پیش از تخصیص ارز.",
 "🏭 نتیجه در مجتمع پلیمر: کاهش زمان اخذ مجوز ثبت سفارش و ترخیص از ۱۴ روز به ۳ روز کاری.",
 "پیش از ثبت نهایی سفارش در سامانه NTSW، کدام بررسی از توقف پرونده در گمرک EPL جلوگیری می‌کند؟",
 "تطبیق ردیف تعرفه ۸ رقمی HS، سابقه ارزش TSC و مجوز استاندارد",
 "صرفاً ترجمه غیررسمی کاتالوگ",
 "حذف شماره پیش‌فاکتور",
 "A", 40, 96, "۱۴۰۵/۰۸/۰۱"),
(4, "MIC-AI-04", "فرمول پرامپت ۳ لایه برای شکار خریدار خارجی در بازار اوراسیا", "هوش مصنوعی تجاری", 180, "مهارت دیجیتال روز",
 "🤖 ارسال ایمیل سرد عمومی به لیست‌های قدیمی نمایشگاهی نرخ پاسخ زیر ۰.۵٪ دارد؛ ترکیب داده‌های گمرکی TradeMap با تحلیل هوش مصنوعی نرخ مذاکره واقعی را ۶ برابر می‌کند.",
 "✅ ساختار پرامپت استاندارد: [نقش تحلیلگر صادرات + کد HS دقیق ۶ رقمی] + [کشور هدف و حجم واردات سالانه] + [جدول مزیت رقابتی تحویل و تعرفه ترجیحی ایران-اوراسیا].",
 "📈 خروجی واقعی: شناسایی ۱۲ واردکننده فعال پلی‌اتیلن در قزاقستان و روسیه در کمتر از ۱۵ دقیقه.",
 "در نگارش پرامپت حرفه‌ای تحلیل بازار صادراتی، کلیدی‌ترین شناسه فنی کالا چیست؟",
 "نام کلی صنف",
 "کد بین‌المللی ۶ رقمی سیستم هماهنگ‌شده (HS Code)",
 "شماره تلفن داخلی کارخانه",
 "B", 35, 134, "۱۴۰۵/۰۸/۰۱");

INSERT IGNORE INTO micro_spaced_flashcards
(id, card_code, deck_category, front_prompt, back_answer, leitner_box, ease_factor, interval_days, next_review_label, reviews_count) VALUES
(1, "FC-UCP-101", "اعتبارات اسنادی UCP 600", "طبق ماده ۱۴ UCP 600، بانک‌ها حداکثر چند روز کاری بانکی برای بررسی مطابقت اسناد حمل فرصت دارند؟", "حداکثر ۵ روز کاری بانکی پس از روز ارائه اسناد (Maximum 5 Banking Days following the day of presentation).", 2, 2.50, 4, "موعد مرور: امروز 🔥", 3),
(2, "FC-CBAM-102", "مقررات کربن مرزی اروپا CBAM", "کدام صنایع صادراتی در فاز نخست مشمول گزارش‌دهی الزامی انتشار کربن مرزی اتحادیه اروپا (CBAM) هستند؟", "۶ صنعت کلیدی: فولاد و آهن، آلومینیوم، سیمان، کودهای شیمیایی، برق و هیدروژن.", 1, 2.35, 1, "موعد مرور: امروز 🔥", 2),
(3, "FC-TAX-103", "مالیات تکلیفی ماده ۸۶", "نرخ کسر مالیات تکلیفی حق‌التدریس و حق‌المشاوره اساتید مدعو خارج از رابطه استخدامی در قراردادهای آموزشی چقدر است؟", "۱۰ درصد مقطوع که توسط پرداخت‌کننده کسر و به حساب سازمان امور مالیاتی واریز و گواهی آن صادر می‌گردد.", 4, 2.75, 12, "مرور بعدی: ۱۲ روز دیگر ✅", 6),
(4, "FC-EUR-104", "توافق تجارت آزاد ایران و اوراسیا", "گواهی مبدأ ویژه بهره‌مندی از تعرفه صفر یا ترجیحی در صادرات کالا به اتحادیه اقتصادی اوراسیا چه نام دارد؟", "گواهی مبدأ فرم CT-3 صادره توسط مؤسسه آموزشی آدان.", 3, 2.60, 7, "مرور بعدی: ۷ روز دیگر", 4);

INSERT IGNORE INTO micro_daily_challenges
(id, challenge_code, scenario_title, scenario_case, option_1, option_2, option_3, correct_choice, explanation_key, bonus_xp, participants_today) VALUES
(1, "DCH-1405-0801", "چالش ۶۰ ثانیه‌ای امروز مدیران: مغایرت تاریخ بارنامه در اعتبار اسنادی!", "خریدار خارجی برای شما L/C گشایش کرده که آخرین مهلت حمل آن ۳۰ مهر است. کشتی در تاریخ ۲۹ مهر بارگیری شده اما تاریخ صدور بارنامه ۲ آبان درج گردیده و یادداشت On-Board مورخ ۲۹ مهر روی آن ممهور شده است. آیا اسناد دارای مغایرت (Discrepancy) است؟",
 "بله، تاریخ صدور بارنامه ملاک است و بانک اسناد را رد می‌کند.",
 "خیر! طبق ماده ۲۰ UCP 600، تاریخ درج‌شده در یادداشت ممهور On-Board (۲۹ مهر) تاریخ واقعی حمل تلقی می‌شود و کاملاً معتبر است.",
 "بارنامه باید به کلی باطل و قرارداد فسخ شود.",
 2, "✅ آفرین! طبق بند a ماده ۲۰ مقررات UCP 600، هنگامی که بارنامه حاوی یادداشت تاریخ‌دار On-Board باشد، همان تاریخ بارگیری ملاک تاریخ حمل است نه تاریخ صدور سند.", 50, 84);

INSERT IGNORE INTO micro_job_aids
(id, aid_code, aid_title, target_desk, format_type, key_steps_summary, audio_script_summary, downloads_count, created_shamsi) VALUES
(1, "AID-EXP-01", "چک‌لیست ۷ گامی کنترل اسناد حمل پیش از تحویل به بانک ارزی", "میز کارشناس بازرگانی خارجی", "تقلب‌نامه ۱ صفحه‌ای PDF/Print", "۱. تطبیق دقیق نگارش نام خریدار | ۲. کنترل مهلت ارائه ۲۱ روزه | ۳. مهر On-Board بارنامه | ۴. پوشش ۱۱۰٪ بیمه کلوز A | ۵. گواهی مبدأ صادره از مرجع مجاز | ۶. امضای سیاهه تجاری | ۷. تطبیق وزن ناخالص در همه اسناد.", "پادکست ۱۸۰ ثانیه‌ای: قبل از ارسال مدارک به بانک عامل، این هفت مورد حیاتی را در سه دقیقه کنترل کنید تا حتی یک دلار کارمزد مغایرت اسنادی نپردازید.", 214, "۱۴۰۵/۰۸/۰۱"),
(2, "AID-FIN-02", "جدول سریع مهلت‌ها و جرایم بخشش‌پذیر سامانه مؤدیان و ماده ۱۶۹", "میز حسابدار ارشد و مدیر مالی", "اینفوگرافیک رومیزی مدیریتی", "کنترل تطبیق شناسه کالا/خدمت ۱۳ رقمی، تفکیک فروش نقدی و نسیه، ثبت صورت‌حساب اصلاحی/ابطالی و استرداد مالیات صادرات.", "پادکست ۱۵۰ ثانیه‌ای: خلاصه اجرایی ضوابط ثبت صورت‌حساب اصلاحی و برگشت از فروش در کارپوشه مالیاتی شرکت‌های تولیدی.", 179, "۱۴۰۵/۰۸/۰۱");

INSERT IGNORE INTO micro_skill_gap_links
(id, prescription_code, detected_gap_topic, source_module, prescribed_capsule_code, estimated_fix_minutes, impact_note) VALUES
(1, "GAP-FIX-01", "شکاف جزئی در تطبیق اسناد حمل و اینکوترمز کانتینری", "پایپ‌لاین استخدام ATS (پرونده APP-1405-7703)", "MIC-INC-01", 3, "افزایش امتیاز آمادگی مصاحبه شغلی از ۸۷٪ به ۹۵٪ تنها با ۳ دقیقه مطالعه هدفمند"),
(2, "GAP-FIX-02", "نیاز به مرور شناسه یکتای صورت‌حساب الکترونیکی", "ارزیابی شایستگی واحد مالی", "MIC-TAX-02", 3, "رفع کامل خطای ثبت فاکتور رسمی پیش از آزمون پایانی دوره");

-- =====================================================================
-- SEED DATA FOR v21.0: CONTEXTUAL PAGE HELP SOP NOTES & FEEDBACK ANALYTICS (#159 - #160)
-- =====================================================================

INSERT IGNORE INTO erp_help_custom_notes (id, route_key, local_sop_title, local_sop_body, contact_extension, video_guide_url, updated_by, updated_shamsi) VALUES
(1, "dashboard", "دستورالعمل روزانه بررسی شاخص‌های کلیدی فرماندهی", "مدیران محترم در ابتدای هر روز کاری ابتدا کارت هشدارهای هوشمند، وضعیت تراز حسابداری (صفر ریال مغایرت) و کارتابل امضاهای منتظر اقدام را بازبینی نمایند.", "داخلی ۱۰۱ — دفتر مدیرکل آموزش", "", "دکتر کیارش رادمهر", "۱۴۰۵/۰۸/۰۱"),
(2, "career-hub", "ضابطه تأیید آگهی‌های شغلی کارخانجات دانش‌پذیر آدان", "پیش از فعال‌سازی نشان «کارفرمای همکار آدان»، اطلاعات سازمان، راه ارتباطی و سابقه همکاری آموزشی بررسی گردد.", "داخلی ۲۴۵ — واحد اشتغال و صنعت", "", "کارشناس مسئول کاریابی", "۱۴۰۵/۰۸/۰۱"),
(3, "finance", "الزام کنترل تراز آزمایشی پیش از ارسال به سامانه مؤدیان", "کلیه اسناد استرداد شهریه و کسور مالیات تکلیفی ماده ۸۶ اساتید باید پیش از بستن دوره ماهانه دارای اختلاف تراز دقیق صفر ریال باشند.", "داخلی ۳۱۰ — مدیریت مالی آموزش", "", "مدیر امور مالی", "۱۴۰۵/۰۸/۰۱");

INSERT IGNORE INTO erp_help_feedback_logs (id, route_key, user_fullname, is_helpful, suggestion_note, created_shamsi) VALUES
(1, "microlearning", "مهندس مهرداد شریفی", 1, "توضیح الگوریتم مرور فاصله‌دار لایتنر SM-2 بسیار دقیق و راهگشا بود.", "۱۴۰۵/۰۸/۰۱"),
(2, "system-settings", "سرکار خانم مهندس پگاه کاظمی", 1, "بخش پیش‌نمایش زنده فونت و پالت رنگی بدون رفرش عالی توضیح داده شده است.", "۱۴۰۵/۰۸/۰۱"),
(3, "iam-access", "دکتر کیارش رادمهر", 1, "راهنمای تفاوت سطح دید داده شعبه‌ای و شرکتی بسیار شفاف است.", "۱۴۰۵/۰۸/۰۱");

-- =====================================================================
-- SEED DATA FOR OFFICE AUTOMATION & E-CORRESPONDENCE (#161 - #164)
-- =====================================================================

INSERT IGNORE INTO oa_letters
(id, indicator_no, letter_type, priority_level, confidentiality, sender_unit, recipient_org, subject_title, letter_body, attachment_note, signatory_name, sign_status, qr_verify_code, created_shamsi) VALUES
(1, "۱۴۰۵/د/۱۰۴۱", "صادره", "فوری", "عادی", "مدیریت آموزش و پژوهش مؤسسه آموزشی آدان", "اداره کل گمرکات استان — معاونت امور بازرگانی", "معرفی دانش‌آموختگان دوره جامع قوانین گمرکی و سامانه جامع تجارت", "با سلام و احترام؛\nبدین‌وسیله فهرست اسامی ۳۲ نفر از مدیران بازرگانی واحدهای تولیدی و صادراتی دانش‌پذیر آدان که دوره تخصصی «مقررات گمرکی، ثبت سفارش و اسناد حمل بین‌المللی» را با موفقیت به پایان رسانده‌اند، جهت استحضار و بهره‌برداری قانونی در فرآیندهای ترخیص ایفاد می‌گردد.", "فهرست اسامی ممهور (۲ برگ)", "دکتر کیارش رادمهر — مدیرکل آموزش", "امضاشده و ثبت در دبیرخانه", "OA-VERIFY-1405-1041", "۱۴۰۵/۰۸/۰۱"),
(2, "۱۴۰۵/د/۱۰۴۲", "وارده", "آنی", "عادی", "شرکت مجتمع فولاد و ذوب‌آهن زاگرس (دبیرخانه)", "ریاست محترم واحد آموزش مؤسسه آموزشی آدان", "درخواست برگزاری دوره اختصاصی اعتبارات اسنادی برای کارشناسان بازرگانی خارجی", "با سلام و احترام؛\nپیرو قرارداد سالانه توانمندسازی سرمایه انسانی، خواهشمند است دستور فرمایید نسبت به برنامه‌ریزی و اعلام تقویم کارگاه عملی «اعتبارات اسنادی و ضمانت‌نامه‌های ارزی» ویژه ۱۸ نفر از کارشناسان بازرگانی خارجی این مجتمع اقدام لازم صورت پذیرد.", "فرم نیازسنجی پرسنل", "مهندس کامران بهرامی — مدیر آموزش فولاد زاگرس", "ثبت وارده — ارجاع‌شده", "OA-VERIFY-1405-1042", "۱۴۰۵/۰۸/۰۱"),
(3, "۱۴۰۵/د/۱۰۴۳", "داخلی", "عادی", "محرمانه", "واحد برنامه‌ریزی و امتحانات", "مدیریت امور مالی و ذی‌حسابی اتاق", "درخواست تسویه حق‌التدریس اساتید مدعو نیمسال پاییز پس از کسر مالیات ماده ۸۶", "احتراماً به پیوست خلاصه کارکرد آموزشی و فرم ارزشیابی اساتید مدعو کارگاه‌های مهرماه ایفاد می‌گردد. خواهشمند است دستور فرمایید پس از اعمال کسور قانونی ماده ۸۶، نسبت به صدور حواله بانکی اقدام گردد.", "خلاصه ساعت تدریس تأییدشده", "مهندس پگاه کاظمی — کارشناس مسئول آموزش", "پیش‌نویس منتظر امضا", "OA-VERIFY-1405-1043", "۱۴۰۵/۰۸/۰۱");

INSERT IGNORE INTO oa_letter_referrals
(id, letter_id, from_person, to_person_unit, action_command, paraph_margin_note, deadline_shamsi, referral_status, created_shamsi) VALUES
(1, 2, "دکتر کیارش رادمهر (مدیرکل آموزش)", "مهندس پگاه کاظمی — واحد برنامه‌ریزی آموزش", "جهت اقدام فوری", "لطفاً ظرفیت تالار خلیج فارس بررسی و پیش‌نویس تقویم اجرایی ظرف ۴۸ ساعت به شرکت فولاد زاگرس اعلام شود.", "۱۴۰۵/۰۸/۰۳", "در دست اقدام", "۱۴۰۵/۰۸/۰۱"),
(2, 3, "مهندس پگاه کاظمی (واحد آموزش)", "جناب آقای بهمنی — مدیریت امور مالی", "جهت صدور دستور پرداخت", "کارکرد ساعات تدریس و حدنصاب رضایت‌سنجی بالای ۹۲٪ مورد تأیید واحد آموزش می‌باشد.", "۱۴۰۵/۰۸/۰۵", "در دست اقدام", "۱۴۰۵/۰۸/۰۱"),
(3, 1, "دبیرخانه مرکزی اتاق", "بایگانی اسناد رسمی و واحد کارت بازرگانی", "بایگانی در پرونده", "نسخه چاپی ممهور از طریق پیک سازمانی ارسال و رسید تحویل ثبت گردید.", "۱۴۰۵/۰۸/۰۲", "اقدام و مختومه شد", "۱۴۰۵/۰۸/۰۱");

INSERT IGNORE INTO oa_admin_requests
(id, req_code, requester_name, unit_name, req_category, date_range_or_amount, description_note, approval_status, approver_note, created_shamsi) VALUES
(1, "OA-REQ-401", "مهندس پگاه کاظمی", "واحد برنامه‌ریزی آموزش", "حکم مأموریت اداری", "۱۴۰۵/۰۸/۰۶ لغایت ۱۴۰۵/۰۸/۰۷ (۲ روز)", "اعزام به شعبه اتاق شهرستان جهت نظارت بر برگزاری آزمون جامع متقاضیان کارت بازرگانی", "تأیید نهایی مدیریت", "با پرداخت حق مأموریت طبق آیین‌نامه موافقت شد.", "۱۴۰۵/۰۸/۰۱"),
(2, "OA-REQ-402", "مهندس سامان فرهادی", "واحد سمعی‌بصری و تالارها", "درخواست تنخواه و تدارکات", "۱۸,۵۰۰,۰۰۰ ریال", "تهیه ملزومات پذیرایی و بسته‌های آموزشی کارگاه تخصصی صادرات روز چهارشنبه", "منتظر تأیید مدیریت", "—", "۱۴۰۵/۰۸/۰۱"),
(3, "OA-REQ-403", "سرکار خانم مریم رضایی", "دبیرخانه و پذیرش", "مرخصی استحقاقی / ساعتی", "پنج‌شنبه ۱۴۰۵/۰۸/۰۸ (۱ روز)", "مرخصی استحقاقی روزانه با هماهنگی جانشین میز پذیرش", "منتظر تأیید مدیریت", "—", "۱۴۰۵/۰۸/۰۱");

INSERT IGNORE INTO oa_meeting_minutes
(id, minute_code, meeting_title, chairperson, attendees_summary, key_resolutions, responsible_owner, due_shamsi, execution_status, created_shamsi) VALUES
(1, "MIN-1405-101", "جلسه شورای راهبری آموزش و توانمندسازی صادرکنندگان استان", "دکتر کیارش رادمهر", "مدیرکل آموزش، مدیر مالی، رئیس کمیسیون صادرات، نماینده واحد صنعت (۷ نفر)", "۱. تصویب تقویم ۱۲ کارگاه عملی تجارت خارجی نیمسال دوم | ۲. اختصاص ۲۰٪ تخفیف ویژه واحدهای تولیدی شهرک‌های صنعتی | ۳. اتصال مستقیم کارنامه قبول‌شدگان به بانک رزومه کاریابی.", "واحد برنامه‌ریزی آموزش", "۱۴۰۵/۰۸/۱۵", "ابلاغ‌شده — در حال پیگیری", "۱۴۰۵/۰۸/۰۱"),
(2, "MIN-1405-102", "کمیته کنترل کیفی و انضباط مالی دوره‌های سازمانی", "مدیر امور مالی اتاق", "مدیر مالی، کارشناس مسئول قراردادها، بازرس داخلی اتاق (۴ نفر)", "۱. الزام تسویه قسط اول پیش از صدور کارت ورود به جلسه | ۲. ارسال خودکار صورت‌حساب الکترونیکی در پایان هر ماه.", "مدیریت امور مالی", "۱۴۰۵/۰۸/۱۰", "اجرا و مختومه شد", "۱۴۰۵/۰۸/۰۱");

-- =====================================================================
-- SEED DATA FOR COMPREHENSIVE ENTERPRISE BI SUITE (#165 - #170)
-- =====================================================================

INSERT IGNORE INTO bi_dashboards
(id, slug, title, subtitle, category, accent_color, layout_density, created_via, is_default, created_by_name, updated_shamsi) VALUES
(1, "executive_command", "داشبورد جامع فرماندهی و هیئت‌رییسه اتاق", "نمای ۳۶۰ درجه درآمد، قیف فروش سازمانی، دوره‌ها، شعب شهرستان‌ها و مکاتبات اداری", "مدیریت کلان", "#4f46e5", "balanced", "click", 1, "دکتر کیارش رادمهر", "۱۴۰۵/۰۸/۰۱"),
(2, "finance_revenue_board", "داشبورد تخصصی مالی، صورت‌حساب‌ها و اسناد حسابداری", "پایش زنده تحقق درآمد، مالیات بر ارزش افزوده، اسناد ۴ سطحی و بودجه دفاتر", "مالی و بودجه", "#0f766e", "compact", "drag_drop", 0, "مدیر امور مالی", "۱۴۰۵/۰۸/۰۱"),
(3, "academic_operations_board", "داشبورد عملیات آموزشی، کارت بازرگانی و اشتغال", "تحلیل ثبت‌نام، نمرات، پرونده‌های کارت بازرگانی، کاریابی و کارتابل اداری", "آموزش و عملیات", "#d97706", "spacious", "voice", 0, "مهندس پگاه کاظمی", "۱۴۰۵/۰۸/۰۱");

INSERT IGNORE INTO bi_dashboard_widgets
(id, dashboard_id, widget_code, title, subtitle, dataset_key, dimension_field, metric_field, agg_func, filter_field, filter_op, filter_val, chart_type, col_span, sort_order, color_palette, created_via, updated_shamsi) VALUES
(1, 1, "WDG-EXEC-01", "ترکیب شهریه دوره‌ها به تفکیک سطح تخصصی", "مقایسه حجم ریالی کاتالوگ دوره‌های مقدماتی، میانی و پیشرفته", "courses_mart", "level", "tuition_rial", "SUM", "", "=", "", "bar", 6, 10, "indigo", "drag_drop", "۱۴۰۵/۰۸/۰۱"),
(2, 1, "WDG-EXEC-02", "قیف فروش سازمانی و ارزش فرصت‌های CRM", "توزیع ریالی مذاکرات و قراردادهای سازمانی در مراحل فروش", "crm_mart", "stage", "estimated_value_rial", "SUM", "", "=", "", "funnel", 6, 20, "emerald", "click", "۱۴۰۵/۰۸/۰۱"),
(3, 1, "WDG-EXEC-03", "سهم وضعیت صورت‌حساب‌ها و وصولی خزانه", "نسبت فاکتورهای پرداخت‌شده، اقساطی و در انتظار تسویه", "invoices_mart", "status", "total_rial", "SUM", "", "=", "", "donut", 4, 30, "amber", "text", "۱۴۰۵/۰۸/۰۱"),
(4, 1, "WDG-EXEC-04", "عملکرد بودجه و تربیت فراگیر در دفاتر شهرستان‌ها", "مقایسه چندبعدی عملکرد شعب شهرستانی استان", "branches_mart", "county_name", "spent_budget_rial", "SUM", "", "=", "", "radar", 4, 40, "violet", "voice", "۱۴۰۵/۰۸/۰۱"),
(5, 1, "WDG-EXEC-05", "پایش وضعیت نامه‌های رسمی اتوماسیون اداری", "توزیع مکاتبات دبیرخانه بر پایه نوع نامه", "oa_mart", "letter_type", "id", "COUNT", "", "=", "", "hbar", 4, 50, "cyan", "drag_drop", "۱۴۰۵/۰۸/۰۱"),
(6, 1, "WDG-EXEC-06", "ماتریس حرارتی پیشرفت و نمره ثبت‌نام‌کنندگان", "میانگین نمره نهایی فراگیران به تفکیک کانال جذب", "enrollments_mart", "source", "final_score", "AVG", "", "=", "", "line", 12, 60, "indigo", "click", "۱۴۰۵/۰۸/۰۱"),
(7, 2, "WDG-FIN-01", "گردش بدهکار اسناد حسابداری ۴ سطحی به تفکیک حساب کل", "توازن حساب‌های کل در دفتر روزنامه و کل", "vouchers_mart", "kol_account", "debit_rial", "SUM", "", "=", "", "bar", 6, 10, "emerald", "drag_drop", "۱۴۰۵/۰۸/۰۱"),
(8, 2, "WDG-FIN-02", "ترکیب روش‌های پرداخت در صورت‌حساب‌های صادره", "نقدی، اقساطی و سهمیه سازمانی", "invoices_mart", "payment_mode", "total_rial", "SUM", "", "=", "", "donut", 6, 20, "amber", "click", "۱۴۰۵/۰۸/۰۱"),
(9, 3, "WDG-ACA-01", "وضعیت احراز صلاحیت پرونده‌های کارت بازرگانی", "تفکیک پرونده‌های تأییدشده و در جریان آموزش الزامی", "cards_mart", "clearance_status", "exam_score", "AVG", "", "=", "", "bar", 6, 10, "indigo", "voice", "۱۴۰۵/۰۸/۰۱"),
(10, 3, "WDG-ACA-02", "تقاضای استخدام صنایع عضو در تابلوی کاریابی", "تعداد متقاضیان جذب‌شده به تفکیک شهر صنعتی", "career_mart", "city_location", "applicants_count", "SUM", "", "=", "", "hbar", 6, 20, "violet", "text", "۱۴۰۵/۰۸/۰۱");

INSERT IGNORE INTO bi_custom_reports
(id, report_code, title, category, dataset_key, dimension_field, metric_field, secondary_metric, agg_func, filter_field, filter_op, filter_val, sort_dir, row_limit, chart_type, natural_query_text, ai_narrative, created_via, created_by_name, created_shamsi) VALUES
(1, "RPT-BI-101", "تحلیل جامع ظرفیت درآمدی دوره‌ها به تفکیک شیوه برگزاری", "آموزش و برنامه‌ریزی", "courses_mart", "delivery_mode", "tuition_rial", "duration_hours", "SUM", "", "=", "", "DESC", 25, "bar", "مجموع شهریه و ساعت دوره‌ها به تفکیک شیوه برگزاری با نمودار ستونی", "دوره‌های حضوری-کارگاهی و آنلاین همزمان بیشترین سهم ارزش ریالی کاتالوگ را به خود اختصاص داده‌اند؛ پیشنهاد می‌شود ظرفیت کارگاه‌های عملی صادرات ۲۰٪ افزایش یابد.", "click", "دکتر کیارش رادمهر", "۱۴۰۵/۰۸/۰۱"),
(2, "RPT-BI-102", "گزارش ارزش قیف فروش سازمانی به تفکیک مرحله مذاکره", "فروش سازمانی و CRM", "crm_mart", "stage", "estimated_value_rial", "probability_pct", "SUM", "", "=", "", "DESC", 25, "funnel", "قیف فروش سازمانی و مبلغ قراردادهای پیشنهادی بر اساس مرحله مذاکره", "تمرکز پیگیری تلفنی و جلسه حضوری بر پرونده‌های مرحله ارسال پیش‌فاکتور، نرخ تبدیل قراردادهای سالانه B2B را به شکل محسوسی ارتقا می‌دهد.", "drag_drop", "مدیر CRM سازمانی", "۱۴۰۵/۰۸/۰۱"),
(3, "RPT-BI-103", "پایش مصرف سهمیه آموزشی شرکت‌های عضو به تفکیک صنعت", "امور بنگاه‌ها", "orgs_mart", "industry", "used_quota_hours", "annual_quota_hours", "SUM", "", "=", "", "DESC", 25, "radar", "مقایسه ساعات سهمیه مصرف‌شده صنایع عضو به تفکیک بخش صنعتی", "صنایع فولاد، پلیمر و غذایی بیشترین نرخ بهره‌برداری از سهمیه آموزشی اتاق را ثبت کرده‌اند؛ ارسال بسته پیشنهادی اختصاصی برای سایر صنایع توصیه می‌شود.", "text", "مهندس پگاه کاظمی", "۱۴۰۵/۰۸/۰۱"),
(4, "RPT-BI-104", "تحلیل بار ترافیکی مکاتبات دبیرخانه بر اساس سطح فوریت", "اتوماسیون اداری", "oa_mart", "priority_level", "id", "id", "COUNT", "", "=", "", "DESC", 25, "donut", "تعداد نامه‌های اتوماسیون اداری به تفکیک فوریت", "بخش قابل توجهی از مکاتبات دارای قید فوری/آنی هستند؛ فعال‌سازی امضای دیجیتال مستقیم زمان گردش مکاتبات را به کمتر از ۴ ساعت رسانده است.", "voice", "مسئول دبیرخانه", "۱۴۰۵/۰۸/۰۱");

INSERT IGNORE INTO bi_goals_okrs
(id, goal_code, title, department_owner, horizon_label, live_metric_source, baseline_value, manual_boost_value, target_value, unit_label, weight_pct, alert_threshold_pct, key_results_note, created_via, updated_shamsi) VALUES
(1, "OKR-1405-01", "تحقق درآمد وصولی و صورت‌حساب‌های آموزشی نیمسال", "مدیریت امور مالی", "نیمسال دوم ۱۴۰۵", "invoices_total_rial", 0, 185000000, 450000000, "ریال", 25, 70, "افزایش قراردادهای سازمانی صنایع بزرگ و تسویه بهنگام اقساط", "click", "۱۴۰۵/۰۸/۰۱"),
(2, "OKR-1405-02", "گسترش ارزش پایپ‌لاین قراردادهای سازمانی (B2B CRM)", "واحد توسعه بازار و CRM", "سال مالی ۱۴۰۵", "crm_pipeline_rial", 0, 120000000, 1500000000, "ریال", 20, 65, "جذب ۱۵ واحد صنعتی جدید از شهرک‌های صنعتی استان", "drag_drop", "۱۴۰۵/۰۸/۰۱"),
(3, "OKR-1405-03", "ارتقای میانگین امتیاز رضایت کیفی فراگیران از دوره‌ها", "معاونت آموزش و کیفیت", "فصل پاییز ۱۴۰۵", "courses_avg_rating_pct", 82, 0, 96, "درصد", 15, 85, "ارزشیابی مستمر اساتید و بازنگری کارگاه‌های کاربردی", "text", "۱۴۰۵/۰۸/۰۱"),
(4, "OKR-1405-04", "توسعه پوشش تربیت مهارت‌آموختگان در دفاتر شهرستان‌ها", "امور شعب شهرستانی", "سال ۱۴۰۵", "branches_learners_sum", 0, 40, 650, "نفر", 15, 70, "اجرای دوره‌های مشترک صادرات و مالیات در تمام شهرستان‌ها", "voice", "۱۴۰۵/۰۸/۰۱"),
(5, "OKR-1405-05", "شتاب‌بخشی به ثبت و امضای مکاتبات رسمی بدون کاغذ", "دبیرخانه و اتوماسیون اداری", "پاییز ۱۴۰۵", "oa_letters_count", 0, 14, 25, "فقره نامه", 10, 60, "گذار ۱۰۰ درصدی مکاتبات واحدها به کارتابل دیجیتال", "click", "۱۴۰۵/۰۸/۰۱"),
(6, "OKR-1405-06", "تکمیل جذب متقاضیان معرفی‌شده به فرصت‌های شغلی اعضا", "مرکز کاریابی و اشتغال", "نیمسال دوم ۱۴۰۵", "career_applicants_sum", 0, 15, 120, "متقاضی", 15, 65, "اتصال مستقیم کارنامه نفرات برتر دوره‌ها به کارفرمایان عضو", "text", "۱۴۰۵/۰۸/۰۱");

INSERT IGNORE INTO bi_whatif_scenarios
(id, scenario_code, title, tuition_delta_pct, enrollment_growth_pct, b2b_conversion_pct, cost_change_pct, projected_revenue_rial, projected_surplus_rial, ai_recommendation, created_by_name, created_shamsi) VALUES
(1, "SCN-BI-01", "سناریوی توسعه دوره‌های صادراتی اوراسیا با تخفیف گروهی اعضا", 10, 35, 30, -8, 685000000, 294000000, "افزایش ۳۵ درصدی ظرفیت به همراه بهینه‌سازی ۸ درصدی هزینه‌های اجرایی از طریق کلاس‌های ترکیبی، حاشیه مازاد عملیاتی را ۴۲٪ ارتقا می‌دهد.", "دکتر کیارش رادمهر", "۱۴۰۵/۰۸/۰۱"),
(2, "SCN-BI-02", "سناریوی تثبیت شهریه فعلی با تمرکز بر قراردادهای B2B شهرک‌ها", 0, 20, 45, -5, 590000000, 241000000, "تثبیت شهریه در کنار نرخ تبدیل ۴۵٪ مذاکرات سازمانی، ریسک ریزش متقاضیان آزاد را به حداقل می‌رساند.", "مدیر امور مالی", "۱۴۰۵/۰۸/۰۱");

INSERT IGNORE INTO bi_report_schedules
(id, schedule_code, report_title, dataset_key, frequency_label, cron_expr, delivery_channel, recipients_list, export_format, is_active, last_run_shamsi) VALUES
(1, "SCH-BI-01", "خلاصه مدیریتی درآمد، وصولی و انحراف بودجه هفتگی", "invoices_mart", "هفتگی — شنبه‌ها ساعت ۰۷:۳۰", "30 7 * * 6", "کارتابل اتوماسیون + ایمیل سازمانی", "مدیریت مؤسسه آدان، دبیرکل، مدیرکل آموزش، مدیر مالی", "PDF A4 + Excel", 1, "۱۴۰۵/۰۸/۰۱"),
(2, "SCH-BI-02", "پایش قیف قراردادهای سازمانی و سهمیه مصرفی اعضا", "crm_mart", "دو هفته یک‌بار — دوشنبه‌ها ساعت ۰۹:۰۰", "0 9 * * 1", "کارتابل مدیریتی + پیام‌رسان بومی", "واحد CRM، معاونت آموزش", "CSV UTF-8", 1, "۱۴۰۵/۰۸/۰۱"),
(3, "SCH-BI-03", "کارنامه عملکرد دفاتر شهرستان‌ها و پرونده‌های کارت بازرگانی", "branches_mart", "ماهانه — یکم هر ماه ساعت ۰۸:۰۰", "0 8 1 * *", "کارتابل اتوماسیون اداری", "مسئولان شعب شهرستان‌ها، واحد نظارت", "PDF A4", 1, "۱۴۰۵/۰۸/۰۱");

-- =====================================================================
-- v26.0 SEED DATA: NEXT-GEN TMS PATHS, INTERACTIVE LMS, OMNI-CHANNEL SOCIAL CAMPAIGNS & AI MARKET RESEARCH
-- =====================================================================

INSERT IGNORE INTO tms_learning_paths
(id, path_code, title, target_persona, level_badge, courses_json, total_hours, bundle_tuition_rial, discount_pct, enrolled_learners, ai_roadmap_summary, status, created_shamsi) VALUES
(1, "PATH-EXP-01", "دیپلم جامع مدیریت صادرات، اینکوترمز ۲۰۲۰ و رفع تعهد ارزی", "مدیران بازرگانی خارجی و صادرکنندگان نمونه", "دیپلم عالی ۳ مرحله‌ای", '["جامع کاربردی اینکوترمز ۲۰۲۰ و اسناد حمل","مقررات مکانیسم تعدیل کربن مرزی اتحادیه اروپا (CBAM)","اعتبارات اسنادی UCP 600 و بانکداری بین‌الملل"]', 56, 128000000, 25, 29, "طراحی‌شده بر اساس بیشترین شکاف مهارتی واحدهای صادراتی استان؛ تکمیل هر ۳ گام منجر به صدور گواهینامه جامع دوزبانه QR می‌شود.", "active", "۱۴۰۵/۰۸/۰۱"),
(2, "PATH-FIN-02", "مسیر خبرگی مالیات ستانی نوین، سامانه مؤدیان و دفاعیه مالیاتی", "مدیران مالی و حسابداران ارشد صنایع", "گواهینامه تخصصی ۲ مرحله‌ای", '["قوانین سامانه مؤدیان و پایانه‌های فروشگاهی","دادرسی مالیاتی و لایحه‌نویسی هیئت‌های حل اختلاف"]', 36, 82000000, 20, 34, "پوشش صددرصدی نیازهای اجرایی واحدهای مالی کارخانجات دانش‌پذیر آدان.", "active", "۱۴۰۵/۰۸/۰۲"),
(3, "PATH-AI-03", "آکادمی تحول دیجیتال و هوش مصنوعی کاربردی در صنعت و بازرگانی", "مدیران‌عامل، مدیران R&D و فروش سازمانی", "مسیر ویژه مدیران آینده", '["هوش مصنوعی در شکار خریدار خارجی و بازاریابی B2B","اتوماسیون فرایندهای بازرگانی و تحلیل داده گمرکی"]', 40, 96000000, 22, 22, "مسیر پیشرو اقیانوس آبی با بالاترین نرخ رضایت و بازگشت سرمایه سریع برای بنگاه‌ها.", "active", "۱۴۰۵/۰۸/۰۳");

INSERT IGNORE INTO tms_pricing_scenarios
(id, scenario_code, course_title, base_tuition_rial, member_discount_pct, early_bird_pct, instructor_total_cost_rial, venue_ops_cost_rial, predicted_enrollments, breakeven_seats, projected_net_profit_rial, created_shamsi) VALUES
(1, "PRC-1405-01", "جامع کاربردی اینکوترمز ۲۰۲۰ و اسناد حمل بین‌المللی", 52000000, 25, 10, 190000000, 68000000, 28, 7, 834000000, "۱۴۰۵/۰۸/۰۱"),
(2, "PRC-1405-02", "مقررات مکانیسم کربن مرزی اروپا (EU CBAM) ویژه صنایع", 72000000, 25, 15, 240000000, 75000000, 24, 6, 981000000, "۱۴۰۵/۰۸/۰۲");

INSERT IGNORE INTO lms_interactive_quizzes
(id, lesson_id, appear_at_sec, timestamp_label, question_text, opt_a, opt_b, opt_c, opt_d, correct_opt, ai_explanation, xp_reward) VALUES
(1, 1, 145, "02:25", "در قاعده CIP ویرایش ۲۰۲۰ اینکوترمز، فروشنده مکلف به تهیه چه سطح پوششی از بیمه باربری بین‌المللی است؟", "حداقل پوشش کلوز C انستیتو لندن", "حداکثر پوشش تمام‌خطر کلوز A انستیتو بیمه لندن", "صرفاً بیمه آتش‌سوزی انبار مبدأ", "فروشنده هیچ تعهد بیمه‌ای ندارد", "B", "در بازنگری ۲۰۲۰ مرجع بین‌المللی ICC (ICC)، سطح پوشش بیمه الزامی در ترم CIP به کلوز A (تمام‌خطر) ارتقا یافت، اما در CIF همچنان کلوز C باقی ماند.", 60),
(2, 1, 320, "05:20", "در حمل کانتینری صادرات خشکبار از کارخانه داخل کشور، کدام ترم جایگزین حرفه‌ای و کم‌ریسک‌تر به جای FOB سنتی است؟", "EXW بدون بارگیری", "FCA (تحویل به حمل‌کننده در ترمینال کانتینری)", "FAS کنار کشتی فله‌بر", "DDP با ترخیص گمرک مقصد", "B", "طبق توصیه صریح ICC، برای محموله‌های کانتینری که پیش از عرشه کشتی به ترمینال تحویل داده می‌شوند، FCA ریسک خاکستری آسیب در محوطه بندری را حذف می‌کند.", 60),
(3, 2, 210, "03:30", "حداکثر مهلت بانک گشایش‌کننده اعتبار اسنادی برای اعلام مغایرت اسناد طبق ماده ۱۴ مقررات UCP 600 چند روز است؟", "۵ روز کاری بانکی پس از روز ارائه اسناد", "۲۱ روز تقویمی از تاریخ بارنامه", "۱۰ روز کاری پس از رسیدن کشتی", "۴۸ ساعت از تاریخ صدور گواهی مبدأ", "A", "ماده ۱۴ بند ب UCP 600 صراحتاً سقف زمانی بررسی ظاهر اسناد توسط بانک را حداکثر ۵ روز بانکی متعاقب روز ارائه تعیین کرده است.", 60);

INSERT IGNORE INTO lms_ai_study_cards
(id, course_id, lesson_id, card_type, title, content_body, mastery_tag, created_by_name, created_shamsi) VALUES
(1, 1, 1, "summary", "چکیده طلایی ۱ دقیقه‌ای تفاوت‌های کلیدی اینکوترمز ۲۰۲۰", "• گروه E و F: کرایه حمل اصلی با خریدار است (EXW, FCA, FAS, FOB).\n• گروه C: کرایه حمل با فروشنده است ولی ریسک در مبدأ منتقل می‌شود (CFR, CIF, CPT, CIP).\n• گروه D: هم هزینه و هم ریسک تا نقطه مقصد بر عهده فروشنده است (DAP, DPU, DDP).", "مرور سریع شب امتحان", "معلم هوشمند LMS", "۱۴۰۵/۰۸/۰۱"),
(2, 1, 1, "case_study", "کیس عملی استان: خطای رایج صادرکننده کاشی و سرامیک در ترم FOB بندرعباس", "یک واحد تولیدی محموله ۲۰ کانتینری خود را در ترمینال بندرعباس تحویل داد و پیش از بارگیری روی عرشه، یک کانتینر در محوطه آسیب دید. به دلیل درج FOB به جای FCA، خسارت ۴۸ هزار دلاری بر عهده فروشنده ماند!", "پرونده واقعی صادراتی", "معلم هوشمند LMS", "۱۴۰۵/۰۸/۰۲");

INSERT IGNORE INTO social_media_posts
(id, post_code, campaign_id, platform, content_format, target_course_title, hook_headline, caption_body, hashtags, utm_url, promo_code, scheduled_shamsi, impressions_count, engagements_count, clicks_count, leads_generated, enrollments_converted, spend_rial, revenue_rial, publish_status) VALUES
(1, "SOC-IG-101", 1, "instagram", "پست اسلایدی ۸ برگی (Carousel)", "جامع کاربردی اینکوترمز ۲۰۲۰ و اسناد حمل", "۳ اشتباه مرگبار در قراردادهای صادراتی که سود یک سال کارخانه را می‌بلعد!", "ورق بزنید 👉 در اسلاید ۴ واقعی‌ترین پرونده خسارت بندرعباس را باز کردیم!\nاگر مدیر بازرگانی یا صادرکننده هستید، انتخاب اشتباه بین FOB و FCA می‌تواند هزاران دلار ریسک بیمه‌نشده روی دست شما بگذارد.\n✅ کارگاه عملی ۲۴ ساعته مرکز آموزش مؤسسه آموزشی آدان با گواهی رسمی دوزبانه QR\n🎁 ۲۵٪ تخفیف ویژه فراگیران آدان با کد ADN-INSTA25", "#آموزش_حسابداری_آدان #صادرات #اینکوترمز #بازرگانی_خارجی #گمرک #مدیران_صنعت", "https://chamber.ir/tms?utm_source=instagram&utm_campaign=incoterms1405", "ADN-INSTA25", "۱۴۰۵/۰۸/۰۵ — ساعت ۲۰:۰۰ (ساعت طلایی)", 28400, 2690, 940, 76, 19, 45000000, 893000000, "published"),
(2, "SOC-LI-102", 1, "linkedin", "مقاله تحلیلی مدیریتی B2B", "مقررات مکانیسم تعدیل کربن مرزی اتحادیه اروپا (CBAM)", "هشدار استراتژیک به مدیران‌عامل صنایع فولاد، سیمان، آلومینیوم و پتروشیمی استان", "از ژانویه ۲۰۲۶ واردکنندگان اروپایی بدون گزارش ردپای کربن تأییدشده (EU CBAM) امکان ترخیص محموله‌های صنعتی را ندارند.\nواحد آموزش مؤسسه آموزشی آدان برای نخستین‌بار در استان، کارگاه تخصصی «ممیزی و گزارش‌دهی عملی CBAM» را با حضور اساتید بین‌المللی برگزار می‌کند.\n🔗 رزرو سهمیه سازمانی ویژه کارخانجات در لینک کامنت اول.", "#EUCBAM #صادرات_صنعتی #فولاد #سیمان #مدیریت_ارشد #آموزش_حسابداری_آدان", "https://chamber.ir/tms?utm_source=linkedin&utm_campaign=cbam_exec", "B2B-LINKEDIN", "۱۴۰۵/۰۸/۰۶ — ساعت ۰۹:۳۰ صبح کاری", 16900, 1420, 680, 54, 16, 30000000, 1152000000, "published"),
(3, "SOC-TG-103", 1, "telegram", "پست کانال فوری + دکمه شیشه‌ای ثبت‌نام", "قوانین سامانه مؤدیان و دفاعیه مالیاتی", "🚨 ظرفیت باقی‌مانده فقط ۶ صندلی | کارگاه عملی لایحه‌نویسی و سامانه مؤدیان", "📊 همکاران مالی و حسابداران ارشد واحدهای تولیدی:\nصفر تا صد رفع مغایرت کارپوشه مؤدیان، معافیت‌های ماده ۱۲ و تنظیم لایحه دفاعیه هیئت حل اختلاف در ۱۶ ساعت کارگاه عملی روی پرونده واقعی!\n👇 ثبت‌نام آنی با تخفیف ویژه کانال رسمی آموزشی آدان:", "#سامانه_مودیان #مالیات #حسابداری #مدیر_مالی #آموزش_حسابداری_آدان", "https://chamber.ir/tms?utm_source=telegram&utm_campaign=tax_pro", "TG-VIP15", "۱۴۰۵/۰۸/۰۷ — ساعت ۱۱:۰۰ صبح", 22100, 1850, 810, 62, 17, 22000000, 697000000, "published"),
(4, "SOC-ET-104", 1, "eitaa", "اطلاعیه رسمی کانال ایتا و بله اعضا", "آموزش متقاضیان صدور و تمدید کارت بازرگانی", "تقویم جدید کلاس‌های الزامی صدور و تمدید کارت بازرگانی (پاییز ۱۴۰۵) منتشر شد", "به اطلاع متقاضیان محترم صدور و تمدید کارت بازرگانی استان می‌رساند ثبت‌نام گروه جدید دوره‌های آموزشی الزامی با برگزاری ترکیبی و صدور گواهی آنی آغاز گردید.", "#کارت_بازرگانی #تاجران #آموزش_حسابداری_آدان", "https://chamber.ir/commercial-card?utm_source=eitaa&utm_campaign=card1405", "CARD-1405", "۱۴۰۵/۰۸/۰۸ — ساعت ۱۰:۰۰ صبح", 19300, 1340, 720, 68, 24, 12000000, 768000000, "scheduled"),
(5, "SOC-YT-105", 1, "youtube", "ویدئو کوتاه آموزشی (Shorts / آپارات)", "هوش مصنوعی در شکار خریدار خارجی و بازاریابی B2B", "چطور با هوش مصنوعی در ۱۰ دقیقه لیست ۵۰ واردکننده واقعی کالای خود در عراق و عمان را پیدا کنیم؟", "در این ویدئوی ۹۰ ثانیه‌ای ۳ پرامپت طلایی تحلیل کد تعرفه HS Code و استخراج خریداران خارجی را نشان دادیم! نسخه کامل در کارگاه عملی هفته آینده مؤسسه آموزشی آدان.", "#هوش_مصنوعی #صادرات_عراق #بازاریابی_بین_المللی #HSCode", "https://chamber.ir/tms?utm_source=youtube&utm_campaign=ai_export", "YT-AI20", "۱۴۰۵/۰۸/۰۹ — ساعت ۲۱:۰۰", 34800, 3920, 1120, 89, 21, 28000000, 966000000, "scheduled");

INSERT IGNORE INTO market_surveys_insights
(id, insight_code, research_title, industry_segment, social_source, sample_size_orgs, demand_urgency_pct, positive_sentiment_pct, willingness_to_pay_rial, tam_provincial_rial, sam_reachable_rial, som_target_rial, key_pain_point, ai_gtm_strategy, launched_to_tms, created_shamsi) VALUES
(1, "MRK-INS-01", "نیازسنجی میدانی و شنود شبکه‌های اجتماعی درباره «هوش مصنوعی در صادرات و تحلیل گمرکی»", "صادرکنندگان مواد غذایی، کاشی، پلیمر و خشکبار", "لینکدین (۴۲٪) + تلگرام تخصصی (۳۵٪) + پرسشنامه اعضا (۲۳٪)", 112, 94, 88, 54000000, 62000000000, 19500000000, 5800000000, "عدم آشنایی تیم‌های فروش خارجی کارخانجات با ابزارهای هوش مصنوعی شناسایی خریدار، مکاتبه چندزبانه و تحلیل داده‌های گمرکی رقبا.", "اجرای کارگاه عملی ۲۴ ساعته با لپ‌تاپ در مؤسسه آموزشی آدان + کمپین ویدئویی Reels اینستاگرام و مقاله تخصصی لینکدین برای مدیران بازرگانی.", 0, "۱۴۰۵/۰۸/۰۱"),
(2, "MRK-INS-02", "پیمایش حساسیت قیمتی و تقاضای بنگاه‌ها برای «مدیریت جریان نقدینگی و تأمین مالی زنجیره تأمین (SCF)»", "واحدهای تولیدی شهرک‌های صنعتی استان", "لینکدین مدیران مالی + کانال تلگرام + مصاحبه عمیق", 86, 89, 82, 62000000, 54000000000, 16800000000, 4900000000, "فشار سرمایه در گردش و عدم بهره‌گیری از ابزارهای نوین برات الکترونیکی، اوراق گام و تأمین مالی زنجیره‌ای بانک‌ها.", "طراحی سمینار مدیریتی ۱ روزه ویژه مدیران‌عامل + کارگاه عملی ۲ روزه مدیران مالی با تبلیغ مستقیم در لینکدین و پیامک VIP اعضا.", 0, "۱۴۰۵/۰۸/۰۲"),
(3, "MRK-INS-03", "تحلیل شکاف مهارتی تجارت با اوراسیا، روسیه و تسویه ارزی برون‌مرزی جدید", "بازرگانان کالاهای کشاورزی، صنعتی و لجستیک", "کانال‌های تلگرامی صادرات + اینستاگرام + کمیسیون تجارت", 95, 91, 86, 58000000, 49000000000, 15200000000, 4400000000, "اجرایی‌شدن موافقت‌نامه تجارت آزاد ایران و اوراسیا (صفر شدن تعرفه ۸۷٪ کالاها) ولی ضعف شدید صادرکنندگان در قرارداد و لجستیک مسیر شمال.", "پرتاب فوری دوره کاربردی تجارت آزاد اوراسیا هم‌زمان با کمپین مشترک تلگرام، لینکدین و ایتا برای اعضای دارای کارت بازرگانی فعال.", 0, "۱۴۰۵/۰۸/۰۳"),
(4, "MRK-INS-04", "پژوهش تقاضاسنجی بازاریابی دیجیتال صنعتی و تولید محتوای صادراتی در لینکدین و اینستاگرام", "واحدهای صنعتی، معدنی و دانش‌بنیان صادرات‌محور", "شنود اینستاگرام بیزینس + لینکدین + پنل فراگیران آدان", 104, 93, 90, 51000000, 57000000000, 18400000000, 5300000000, "ضعف شدید برندینگ دیجیتال کارخانجات ایرانی در لینکدین و یوتیوب برای جذب خریداران عمده منطقه‌ای در خلیج فارس و عراق.", "برگزاری بوت‌کمپ کمپین‌سازی بین‌المللی شبکه‌های اجتماعی B2B همراه با کلینیک عملی ساخت پیج و قیف جذب سرنخ صادراتی.", 0, "۱۴۰۵/۰۸/۰۴");

SET FOREIGN_KEY_CHECKS = 1;