-- =============================================================================
-- سامانه جامع هوشمند آموزش مؤسسه آموزشی آدان (Adan Accounting Education ERP + LMS + AI)
-- سازگار با MariaDB 10.3 / 10.4 / 10.6 / 11.x در XAMPP و cPanel (phpMyAdmin)
-- معماری: Pure PHP MVC + AI Gateway
-- =============================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ۱. سازمان‌ها و بنگاه‌های دانش‌پذیر آدان
CREATE TABLE IF NOT EXISTS organizations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    chamber_member_code VARCHAR(80) UNIQUE,
    national_id VARCHAR(30),
    industry VARCHAR(120) DEFAULT 'صنعت و بازرگانی',
    membership_tier ENUM('gold','silver','standard','non_member') DEFAULT 'gold',
    city VARCHAR(100) DEFAULT 'مرکز استان',
    annual_quota_hours INT DEFAULT 200,
    used_quota_hours INT DEFAULT 0,
    contact_phone VARCHAR(40),
    status ENUM('active','pending','suspended') DEFAULT 'active',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۲. کاربران، نقش‌ها، گذرنامه استعداد و تنظیمات رضایت ارتباطی
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    org_id INT NULL,
    username VARCHAR(100) NOT NULL UNIQUE,
    email VARCHAR(190) NOT NULL UNIQUE,
    mobile VARCHAR(25),
    national_code VARCHAR(20),
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(180) NOT NULL,
    role VARCHAR(60) NOT NULL DEFAULT 'learner',
    job_title VARCHAR(150) DEFAULT 'کارشناس',
    avatar_initials VARCHAR(10) DEFAULT 'ک',
    public_passport_slug VARCHAR(120) UNIQUE,
    passport_is_public TINYINT(1) DEFAULT 0,
    marketing_opt_in TINYINT(1) DEFAULT 1,
    telegram_chat_id VARCHAR(60) NULL,
    daily_ai_token_limit INT DEFAULT 25000,
    status ENUM('active','locked','inactive') DEFAULT 'active',
    last_login_at DATETIME NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_users_org (org_id),
    INDEX idx_users_role (role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۳. قفل موقت ورود (Brute-Force Protection)
CREATE TABLE IF NOT EXISTS login_attempts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    identifier VARCHAR(190) NOT NULL,
    ip_address VARCHAR(64) NOT NULL,
    attempted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    is_success TINYINT(1) DEFAULT 0,
    INDEX idx_login_ident (identifier, attempted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۴. لاگ ممیزی امنیتی و عملیاتی (Audit Log)
CREATE TABLE IF NOT EXISTS audit_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    user_role VARCHAR(50),
    module VARCHAR(80) NOT NULL,
    action VARCHAR(120) NOT NULL,
    entity_type VARCHAR(80),
    entity_id INT NULL,
    details_json LONGTEXT,
    ip_address VARCHAR(64),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_audit_mod (module, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۵. تنظیمات سراسری سامانه و کلیدهای سمت سرور
CREATE TABLE IF NOT EXISTS system_settings (
    setting_key VARCHAR(120) PRIMARY KEY,
    setting_value LONGTEXT,
    category VARCHAR(60) DEFAULT 'general',
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۶. اعلان‌های نقش‌محور و فردی
CREATE TABLE IF NOT EXISTS notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    target_role VARCHAR(50) NULL,
    title VARCHAR(200) NOT NULL,
    body TEXT,
    type ENUM('info','success','warning','urgent') DEFAULT 'info',
    link VARCHAR(255) NULL,
    is_read TINYINT(1) DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۷. دسته‌بندی دوره‌ها (TMS)
CREATE TABLE IF NOT EXISTS course_categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(160) NOT NULL,
    slug VARCHAR(160) NOT NULL UNIQUE,
    icon VARCHAR(40) DEFAULT 'briefcase',
    color VARCHAR(30) DEFAULT '#0f766e',
    description VARCHAR(500)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۸. کاتالوگ دوره‌ها و گردش تصویب (TMS)
CREATE TABLE IF NOT EXISTS courses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT NOT NULL,
    code VARCHAR(50) NOT NULL UNIQUE,
    title VARCHAR(220) NOT NULL,
    level ENUM('مقدماتی','میانی','پیشرفته','مدیریتی ویژه') DEFAULT 'میانی',
    delivery_mode ENUM('حضوری','آنلاین همزمان','ترکیبی','خودآموز LMS') DEFAULT 'ترکیبی',
    duration_hours INT NOT NULL DEFAULT 16,
    tuition_rial BIGINT NOT NULL DEFAULT 0,
    member_discount_pct INT DEFAULT 20,
    prerequisite_text VARCHAR(255) DEFAULT 'ندارد',
    workflow_status ENUM('draft','under_review','approved','published','archived') DEFAULT 'published',
    reviewer_note VARCHAR(500) NULL,
    approved_by INT NULL,
    summary TEXT,
    rating DECIMAL(3,2) DEFAULT 4.80,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_course_status (workflow_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۹. اجراها / ترم‌های دوره (TMS)
CREATE TABLE IF NOT EXISTS course_runs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_id INT NOT NULL,
    instructor_id INT NULL,
    classroom_id INT NULL,
    run_code VARCHAR(60) NOT NULL UNIQUE,
    term_label VARCHAR(100) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    start_shamsi VARCHAR(30) NOT NULL,
    schedule_text VARCHAR(180) NOT NULL,
    capacity INT NOT NULL DEFAULT 30,
    enrolled_count INT NOT NULL DEFAULT 0,
    status ENUM('planning','registration','running','completed','cancelled') DEFAULT 'registration',
    execution_report TEXT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۱۰. جلسات کلاسی هر اجرا (TMS)
CREATE TABLE IF NOT EXISTS course_sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    run_id INT NOT NULL,
    session_number INT NOT NULL DEFAULT 1,
    title VARCHAR(200) NOT NULL,
    session_date DATE NOT NULL,
    session_shamsi VARCHAR(30) NOT NULL,
    start_time VARCHAR(10) DEFAULT '14:00',
    end_time VARCHAR(10) DEFAULT '18:00',
    room_or_link VARCHAR(255) DEFAULT 'سالن خلیج فارس - طبقه دوم اتاق',
    is_held TINYINT(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۱۱. ثبت‌نام‌ها و فهرست انتظار (تکی / گروهی سازمانی / API)
CREATE TABLE IF NOT EXISTS enrollments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    run_id INT NOT NULL,
    user_id INT NOT NULL,
    org_id INT NULL,
    source ENUM('web','bulk_org','api','admin') DEFAULT 'web',
    status ENUM('active','waitlist','completed','cancelled') DEFAULT 'active',
    attendance_pct INT DEFAULT 100,
    progress_pct INT DEFAULT 0,
    final_score DECIMAL(5,2) NULL,
    invoice_id INT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_run_user (run_id, user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۱۲. حضور و غیاب جلسه‌ای
CREATE TABLE IF NOT EXISTS session_attendance (
    id INT AUTO_INCREMENT PRIMARY KEY,
    session_id INT NOT NULL,
    user_id INT NOT NULL,
    status ENUM('present','absent','late','excused') DEFAULT 'present',
    note VARCHAR(200) NULL,
    recorded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_sess_user (session_id, user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۱۳. بانک شایستگی‌ها (TNA)
CREATE TABLE IF NOT EXISTS competencies (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(40) NOT NULL UNIQUE,
    title VARCHAR(180) NOT NULL,
    domain ENUM('تجارت بین‌الملل','مدیریت و رهبری','مالی و گمرکی','تحول دیجیتال و AI','مذاکره و حقوق تجاری') DEFAULT 'تجارت بین‌الملل',
    recommended_course_id INT NULL,
    weight INT DEFAULT 3,
    description TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۱۴. ماتریس ارزیابی سطح فعلی و هدف شایستگی
CREATE TABLE IF NOT EXISTS competency_assessments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    competency_id INT NOT NULL,
    target_role_title VARCHAR(150) DEFAULT 'مدیر صادرات',
    current_level TINYINT NOT NULL DEFAULT 2,
    target_level TINYINT NOT NULL DEFAULT 4,
    priority ENUM('عادی','مهم','حیاتی') DEFAULT 'مهم',
    ai_recommendation VARCHAR(500) NULL,
    assessed_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۱۵. پیشنهاد دوره توسط اعضا و نظرسنجی نیازسنجی
CREATE TABLE IF NOT EXISTS course_proposals (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    org_id INT NULL,
    proposed_title VARCHAR(220) NOT NULL,
    target_audience VARCHAR(180),
    estimated_learners INT DEFAULT 15,
    business_problem TEXT,
    votes_count INT DEFAULT 1,
    status ENUM('pending','ai_analyzed','approved','converted_to_course','rejected') DEFAULT 'pending',
    ai_analysis_note TEXT NULL,
    reviewer_comment VARCHAR(400) NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۱۶. فصل‌های آموزشی LMS 
CREATE TABLE IF NOT EXISTS lms_chapters (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_id INT NOT NULL,
    sort_order INT DEFAULT 1,
    title VARCHAR(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۱۷. درس‌ها، محتوای چندرسانه‌ای و بسته SCORM 
CREATE TABLE IF NOT EXISTS lms_lessons (
    id INT AUTO_INCREMENT PRIMARY KEY,
    chapter_id INT NOT NULL,
    course_id INT NOT NULL,
    sort_order INT DEFAULT 1,
    title VARCHAR(220) NOT NULL,
    content_type ENUM('video','audio','pdf','scorm','article') DEFAULT 'video',
    estimated_minutes INT DEFAULT 25,
    sequential_lock TINYINT(1) DEFAULT 1,
    media_url VARCHAR(300) NULL,
    scorm_manifest_path VARCHAR(300) NULL,
    scorm_version VARCHAR(40) NULL,
    body_html LONGTEXT,
    attachment_name VARCHAR(200) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۱۸. پیشرفت و زمان مطالعه LMS
CREATE TABLE IF NOT EXISTS lms_progress (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    lesson_id INT NOT NULL,
    is_completed TINYINT(1) DEFAULT 0,
    spent_minutes INT DEFAULT 0,
    completed_at DATETIME NULL,
    UNIQUE KEY uq_user_lesson (user_id, lesson_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۱۹. گفت‌وگوی کلاسی LMS
CREATE TABLE IF NOT EXISTS lms_discussions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_id INT NOT NULL,
    lesson_id INT NULL,
    user_id INT NOT NULL,
    message TEXT NOT NULL,
    instructor_reply TEXT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۲۰. تکالیف و فایل‌های ارسالی LMS
CREATE TABLE IF NOT EXISTS lms_assignments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_id INT NOT NULL,
    user_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    submission_text TEXT,
    file_path VARCHAR(255) NULL,
    grade DECIMAL(5,2) NULL,
    feedback VARCHAR(400) NULL,
    status ENUM('submitted','graded','revision_needed') DEFAULT 'submitted',
    submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۲۱. استودیوی تولید محتوا با AI و بازبینی انسانی 
CREATE TABLE IF NOT EXISTS ai_contents (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_id INT NULL,
    creator_id INT NOT NULL,
    content_kind ENUM('course_draft','lesson_plan','quiz','microlearning','slides','summary') NOT NULL,
    title VARCHAR(220) NOT NULL,
    source_excerpt LONGTEXT NULL,
    current_version INT DEFAULT 1,
    body_markdown LONGTEXT NOT NULL,
    model_used VARCHAR(80) DEFAULT 'ai/gpt-4o-mini',
    review_status ENUM('ai_draft','in_review','human_approved','published') DEFAULT 'ai_draft',
    approved_by INT NULL,
    approved_at DATETIME NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۲۲. تاریخچه نسخه‌های استودیوی AI
CREATE TABLE IF NOT EXISTS ai_content_versions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ai_content_id INT NOT NULL,
    version_no INT NOT NULL DEFAULT 1,
    editor_id INT NOT NULL,
    change_note VARCHAR(255) DEFAULT 'نسخه اولیه پیش‌نویس هوش مصنوعی',
    body_snapshot LONGTEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۲۳. پرونده بانک مدرسان 
CREATE TABLE IF NOT EXISTS instructor_profiles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,
    degree VARCHAR(120) DEFAULT 'دکتری تخصصی مدیریت بازرگانی',
    specialties VARCHAR(350) NOT NULL,
    teaching_years INT DEFAULT 8,
    hourly_rate_rial BIGINT DEFAULT 12000000,
    avg_rating DECIMAL(3,2) DEFAULT 4.85,
    qualification_status ENUM('pending','committee_approved','conditional','suspended') DEFAULT 'committee_approved',
    availability_slots VARCHAR(255) DEFAULT 'دوشنبه و چهارشنبه ۱۴ الی ۲۰ | پنجشنبه ۹ الی ۱۳',
    portfolio_url VARCHAR(255) NULL,
    bio TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۲۴. گردش پرداخت حق‌التدریس مدرسان 
CREATE TABLE IF NOT EXISTS instructor_payouts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    instructor_user_id INT NOT NULL,
    run_id INT NULL,
    hours_taught INT NOT NULL DEFAULT 16,
    gross_amount_rial BIGINT NOT NULL,
    tax_deduction_rial BIGINT NOT NULL DEFAULT 0,
    net_amount_rial BIGINT NOT NULL,
    status ENUM('draft','verified','approved_finance','paid') DEFAULT 'verified',
    payment_ref VARCHAR(100) NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۲۵. کارگاه‌ها، نشست‌ها و برنامه‌های آموزشی
CREATE TABLE IF NOT EXISTS events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(50) NOT NULL UNIQUE,
    title VARCHAR(220) NOT NULL,
    event_type ENUM('همایش استانی','نشست هیئت تجاری','سمینار تخصصی','کارگاه رایگان اعضا','کارگاه آموزشی','نشست تخصصی','جلسه رفع اشکال') DEFAULT 'کارگاه آموزشی',
    speakers VARCHAR(350) NOT NULL,
    event_date DATE NOT NULL,
    event_shamsi VARCHAR(30) NOT NULL,
    venue VARCHAR(200) DEFAULT 'آموزشگاه حسابداری آدان',
    capacity INT NOT NULL DEFAULT 150,
    registered_count INT DEFAULT 0,
    price_rial BIGINT NOT NULL DEFAULT 0,
    estimated_cost_rial BIGINT DEFAULT 0,
    sms_reminder_status ENUM('sandbox_queued','sandbox_sent','disabled') DEFAULT 'sandbox_queued',
    status ENUM('open','sold_out','closed') DEFAULT 'open',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۲۶. بلیت‌ها و ثبت ورود QR رویدادها 
CREATE TABLE IF NOT EXISTS event_tickets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    event_id INT NOT NULL,
    user_id INT NOT NULL,
    ticket_code VARCHAR(80) NOT NULL UNIQUE,
    paid_status ENUM('free','paid_invoice') DEFAULT 'free',
    checked_in_at DATETIME NULL,
    feedback_score TINYINT NULL,
    feedback_comment VARCHAR(300) NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_event_user (event_id, user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۲۷. کدهای تخفیف (مالی)
CREATE TABLE IF NOT EXISTS discount_codes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(50) NOT NULL UNIQUE,
    discount_pct INT NOT NULL DEFAULT 15,
    max_uses INT DEFAULT 100,
    used_count INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۲۸. فاکتورها، مالیات بر ارزش افزوده و استرداد 
CREATE TABLE IF NOT EXISTS invoices (
    id INT AUTO_INCREMENT PRIMARY KEY,
    invoice_number VARCHAR(60) NOT NULL UNIQUE,
    user_id INT NOT NULL,
    org_id INT NULL,
    item_description VARCHAR(255) NOT NULL,
    subtotal_rial BIGINT NOT NULL,
    discount_rial BIGINT DEFAULT 0,
    vat_rial BIGINT DEFAULT 0,
    total_rial BIGINT NOT NULL,
    payment_mode ENUM('cash_gateway_sim','installment','corporate_contract') DEFAULT 'cash_gateway_sim',
    status ENUM('unpaid','partial','paid','refund_requested','refunded') DEFAULT 'unpaid',
    refund_reason VARCHAR(255) NULL,
    payment_reference VARCHAR(100) NULL,
    refund_payment_reference VARCHAR(100) NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_invoice_payment_reference (payment_reference),
    UNIQUE KEY uq_invoice_refund_payment_reference (refund_payment_reference)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۲۹. تقسیط شهریه 
CREATE TABLE IF NOT EXISTS invoice_installments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    invoice_id INT NOT NULL,
    installment_no INT NOT NULL DEFAULT 1,
    due_shamsi VARCHAR(30) NOT NULL,
    amount_rial BIGINT NOT NULL,
    status ENUM('pending','paid','overdue') DEFAULT 'pending',
    payment_reference VARCHAR(100) NULL,
    UNIQUE KEY uq_installment_payment_reference (payment_reference)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۳۰. دفترکل مالی، هزینه‌ها و بودجه واحد آموزش 
CREATE TABLE IF NOT EXISTS ledger_entries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    entry_date DATE NOT NULL,
    entry_shamsi VARCHAR(30) NOT NULL,
    account_head VARCHAR(140) NOT NULL,
    entry_type ENUM('revenue','expense','budget_alloc','refund') NOT NULL,
    course_id INT NULL,
    debit_rial BIGINT DEFAULT 0,
    credit_rial BIGINT DEFAULT 0,
    description VARCHAR(300)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۳۱. ارزیابی اثربخشی کرکپاتریک، پیش/پس‌آزمون، ۳۶۰ و ROI 
CREATE TABLE IF NOT EXISTS evaluations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_id INT NOT NULL,
    evaluator_id INT NOT NULL,
    kirkpatrick_l1_reaction DECIMAL(4,2) DEFAULT 4.60,
    pre_test_score DECIMAL(5,2) DEFAULT 48.00,
    post_test_score DECIMAL(5,2) DEFAULT 86.00,
    kirkpatrick_l3_behavior DECIMAL(4,2) DEFAULT 4.20,
    transfer_notes VARCHAR(350) NULL,
    program_cost_rial BIGINT DEFAULT 450000000,
    estimated_benefit_rial BIGINT DEFAULT 1150000000,
    feedback_360_summary VARCHAR(400) NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۳۲. مخاطبان و سرنخ‌های CRM آموزشی 
CREATE TABLE IF NOT EXISTS crm_contacts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    org_id INT NULL,
    full_name VARCHAR(160) NOT NULL,
    position_title VARCHAR(120) DEFAULT 'مدیر آموزش و توسعه سرمایه انسانی',
    phone VARCHAR(40),
    email VARCHAR(160),
    lead_score INT DEFAULT 75,
    last_interaction VARCHAR(255) DEFAULT 'تماس کارشناسی معرفی تقویم آموزشی پاییز',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۳۳. فرصت‌های فروش و قیف CRM 
CREATE TABLE IF NOT EXISTS crm_deals (
    id INT AUTO_INCREMENT PRIMARY KEY,
    org_id INT NOT NULL,
    title VARCHAR(220) NOT NULL,
    estimated_value_rial BIGINT NOT NULL DEFAULT 850000000,
    stage ENUM('lead','qualified','proposal','negotiation','won','lost') DEFAULT 'proposal',
    probability_pct INT DEFAULT 60,
    next_followup_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۸/۰۵',
    owner_user_id INT NULL,
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۳۴. قراردادهای سازمانی 
CREATE TABLE IF NOT EXISTS corporate_contracts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    contract_no VARCHAR(60) NOT NULL UNIQUE,
    org_id INT NOT NULL,
    title VARCHAR(220) NOT NULL,
    total_amount_rial BIGINT NOT NULL,
    paid_amount_rial BIGINT DEFAULT 0,
    seat_quota INT NOT NULL DEFAULT 50,
    seats_used INT DEFAULT 0,
    start_shamsi VARCHAR(30) NOT NULL,
    end_shamsi VARCHAR(30) NOT NULL,
    approval_stage ENUM('draft','legal_review','finance_review','approved_active','expired') DEFAULT 'approved_active',
    deliverables_summary TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۳۵. مسیرها و سناریوهای آکادمی تجارت بین‌الملل 
CREATE TABLE IF NOT EXISTS trade_paths (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    target_market VARCHAR(120) DEFAULT 'اتحادیه اروپا، خلیج فارس و اوراسیا',
    steps_json LONGTEXT NOT NULL,
    scenario_title VARCHAR(220) NOT NULL,
    scenario_prompt TEXT NOT NULL,
    optimal_incoterm VARCHAR(40) DEFAULT 'CIF / CIP Incoterms 2020',
    badge_title VARCHAR(140) DEFAULT 'متخصص ارشد صادرات مؤسسه آموزشی آدان'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۳۶. برنامه‌های توسعه رهبری و شبیه‌ساز تصمیم‌گیری وزن‌دار 
CREATE TABLE IF NOT EXISTS leadership_programs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    cohort_name VARCHAR(100) DEFAULT 'دوره چهارم مدیران عامل استان',
    participants_count INT DEFAULT 24,
    criteria_weights_json LONGTEXT NOT NULL,
    mentoring_assignment VARCHAR(350) NOT NULL,
    avg_360_score DECIMAL(4,2) DEFAULT 4.45
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۳۷. جلسات مشاوره و منتورینگ + یادداشت محرمانه 
CREATE TABLE IF NOT EXISTS consulting_sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    consultant_id INT NOT NULL,
    client_user_id INT NOT NULL,
    topic VARCHAR(200) NOT NULL,
    slot_label VARCHAR(120) NOT NULL,
    status ENUM('requested','confirmed','completed','cancelled') DEFAULT 'confirmed',
    agenda TEXT,
    confidential_note TEXT NULL,
    action_items TEXT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۳۸. آزمون‌ها و بانک سؤال 
CREATE TABLE IF NOT EXISTS exams (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    duration_minutes INT NOT NULL DEFAULT 20,
    max_attempts INT NOT NULL DEFAULT 2,
    pass_score DECIMAL(5,2) NOT NULL DEFAULT 70.00,
    is_active TINYINT(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS exam_questions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    exam_id INT NOT NULL,
    question_type ENUM('mcq','descriptive') DEFAULT 'mcq',
    question_text TEXT NOT NULL,
    option_a VARCHAR(255) NULL,
    option_b VARCHAR(255) NULL,
    option_c VARCHAR(255) NULL,
    option_d VARCHAR(255) NULL,
    correct_option CHAR(1) NULL,
    points DECIMAL(5,2) DEFAULT 25.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS exam_attempts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    exam_id INT NOT NULL,
    user_id INT NOT NULL,
    attempt_no INT NOT NULL DEFAULT 1,
    auto_score DECIMAL(5,2) DEFAULT 0,
    descriptive_score DECIMAL(5,2) NULL,
    descriptive_answer TEXT NULL,
    status ENUM('auto_graded','pending_descriptive_review','finalized') DEFAULT 'auto_graded',
    submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۳۹. گواهی‌نامه‌های رسمی قابل استعلام با QR و ابطال‌پذیر 
CREATE TABLE IF NOT EXISTS certificates (
    id INT AUTO_INCREMENT PRIMARY KEY,
    serial_code VARCHAR(80) NOT NULL UNIQUE,
    user_id INT NOT NULL,
    course_id INT NOT NULL,
    issue_shamsi VARCHAR(30) NOT NULL,
    grade_label VARCHAR(50) DEFAULT 'عالی (A)',
    hours_completed INT DEFAULT 16,
    status ENUM('valid','revoked') DEFAULT 'valid',
    revoked_reason VARCHAR(255) NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۴۰. کلاس‌ها، تجهیزات، رزرو بدون تداخل و اعلام خرابی 
CREATE TABLE IF NOT EXISTS classrooms (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    capacity INT NOT NULL DEFAULT 35,
    equipment VARCHAR(300) DEFAULT 'ویدئوپروژکتور لیزری، سیستم کنفرانس، ضبط تصویر، اینترنت فیبر نوری',
    hourly_fee_rial BIGINT DEFAULT 8500000,
    maintenance_status ENUM('ready','service_needed') DEFAULT 'ready',
    maintenance_note VARCHAR(255) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS classroom_bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    classroom_id INT NOT NULL,
    booked_by INT NOT NULL,
    purpose VARCHAR(200) NOT NULL,
    booking_date DATE NOT NULL,
    booking_shamsi VARCHAR(30) NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    catering_request VARCHAR(200) NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_room_slot (classroom_id, booking_date, start_time, end_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۴۱. پژوهش آموزشی، کتابخانه دانشی و امانت (بخش تخصصی و ۱۸)
CREATE TABLE IF NOT EXISTS research_projects (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(220) NOT NULL,
    lead_researcher VARCHAR(150) NOT NULL,
    methodology VARCHAR(150) DEFAULT 'پیمایشی - مصاحبه عمیق با صادرکنندگان نمونه',
    budget_rial BIGINT DEFAULT 650000000,
    progress_pct INT DEFAULT 65,
    form_id INT NULL,
    publication_summary TEXT,
    status ENUM('proposal','fieldwork','published') DEFAULT 'fieldwork'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS library_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(220) NOT NULL,
    authors VARCHAR(180) NOT NULL,
    category VARCHAR(100) DEFAULT 'گزارش بازار و تجارت خارجی',
    license_type VARCHAR(100) DEFAULT 'دسترسی آزاد فراگیران آدان',
    edition VARCHAR(40) DEFAULT 'ویرایش ۱۴۰۵',
    course_id INT NULL,
    downloads_count INT DEFAULT 42,
    available_copies INT DEFAULT 3,
    abstract_text TEXT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS library_loans (
    id INT AUTO_INCREMENT PRIMARY KEY,
    item_id INT NOT NULL,
    user_id INT NOT NULL,
    loan_shamsi VARCHAR(30) NOT NULL,
    due_shamsi VARCHAR(30) NOT NULL,
    returned_at DATETIME NULL,
    review_note VARCHAR(300) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۴۲. کارآموزی، مسابقات، منابع انسانی داخلی و موتور BPMS (بخش تخصصی، ۲۰، ۲۱، ۲۲)
CREATE TABLE IF NOT EXISTS internships (
    id INT AUTO_INCREMENT PRIMARY KEY,
    program_title VARCHAR(200) NOT NULL,
    host_org_id INT NOT NULL,
    intern_user_id INT NOT NULL,
    team_name VARCHAR(120) DEFAULT 'تیم توسعه صادرات الف',
    milestone_stage VARCHAR(120) DEFAULT 'تحویل فاز دوم: تحلیل بازار هدف',
    deliverable_file VARCHAR(255) NULL,
    rubric_score_json LONGTEXT NULL,
    total_score DECIMAL(5,2) DEFAULT 88.50,
    status ENUM('applied','active','evaluated') DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS competitions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    current_round VARCHAR(80) DEFAULT 'راند دوم - نیمه‌نهایی استانی',
    team_name VARCHAR(140) NOT NULL,
    weighted_criteria_json LONGTEXT NOT NULL,
    jury_score DECIMAL(5,2) DEFAULT 91.20,
    judge_comment VARCHAR(300) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS hr_records (
    id INT AUTO_INCREMENT PRIMARY KEY,
    staff_user_id INT NOT NULL,
    record_type ENUM('task','leave_request','periodic_eval','succession','payslip_note') NOT NULL,
    title VARCHAR(200) NOT NULL,
    details VARCHAR(400),
    kpi_score INT NULL,
    status ENUM('open','approved','rejected','done') DEFAULT 'open',
    created_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bpms_workflows (
    id INT AUTO_INCREMENT PRIMARY KEY,
    process_key VARCHAR(60) NOT NULL,
    process_title VARCHAR(200) NOT NULL,
    subject_label VARCHAR(220) NOT NULL,
    initiator_id INT NOT NULL,
    current_step VARCHAR(140) NOT NULL,
    assigned_role VARCHAR(60) NOT NULL,
    sla_hours INT DEFAULT 48,
    elapsed_hours INT DEFAULT 14,
    status ENUM('running','approved','rejected') DEFAULT 'running',
    history_json LONGTEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۴۳. گزارش‌ساز BI، مدیریت AI، RAG، وب‌هوک‌ها و افزونه‌های سراسری (بخش تخصصی، ۲۴ و پلاگین‌ها)
CREATE TABLE IF NOT EXISTS saved_reports (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(180) NOT NULL,
    dataset_key VARCHAR(60) NOT NULL,
    filter_expr VARCHAR(120) NULL,
    cron_schedule VARCHAR(60) DEFAULT '0 7 * * 6',
    ai_insight TEXT NULL,
    created_by INT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ai_prompts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(60) NOT NULL UNIQUE,
    title VARCHAR(180) NOT NULL,
    module_name VARCHAR(80) NOT NULL,
    system_prompt TEXT NOT NULL,
    temperature DECIMAL(3,2) DEFAULT 0.40
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ai_usage_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    module_name VARCHAR(80) NOT NULL,
    provider VARCHAR(50) DEFAULT 'AI',
    model_name VARCHAR(80) NOT NULL,
    prompt_tokens INT DEFAULT 0,
    completion_tokens INT DEFAULT 0,
    latency_ms INT DEFAULT 0,
    execution_mode ENUM('live_api','simulation_fallback') DEFAULT 'simulation_fallback',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS rag_documents (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    category VARCHAR(80) DEFAULT 'دستورالعمل آموزشی مؤسسه آدان',
    keywords VARCHAR(255) NOT NULL,
    chunk_text LONGTEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS webhooks_and_jobs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    entry_kind ENUM('webhook','queue_job') DEFAULT 'webhook',
    name VARCHAR(160) NOT NULL,
    target_url_or_handler VARCHAR(255) NOT NULL,
    event_trigger VARCHAR(80) DEFAULT 'enrollment.created',
    status ENUM('active','queued','completed','failed','draft_local') DEFAULT 'draft_local',
    last_response VARCHAR(255) DEFAULT 'پیش‌نویس محلی؛ ارسال بیرونی فعال نیست',
    last_run_at DATETIME NULL DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS documents (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    doc_category VARCHAR(80) DEFAULT 'اسناد رسمی و بخشنامه‌ها',
    file_name VARCHAR(200) NOT NULL,
    file_path VARCHAR(255) NOT NULL,
    uploaded_by INT NOT NULL,
    access_scope ENUM('public','staff','org_only') DEFAULT 'staff',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS dynamic_forms (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    slug VARCHAR(120) NOT NULL UNIQUE,
    purpose VARCHAR(150) DEFAULT 'نظرسنجی و گردآوری داده پژوهشی',
    fields_json LONGTEXT NOT NULL,
    submissions_count INT DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS form_submissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    form_id INT NOT NULL,
    user_id INT NULL,
    payload_json LONGTEXT NOT NULL,
    submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS portal_pages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    slug VARCHAR(80) NOT NULL,
    version_no INT NOT NULL DEFAULT 1,
    hero_title VARCHAR(240) NOT NULL,
    hero_subtitle VARCHAR(400) NOT NULL,
    announcement_bar VARCHAR(255) NULL,
    featured_boxes_json LONGTEXT NOT NULL,
    is_published TINYINT(1) DEFAULT 0,
    edited_by INT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS marketing_campaigns (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    segment_name VARCHAR(140) NOT NULL,
    channel ENUM('sms_sandbox','email_sandbox','telegram_sandbox') DEFAULT 'sms_sandbox',
    variant_a_text VARCHAR(400) NOT NULL,
    variant_b_text VARCHAR(400) NOT NULL,
    human_approved TINYINT(1) DEFAULT 0,
    scheduled_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۳ ساعت ۱۰:۰۰',
    conversion_a_pct DECIMAL(4,1) DEFAULT NULL,
    conversion_b_pct DECIMAL(4,1) DEFAULT NULL,
    status ENUM('draft','awaiting_approval','scheduled','sent_simulated') DEFAULT 'awaiting_approval'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS market_intel (
    id INT AUTO_INCREMENT PRIMARY KEY,
    region ENUM('ایران','اتحادیه اروپا','خلیج فارس و اوراسیا') DEFAULT 'اتحادیه اروپا',
    competitor_or_source VARCHAR(200) NOT NULL,
    source_url VARCHAR(255) NOT NULL,
    trend_topic VARCHAR(220) NOT NULL,
    ai_gap_summary TEXT NOT NULL,
    last_checked_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS psychometric_results (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    test_name VARCHAR(160) DEFAULT 'سنجش سبک مذاکره تجاری و شایستگی رفتاری (نسخه قطعی)',
    analytical_score INT NOT NULL,
    collaborative_score INT NOT NULL,
    decisive_score INT NOT NULL,
    resilience_score INT NOT NULL,
    dominant_style VARCHAR(140) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS user_badges (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    badge_code VARCHAR(60) NOT NULL UNIQUE,
    badge_title VARCHAR(160) NOT NULL,
    skill_domain VARCHAR(120) NOT NULL,
    issued_shamsi VARCHAR(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS support_tickets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    subject VARCHAR(200) NOT NULL,
    department VARCHAR(80) DEFAULT 'آموزش و گواهی‌نامه‌ها',
    message TEXT NOT NULL,
    reply_text TEXT NULL,
    status ENUM('open','answered','closed') DEFAULT 'open',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bpms_routing_rules (
    id INT AUTO_INCREMENT PRIMARY KEY,
    rule_name VARCHAR(180) NOT NULL,
    process_key VARCHAR(60) NOT NULL,
    condition_expr VARCHAR(200) NOT NULL,
    routing_mode ENUM('sequential','parallel','conditional') DEFAULT 'conditional',
    target_roles VARCHAR(160) NOT NULL,
    sla_hours INT DEFAULT 24,
    is_active TINYINT(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE invoices ADD COLUMN IF NOT EXISTS event_id INT NULL;

CREATE TABLE IF NOT EXISTS scorm_cmi_tracks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    lesson_id INT NOT NULL DEFAULT 1,
    sco_identifier VARCHAR(120) DEFAULT 'INCOTERMS_2020_SCO_01',
    lesson_status VARCHAR(40) DEFAULT 'incomplete',
    score_raw DECIMAL(6,2) DEFAULT 0.00,
    score_max DECIMAL(6,2) DEFAULT 100.00,
    session_time VARCHAR(30) DEFAULT '00:05:12',
    lesson_location VARCHAR(120) DEFAULT 'slide_1',
    suspend_data TEXT NULL,
    cmi_json LONGTEXT NULL,
    commit_count INT DEFAULT 1,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_scorm_user_lesson (user_id, lesson_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS payment_transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    invoice_id INT NOT NULL,
    authority_code VARCHAR(80) NOT NULL,
    ref_id VARCHAR(80) NOT NULL,
    amount_rial BIGINT NOT NULL,
    gateway_mode VARCHAR(50) DEFAULT 'sandbox_hmac_signed',
    hmac_signature VARCHAR(128) NOT NULL,
    is_reconciled TINYINT(1) DEFAULT 0,
    reconciled_at DATETIME NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==================== فازهای ۷ تا ۱۰: بخش‌های سامانه راهبردی مؤسسه آموزشی آدان (ماژول‌های ۲۵ تا ۳۸) ====================

-- آموزش‌های الزامی متقاضیان صدور و تمدید کارت بازرگانی
CREATE TABLE IF NOT EXISTS commercial_card_cases (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tracking_code VARCHAR(50) NOT NULL UNIQUE,
    applicant_name VARCHAR(180) NOT NULL,
    national_or_legal_id VARCHAR(30) NOT NULL,
    card_request_type ENUM('صدور اولیه حقیقی','صدور اولیه حقوقی','تمدید کارت بازرگانی') DEFAULT 'صدور اولیه حقوقی',
    attendance_pct INT DEFAULT 0,
    exam_score DECIMAL(5,2) DEFAULT 0.00,
    aml_declaration TINYINT(1) DEFAULT 1,
    clearance_status ENUM('در حال گذراندن دوره','تأیید نهایی واحد آموزش','نیازمند آزمون مجدد') DEFAULT 'در حال گذراندن دوره',
    clearance_code VARCHAR(70) NULL,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- کلاس آنلاین زنده و وبینار (اسکای‌روم / ادوبی‌کانکت / BBB)
CREATE TABLE IF NOT EXISTS virtual_class_rooms (
    id INT AUTO_INCREMENT PRIMARY KEY,
    run_id INT NOT NULL DEFAULT 1,
    provider ENUM('Skyroom','BigBlueButton','AdobeConnect') DEFAULT 'Skyroom',
    room_title VARCHAR(200) NOT NULL,
    sso_slug VARCHAR(120) NOT NULL,
    online_participants INT DEFAULT 0,
    synced_attendance_count INT DEFAULT 0,
    recording_url VARCHAR(255) NULL,
    connection_mode VARCHAR(40) DEFAULT 'not_configured',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- سامانه مؤدیان مالیاتی و پل نرم‌افزارهای حسابداری ایران
CREATE TABLE IF NOT EXISTS tax_moadian_packets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    invoice_id INT NOT NULL,
    tax_unique_id_22 VARCHAR(30) NOT NULL,
    invoice_pattern VARCHAR(60) DEFAULT 'الگوی اول - فروش خدمات آموزشی',
    accounting_target ENUM('سپیدار همکاران','همکاران سیستم','هلو','محک') DEFAULT 'سپیدار همکاران',
    payload_sha256 VARCHAR(128) NOT NULL,
    submission_status VARCHAR(60) DEFAULT 'پیش‌نویس محلی - ارسال نشده',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- هیئت‌های تجاری اعزامی/پذیرشی و تورهای صنعتی
CREATE TABLE IF NOT EXISTS trade_missions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    mission_code VARCHAR(40) NOT NULL,
    title VARCHAR(220) NOT NULL,
    mission_type ENUM('هیئت تجاری اعزامی','هیئت تجاری پذیرشی','تور بازدید صنعتی استان') DEFAULT 'هیئت تجاری اعزامی',
    target_country_or_city VARCHAR(100) NOT NULL,
    sector_focus VARCHAR(150) NOT NULL,
    shamsi_dates VARCHAR(80) NOT NULL,
    delegates_count INT DEFAULT 12,
    b2b_meetings_count INT DEFAULT 35,
    mou_value_usd BIGINT DEFAULT 0,
    status VARCHAR(50) DEFAULT 'در حال ثبت‌نام اعضا'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- کمیسیون‌های تخصصی، تشکل‌های صادراتی و اتاق‌های مشترک
CREATE TABLE IF NOT EXISTS chamber_commissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    commission_name VARCHAR(180) NOT NULL,
    chairperson_name VARCHAR(150) NOT NULL,
    resolution_title VARCHAR(240) NOT NULL,
    requested_course_topic VARCHAR(220) NOT NULL,
    priority_level ENUM('فوری استانی','اولویت فصلی','برنامه سالانه') DEFAULT 'فوری استانی',
    converted_to_tms TINYINT(1) DEFAULT 0,
    session_shamsi VARCHAR(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- تضمین کیفیت، ممیزی استاندارد ISO 21001 / ISO 10015 و CAPA
CREATE TABLE IF NOT EXISTS iso_qa_records (
    id INT AUTO_INCREMENT PRIMARY KEY,
    standard_code VARCHAR(60) DEFAULT 'ISO 21001:2018',
    clause_title VARCHAR(200) NOT NULL,
    finding_type ENUM('انطباق کامل','عدم انطباق جزئی','فرصت بهبود') DEFAULT 'انطباق کامل',
    capa_action TEXT NOT NULL,
    owner_unit VARCHAR(120) NOT NULL,
    status ENUM('باز','اقدام اصلاحی انجام شد','تأیید ممیز نهایی') DEFAULT 'تأیید ممیز نهایی',
    audit_shamsi VARCHAR(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- کلینیک عارضه‌یابی صنعتی و سنجش آمادگی صادراتی (ERA)
CREATE TABLE IF NOT EXISTS business_clinic_cases (
    id INT AUTO_INCREMENT PRIMARY KEY,
    org_name VARCHAR(180) NOT NULL,
    industry_sector VARCHAR(120) NOT NULL,
    era_production_score INT DEFAULT 70,
    era_packaging_score INT DEFAULT 55,
    era_marketing_score INT DEFAULT 45,
    era_finance_legal_score INT DEFAULT 60,
    total_era_index INT DEFAULT 58,
    main_bottleneck VARCHAR(220) NOT NULL,
    prescribed_pack VARCHAR(240) NOT NULL,
    diagnosed_shamsi VARCHAR(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بازارگاه اشتغال تخصصی و همرسانی نیروی ماهر به صنایع عضو
CREATE TABLE IF NOT EXISTS job_board_listings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    org_name VARCHAR(180) NOT NULL,
    job_title VARCHAR(180) NOT NULL,
    required_cert_code VARCHAR(80) NOT NULL,
    city VARCHAR(80) DEFAULT 'مرکز استان',
    salary_range VARCHAR(100) DEFAULT 'توافقی + بیمه تکمیلی',
    matched_candidates INT DEFAULT 3,
    status ENUM('فعال','در مرحله مصاحبه','جذب شد') DEFAULT 'فعال',
    posted_shamsi VARCHAR(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- تفاهم‌نامه‌ها (MoU)، یارانه‌های آموزشی SMEها و اسپانسرینگ
CREATE TABLE IF NOT EXISTS grants_and_mous (
    id INT AUTO_INCREMENT PRIMARY KEY,
    record_category ENUM('تفاهم‌نامه همکاری','یارانه آموزشی SME','حامی مالی همایش') DEFAULT 'یارانه آموزشی SME',
    partner_organization VARCHAR(200) NOT NULL,
    title VARCHAR(220) NOT NULL,
    subsidy_percent INT DEFAULT 50,
    allocated_budget_rial BIGINT DEFAULT 500000000,
    utilized_rial BIGINT DEFAULT 180000000,
    expiry_shamsi VARCHAR(30) NOT NULL,
    status VARCHAR(50) DEFAULT 'فعال و قابل تخصیص'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- احراز هویت یکپارچه کشوری، شاهکار، OTP و امضای دیجیتال اسناد
CREATE TABLE IF NOT EXISTS sso_pki_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_full_name VARCHAR(160) NOT NULL,
    national_code VARCHAR(20) NOT NULL,
    mobile_number VARCHAR(20) NOT NULL,
    shahkar_status VARCHAR(100) DEFAULT 'شبیه‌سازی محلی - اتصال شاهکار انجام نشده',
    document_title VARCHAR(200) NOT NULL,
    pki_hash_sha256 VARCHAR(128) NOT NULL,
    signed_shamsi VARCHAR(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- نظارت هوشمند آزمون (Proctoring) و حفاظت محتوا (DRM Watermark)
CREATE TABLE IF NOT EXISTS proctoring_events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_full_name VARCHAR(160) NOT NULL,
    exam_or_lesson_title VARCHAR(200) NOT NULL,
    event_type ENUM('تغییر تب مرورگر','خروج از تمام‌صفحه','تغییر آدرس IP','فعال‌سازی واترمارک پویا') DEFAULT 'تغییر تب مرورگر',
    risk_level ENUM('کم','متوسط','شدید - بازبینی کمیته') DEFAULT 'کم',
    watermark_stamp VARCHAR(140) NOT NULL,
    reviewer_decision VARCHAR(80) DEFAULT 'تأیید سلامت آزمون',
    logged_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- باشگاه دانش‌آموختگان و شبکه‌سازی مدیران اتاق
CREATE TABLE IF NOT EXISTS alumni_network_posts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    author_name VARCHAR(160) NOT NULL,
    company_and_role VARCHAR(180) NOT NULL,
    graduated_course VARCHAR(180) NOT NULL,
    collaboration_type ENUM('کنسرسیوم صادراتی','تأمین مواد اولیه','همرسانی حمل‌ونقل','پرسش تخصصی همتایان') DEFAULT 'کنسرسیوم صادراتی',
    proposal_body TEXT NOT NULL,
    responses_count INT DEFAULT 4,
    posted_shamsi VARCHAR(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- درگاه پیامک ایرانی و بازوهای پیام‌رسان بومی (بله و ایتا)
CREATE TABLE IF NOT EXISTS iran_messenger_dispatches (
    id INT AUTO_INCREMENT PRIMARY KEY,
    channel ENUM('کاوه‌نگار SMS','ملی‌پیامک SMS','بازوی بله (Bale)','بازوی ایتا (Eitaa)') DEFAULT 'کاوه‌نگار SMS',
    recipient_group VARCHAR(160) NOT NULL,
    message_text TEXT NOT NULL,
    delivery_mode VARCHAR(50) DEFAULT 'ثبت محلی - ارسال نشده',
    sent_count INT DEFAULT 0,
    sent_shamsi VARCHAR(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- دفاتر نمایندگی شهرستان‌ها و مدیریت چندشعبه‌ای استان
CREATE TABLE IF NOT EXISTS county_branches (
    id INT AUTO_INCREMENT PRIMARY KEY,
    county_name VARCHAR(120) NOT NULL,
    branch_manager VARCHAR(150) NOT NULL,
    active_courses_count INT DEFAULT 4,
    trained_learners_count INT DEFAULT 120,
    annual_budget_rial BIGINT DEFAULT 1200000000,
    spent_budget_rial BIGINT DEFAULT 680000000,
    key_specialty VARCHAR(180) NOT NULL,
    status VARCHAR(40) DEFAULT 'فعال'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- فازهای ۱۱ تا ۱۳: جداول تکمیلی عمیق هسته عملیاتی (یادداشت ثانیه‌ای، چک‌های صیادی ۱۶ رقمی، آزمایشگاه اسناد بازرگانی و داوری همتای پژوهش)
CREATE TABLE IF NOT EXISTS lms_learner_notes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    lesson_id INT NOT NULL,
    video_timestamp VARCHAR(16) DEFAULT '00:00',
    note_body TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ★ v26.8 — یادداشت‌های ثانیه‌ای نمونه فراگیر (خوراک «کارت‌سازی خودکار از یادداشت‌ها» در مربی هوشمند)
INSERT IGNORE INTO lms_learner_notes (id, user_id, lesson_id, video_timestamp, note_body) VALUES
(1, 7, 1, '07:12', 'در اینکوترمز ۲۰۲۰، با CIF هزینه و ریسک حمل تا بندر مقصد با فروشنده است، اما بیمه فقط حداقل پوشش (Institute Cargo Clauses C) است؛ برای کالای حساس باید پوشش All Risks را جداگانه درخواست کنم.'),
(2, 7, 1, '18:40', 'نکته آزمون: در EXW انتقال ریسک در محل فروشنده اتفاق می‌افتد، پس ترخیص خروجی هم با خریدار است — این قلاب پرتکرار را در سؤالات تطبیق فراموش نکنم.'),
(3, 7, 2, '05:25', 'مبنای حق‌الوکاله کارگزاری: درصدی از ارزش CIF به‌همراه هزینه‌های جانبی؛ در پرونده قبلی هزینه انبارش را جدا محاسبه کردند، باید آن را در چک‌لیست مذاکره بیاورم.'),
(4, 7, 3, '11:05', 'در اعتبار اسنادی، تطابق اسناد حداکثر پنج روز کاری بررسی می‌شود؛ تاریخ سررسید سند را در تقویم شمسی ثبت می‌کنم تا پشت‌افتادگی پیدا نشود.'),
(5, 8, 2, '03:50', 'خلاصه شخصی من: در FOB، هزینه بارگیری و ریسک تا روی عرشه با فروشنده است و بیمه دریایی از همان لحظه به خریدار منتقل می‌شود.');

CREATE TABLE IF NOT EXISTS sayad_cheques (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sayad_16digit VARCHAR(20) NOT NULL UNIQUE,
    drawer_company VARCHAR(190) NOT NULL,
    bank_name VARCHAR(90) NOT NULL,
    amount_rial BIGINT NOT NULL DEFAULT 0,
    due_shamsi VARCHAR(20) NOT NULL,
    inquiry_color VARCHAR(40) DEFAULT 'سفید - بدون چک برگشتی',
    clearance_status VARCHAR(40) DEFAULT 'در جریان وصول',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS trade_doc_submissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    doc_type VARCHAR(70) NOT NULL,
    hs_code VARCHAR(25) NOT NULL,
    incoterm_rule VARCHAR(20) NOT NULL,
    currency_amount VARCHAR(60) NOT NULL,
    destination_port VARCHAR(120) NOT NULL,
    compliance_score INT DEFAULT 100,
    audit_feedback TEXT,
    submitted_shamsi VARCHAR(25) DEFAULT '',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS research_peer_reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL,
    reviewer_alias VARCHAR(90) NOT NULL,
    scientific_score INT DEFAULT 85,
    applicability_score INT DEFAULT 90,
    recommendation VARCHAR(60) DEFAULT 'تأیید و آزادسازی قسط بودجه',
    review_comment TEXT,
    reviewed_shamsi VARCHAR(25) DEFAULT '',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- محورهای ۳، ۴ و ۸ نسخه v8.0: جداول اسلات مذاکرات B2B، سند حسابداری ۴ سطحی دوبل و گفت‌وگوی چندنوبته مذاکره تجاری
CREATE TABLE IF NOT EXISTS b2b_matchmaking_slots (
    id INT AUTO_INCREMENT PRIMARY KEY,
    mission_id INT NOT NULL DEFAULT 1,
    slot_time VARCHAR(40) NOT NULL,
    table_no VARCHAR(25) NOT NULL,
    iranian_company VARCHAR(190) NOT NULL,
    foreign_counterpart VARCHAR(190) NOT NULL,
    product_hs_focus VARCHAR(150) NOT NULL,
    interpreter_lang VARCHAR(50) DEFAULT 'عربی / انگلیسی',
    outcome_status VARCHAR(60) DEFAULT 'برنامه‌ریزی شده',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS accounting_vouchers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    voucher_no VARCHAR(40) NOT NULL UNIQUE,
    voucher_shamsi VARCHAR(25) NOT NULL,
    group_code VARCHAR(40) NOT NULL,
    kol_account VARCHAR(90) NOT NULL,
    moein_account VARCHAR(120) NOT NULL,
    tafsili_entity VARCHAR(150) NOT NULL,
    debit_rial BIGINT NOT NULL DEFAULT 0,
    credit_rial BIGINT NOT NULL DEFAULT 0,
    voucher_desc VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS trade_negotiation_turns (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    scenario_lang VARCHAR(30) DEFAULT 'fa',
    buyer_persona VARCHAR(140) DEFAULT 'واردکننده عمده خشکبار در دبی',
    exporter_message TEXT NOT NULL,
    ai_counter_offer TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- رادار هوشمند بازار آموزش، پایش زنده رقبا در وب و تحقیق و توسعه (Market Radar & R&D Intelligence)
CREATE TABLE IF NOT EXISTS rd_competitors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(180) NOT NULL,
    category VARCHAR(90) NOT NULL,
    website_url VARCHAR(255) NOT NULL,
    city_scope VARCHAR(80) DEFAULT 'ملی / آنلاین',
    avg_hourly_rate_rial BIGINT DEFAULT 3000000,
    delivery_model VARCHAR(90) DEFAULT 'حضوری و آنلاین هم‌زمان',
    key_strengths TEXT,
    key_weaknesses TEXT,
    last_crawled_at VARCHAR(40) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS rd_competitor_courses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    competitor_id INT NOT NULL,
    course_title VARCHAR(220) NOT NULL,
    duration_hours INT DEFAULT 24,
    tuition_rial BIGINT DEFAULT 45000000,
    delivery_format VARCHAR(60) DEFAULT 'آنلاین / حضوری',
    source_url VARCHAR(500) DEFAULT '',
    our_catalog_status VARCHAR(90) DEFAULT 'شکاف کاتالوگ (اقیانوس آبی)',
    captured_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS rd_web_signals (
    id INT AUTO_INCREMENT PRIMARY KEY,
    keyword_query VARCHAR(160) NOT NULL,
    signal_title VARCHAR(255) NOT NULL,
    source_engine VARCHAR(70) DEFAULT 'DuckDuckGo Live Web',
    source_url VARCHAR(600) DEFAULT '',
    demand_score INT DEFAULT 88,
    competition_saturation INT DEFAULT 35,
    opportunity_index INT DEFAULT 82,
    catalog_gap_status VARCHAR(90) DEFAULT 'شکاف طلایی کاتالوگ (پیشنهاد ساخت)',
    discovered_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS rd_course_proposals (
    id INT AUTO_INCREMENT PRIMARY KEY,
    proposal_code VARCHAR(40) NOT NULL UNIQUE,
    proposed_title VARCHAR(220) NOT NULL,
    target_audience VARCHAR(180) NOT NULL,
    recommended_hours INT DEFAULT 24,
    competitor_avg_rial BIGINT DEFAULT 68000000,
    suggested_tuition_rial BIGINT DEFAULT 58000000,
    breakeven_learners INT DEFAULT 9,
    projected_net_rial BIGINT DEFAULT 620000000,
    strategic_rationale TEXT NOT NULL,
    syllabus_outline TEXT NOT NULL,
    ai_confidence_score INT DEFAULT 92,
    status VARCHAR(70) DEFAULT 'آماده طرح در شورای R&D',
    launched_course_id INT DEFAULT NULL,
    created_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- آرشیو نتایج آزمون‌های استاندارد روان‌شناختی، شغلی، زبان و صلاحیت حرفه‌ای
CREATE TABLE IF NOT EXISTS standard_test_catalog (
    id INT AUTO_INCREMENT PRIMARY KEY,
    test_code VARCHAR(40) NOT NULL UNIQUE,
    category_key VARCHAR(40) NOT NULL,
    category_label VARCHAR(90) NOT NULL,
    title_fa VARCHAR(200) NOT NULL,
    standard_ref VARCHAR(120) NOT NULL,
    duration_min INT DEFAULT 10,
    items_count INT DEFAULT 6,
    scale_type VARCHAR(40) DEFAULT 'psychometric',
    summary_text VARCHAR(255) NOT NULL,
    recommended_course VARCHAR(190) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS standard_test_results (
    id INT AUTO_INCREMENT PRIMARY KEY,
    report_code VARCHAR(45) NOT NULL UNIQUE,
    user_id INT NOT NULL,
    test_code VARCHAR(40) NOT NULL,
    test_title VARCHAR(200) NOT NULL,
    result_badge VARCHAR(140) NOT NULL,
    score_pct INT DEFAULT 85,
    interpretation_text TEXT NOT NULL,
    recommended_course VARCHAR(190) NOT NULL,
    dimensions_json TEXT,
    completed_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- مرکز فرماندهی صوتی سراسری، مفسر زبان طبیعی فارسی و عامل اقدام‌گر (Global Voice Action OS)
CREATE TABLE IF NOT EXISTS voice_command_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL DEFAULT 1,
    spoken_text VARCHAR(500) NOT NULL,
    detected_intent VARCHAR(50) NOT NULL,
    target_route VARCHAR(80) DEFAULT '',
    action_summary VARCHAR(255) NOT NULL,
    spoken_response TEXT NOT NULL,
    created_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- هسته مرکزی ERP هوشمند، قوانین خودران میان‌ماژولی، پیش‌بینی RFM، زمان‌بند محدودیت‌محور و تطبیق مهارت-صنعت (جداول ۹۶ تا ۱۰۰)
CREATE TABLE IF NOT EXISTS erp_automation_rules (
    id INT AUTO_INCREMENT PRIMARY KEY,
    rule_code VARCHAR(40) NOT NULL UNIQUE,
    rule_title VARCHAR(200) NOT NULL,
    source_module VARCHAR(80) NOT NULL,
    trigger_condition VARCHAR(220) NOT NULL,
    target_modules VARCHAR(180) NOT NULL,
    autonomous_action VARCHAR(255) NOT NULL,
    executions_count INT DEFAULT 0,
    last_triggered_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS erp_smart_alerts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    alert_code VARCHAR(40) NOT NULL UNIQUE,
    severity VARCHAR(20) NOT NULL DEFAULT 'warning',
    module_route VARCHAR(80) NOT NULL,
    alert_title VARCHAR(210) NOT NULL,
    ai_diagnosis TEXT NOT NULL,
    prescribed_action VARCHAR(240) NOT NULL,
    financial_impact_rial BIGINT DEFAULT 0,
    status VARCHAR(30) DEFAULT 'open',
    resolved_shamsi VARCHAR(30) DEFAULT '',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS crm_rfm_scores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    org_id INT NOT NULL,
    org_name VARCHAR(180) NOT NULL,
    recency_days INT DEFAULT 18,
    frequency_count INT DEFAULT 4,
    monetary_rial BIGINT DEFAULT 180000000,
    rfm_composite INT DEFAULT 85,
    segment_label VARCHAR(80) NOT NULL,
    churn_probability_pct INT DEFAULT 12,
    next_best_course VARCHAR(200) NOT NULL,
    prescribed_discount_pct INT DEFAULT 10,
    updated_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ai_schedule_optimizations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_code VARCHAR(40) NOT NULL,
    course_title VARCHAR(200) NOT NULL,
    instructor_name VARCHAR(140) NOT NULL,
    classroom_name VARCHAR(140) NOT NULL,
    assigned_slot VARCHAR(90) NOT NULL,
    predicted_learners INT DEFAULT 22,
    room_capacity INT DEFAULT 25,
    utilization_pct INT DEFAULT 88,
    conflict_status VARCHAR(80) DEFAULT 'بدون تداخل (بهینه ۱۰۰٪)',
    generated_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ai_skill_job_matches (
    id INT AUTO_INCREMENT PRIMARY KEY,
    candidate_name VARCHAR(140) NOT NULL,
    psychometric_badge VARCHAR(120) NOT NULL,
    target_company VARCHAR(180) NOT NULL,
    job_role_title VARCHAR(180) NOT NULL,
    match_score_pct INT DEFAULT 91,
    verified_skills VARCHAR(240) NOT NULL,
    recommended_gap_course VARCHAR(190) NOT NULL,
    status VARCHAR(60) DEFAULT 'معرفی‌شده هوشمند به صنعت',
    matched_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- نسخه مرجع v12.0: مجموعه عمیق‌سازی تخصصی ماژول‌های صنعتی، مالیاتی، تطبیقی CAT، کنسرسیوم صادراتی و کمیسیون‌ها (جداول ۱۰۱ تا ۱۰۵)
CREATE TABLE IF NOT EXISTS factory_prescriptions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    rx_code VARCHAR(40) NOT NULL UNIQUE,
    factory_name VARCHAR(180) NOT NULL,
    sector VARCHAR(100) NOT NULL,
    prod_score INT DEFAULT 70,
    energy_cbam_score INT DEFAULT 55,
    export_fx_score INT DEFAULT 62,
    working_cap_score INT DEFAULT 68,
    b2b_brand_score INT DEFAULT 58,
    hr_skill_score INT DEFAULT 64,
    ai_digital_score INT DEFAULT 50,
    overall_health_idx INT DEFAULT 61,
    primary_bottleneck VARCHAR(220) NOT NULL,
    roadmap_180d TEXT NOT NULL,
    assigned_consultant VARCHAR(140) NOT NULL,
    approved_subsidy_pct INT DEFAULT 30,
    created_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS adaptive_cat_sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    session_code VARCHAR(40) NOT NULL UNIQUE,
    candidate_name VARCHAR(140) NOT NULL,
    domain_title VARCHAR(160) NOT NULL,
    questions_administered INT DEFAULT 6,
    final_difficulty_level INT DEFAULT 4,
    theta_ability DECIMAL(4,2) DEFAULT 1.85,
    cefr_or_mastery_band VARCHAR(90) NOT NULL,
    tab_switches_detected INT DEFAULT 0,
    collusion_similarity_pct INT DEFAULT 4,
    integrity_score INT DEFAULT 98,
    completed_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ocr_financial_scans (
    id INT AUTO_INCREMENT PRIMARY KEY,
    scan_code VARCHAR(40) NOT NULL UNIQUE,
    doc_type VARCHAR(60) NOT NULL,
    raw_extracted_text TEXT NOT NULL,
    detected_amount_rial BIGINT NOT NULL DEFAULT 0,
    detected_sayad_or_ref VARCHAR(40) NOT NULL,
    detected_iban VARCHAR(34) DEFAULT '',
    checksum_verified TINYINT(1) DEFAULT 0,
    moadian_vat_status VARCHAR(120) DEFAULT 'پیش‌نویس محلی - وضعیت مالیاتی بررسی نشده/ارسال نشده',
    booked_voucher_no VARCHAR(40) NOT NULL DEFAULT '',
    scanned_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS export_consortium_groups (
    id INT AUTO_INCREMENT PRIMARY KEY,
    consortium_code VARCHAR(40) NOT NULL UNIQUE,
    consortium_title VARCHAR(200) NOT NULL,
    target_market VARCHAR(100) NOT NULL,
    hs_code_cluster VARCHAR(80) NOT NULL,
    lead_producer_org VARCHAR(160) NOT NULL,
    packaging_logistics_org VARCHAR(160) NOT NULL,
    trading_house_org VARCHAR(160) NOT NULL,
    synergy_score_pct INT DEFAULT 92,
    annual_target_usd BIGINT DEFAULT 1200000,
    status VARCHAR(80) DEFAULT 'پیش‌نویس اساسنامه کنسرسیوم آماده امضا',
    created_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS commission_policy_briefs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    brief_code VARCHAR(40) NOT NULL UNIQUE,
    commission_name VARCHAR(160) NOT NULL,
    recipient_authority VARCHAR(160) NOT NULL,
    issue_summary VARCHAR(240) NOT NULL,
    legal_citation VARCHAR(220) NOT NULL,
    formal_letter_body TEXT NOT NULL,
    status VARCHAR(60) DEFAULT 'آماده امضای مدیر مؤسسه آدان استان',
    created_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- نسخه مرجع نهایی v13.0: قله نهایی هوشمندی صددرصدی تمام ماژول‌ها (یادگیری تطبیقی LMS، ممیزی قرارداد صادراتی، مرجعیت اساتید، معدن‌کاوی BPMS و آمایش شهرستان‌ها — جداول ۱۰۶ تا ۱۱۰)
CREATE TABLE IF NOT EXISTS lms_adaptive_paths (
    id INT AUTO_INCREMENT PRIMARY KEY,
    learner_name VARCHAR(140) NOT NULL,
    course_title VARCHAR(190) NOT NULL,
    lesson_timestamp VARCHAR(30) DEFAULT '۱۲:۴۰',
    learner_question VARCHAR(255) NOT NULL,
    ai_timestamp_answer TEXT NOT NULL,
    quiz_diagnostic_pct INT DEFAULT 62,
    injected_remedial_micro VARCHAR(220) NOT NULL,
    spaced_repetition_cards INT DEFAULT 5,
    created_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS trade_contract_redlines (
    id INT AUTO_INCREMENT PRIMARY KEY,
    audit_code VARCHAR(40) NOT NULL UNIQUE,
    contract_title VARCHAR(190) NOT NULL,
    counterparty_country VARCHAR(80) NOT NULL,
    submitted_clause TEXT NOT NULL,
    safety_score_pct INT DEFAULT 54,
    detected_traps VARCHAR(255) NOT NULL,
    icc_protective_rewrite TEXT NOT NULL,
    audited_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS instructor_impact_scores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    instructor_name VARCHAR(140) NOT NULL,
    kirkpatrick_avg DECIMAL(3,2) DEFAULT 4.75,
    exam_pass_rate_pct INT DEFAULT 92,
    repeat_retention_pct INT DEFAULT 84,
    sla_punctuality_pct INT DEFAULT 96,
    composite_impact_score INT DEFAULT 91,
    academic_tier_badge VARCHAR(80) NOT NULL,
    suggested_hourly_rial BIGINT DEFAULT 6500000,
    evaluated_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bpms_process_mining (
    id INT AUTO_INCREMENT PRIMARY KEY,
    stage_code VARCHAR(40) NOT NULL UNIQUE,
    department_stage VARCHAR(160) NOT NULL,
    active_cases_count INT DEFAULT 12,
    avg_dwell_hours DECIMAL(5,1) DEFAULT 6.5,
    sla_target_hours INT DEFAULT 12,
    bottleneck_severity VARCHAR(140) DEFAULT 'سبز — داخل SLA',
    auto_escalation_rule VARCHAR(220) NOT NULL,
    mined_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS county_economic_clusters (
    id INT AUTO_INCREMENT PRIMARY KEY,
    county_name VARCHAR(120) NOT NULL,
    dominant_cluster VARCHAR(160) NOT NULL,
    active_industrial_units INT DEFAULT 140,
    skill_gap_index INT DEFAULT 76,
    prescribed_mobile_workshop VARCHAR(210) NOT NULL,
    recommended_budget_share_pct INT DEFAULT 22,
    projected_export_boost_usd BIGINT DEFAULT 850000,
    analyzed_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- نسخه مرجع فوق‌پیشرفته v14.0: اتاق جنگ مدیران عامل، بهینه‌ساز یارانه SME، قیمت‌گذاری پویا، پایش سوخت سهمیه B2B، مسیریاب عمومی و جست‌وجوی معنایی RAG (جداول ۱۱۱ تا ۱۱۶)
CREATE TABLE IF NOT EXISTS executive_warroom_simulations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sim_code VARCHAR(40) NOT NULL UNIQUE,
    ceo_participant VARCHAR(140) NOT NULL,
    shock_scenario VARCHAR(190) NOT NULL,
    chosen_strategy VARCHAR(220) NOT NULL,
    cashflow_runway_months DECIMAL(4,1) DEFAULT 9.5,
    export_share_retention_pct INT DEFAULT 88,
    resilience_score INT DEFAULT 90,
    board_ai_critique TEXT NOT NULL,
    simulated_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS sme_subsidy_allocations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    alloc_code VARCHAR(40) NOT NULL UNIQUE,
    sme_company_name VARCHAR(180) NOT NULL,
    employees_count INT DEFAULT 45,
    export_readiness_idx INT DEFAULT 72,
    requested_subsidy_pct INT DEFAULT 50,
    ai_approved_subsidy_pct INT DEFAULT 38,
    economic_roi_multiplier DECIMAL(4,2) DEFAULT 4.20,
    priority_rank_label VARCHAR(90) NOT NULL,
    allocated_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS tms_dynamic_pricing_rules (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_code VARCHAR(40) NOT NULL,
    course_title VARCHAR(200) NOT NULL,
    base_tuition_rial BIGINT NOT NULL,
    seat_fill_pct INT DEFAULT 78,
    days_to_start INT DEFAULT 6,
    ai_pricing_tier VARCHAR(110) NOT NULL,
    dynamic_tuition_rial BIGINT NOT NULL,
    projected_revenue_gain_pct INT DEFAULT 18,
    updated_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS b2b_quota_burn_alerts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    org_name VARCHAR(180) NOT NULL,
    contract_title VARCHAR(190) NOT NULL,
    elapsed_year_pct INT DEFAULT 68,
    quota_used_pct INT DEFAULT 31,
    burn_status VARCHAR(90) NOT NULL,
    auto_triggered_offer VARCHAR(230) NOT NULL,
    monitored_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS public_ai_pathfinder_leads (
    id INT AUTO_INCREMENT PRIMARY KEY,
    visitor_fullname VARCHAR(140) NOT NULL,
    visitor_mobile VARCHAR(30) NOT NULL,
    visitor_goal VARCHAR(160) NOT NULL,
    industry_field VARCHAR(120) NOT NULL,
    recommended_roadmap VARCHAR(240) NOT NULL,
    estimated_90d_roi VARCHAR(140) NOT NULL,
    synced_crm_status VARCHAR(80) DEFAULT 'ثبت خودکار سرنخ داغ در CRM',
    captured_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS student_admissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(160) NOT NULL,
    mobile VARCHAR(30) NOT NULL,
    course_id INT NOT NULL,
    prior_education VARCHAR(255) NULL,
    status ENUM('submitted','contacted','accepted','rejected','enrolled') DEFAULT 'submitted',
    review_note VARCHAR(500) NULL,
    user_id INT NULL,
    enrollment_id INT NULL,
    invoice_id INT NULL,
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_admission_status (status, submitted_at),
    INDEX idx_admission_course (course_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS rag_knowledge_chunks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    doc_code VARCHAR(40) NOT NULL UNIQUE,
    source_authority VARCHAR(160) NOT NULL,
    clause_reference VARCHAR(140) NOT NULL,
    topic_keywords VARCHAR(220) NOT NULL,
    chunk_text TEXT NOT NULL,
    updated_shamsi VARCHAR(30) DEFAULT '۱۴۰۵/۰۷/۳۰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==================== نسخه v15.0: زنجیره هش ضدجعل گواهی، لیگ شبیه‌ساز، SOC امنیتی، اعتبار مالیاتی پویش، همرسان رزومه و گذرگاه ملی NIX ====================
CREATE TABLE IF NOT EXISTS verifiable_credential_blocks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    block_height INT NOT NULL,
    cert_or_badge_code VARCHAR(60) NOT NULL,
    holder_fullname VARCHAR(150) NOT NULL,
    prev_block_hash CHAR(64) NOT NULL,
    block_sha256_hash CHAR(64) NOT NULL,
    w3c_standard_version VARCHAR(60) DEFAULT 'چکیده محلی؛ استاندارد یا امضای W3C تأیید نشده',
    sealed_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bizsim_league_rounds (
    id INT AUTO_INCREMENT PRIMARY KEY,
    round_code VARCHAR(40) NOT NULL UNIQUE,
    team_name VARCHAR(150) NOT NULL,
    quarter_label VARCHAR(50) NOT NULL,
    export_pricing_usd DECIMAL(10,2) NOT NULL DEFAULT 1250.00,
    fx_hedge_ratio_pct INT NOT NULL DEFAULT 60,
    rnd_investment_pct INT NOT NULL DEFAULT 12,
    simulated_ebitda_usd BIGINT NOT NULL DEFAULT 185000,
    elo_rating INT NOT NULL DEFAULT 1620,
    ai_referee_note VARCHAR(255) NOT NULL,
    played_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS security_soc_telemetry (
    id INT AUTO_INCREMENT PRIMARY KEY,
    event_code VARCHAR(40) NOT NULL UNIQUE,
    actor_username VARCHAR(100) NOT NULL,
    client_ip VARCHAR(60) NOT NULL,
    geo_and_device VARCHAR(160) NOT NULL,
    risk_score INT NOT NULL DEFAULT 12,
    threat_classification VARCHAR(160) NOT NULL,
    mitigation_action VARCHAR(160) NOT NULL,
    detected_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS pooyesh_stipend_claims (
    id INT AUTO_INCREMENT PRIMARY KEY,
    claim_code VARCHAR(40) NOT NULL UNIQUE,
    host_company VARCHAR(160) NOT NULL,
    intern_fullname VARCHAR(140) NOT NULL,
    duration_months INT NOT NULL DEFAULT 4,
    monthly_stipend_rial BIGINT NOT NULL DEFAULT 95000000,
    total_paid_rial BIGINT NOT NULL DEFAULT 380000000,
    tax_credit_approved_rial BIGINT NOT NULL DEFAULT 380000000,
    statutory_clause VARCHAR(180) DEFAULT 'ماده ۱۱ قانون جهش تولید دانش‌بنیان (اعتبار مالیاتی طرح پویش)',
    created_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ai_cv_match_interviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    match_code VARCHAR(40) NOT NULL UNIQUE,
    candidate_name VARCHAR(150) NOT NULL,
    target_company VARCHAR(160) NOT NULL,
    target_role VARCHAR(160) NOT NULL,
    verified_certs_summary VARCHAR(220) NOT NULL,
    vector_similarity_pct INT NOT NULL DEFAULT 91,
    generated_interview_guide TEXT NOT NULL,
    matched_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS national_bus_inquiries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    trace_code VARCHAR(45) NOT NULL UNIQUE,
    target_system VARCHAR(140) NOT NULL,
    identifier_queried VARCHAR(90) NOT NULL,
    math_checksum_valid TINYINT(1) NOT NULL DEFAULT 0,
    gateway_execution_mode VARCHAR(90) DEFAULT 'پیش‌نمایش محلی - استعلام انجام نشده',
    response_summary VARCHAR(255) NOT NULL,
    customs_duty_pct INT DEFAULT NULL,
    inquired_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==================== نسخه v16.0: تحلیل رفتار فراگیران (xAPI / LBA) و موتور گیمیفیکیشن سراسری کل سامانه ====================
CREATE TABLE IF NOT EXISTS learner_behavior_events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL DEFAULT 1,
    learner_name VARCHAR(150) NOT NULL,
    module_route VARCHAR(80) NOT NULL,
    action_verb VARCHAR(90) NOT NULL,
    dwell_seconds INT NOT NULL DEFAULT 180,
    scroll_depth_pct INT NOT NULL DEFAULT 85,
    focus_index_pct INT NOT NULL DEFAULT 92,
    study_hour_band VARCHAR(50) DEFAULT '۱۹:۰۰ تا ۲۲:۰۰ (اوج تمرکز)',
    xp_awarded INT NOT NULL DEFAULT 25,
    created_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS learner_dropout_predictions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    learner_name VARCHAR(150) NOT NULL,
    org_name VARCHAR(160) NOT NULL,
    enrolled_course VARCHAR(190) NOT NULL,
    learning_persona VARCHAR(120) NOT NULL,
    engagement_score INT NOT NULL DEFAULT 72,
    dropout_risk_pct INT NOT NULL DEFAULT 24,
    last_login_days_ago INT NOT NULL DEFAULT 2,
    ai_intervention_status VARCHAR(220) NOT NULL,
    updated_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS gamification_wallets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,
    learner_name VARCHAR(150) NOT NULL,
    org_name VARCHAR(160) NOT NULL,
    xp_points INT NOT NULL DEFAULT 1200,
    chamber_coins INT NOT NULL DEFAULT 450,
    level_num INT NOT NULL DEFAULT 4,
    rank_title VARCHAR(120) NOT NULL DEFAULT 'کارشناس ارشد تجارت',
    streak_days INT NOT NULL DEFAULT 7,
    badges_count INT NOT NULL DEFAULT 4,
    updated_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS gamification_quests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    quest_code VARCHAR(40) NOT NULL UNIQUE,
    title VARCHAR(190) NOT NULL,
    target_module_route VARCHAR(80) NOT NULL,
    difficulty_tier VARCHAR(50) NOT NULL DEFAULT 'حرفه‌ای',
    xp_reward INT NOT NULL DEFAULT 250,
    coin_reward INT NOT NULL DEFAULT 120,
    progress_pct INT NOT NULL DEFAULT 80,
    is_claimed TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS gamification_reward_store (
    id INT AUTO_INCREMENT PRIMARY KEY,
    reward_code VARCHAR(40) NOT NULL UNIQUE,
    reward_title VARCHAR(190) NOT NULL,
    category_label VARCHAR(90) NOT NULL,
    coin_cost INT NOT NULL DEFAULT 800,
    stock_remaining INT NOT NULL DEFAULT 15,
    redeemed_count INT NOT NULL DEFAULT 3,
    last_voucher_serial VARCHAR(80) DEFAULT 'VCH-GAM-1405-INIT',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS content_friction_heatmaps (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_title VARCHAR(190) NOT NULL,
    lesson_segment VARCHAR(160) NOT NULL,
    avg_rewind_count DECIMAL(4,1) NOT NULL DEFAULT 3.2,
    dropoff_rate_pct INT NOT NULL DEFAULT 28,
    quiz_error_rate_pct INT NOT NULL DEFAULT 35,
    ai_pedagogical_fix VARCHAR(240) NOT NULL,
    analyzed_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==================== نسخه v17.0: پیشخوان‌های اختصاصی نقش‌محور ۸گانه و موتور عملیاتی هر نقش (Role-Personalized Cockpits) ====================
CREATE TABLE IF NOT EXISTS executive_signoff_queue (
    id INT AUTO_INCREMENT PRIMARY KEY,
    doc_ref_no VARCHAR(45) NOT NULL UNIQUE,
    doc_category VARCHAR(120) NOT NULL,
    subject_title VARCHAR(210) NOT NULL,
    amount_or_impact VARCHAR(140) NOT NULL,
    sign_status VARCHAR(50) NOT NULL DEFAULT 'pending',
    signature_sha256 CHAR(64) DEFAULT NULL,
    signed_by_name VARCHAR(140) DEFAULT NULL,
    signed_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS class_runbook_checklists (
    id INT AUTO_INCREMENT PRIMARY KEY,
    run_code VARCHAR(45) NOT NULL UNIQUE,
    course_title VARCHAR(190) NOT NULL,
    skyroom_link_ready TINYINT(1) NOT NULL DEFAULT 1,
    slides_uploaded TINYINT(1) NOT NULL DEFAULT 1,
    sms_24h_sent TINYINT(1) NOT NULL DEFAULT 0,
    hall_catering_ok TINYINT(1) NOT NULL DEFAULT 1,
    bulk_enrolled_count INT NOT NULL DEFAULT 18,
    readiness_pct INT NOT NULL DEFAULT 75,
    updated_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS tuition_refund_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    refund_code VARCHAR(45) NOT NULL UNIQUE,
    applicant_name VARCHAR(150) NOT NULL,
    course_title VARCHAR(190) NOT NULL,
    paid_tuition_rial BIGINT NOT NULL DEFAULT 52000000,
    hours_before_start INT NOT NULL DEFAULT 48,
    deduction_pct INT NOT NULL DEFAULT 15,
    net_refund_rial BIGINT NOT NULL DEFAULT 44200000,
    reversal_voucher_no VARCHAR(45) NOT NULL,
    processed_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS b2b_account_touchpoints (
    id INT AUTO_INCREMENT PRIMARY KEY,
    proposal_code VARCHAR(45) NOT NULL UNIQUE,
    company_name VARCHAR(160) NOT NULL,
    channel_source VARCHAR(90) NOT NULL,
    contact_summary VARCHAR(230) NOT NULL,
    proposed_package_rial BIGINT NOT NULL DEFAULT 680000000,
    win_probability_pct INT NOT NULL DEFAULT 78,
    next_followup_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۵',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS instructor_availability_endorsements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    record_code VARCHAR(45) NOT NULL UNIQUE,
    instructor_name VARCHAR(150) NOT NULL,
    free_weekly_slots VARCHAR(190) NOT NULL,
    endorsed_learner_name VARCHAR(150) NOT NULL,
    endorsed_skill_badge VARCHAR(180) NOT NULL,
    recommendation_note VARCHAR(240) NOT NULL,
    created_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS org_employee_training_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    req_code VARCHAR(45) NOT NULL UNIQUE,
    org_name VARCHAR(160) NOT NULL,
    employee_fullname VARCHAR(150) NOT NULL,
    department_unit VARCHAR(120) NOT NULL,
    requested_course VARCHAR(190) NOT NULL,
    hr_approval_status VARCHAR(60) NOT NULL DEFAULT 'در انتظار تأیید نماینده سازمان',
    contract_quota_deducted TINYINT(1) NOT NULL DEFAULT 0,
    requested_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS learner_personal_idp_steps (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL DEFAULT 7,
    learner_name VARCHAR(150) NOT NULL,
    step_order INT NOT NULL DEFAULT 1,
    milestone_title VARCHAR(200) NOT NULL,
    source_diagnostic VARCHAR(150) NOT NULL,
    xp_bonus INT NOT NULL DEFAULT 50,
    is_done TINYINT(1) NOT NULL DEFAULT 0,
    target_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۱۵',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==================== نسخه v18.0: ماژول جامع کاریابی، استودیو هوشمند انتشار آگهی، رزومه‌ساز تاییدشده و پایپ‌لاین ATS ====================
CREATE TABLE IF NOT EXISTS career_job_ads (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ad_code VARCHAR(45) NOT NULL UNIQUE,
    company_name VARCHAR(165) NOT NULL,
    is_verified_member TINYINT(1) NOT NULL DEFAULT 1,
    job_title VARCHAR(190) NOT NULL,
    category_slug VARCHAR(70) NOT NULL DEFAULT 'export_trade',
    cooperation_type VARCHAR(70) NOT NULL DEFAULT 'تمام‌وقت',
    seniority_level VARCHAR(70) NOT NULL DEFAULT 'کارشناس ارشد',
    city_location VARCHAR(110) NOT NULL DEFAULT 'شهرک صنعتی بزرگ استان',
    salary_min_million INT NOT NULL DEFAULT 42,
    salary_max_million INT NOT NULL DEFAULT 65,
    perks_badges VARCHAR(240) NOT NULL DEFAULT 'بیمه تکمیلی، پورسانت ارزی صادرات، ناهار و سرویس',
    required_skills_tags VARCHAR(240) NOT NULL,
    required_chamber_cert VARCHAR(190) NOT NULL,
    job_description_ai TEXT NOT NULL,
    is_urgent TINYINT(1) NOT NULL DEFAULT 0,
    views_count INT NOT NULL DEFAULT 140,
    applicants_count INT NOT NULL DEFAULT 6,
    ad_status VARCHAR(40) NOT NULL DEFAULT 'active',
    posted_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS career_candidate_profiles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,
    full_name VARCHAR(150) NOT NULL,
    headline_title VARCHAR(190) NOT NULL,
    experience_years INT NOT NULL DEFAULT 5,
    expected_salary_million INT NOT NULL DEFAULT 55,
    city_preference VARCHAR(110) NOT NULL DEFAULT 'مرکز استان / هیبرید',
    availability_status VARCHAR(90) NOT NULL DEFAULT 'آماده شروع فوری',
    foreign_languages VARCHAR(190) NOT NULL DEFAULT 'انگلیسی تجاری C1 (BEC) | عربی بازرگانی B2',
    core_skills_csv VARCHAR(250) NOT NULL,
    synced_certs_summary VARCHAR(240) NOT NULL,
    work_style_nonclinical VARCHAR(180) NOT NULL DEFAULT 'تیپ تحلیلی-نتیجه‌گرا (ENTJ — ارزیابی غیربالینی شغلی)',
    gamification_xp_badge VARCHAR(120) NOT NULL DEFAULT 'سطح ۸ — سفیر طلایی صادرات (۴,۸۹۰ XP)',
    updated_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS career_ats_applications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tracking_code VARCHAR(45) NOT NULL UNIQUE,
    job_ad_id INT NOT NULL,
    job_title_snapshot VARCHAR(190) NOT NULL,
    company_snapshot VARCHAR(165) NOT NULL,
    candidate_name VARCHAR(150) NOT NULL,
    ats_stage VARCHAR(45) NOT NULL DEFAULT 'ai_screened',
    ai_match_score_pct INT NOT NULL DEFAULT 93,
    skill_gap_prescription VARCHAR(240) NOT NULL,
    candidate_note VARCHAR(240) DEFAULT 'دارای گواهی رسمی QR اتاق و نمونه پرونده عملی صادراتی',
    applied_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS career_interview_schedules (
    id INT AUTO_INCREMENT PRIMARY KEY,
    interview_code VARCHAR(45) NOT NULL UNIQUE,
    candidate_name VARCHAR(150) NOT NULL,
    company_name VARCHAR(165) NOT NULL,
    job_title VARCHAR(190) NOT NULL,
    interview_mode VARCHAR(80) NOT NULL DEFAULT 'آنلاین (اتاق اختصاصی اسکای‌روم)',
    scheduled_shamsi VARCHAR(70) NOT NULL,
    interviewer_panel VARCHAR(160) NOT NULL,
    ai_tailored_questions TEXT NOT NULL,
    technical_score INT DEFAULT 91,
    interview_outcome VARCHAR(90) DEFAULT 'تأیید فنی — ارسال به مرحله پیشنهاد حقوق',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS career_job_offers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    offer_serial VARCHAR(45) NOT NULL UNIQUE,
    candidate_name VARCHAR(150) NOT NULL,
    company_name VARCHAR(165) NOT NULL,
    position_title VARCHAR(190) NOT NULL,
    base_monthly_million INT NOT NULL DEFAULT 58,
    export_commission_note VARCHAR(160) NOT NULL DEFAULT '۱.۵٪ پورسانت دلاری وصول ارزی صادرات + بیمه تکمیلی طلایی',
    start_date_shamsi VARCHAR(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۱۵',
    offer_status VARCHAR(70) NOT NULL DEFAULT 'ارسال‌شده به کارجو — منتظر امضا',
    created_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS career_salary_benchmarks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    role_family VARCHAR(165) NOT NULL,
    min_million INT NOT NULL,
    median_million INT NOT NULL,
    max_top_decile_million INT NOT NULL,
    market_demand_index INT NOT NULL DEFAULT 92,
    top_value_cert VARCHAR(190) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS career_job_fair_booths (
    id INT AUTO_INCREMENT PRIMARY KEY,
    booth_code VARCHAR(40) NOT NULL UNIQUE,
    company_name VARCHAR(165) NOT NULL,
    industry_sector VARCHAR(120) NOT NULL,
    open_positions_count INT NOT NULL DEFAULT 4,
    speed_interview_slots_left INT NOT NULL DEFAULT 7,
    featured_roles VARCHAR(220) NOT NULL,
    fair_date_shamsi VARCHAR(60) DEFAULT 'چهارشنبه ۱۴۰۵/۰۸/۱۴ — تالار بزرگ مؤسسه آموزشی آدان',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================================
-- v19.0 ENTERPRISE SETTINGS, LIVE THEME & FONT STUDIO, GRANULAR IAM/RBAC & ACADEMIC ERP CORE (#143 - #152)
-- =====================================================================

CREATE TABLE IF NOT EXISTS erp_ui_theme_profiles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    theme_slug VARCHAR(60) NOT NULL UNIQUE,
    theme_title VARCHAR(150) NOT NULL,
    color_mode VARCHAR(15) NOT NULL DEFAULT 'light',
    primary_hex VARCHAR(16) NOT NULL DEFAULT '#0f766e',
    gold_accent_hex VARCHAR(16) NOT NULL DEFAULT '#c99227',
    sidebar_bg_hex VARCHAR(16) NOT NULL DEFAULT '#0b1f3a',
    font_family_key VARCHAR(40) NOT NULL DEFAULT 'Vazirmatn',
    base_font_px INT NOT NULL DEFAULT 14,
    line_height_val VARCHAR(10) NOT NULL DEFAULT '1.75',
    border_radius_px INT NOT NULL DEFAULT 16,
    ui_density VARCHAR(20) NOT NULL DEFAULT 'comfortable',
    brand_org_title VARCHAR(190) NOT NULL DEFAULT 'مؤسسه آموزشی آدان',
    brand_unit_subtitle VARCHAR(190) NOT NULL DEFAULT 'آموزش تخصصی حسابداری و امور مالی',
    brand_monogram VARCHAR(16) NOT NULL DEFAULT 'ناب',
    is_active TINYINT(1) NOT NULL DEFAULT 0,
    updated_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS erp_system_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_group VARCHAR(50) NOT NULL,
    setting_key VARCHAR(90) NOT NULL UNIQUE,
    setting_label VARCHAR(180) NOT NULL,
    setting_value TEXT NOT NULL,
    input_type VARCHAR(30) NOT NULL DEFAULT 'text',
    updated_by VARCHAR(120) DEFAULT 'مدیرکل آموزش',
    updated_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS iam_custom_roles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    role_slug VARCHAR(60) NOT NULL UNIQUE,
    role_title_fa VARCHAR(160) NOT NULL,
    data_scope VARCHAR(40) NOT NULL DEFAULT 'global_province',
    badge_color VARCHAR(20) NOT NULL DEFAULT 'info',
    is_system_builtin TINYINT(1) NOT NULL DEFAULT 1,
    description_note VARCHAR(240) NOT NULL DEFAULT '',
    created_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS iam_role_permissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    role_slug VARCHAR(60) NOT NULL,
    module_domain VARCHAR(80) NOT NULL,
    module_label_fa VARCHAR(160) NOT NULL,
    can_view TINYINT(1) NOT NULL DEFAULT 1,
    can_create TINYINT(1) NOT NULL DEFAULT 0,
    can_edit TINYINT(1) NOT NULL DEFAULT 0,
    can_delete TINYINT(1) NOT NULL DEFAULT 0,
    can_approve TINYINT(1) NOT NULL DEFAULT 0,
    can_export TINYINT(1) NOT NULL DEFAULT 0,
    updated_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    UNIQUE KEY uq_role_domain (role_slug, module_domain)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS iam_user_overrides (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    user_fullname VARCHAR(150) NOT NULL,
    route_or_perm VARCHAR(90) NOT NULL,
    effect_type VARCHAR(15) NOT NULL DEFAULT 'allow',
    reason_note VARCHAR(220) NOT NULL,
    expires_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۱۲/۲۹',
    granted_by VARCHAR(120) DEFAULT 'مدیرکل آموزش',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS academic_terms_calendar (
    id INT AUTO_INCREMENT PRIMARY KEY,
    term_code VARCHAR(40) NOT NULL UNIQUE,
    term_title VARCHAR(160) NOT NULL,
    registration_window VARCHAR(90) NOT NULL,
    add_drop_deadline VARCHAR(90) NOT NULL,
    exams_window VARCHAR(90) NOT NULL,
    target_capacity INT NOT NULL DEFAULT 650,
    term_status VARCHAR(30) NOT NULL DEFAULT 'در حال ثبت‌نام و اجرا',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS academic_attendance_gradebook (
    id INT AUTO_INCREMENT PRIMARY KEY,
    record_serial VARCHAR(45) NOT NULL UNIQUE,
    term_code VARCHAR(40) NOT NULL DEFAULT 'TERM-1405-FALL',
    learner_name VARCHAR(150) NOT NULL,
    national_id VARCHAR(20) NOT NULL DEFAULT '1079025413',
    course_title VARCHAR(185) NOT NULL,
    sessions_total INT NOT NULL DEFAULT 10,
    sessions_attended INT NOT NULL DEFAULT 9,
    attendance_pct INT NOT NULL DEFAULT 90,
    quiz_activity_score INT NOT NULL DEFAULT 88,
    practical_project_score INT NOT NULL DEFAULT 92,
    final_exam_score INT NOT NULL DEFAULT 94,
    weighted_total_score INT NOT NULL DEFAULT 92,
    academic_standing VARCHAR(60) NOT NULL DEFAULT 'قبول ممتاز — مجاز به صدور گواهی QR',
    appeal_status VARCHAR(80) NOT NULL DEFAULT 'بدون اعتراض',
    updated_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS academic_prereq_waitlist (
    id INT AUTO_INCREMENT PRIMARY KEY,
    rule_or_queue_code VARCHAR(45) NOT NULL UNIQUE,
    target_course_title VARCHAR(185) NOT NULL,
    prerequisite_course_title VARCHAR(185) NOT NULL,
    rule_type VARCHAR(40) NOT NULL DEFAULT 'پیش‌نیاز الزامی',
    waitlist_applicant_name VARCHAR(150) NOT NULL,
    applicant_priority_score INT NOT NULL DEFAULT 90,
    queue_status VARCHAR(50) NOT NULL DEFAULT 'در صف انتظار ظرفیت',
    created_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS erp_helpdesk_tickets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ticket_no VARCHAR(45) NOT NULL UNIQUE,
    requester_name VARCHAR(150) NOT NULL,
    requester_role VARCHAR(60) NOT NULL DEFAULT 'فراگیر دانش‌پذیر آدان',
    department_unit VARCHAR(90) NOT NULL,
    priority_level VARCHAR(25) NOT NULL DEFAULT 'بالا (فوری)',
    sla_hours INT NOT NULL DEFAULT 4,
    subject_line VARCHAR(200) NOT NULL,
    official_reply TEXT DEFAULT NULL,
    ticket_status VARCHAR(40) NOT NULL DEFAULT 'در انتظار پاسخ کارشناس',
    created_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS erp_admin_requests_templates (
    id INT AUTO_INCREMENT PRIMARY KEY,
    entry_code VARCHAR(45) NOT NULL UNIQUE,
    record_category VARCHAR(30) NOT NULL DEFAULT 'student_request',
    applicant_or_event VARCHAR(175) NOT NULL,
    request_type_or_channel VARCHAR(120) NOT NULL,
    body_or_template TEXT NOT NULL,
    approval_state VARCHAR(60) NOT NULL DEFAULT 'تأیید و صادرشده ✅',
    updated_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================================
-- v20.0 ENTERPRISE MICROLEARNING, SPACED REPETITION (SM-2 / LEITNER) & AI MICRO-CAPSULE STUDIO (#153 - #158)
-- =====================================================================

CREATE TABLE IF NOT EXISTS micro_learning_capsules (
    id INT AUTO_INCREMENT PRIMARY KEY,
    capsule_code VARCHAR(45) NOT NULL UNIQUE,
    title VARCHAR(190) NOT NULL,
    topic_domain VARCHAR(80) NOT NULL,
    duration_seconds INT NOT NULL DEFAULT 180,
    difficulty_tag VARCHAR(40) NOT NULL DEFAULT 'کاربردی مدیران',
    slide_1_hook TEXT NOT NULL,
    slide_2_rule TEXT NOT NULL,
    slide_3_example TEXT NOT NULL,
    quiz_question VARCHAR(240) NOT NULL,
    quiz_opt_a VARCHAR(160) NOT NULL,
    quiz_opt_b VARCHAR(160) NOT NULL,
    quiz_opt_c VARCHAR(160) NOT NULL,
    correct_opt CHAR(1) NOT NULL DEFAULT 'B',
    xp_reward INT NOT NULL DEFAULT 35,
    completions_count INT NOT NULL DEFAULT 42,
    created_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS micro_capsule_progress (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    capsule_id INT NOT NULL,
    selected_opt CHAR(1) NOT NULL,
    is_mastered TINYINT(1) NOT NULL DEFAULT 1,
    xp_earned INT NOT NULL DEFAULT 35,
    completed_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS micro_spaced_flashcards (
    id INT AUTO_INCREMENT PRIMARY KEY,
    card_code VARCHAR(45) NOT NULL UNIQUE,
    deck_category VARCHAR(90) NOT NULL,
    front_prompt TEXT NOT NULL,
    back_answer TEXT NOT NULL,
    leitner_box INT NOT NULL DEFAULT 1,
    ease_factor DECIMAL(4,2) NOT NULL DEFAULT 2.50,
    interval_days INT NOT NULL DEFAULT 1,
    next_review_label VARCHAR(60) NOT NULL DEFAULT 'موعد مرور: امروز 🔥',
    reviews_count INT NOT NULL DEFAULT 0,
    owner_user_id INT NULL DEFAULT NULL,
    source_kind VARCHAR(30) NOT NULL DEFAULT 'catalog',
    source_ref VARCHAR(190) NULL DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY idx_msf_owner (owner_user_id, leitner_box)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS micro_daily_challenges (
    id INT AUTO_INCREMENT PRIMARY KEY,
    challenge_code VARCHAR(45) NOT NULL UNIQUE,
    scenario_title VARCHAR(195) NOT NULL,
    scenario_case TEXT NOT NULL,
    option_1 VARCHAR(170) NOT NULL,
    option_2 VARCHAR(170) NOT NULL,
    option_3 VARCHAR(170) NOT NULL,
    correct_choice INT NOT NULL DEFAULT 2,
    explanation_key TEXT NOT NULL,
    bonus_xp INT NOT NULL DEFAULT 50,
    participants_today INT NOT NULL DEFAULT 68,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS micro_job_aids (
    id INT AUTO_INCREMENT PRIMARY KEY,
    aid_code VARCHAR(45) NOT NULL UNIQUE,
    aid_title VARCHAR(185) NOT NULL,
    target_desk VARCHAR(95) NOT NULL,
    format_type VARCHAR(55) NOT NULL DEFAULT 'چک‌لیست رومیزی ۱ صفحه‌ای',
    key_steps_summary TEXT NOT NULL,
    audio_script_summary TEXT NOT NULL,
    downloads_count INT NOT NULL DEFAULT 115,
    created_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS micro_skill_gap_links (
    id INT AUTO_INCREMENT PRIMARY KEY,
    prescription_code VARCHAR(45) NOT NULL UNIQUE,
    detected_gap_topic VARCHAR(175) NOT NULL,
    source_module VARCHAR(85) NOT NULL DEFAULT 'آزمون استاندارد / پایپ‌لاین ATS',
    prescribed_capsule_code VARCHAR(45) NOT NULL,
    estimated_fix_minutes INT NOT NULL DEFAULT 4,
    impact_note VARCHAR(210) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================================
-- v21.0 CONTEXTUAL PER-PAGE HELP ENGINE (77 UNIQUE GUIDES) & MASTER ERP ENCYCLOPEDIA (#159 - #160)
-- =====================================================================

CREATE TABLE IF NOT EXISTS erp_help_custom_notes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    route_key VARCHAR(90) NOT NULL UNIQUE,
    local_sop_title VARCHAR(185) NOT NULL,
    local_sop_body TEXT NOT NULL,
    contact_extension VARCHAR(80) NOT NULL DEFAULT 'داخلی ۲۱۰ — واحد راهبری سیستم',
    video_guide_url VARCHAR(255) DEFAULT '',
    updated_by VARCHAR(120) DEFAULT 'مدیرکل آموزش',
    updated_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS erp_help_feedback_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    route_key VARCHAR(90) NOT NULL,
    user_fullname VARCHAR(150) NOT NULL,
    is_helpful TINYINT(1) NOT NULL DEFAULT 1,
    suggestion_note VARCHAR(240) NOT NULL DEFAULT 'راهنمای گام‌به‌گام کاملاً شفاف و کاربردی بود',
    created_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================================
-- ENTERPRISE OFFICE AUTOMATION & E-CORRESPONDENCE SUBSYSTEM (#161 - #164)
-- =====================================================================

CREATE TABLE IF NOT EXISTS oa_letters (
    id INT AUTO_INCREMENT PRIMARY KEY,
    indicator_no VARCHAR(50) NOT NULL UNIQUE,
    letter_type VARCHAR(30) NOT NULL DEFAULT 'داخلی',
    priority_level VARCHAR(30) NOT NULL DEFAULT 'عادی',
    confidentiality VARCHAR(30) NOT NULL DEFAULT 'عادی',
    sender_unit VARCHAR(140) NOT NULL,
    recipient_org VARCHAR(160) NOT NULL,
    subject_title VARCHAR(220) NOT NULL,
    letter_body TEXT NOT NULL,
    attachment_note VARCHAR(160) DEFAULT 'ندارد',
    signatory_name VARCHAR(120) NOT NULL DEFAULT 'دکتر کیارش رادمهر — مدیرکل آموزش',
    sign_status VARCHAR(60) NOT NULL DEFAULT 'امضاشده و ثبت در دبیرخانه',
    qr_verify_code VARCHAR(60) NOT NULL,
    created_shamsi VARCHAR(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    sender_user_id INT NULL,
    recipient_user_id INT NULL,
    reply_to_letter_id INT NULL,
    recipient_status VARCHAR(40) NOT NULL DEFAULT 'خوانده‌نشده',
    read_at DATETIME NULL,
    archived_at DATETIME NULL,
    external_recipient VARCHAR(160) NULL,
    INDEX idx_oa_letters_recipient_inbox (recipient_user_id, archived_at, id),
    INDEX idx_oa_letters_sender_outbox (sender_user_id, id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS oa_letter_referrals (
    id INT AUTO_INCREMENT PRIMARY KEY,
    letter_id INT NOT NULL,
    from_person VARCHAR(120) NOT NULL,
    to_person_unit VARCHAR(140) NOT NULL,
    action_command VARCHAR(90) NOT NULL DEFAULT 'جهت اقدام مقتضی',
    paraph_margin_note VARCHAR(255) NOT NULL,
    deadline_shamsi VARCHAR(40) DEFAULT '۱۴۰۵/۰۸/۰۵',
    referral_status VARCHAR(60) NOT NULL DEFAULT 'در دست اقدام',
    created_shamsi VARCHAR(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    from_user_id INT NULL,
    to_user_id INT NULL,
    INDEX idx_oa_referrals_assignee (to_user_id, referral_status),
    INDEX idx_oa_referrals_letter (letter_id, id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS oa_admin_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    req_code VARCHAR(45) NOT NULL UNIQUE,
    requester_name VARCHAR(130) NOT NULL,
    unit_name VARCHAR(120) NOT NULL,
    req_category VARCHAR(80) NOT NULL DEFAULT 'مرخصی استحقاقی / ساعتی',
    date_range_or_amount VARCHAR(120) NOT NULL,
    description_note VARCHAR(255) NOT NULL,
    approval_status VARCHAR(60) NOT NULL DEFAULT 'منتظر تأیید مدیریت',
    approver_note VARCHAR(180) DEFAULT '—',
    created_shamsi VARCHAR(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    requester_user_id INT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS oa_meeting_minutes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    minute_code VARCHAR(45) NOT NULL UNIQUE,
    meeting_title VARCHAR(200) NOT NULL,
    chairperson VARCHAR(120) NOT NULL,
    attendees_summary VARCHAR(240) NOT NULL,
    key_resolutions TEXT NOT NULL,
    responsible_owner VARCHAR(120) NOT NULL,
    due_shamsi VARCHAR(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۱۵',
    execution_status VARCHAR(60) NOT NULL DEFAULT 'ابلاغ‌شده — در حال پیگیری',
    created_shamsi VARCHAR(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================================
-- ENTERPRISE BUSINESS INTELLIGENCE, REPORT BUILDER, DASHBOARD STUDIO & OKR (#165 - #170)
-- =====================================================================

CREATE TABLE IF NOT EXISTS bi_dashboards (
    id INT AUTO_INCREMENT PRIMARY KEY,
    slug VARCHAR(70) NOT NULL UNIQUE,
    title VARCHAR(180) NOT NULL,
    subtitle VARCHAR(255) NOT NULL DEFAULT '',
    category VARCHAR(80) NOT NULL DEFAULT 'مدیریت کلان',
    accent_color VARCHAR(20) NOT NULL DEFAULT '#4f46e5',
    layout_density VARCHAR(30) NOT NULL DEFAULT 'balanced',
    created_via VARCHAR(30) NOT NULL DEFAULT 'click',
    is_default TINYINT(1) NOT NULL DEFAULT 0,
    created_by_name VARCHAR(120) NOT NULL DEFAULT 'مدیرکل آموزش',
    updated_shamsi VARCHAR(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bi_dashboard_widgets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    dashboard_id INT NOT NULL DEFAULT 1,
    widget_code VARCHAR(50) NOT NULL UNIQUE,
    title VARCHAR(180) NOT NULL,
    subtitle VARCHAR(220) NOT NULL DEFAULT '',
    dataset_key VARCHAR(60) NOT NULL DEFAULT 'courses_mart',
    dimension_field VARCHAR(60) NOT NULL DEFAULT 'level',
    metric_field VARCHAR(60) NOT NULL DEFAULT 'tuition_rial',
    agg_func VARCHAR(20) NOT NULL DEFAULT 'SUM',
    filter_field VARCHAR(60) NOT NULL DEFAULT '',
    filter_op VARCHAR(20) NOT NULL DEFAULT '=',
    filter_val VARCHAR(120) NOT NULL DEFAULT '',
    chart_type VARCHAR(30) NOT NULL DEFAULT 'bar',
    col_span INT NOT NULL DEFAULT 6,
    sort_order INT NOT NULL DEFAULT 10,
    color_palette VARCHAR(30) NOT NULL DEFAULT 'indigo',
    created_via VARCHAR(30) NOT NULL DEFAULT 'drag_drop',
    updated_shamsi VARCHAR(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bi_custom_reports (
    id INT AUTO_INCREMENT PRIMARY KEY,
    report_code VARCHAR(50) NOT NULL UNIQUE,
    title VARCHAR(200) NOT NULL,
    category VARCHAR(80) NOT NULL DEFAULT 'گزارش مدیریتی',
    dataset_key VARCHAR(60) NOT NULL DEFAULT 'courses_mart',
    dimension_field VARCHAR(60) NOT NULL DEFAULT 'level',
    metric_field VARCHAR(60) NOT NULL DEFAULT 'tuition_rial',
    secondary_metric VARCHAR(60) NOT NULL DEFAULT 'duration_hours',
    agg_func VARCHAR(20) NOT NULL DEFAULT 'SUM',
    filter_field VARCHAR(60) NOT NULL DEFAULT '',
    filter_op VARCHAR(20) NOT NULL DEFAULT '=',
    filter_val VARCHAR(120) NOT NULL DEFAULT '',
    sort_dir VARCHAR(10) NOT NULL DEFAULT 'DESC',
    row_limit INT NOT NULL DEFAULT 25,
    chart_type VARCHAR(30) NOT NULL DEFAULT 'bar',
    natural_query_text VARCHAR(255) NOT NULL DEFAULT '',
    ai_narrative TEXT,
    created_via VARCHAR(30) NOT NULL DEFAULT 'click',
    created_by_name VARCHAR(120) NOT NULL DEFAULT 'مدیرکل آموزش',
    created_shamsi VARCHAR(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bi_goals_okrs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    goal_code VARCHAR(50) NOT NULL UNIQUE,
    title VARCHAR(200) NOT NULL,
    department_owner VARCHAR(120) NOT NULL DEFAULT 'معاونت آموزش',
    horizon_label VARCHAR(70) NOT NULL DEFAULT 'نیمسال دوم ۱۴۰۵',
    live_metric_source VARCHAR(60) NOT NULL DEFAULT 'invoices_total_rial',
    baseline_value DOUBLE NOT NULL DEFAULT 0,
    manual_boost_value DOUBLE NOT NULL DEFAULT 0,
    target_value DOUBLE NOT NULL DEFAULT 100,
    unit_label VARCHAR(40) NOT NULL DEFAULT 'ریال',
    weight_pct INT NOT NULL DEFAULT 20,
    alert_threshold_pct INT NOT NULL DEFAULT 70,
    key_results_note VARCHAR(255) NOT NULL DEFAULT '',
    created_via VARCHAR(30) NOT NULL DEFAULT 'click',
    updated_shamsi VARCHAR(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bi_whatif_scenarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    scenario_code VARCHAR(50) NOT NULL UNIQUE,
    title VARCHAR(190) NOT NULL,
    tuition_delta_pct INT NOT NULL DEFAULT 10,
    enrollment_growth_pct INT NOT NULL DEFAULT 25,
    b2b_conversion_pct INT NOT NULL DEFAULT 20,
    cost_change_pct INT NOT NULL DEFAULT -5,
    projected_revenue_rial BIGINT NOT NULL DEFAULT 0,
    projected_surplus_rial BIGINT NOT NULL DEFAULT 0,
    ai_recommendation TEXT,
    created_by_name VARCHAR(120) NOT NULL DEFAULT 'مدیرکل آموزش',
    created_shamsi VARCHAR(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bi_report_schedules (
    id INT AUTO_INCREMENT PRIMARY KEY,
    schedule_code VARCHAR(50) NOT NULL UNIQUE,
    report_title VARCHAR(190) NOT NULL,
    dataset_key VARCHAR(60) NOT NULL DEFAULT 'invoices_mart',
    frequency_label VARCHAR(70) NOT NULL DEFAULT 'هفتگی — شنبه‌ها ساعت ۰۸:۰۰',
    cron_expr VARCHAR(50) NOT NULL DEFAULT '0 8 * * 6',
    delivery_channel VARCHAR(80) NOT NULL DEFAULT 'کارتابل مدیریتی + ایمیل + پیام‌رسان',
    recipients_list VARCHAR(220) NOT NULL DEFAULT 'هیئت رئیسه، مدیرکل آموزش، مدیر مالی',
    export_format VARCHAR(30) NOT NULL DEFAULT 'CSV + PDF A4',
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    last_run_shamsi VARCHAR(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================================
-- v26.0 NEXT-GEN WOW TMS, INTERACTIVE LMS, OMNI-CHANNEL SOCIAL CAMPAIGNS & AI MARKET RESEARCH (#171 - #176)
-- =====================================================================

CREATE TABLE IF NOT EXISTS tms_learning_paths (
    id INT AUTO_INCREMENT PRIMARY KEY,
    path_code VARCHAR(50) NOT NULL UNIQUE,
    title VARCHAR(190) NOT NULL,
    target_persona VARCHAR(150) NOT NULL DEFAULT 'مدیران بازرگانی و صادرات',
    level_badge VARCHAR(60) NOT NULL DEFAULT 'دیپلم جامع حرفه‌ای',
    courses_json TEXT NOT NULL,
    total_hours INT NOT NULL DEFAULT 48,
    bundle_tuition_rial BIGINT NOT NULL DEFAULT 95000000,
    discount_pct INT NOT NULL DEFAULT 22,
    enrolled_learners INT NOT NULL DEFAULT 18,
    ai_roadmap_summary TEXT,
    status VARCHAR(30) NOT NULL DEFAULT 'active',
    created_shamsi VARCHAR(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS tms_pricing_scenarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    scenario_code VARCHAR(50) NOT NULL UNIQUE,
    course_title VARCHAR(190) NOT NULL,
    base_tuition_rial BIGINT NOT NULL DEFAULT 48000000,
    member_discount_pct INT NOT NULL DEFAULT 25,
    early_bird_pct INT NOT NULL DEFAULT 10,
    instructor_total_cost_rial BIGINT NOT NULL DEFAULT 180000000,
    venue_ops_cost_rial BIGINT NOT NULL DEFAULT 65000000,
    predicted_enrollments INT NOT NULL DEFAULT 26,
    breakeven_seats INT NOT NULL DEFAULT 7,
    projected_net_profit_rial BIGINT NOT NULL DEFAULT 690000000,
    created_shamsi VARCHAR(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS lms_interactive_quizzes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    lesson_id INT NOT NULL DEFAULT 1,
    appear_at_sec INT NOT NULL DEFAULT 180,
    timestamp_label VARCHAR(20) NOT NULL DEFAULT '03:00',
    question_text VARCHAR(255) NOT NULL,
    opt_a VARCHAR(190) NOT NULL,
    opt_b VARCHAR(190) NOT NULL,
    opt_c VARCHAR(190) NOT NULL,
    opt_d VARCHAR(190) NOT NULL,
    correct_opt CHAR(1) NOT NULL DEFAULT 'B',
    ai_explanation TEXT,
    xp_reward INT NOT NULL DEFAULT 50,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS lms_ai_study_cards (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_id INT NOT NULL DEFAULT 1,
    lesson_id INT NOT NULL DEFAULT 1,
    card_type VARCHAR(50) NOT NULL DEFAULT 'summary',
    title VARCHAR(190) NOT NULL,
    content_body TEXT NOT NULL,
    mastery_tag VARCHAR(80) NOT NULL DEFAULT 'تسلط مفهومی و کاربردی',
    created_by_name VARCHAR(120) NOT NULL DEFAULT 'دستیار هوشمند LMS',
    created_shamsi VARCHAR(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS social_media_posts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    post_code VARCHAR(50) NOT NULL UNIQUE,
    campaign_id INT DEFAULT 1,
    platform VARCHAR(40) NOT NULL DEFAULT 'instagram',
    content_format VARCHAR(60) NOT NULL DEFAULT 'پست اسلایدی (Carousel)',
    target_course_title VARCHAR(190) NOT NULL,
    hook_headline VARCHAR(220) NOT NULL,
    caption_body TEXT NOT NULL,
    hashtags VARCHAR(255) NOT NULL DEFAULT '#آموزش_حسابداری_آدان #آموزش_صادرات #تجارت_بین_الملل',
    utm_url VARCHAR(255) NOT NULL DEFAULT 'https://chamber.ir/tms?utm_source=instagram&utm_medium=social',
    promo_code VARCHAR(40) NOT NULL DEFAULT 'ADN-INSTA20',
    scheduled_shamsi VARCHAR(60) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۶ — ساعت ۱۹:۳۰',
    impressions_count INT NOT NULL DEFAULT 0,
    engagements_count INT NOT NULL DEFAULT 0,
    clicks_count INT NOT NULL DEFAULT 0,
    leads_generated INT NOT NULL DEFAULT 0,
    enrollments_converted INT NOT NULL DEFAULT 0,
    spend_rial BIGINT NOT NULL DEFAULT 0,
    revenue_rial BIGINT NOT NULL DEFAULT 0,
    publish_status VARCHAR(30) NOT NULL DEFAULT 'scheduled_local',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS market_surveys_insights (
    id INT AUTO_INCREMENT PRIMARY KEY,
    insight_code VARCHAR(50) NOT NULL UNIQUE,
    research_title VARCHAR(190) NOT NULL,
    industry_segment VARCHAR(120) NOT NULL DEFAULT 'صنایع غذایی، فولاد و بازرگانی خارجی',
    social_source VARCHAR(90) NOT NULL DEFAULT 'لینکدین + تلگرام + نظرسنجی بنگاه‌ها',
    sample_size_orgs INT NOT NULL DEFAULT 84,
    demand_urgency_pct INT NOT NULL DEFAULT 91,
    positive_sentiment_pct INT NOT NULL DEFAULT 84,
    willingness_to_pay_rial BIGINT NOT NULL DEFAULT 52000000,
    tam_provincial_rial BIGINT NOT NULL DEFAULT 48000000000,
    sam_reachable_rial BIGINT NOT NULL DEFAULT 14500000000,
    som_target_rial BIGINT NOT NULL DEFAULT 4200000000,
    key_pain_point TEXT NOT NULL,
    ai_gtm_strategy TEXT NOT NULL,
    launched_to_tms TINYINT(1) NOT NULL DEFAULT 0,
    created_shamsi VARCHAR(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

-- =====================================================================
-- ★ v26.8 — استودیوی گزارش‌ساز صوتی هوشمند (بایگانی گزارش‌های سخنگو)
-- =====================================================================
CREATE TABLE IF NOT EXISTS voice_report_archive (
    id INT AUTO_INCREMENT PRIMARY KEY,
    report_code VARCHAR(45) NOT NULL UNIQUE,
    report_kind VARCHAR(60) NOT NULL,
    audience_role VARCHAR(30) NOT NULL DEFAULT 'super_admin',
    user_id INT NOT NULL,
    user_name VARCHAR(150) NOT NULL DEFAULT 'سامانه',
    report_title VARCHAR(240) NOT NULL,
    narrative_text MEDIUMTEXT NOT NULL,
    speech_text MEDIUMTEXT NOT NULL,
    metrics_json TEXT NULL,
    speech_chars INT NOT NULL DEFAULT 0,
    est_duration_sec INT NOT NULL DEFAULT 60,
    delivery_mode VARCHAR(30) NOT NULL DEFAULT 'browser_tts',
    visibility_scope VARCHAR(30) NOT NULL DEFAULT 'own_role',
    created_shamsi VARCHAR(40) NOT NULL DEFAULT '۱۴۰۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY idx_vra_role (audience_role, id),
    KEY idx_vra_user (user_id, id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================================
-- ★ v26.8 — تله‌متری قابلیت‌های هوشمند فضای یادگیری فراگیر (نرخ پذیرش برای مدیران)
-- =====================================================================
CREATE TABLE IF NOT EXISTS learner_ai_telemetry (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    feature_key VARCHAR(60) NOT NULL,
    ref_label VARCHAR(240) NOT NULL DEFAULT '',
    score_value INT NOT NULL DEFAULT 0,
    detail_json TEXT NULL,
    created_shamsi VARCHAR(40) NOT NULL DEFAULT '۱۴۵/۰۸/۰۱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY idx_lat_user (user_id, id),
    KEY idx_lat_feature (feature_key, id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO voice_report_archive
    (report_code, report_kind, audience_role, user_id, user_name, report_title, narrative_text, speech_text, metrics_json, speech_chars, est_duration_sec, delivery_mode, visibility_scope, created_shamsi)
VALUES
    ('VRA-SEED-01', 'daily_digest', 'super_admin', 1, 'دبیرخانه هوشمند',
     'گزارش نمونه بایگانی‌شده استودیوی گزارش صوتی',
     'این یک گزارش نمونه است تا ساختار بایگانی استودیوی گزارش صوتی در نصب تازه خالی نباشد؛ با نخستین تولید گزارش، گزارش‌های واقعی جای آن را می‌گیرند.',
     'گزارش نمونه استودیوی گزارش صوتی مؤسسه آموزشی آدان. سامانه آماده تولید گزارش‌های زنده است.',
     '{"نمونه":"فعال"}', 92, 22, 'browser_tts', 'own_role', '۱۴۰۵/۰۸/۰۱');
