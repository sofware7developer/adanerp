<?php
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

/**
 * پردازشگر کارهای زمان‌بندی‌شده (Cron Job) ویژه cPanel و سرور لینوکس/ویندوز
 * نمونه تنظیم در cPanel Cron Jobs:
 * 0 * * * * /usr/local/bin/php /home/cpaneluser/public_html/cron.php
 */
require_once __DIR__ . '/app/Core/Autoloader.php';
\App\Core\Autoloader::register(__DIR__);
require_once __DIR__ . '/app/Core/helpers.php';

use App\Core\App;
use App\Core\Database;
use App\Services\CronService;

try {
    App::boot(__DIR__);
    Database::healMissingColumns();
    $missingColumns = Database::missingColumns();
    if (in_array('last_run_at', $missingColumns['webhooks_and_jobs'] ?? [], true)) {
        throw new \RuntimeException('ستون ثبت زمان اجرای Cron در پایگاه‌داده موجود نیست و قابل ایجاد نشد.');
    }

    $result = CronService::run();
    echo sprintf(
        "[Adan Cron] Completed: %d | Failed: %d | Workflow timers refreshed: %d | %s\n",
        $result['completed'],
        $result['failed'],
        $result['workflow_rows_updated'],
        date('Y-m-d H:i:s')
    );
    if ($result['failed'] > 0) {
        exit(1);
    }
} catch (Throwable $e) {
    fwrite(STDERR, '[Adan Cron] ' . $e->getMessage() . PHP_EOL);
    exit(1);
}
