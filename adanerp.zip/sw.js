/**
 * Service Worker پوسته — نسخه ۲۶٫۹ (نگاشت cache فقط برای دارایی‌های ایستا)
 *
 * دو قاعده حیاتی که در این نسخه اصلاح شد:
 *  ۱) هرگز پاسخ «تعریف‌نشده» به مرورگر برگردانده نمی‌شود؛ respondWith فقط با یک Response واقعی
 *     صدا می‌زند (خطای `Failed to convert value to 'Response'` از همین‌جا ناشی می‌شد).
 *  ۲) مسیرهای پویا/ناوبری/JSON (index.php، ?r=، /api، POST) اصلاً بین‌وجه نمی‌شوند تا جریان
 *     تولید گزارش صوتی، ریدایرکت پس از فرم و لود صفحه هرگز به دست cache ننشیند.
 */
const SHELL_CACHE = 'chamber-edu-shell-v27';
const ASSET_HINTS = /\.(css|js|woff2?|ttf|otf|eot|svg|png|jpe?g|gif|webp|avif|ico|mp3|wav|ogg|m4a|webmanifest)(\?|#|$)/i;
const BYPASS_HINTS = /(index\.php|\?r=|&r=|\/api\/|logout|login|action=|play=|\?src=)/i;

self.addEventListener('install', () => {
    self.skipWaiting();
});

self.addEventListener('activate', (event) => {
    event.waitUntil(
        caches.keys()
            .then((keys) => Promise.all(keys.filter((k) => k !== SHELL_CACHE).map((k) => caches.delete(k))))
            .then(() => self.clients.claim())
    );
});

self.addEventListener('fetch', (event) => {
    const req = event.request;

    // فقط GET هم‌ریشه؛ بقیه (ناوبری، فرم‌ها، API، crossorigin) مستقیماً به شبکه می‌روند
    if (req.method !== 'GET') return;
    let url;
    try {
        url = new URL(req.url);
    } catch (e) {
        return;
    }
    if (url.origin !== self.location.origin) return;
    if (req.mode === 'navigate' || req.mode === 'websocket') return;
    if (BYPASS_HINTS.test(url.pathname + url.search)) return;
    if (!ASSET_HINTS.test(url.pathname + url.search)) return;

    event.respondWith(
        fetch(req)
            .then((res) => {
                if (res && res.ok && (res.type === 'basic' || res.type === 'default')) {
                    const copy = res.clone();
                    caches.open(SHELL_CACHE).then((c) => c.put(req, copy)).catch(() => {});
                }
                return res;
            })
            .catch(() => caches.match(req, { ignoreSearch: false })
                .then((hit) => hit || new Response('', { status: 504, statusText: 'Offline Shell' })))
    );
});
