# راهنمای جامع استقرار مستقیم با Import دیتابیس (بدون صفحه نصب) در XAMPP و cPanel
## آموزشگاه حسابداری آدان — راهنمای استقرار در XAMPP و cPanel

---

## ۱. مکانیسم راه‌اندازی مستقیم بدون صفحه نصب (Direct SQL Import Architecture)

در این نسخه، **هیچ صفحه نصاب وب (`install.php`) وجود ندارد** (حذف کامل مخاطرات امنیتی نصاب وب در محیط بهره‌برداری) و راه‌اندازی سامانه صرفاً با **Import مستقیم فایل پایگاه‌داده در `phpMyAdmin`** و تنظیم ۴ خط اتصال در فایل `config/config.php` انجام می‌شود:

```
adanerp/
├── index.php                                  # هسته ورودی MVC، بررسی مستقیم دیتابیس و میدل‌ویر RBAC
├── .htaccess                                  # بازنویسی آدرس‌ها و حفاظت پوشه‌های حساس در Apache (XAMPP/cPanel)
├── cron.php                                   # پردازشگر کارهای زمان‌بندی‌شده گزارش‌ساز BI و SLA
├── config/
│   ├── config.php                             # تنظیمات مستقیم MariaDB (از پیش تنظیم‌شده برای XAMPP) + AvalAI
│   └── phases.php                             # رجیستری مرکزی ۱۰ فاز و ۵۲ ماژول تخصصی
├── database/
│   ├── xampp_oneclick_import.sql              # ایمپورت یک‌کلیکی مخصوص XAMPP (ساخت خودکار دیتابیس adanerpdb + ۱۷۸ جدول)
│   ├── full_chamber_edu_xampp_cpanel.sql      # دامپ استاندارد ۱۷۸ جدول و داده‌های فارسی (سازگار با cPanel و XAMPP)
│   ├── schema.sql                             # ساختار پایه جداول MariaDB
│   └── seed.sql                               # داده‌های نمونه آموزشگاه حسابداری آدان
├── app/
│   ├── Core/                                  # Autoloader, App, Database (PDO Auto-Host Fallback), Router, Auth/RBAC
│   ├── Services/                              # سرویس‌های AvalAI، هوش ERP، میکرولرنینگ SM-2، تم/فونت و هلپ ۷۷ صفحه
│   ├── Controllers/                           # کنترلرهای تفکیک‌شده ۵۲ ماژول + REST API v1
│   └── Views/                                 # نماهای ریسپانسیو RTL + پنجره راهنمای اختصاصی F1 در تک‌تک صفحات
└── assets/                                    # استایل‌های CSS و تعاملات Vanilla JS بدون وابستگی خارجی
```

---

## ۲. راه‌اندازی ۲ دقیقه‌ای در XAMPP (بدون نیاز به ویرایش هیچ فایلی!)

مقادیر پیش‌فرض فایل `config/config.php` از پیش دقیقاً روی تنظیمات استاندارد **XAMPP** (`host: localhost`، `database: adanerpdb`، `username: root`، `password: ''`) قرار داده شده است:

1. پوشه پروژه را در مسیر `C:\xampp\htdocs\adanerp` قرار دهید.
2. در کنترل‌پنل XAMPP، سرویس‌های **Apache** و **MySQL** را `Start` کنید.
3. وارد `http://localhost/phpmyadmin` شوید، مستقیماً از نوار بالا روی تب **`Import`** کلیک کنید، فایل زیر را انتخاب کرده و دکمه **`Import` / `Go`** را بزنید:
   - **`database/xampp_oneclick_import.sql`** *(این فایل به صورت خودکار دیتابیس `adanerpdb` و تمام `178` جدول و داده‌های نمونه فارسی را یک‌جا می‌سازد!)*
   - *(روش معادل: یا ابتدا دیتابیس `adanerpdb` را بسازید، وارد آن شوید و فایل `database/full_chamber_edu_xampp_cpanel.sql` را Import کنید.)*
4. بلافاصله آدرس زیر را در مرورگر باز کنید — سامانه بدون هیچ مرحله نصبی آماده استفاده است:
   - **`http://localhost/adanerp/`**

---

## ۳. استقرار استاندارد در هاست اشتراکی یا اختصاصی سی‌پنل (cPanel)

در هاست‌های اشتراکی `cPanel`، ساخت دیتابیس باید از پنل `MySQL® Databases` انجام شود؛ بنابراین از فایل **`database/full_chamber_edu_xampp_cpanel.sql`** استفاده نمایید:

1. وارد **cPanel -> MySQL® Database Wizard** شوید:
   - یک دیتابیس بسازید (مثلاً `cpuser_adanerpdb`).
   - یک کاربر دیتابیس با رمز عبور قوی بسازید (مثلاً `cpuser_admin`) و تیک **`ALL PRIVILEGES`** را فعال کنید.
2. وارد **cPanel -> phpMyAdmin** شوید، در ستون سمت چپ روی دیتابیس ساخته‌شده (`cpuser_adanerpdb`) کلیک کنید، تب **`Import`** را بزنید و فایل **`database/full_chamber_edu_xampp_cpanel.sql`** را آپلود و اجرا نمایید.
3. محتویات پوشه `adanerp` را در `public_html` (یا پوشه ساب‌دامین `edu.yourdomain.ir`) قرار دهید و فقط بخش `db` در فایل **`config/config.php`** را مطابق مشخصات هاست خود ویرایش نمایید:
   ```php
   'db' => [
       'host' => 'localhost',
       'port' => 3306,
       'database' => 'cpuser_adanerpdb',
       'username' => 'cpuser_admin',
       'password' => 'رمز_عبور_دیتابیس_شما',
       'charset' => 'utf8mb4',
   ],
   ```
4. سامانه بلافاصله روی دامنه شما فعال است. برای اتصال هوش مصنوعی نیز از منوی **«۲۴. مدیریت AI، RAG و وب‌هوک»** یا کلید `'avalai_api_key'` در `config/config.php` کلید `AvalAI` را وارد نمایید.

---

## ۴. اطلاعات ورود پیش‌فرض (پس از Import دیتابیس)

- **نام کاربری مدیر آموزش:** `admin` *(ورود با نام کاربری و گذرواژه انجام می‌شود؛ ایمیل پذیرفته نیست.)*
- **گذرواژه پیش‌فرض حساب مدیر و حساب‌های نمونه:** **`Chamber@1405`**
