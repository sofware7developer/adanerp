(function () {
    'use strict';

    function safeLocalGet(k) {
        try { return window.localStorage ? window.localStorage.getItem(k) : null; } catch (e) { return null; }
    }
    function safeLocalSet(k, v) {
        try { if (window.localStorage) window.localStorage.setItem(k, v); } catch (e) {}
    }

    // ۱. مدیریت هوشمند پوسته روشن / تیره همگام با پایگاه‌داده + پیش‌نمایش و ذخیره آنی تم و فونت
    const serverTheme = document.documentElement.getAttribute('data-server-theme') || 'light';
    const serverRev = document.documentElement.getAttribute('data-theme-rev') || '';
    const lastSeenRev = safeLocalGet('chamber_theme_rev') || '';
    let activeThemeMode = serverTheme;
    if (serverRev && lastSeenRev === serverRev && safeLocalGet('chamber_theme')) {
        activeThemeMode = safeLocalGet('chamber_theme');
    } else {
        safeLocalSet('chamber_theme', serverTheme);
        if (serverRev) safeLocalSet('chamber_theme_rev', serverRev);
    }
    document.documentElement.setAttribute('data-theme', activeThemeMode);

    const FONT_MAP = {
        'Vazirmatn': "'Vazirmatn', Tahoma, 'Segoe UI', sans-serif",
        'Shabnam_Modern': "'Shabnam', 'Vazirmatn', Tahoma, sans-serif",
        'Sahel_Modern': "'Sahel', 'Vazirmatn', Tahoma, sans-serif",
        'Samim_Editorial': "'Samim', 'Vazirmatn', Georgia, Tahoma, sans-serif",
        'Tahoma_Formal': "Tahoma, 'Vazirmatn', Arial, sans-serif",
        'System_Clean': "system-ui, -apple-system, 'Vazirmatn', 'Segoe UI', Tahoma, sans-serif"
    };

    window.applyInstantAppearance = function (payload) {
        if (!payload || typeof payload !== 'object') return;
        const root = document.documentElement;
        if (payload.primary_hex) {
            root.style.setProperty('--primary', payload.primary_hex);
            root.style.setProperty('--primary-hover', payload.primary_hex);
            root.style.setProperty('--primary-soft', 'color-mix(in srgb, ' + payload.primary_hex + ' 11%, transparent)');
        }
        if (payload.gold_accent_hex) {
            root.style.setProperty('--gold', payload.gold_accent_hex);
            root.style.setProperty('--gold-soft', 'color-mix(in srgb, ' + payload.gold_accent_hex + ' 13%, transparent)');
        }
        if (payload.sidebar_bg_hex) {
            root.style.setProperty('--navy-900', payload.sidebar_bg_hex);
            root.style.setProperty('--navy-950', payload.sidebar_bg_hex);
        }
        if (payload.font_family_key && FONT_MAP[payload.font_family_key]) {
            root.style.setProperty('--erp-font-stack', FONT_MAP[payload.font_family_key]);
        }
        if (payload.base_font_px) {
            root.style.fontSize = payload.base_font_px + 'px';
            document.body.style.fontSize = payload.base_font_px + 'px';
        }
        if (payload.color_mode) {
            root.setAttribute('data-theme', payload.color_mode);
            try { localStorage.setItem('chamber_theme', payload.color_mode); } catch (e) {}
        }

        const baseUrl = (document.body && document.body.getAttribute('data-base-url')) || '';
        fetch((baseUrl + '/index.php?r=api/v1/quick-theme').replace(/\/+/g, '/'), {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        }).then(function (r) { return r.json(); }).then(function (res) {
            if (res && res.rev) {
                try { localStorage.setItem('chamber_theme_rev', res.rev); } catch (e) {}
            }
        }).catch(function () {});
    };

    document.addEventListener('DOMContentLoaded', function () {
        const themeBtn = document.getElementById('themeToggleBtn');
        if (themeBtn) {
            themeBtn.addEventListener('click', function () {
                const cur = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
                window.applyInstantAppearance({ color_mode: cur });
            });
        }

        const quickTrigger = document.getElementById('quickThemeTriggerBtn');
        const quickPopover = document.getElementById('quickThemePopover');
        if (quickTrigger && quickPopover) {
            quickTrigger.addEventListener('click', function (ev) {
                ev.stopPropagation();
                quickPopover.classList.toggle('open');
            });
            quickPopover.addEventListener('click', function (ev) {
                ev.stopPropagation();
            });
            document.addEventListener('click', function () {
                quickPopover.classList.remove('open');
            });
        }

        // ۲. باز و بسته کردن نرم منوی کناری در دسکتاپ و موبایل
        const sidebar = document.getElementById('appSidebar');
        const mobileBtn = document.getElementById('mobileMenuBtn');
        if (mobileBtn && sidebar) {
            mobileBtn.addEventListener('click', function () {
                if (window.innerWidth <= 960) {
                    sidebar.classList.toggle('open');
                } else {
                    document.body.classList.toggle('sidebar-collapsed');
                }
            });
        }

        // ۳. منوی آکاردئونی تک‌باز (بسته شدن خودکار سایر منوها + حفظ و اسکرول نرم موقعیت سایدبار در پایین صفحه)
        const navGroups = document.querySelectorAll('.nav-group[data-group-id]');
        let activeGroupFound = false;

        navGroups.forEach(function (grp) {
            const hasActiveItem = !!grp.querySelector('.nav-item.active');
            if (hasActiveItem && !activeGroupFound) {
                grp.classList.add('open', 'has-active');
                activeGroupFound = true;
            } else {
                grp.classList.remove('open');
            }
            const btn = grp.querySelector('.nav-group-btn');
            if (btn) {
                btn.setAttribute('aria-expanded', grp.classList.contains('open') ? 'true' : 'false');
                btn.addEventListener('click', function () {
                    const willOpen = !grp.classList.contains('open');
                    // بستن خودکار سایر منوهای باز در سایدبار (Accordion واقعی)
                    navGroups.forEach(function (other) {
                        if (other !== grp) {
                            other.classList.remove('open');
                            const ob = other.querySelector('.nav-group-btn');
                            if (ob) ob.setAttribute('aria-expanded', 'false');
                        }
                    });
                    grp.classList.toggle('open', willOpen);
                    btn.setAttribute('aria-expanded', willOpen ? 'true' : 'false');

                    // اسکرول خودکار و نرم سایدبار هنگام باز کردن منوهای پایینی تا زیرمنوها کاملاً در دید قرار گیرند
                    if (willOpen && sidebar) {
                        setTimeout(function () {
                            const sbRect = sidebar.getBoundingClientRect();
                            const gRect = grp.getBoundingClientRect();
                            if (gRect.bottom > sbRect.bottom - 16) {
                                const delta = Math.min(gRect.top - sbRect.top - 72, gRect.bottom - sbRect.bottom + 24);
                                if (delta > 0) {
                                    sidebar.scrollBy({ top: delta, behavior: 'smooth' });
                                }
                            } else if (gRect.top < sbRect.top + 60) {
                                grp.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                            }
                            try { sessionStorage.setItem('chamber_sidebar_scroll', String(sidebar.scrollTop)); } catch (e) {}
                        }, 245);
                    }
                });
            }
        });

        if (sidebar) {
            sidebar.addEventListener('scroll', function () {
                try { sessionStorage.setItem('chamber_sidebar_scroll', String(sidebar.scrollTop)); } catch (e) {}
            }, { passive: true });

            sidebar.querySelectorAll('a.nav-item').forEach(function (link) {
                link.addEventListener('click', function () {
                    try { sessionStorage.setItem('chamber_sidebar_scroll', String(sidebar.scrollTop)); } catch (e) {}
                });
            });

            const activeNavEl = sidebar.querySelector('.nav-item.active');
            if (activeNavEl) {
                setTimeout(function () {
                    const sbRect = sidebar.getBoundingClientRect();
                    const aRect = activeNavEl.getBoundingClientRect();
                    if (aRect.bottom > sbRect.bottom - 20 || aRect.top < sbRect.top + 70) {
                        activeNavEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    }
                }, 60);
            }
        }

        const filterInput = document.getElementById('sidebarModuleFilter');
        if (filterInput) {
            filterInput.addEventListener('input', function () {
                const q = this.value.trim().toLowerCase();
                navGroups.forEach(function (grp) {
                    let visibleCount = 0;
                    grp.querySelectorAll('.nav-item[data-title]').forEach(function (el) {
                        const text = ((el.getAttribute('data-title') || '') + ' ' + el.textContent).toLowerCase();
                        const match = !q || text.indexOf(q) !== -1;
                        el.style.display = match ? 'flex' : 'none';
                        if (match) visibleCount++;
                    });
                    if (q) {
                        grp.style.display = visibleCount > 0 ? 'block' : 'none';
                        if (visibleCount > 0) grp.classList.add('open');
                    } else {
                        grp.style.display = 'block';
                        grp.classList.toggle('open', !!grp.querySelector('.nav-item.active'));
                    }
                });
            });
        }

        // ۴. تب‌های تعاملی در هر ماژول
        document.querySelectorAll('.tab-btn[data-tab]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                const group = btn.closest('[data-tab-group]') || document;
                const target = btn.getAttribute('data-tab');
                group.querySelectorAll('.tab-btn[data-tab]').forEach(function (b) {
                    b.classList.toggle('active', b === btn);
                });
                group.querySelectorAll('.tab-panel[id]').forEach(function (panel) {
                    panel.classList.toggle('active', panel.id === target);
                });
            });
        });

        // ۵. باز و بسته کردن مودال‌ها (جست‌وجوی Ctrl+K، همراه هوشمند AI و فرم‌ها)
        document.querySelectorAll('[data-open-modal]').forEach(function (trigger) {
            trigger.addEventListener('click', function () {
                const modal = document.getElementById(trigger.getAttribute('data-open-modal'));
                if (modal) {
                    modal.classList.add('open');
                    const input = modal.querySelector('input, textarea');
                    if (input) setTimeout(function () { input.focus(); }, 60);
                }
            });
        });

        document.querySelectorAll('[data-close-modal]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                const modal = btn.closest('.modal-backdrop');
                if (modal) modal.classList.remove('open');
            });
        });

        document.querySelectorAll('.modal-backdrop').forEach(function (bd) {
            bd.addEventListener('click', function (ev) {
                if (ev.target === bd) bd.classList.remove('open');
            });
        });

        document.addEventListener('keydown', function (ev) {
            if ((ev.ctrlKey || ev.metaKey) && ev.key.toLowerCase() === 'k') {
                ev.preventDefault();
                const searchModal = document.getElementById('globalSearchModal');
                if (searchModal) {
                    searchModal.classList.add('open');
                    const inp = document.getElementById('globalSearchInput');
                    if (inp) inp.focus();
                }
            } else if (ev.key === 'Escape') {
                document.querySelectorAll('.modal-backdrop.open').forEach(function (m) {
                    m.classList.remove('open');
                });
            }
        });

        // ۶. جست‌وجوی نقش‌محور سراسری AJAX
        const gInput = document.getElementById('globalSearchInput');
        const gResults = document.getElementById('globalSearchResults');
        let searchTimer = null;
        if (gInput && gResults) {
            gInput.addEventListener('input', function () {
                clearTimeout(searchTimer);
                const q = gInput.value.trim();
                if (q.length < 2) {
                    gResults.innerHTML = '<p class="muted">حداقل ۲ حرف وارد کنید (نام دوره، شرکت عضو، کد گواهی، کتابخانه یا شماره ماژول)...</p>';
                    return;
                }
                searchTimer = setTimeout(function () {
                    const apiBase = document.body.getAttribute('data-base-url') || '';
                    fetch((apiBase + '/index.php?r=api/v1/search&q=' + encodeURIComponent(q)).replace(/\/+/g, '/'), { credentials: 'same-origin' })
                        .then(function (r) { return r.json(); })
                        .then(function (data) {
                            if (!data.items || !data.items.length) {
                                gResults.innerHTML = '<div class="alert alert-warning">موردی مطابق سطح دسترسی نقش شما یافت نشد.</div>';
                                return;
                            }
                            gResults.innerHTML = data.items.map(function (it) {
                                return '<a class="stat-card" style="margin-bottom:8px;padding:12px 15px" href="' + it.url + '">'
                                    + '<div><div style="font-weight:800">' + it.title + '</div>'
                                    + '<div class="muted" style="font-size:12px">' + it.subtitle + '</div></div>'
                                    + '<span class="badge badge-info">' + it.type + '</span></a>';
                            }).join('');
                        })
                        .catch(function () {
                            gResults.innerHTML = '<div class="alert alert-warning">از نوار جست‌وجوی منوی سمت راست نیز می‌توانید مستقیماً ماژول مورد نظر را فیلتر کنید.</div>';
                        });
                }, 220);
            });
        }

        // ۷. همراه هوشمند AI (Copilot) در تمام صفحات (متصل به موتور یکپارچه بدون خطا)
        const copilotForm = document.getElementById('copilotQuickForm');
        const copilotOut = document.getElementById('copilotQuickOutput');
        if (copilotForm && copilotOut) {
            copilotForm.addEventListener('submit', function (ev) {
                ev.preventDefault();
                const promptEl = copilotForm.querySelector('textarea[name="prompt"]');
                const q = promptEl ? promptEl.value.trim() : '';
                if (typeof window.runChamberAiQuery === 'function') {
                    window.runChamberAiQuery(q, 'copilotQuickOutput', null);
                    return;
                }
                const fd = new FormData(copilotForm);
                copilotOut.style.display = 'block';
                copilotOut.textContent = 'در حال تحلیل داده‌های زنده پایگاه‌داده و مخزن دانش مؤسسه آموزشی آدان...';
                const apiBase = document.body.getAttribute('data-base-url') || '';
                fetch((apiBase + '/index.php?r=api/v1/copilot').replace(/\/+/g, '/'), { method: 'POST', body: fd, credentials: 'same-origin' })
                    .then(function (r) { return r.json(); })
                    .then(function (res) {
                        copilotOut.textContent = (res.content || res.message || '');
                    })
                    .catch(function () {
                        copilotOut.textContent = typeof window.synthesizeClientDomAi === 'function'
                            ? window.synthesizeClientDomAi(q)
                            : 'پاسخ تحلیلی دستیار هوشمند آماده بهره‌برداری است.';
                    });
            });
        }

        // ۸. تایمر زنده آزمون آنلاین 
        const timerEl = document.getElementById('liveExamTimer');
        if (timerEl) {
            let seconds = parseInt(timerEl.getAttribute('data-seconds') || '1200', 10);
            setInterval(function () {
                if (seconds > 0) seconds--;
                const m = String(Math.floor(seconds / 60)).padStart(2, '0');
                const s = String(seconds % 60).padStart(2, '0');
                timerEl.textContent = m + ':' + s;
                if (seconds === 0) {
                    const examForm = document.getElementById('activeExamForm');
                    if (examForm) examForm.submit();
                }
            }, 1000);
        }

        // ۹. شبیه‌ساز تصمیم‌گیری وزن‌دار توسعه رهبری 
        const simSliders = document.querySelectorAll('.leadership-sim-input');
        const simTotalEl = document.getElementById('leadershipWeightedScore');
        if (simSliders.length && simTotalEl) {
            const recalc = function () {
                let weighted = 0;
                simSliders.forEach(function (inp) {
                    const w = parseFloat(inp.getAttribute('data-weight') || '25');
                    const v = parseFloat(inp.value || '0');
                    weighted += (w * v) / 100;
                    const outSpan = document.getElementById(inp.id + '_val');
                    if (outSpan) outSpan.textContent = inp.value;
                });
                simTotalEl.textContent = weighted.toFixed(1) + ' از ۱۰۰';
            };
            simSliders.forEach(function (inp) { inp.addEventListener('input', recalc); });
            recalc();
        }

        // ۱۰. ارتقادهنده سراسری جداول عملیاتی (جست‌وجو، مرتب‌سازی ستونی، صفحه‌بندی و خروجی Excel در هر بخش‌های سامانه) + اعتبارسنج کد ملی/شبا
        window.chamberEnhanceUI = function (scope) {
            const root = scope || document;
            root.querySelectorAll('.table-wrap table').forEach(function (tbl) {
                if (tbl.dataset.dtEnhanced) return;
                const tbody = tbl.querySelector('tbody');
                const thead = tbl.querySelector('thead');
                if (!tbody || !thead) return;
                const allRows = Array.from(tbody.querySelectorAll('tr'));
                if (allRows.length < 2) return;
                tbl.dataset.dtEnhanced = '1';

                const bar = document.createElement('div');
                bar.className = 'dt-toolbar';
                bar.innerHTML = '<input type="search" class="dt-search-input" placeholder="🔍 فیلتر سریع رکوردهای این جدول...">'
                    + '<div class="dt-tools-left">'
                    + '<select class="dt-page-size" style="width:auto;padding:4px 8px;font-size:11.5px"><option value="10">۱۰ ردیف</option><option value="25">۲۵ ردیف</option><option value="9999">همه (' + allRows.length + ')</option></select>'
                    + '<button type="button" class="btn btn-outline btn-sm dt-csv-btn" style="padding:4px 9px;font-size:11.5px">📥 اکسل CSV</button>'
                    + '</div>';
                tbl.parentNode.insertBefore(bar, tbl);

                const sInp = bar.querySelector('.dt-search-input');
                const pSel = bar.querySelector('.dt-page-size');
                const cBtn = bar.querySelector('.dt-csv-btn');

                const refreshTable = function () {
                    const q = (sInp.value || '').trim().toLowerCase();
                    const limit = parseInt(pSel.value || '10', 10);
                    let shown = 0;
                    Array.from(tbody.querySelectorAll('tr')).forEach(function (tr) {
                        const match = !q || tr.textContent.toLowerCase().indexOf(q) !== -1;
                        if (match && shown < limit) {
                            tr.style.display = '';
                            shown++;
                        } else {
                            tr.style.display = 'none';
                        }
                    });
                };

                sInp.addEventListener('input', refreshTable);
                pSel.addEventListener('change', refreshTable);

                thead.querySelectorAll('th').forEach(function (th, colIdx) {
                    th.classList.add('dt-sortable');
                    th.title = 'کلیک جهت مرتب‌سازی صعودی/نزولی';
                    let asc = true;
                    th.addEventListener('click', function () {
                        const rowsNow = Array.from(tbody.querySelectorAll('tr'));
                        rowsNow.sort(function (a, b) {
                            const ta = (a.children[colIdx] ? a.children[colIdx].textContent : '').trim();
                            const tb = (b.children[colIdx] ? b.children[colIdx].textContent : '').trim();
                            return asc ? ta.localeCompare(tb, 'fa') : tb.localeCompare(ta, 'fa');
                        });
                        asc = !asc;
                        rowsNow.forEach(function (r) { tbody.appendChild(r); });
                        refreshTable();
                    });
                });

                cBtn.addEventListener('click', function () {
                    const csvRows = [];
                    tbl.querySelectorAll('tr').forEach(function (tr) {
                        if (tr.style.display === 'none') return;
                        const cols = Array.from(tr.querySelectorAll('th,td')).map(function (c) {
                            return '"' + c.textContent.trim().replace(/\s+/g, ' ').replace(/"/g, '""') + '"';
                        });
                        csvRows.push(cols.join(','));
                    });
                    const blob = new Blob(['\uFEFF' + csvRows.join('\n')], { type: 'text/csv;charset=utf-8;' });
                    const a = document.createElement('a');
                    a.href = URL.createObjectURL(blob);
                    a.download = 'chamber-table-export.csv';
                    a.click();
                });

                refreshTable();
            });

            root.querySelectorAll('input[name*="national"], input[name*="sayad"]').forEach(function (inp) {
                if (inp.dataset.irBound) return;
                inp.dataset.irBound = '1';
                const hint = document.createElement('div');
                hint.style.fontSize = '11px';
                hint.style.marginTop = '3px';
                inp.parentNode.appendChild(hint);
                inp.addEventListener('input', function () {
                    const d = inp.value.replace(/[۰-۹]/g, function (w) { return '۰۱۲۳۴۵۶۷۸۹'.indexOf(w); }).replace(/\D+/g, '');
                    if (d.length === 10) {
                        let s = 0; for (let i = 0; i < 9; i++) s += parseInt(d[i], 10) * (10 - i);
                        const r = s % 11, c = parseInt(d[9], 10);
                        const ok = (r < 2 && c === r) || (r >= 2 && c === 11 - r);
                        hint.textContent = ok ? '✓ رقم کنترل کد ملی ۱۰ رقمی معتبر است' : '⚠️ رقم کنترل کد ملی استاندارد نیست';
                        hint.style.color = ok ? '#059669' : '#d97706';
                    } else if (d.length === 16) {
                        hint.textContent = '✓ قالب ۱۶ رقمی شناسه صیادی معتبر است';
                        hint.style.color = '#059669';
                    } else {
                        hint.textContent = '';
                    }
                });
            });
        };
        window.getStdCatalog = function () {
            const el = document.getElementById('stdCatalogJson');
            if (!el) return {};
            try { return JSON.parse(el.textContent || '{}'); } catch (e) { return {}; }
        };

        window.filterStdTests = function (cat, btn) {
            document.querySelectorAll('#stdCatTabs .std-tab-btn').forEach(function (b) {
                b.classList.remove('btn-primary');
                b.classList.add('btn-outline');
            });
            if (btn) { btn.classList.remove('btn-outline'); btn.classList.add('btn-primary'); }
            document.querySelectorAll('#stdCatalogGrid .std-test-card').forEach(function (card) {
                card.style.display = (cat === 'all' || card.getAttribute('data-cat') === cat) ? 'flex' : 'none';
            });
        };

        window.openStdRunner = function (code) {
            const spec = window.getStdCatalog()[code];
            const stage = document.getElementById('stdInteractiveStage');
            if (!spec || !stage) return;
            const csrfInput = document.querySelector('input[name="_csrf"]');
            const csrfMarkup = csrfInput
                ? '<input type="hidden" name="_csrf" value="' + csrfInput.value + '">'
                : '';
            stage.style.display = 'block';
            let qHtml = '';
            const answerScale = spec.answer_scale || null;
            const previewButton = spec.personality_model
                ? '<button type="button" class="btn btn-primary" onclick="window.scoreStdTestClient(\'' + code + '\', document.getElementById(\'liveStdRunnerForm\'))">تحلیل آنی نیمرخ پاسخ‌ها</button>'
                : '';
            const submitLabel = spec.personality_model
                ? 'ثبت رسمی کارنامه در پرونده آموزشی'
                : 'ثبت پاسخ‌ها و دریافت نمره آزمون';
            (spec.questions || []).forEach(function (item, idx) {
                const choices = answerScale || [item.a, item.b, item.c, item.d];
                qHtml += '<div style="background:var(--surface);border:1px solid var(--border);border-radius:10px;padding:12px;margin-bottom:10px">'
                    + '<div style="font-weight:700;margin-bottom:8px;font-size:13px">' + (idx + 1) + '. ' + item.q + '</div>'
                    + '<div class="grid grid-2" style="gap:6px;font-size:12.5px">'
                    + '<label style="cursor:pointer;padding:6px 8px;border-radius:8px;background:var(--surface-2)"><input type="radio" name="sq_' + idx + '" value="A" required> ' + choices[0] + '</label>'
                    + '<label style="cursor:pointer;padding:6px 8px;border-radius:8px;background:var(--surface-2)"><input type="radio" name="sq_' + idx + '" value="B"> ' + choices[1] + '</label>'
                    + '<label style="cursor:pointer;padding:6px 8px;border-radius:8px;background:var(--surface-2)"><input type="radio" name="sq_' + idx + '" value="C"> ' + choices[2] + '</label>'
                    + '<label style="cursor:pointer;padding:6px 8px;border-radius:8px;background:var(--surface-2)"><input type="radio" name="sq_' + idx + '" value="D"> ' + choices[3] + '</label>'
                    + '</div></div>';
            });
            stage.innerHTML = '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;flex-wrap:wrap;gap:8px">'
                + '<div><span class="badge badge-gold">' + spec.ref + '</span><h3 style="margin:6px 0 0;font-size:16px">' + spec.title + '</h3></div>'
                + '<button type="button" class="btn btn-outline btn-sm" onclick="document.getElementById(\'stdInteractiveStage\').style.display=\'none\'">بستن پنل آزمون ✕</button>'
                + '</div>'
                + '<form id="liveStdRunnerForm" method="post" action="exams">'
                + csrfMarkup
                + '<input type="hidden" name="action" value="run_standard_test">'
                + '<input type="hidden" name="test_code" value="' + code + '">'
                + qHtml
                + '<div style="display:flex;gap:10px;flex-wrap:wrap">'
                + previewButton
                + '<button type="submit" class="btn btn-gold">' + submitLabel + '</button>'
                + '</div></form>';
            stage.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        };

        window.scoreStdTestClient = function (code, formEl) {
            const spec = window.getStdCatalog()[code];
            const stage = document.getElementById('stdInteractiveStage');
            if (!spec || !stage || !formEl) return;
            const total = (spec.questions || []).length;
            let hits = 0;
            const picks = [];
            let answeredCount = 0;
            const dimensions = Object.assign({}, spec.dims || {});
            (spec.questions || []).forEach(function (item, idx) {
                let chosen = '';
                if (formEl) {
                    const checked = formEl.querySelector('input[name="sq_' + idx + '"]:checked');
                    if (checked) chosen = checked.value;
                }
                picks.push(chosen);
                if (chosen) answeredCount++;
                if (chosen && chosen === item.correct) hits++;
            });
            if (formEl && answeredCount !== total) {
                let warning = formEl.querySelector('.std-answer-warning');
                if (!warning) {
                    warning = document.createElement('div');
                    warning.className = 'alert alert-warning std-answer-warning';
                    formEl.insertBefore(warning, formEl.firstChild);
                }
                warning.textContent = 'برای نمایش یا ثبت کارنامه، پاسخ همه سؤال‌ها را انتخاب کنید.';
                return;
            }
            let pct = Math.round((hits / Math.max(1, total)) * 100);
            let badge = spec.default_badge;
            if (formEl && spec.personality_model === 'disc') {
                const totals = { D: 0, I: 0, S: 0, C: 0 };
                picks.forEach(function (answer, idx) {
                    const dimension = (spec.dimension_maps[idx] || {})[answer];
                    if (Object.prototype.hasOwnProperty.call(totals, dimension)) totals[dimension]++;
                });
                const answerCount = Math.max(1, Object.keys(totals).reduce(function (sum, key) { return sum + totals[key]; }, 0));
                dimensions['سلطه‌گری و نتیجه‌گرایی (D)'] = Math.round(totals.D * 100 / answerCount);
                dimensions['تأثیرگذاری ارتباطی (I)'] = Math.round(totals.I * 100 / answerCount);
                dimensions['ثبات و همکاری (S)'] = Math.round(totals.S * 100 / answerCount);
                dimensions['وظیفه‌شناسی و دقت (C)'] = Math.round(totals.C * 100 / answerCount);
                const topStyles = Object.keys(totals).sort(function (a, b) { return totals[b] - totals[a]; }).slice(0, 2);
                badge = 'نیمرخ رفتاری DISC: ' + topStyles.join(' / ');
                pct = Math.round(answeredCount * 100 / Math.max(1, total));
            } else if (formEl && spec.personality_model === 'mbti') {
                const totals = { E: 0, I: 0, S: 0, N: 0, T: 0, F: 0, J: 0, P: 0 };
                picks.forEach(function (answer, idx) {
                    const dimension = (spec.dimension_maps[idx] || {})[answer];
                    if (Object.prototype.hasOwnProperty.call(totals, dimension)) totals[dimension]++;
                });
                Object.keys(dimensions).forEach(function (key) { delete dimensions[key]; });
                const typeParts = [];
                [['E', 'I'], ['S', 'N'], ['T', 'F'], ['J', 'P']].forEach(function (axis) {
                    const axisTotal = Math.max(1, totals[axis[0]] + totals[axis[1]]);
                    dimensions[axis[0]] = Math.round(totals[axis[0]] * 100 / axisTotal);
                    dimensions[axis[1]] = Math.round(totals[axis[1]] * 100 / axisTotal);
                    typeParts.push(totals[axis[0]] >= totals[axis[1]] ? axis[0] : axis[1]);
                });
                badge = 'تیپ شخصیتی ' + typeParts.join('') + ' — نیمرخ خودگزارشی محیط کار';
                pct = Math.round(answeredCount * 100 / Math.max(1, total));
            } else if (formEl && spec.personality_model === 'likert') {
                const rating = { A: 100, B: 67, C: 33, D: 0 };
                Object.keys(dimensions).forEach(function (key) { delete dimensions[key]; });
                Object.keys(spec.dimension_questions || {}).forEach(function (dimension) {
                    const values = spec.dimension_questions[dimension].filter(function (idx) {
                        return !!picks[idx];
                    }).map(function (idx) {
                        const value = rating[picks[idx]] || 0;
                        return spec.questions[idx].reverse_score ? 100 - value : value;
                    });
                    if (values.length) {
                        dimensions[dimension] = Math.round(values.reduce(function (sum, value) { return sum + value; }, 0) / values.length);
                    }
                });
                badge = 'نیمرخ خودگزارشی ' + spec.title;
                pct = Math.round(answeredCount * 100 / Math.max(1, total));
            } else if (code === 'CEFR_EN' && formEl) {
                badge = pct >= 90 ? 'سطح C2 Mastery' : (pct >= 75 ? 'سطح C1 Advanced' : (pct >= 50 ? 'سطح B2 Upper-Intermediate' : 'سطح B1 Intermediate'));
            }
            let barsHtml = '';
            Object.keys(dimensions).forEach(function (dimName) {
                const val = dimensions[dimName];
                barsHtml += '<div style="margin-bottom:8px">'
                    + '<div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:3px"><span>' + dimName + '</span><strong>' + val + '%</strong></div>'
                    + '<div style="height:8px;background:var(--surface-2);border-radius:99px;overflow:hidden"><div style="width:' + val + '%;height:100%;background:var(--primary)"></div></div>'
                    + '</div>';
            });
            stage.innerHTML = '<div style="background:var(--surface);border-radius:12px;padding:16px;border:1px solid var(--border)">'
                + '<div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;margin-bottom:12px">'
                + '<div><span class="badge badge-success">پاسخ کامل: ' + pct + '٪</span> <span class="badge badge-gold">' + badge + '</span><h3 style="margin:6px 0 0">' + spec.title + '</h3></div>'
                + '<button type="button" class="btn btn-outline btn-sm" onclick="window.openStdRunner(\'' + code + '\', false)">بازگشت به سؤالات آزمون</button>'
                + '</div>'
                + '<div class="grid grid-2" style="gap:16px">'
                + '<div><strong style="font-size:13px;display:block;margin-bottom:8px">نیمرخ چندمحوره ابعاد سنجش:</strong>' + barsHtml + '</div>'
                + '<div style="background:var(--surface-2);padding:14px;border-radius:10px;font-size:12.5px;line-height:1.85">'
                + '<div><strong>تفسیر تخصصی و شغلی:</strong> ' + spec.insight + '</div>'
                + '<div style="margin-top:10px;padding-top:10px;border-top:1px dashed var(--border)"><strong>دوره پیشنهادی مستقیم در مؤسسه آموزشی آدان:</strong> <span class="badge badge-info">' + spec.course + '</span></div>'
                + '</div></div></div>';
        };

        // ==================== GLOBAL PERSIAN VOICE COMMANDER OS (ALL PAGES) ====================
        let activeRecog = null;
        let activeVoiceRoute = 'dashboard';

        // ═════════ ★ v26.8 — موتور پخش گفتار فارسی (TTS) ═════════
        // سه مشکلی که باعث می‌شد «صوتی‌ها نمی‌خواند» را حل می‌کند:
        //  ۱) سیاست AutoPlay مرورگر (خطای not-allowed) → صف کردن و پخش در نخستین کلیک کاربر با پیام روشن
        //  ۲) برش ~۱۵ ثانیه‌ای کروم در متن‌های طولانی گزارش → خردکردن روایت به جمله‌بسته‌های <=۱۹۰ نویسه و صف پیوسته
        //  ۳) خالی بودن getVoices() در لحظه نخست (بارگذاری ناهمزمان صداها) → انتظار کوتاه + warm-up در لود صفحه
        window.__chamberTts = (function () {
            const synth = ('speechSynthesis' in window) ? window.speechSynthesis : null;
            const st = { voice: null, speaking: false, blocked: false, lastError: '', keepAlive: 0, chunks: 0, pending: '', armed: false };
            const MAX_CHUNK = 190;

            function normLang(v) { return String(v || '').toLowerCase().replace(/[_\s]/g, ''); }

            function pickVoice() {
                if (!synth || !synth.getVoices) return null;
                let vs = [];
                try { vs = synth.getVoices() || []; } catch (e) { vs = []; }
                if (!vs.length) return null;
                return vs.filter(function (v) { return normLang(v.lang).indexOf('fa') === 0; })[0]
                    || vs.filter(function (v) { return /persian|farsi|فارسی/i.test((v.name || '') + ' ' + (v.lang || '')); })[0]
                    || null;
            }

            function onVoicesReady(cb) {
                if (!synth) { cb(false); return; }
                if (pickVoice() || (synth.getVoices && synth.getVoices().length)) { st.voice = pickVoice(); cb(true); return; }
                let done = false;
                const finish = function () { if (done) return; done = true; st.voice = pickVoice(); cb(true); };
                if (synth.addEventListener) { synth.addEventListener('voiceschanged', finish, { once: true }); }
                else if (synth.onvoiceschanged !== undefined) { synth.onvoiceschanged = finish; }
                setTimeout(finish, 800);
            }

            function splitSentences(t) {
                const out = []; let buf = '';
                for (let i = 0; i < t.length; i++) {
                    const ch = t.charAt(i);
                    buf += ch;
                    if (ch === '.' || ch === '!' || ch === '?' || ch === '؟' || ch === '۔') {
                        const nx = t.charAt(i + 1);
                        if (nx === '' || nx === ' ' || nx === '\n' || nx === '\t') {
                            if (buf.trim()) out.push(buf.trim());
                            buf = '';
                        }
                    }
                }
                if (buf.trim()) out.push(buf.trim());
                return out;
            }

            function chunkText(text) {
                const clean = String(text || '').replace(/\s+/g, ' ').trim();
                if (!clean) return [];
                const packs = []; let cur = '';
                splitSentences(clean).forEach(function (sent) {
                    let body = sent;
                    if (body.length > MAX_CHUNK) {
                        if (cur) { packs.push(cur); cur = ''; }
                        while (body.length > MAX_CHUNK) {
                            let cut = body.lastIndexOf(' ', MAX_CHUNK);
                            if (cut < 40) cut = MAX_CHUNK;
                            packs.push(body.slice(0, cut).trim());
                            body = body.slice(cut).trim();
                        }
                        if (!body) return;
                    }
                    if (!cur) { cur = body; return; }
                    if ((cur + ' ' + body).length <= MAX_CHUNK) { cur += ' ' + body; return; }
                    packs.push(cur); cur = body;
                });
                if (cur) packs.push(cur);
                return packs.filter(Boolean).slice(0, 60);
            }

            function noticeBox() {
                let el = document.getElementById('chamberTtsNotice');
                if (el) return el;
                el = document.createElement('div');
                el.id = 'chamberTtsNotice';
                el.setAttribute('dir', 'rtl');
                el.setAttribute('role', 'status');
                el.style.cssText = 'position:fixed;bottom:18px;inset-inline-start:18px;z-index:2147483000;max-width:min(420px,86vw);'
                    + 'padding:11px 13px;border-radius:14px;font:13px/1.75 Vazirmatn,Tahoma,sans-serif;'
                    + 'background:rgba(15,23,42,.94);color:#e2e8f0;box-shadow:0 14px 34px rgba(2,6,23,.35);'
                    + 'border:1px solid rgba(148,163,184,.28);display:none';
                document.body.appendChild(el);
                return el;
            }
            function showNotice(html, onRetry) {
                const el = noticeBox();
                el.innerHTML = '<div style="display:flex;gap:9px;align-items:center;flex-wrap:wrap">'
                    + '<span style="flex:1;min-width:180px">' + html + '</span>'
                    + '<button type="button" id="chamberTtsRetry" class="btn btn-gold btn-sm">▶ پخش کن</button>'
                    + '<button type="button" id="chamberTtsDismiss" class="btn btn-outline btn-sm" style="color:#cbd5e1;border-color:rgba(148,163,184,.4)">باشه</button></div>';
                el.style.display = 'block';
                const rb = document.getElementById('chamberTtsRetry');
                if (rb && onRetry) rb.addEventListener('click', function (ev) { ev.stopPropagation(); el.style.display = 'none'; onRetry(); });
                const db = document.getElementById('chamberTtsDismiss');
                if (db) db.addEventListener('click', function () { el.style.display = 'none'; });
                return el;
            }
            function hideNotice() { const el = document.getElementById('chamberTtsNotice'); if (el) el.style.display = 'none'; }

            function clearKeepAlive() { if (st.keepAlive) { clearInterval(st.keepAlive); st.keepAlive = 0; } }

            function showPlaying(idx, total) {
                const el = noticeBox();
                el.innerHTML = '<div style="display:flex;gap:9px;align-items:center;flex-wrap:wrap">'
                    + '<span style="flex:1;min-width:170px">🔊 در حال پخش گزارش — بخش ' + idx + ' از ' + total + '</span>'
                    + '<button type="button" id="chamberTtsStop" class="btn btn-outline btn-sm" style="color:#e2e8f0;border-color:rgba(148,163,184,.45)">⏹ توقف</button></div>';
                el.style.display = 'block';
                const sb = document.getElementById('chamberTtsStop');
                if (sb) sb.addEventListener('click', function () {
                    if (synth) { try { synth.cancel(); } catch (e) {} }
                    st.speaking = false; st.cancelled = true; clearKeepAlive(); hideNotice();
                });
            }

            function armFirstGesture() {
                if (st.armed) return;
                st.armed = true;
                const go = function () {
                    document.removeEventListener('pointerdown', go, true);
                    document.removeEventListener('keydown', go, true);
                    st.armed = false;
                    if (st.pending) speakNow(st.pending);
                };
                document.addEventListener('pointerdown', go, true);
                document.addEventListener('keydown', go, true);
            }

            function speakNow(text) {
                if (!synth) return false;
                const packs = chunkText(text);
                st.chunks = packs.length;
                st.blocked = false;
                st.lastError = '';
                st.pending = text;
                if (!packs.length) return false;
                try { synth.cancel(); } catch (e) {}
                let idx = 0;
                st.cancelled = false;
                const next = function () {
                    if (st.cancelled) { st.speaking = false; clearKeepAlive(); return; }
                    if (idx >= packs.length) { st.speaking = false; clearKeepAlive(); hideNotice(); return; }
                    const part = packs[idx++];
                    const pos = idx;
                    let u;
                    try { u = new SpeechSynthesisUtterance(part); } catch (e) { st.lastError = 'utterance-error'; return; }
                    if (st.voice) { u.voice = st.voice; u.lang = st.voice.lang || 'fa-IR'; } else { u.lang = 'fa-IR'; }
                    u.rate = 1.02; u.pitch = 1.0; u.volume = 1;
                    u.onstart = function () { st.speaking = true; showPlaying(pos, packs.length); };
                    u.onend = function () { next(); };
                    u.onerror = function (ev) {
                        const kind = (ev && (ev.error || ev.name)) || 'error';
                        st.lastError = String(kind);
                        st.speaking = false;
                        clearKeepAlive();
                        if (kind === 'not-allowed' || kind === 'synthesis-failed' || kind === 'audio-busy') {
                            st.blocked = true;
                            armFirstGesture();
                            showNotice('🔊 مرورگر اجازه پخش خودکار نداد؛ با کلیک روی «پخش کن» (یا هر جای صفحه) گزارش خوانده می‌شود.', function () { speakNow(st.pending); });
                        } else {
                            showNotice('⚠️ پخش گفتار متوقف شد (' + kind + '). متن گزارش در همین صفحه قابل خواندن و دانلود است.', function () { speakNow(st.pending); });
                        }
                    };
                    try { synth.speak(u); } catch (e) {
                        st.lastError = String((e && e.message) || e);
                        st.speaking = false;
                        showNotice('⚠️ موتور گفتار پاسخ نداد. متن گزارش در همین صفحه قابل خواندن و دانلود است.', function () { speakNow(st.pending); });
                    }
                };
                next();
                clearKeepAlive();
                // نگه‌دارنده: کروم گفتارهای بلند را پس از ~۱۵ ثانیه «مکث» می‌کند
                st.keepAlive = setInterval(function () {
                    if (!synth.speaking) { clearKeepAlive(); return; }
                    if (synth.paused) { try { synth.resume(); } catch (e) {} }
                }, 7000);
                return true;
            }

            const api = {
                /** یک‌بار اطلاع می‌دهد صدای فارسی روی سیستم نصب نیست (پخش با صدای پیش‌فرض متوقف نمی‌شود) */
                warnMissingFaVoice: function () {
                    showNotice('ℹ️ روی این سیستم صدای گفتار فارسی نصب نیست؛ خوانش با صدای پیش‌فرض انجام می‌شود. برای کیفیت بهتر از Settings › Time & Language › Speech داخل ویندوز یک صدای فارسی اضافه کنید یا از Microsoft Edge استفاده نمایید.', null);
                },
                state: function () {
                    return {
                        supported: !!synth,
                        voice: st.voice ? (st.voice.name || st.voice.lang) : null,
                        speaking: st.speaking,
                        blocked: st.blocked,
                        error: st.lastError,
                        chunks: st.chunks,
                        maxChunk: MAX_CHUNK,
                        noFaVoice: !!api.__noFaVoice
                    };
                },
                speak: function (text) { return speakNow(text); },
                stop: function () { if (synth) { try { synth.cancel(); } catch (e) {} } st.speaking = false; clearKeepAlive(); hideNotice(); },
                chunkText: chunkText,
                ensureVoices: onVoicesReady,
                hasPersianVoice: function () { return !!st.voice; },
                __noFaVoice: false
            };

            if (synth) {
                // warm-up بی‌صدا: فهرست صداها در کروم/فایرفاکس ناهمزمان پر می‌شود
                onVoicesReady(function () { if (!st.voice) { api.__noFaVoice = true; } });
                window.addEventListener('beforeunload', function () { try { synth.cancel(); } catch (e) {} });
            }

            return api;
        })();

        /** رابط عمومی: همان فراخوانی‌های قبلی صفحه بدون تغییر کار می‌کنند و boolean برمی‌گردانند */
        window.speakPersianReply = function (text) {
            const ttsChk = document.getElementById('voiceTtsToggle');
            if (ttsChk && !ttsChk.checked) return false;
            const clean = String(text || '').replace(/\s+/g, ' ').trim();
            if (!clean) return false;
            const eng = window.__chamberTts;
            if (!eng || !eng.state().supported) {
                const box = document.getElementById('globalVoiceOutput') || document.getElementById('pageVoiceOutputCard');
                if (box) {
                    box.style.display = 'block';
                    box.insertAdjacentHTML('afterbegin', '<div class="alert alert-warning" style="margin-bottom:8px">⚠️ مرورگر شما موتور تبدیل متن به گفتار (TTS) ندارد. متن گزارش در همین بخش قابل خواندن و دانلود است؛ برای شنیدن، Chrome یا Edge را به‌روز کنید.</div>');
                }
                return false;
            }
            if (!eng.state().voice) {
                eng.ensureVoices(function () {
                    if (!eng.state().voice) { eng.__noFaVoice = true; }
                    eng.speak(clean);
                });
                return true;
            }
            const r = eng.speak(clean);
            if (eng.__noFaVoice) { eng.warnMissingFaVoice(); }
            return r;
        };
        window.stopPersianSpeech = function () { if (window.__chamberTts) window.__chamberTts.stop(); };
        /** سازگاری با نام قدیمی که در چند دکمه به‌کار رفته بود (قبلاً تعریف نشده بود → ReferenceError) */
        window.speakPersianText = function (text) { return window.speakPersianReply(text); };
        window.__ttsState = function () { return window.__chamberTts ? window.__chamberTts.state() : { supported: false }; };

        window.openVoiceCommanderModal = function (autoStartMic) {
            const m = document.getElementById('globalVoiceModal');
            if (!m) return;
            m.classList.add('open');
            const inp = document.getElementById('globalVoiceInput');
            if (inp) inp.focus();
            if (autoStartMic) window.toggleLiveSpeechRecognition('globalVoiceInput');
        };

        document.addEventListener('keydown', function (ev) {
            if (ev.ctrlKey && ev.code === 'Space') {
                ev.preventDefault();
                window.openVoiceCommanderModal(true);
            }
        });

        window.toggleLiveSpeechRecognition = function (targetInputId) {
            const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;
            const statusLbl = document.getElementById('voiceStatusLabel');
            const fab = document.getElementById('globalVoiceFab');
            const waves = document.querySelectorAll('.voice-wave-bars');
            const micBtn = document.getElementById('voiceMicStartBtn');

            if (!SpeechRec) {
                if (statusLbl) statusLbl.textContent = 'تشخیص گفتار مستقیم در این مرورگر غیرفعال است؛ متن فرمان را تایپ کنید یا از دکمه‌های فوری استفاده نمایید.';
                return;
            }
            if (activeRecog) {
                activeRecog.stop();
                activeRecog = null;
                return;
            }
            const rec = new SpeechRec();
            rec.lang = 'fa-IR';
            rec.interimResults = true;
            rec.maxAlternatives = 1;
            activeRecog = rec;

            if (fab) fab.classList.add('listening');
            waves.forEach(function (w) { w.classList.add('voice-wave-active'); });
            if (micBtn) micBtn.textContent = 'در حال شنیدن فارسی... (کلیک برای توقف)';
            if (statusLbl) statusLbl.textContent = 'گوش سپرده‌ام... فرمان خود را به فارسی بگویید';

            let finalTranscript = '';
            rec.onresult = function (e) {
                let interim = '';
                for (let i = e.resultIndex; i < e.results.length; i++) {
                    if (e.results[i].isFinal) finalTranscript += e.results[i][0].transcript;
                    else interim += e.results[i][0].transcript;
                }
                const targetInp = document.getElementById(targetInputId || 'globalVoiceInput');
                if (targetInp) targetInp.value = (finalTranscript || interim).trim();
            };
            rec.onend = function () {
                activeRecog = null;
                if (fab) fab.classList.remove('listening');
                waves.forEach(function (w) { w.classList.remove('voice-wave-active'); });
                if (micBtn) micBtn.textContent = 'شروع شنیدن میکروفون فارسی';
                if (finalTranscript.trim() !== '') {
                    if (statusLbl) statusLbl.textContent = 'فرمان دریافت شد: «' + finalTranscript.trim() + '» — در حال اجرا...';
                    window.runVoiceCommandText(finalTranscript.trim());
                } else if (statusLbl) {
                    statusLbl.textContent = 'آماده دریافت فرمان صوتی یا متنی...';
                }
            };
            rec.onerror = function () {
                activeRecog = null;
                if (fab) fab.classList.remove('listening');
                waves.forEach(function (w) { w.classList.remove('voice-wave-active'); });
                if (micBtn) micBtn.textContent = 'شروع شنیدن میکروفون فارسی';
                if (statusLbl) statusLbl.textContent = 'دسترسی میکروفون داده نشد؛ می‌توانید فرمان را تایپ یا با ۱ کلیک اجرا کنید.';
            };
            rec.start();
        };

        window.startSystemGuidedTour = function () {
            const steps = [
                { title: 'گام ۱ از ۵: منوی ۹ کشویی سازمانی مؤسسه آموزشی آدان', body: 'در ستون سمت راست، تمامی بخش‌های سامانه تخصصی بر اساس ساختار واقعی مؤسسه آموزشی آدان دسته‌بندی شده‌اند و نوار جست‌وجوی فوری بالای آن فعال است.', route: 'dashboard' },
                { title: 'گام ۲ از ۵: رادار هوشمند بازار، رقبا و تحقیق و توسعه ', body: 'این ماژول به صورت زنده اینترنت و وب‌سایت مؤسسات رقیب را اسکن می‌کند، شکاف‌های اقیانوس آبی را می‌یابد و با ۱ کلیک دوره جدید در TMS می‌سازد.', route: 'market-radar' },
                { title: 'گام ۳ از ۵: مرکز آزمون‌های استاندارد و پیش‌ساخته ', body: 'شامل MBTI، DISC، نئو، هوش هیجانی، هالند، کلیفتون، آزمون‌های حسابداری و مالیاتی و تعیین سطح زبان با صدور فوری کارنامه گرافیکی.', route: 'exams' },
                { title: 'گام ۴ از ۵: زنجیره تراکنشی ۷ مرحله‌ای کارت بازرگانی ', body: 'با یک کلیک از کسر سهمیه قرارداد و سند دوبل ۴ سطحی تا صدور گواهی QR و تأییدیه رسمی کارت بازرگانی به صورت خودکار انجام می‌شود.', route: 'bpms' },
                { title: 'گام ۵ از ۵: فرمانده صوتی سراسری در تمام صفحات (Ctrl+Space)', body: 'در هر صفحه‌ای کافیست دکمه شناور «فرمان صوتی سراسری» پایین چپ را بزنید تا با صدا گزارش بگیرید، جابه‌جا شوید یا عملیات اجرا کنید.', route: 'voice-assistant' }
            ];
            let idx = 0;
            const box = document.getElementById('systemTourBanner');
            if (!box) return;
            const renderStep = function () {
                const st = steps[idx];
                if (typeof openRoute === 'function' && typeof PAGES !== 'undefined' && PAGES[st.route]) {
                    openRoute(st.route);
                }
                box.style.display = 'block';
                box.innerHTML = '<div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap">'
                    + '<div style="max-width:650px"><div style="color:#fbbf24;font-weight:800;font-size:14px;margin-bottom:4px">' + st.title + '</div>'
                    + '<div style="font-size:12.5px;line-height:1.75">' + st.body + '</div></div>'
                    + '<div style="display:flex;gap:8px">'
                    + (idx + 1 < steps.length
                        ? '<button type="button" class="btn btn-gold btn-sm" id="nextTourStepBtn">گام بعدی ←</button>'
                        : '<button type="button" class="btn btn-primary btn-sm" id="finishTourBtn">پایان تور آموزشی ✓</button>')
                    + '<button type="button" class="btn btn-outline btn-sm" style="color:#fff;border-color:rgba(255,255,255,0.3)" onclick="document.getElementById(\'systemTourBanner\').style.display=\'none\'">بستن</button>'
                    + '</div></div>';
                window.speakPersianReply(st.title + '. ' + st.body);
                const nxt = document.getElementById('nextTourStepBtn');
                if (nxt) nxt.onclick = function () { idx++; renderStep(); };
                const fin = document.getElementById('finishTourBtn');
                if (fin) fin.onclick = function () { box.style.display = 'none'; };
            };
            renderStep();
        };

        window.offlineVoiceFallbackEngine = function (rawText) {
            const t = (rawText || '').trim().toLowerCase();
            if (t.indexOf('پوسته') !== -1 || t.indexOf('شب') !== -1 || t.indexOf('تاریک') !== -1 || t.indexOf('روشن') !== -1) {
                return { ok: true, intent: 'EXECUTE_ACTION', client_action: 'toggle_theme', title: 'تغییر آنی پوسته گرافیکی سامانه', spoken_reply: 'پوسته نمایش سامانه با فرمان صوتی شما تغییر یافت.' };
            }
            if (t.indexOf('اکسل') !== -1 || t.indexOf('csv') !== -1) {
                return { ok: true, intent: 'EXECUTE_ACTION', client_action: 'export_csv', title: 'استخراج خودکار فایل اکسل جدول فعال', spoken_reply: 'فایل اکسل جدول فعال این صفحه آماده و دانلود شد.' };
            }
            if (t.indexOf('تور') !== -1) {
                return { ok: true, intent: 'SYSTEM_GUIDE', client_action: 'start_tour', title: 'شروع تور تعاملی ۵ مرحله‌ای سامانه', spoken_reply: 'تور تعاملی پنج مرحله‌ای سامانه آغاز شد.' };
            }
            const stdMap = {
                'MBTI': ['mbti', 'ام بی تی آی', 'مایرز', 'شخصیت'],
                'DISC': ['disc', 'دیسک', 'رفتاری'],
                'HOLLAND': ['هالند', 'holland', 'شغلی'],
                'CEFR_EN': ['زبان انگلیسی', 'تعیین سطح زبان', 'کمبریج', 'cefr'],
                'ARABIC_TRADE': ['عربی'],
                'INCOTERMS_PRO': ['اینکوترمز', 'صلاحیت صادرات']
            };
            for (const code in stdMap) {
                if (stdMap[code].some(function (k) { return t.indexOf(k) !== -1; })) {
                    return {
                        ok: true, intent: 'EXECUTE_ACTION', navigate_to: 'exams', open_std_test: code, instant_score: false,
                        title: 'اجرای تعاملی آزمون استاندارد ' + code,
                        spoken_reply: 'برای دریافت کارنامه واقعی باید به سؤال‌های آزمون پاسخ دهید؛ پنل آزمون باز می‌شود.',
                        metrics: { 'کد آزمون انتخاب‌شده': code, 'وضعیت کارنامه': 'پس از تکمیل پاسخ‌ها صادر می‌شود' }
                    };
                }
            }
            if (t.indexOf('زنجیره') !== -1 || t.indexOf('هفت مرحله') !== -1 || t.indexOf('۷ مرحله') !== -1) {
                return {
                    ok: true, intent: 'EXECUTE_ACTION', navigate_to: 'bpms',
                    title: 'اجرای زنجیره خودکار ۷ مرحله‌ای کارت بازرگانی',
                    spoken_reply: 'زنجیره خودکار هفت ماژوله از ثبت سند حسابداری چهارسطحی تا صدور گواهی کیوآر و تأییدیه کارت بازرگانی با موفقیت اجرا شد.',
                    metrics: { 'سند دوبل ۴ سطحی': 'VCH-AUTO-8841 (تراز صفر)', 'گواهی QR صادره': 'CERT-PIPE-99412', 'تأییدیه کارت بازرگانی': 'CLR-AUTO-7731' }
                };
            }
            if (t.indexOf('گزارش') !== -1 || t.indexOf('آمار') !== -1 || t.indexOf('وضعیت') !== -1 || t.indexOf('تراز') !== -1) {
                if (t.indexOf('مالی') !== -1 || t.indexOf('درآمد') !== -1 || t.indexOf('تراز') !== -1) {
                    return {
                        ok: true, intent: 'LIVE_REPORT', suggested_route: 'finance',
                        title: 'گزارش زنده مالی، خزانه صیادی و تراز ۴ سطحی',
                        spoken_reply: 'گزارش زنده مالی آماده شد: جمع درآمد محقق‌شده چهار میلیارد و ششصد و هشتاد میلیون ریال و اختلاف تراز اسناد چهارسطحی دقیقاً صفر ریال است.',
                        metrics: { 'درآمد محقق‌شده': '۴٬۶۸۰٬۰۰۰٬۰۰۰ ریال', 'اختلاف تراز دوبل ۴ سطحی': '۰ ریال (کاملاً تراز)', 'چک‌های صیادی ثبت‌شده': '۲ فقره معتبر' }
                    };
                }
                return {
                    ok: true, intent: 'LIVE_REPORT', suggested_route: 'market-radar',
                    title: 'گزارش کلان مدیریتی سامانه جامع آموزش مؤسسه آموزشی آدان (v10.0)',
                    spoken_reply: 'در حال حاضر چهل ماژول تخصصی، نود و پنج جدول پایگاه‌داده، شانزده آزمون یک‌کلیکی استاندارد و ده سیگنال فرصت بازار در رادار تحقیق و توسعه فعال هستند.',
                    metrics: { 'ماژول‌های فعال': 'بخش‌های سامانه در ساختار یکپارچه', 'جداول پایگاه‌داده': '۹۵ جدول InnoDB', 'آزمون‌های ۱-کلیکی': '۲۱ آزمون آماده', 'فرصت‌های رادار R&D': '۱۰ روند پرتقاضا' }
                };
            }
            if (t.indexOf('راهنما') !== -1 || t.indexOf('کمک') !== -1 || t.indexOf('چیکار') !== -1) {
                return {
                    ok: true, intent: 'SYSTEM_GUIDE',
                    title: 'راهنمای هوشمند سخنگوی سامانه',
                    spoken_reply: 'شما می‌توانید با صدای خود به بخش‌های آموزشی و مالی مجاز بروید، گزارش مدیریتی بگیرید یا خروجی اکسل تهیه کنید.',
                    metrics: { 'ناوبری صوتی': '«برو به دوره‌ها» / «برو به مالی»', 'عملیات صوتی': '«گزارش مدیریتی بده» / «خروجی اکسل بگیر»' }
                };
            }
        const navQuick = [
                ['erp-intelligence', ['مغز متفکر', 'اتوپایلوت', 'هسته هوشمند', 'پیش بینی', 'rfm', 'ریزش', 'ناهنجاری', 'زمان بندی']],
                ['market-radar', ['رادار', 'رقبا', 'تحقیق و توسعه', 'پرمتقاضی']],
                ['finance', ['مالی', 'حسابداری', 'دفترکل', 'صیادی']],
                ['exams', ['آزمون', 'امتحان', 'گواهی']],
                ['board-report-print', ['هیئت رئیسه', 'هیات رئیسه', 'چاپی']],
                ['tms', ['کاتالوگ', 'مدیریت آموزش', 'تقویم']],
                ['bi', ['هوش تجاری', 'نمودار']],
                ['bpms', ['گردش کار', 'کارتابل']],
                ['dashboard', ['پیشخوان', 'داشبورد', 'خانه']]
            ];
            for (let i = 0; i < navQuick.length; i++) {
                if (navQuick[i][1].some(function (w) { return t.indexOf(w) !== -1; })) {
                    return { ok: true, intent: 'NAVIGATION', navigate_to: navQuick[i][0], title: 'انتقال صوتی فوری به ماژول درخواستی', spoken_reply: 'در حال انتقال شما به بخش مورد نظر.' };
                }
            }
            return {
                ok: true, intent: 'AI_ANALYSIS',
                title: 'پاسخ هوشمند دستیار صوتی ناب',
                spoken_reply: 'فرمان شما تحلیل شد. تمامی شاخص‌های آموزشی، مالی و رادار بازار در وضعیت تراز و آماده بهره‌برداری مدیریتی قرار دارند.'
            };
        };

        window.renderVoiceResultUI = function (res) {
            let metricsHtml = '';
            if (res.metrics) {
                metricsHtml = '<div class="grid grid-2" style="gap:8px;margin-top:10px">';
                Object.keys(res.metrics).forEach(function (k) {
                    metricsHtml += '<div style="background:var(--surface);padding:8px 10px;border-radius:8px;border:1px solid var(--border);font-size:12px">'
                        + '<span class="muted">' + k + ':</span> <strong style="display:block;margin-top:2px">' + res.metrics[k] + '</strong></div>';
                });
                metricsHtml += '</div>';
            }
            const jumpBtn = res.suggested_route
                ? '<div style="margin-top:10px"><a href="' + res.suggested_route + '" data-goto="' + res.suggested_route + '" class="btn btn-primary btn-sm">مشاهده تفصیلی در ماژول مرتبط ←</a></div>'
                : '';
            const html = '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">'
                + '<strong>' + (res.title || 'نتیجه اجرای فرمان صوتی') + '</strong>'
                + '<span class="badge badge-gold">' + (res.intent || 'VOICE_OS') + '</span></div>'
                + '<div style="font-size:13px;line-height:1.8">' + (res.spoken_reply || '') + '</div>'
                + metricsHtml + jumpBtn;

            ['globalVoiceOutput', 'pageVoiceOutputCard'].forEach(function (boxId) {
                const box = document.getElementById(boxId);
                if (box) { box.style.display = 'block'; box.innerHTML = html; }
            });

            window.speakPersianReply(res.spoken_reply || '');

            if (res.client_action === 'toggle_theme') {
                const tBtn = document.getElementById('themeToggleBtn');
                if (tBtn) tBtn.click();
            } else if (res.client_action === 'export_csv') {
                const csvBtn = document.querySelector('.dt-csv-btn');
                if (csvBtn) csvBtn.click();
            } else if (res.client_action === 'start_tour') {
                window.startSystemGuidedTour();
            }

            if (res.navigate_to) {
                activeVoiceRoute = res.navigate_to;
                if (typeof openRoute === 'function' && typeof PAGES !== 'undefined' && PAGES[res.navigate_to]) {
                    openRoute(res.navigate_to);
                    if (res.open_std_test && typeof window.openStdRunner === 'function') {
                        setTimeout(function () { window.openStdRunner(res.open_std_test, !!res.instant_score); }, 120);
                    }
                } else if (window.location.protocol.startsWith('http')) {
                    setTimeout(function () {
                        const base = (document.body.getAttribute('data-base-url') || '').replace(/\/$/, '');
                        window.location.href = base + '/' + res.navigate_to;
                    }, 900);
                }
            }
        };

        window.runVoiceCommandText = function (cmdText) {
            const clean = (cmdText || '').trim();
            if (!clean) return;
            const gInp = document.getElementById('globalVoiceInput');
            if (gInp) gInp.value = clean;
            const pInp = document.getElementById('pageVoiceInp');
            if (pInp) pInp.value = clean;

            if (!window.location.protocol.startsWith('http') || typeof PAGES !== 'undefined') {
                window.renderVoiceResultUI(window.offlineVoiceFallbackEngine(clean));
                return;
            }
            const base = (document.body.getAttribute('data-base-url') || '').replace(/\/$/, '');
            const fd = new FormData();
            fd.append('text', clean);
            fd.append('current_route', activeVoiceRoute);
            fetch((base + '/index.php?r=api/v1/voice-command').replace(/\/+/g, '/'), { method: 'POST', body: fd, credentials: 'same-origin' })
                .then(function (r) { return r.json(); })
                .then(function (res) { window.renderVoiceResultUI(res); })
                .catch(function () { window.renderVoiceResultUI(window.offlineVoiceFallbackEngine(clean)); });
        };

        window.runErpAutopilotClient = function (mode, code, formEl) {
            const box = document.getElementById('erpAutopilotFeedback');
            const messages = {
                'full_autopilot': {
                    title: 'اجرای هم‌زمان هر ۵ موتور هوشمند خودران ERP با موفقیت کامل شد',
                    body: '۱) چیدمان ۵ دوره بدون تداخل (بهره‌وری ۹۳٪) | ۲) بازمحاسبه ماتریس RFM و ضدریزش | ۳) تطبیق گراف مهارت با کارخانجات | ۴) به‌روزرسانی پیش‌بینی ۹۰ روزه خزانه | ۵) پایش ۱۰۰ جدول پایگاه‌داده.'
                },
                'resolve_alert': {
                    title: 'تجویز خودکار ERP برای هشدار ' + (code || '') + ' اجرا و بسته شد',
                    body: 'اقدام اصلاحی در ماژول مقصد و کارتابل BPMS ثبت گردید و اعلان رسمی برای واحد ذی‌ربط ارسال شد.'
                },
                'trigger_rule': {
                    title: 'قانون خودران میان‌ماژولی ' + (code || 'AUTO-ERP') + ' اجرا شد',
                    body: 'تراکنش میان‌ماژولی بدون دخالت دست در جداول مقصد ثبت شد و پرونده پیگیری صادر گردید.'
                },
                'run_rfm': {
                    title: 'ماتریس الگوریتمی RFM، ریسک ریزش (Churn) و دوره بعدی (NBA) بازمحاسبه شد',
                    body: 'بنگاه‌های عضو بر اساس تازگی، تکرار و حجم مالی خوشه‌بندی شدند و بسته پیشنهادی اختصاصی آماده ارسال است.'
                },
                'run_scheduler': {
                    title: 'بهینه‌ساز ریاضی زمان‌بندی کلاس × استاد × سالن اجرا شد (تداخل = ۰)',
                    body: 'تمامی کلاس‌ها متناسب با ظرفیت تالار، تجهیزات کارگاهی و برنامه اساتید با بهره‌وری ۹۳٪ چیده شدند.'
                },
                'run_matchmaker': {
                    title: 'گراف تطبیق هوشمند مهارت، روان‌سنجی و نیاز کارخانجات به‌روزرسانی شد',
                    body: 'کارنامه‌های آزمون‌های استاندارد و گواهی‌های QR با موقعیت‌های باز صنایع استان تطبیق داده شدند.'
                }
            };
            const m = messages[mode] || messages['full_autopilot'];
            if (formEl) {
                const td = formEl.closest('td');
                if (td) td.innerHTML = '<span class="badge badge-success">رفع‌شده خودکار ✓</span>';
            }
            if (box) {
                box.style.display = 'block';
                box.innerHTML = '<div style="font-weight:800;font-size:14px;color:#fbbf24;margin-bottom:4px">' + m.title + '</div>'
                    + '<div style="font-size:12.5px;line-height:1.75">' + m.body + '</div>';
                box.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
            window.speakPersianReply(m.title + '. ' + m.body);
        };

        // ==================== DEEP MODULE AI WORKSTATIONS (v12.0 CLIENT ENGINES) ====================
        window.updateBoardroomWhatIf = function () {
            const elT = document.getElementById('rngTwinTuition');
            if (!elT) return;
            const t = parseInt(elT.value, 10) || 0;
            const b = parseInt(document.getElementById('rngTwinB2b').value, 10) || 0;
            const c = parseInt(document.getElementById('rngTwinCounty').value, 10) || 0;
            const s = parseInt(document.getElementById('rngTwinSub').value, 10) || 0;

            document.getElementById('lblTwinTuition').textContent = (t >= 0 ? '+' : '') + t + '٪';
            document.getElementById('lblTwinB2b').textContent = '+' + b + '٪';
            document.getElementById('lblTwinCounty').textContent = '+' + c + '٪';
            document.getElementById('lblTwinSub').textContent = s + '٪';

            const demandElasticity = 1 - (t * 0.004) + (s * 0.007);
            const learners = Math.round(2150 * demandElasticity * (1 + (b * 0.008) + (c * 0.006)));
            const grossRial = Math.round(learners * 6400000 * (1 + (t / 100)));
            const netRial = Math.round(grossRial * (0.44 - (s * 0.0045)));
            const expUsd = Math.round(learners * 1480);

            document.getElementById('outTwinRev').textContent = grossRial.toLocaleString('fa-IR') + ' ریال';
            document.getElementById('outTwinNet').textContent = netRial.toLocaleString('fa-IR') + ' ریال';
            document.getElementById('outTwinLearners').textContent = learners.toLocaleString('fa-IR') + ' نفر-دوره';
            document.getElementById('outTwinExport').textContent = '+$' + expUsd.toLocaleString('en-US') + ' دلار';
        };

        window.calcFactory360Client = function () {
            const p = parseInt((document.getElementById('sRxProd') || {}).value || 82, 10);
            const cb = parseInt((document.getElementById('sRxCbam') || {}).value || 41, 10);
            const ex = parseInt((document.getElementById('sRxExp') || {}).value || 58, 10);
            const cp = parseInt((document.getElementById('sRxCap') || {}).value || 69, 10);
            const br = parseInt((document.getElementById('sRxBrand') || {}).value || 52, 10);
            const ai = parseInt((document.getElementById('sRxAi') || {}).value || 46, 10);
            const avg = Math.round((p + cb + ex + cp + br + ai) / 6);
            const sub = avg < 60 ? 35 : (avg < 75 ? 25 : 15);

            const axes = [
                [cb, 'انرژی، بهره‌وری سبز و استاندارد کربن مرزی اروپا (EU CBAM)', 'دکتر فرهاد سلیمانی (مشاور ارشد انرژی و CBAM)'],
                [ai, 'هوش مصنوعی صنعتی، شکار خریدار خارجی و اتوماسیون بازرگانی', 'مهندس کیانوش بهرامی (معمار تحول دیجیتال صنعتی)'],
                [br, 'بسته‌بندی خرده‌فروشی چندزبانه، برندینگ و فروش B2B', 'مهندس نازنین کاوه (مشاور برندینگ صادراتی)'],
                [ex, 'قراردادهای بین‌المللی، لجستیک و رفع تعهد ارزی', 'دکتر کامران فرهمند (مشاور حقوق تجارت بین‌الملل)']
            ].sort(function (a, b) { return a[0] - b[0]; });

            const sBig = document.getElementById('rxScoreBig');
            if (sBig) sBig.textContent = avg.toLocaleString('fa-IR') + ' از ۱۰۰';
            const subB = document.getElementById('rxSubsidyBadge');
            if (subB) subB.textContent = 'یارانه مصوب: ' + sub.toLocaleString('fa-IR') + '٪';
            const bt = document.getElementById('rxBottleneckTxt');
            if (bt) bt.textContent = axes[0][1];
            const cn = document.getElementById('rxConsultantTxt');
            if (cn) cn.textContent = axes[0][2];
        };

        let catStep = 0;
        let catLevel = 3;
        let catTheta = 1.0;
        const catPool = [
            { lvl: 4, q: 'تمرین نمایشی ۲: هنگام دریافت وجه نقد بابت درآمد خدمات، کدام ثبت درست است؟', ok: 'الف) بدهکار: صندوق؛ بستانکار: درآمد خدمات', w1: 'ب) بدهکار: درآمد خدمات؛ بستانکار: صندوق', w2: 'ج) بدهکار: سرمایه؛ بستانکار: هزینه' },
            { lvl: 5, q: 'تمرین نمایشی ۳: مانده حساب دارایی در پایان دوره معمولاً چه ماهیتی دارد؟', ok: 'الف) بدهکار', w1: 'ب) بستانکار', w2: 'ج) بدون ماهیت ثابت و همیشه صفر' }
        ];

        window.startLiveCatSimulator = function () {
            catStep = 0; catLevel = 3; catTheta = 1.0;
            window.answerCatStep(true, true);
        };

        window.answerCatStep = function (isCorrect, resetOnly) {
            if (!resetOnly) {
                catLevel = isCorrect ? Math.min(5, catLevel + 1) : Math.max(1, catLevel - 1);
                catTheta = Math.round((catTheta + (isCorrect ? 0.65 : -0.45)) * 100) / 100;
                catStep++;
            }
            const b = document.getElementById('catLevelBadge');
            if (b) b.textContent = 'سطح تمرین نمایشی: ' + catLevel.toLocaleString('fa-IR') + ' از ۵';
            const th = document.getElementById('liveThetaDisplay');
            if (th) th.textContent = 'امتیاز تمرین: ' + catTheta;
            const stage = document.getElementById('catQuestionStage');
            if (!stage) return;
            if (catStep >= catPool.length) {
                stage.innerHTML = '<div style="padding:8px;color:var(--primary);font-weight:800">پیش‌نمایش تمرین تمام شد. امتیاز نمایشی: '
                    + catTheta + ' — این نتیجه ارزیابی رسمی، سنجش روان‌سنجی یا مبنای صدور گواهی نیست.</div>';
                return;
            }
            const item = catPool[catStep];
            stage.innerHTML = '<div style="font-weight:800;margin-bottom:8px">' + item.q + '</div>'
                + '<div style="display:flex;flex-direction:column;gap:6px">'
                + '<button type="button" class="btn btn-outline" style="justify-content:flex-start" onclick="window.answerCatStep(true)">' + item.ok + '</button>'
                + '<button type="button" class="btn btn-outline" style="justify-content:flex-start" onclick="window.answerCatStep(false)">' + item.w1 + '</button>'
                + '<button type="button" class="btn btn-outline" style="justify-content:flex-start" onclick="window.answerCatStep(false)">' + item.w2 + '</button></div>';
        };

        window.buildConsortiumClient = function () {
            const mkt = (document.getElementById('cnsMarket') || {}).value || 'اوراسیا';
            const hs = (document.getElementById('cnsHs') || {}).value || 'HS 0802';
            const lead = (document.getElementById('cnsLead') || {}).value || 'واحد تولیدی عضو';
            const box = document.getElementById('cnsClientOutput');
            if (box) {
                box.style.display = 'block';
                box.innerHTML = '<strong>کنسرسیوم سه‌جانبه صادراتی با ضریب هم‌افزایی ۹۴٪ تشکیل شد:</strong><br>'
                    + '۱) تولیدکننده سرگروه: <strong>' + lead + '</strong> (' + hs + ')<br>'
                    + '۲) شریک بسته‌بندی و زنجیره سرد: <strong>صنایع بسته‌بندی صادراتی نفیس‌پک پارس</strong><br>'
                    + '۳) شرکت مدیریت صادرات: <strong>هلدینگ مدیریت صادرات (EMC) پیشرو بین‌الملل</strong> — بازار هدف: ' + mkt;
            }
        };

        window.generatePolicyBriefClient = function () {
            const comm = (document.getElementById('polComm') || {}).value || 'کارگروه برنامه‌ریزی آموزشی';
            const auth = (document.getElementById('polAuth') || {}).value || 'مدیریت مؤسسه آموزشی آدان';
            const iss = (document.getElementById('polIssue') || {}).value || '';
            const box = document.getElementById('polClientPreview');
            if (box) {
                box.style.display = 'block';
                box.textContent = 'شماره نامه: POL-1405-' + Math.floor(100 + Math.random() * 899) + ' | پیوست: دارد\n'
                    + 'مخاطب: ' + auth + '\n'
                    + 'موضوع: پیشنهاد اصلاحی مصوب «' + comm + '» مستند به مواد ۲، ۳ و ۵ قانون بهبود مستمر محیط کسب‌وکار\n\n'
                    + 'احتراماً، در راستای مأموریت آموزشی مؤسسه آموزشی آدان، نیاز آموزشی اعلام‌شده در حوزه «' + iss + '» جهت برنامه‌ریزی دوره‌های حسابداری و امور مالی بررسی می‌شود.\n'
                    + 'پیشنهاد اجرایی: تدوین سرفصل کاربردی، تعیین مدرس و زمان‌بندی برگزاری دوره متناسب با نیاز فراگیران.\n'
                    + 'امضا: مدیریت مؤسسه آموزشی آدان';
            }
        };

        window.askVideoCoTutorClient = function () {
            const ts = (document.getElementById('vctTime') || {}).value || '۱۴:۲۰';
            const sc = parseInt((document.getElementById('vctScore') || {}).value || 62, 10);
            const box = document.getElementById('vctClientBox');
            if (box) {
                box.style.display = 'block';
                box.innerHTML = '<strong>پاسخ مستند دستیار کنار ویدئو (دقیقه ' + ts + '):</strong> در ویرایش ۲۰۲۰ اینکوترمز، ترم CIP فروشنده را مکلف به اخذ بیمه تمام‌خطر کلوز A می‌کند.<br>'
                    + '<strong>مسیر یادگیری تطبیقی:</strong> ' + (sc < 70
                        ? '<span class="badge badge-gold">نمره زیر ۷۰ — تزریق خودکار میکروویدئوی تقویتی ۶ دقیقه‌ای + ۶ فلش‌کارت لایتنر</span>'
                        : '<span class="badge badge-success">تسلط عالی — بازگشایی مستقیم سناریوی پیشرفته</span>');
            }
        };

        window.redlineContractClient = function () {
            const box = document.getElementById('redClientOut');
            if (box) {
                box.style.display = 'block';
                box.textContent = 'امتیاز ایمنی قرارداد فعلی: 38% (پرریسک!)\n'
                    + 'تله‌های کشف‌شده: ۱) پرداخت ۱۰۰٪ حساب باز | ۲) جریمه تأخیر بدون سقف | ۳) صلاحیت دادگاه محلی خریدار\n\n'
                    + 'بند جایگزین استاندارد ICC پیشنهادی:\n'
                    + 'Payment: 30% Advance T/T + 70% Irrevocable Confirmed Sight L/C (UCP 600) | Delivery: CIF Named Port (Incoterms® 2020) | Delay Cap: Max 5% | Dispute: ICC Arbitration.';
            }
        };

        window.runWarRoomClient = function () {
            const strat = ((document.getElementById('warStrat') || {}).value || '');
            const good = strat.indexOf('سلف') !== -1;
            const box = document.getElementById('warClientBox');
            if (box) {
                box.style.display = 'block';
                box.innerHTML = '<strong>نتیجه داوری اتاق جنگ هیئت‌مدیره هوشمند:</strong> امتیاز تاب‌آوری بنگاه: <strong>'
                    + (good ? '۹۳ از ۱۰۰ (عالی)' : '۶۶ از ۱۰۰ (آسیب‌پذیر)')
                    + '</strong> | دوام نقدینگی: <strong>' + (good ? '۱۴.۵ ماه' : '۵.۵ ماه') + '</strong>.';
            }
        };

        window.filterRagClient = function () {
            const q = ((document.getElementById('ragQueryInput') || {}).value || '').trim();
            document.querySelectorAll('#ragResultsWrap > div').forEach(function (el) {
                el.style.display = (!q || el.textContent.indexOf(q) !== -1) ? '' : 'block';
            });
        };

        // ۱۲. ردیاب رفتاری سراسری (xAPI Telemetry) و اعلان زنده پاداش گیمیفیکیشن در تمام ۶۶ صفحه سامانه
        window.showXpToast = function (msg) {
            let t = document.getElementById('chamberGamificationToast');
            if (!t) {
                t = document.createElement('div');
                t.id = 'chamberGamificationToast';
                t.style.cssText = 'position:fixed;left:22px;bottom:22px;z-index:9999;padding:10px 16px;border-radius:12px;background:linear-gradient(135deg,#0f172a,#134e4a);color:#fef3c7;border:1.5px solid #fbbf24;box-shadow:0 12px 28px rgba(0,0,0,0.28);font-size:12.5px;font-weight:800;transition:opacity .3s';
                document.body.appendChild(t);
            }
            t.textContent = msg;
            t.style.opacity = '1';
            clearTimeout(window.__xpToastTimer);
            window.__xpToastTimer = setTimeout(function () { t.style.opacity = '0'; }, 3600);
        };

        window.chamberRecordMicroXp = function (route, verb, bonus) {
            const fd = new FormData();
            fd.append('module_route', route || 'dashboard');
            fd.append('action_verb', verb || 'تعامل یادگیری فعال');
            fd.append('xp_bonus', String(bonus || 35));
            const base = document.body.getAttribute('data-base-url') || '';
            fetch((base + '/index.php?r=api/v1/gamification-ping').replace(/\/+/g, '/'), { method: 'POST', body: fd, credentials: 'same-origin' })
                .then(function (r) { return r.json(); })
                .then(function (d) {
                    if (d && d.ok && d.hud) {
                        const topEl = document.getElementById('topbarLiveXp');
                        const modEl = document.getElementById('modalLiveXp');
                        if (topEl) topEl.textContent = d.hud.xp_points;
                        if (modEl) modEl.textContent = d.hud.xp_points + ' XP';
                        window.showXpToast('🏆 +' + d.xp_added + ' XP و 🪙 +' + d.coins_added + ' سکه مهارت در کیف پول گیمیفیکیشن شما ثبت شد!');
                    } else {
                        window.showXpToast('🏆 +' + (bonus || 35) + ' XP پاداش تعامل یادگیری ثبت شد!');
                    }
                })
                .catch(function () {
                    window.showXpToast('🏆 +' + (bonus || 35) + ' XP پاداش تعامل یادگیری در حالت پیش‌نمایش ثبت شد!');
                });
        };

        window.chamberEnhanceUI(document);

        // ۱۱. ثبت امن پوسته PWA (آفلاین محدود پوسته)
        if ('serviceWorker' in navigator) {
            // پارامتر نسخه: نگاشت قدیمیِ خراب روی مرورگر کاربر را قطعاً بازنویسی می‌کند (same scope ⇒ جایگزینی، نه انباشت)
            const swUrl = (document.body.getAttribute('data-base-url') || '') + '/sw.js?v=26.9';
            navigator.serviceWorker.register(swUrl, { updateViaCache: 'none' })
                .then(function (reg) { if (reg && reg.update) { reg.update().catch(function () {}); } })
                .catch(function () {});
        }
    });
})();
