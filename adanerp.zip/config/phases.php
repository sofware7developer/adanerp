<?php
declare(strict_types=1);

return [
    // معماری ۸ رکنی استاندارد جهانی ERP آموزشی (Educational & Training ERP Standard Taxonomy)
    'nav_groups' => [
        'executive_bi' => [
            'accent' => '#8b5cf6',
            'icon' => '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/></svg>',
            'title' => 'مدیریت آموزشگاه و گزارش‌ها',
            'subtitle' => 'داشبورد آدان، گزارش‌های آموزشی و میزکار نقش‌ها',
            'routes' => ['dashboard', 'bi', 'digital-twin-bi', 'role-workstations'],
        ],
        'academic_core' => [
            'accent' => '#38bdf8',
            'icon' => '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 10v6M2 10l10-5 10 5-10 5z"/><path d="M6 12v5c3 3 9 3 12 0v-5"/></svg>',
            'title' => 'دوره‌ها، کلاس‌ها و مدرسان',
            'subtitle' => 'دوره‌های حسابداری، برنامه کلاس، حضور و غیاب و مدرسان',
            'routes' => ['tms', 'academic-erp-core', 'classrooms', 'instructors', 'competency', 'evaluation'],
        ],
        'lms_exams' => [
            'accent' => '#10b981',
            'icon' => '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="5 3 19 12 5 21 5 3"/></svg>',
            'title' => 'یادگیری، آزمون و گواهی‌نامه',
            'subtitle' => 'LMS، وبینار زنده، لایتنر، آزمون و گواهی QR',
            'routes' => ['lms', 'virtual-class', 'microlearning', 'ai-studio', 'exams', 'proctoring-drm', 'iso-qa', 'gamification-analytics', 'verify'],
        ],
        'learners_crm' => [
            'accent' => '#f59e0b',
            'icon' => '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
            'title' => 'دانشجویان و پذیرش',
            'subtitle' => 'پرونده آموزشی، ثبت‌نام و ارتباط با دانشجویان',
            'routes' => ['portal', 'crm', 'marketing-intel', 'market-radar', 'alumni-club'],
        ],
        'finance_accounting' => [
            'accent' => '#22c55e',
            'icon' => '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="5" width="20" height="14" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/></svg>',
            'title' => 'امور مالی، شهریه و حسابداری',
            'subtitle' => 'شهریه، صورت‌حساب، دفترکل ۴ سطحی و مؤدیان',
            'routes' => ['finance', 'tax-moadian', 'national-interchange'],
        ],
        'office_hr' => [
            'accent' => '#fb7185',
            'icon' => '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>',
            'title' => 'امور و پشتیبانی آموزشگاه',
            'subtitle' => 'امور اداری، کارکنان و پاسخ‌گویی به دانشجویان',
            'routes' => ['office-automation', 'hr', 'bpms', 'helpdesk-sla', 'workspace-tools'],
        ],
        'learning_resources' => [
            'accent' => '#06b6d4',
            'icon' => '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>',
            'title' => 'منابع و فعالیت‌های آموزشی',
            'subtitle' => 'کتابخانه، پژوهش، کارگاه و مسابقه‌های آموزشی',
            'routes' => ['events', 'research', 'library', 'competitions'],
        ],
        'ai_governance_sys' => [
            'accent' => '#a78bfa',
            'icon' => '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',
            'title' => 'تنظیمات و ابزارهای سامانه',
            'subtitle' => 'تنظیمات آدان، هوش مصنوعی، کاربران و راهنما',
            'routes' => ['ai-governance', 'erp-intelligence', 'voice-assistant', 'system-settings', 'iam-access', 'portal-builder', 'public-home', 'system-ops', 'help-center'],
        ],
    ],

    // =====================================================================
    // منوی ساده‌شده فضای دانشجویی
    // دانشجو هیچ داشبورد مدیریتی، ERP یا ماژول سازمانی نمی‌بیند؛ فقط دوره و هرچه
    // مستقیماً به یادگیری او مربوط است (منو + دسترسی مسیرها با هم یکی هستند).
    // =====================================================================
    'learner_nav' => [
        'my_learning' => [
            'title' => '🎓 فضای دانشجویی من',
            'items' => [
                ['route' => 'dashboard',          'title' => 'پیشخوان دانشجو'],
                ['route' => 'tms',                'title' => 'دوره‌ها و ثبت‌نام'],
                ['route' => 'lms',                'title' => 'درس‌ها و ویدئوهای من'],
                ['route' => 'academic-erp-core',  'title' => 'برنامه کلاس، حضور و کارنامه'],
                ['route' => 'virtual-class',      'title' => 'وبینار و کلاس آنلاین زنده'],
                ['route' => 'microlearning',      'title' => 'مرور سریع و جعبه لایتنر'],
                ['route' => 'exams',              'title' => 'آزمون و گواهی QR'],
                ['route' => 'library',            'title' => 'کتابخانه و منابع درسی'],
                ['route' => 'finance',            'title' => 'شهریه، فاکتور و پرداخت من'],
                ['route' => 'helpdesk-sla',       'title' => 'پشتیبانی و میز خدمت'],
            ],
        ],
        'my_profile' => [
            'title' => '👤 پرونده آموزشی من',
            'items' => [
                ['route' => 'portal',     'title' => 'پرونده آموزشی و وضعیت دوره‌ها'],
                ['route' => 'competency', 'title' => 'ماتریس شایستگی و مسیر رشد من'],
            ],
        ],
    ],

    // مسیرهای کمکی فراگیر (چاپ کارت/کارنامه/فاکتور و استعلام گواهی) — باز اما بدون نمایش در منو
    'learner_aux_routes' => [
        'class-card-print', 'transcript-print', 'invoice-print', 'verify', 'passport', 'help-center',
    ],

    'phases' => [
        1 => ['code' => 'CORE', 'title' => 'هسته آموزش حسابداری و یادگیری هوشمند', 'subtitle' => 'مدیریت دوره‌ها، برنامه کلاس، یادگیری الکترونیکی و محتوای آموزشی', 'progress' => 100],
        2 => ['code' => 'FIN',  'title' => 'مدرسان، آزمون‌ها و امور مالی آموزشگاه', 'subtitle' => 'بانک مدرسان، شهریه، ارزیابی، صورتحساب و گزارش مالی', 'progress' => 100],
        3 => ['code' => 'STU',  'title' => 'پذیرش، ثبت‌نام و پرونده دانشجویان', 'subtitle' => 'پرونده آموزشی، ارتباط با دانشجو و پیگیری ثبت‌نام دوره‌ها', 'progress' => 100],
        4 => ['code' => 'ACAD', 'title' => 'دوره‌های تخصصی حسابداری و مالیات', 'subtitle' => 'حسابداری، حقوق و دستمزد، نرم‌افزار مالی و قوانین مالیاتی', 'progress' => 100],
        5 => ['code' => 'RES',  'title' => 'فضاهای آموزشی، پژوهش، کتابخانه و مهارت‌ورزی', 'subtitle' => 'رزرو کلاس‌ها، طرح‌های پژوهشی، کتابخانه دیجیتال، کارآموزی و مسابقات', 'progress' => 100],
        6 => ['code' => 'OA',   'title' => 'اتوماسیون اداری، گردش کار، هوش تجاری و AI', 'subtitle' => 'مکاتبات و دبیرخانه، منابع انسانی، فرایندساز، گزارش‌ساز BI و مدیریت AI', 'progress' => 100],
        7 => ['code' => 'STAT', 'title' => 'کلاس آنلاین، مالیات و اطلاع‌رسانی آموزشی', 'subtitle' => 'کلاس زنده، سامانه مؤدیان و ارتباط با دانشجویان', 'progress' => 100],
        8 => ['code' => 'DIP',  'title' => 'فعالیت‌های تکمیلی و مهارت‌ورزی', 'subtitle' => 'کارآموزی، مسابقه‌های مهارتی و برنامه‌های دانش‌آموختگان', 'progress' => 100],
        9 => ['code' => 'EMP',  'title' => 'کیفیت آموزشی و مسیر شغلی دانش‌آموختگان', 'subtitle' => 'استاندارد کیفیت آموزشی، فرصت‌های شغلی و شبکه فارغ‌التحصیلان', 'progress' => 100],
        10 => ['code' => 'SEC', 'title' => 'امنیت دسترسی، امضای دیجیتال، شعب و مستندات', 'subtitle' => 'احراز هویت، سلامت آزمون، دفاتر شهرستان‌ها، تنظیمات سیستم و مرکز راهنما', 'progress' => 100],
    ],

    'modules' => [
        ['num' => 0,  'phase' => 6,  'route' => 'dashboard',              'title' => 'پیشخوان مدیریت آموزشگاه',                'badge' => 'پیشخوان',      'roles' => ['super_admin','training_expert','finance_manager','crm_manager','instructor','org_rep','learner']],
        ['num' => 1,  'phase' => 1,  'route' => 'tms',                    'title' => 'مدیریت دوره‌ها و کلاس‌ها',                'badge' => 'آموزش',        'roles' => ['super_admin','training_expert','instructor','finance_manager','org_rep','learner']],
        ['num' => 2,  'phase' => 1,  'route' => 'competency',             'title' => 'نیازسنجی و ماتریس شایستگی',              'badge' => 'شایستگی',      'roles' => ['super_admin','training_expert','instructor','org_rep','learner']],
        ['num' => 3,  'phase' => 1,  'route' => 'lms',                    'title' => 'سامانه یادگیری الکترونیکی (LMS)',        'badge' => 'محتوا',        'roles' => ['super_admin', 'training_expert', 'instructor', 'learner']],
        ['num' => 4,  'phase' => 1,  'route' => 'ai-studio',              'title' => 'استودیوی تولید محتوا با AI',             'badge' => 'AI',           'roles' => ['super_admin','training_expert','instructor']],

        ['num' => 5,  'phase' => 2,  'route' => 'instructors',            'title' => 'بانک اساتید و حق‌التدریس',               'badge' => 'اساتید',       'roles' => ['super_admin', 'training_expert', 'finance_manager']],
        ['num' => 6,  'phase' => 2,  'route' => 'events',                 'title' => 'کارگاه‌ها و نشست‌های آموزشی',              'badge' => 'کارگاه',       'roles' => ['super_admin', 'training_expert', 'finance_manager', 'crm_manager', 'org_rep', 'learner']],
        ['num' => 7,  'phase' => 2,  'route' => 'finance',                'title' => 'امور مالی و شهریه',                      'badge' => 'مالی',         'roles' => ['super_admin','finance_manager','training_expert','org_rep','learner']],
        ['num' => 8,  'phase' => 2,  'route' => 'evaluation',             'title' => 'ارزشیابی آموزشی و اثربخشی',              'badge' => 'اثربخشی',      'roles' => ['super_admin','training_expert','instructor','finance_manager']],

        ['num' => 9,  'phase' => 3,  'route' => 'portal',                 'title' => 'پرونده آموزشی و خدمات دانشجو',            'badge' => 'دانشجو',       'roles' => ['super_admin', 'training_expert', 'org_rep', 'learner']],
        ['num' => 10, 'phase' => 3,  'route' => 'crm',                    'title' => 'پذیرش و پیگیری ثبت‌نام',                  'badge' => 'پذیرش',        'roles' => ['super_admin', 'training_expert', 'crm_manager']],
        ['num' => 11, 'phase' => 3,  'route' => 'contracts',              'title' => 'قراردادهای آموزشی سازمانی',              'badge' => 'قرارداد',      'roles' => ['super_admin','crm_manager','finance_manager','training_expert','org_rep']],

        ['num' => 13, 'phase' => 4,  'route' => 'leadership',             'title' => 'توسعه مهارت‌های مدیریتی و رهبری',        'badge' => 'مدیریت',       'roles' => ['super_admin', 'training_expert', 'learner']],
        ['num' => 14, 'phase' => 4,  'route' => 'consulting',             'title' => 'مشاوره تخصصی و منتورینگ',                'badge' => 'مشاوره',       'roles' => ['super_admin', 'training_expert', 'learner']],
        ['num' => 15, 'phase' => 4,  'route' => 'exams',                  'title' => 'مرکز آزمون و صدور گواهی QR',             'badge' => 'آزمون',        'roles' => ['super_admin','training_expert','instructor','org_rep','learner']],

        ['num' => 16, 'phase' => 5,  'route' => 'classrooms',             'title' => 'مدیریت کلاس‌ها و تالارها',               'badge' => 'تالار',        'roles' => ['super_admin', 'training_expert']],
        ['num' => 17, 'phase' => 5,  'route' => 'research',               'title' => 'پژوهش‌های کاربردی و پیمایش',             'badge' => 'پژوهش',        'roles' => ['super_admin', 'training_expert']],
        ['num' => 18, 'phase' => 5,  'route' => 'library',                'title' => 'کتابخانه دیجیتال و مخزن دانش',           'badge' => 'دانش',         'roles' => ['super_admin', 'training_expert', 'instructor', 'learner']],
        ['num' => 19, 'phase' => 5,  'route' => 'internships',            'title' => 'کارآموزی صنعتی و مهارت‌ورزی',            'badge' => 'کارآموزی',     'roles' => ['super_admin', 'training_expert', 'learner']],
        ['num' => 20, 'phase' => 5,  'route' => 'competitions',           'title' => 'مسابقات و رویدادهای مهارتی',             'badge' => 'مسابقات',      'roles' => ['super_admin', 'training_expert', 'learner']],

        ['num' => 21, 'phase' => 6,  'route' => 'hr',                     'title' => 'منابع انسانی و کارگزینی',                'badge' => 'کارگزینی',     'roles' => ['super_admin','finance_manager']],
        ['num' => 22, 'phase' => 6,  'route' => 'bpms',                   'title' => 'مدیریت فرایندها و گردش کار',             'badge' => 'فرایند',       'roles' => ['super_admin','training_expert','finance_manager','crm_manager']],
        ['num' => 23, 'phase' => 6,  'route' => 'bi',                     'title' => 'هوش تجاری، گزارش‌ساز و داشبوردساز',      'badge' => 'BI + OKR',     'roles' => ['super_admin','training_expert','finance_manager','crm_manager']],
        ['num' => 24, 'phase' => 6,  'route' => 'ai-governance',          'title' => 'تنظیمات درگاه هوش مصنوعی (AI)',          'badge' => 'AI Hub',       'roles' => ['super_admin']],

        ['num' => 26, 'phase' => 7,  'route' => 'virtual-class',          'title' => 'کلاس آنلاین و وبینار زنده',              'badge' => 'آنلاین',       'roles' => ['super_admin', 'training_expert', 'instructor', 'learner']],
        ['num' => 27, 'phase' => 7,  'route' => 'tax-moadian',            'title' => 'سامانه مؤدیان مالیاتی و سپیدار',         'badge' => 'مالیاتی',      'roles' => ['super_admin', 'finance_manager']],
        ['num' => 37, 'phase' => 7,  'route' => 'iran-messengers',        'title' => 'پیامک خدماتی و پیام‌رسان‌های بومی',       'badge' => 'اطلاع‌رسانی',  'roles' => ['super_admin', 'crm_manager']],


        ['num' => 30, 'phase' => 9,  'route' => 'iso-qa',                 'title' => 'تضمین کیفیت و ممیزی استاندارد',          'badge' => 'کیفیت',        'roles' => ['super_admin','training_expert']],
        ['num' => 32, 'phase' => 9,  'route' => 'job-board',              'title' => 'فرصت‌های شغلی دانش‌آموختگان',             'badge' => 'اشتغال',       'roles' => ['super_admin', 'crm_manager']],
        ['num' => 33, 'phase' => 9,  'route' => 'grants-mou',             'title' => 'حمایت‌های آموزشی و تفاهم‌نامه‌ها',       'badge' => 'تفاهم‌نامه',   'roles' => ['super_admin', 'training_expert', 'finance_manager', 'crm_manager']],
        ['num' => 36, 'phase' => 9,  'route' => 'alumni-club',            'title' => 'کانون دانش‌آموختگان و شبکه‌سازی',        'badge' => 'شبکه‌سازی',    'roles' => ['super_admin', 'training_expert', 'learner']],

        ['num' => 34, 'phase' => 10, 'route' => 'sso-pki',                'title' => 'احراز هویت یکپارچه و امضای دیجیتال',     'badge' => 'امنیت',        'roles' => ['super_admin']],
        ['num' => 35, 'phase' => 10, 'route' => 'proctoring-drm',         'title' => 'نظارت سلامت آزمون و حفاظت محتوا',        'badge' => 'حفاظت',        'roles' => ['super_admin', 'training_expert']],
        ['num' => 40, 'phase' => 6,  'route' => 'voice-assistant',        'title' => 'دستیار فرمان صوتی فارسی',                'badge' => 'صوتی',         'roles' => ['super_admin', 'training_expert', 'finance_manager', 'crm_manager', 'instructor', 'org_rep']],
        ['num' => 41, 'phase' => 6,  'route' => 'erp-intelligence',       'title' => 'مغز متفکر و پیش‌بینی هوشمند ERP',        'badge' => 'تحلیل AI',     'roles' => ['super_admin','training_expert','finance_manager','crm_manager']],
        ['num' => 42, 'phase' => 6,  'route' => 'digital-twin-bi',        'title' => 'اتاق وضعیت مدیریتی و مشاور قوانین',      'badge' => 'مدیریتی',      'roles' => ['super_admin','training_expert','finance_manager','crm_manager']],
        ['num' => 44, 'phase' => 8,  'route' => 'gamification-analytics', 'title' => 'تحلیل رفتار فراگیران و گیمیفیکیشن',      'badge' => 'گیمیفیکیشن',   'roles' => ['super_admin', 'training_expert']],
        ['num' => 45, 'phase' => 6,  'route' => 'role-workstations',      'title' => 'میزکار اختصاصی نقش سازمانی',             'badge' => 'میزکار',       'roles' => ['super_admin', 'learner']],
        ['num' => 46, 'phase' => 9,  'route' => 'career-hub',             'title' => 'کاریابی و رزومه دانش‌آموختگان',           'badge' => 'کاریابی',      'roles' => ['super_admin', 'crm_manager']],
        ['num' => 47, 'phase' => 10, 'route' => 'system-settings',        'title' => 'ظاهر، فونت و تنظیمات سیستم',             'badge' => 'تنظیمات',      'roles' => ['super_admin']],
        ['num' => 48, 'phase' => 10, 'route' => 'iam-access',             'title' => 'کاربران، نقش‌ها و سطوح دسترسی',           'badge' => 'دسترسی',       'roles' => ['super_admin']],
        ['num' => 49, 'phase' => 1,  'route' => 'academic-erp-core',      'title' => 'تقویم آموزشی، حضور و غیاب و کارنامه',    'badge' => 'امور آموزشی',  'roles' => ['super_admin','training_expert','instructor','org_rep','learner']],
        ['num' => 50, 'phase' => 3,  'route' => 'helpdesk-sla',           'title' => 'میز خدمت، تیکتینگ و پاسخگویی',          'badge' => 'میز خدمت',     'roles' => ['super_admin','training_expert','finance_manager','crm_manager','instructor','org_rep','learner']],
        ['num' => 51, 'phase' => 1,  'route' => 'microlearning',          'title' => 'میکرولرنینگ و جعبه لایتنر هوشمند',       'badge' => 'یادگیری خرد',  'roles' => ['super_admin', 'training_expert', 'learner']],
        ['num' => 52, 'phase' => 10, 'route' => 'help-center',            'title' => 'مرکز راهنما و مستندات جامع سیستم',       'badge' => 'راهنما',       'roles' => ['super_admin','training_expert','finance_manager','crm_manager','instructor','org_rep','learner']],
        ['num' => 53, 'phase' => 6,  'route' => 'office-automation',      'title' => 'اتوماسیون اداری و کارتابل مکاتبات',      'badge' => 'دبیرخانه',     'roles' => ['super_admin', 'training_expert', 'finance_manager', 'crm_manager', 'instructor']],
        ['num' => 54, 'phase' => 5,  'route' => 'workspace-tools',        'title' => 'آرشیو اسناد، فرم‌ساز و ممیزی امنیتی',    'badge' => 'اسناد',        'roles' => ['super_admin', 'finance_manager', 'crm_manager']],
        ['num' => 55, 'phase' => 10, 'route' => 'portal-builder',         'title' => 'مدیریت صفحات پورتال عمومی',              'badge' => 'پورتال‌ساز',   'roles' => ['super_admin', 'crm_manager']],
        ['num' => 56, 'phase' => 9,  'route' => 'marketing-intel',        'title' => 'استودیو کمپین، محتوا و قیف بازاریابی',       'badge' => 'کمپین و محتوا','roles' => ['super_admin','crm_manager','training_expert']],
        ['num' => 57, 'phase' => 9,  'route' => 'talent-psych',           'title' => 'تیپ‌شناسی شغلی و گذرنامه مهارت',          'badge' => 'استعداد',     'roles' => ['super_admin', 'training_expert', 'learner']],
        ['num' => 58, 'phase' => 10, 'route' => 'system-ops',             'title' => 'پشتیبان‌گیری دیتابیس و سلامت سرور',        'badge' => 'پشتیبان',     'roles' => ['super_admin']],
        ['num' => 59, 'phase' => 10, 'route' => 'public-home',            'title' => 'پورتال عمومی آموزشگاه آدان',              'badge' => 'وب‌سایت',      'roles' => ['super_admin', 'training_expert', 'crm_manager', 'learner']],
        ['num' => 60, 'phase' => 4,  'route' => 'verify',                 'title' => 'استعلام اصالت گواهی‌نامه (QR)',          'badge' => 'استعلام QR',   'roles' => ['super_admin', 'training_expert', 'crm_manager', 'learner']],
        ['num' => 39, 'phase' => 9,  'route' => 'market-radar',           'title' => 'ماژول بازاریابی و رادار بازار',            'badge' => 'بازاریابی',    'roles' => ['super_admin', 'training_expert', 'crm_manager']],
        ['num' => 61, 'phase' => 7,  'route' => 'national-interchange',   'title' => 'پیش‌نمایش تعامل‌پذیری سامانه‌های ملی',   'badge' => 'تعامل ملی',    'roles' => ['super_admin', 'finance_manager']],
    ],
];
