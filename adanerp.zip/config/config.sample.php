<?php
declare(strict_types=1);

/**
 * فایل نمونه تنظیمات سامانه آموزشگاه حسابداری آدان
 * سازگار با XAMPP (ویندوز/لینوکس) و cPanel (هاست اشتراکی و اختصاصی)
 */
return [
    'app' => [
        'name' => 'سامانه آموزشگاه حسابداری آدان',
        'short_name' => 'آدان | آموزش تخصصی حسابداری',
        'version' => '2.4.0-Enterprise',
        'timezone' => 'Asia/Tehran',
        'debug' => false,
    ],
    'db' => [
        'host' => '127.0.0.1',
        'port' => 3306,
        'database' => 'adanerpdb',    // در cPanel نام کامل مانند cpaneluser_adanerpdb وارد شود
        'username' => 'root',          // در XAMPP معمولاً root و در cPanel کاربر دیتابیس
        'password' => '',              // در XAMPP معمولاً خالی و در cPanel رمز کاربر دیتابیس
        'charset' => 'utf8mb4',
    ],
    'security' => [
        'session_name' => 'CHAMBER_EDU_SESS',
        'max_login_attempts' => 5,
        'lockout_minutes' => 15,
        'csrf_key' => 'chamber_csrf_token',
    ],
    'ai' => [
        'default_provider' => 'avalai',
        'avalai_base_url' => 'https://api.openai.com/v1',
        'avalai_api_key' => '', // کلید AI صرفاً سمت سرور نگهداری می‌شود
        'default_model' => 'gpt-4o-mini',
        'timeout_seconds' => 25,
    ],
];
