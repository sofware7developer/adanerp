<?php
declare(strict_types=1);

/**
 * ★ سیاست تفکیک نقش‌ها — نگارش ۲۶٫۹ («هر نقش، دقیقاً کار خودش»)
 *
 * این فایل تنها منبع حقیقت برای سه پرسش است:
 *   ۱) هر نقش چه ماژول‌هایی را در منو و در آدرس‌ها باز می‌کند  → allow / deny
 *   ۲) داخل یک ماژول مشترک، هر نقش کدام تب (زیرماژول) را می‌بیند → tabs
 *   ۳) هر فرمان/دکمۀ ثبت (action) مختص چه نقش‌هایی است          → actions
 *
 * اعمال: EnterpriseSettingsIamService::checkDynamicRouteAccess (منو + مسیر)
 *        Router::dispatch (تب + اکشن، سمت سرور، حتی با POST مستقیم)
 *
 * نکته: «allow» فقط روی مسیرهای منویی اثر می‌گذارد؛ مسیرهای کمکی (چاپ، استعلام، API)
 * با نقش‌های خودِ روتر کنترل می‌شوند و در «aux» مستند شده‌اند.
 */

return [
    'roles' => ['super_admin', 'training_expert', 'finance_manager', 'crm_manager', 'instructor', 'org_rep', 'learner'],

    // نقش‌هایی که منوی فشرده دارند (غایب = همان نقش‌های ماژول در phases.php)
    'allow' => [
        'instructor' => [
            'academic-erp-core', 'ai-studio', 'competency', 'dashboard', 'evaluation', 'exams', 'help-center', 'helpdesk-sla', 'library', 'lms', 'office-automation', 'tms', 'virtual-class', 'voice-assistant',
        ],
        'org_rep' => [
            'academic-erp-core', 'competency', 'contracts', 'dashboard', 'events', 'exams', 'finance', 'help-center', 'helpdesk-sla', 'portal', 'tms', 'voice-assistant',
        ],
        'finance_manager' => [
            'bi', 'bpms', 'contracts', 'dashboard', 'digital-twin-bi', 'erp-intelligence', 'evaluation', 'events', 'finance', 'grants-mou', 'help-center', 'helpdesk-sla', 'hr', 'instructors', 'national-interchange', 'office-automation', 'tax-moadian', 'tms', 'voice-assistant', 'workspace-tools',
        ],
        'crm_manager' => [
            'alumni-club', 'bi', 'bpms', 'career-hub', 'competitions', 'contracts', 'crm', 'dashboard', 'digital-twin-bi', 'erp-intelligence', 'events', 'grants-mou', 'help-center', 'helpdesk-sla', 'internships', 'iran-messengers', 'job-board', 'marketing-intel', 'market-radar', 'office-automation', 'portal-builder', 'public-home', 'tms', 'verify', 'voice-assistant', 'workspace-tools',
        ],
        // کارشناس آموزش: فهرست منفی (همۀ ماژول‌ها به‌جز این‌ها)
        'training_expert_exclude' => [
            'hr', 'tax-moadian', 'sso-pki', 'system-settings', 'system-ops', 'iam-access', 'ai-governance', 'portal-builder', 'iran-messengers', 'career-hub', 'job-board', 'workspace-tools', 'role-workstations',
        ],
    ],

    // صفحۀ «چرا این بخش را نمی‌بینم» و نقشۀ راهنمای کاربر از این متن‌ها استفاده می‌کنند
    'notes_routes' => ['learner' => ['dashboard', 'tms', 'lms', 'academic-erp-core', 'virtual-class', 'microlearning', 'exams', 'library', 'finance', 'helpdesk-sla', 'portal', 'competency']],

    // خط سرخ: برای این نقش‌ها هیچ‌وقت باز نمی‌شود (حتی اگر ماژول باز بماند)
    'deny' => [
        'ai-governance' => ['training_expert', 'finance_manager', 'crm_manager', 'instructor', 'org_rep', 'learner'],
        'system-settings' => ['training_expert', 'finance_manager', 'crm_manager', 'instructor', 'org_rep', 'learner'],
        'system-ops' => ['training_expert', 'finance_manager', 'crm_manager', 'instructor', 'org_rep', 'learner'],
        'iam-access' => ['training_expert', 'finance_manager', 'crm_manager', 'instructor', 'org_rep', 'learner'],
        'sso-pki' => ['training_expert', 'finance_manager', 'crm_manager', 'instructor', 'org_rep', 'learner'],
        'hr' => ['instructor', 'org_rep', 'learner', 'crm_manager'],
        'tax-moadian' => ['instructor', 'org_rep', 'learner', 'crm_manager'],
        'instructors' => ['instructor', 'org_rep', 'learner'],
        'career-hub' => ['instructor', 'org_rep', 'learner'],
        'job-board' => ['instructor', 'org_rep', 'learner'],
        'microlearning' => ['instructor', 'org_rep'],
        'proctoring-drm' => ['instructor', 'org_rep', 'learner'],
        'classrooms' => ['instructor', 'org_rep', 'learner'],
        'research' => ['instructor', 'org_rep', 'learner'],
        'gamification-analytics' => ['instructor', 'org_rep'],
        'role-workstations' => ['finance_manager', 'crm_manager', 'instructor', 'org_rep'],
        'digital-twin-bi' => ['instructor', 'org_rep', 'learner'],
        'erp-intelligence' => ['instructor', 'org_rep', 'learner'],
        'portal-builder' => ['instructor', 'org_rep', 'learner'],
        'workspace-tools' => ['instructor', 'org_rep', 'learner'],
        'office-automation' => ['org_rep', 'learner'],
        'talent-psych' => ['instructor', 'org_rep'],
        'iso-qa' => ['instructor', 'org_rep', 'learner'],
        'alumni-club' => ['instructor'],
        'voice-assistant' => ['learner'],
    ],

    // تب‌های مجاز هر نقش در ماژول‌های مشترک (زیرماژول‌ها)
    'tabs' => [
        'academic-erp-core' => [
            'instructor' => ['gradebook', 'terms'],
            'org_rep' => ['gradebook', 'terms'],
            'learner' => ['gradebook', 'terms'],
        ],
        'helpdesk-sla' => [
            'instructor' => ['tickets', 'requests'],
            'org_rep' => ['tickets', 'requests'],
            'learner' => ['tickets'],
        ],
        'help-center' => [
            'instructor' => ['catalog', 'flows'],
            'org_rep' => ['catalog', 'flows'],
            'learner' => ['catalog'],
        ],
        'microlearning' => [
            'org_rep' => ['leitner', 'mycards'],
            'learner' => ['leitner', 'mycards', 'capsules'],
        ],
        'bi' => [
            'finance_manager' => ['catalog', 'dashboards'],
            'crm_manager' => ['catalog', 'dashboards'],
        ],
    ],

    // اکشن‌های حساس: '*' یعنی همۀ اکشن‌های آن ماژول فقط برای این نقش‌ها
    'actions' => [
        'tms' => [
            'create_course' => ['super_admin', 'training_expert'],
            'create_run' => ['super_admin', 'training_expert'],
            'workflow_transition' => ['super_admin', 'training_expert'],
            'kanban_move' => ['super_admin', 'training_expert'],
            'save_pricing_scenario' => ['super_admin', 'training_expert'],
            'save_learning_path' => ['super_admin', 'training_expert'],
            'save_exec_report' => ['super_admin', 'training_expert'],
            'capacity' => ['super_admin', 'training_expert'],
            'create_session' => ['super_admin', 'training_expert', 'instructor'],
            'record_attendance' => ['super_admin', 'training_expert', 'instructor'],
            'ai_build_full_course' => ['super_admin', 'training_expert', 'instructor'],
            'bulk_group_enroll' => ['super_admin', 'training_expert', 'org_rep'],
            'cancel_enrollment' => ['super_admin', 'training_expert', 'org_rep', 'learner'],
        ],
        'competency' => [
            'review_proposal' => ['super_admin', 'training_expert'],
            'run_ai_gap_summary' => ['super_admin', 'training_expert'],
            'propose_course' => ['super_admin', 'training_expert', 'finance_manager', 'crm_manager', 'instructor', 'org_rep', 'learner'],
            'add_assessment' => ['super_admin', 'training_expert', 'finance_manager', 'crm_manager', 'instructor', 'org_rep', 'learner'],
        ],
        'exams' => [
            'create_exam' => ['super_admin', 'training_expert'],
            'toggle_exam' => ['super_admin', 'training_expert'],
            'add_question' => ['super_admin', 'training_expert', 'instructor'],
            'clone_standard_to_bank' => ['super_admin', 'training_expert', 'instructor'],
            'batch_issue_course' => ['super_admin', 'training_expert'],
            'issue_certificate' => ['super_admin', 'training_expert'],
            'revoke_certificate' => ['super_admin'],
            'grade_descriptive' => ['super_admin', 'training_expert', 'instructor'],
            'ai_auto_grade_submission' => ['super_admin', 'training_expert', 'instructor'],
            'run_standard_test' => ['super_admin', 'training_expert', 'finance_manager', 'crm_manager', 'instructor', 'org_rep', 'learner'],
            'submit_exam' => ['super_admin', 'training_expert', 'finance_manager', 'crm_manager', 'instructor', 'org_rep', 'learner'],
        ],
        'lms' => [
            'upload_scorm' => ['super_admin', 'training_expert', 'instructor'],
            'ai_generate_lesson_pack' => ['super_admin', 'training_expert', 'instructor'],
            'grade_submission' => ['super_admin', 'training_expert', 'instructor'],
            'ai_auto_grade_submission' => ['super_admin', 'training_expert', 'instructor'],
            'complete_lesson' => ['super_admin', 'training_expert', 'finance_manager', 'crm_manager', 'instructor', 'org_rep', 'learner'],
            'submit_assignment' => ['super_admin', 'training_expert', 'finance_manager', 'crm_manager', 'instructor', 'org_rep', 'learner'],
            'save_note' => ['super_admin', 'training_expert', 'finance_manager', 'crm_manager', 'instructor', 'org_rep', 'learner'],
            'post_discussion' => ['super_admin', 'training_expert', 'finance_manager', 'crm_manager', 'instructor', 'org_rep', 'learner'],
        ],
        'finance' => [
            'create_invoice' => ['super_admin', 'training_expert', 'finance_manager'],
            'add_ledger' => ['super_admin', 'finance_manager'],
            'create_double_voucher' => ['super_admin', 'finance_manager'],
            'reconcile_bank_csv' => ['super_admin', 'finance_manager'],
            'register_sayad_cheque' => ['super_admin', 'finance_manager'],
            'clear_sayad_cheque' => ['super_admin', 'finance_manager'],
            'settle_installment' => ['super_admin', 'finance_manager'],
            'simulate_gateway_pay' => ['super_admin', 'finance_manager', 'org_rep', 'learner'],
            'request_refund' => ['super_admin', 'finance_manager', 'org_rep', 'learner'],
        ],
        'internships' => [
            'submit_milestone' => ['super_admin', 'training_expert', 'learner'],
            'save_rubric' => ['super_admin', 'training_expert'],
            'calc_pooyesh_tax' => ['super_admin', 'training_expert'],
        ],
        'competitions' => [
            'run_bizsim' => ['super_admin', 'training_expert', 'learner'],
            'score_team' => ['super_admin', 'training_expert'],
        ],
        'hr' => [
            'create_hr_record' => ['super_admin', 'finance_manager'],
            'approve_hr' => ['super_admin'],
        ],
        'bpms' => [
            'run_full_pipeline' => ['super_admin'],
            'start_workflow' => ['super_admin', 'training_expert', 'finance_manager', 'crm_manager'],
            'add_routing_rule' => ['super_admin', 'training_expert', 'finance_manager'],
            'transition_workflow' => ['super_admin', 'training_expert', 'finance_manager', 'crm_manager'],
            'bypass_bottleneck' => ['super_admin', 'training_expert'],
        ],
        'instructors' => [
            '*' => ['super_admin', 'training_expert', 'finance_manager'],
        ],
        'office-automation' => [
            '*' => ['super_admin', 'training_expert', 'finance_manager', 'crm_manager', 'instructor'],
        ],
        'workspace-tools' => [
            '*' => ['super_admin', 'training_expert', 'finance_manager', 'crm_manager'],
        ],
        'system-settings' => [
            '*' => ['super_admin'],
        ],
        'iam-access' => [
            '*' => ['super_admin'],
        ],
        'system-ops' => [
            '*' => ['super_admin'],
        ],
        'ai-governance' => [
            '*' => ['super_admin'],
        ],
        'sso-pki' => [
            '*' => ['super_admin'],
        ],
    ],

    // مسیرهای کمکی (چاپ/استعلام) — مستند سیاست؛ اعمالش با نقش‌های روتر است
    'aux' => [
        'transcript-print' => ['super_admin', 'training_expert', 'instructor', 'org_rep', 'learner'],
        'class-card-print' => ['super_admin', 'training_expert', 'finance_manager', 'crm_manager', 'instructor', 'org_rep', 'learner'],
        'event-badge-print' => ['super_admin', 'training_expert', 'finance_manager', 'crm_manager'],
        'instructor-contract-print' => ['super_admin', 'training_expert', 'finance_manager', 'instructor'],
        'contract-print' => ['super_admin', 'training_expert', 'finance_manager', 'crm_manager', 'org_rep'],
        'invoice-print' => ['super_admin', 'training_expert', 'finance_manager', 'org_rep', 'learner'],
        'letter-print' => ['super_admin', 'training_expert', 'finance_manager', 'crm_manager', 'instructor'],
        'board-report-print' => ['super_admin', 'training_expert', 'finance_manager', 'crm_manager'],
        'bi-report-print' => ['super_admin', 'training_expert', 'finance_manager', 'crm_manager'],
        'cv-print' => ['super_admin', 'training_expert', 'finance_manager', 'crm_manager', 'instructor', 'org_rep'],
        'help-manual-print' => [], // عمومی
    ],

    // توضیح سیاست، برای صفحۀ ۴۰۳ و راهنمای کاربر
    'notes' => [
        'instructor' => 'مدرس روی تدریس خودش تمرکز می‌کند: کلاس‌ها، درس‌ها، آزمون و تصحیح، حضور و غیاب، ارزیابی تدریس، کتابخانه، استودیوی محتوا و پشتیبانی.',
        'org_rep' => 'نمایندۀ سازمان، امور کارکنان خودش را می‌بیند: ثبت‌نام گروهی، سهمیه، فاکتور سازمانی، قرارداد، کارنامه و گواهی پرسنل.',
        'finance_manager' => 'امور مالی درگیر چیدمان دوره، آزمون و LMS نمی‌شود؛ فاکتور، دفترکل، مؤدیان، یارانه و تراز.',
        'crm_manager' => 'بازاریابی روی اعضا، کمپین، رویداد، قرارداد سازمانی و کاریابی تمرکز دارد؛ نه تصحیح آزمون و نه تنظیمات سیستم.',
        'training_expert' => 'کارشناس آموزش مالیات، مؤدیان، زیرساخت پیامک/پورتال و کاریابی (ATS) را ندارد؛ آن‌ها مال امور مالی، بازاریابی و منابع انسانی است.',
    ],
];
