<?php $isLearnerVC = \App\Core\Auth::role() === 'learner'; ?>
<div class="hero-banner">
    <div>
        <span class="badge badge-warning">اتصال کلاس آنلاین پیکربندی نشده</span>
        <h1>یکپارچه‌سازی کلاس آنلاین زنده (اسکای‌روم، ادوبی‌کانکت و BigBlueButton)</h1>
        <p>اتاق‌های این بخش فعلاً رکورد داخلی هستند؛ لینک ورود، حضور آنلاین و ضبط تا اتصال API واقعی در دسترس نیست.</p>
    </div>
</div>

<div class="alert alert-info">
    ℹ️ <strong>حالت فعلی: نمایشی/محلی.</strong> این نسخه به سرویس زنده‌ای متصل نیست و آمار حضور یا لینک جلسه تولید نمی‌کند.
</div>

<div class="grid grid-sidebar">
<?php if (!$isLearnerVC): ?>
    <div class="card">
        <div class="card-header"><div class="card-title">اتاق‌های ثبت‌شدهٔ محلی (بدون کلاس زنده یا همگام‌سازی حضور)</div></div>
        <?php foreach ($rooms as $r): ?>
            <div style="border:1px solid var(--border);border-radius:14px;padding:14px;margin-bottom:12px">
                <div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:8px">
                    <div>
                        <span class="badge badge-info"><?= e($r['provider']) ?></span>
                        <strong style="margin-right:6px"><?= e($r['room_title']) ?></strong>
                    </div>
                    <span class="badge badge-warning">اتصال برقرار نیست</span>
                </div>
                <div class="muted" style="font-size:12px;margin:8px 0">
                    شناسه داخلی: <code><?= e($r['sso_slug']) ?></code> | لینک ورود/ضبط: موجود نیست
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php if (!$isLearnerVC): ?>
    <div class="card">
        <div class="card-header"><div class="card-title">➕ ایجاد اتاق کلاس آنلاین جدید</div></div>
        <form method="post" action="<?= e(url('virtual-class')) ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="create_room">
            <div class="form-group">
                <label>پلتفرم کلاس مجازی:</label>
                <select name="provider">
                    <option value="Skyroom">اسکای‌روم (Skyroom API)</option>
                    <option value="BigBlueButton">بیگ‌بلوباتن اختصاصی (BBB)</option>
                    <option value="AdobeConnect">ادوبی‌کانکت سازمانی</option>
                </select>
            </div>
            <div class="form-group">
                <label>اجرای دوره مرتبط در TMS:</label>
                <select name="run_id">
                    <?php foreach ($runs as $rn): ?>
                        <option value="<?= (int)$rn['id'] ?>"><?= e($rn['run_code']) ?> (<?= e($rn['term_label']) ?>)</option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>عنوان اتاق وبینار:</label>
                <input type="text" name="room_title" value="کارگاه آنلاین حسابداری مقدماتی" required>
            </div>
            <button type="submit" class="btn btn-primary" style="width:100%">ثبت داخلی اتاق (بدون ساخت لینک زنده)</button>
        </form>
    </div>
<?php endif; ?>
</div>
