<div class="hero-banner">
    <div>
        <span class="badge badge-warning">پیش‌نمایش محلی؛ هیچ سامانهٔ ملی متصل نیست</span>
        <h1>آماده‌سازی اتصال به سامانه‌های ملی</h1>
        <p>این بخش فقط قالب و رقم کنترل نمونه‌ها را در همین سامانه بررسی می‌کند. هویت، وضعیت ثبتی شرکت، تعرفه یا پاسخ گمرکی استعلام نمی‌شود؛ اطلاعات واقعی اشخاص را وارد نکنید.</p>
    </div>
</div>

<div class="alert alert-info">
    <div>
        <strong>وضعیت اتصال:</strong> دسترسی یا کلید GSB/NIX تنظیم نشده است. شناسه‌های واردشده ذخیره نمی‌شوند و هیچ درخواست شبکه‌ای به NTSW، SSAA یا EPL ارسال نمی‌شود.
    </div>
</div>

<div class="card" style="margin-bottom:18px;border:1.5px solid rgba(15,118,110,0.35)">
    <div class="card-header">
        <div>
            <div class="card-title">کنترل محلی قالب شناسهٔ نمونه</div>
            <div class="muted" style="font-size:12px">این کنترل، هویت یا اعتبار رسمی شناسه را تأیید نمی‌کند.</div>
        </div>
        <span class="badge badge-warning">بدون استعلام بیرونی</span>
    </div>

    <form method="post" action="<?= e(url('national-interchange')) ?>" class="grid grid-3" style="gap:12px;align-items:end;margin-bottom:16px">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="preview_identifier">
        <div>
            <label>قالب موردنظر برای بررسی محلی:</label>
            <select name="system_type">
                <option value="NTSW">قالب ۱۰ رقمی با رقم کنترل</option>
                <option value="SSAA">قالب ۱۱ رقمی با رقم کنترل</option>
                <option value="EPL">قالب کد ۸ رقمی</option>
            </select>
        </div>
        <div>
            <label>شناسهٔ ساختگی برای آزمون (اطلاعات واقعی وارد نکنید):</label>
            <input type="text" name="identifier" value="" maxlength="11" dir="ltr" required>
        </div>
        <div>
            <button type="submit" class="btn btn-primary" style="width:100%">بررسی محلی بدون استعلام</button>
        </div>
    </form>

    <div class="table-wrap">
        <table>
            <thead><tr><th>شناسهٔ پیش‌نمایش محلی</th><th>سامانهٔ موردنظر (متصل نیست)</th><th>شناسهٔ ورودی</th><th>نتیجهٔ قالب محلی</th><th>وضعیت اتصال</th><th>نتیجهٔ محلی</th></tr></thead>
            <tbody>
            <?php foreach ($inquiries as $inq): ?>
                <?php $legacyInquiry = str_starts_with((string)$inq['gateway_execution_mode'], 'رکورد قدیمی پاک‌سازی'); ?>
                <tr>
                    <td><code><?= e($inq['trace_code']) ?></code></td>
                    <td><strong><?= e($inq['target_system']) ?></strong></td>
                    <td dir="ltr"><code><?= e($inq['identifier_queried']) ?></code></td>
                    <td>
                        <?php if ($legacyInquiry): ?>
                            <span class="badge badge-warning">نتیجهٔ قدیمی پاک‌سازی شده</span>
                        <?php elseif ((int)$inq['math_checksum_valid'] === 1): ?>
                            <span class="badge badge-success">قالب/رقم کنترل محلی معتبر</span>
                        <?php else: ?>
                            <span class="badge badge-danger">قالب نمونه نامعتبر</span>
                        <?php endif; ?>
                    </td>
                    <td><span class="badge badge-info"><?= e($inq['gateway_execution_mode']) ?></span></td>
                    <td style="font-size:12px;max-width:340px"><?= e($inq['response_summary']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="card" style="border:1.5px solid rgba(201,146,39,0.4)">
    <div class="card-header">
        <div>
            <div class="card-title">چکیده‌های محلی گواهی‌ها</div>
            <div class="muted" style="font-size:12px">این چکیده‌ها امضای مستقل ندارند و دستکاری پایگاه‌داده را به‌تنهایی آشکار نمی‌کنند.</div>
        </div>
        <span class="badge badge-warning">استاندارد W3C تأیید نشده</span>
    </div>
    <div class="table-wrap">
        <table>
            <thead><tr><th>شمارهٔ محلی</th><th>کد گواهی / نشان</th><th>نام ثبت‌شده</th><th>چکیدهٔ قبلی</th><th>چکیدهٔ SHA-256 محلی</th><th>وضعیت</th></tr></thead>
            <tbody>
            <?php foreach ($blocks as $b): ?>
                <tr>
                    <td><strong>#<?= fa($b['block_height']) ?></strong></td>
                    <td><code><?= e($b['cert_or_badge_code']) ?></code></td>
                    <td><?= e($b['holder_fullname']) ?></td>
                    <td dir="ltr"><code><?= e(substr($b['prev_block_hash'], 0, 16)) ?>...</code></td>
                    <td dir="ltr"><code><?= e(substr($b['block_sha256_hash'], 0, 22)) ?>...</code></td>
                    <td><span class="badge badge-warning">محلی؛ امضا نشده</span></td>
                </tr>
            <?php endforeach; ?>
            <?php if (empty($blocks)): ?>
                <tr><td colspan="6" class="muted">چکیدهٔ محلی ثبت نشده است.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
