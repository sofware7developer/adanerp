<div class="hero-banner">
    <div>
        <span class="badge badge-warning">اتصال ارسال پیام هنوز فعال نیست</span>
        <h1>درگاه پیامک بومی (کاوه‌نگار / ملی‌پیامک) و بازوهای پیام‌رسان «بله» و «ایتا»</h1>
        <p>در نسخه فعلی پیام‌ها فقط ثبت محلی می‌شوند؛ کلید API ذخیره‌شده به‌تنهایی به معنی ارسال یا تحویل پیام نیست.</p>
    </div>
</div>

<div class="grid grid-sidebar">
    <div class="card">
        <div class="card-header"><div class="card-title">📨 لاگ ارسال پیام‌های چندکاناله (SMS + بله + ایتا)</div></div>
        <div class="table-wrap">
            <table>
                <thead><tr><th>کانال ارتباطی</th><th>گروه مخاطبان</th><th>متن پیام سازمانی</th><th>تعداد</th><th>وضعیت</th></tr></thead>
                <tbody>
                <?php foreach ($dispatches as $d): ?>
                    <tr>
                        <td><span class="badge badge-info"><?= e($d['channel']) ?></span></td>
                        <td><strong><?= e($d['recipient_group']) ?></strong></td>
                        <td><?= e($d['message_text']) ?></td>
                        <td><?= fa($d['sent_count']) ?> نفر</td>
                        <td><span class="badge badge-warning"><?= e($d['delivery_mode']) ?></span></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div>
        <div class="card">
            <div class="card-header"><div class="card-title">ثبت محلی پیام (ارسال نمی‌شود)</div></div>
            <form method="post" action="<?= e(url('iran-messengers')) ?>">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="dispatch_message">
                <div class="form-group">
                    <label>انتخاب کانال بومی:</label>
                    <select name="channel">
                        <option value="کاوه‌نگار SMS">درگاه پیامک کاوه‌نگار</option>
                        <option value="ملی‌پیامک SMS">درگاه ملی‌پیامک / فراز</option>
                        <option value="بازوی بله (Bale)">بازوی سازمانی پیام‌رسان بله</option>
                        <option value="بازوی ایتا (Eitaa)">کانال/بازوی پیام‌رسان ایتا</option>
                    </select>
                </div>
                <div class="form-group"><input type="text" name="recipient_group" value="شرکت‌کنندگان کارگاه صادرات" required></div>
                <div class="form-group"><textarea name="message_text" rows="2" required>یادآوری شروع کلاس فردا ساعت ۱۴ در تالار مرکزی مؤسسه آموزشی آدان.</textarea></div>
                <button type="submit" class="btn btn-outline" style="width:100%">ثبت پیام بدون ارسال</button>
            </form>
        </div>

        <div class="card">
            <div class="card-header"><div class="card-title">🔑 ذخیره کلید برای اتصال آتی (در ارسال فعلی استفاده نمی‌شود)</div></div>
            <form method="post" action="<?= e(url('iran-messengers')) ?>">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="save_credentials">
                <div class="form-group"><label>کلید API کاوه‌نگار / ملی‌پیامک (<?= $hasSmsKey ? 'ثبت شده' : 'خالی' ?>):</label><input type="password" name="kavenegar_api_key" placeholder="API Key..."></div>
                <div class="form-group"><label>توکن بازوی بله (ble.ir):</label><input type="password" name="bale_bot_token" placeholder="Bale Bot Token..."></div>
                <div class="form-group"><label>توکن بازوی ایتا (eitaa.com):</label><input type="password" name="eitaa_bot_token" placeholder="Eitaa Token..."></div>
                <button type="submit" class="btn btn-gold btn-sm" style="width:100%">ذخیره امن سمت سرور</button>
            </form>
        </div>
    </div>
</div>
