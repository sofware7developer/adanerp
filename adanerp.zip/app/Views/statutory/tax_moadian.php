<div class="hero-banner">
    <div>
        <span class="badge badge-warning">پیش‌نویس محلی؛ OCR، مشاوره مالیاتی و اتصال نرم‌افزار فعال نیست</span>
        <h1>پیش‌نویس اطلاعات مالیاتی و خروجی ساده دفترکل</h1>
        <p>این بخش اطلاعات صورتحساب را برای بازبینی داخلی نگه می‌دارد. هیچ شناسه مالیاتی صادر یا داده‌ای به سامانه مؤدیان و نرم‌افزار حسابداری ارسال نمی‌شود؛ خروجی CSV نیز قالب رسمی سپیدار/همکاران نیست.</p>
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
        <a class="btn btn-gold" href="<?= e(url('tax-moadian', ['export_accounting' => 'sepidar'])) ?>">دریافت CSV ساده از ردیف‌های دفترکل</a>
    </div>
</div>

<!-- Rule-based local text preview; no OCR or accounting posting is performed. -->
<div class="grid grid-2" style="margin-bottom:18px">
    <div class="card" style="border:1.5px solid rgba(15,118,110,0.35)">
        <div class="card-header">
            <div class="card-title">پیش‌نمایش قاعده‌محور متن رسید/چک (بدون OCR)</div>
            <span class="badge badge-warning">بدون ثبت سند حسابداری</span>
        </div>
        <form method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="scan_receipt_ocr">
            <div class="form-group">
                <label>متن نمونه برای استخراج آزمایشی الگوها (اطلاعات حساس وارد نکنید):</label>
                <textarea id="ocrRawInput" name="raw_receipt_text" rows="3" required placeholder="مثال: مبلغ 10000000 ریال؛ این بخش الگوهای سادهٔ متن را بررسی می‌کند."></textarea>
            </div>
            <button type="submit" class="btn btn-primary" style="width:100%">ساخت پیش‌نمایش محلی (بدون ثبت مالی)</button>
        </form>
    </div>

    <div class="card">
        <div class="card-header">
            <div class="card-title">پیش‌نویس اطلاعات صورتحساب برای سامانه مؤدیان</div>
            <span class="badge badge-warning">اتصال و ارسال فعال نیست</span>
        </div>
        <form method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="generate_moadian_packet">
            <div class="form-group">
                <label>انتخاب صورت‌حساب صادرشده:</label>
                <select name="invoice_id">
                    <?php foreach (($invoices ?? []) as $inv): ?>
                        <option value="<?= (int)$inv['id'] ?>"><?= e($inv['invoice_number']) ?> — مبلغ: <?= rial($inv['total_rial']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>قالب نرم‌افزار حسابداری مقصد:</label>
                <select name="accounting_target">
                    <option value="سپیدار همکاران">سپیدار</option>
                    <option value="همکاران سیستم">همکاران سیستم (نسخه سازمانی)</option>
                    <option value="هلو">هلو</option>
                    <option value="محک">محک</option>
                </select>
            </div>
            <button type="submit" class="btn btn-gold" style="width:100%">ذخیره پیش‌نویس محلی (بدون ارسال مالیاتی)</button>
        </form>
    </div>
</div>

<!-- OCR SCANS LOG -->
<div class="card" style="margin-bottom:18px">
    <div class="card-header"><div class="card-title">پیش‌نمایش‌های محلی استخراج الگو از متن (بدون ثبت در دفترکل)</div></div>
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>کد اسکن</th>
                    <th>نوع مدرک</th>
                    <th>شناسه صیاد / پیگیری</th>
                    <th>مبلغ تشخیص‌داده‌شده</th>
                    <th>اعتبارسنجی قالب شبا</th>
                    <th>وضعیت مالیاتی/ارسال</th>
                    <th>سند حسابداری</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach (($ocrScans ?? []) as $sc): ?>
                <tr>
                    <td><code><?= e($sc['scan_code']) ?></code></td>
                    <td><strong><?= e($sc['doc_type']) ?></strong></td>
                    <td><code><?= e($sc['detected_sayad_or_ref'] ?: 'استخراج نشده') ?></code></td>
                    <td><strong><?= !empty($sc['detected_amount_rial']) ? rial($sc['detected_amount_rial']) : 'استخراج نشده' ?></strong></td>
                    <td>
                        <?php if (empty($sc['detected_iban'])): ?>
                            <span class="badge badge-warning">شبا وارد نشده</span>
                        <?php elseif ((int)$sc['checksum_verified'] === 1): ?>
                            <span class="badge badge-success">قالب Mod-97 معتبر</span>
                        <?php else: ?>
                            <span class="badge badge-warning">نامعتبر؛ بازبینی شود</span>
                        <?php endif; ?>
                    </td>
                    <td style="font-size:12px"><?= e($sc['moadian_vat_status']) ?></td>
                    <td><span class="badge badge-warning"><?= empty($sc['booked_voucher_no']) ? 'ثبت نشده' : 'کد قدیمی؛ بازبینی لازم' ?></span></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- MOADIAN PACKETS -->
<div class="card">
    <div class="card-header"><div class="card-title">پیش‌نویس‌های محلی (ارسال‌نشده به سامانه مؤدیان)</div></div>
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>شماره فاکتور</th>
                    <th>مبلغ کل</th>
                    <th>شناسه مالیاتی</th>
                    <th>نرم‌افزار حسابداری مقصد</th>
                    <th>اثر انگشت داخلی</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach (($packets ?? []) as $pk): ?>
                <tr>
                    <td><strong><?= e($pk['invoice_number']) ?></strong></td>
                    <td><?= rial($pk['total_rial']) ?></td>
                    <td><code><?= e($pk['tax_unique_id_22'] ?: 'صادر نشده') ?></code><div class="muted"><?= e($pk['submission_status']) ?></div></td>
                    <td><span class="badge badge-purple"><?= e($pk['accounting_target']) ?></span></td>
                    <td style="font-family:monospace;font-size:11px"><?= e(substr((string)$pk['payload_sha256'], 0, 24)) ?>...</td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
