<?php use App\Core\Auth;
$isLearnerComp = Auth::role() === 'learner'; // v26.6 — نمای ساده و خودکار فراگیر ?>
<div class="hero-banner">
    <div>
        <span class="badge badge-gold">نیازسنجی و معماری شایستگی</span>
        <h1>نیازسنجی آموزشی (TNA)، ماتریس شایستگی و تحلیل شکاف هوشمند</h1>
        <p>بانک شایستگی‌های تخصصی بازرگانی و مدیریتی، ماتریس سطح فعلی و هدف (۱ تا ۵)، محاسبه وزنی شکاف مهارتی، پیشنهاد دوره توسط اعضا و تحلیل کمکی AI.</p>
    </div>
    <?php if ($isLearnerComp): ?>
        <span class="badge badge-info" style="align-self:center">نمای شخصی ماتریس شایستگی شما</span>
    <?php else: ?>
        <form method="post" action="<?= e(url('competency')) ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="run_ai_gap_summary">
            <button type="submit" class="btn btn-gold">🤖 اجرای تحلیل هوشمند شکاف مهارتی (AI)</button>
        </form>
    <?php endif; ?>
</div>

<?php if ($aiReport): ?>
    <div class="card" style="border-color:var(--primary)">
        <div class="card-header">
            <div class="card-title">🤖 خروجی مشاور هوش مصنوعی نیازسنجی مؤسسه آموزشی آدان</div>
            <span class="badge badge-purple">مدل: <?= e($aiReport['model']) ?></span>
        </div>
        <div class="pre-box"><?= e($aiReport['content']) ?></div>
    </div>
<?php endif; ?>

<div class="card">
    <div class="card-header">
        <div class="card-title">🕸️ نمودار رادار ۵ محوره شکاف شایستگی<?= $isLearnerComp ? ' من' : ' بنگاه‌های عضو' ?> (سطح فعلی در برابر سطح هدف)</div>
        <?php if (!$isLearnerComp): ?>
            <form method="get" action="<?= e(url('competency')) ?>" style="display:flex;gap:6px;align-items:center">
                <select name="radar_user" onchange="this.form.submit()" style="width:210px;padding:5px">
                    <option value="0">— میانگین کل بنگاه‌های عضو —</option>
                    <?php foreach ($users as $usr): ?>
                        <option value="<?= (int)$usr['id'] ?>" <?= ($radarUser ?? 0) === (int)$usr['id'] ? 'selected' : '' ?>>فیلتر فردی: <?= e($usr['full_name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </form>
        <?php else: ?>
            <span class="badge badge-success">نمای شخصی: فقط شایستگی‌های خود شما</span>
        <?php endif; ?>
    </div>
    <div class="grid grid-2" style="align-items:center;margin-bottom:0">
        <svg viewBox="0 0 320 300" style="width:100%;max-width:340px;margin:0 auto;display:block" role="img" aria-label="نمودار رادار شایستگی">
            <circle cx="160" cy="150" r="105" fill="none" stroke="#cbd5e1" stroke-dasharray="3 3"/>
            <circle cx="160" cy="150" r="65" fill="none" stroke="#e2e8f0" stroke-dasharray="3 3"/>
            <circle cx="160" cy="150" r="30" fill="none" stroke="#e2e8f0"/>
            <?php foreach ($radar['axes'] as $ax): ?>
                <line x1="160" y1="150" x2="<?= $ax['x'] ?>" y2="<?= $ax['y'] ?>" stroke="#cbd5e1" stroke-width="1"/>
                <text x="<?= $ax['lx'] ?>" y="<?= $ax['ly'] ?>" text-anchor="middle" font-size="10.5" font-weight="bold" fill="#334155"><?= e($ax['code']) ?></text>
            <?php endforeach; ?>
            <polygon points="<?= e($radar['target_points']) ?>" fill="rgba(201,146,39,0.18)" stroke="#c99227" stroke-width="2.5"/>
            <polygon points="<?= e($radar['current_points']) ?>" fill="rgba(15,118,110,0.34)" stroke="#0f766e" stroke-width="2.5"/>
        </svg>
        <div>
            <p style="margin-bottom:10px">
                چندضلعی <strong style="color:#c99227">طلایی</strong> بیانگر <strong>سطح هدف استاندارد مؤسسه آموزشی آدان</strong> و چندضلعی <strong style="color:#0f766e">فیروزه‌ای</strong> بیانگر <strong><?= $isLearnerComp ? 'سطح فعلی خودِ شما' : 'میانگین سطح فعلی کارشناسان بنگاه‌های عضو' ?></strong> است:
            </p>
            <?php foreach ($radar['axes'] as $ax): ?>
                <div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid var(--border);font-size:12.5px">
                    <strong><?= e($ax['code']) ?></strong>
                    <span>فعلی: <strong><?= fa($ax['cur']) ?></strong> از هدف: <strong><?= fa($ax['tar']) ?></strong></span>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<div class="grid grid-sidebar">
    <div class="card">
        <div class="card-header">
            <div class="card-title">📊 ماتریس سطح فعلی در برابر سطح هدف و تحلیل شکاف (Gap Matrix)</div>
        </div>
        <div class="table-wrap">
            <table>
                <thead>
                <tr>
                    <th>شاغل / سمت هدف</th>
                    <th>شایستگی تخصصی</th>
                    <th>فعلی ← هدف</th>
                    <th>امتیاز وزنی شکاف</th>
                    <th>دوره پیشنهادی متناظر در TMS</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($matrix as $m): ?>
                    <?php
                    $gap = max(0, (int)$m['target_level'] - (int)$m['current_level']);
                    $weightedGap = $gap * (int)$m['weight'];
                    ?>
                    <tr>
                        <td>
                            <strong><?= e($m['full_name']) ?></strong>
                            <div class="muted" style="font-size:11.5px"><?= e($m['target_role_title']) ?></div>
                        </td>
                        <td>
                            <?= e($m['comp_title']) ?>
                            <div class="badge badge-info"><?= e($m['domain']) ?></div>
                        </td>
                        <td>
                            <span class="badge badge-warning">فعلی: <?= fa($m['current_level']) ?></span>
                            ←
                            <span class="badge badge-success">هدف: <?= fa($m['target_level']) ?></span>
                        </td>
                        <td>
                            <strong style="color:<?= $gap >= 2 ? 'var(--danger)' : 'var(--primary)' ?>">
                                شکاف <?= fa($gap) ?> سطحی (وزن: <?= fa($weightedGap) ?>)
                            </strong>
                        </td>
                        <td>
                            <?php if (!empty($m['rec_course'])): ?>
                                <a href="<?= e(url('tms')) ?>" class="badge badge-gold" style="text-decoration:none">🎯 ثبت‌نام مستقیم: <?= e($m['rec_course']) ?></a>
                            <?php else: ?>—<?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card">
        <div class="card-header"><div class="card-title">➕ ثبت ارزیابی جدید در ماتریس شایستگی</div></div>
        <form method="post" action="<?= e(url('competency')) ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="add_assessment">
            <div class="form-group">
                <label>کاربر / کارشناس مورد ارزیابی:</label>
                <?php if ($isLearnerComp): ?>
                    <input type="text" value="<?= e(Auth::user()['full_name'] ?? 'فراگیر') ?> — ارزیابی خودسنجی" disabled>
                    <div class="muted" style="font-size:11.5px;margin-top:4px">در نقش فراگیر، ارزیابی تنها برای پرونده مهارتی خودتان ثبت می‌شود (ارزیابی دیگران مخصوص مدیران و مدرسان است).</div>
                <?php else: ?>
                    <select name="user_id">
                        <?php foreach ($users as $u): ?>
                            <option value="<?= (int)$u['id'] ?>"><?= e($u['full_name']) ?> (<?= e($u['job_title']) ?>)</option>
                        <?php endforeach; ?>
                    </select>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label>انتخاب شایستگی از بانک استاندارد:</label>
                <select name="competency_id">
                    <?php foreach ($competencies as $cp): ?>
                        <option value="<?= (int)$cp['id'] ?>">[<?= e($cp['code']) ?>] <?= e($cp['title']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>سمت هدف:</label>
                <input type="text" name="target_role_title" value="مدیر توسعه صادرات">
            </div>
            <div class="form-grid">
                <div class="form-group">
                    <label>سطح فعلی (۱ تا ۵):</label>
                    <input type="number" name="current_level" value="2" min="1" max="5">
                </div>
                <div class="form-group">
                    <label>سطح هدف (۱ تا ۵):</label>
                    <input type="number" name="target_level" value="5" min="1" max="5">
                </div>
            </div>
            <button type="submit" class="btn btn-primary" style="width:100%">محاسبه شکاف و ثبت در ماتریس</button>
        </form>
    </div>
</div>

<!-- COURSE PROPOSALS BY MEMBERS -->
<?php if (!$isLearnerComp): ?>
<div class="grid grid-2">
    <div class="card">
        <div class="card-header"><div class="card-title">💡 ثبت پیشنهاد دوره جدید توسط اعضا / سازمان‌ها (با تحلیل خودکار AI)</div></div>
        <form method="post" action="<?= e(url('competency')) ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="propose_course">
            <div class="form-group">
                <label>عنوان دوره پیشنهادی:</label>
                <input type="text" name="proposed_title" required placeholder="مثلاً: کارگاه عملی حمل ریلی صادراتی به آسیای میانه و روسیه">
            </div>
            <div class="form-grid">
                <div class="form-group">
                    <label>گروه مخاطبان هدف:</label>
                    <input type="text" name="target_audience" value="مدیران لجستیک و صادرات شرکت‌های عضو">
                </div>
                <div class="form-group">
                    <label>تعداد متقاضی تخمینی:</label>
                    <input type="number" name="estimated_learners" value="25">
                </div>
            </div>
            <div class="form-group">
                <label>شرح نیاز یا مسئله واقعی کسب‌وکار:</label>
                <textarea name="business_problem" rows="2" placeholder="چرایی نیاز بنگاه‌های استان به این دوره..."></textarea>
            </div>
            <button type="submit" class="btn btn-primary">ارسال پیشنهاد و دریافت نظر اولیه AI</button>
        </form>
    </div>

    <div class="card">
        <div class="card-header"><div class="card-title">📋 بانک پیشنهادهای دوره و بررسی کمیته نیازسنجی</div></div>
        <?php foreach ($proposals as $pr): ?>
            <div style="border:1px solid var(--border);border-radius:12px;padding:12px;margin-bottom:12px">
                <div style="display:flex;justify-content:space-between;gap:8px">
                    <strong><?= e($pr['proposed_title']) ?></strong>
                    <span class="badge badge-info"><?= e($pr['status']) ?></span>
                </div>
                <div class="muted" style="font-size:12px;margin:4px 0">
                    پیشنهاددهنده: <?= e($pr['full_name']) ?> (<?= e($pr['org_name'] ?? 'عضو حقیقی') ?>) | متقاضی تخمینی: <?= fa($pr['estimated_learners']) ?> نفر
                </div>
                <?php if (!empty($pr['ai_analysis_note'])): ?>
                    <div class="pre-box" style="font-size:12px;margin:8px 0"><?= e($pr['ai_analysis_note']) ?></div>
                <?php endif; ?>
                <?php if (Auth::hasRole(['super_admin', 'training_expert'])): ?>
                    <form method="post" action="<?= e(url('competency')) ?>" style="display:flex;gap:6px;margin-top:8px">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="review_proposal">
                        <input type="hidden" name="proposal_id" value="<?= (int)$pr['id'] ?>">
                        <input type="text" name="reviewer_comment" placeholder="نظر کارشناس آموزش..." value="<?= e($pr['reviewer_comment'] ?? '') ?>">
                        <select name="status" style="width:140px">
                            <option value="approved">تأیید کمیته</option>
                            <option value="converted_to_course">تبدیل به دوره</option>
                            <option value="rejected">رد شده</option>
                        </select>
                        <button type="submit" class="btn btn-outline btn-sm">ثبت نظر</button>
                    </form>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>
