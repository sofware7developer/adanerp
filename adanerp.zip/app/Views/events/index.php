<?php
use App\Core\QrSvg;
?>
<div class="hero-banner">
    <div>
        <span class="badge badge-gold">کارگاه‌ها و نشست‌های آموزشی آدان</span>
        <h1>برنامه‌های آموزشی و کارگاه‌های حسابداری</h1>
        <p>تقویم کارگاه‌ها، ثبت‌نام فراگیران، حضور در برنامه و دریافت بازخورد آموزشی.</p>
    </div>
    <div class="hero-actions">
        <?php if ($canManageEvents): ?>
            <a class="btn btn-gold" href="<?= e(url('events', ['export' => 'attendees'])) ?>">📥 دریافت CSV ثبت‌نام‌ها</a>
        <?php endif; ?>
    </div>
</div>

<div class="alert alert-warning">
    <div>
        <strong>راهنمای ثبت‌نام:</strong> برای برنامه‌های رایگان بلیت QR صادر می‌شود؛ برای برنامه‌های دارای تعرفه، ابتدا پیش‌فاکتور را در بخش مالی تسویه کنید.
    </div>
</div>

<div class="grid grid-2">
    <?php foreach ($events as $ev): ?>
        <?php
        $isPaid = (int)$ev['price_rial'] > 0;
        $registrationOpen = $ev['status'] === 'open'
            && $ev['event_date'] >= date('Y-m-d')
            && (int)$ev['registered_count'] < (int)$ev['capacity'];
        $estRevenue = (int)$ev['registered_count'] * (int)$ev['price_rial'];
        $estProfit = $estRevenue - (int)$ev['estimated_cost_rial'];
        ?>
        <div class="card">
            <div class="card-header">
                <div class="card-title">🎤 <?= e($ev['title']) ?></div>
                <span class="badge <?= $isPaid ? 'badge-warning' : 'badge-success' ?>">
                    <?= $isPaid ? 'شهریه برنامه: ' . rial($ev['price_rial']) : 'رایگان برای فراگیران' ?>
                </span>
            </div>
            <p style="font-size:13px;margin-bottom:8px">
                <strong>نوع برنامه:</strong> <?= e($ev['event_type'] ?: 'برنامه آموزشی') ?> |
                <strong>مدرس:</strong> <?= e($ev['speakers']) ?><br>
                <strong>تاریخ و مکان:</strong> <?= e($ev['event_shamsi']) ?> — <?= e($ev['venue']) ?><br>
                <strong>ظرفیت باقی‌مانده:</strong> <?= fa(max(0, (int)$ev['capacity'] - (int)$ev['registered_count'])) ?> نفر
            </p>
            <?php if ($canManageEvents): ?>
                <div style="font-size:12px;margin-bottom:12px" class="muted">
                    برآورد مالی — هزینه اجرا: <?= rial($ev['estimated_cost_rial']) ?> | تراز خالص: <?= rial($estProfit) ?> |
                    یادآوری پیامکی:
                    <?= $ev['sms_reminder_status'] === 'disabled' ? 'غیرفعال' : ($ev['sms_reminder_status'] === 'sandbox_queued' ? 'در صف آزمایشی' : 'ارسال آزمایشی') ?>
                </div>
            <?php endif; ?>

            <div style="display:flex;gap:8px;flex-wrap:wrap">
                <?php if ($registrationOpen): ?>
                    <form method="post" action="<?= e(url('events')) ?>">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="register_event">
                        <input type="hidden" name="event_id" value="<?= (int)$ev['id'] ?>">
                        <button type="submit" class="btn btn-primary">
                            <?= $isPaid ? '🎟️ دریافت بلیت پس از تسویه شهریه' : '🎟️ ثبت‌نام و دریافت بلیت QR' ?>
                        </button>
                    </form>
                    <?php if ($isPaid): ?>
                        <form method="post" action="<?= e(url('events')) ?>">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="issue_event_invoice">
                            <input type="hidden" name="event_id" value="<?= (int)$ev['id'] ?>">
                            <button type="submit" class="btn btn-gold">🧾 صدور پیش‌فاکتور</button>
                        </form>
                    <?php endif; ?>
                <?php else: ?>
                    <span class="badge badge-warning">
                        <?= $ev['event_date'] < date('Y-m-d') ? 'تاریخ برگزاری گذشته است' : 'ثبت‌نام بسته یا ظرفیت تکمیل است' ?>
                    </span>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<div class="grid grid-2">
    <!-- QR CHECK-IN CONSOLE -->
    <?php if ($canManageEvents): ?>
        <div class="card">
            <div class="card-header"><div class="card-title">📲 پذیرش فراگیران با بلیت QR</div></div>
            <form method="post" action="<?= e(url('events')) ?>">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="qr_checkin">
                <div class="form-group">
                    <label>کد بلیت را با بارکدخوان اسکن یا وارد کنید:</label>
                    <input type="text" name="ticket_code" placeholder="کد روی بلیت QR" required>
                </div>
                <button type="submit" class="btn btn-primary">ثبت حضور فراگیر</button>
            </form>
        </div>
    <?php endif; ?>

    <!-- CREATE NEW EVENT -->
    <?php if ($canCreateEvents): ?>
        <div class="card">
            <div class="card-header"><div class="card-title">➕ تعریف کارگاه یا نشست آموزشی</div></div>
            <form method="post" action="<?= e(url('events')) ?>">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="create_event">
                <div class="form-grid">
                    <div class="form-group">
                        <label>عنوان برنامه:</label>
                        <input type="text" name="title" required placeholder="کارگاه عملی ثبت اسناد حسابداری">
                    </div>
                    <div class="form-group">
                        <label>نوع برنامه:</label>
                        <select name="event_type">
                            <option value="کارگاه آموزشی">کارگاه آموزشی</option>
                            <option value="نشست تخصصی">نشست تخصصی</option>
                            <option value="جلسه رفع اشکال">جلسه رفع اشکال</option>
                        </select>
                    </div>
                </div>
                <div class="form-grid">
                    <div class="form-group">
                        <label>مدرس یا مسئول برنامه:</label>
                        <input type="text" name="speakers" value="مدرس دوره" required>
                    </div>
                    <div class="form-group">
                        <label>تاریخ برگزاری:</label>
                        <input type="date" name="event_date" value="<?= e($defaultEventDate) ?>" required>
                    </div>
                    <div class="form-group">
                        <label>مکان برگزاری:</label>
                        <input type="text" name="venue" value="آموزشگاه حسابداری آدان" required>
                    </div>
                    <div class="form-group">
                        <label>ظرفیت فراگیران:</label>
                        <input type="number" name="capacity" value="30" min="1" required>
                    </div>
                    <div class="form-group">
                        <label>شهریه (ریال؛ صفر = رایگان):</label>
                        <input type="number" name="price_rial" value="0" min="0" required>
                    </div>
                </div>
                <button type="submit" class="btn btn-outline">ثبت در تقویم آموزشی آدان</button>
            </form>
        </div>
    <?php endif; ?>
</div>

<!-- ISSUED QR TICKETS -->
<div class="card">
    <div class="card-header">
        <div class="card-title">
            🎟️ <?= $canManageEvents ? 'بلیت‌های صادرشده و وضعیت پذیرش' : 'بلیت‌های آموزشی من و وضعیت حضور' ?>
        </div>
    </div>
    <?php if ($tickets === []): ?>
        <p class="muted">هنوز برای برنامه‌ای ثبت‌نام نکرده‌اید.</p>
    <?php else: ?>
        <div class="grid grid-2">
            <?php foreach ($tickets as $t): ?>
                <div class="stat-card" style="align-items:center">
                    <div>
                        <div style="font-weight:800"><?= e($t['event_title']) ?></div>
                        <?php if ($canManageEvents): ?>
                            <div style="margin:4px 0">فراگیر: <strong><?= e($t['full_name']) ?></strong></div>
                        <?php endif; ?>
                        <div style="margin:4px 0">کد بلیت: <code><?= e($t['ticket_code']) ?></code></div>
                        <span class="badge <?= $t['checked_in_at'] ? 'badge-success' : 'badge-info' ?>">
                            <?= $t['checked_in_at'] ? '✅ حضور ثبت شده' : 'آماده پذیرش' ?>
                        </span>
                        <form method="post" action="<?= e(url('events')) ?>" style="display:flex;gap:5px;margin-top:8px;align-items:center">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="submit_feedback">
                            <input type="hidden" name="ticket_id" value="<?= (int)$t['id'] ?>">
                            <input type="number" name="feedback_score" value="<?= (int)($t['feedback_score'] ?? 5) ?>" min="1" max="5" style="width:65px" title="امتیاز ۱ تا ۵">
                            <input type="text" name="feedback_comment" value="<?= e($t['feedback_comment'] ?? '') ?>" placeholder="بازخورد آموزشی..." style="max-width:200px">
                            <button type="submit" class="btn btn-outline btn-sm">ثبت بازخورد</button>
                        </form>
                    </div>
                    <?= QrSvg::render($t['ticket_code'], 96) ?>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>
