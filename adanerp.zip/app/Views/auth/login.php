<div class="auth-login-page">
    <div class="card">
        <span class="badge badge-gold" style="margin-bottom:10px">ورود با نام کاربری و گذرواژه</span>
        <h2 style="font-size:21px;margin-bottom:8px">ورود به سامانه آموزشگاه حسابداری آدان</h2>
        <?php $appVer = (string)(\App\Core\App::config('app')['version'] ?? ''); [$verNum, $verCode] = array_pad(explode('-', $appVer, 2), 2, ''); ?>
        <?php if ($verNum !== ''): ?>
            <div style="margin:-2px 0 14px;display:flex;gap:6px;flex-wrap:wrap;align-items:center">
                <span class="badge badge-info" title="<?= e($appVer) ?>">نسخه مرجع <?= fa(str_replace('.', '٫', $verNum)) ?></span>
                <span class="muted" style="font-size:11.5px">آموزش حسابداری و مالی • کلاس حضوری و آنلاین • پشتیبانی آموزشی</span>
            </div>
        <?php endif; ?>
        <p class="muted" style="margin-bottom:20px">
            با نام کاربری و گذرواژه حساب خود وارد شوید. پس از ۵ تلاش ناموفق، قفل امنیتی موقت ۱۵ دقیقه‌ای فعال می‌گردد.
        </p>

        <form method="post" action="<?= e(url('login')) ?>">
            <?= csrf_field() ?>
            <div class="form-group">
                <label for="loginUsername">نام کاربری</label>
                <input type="text" name="username" id="loginUsername" autocomplete="username" required>
            </div>
            <div class="form-group">
                <label for="loginPassword">گذرواژه</label>
                <input type="password" name="password" id="loginPassword" autocomplete="current-password" required>
            </div>
            <button type="submit" class="btn btn-primary" style="width:100%;padding:11px;font-size:14px">
                ورود امن به پیشخوان نقش‌محور
            </button>
        </form>

        <div style="margin-top:20px;padding-top:16px;border-top:1px solid var(--border);display:flex;gap:8px;flex-wrap:wrap">
            <a class="btn btn-outline btn-sm" href="<?= e(url('public-home')) ?>">🌐 معرفی دوره‌های آدان</a>
            <a class="btn btn-outline btn-sm" href="<?= e(url('verify')) ?>">🔎 بررسی کد گواهی QR</a>
            <a class="btn btn-outline btn-sm" href="<?= e(url('help-manual-print')) ?>">📚 کتابچه راهنمای کل سیستم</a>
        </div>
    </div>
</div>
