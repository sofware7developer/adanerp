<div class="hero-banner">
    <div>
        <span class="badge badge-gold">مرکز مطالعات و پژوهش‌های آموزشی</span>
        <h1>پژوهش آموزشی، مصاحبه و مشاهده میدانی، بودجه و انتشارات</h1>
        <p>مدیریت طرح‌های پژوهشی استانی، روش‌شناسی، بودجه پژوهش، مقالات/گزارش‌های سیاستی و پیوند مستقیم به فرم‌ساز پویا.</p>
    </div>
    <a class="btn btn-gold" href="<?= e(url('workspace-tools')) ?>">📋 باز کردن فرم‌ساز گردآوری داده</a>
</div>

<div class="grid grid-sidebar">
    <div class="card">
        <div class="card-header"><div class="card-title">🔬 طرح‌های پژوهشی و مطالعات نیازسنجی استانی</div></div>
        <?php foreach ($projects as $prj): ?>
            <div style="border:1px solid var(--border);border-radius:14px;padding:15px;margin-bottom:14px">
                <div style="display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap">
                    <strong><?= e($prj['title']) ?></strong>
                    <span class="badge badge-info">پیشرفت: <?= fa($prj['progress_pct']) ?>٪ | <?= e($prj['status']) ?></span>
                </div>
                <div class="muted" style="font-size:12px;margin:6px 0">
                    مجری مسئول: <?= e($prj['lead_researcher']) ?> | روش تحقیق: <?= e($prj['methodology']) ?> | بودجه: <?= rial($prj['budget_rial']) ?>
                </div>
                <p style="font-size:13px"><?= e($prj['publication_summary']) ?></p>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="card">
        <div class="card-header"><div class="card-title">➕ ثبت پروپوزال پژوهشی جدید</div></div>
        <form method="post" action="<?= e(url('research')) ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="create_research">
            <div class="form-group">
                <label>عنوان طرح پژوهشی / مقاله:</label>
                <input type="text" name="title" required placeholder="بررسی اثر دوره‌های گمرکی بر کاهش زمان ترخیص">
            </div>
            <div class="form-group">
                <label>پژوهشگر مسئول:</label>
                <input type="text" name="lead_researcher" value="واحد پژوهش و آموزش آدان" required>
            </div>
            <div class="form-group">
                <label>روش تحقیق و ابزار گردآوری:</label>
                <input type="text" name="methodology" value="مصاحبه نیمه‌ساختاریافته + پرسشنامه فرم‌ساز">
            </div>
            <div class="form-group">
                <label>بودجه مصوب (ریال):</label>
                <input type="number" name="budget_rial" value="480000000">
            </div>
            <div class="form-group">
                <label>خلاصه اهداف و خروجی علمی:</label>
                <textarea name="publication_summary" rows="2"></textarea>
            </div>
            <button type="submit" class="btn btn-primary" style="width:100%">ثبت طرح پژوهشی</button>
        </form>
    </div>
</div>

<!-- DOUBLE-BLIND PEER REVIEW & MILESTONE BUDGET RELEASE -->
<div class="grid grid-sidebar" style="margin-top:18px">
    <div class="card">
        <div class="card-header"><div class="card-title">🔬 کارتابل داوری همتای دوسوکور (Double-Blind Peer Review) و آزادسازی مرحله‌ای بودجه پژوهش</div></div>
        <div class="table-wrap">
            <table>
                <thead><tr><th>عنوان طرح پژوهشی</th><th>کد داور ناشناس</th><th>امتیاز علمی / کاربردی</th><th>رأی کمیته علمی</th><th>توضیحات داور</th></tr></thead>
                <tbody>
                <?php foreach (($peerReviews ?? []) as $pr): ?>
                    <tr>
                        <td><strong><?= e((string)($pr['project_title'] ?? 'طرح پژوهشی استان')) ?></strong></td>
                        <td><span class="badge badge-purple"><?= e($pr['reviewer_alias']) ?></span></td>
                        <td><?= fa($pr['scientific_score']) ?> | <?= fa($pr['applicability_score']) ?></td>
                        <td><span class="badge badge-success"><?= e($pr['recommendation']) ?></span></td>
                        <td style="font-size:12px"><?= e($pr['review_comment']) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card">
        <div class="card-header"><div class="card-title">✍️ ثبت رأی داور علمی همتا</div></div>
        <form method="post" action="<?= e(url('research')) ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="submit_peer_review">
            <div class="form-group">
                <select name="project_id">
                    <?php foreach ($projects as $p): ?>
                        <option value="<?= (int)$p['id'] ?>"><?= e($p['title']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group"><input type="text" name="reviewer_alias" value="داور ناشناس کد DR-209 (عضو هیئت علمی)" required></div>
            <div class="form-grid">
                <input type="number" name="scientific_score" value="92" min="0" max="100">
                <input type="number" name="applicability_score" value="95" min="0" max="100">
            </div>
            <div class="form-group" style="margin-top:8px">
                <select name="recommendation">
                    <option value="تأیید و آزادسازی قسط بعدی بودجه">تأیید و آزادسازی قسط بعدی بودجه</option>
                    <option value="تأیید مشروط به اصلاح روش‌شناسی">تأیید مشروط به اصلاح روش‌شناسی</option>
                </select>
            </div>
            <div class="form-group"><textarea name="review_comment" rows="2" required>یافته‌های میدانی کاملاً منطبق با چالش‌های واقعی صادرکنندگان استان است.</textarea></div>
            <button type="submit" class="btn btn-primary" style="width:100%">ثبت رأی داور و ارتقای پیشرفت</button>
        </form>
    </div>
</div>
