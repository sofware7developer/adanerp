<div class="hero-banner">
    <div>
        <span class="badge badge-gold">مدیریت سالن‌ها و زیرساخت کالبدی</span>
        <h1>کلاس‌ها، تجهیزات، رزرو اسلاتی ضد تداخل و اعلام خرابی</h1>
        <p>کنترل هوشمند تداخل زمانی در رزرو سالن‌های مؤسسه آموزشی آدان، تعرفه ساعتی، پذیرایی و ثبت درخواست تعمیرات تجهیزات.</p>
    </div>
</div>

<div class="grid grid-3">
    <?php foreach ($rooms as $rm): ?>
        <div class="card">
            <div class="card-header">
                <div class="card-title">🏛️ <?= e($rm['name']) ?></div>
                <span class="badge <?= $rm['maintenance_status'] === 'ready' ? 'badge-success' : 'badge-warning' ?>">
                    <?= $rm['maintenance_status'] === 'ready' ? 'آماده بهره‌برداری' : 'نیازمند سرویس فنی' ?>
                </span>
            </div>
            <p style="font-size:12.5px">ظرفیت: <strong><?= fa($rm['capacity']) ?> نفر</strong> | تعرفه ساعتی: <strong><?= rial($rm['hourly_fee_rial']) ?></strong></p>
            <p class="muted" style="font-size:12px;margin:6px 0">تجهیزات: <?= e($rm['equipment']) ?></p>
            <?php if (!empty($rm['maintenance_note'])): ?>
                <div class="alert alert-warning" style="padding:8px 10px;font-size:11.5px;margin-top:8px">🔧 <?= e($rm['maintenance_note']) ?></div>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
</div>

<div class="grid grid-2">
    <!-- BOOKING WITH SQL OVERLAP CHECK -->
    <div class="card">
        <div class="card-header"><div class="card-title">📅 ثبت رزرو اسلاتی کلاس (با کنترل خودکار تداخل زمانی)</div></div>
        <form method="post" action="<?= e(url('classrooms')) ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="book_room">
            <div class="form-group">
                <label>انتخاب سالن / کارگاه:</label>
                <select name="classroom_id">
                    <?php foreach ($rooms as $rm): ?>
                        <option value="<?= (int)$rm['id'] ?>"><?= e($rm['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-grid">
                <div class="form-group">
                    <label>تاریخ میلادی جلسه:</label>
                    <input type="date" name="booking_date" value="2026-11-01" required>
                </div>
                <div class="form-group">
                    <label>ساعت شروع:</label>
                    <input type="time" name="start_time" value="15:00" required>
                </div>
                <div class="form-group">
                    <label>ساعت پایان:</label>
                    <input type="time" name="end_time" value="17:00" required>
                </div>
            </div>
            <div class="form-group">
                <label>موضوع جلسه / کارگاه:</label>
                <input type="text" name="purpose" required value="جلسه کارگروه صادرات استان">
            </div>
            <div class="form-group">
                <label>درخواست پذیرایی و تشریفات:</label>
                <input type="text" name="catering_request" value="پذیرایی میان‌وعده ۲۵ نفر">
            </div>
            <button type="submit" class="btn btn-primary">بررسی عدم تداخل و ثبت رزرو</button>
        </form>
    </div>

    <!-- MAINTENANCE TICKET -->
    <div class="card">
        <div class="card-header"><div class="card-title">🛠️ اعلام خرابی تجهیزات یا درخواست خدمات پشتیبانی</div></div>
        <form method="post" action="<?= e(url('classrooms')) ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="report_issue">
            <div class="form-group">
                <label>سالن مورد نظر:</label>
                <select name="classroom_id">
                    <?php foreach ($rooms as $rm): ?>
                        <option value="<?= (int)$rm['id'] ?>"><?= e($rm['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>شرح خرابی یا سرویس درخواستی:</label>
                <textarea name="maintenance_note" rows="3" required placeholder="مثلاً: تنظیم سیستم ترجمه همزمان پیش از نشست فردا"></textarea>
            </div>
            <button type="submit" class="btn btn-outline">ثبت تیکت واحد پشتیبانی فنی</button>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-header"><div class="card-title">جدول زمان‌بندی رزروهای ثبت‌شده</div></div>
    <div class="table-wrap">
        <table>
            <thead><tr><th>سالن</th><th>تاریخ شمسی</th><th>بازه ساعت</th><th>عنوان برنامه</th><th>پذیرایی</th></tr></thead>
            <tbody>
            <?php foreach ($bookings as $bk): ?>
                <tr>
                    <td><strong><?= e($bk['room_name']) ?></strong></td>
                    <td><?= e($bk['booking_shamsi']) ?></td>
                    <td dir="ltr" style="text-align:right"><?= e(substr($bk['start_time'], 0, 5)) ?> - <?= e(substr($bk['end_time'], 0, 5)) ?></td>
                    <td><?= e($bk['purpose']) ?></td>
                    <td><?= e($bk['catering_request']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
