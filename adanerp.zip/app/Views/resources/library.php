<div class="hero-banner">
    <div>
        <span class="badge badge-gold">کتابخانه تخصصی و مرکز دانش</span>
        <h1>کتابخانه دیجیتال و فیزیکی، جست‌وجوی کمکی AI و نظام امانت</h1>
        <p>مخزن گزارش‌های تجاری کشورها، کتب و راهنماهای گمرکی، مجوز و نسخه، امانت و بازگشت، نقد خوانندگان و پیوند به دوره‌ها.</p>
    </div>
</div>

<div class="alert alert-info">
    <div>
        <strong>شفافیت معماری جست‌وجوی دانشی:</strong> جست‌وجوی کمکی هوش مصنوعی بر روی متن چکیده‌ها و کلیدواژه‌های کتابخانه عمل می‌کند و <strong>جایگزین موتور پایگاه داده برداری (Vector Database) مقیاس بزرگ نیست.</strong>
    </div>
</div>

<div class="grid grid-2">
    <div class="card">
        <div class="card-header"><div class="card-title">🔎 جست‌وجوی متنی سریع در منابع کتابخانه</div></div>
        <form method="get" action="<?= e(url('library')) ?>" style="display:flex;gap:8px">
            <input type="text" name="q" value="<?= e($q) ?>" placeholder="جست‌وجوی کلیدواژه (مثلاً: CBAM، اینکوترمز، بارنامه)...">
            <button type="submit" class="btn btn-primary">جست‌وجو</button>
        </form>
    </div>

    <div class="card">
        <div class="card-header"><div class="card-title">🤖 دستیار هوش مصنوعی راهنمای منابع (AI)</div></div>
        <form method="post" action="<?= e(url('library')) ?>" style="display:flex;gap:8px">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="ai_library_assist">
            <input type="text" name="ai_query" required placeholder="کدام منبع کتابخانه برای صادرات فولاد به اروپا مناسب است؟">
            <button type="submit" class="btn btn-gold">پرسش از کتابدار هوشمند</button>
        </form>
        <?php if ($aiAnswer): ?>
            <div class="pre-box" style="margin-top:10px"><?= e($aiAnswer['content']) ?></div>
        <?php endif; ?>
    </div>
</div>

<div class="card">
    <div class="card-header"><div class="card-title">📚 مخزن کتب و گزارش‌های راهبردی</div></div>
    <?php foreach ($items as $it): ?>
        <div style="border:1px solid var(--border);border-radius:14px;padding:15px;margin-bottom:12px">
            <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap">
                <div>
                    <span class="badge badge-info"><?= e($it['category']) ?> | <?= e($it['edition']) ?></span>
                    <strong style="margin-right:6px"><?= e($it['title']) ?></strong>
                </div>
                <span class="badge badge-gold">نسخه‌های موجود امانت: <?= fa($it['available_copies']) ?> | دانلود: <?= fa($it['downloads_count']) ?></span>
            </div>
            <p style="font-size:13px;margin:8px 0"><?= e($it['abstract_text']) ?></p>
            <form method="post" action="<?= e(url('library')) ?>" style="display:flex;gap:8px;align-items:center">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="loan_book">
                <input type="hidden" name="item_id" value="<?= (int)$it['id'] ?>">
                <input type="text" name="review_note" placeholder="یادداشت / نقد کوتاه شما بر این منبع..." style="max-width:340px">
                <button type="submit" class="btn btn-outline btn-sm">📥 ثبت دریافت / امانت منبع</button>
            </form>
        </div>
    <?php endforeach; ?>
</div>

<div class="card">
    <div class="card-header"><div class="card-title">🔄 سابقه امانت و بازگشت نسخه‌های فیزیکی</div></div>
    <div class="table-wrap">
        <table>
            <thead><tr><th>عنوان منبع</th><th>امانت‌گیرنده</th><th>سررسید بازگشت</th><th>نقد ثبت‌شده</th><th>وضعیت</th></tr></thead>
            <tbody>
            <?php foreach ($loans as $ln): ?>
                <tr>
                    <td><strong><?= e($ln['title']) ?></strong></td>
                    <td><?= e($ln['full_name']) ?></td>
                    <td><?= e($ln['due_shamsi']) ?></td>
                    <td><?= e($ln['review_note']) ?></td>
                    <td>
                        <?php if ($ln['returned_at']): ?>
                            <span class="badge badge-success">بازگردانده شد</span>
                        <?php else: ?>
                            <form method="post" action="<?= e(url('library')) ?>">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="return_loan">
                                <input type="hidden" name="loan_id" value="<?= (int)$ln['id'] ?>">
                                <button type="submit" class="btn btn-primary btn-sm">ثبت بازگشت</button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
