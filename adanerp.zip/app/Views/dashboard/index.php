<?php
use App\Core\Auth;
use App\Core\Jalali;

$curRoleKey = $activeRole ?? Auth::role() ?: 'learner';
$hud = \App\Services\LearnerBehaviorGamificationService::getUserHudSnapshot(
    (int)($currentUser['id'] ?? 1),
    (string)($currentUser['full_name'] ?? 'کاربر')
);
?>

<?php if ($curRoleKey === 'super_admin'): ?>
    <!-- ==================== ۱. پیشخوان فرماندهی کلان ویژه مدیرکل آموزش / دبیرکل ==================== -->
    <div class="hero-banner">
        <div>
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;flex-wrap:wrap">
                <span class="badge badge-gold">دسترسی فرماندهی کلان • <?= e(Auth::roleLabel($curRoleKey)) ?></span>
                <span style="font-size:12px;color:rgba(226,232,240,0.8)"><?= e(Jalali::todayFull()) ?></span>
            </div>
            <h1>سلام، <?= e($currentUser['full_name']) ?> 👋</h1>
            <p>نمای کلان دوره‌ها و کلاس‌ها، وضعیت دانشجویان، درآمد شهریه و عملکرد آموزشی مؤسسه آدان</p>
        </div>
        <div class="hero-actions">
            <a class="btn btn-primary" href="<?= e(url('tms')) ?>">+ مدیریت دوره‌ها (TMS)</a>
            <a class="btn btn-gold" href="<?= e(url('bi')) ?>">هوش تجاری و گزارش‌ساز BI</a>
            <a class="btn btn-outline" style="background:rgba(255,255,255,0.12);color:#fff;border-color:rgba(255,255,255,0.25)" href="<?= e(url('board-report-print')) ?>" target="_blank">گزارش مدیریتی آموزشگاه</a>
        </div>
    </div>

    <div class="grid grid-4">
        <div class="stat-card">
            <div>
                <div class="stat-label">دوره‌های کاتالوگ آموزش</div>
                <div class="stat-value"><?= fa($kpis['courses_total']) ?> دوره</div>
                <div class="stat-meta"><?= fa($kpis['active_runs']) ?> کلاس در حال برگزاری</div>
            </div>
            <div class="stat-icon icon-teal">📚</div>
        </div>
        <div class="stat-card">
            <div>
                <div class="stat-label">دانشجویان ثبت‌شده</div>
                <div class="stat-value"><?= fa($kpis['learners_total']) ?> نفر</div>
                <div class="stat-meta">دارای پرونده آموزشی در آدان</div>
            </div>
            <div class="stat-icon icon-gold">🏢</div>
        </div>
        <div class="stat-card">
            <div>
                <div class="stat-label">درآمد محقق‌شده آموزشی</div>
                <div class="stat-value" style="font-size:17.5px;white-space:nowrap"><?= rial($kpis['revenue_rial']) ?></div>
                <div class="stat-meta">تراز دقیق دفترکل ۴ سطحی</div>
            </div>
            <div class="stat-icon icon-green">💰</div>
        </div>
        <div class="stat-card">
            <div>
                <div class="stat-label">گواهی‌نامه‌های معتبر QR</div>
                <div class="stat-value"><?= fa($kpis['valid_certs']) ?> فقره</div>
                <div class="stat-meta">قابل استعلام برخط برای دانشجویان</div>
            </div>
            <div class="stat-icon icon-purple">🏅</div>
        </div>
    </div>

    <div class="grid grid-2" style="margin-top:16px">
        <div class="card">
            <div class="card-header">
                <div class="card-title">ظرفیت کلاس‌های فعال در حال اجرا</div>
                <a class="btn btn-outline btn-sm" href="<?= e(url('tms')) ?>">مدیریت کلاس‌ها</a>
            </div>
            <div class="table-wrap">
                <table>
                    <thead><tr><th>عنوان دوره</th><th>شروع</th><th>تکمیل ظرفیت</th><th>وضعیت</th></tr></thead>
                    <tbody>
                    <?php foreach ($recentRuns as $r): ?>
                        <?php $pct = min(100, (int)round(((int)$r['enrolled_count'] / max(1, (int)$r['capacity'])) * 100)); ?>
                        <tr>
                            <td><strong><?= e($r['course_title']) ?></strong><div class="muted" style="font-size:11.5px"><?= e($r['run_code']) ?></div></td>
                            <td><?= e($r['start_shamsi']) ?></td>
                            <td><?= fa($r['enrolled_count']) ?>/<?= fa($r['capacity']) ?> (<?= fa($pct) ?>٪)</td>
                            <td><span class="badge badge-info"><?= e($r['status']) ?></span></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <div class="card-title">آخرین رخدادهای امنیتی و ممیزی دسترسی (ویژه مدیر ارشد)</div>
                <a class="btn btn-outline btn-sm" href="<?= e(url('iam-access')) ?>">مدیریت دسترسی‌ها</a>
            </div>
            <div class="table-wrap">
                <table>
                    <thead><tr><th>بخش</th><th>رویداد</th><th>کاربر</th><th>IP</th></tr></thead>
                    <tbody>
                    <?php foreach ($recentLogs as $lg): ?>
                        <tr>
                            <td><span class="badge badge-purple"><?= e($lg['module']) ?></span></td>
                            <td><?= e($lg['action']) ?></td>
                            <td><?= e($lg['full_name'] ?? 'سیستم') ?></td>
                            <td dir="ltr" style="font-size:11.5px" class="muted"><?= e($lg['ip_address']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

<?php elseif ($curRoleKey === 'training_expert'): ?>
    <!-- ==================== ۲. پیشخوان اختصاصی کارشناس مسئول آموزش ==================== -->
    <div class="hero-banner">
        <div>
            <span class="badge badge-gold">حوزه تخصصی برنامه‌ریزی و اجرای آموزش • <?= e(Auth::roleLabel($curRoleKey)) ?></span>
            <h1>پیشخوان عملیاتی آموزش — خوش آمدید <?= e($currentUser['full_name']) ?></h1>
            <p>برنامه‌ریزی دوره‌ها و تقویم ترم، پایش ظرفیت کلاس‌ها، هماهنگی اساتید، صدور گواهی‌نامه‌های QR و نظارت بر محتوای LMS</p>
        </div>
        <div class="hero-actions">
            <a class="btn btn-gold" href="<?= e(url('tms')) ?>">📚 کارخانه دوره‌ها و TMS</a>
            <a class="btn btn-primary" href="<?= e(url('lms')) ?>">🎬 مدیریت محتوای LMS</a>
            <a class="btn btn-outline" style="background:rgba(255,255,255,0.12);color:#fff" href="<?= e(url('exams')) ?>">📝 آزمون و گواهی QR</a>
        </div>
    </div>

    <div class="grid grid-4">
        <div class="stat-card">
            <div><div class="stat-label">کل دوره‌های کاتالوگ</div><div class="stat-value"><?= fa($kpis['courses_total']) ?> دوره</div><div class="stat-meta">فعال در تقویم آموزشی</div></div>
            <div class="stat-icon icon-teal">📚</div>
        </div>
        <div class="stat-card">
            <div><div class="stat-label">کلاس‌های در حال ثبت‌نام/اجرا</div><div class="stat-value"><?= fa($kpis['active_runs']) ?> اجرا</div><div class="stat-meta">همراه لیست انتظار خودکار</div></div>
            <div class="stat-icon icon-blue">🏫</div>
        </div>
        <div class="stat-card">
            <div><div class="stat-label">مدرسان فعال</div><div class="stat-value"><?= fa($kpis['instructors_total']) ?> مدرس</div><div class="stat-meta">بانک مدرسان آدان</div></div>
            <div class="stat-icon icon-gold">👨‍🏫</div>
        </div>
        <div class="stat-card">
            <div><div class="stat-label">پیش‌نویس‌های منتظر تأیید علمی</div><div class="stat-value"><?= fa($kpis['ai_drafts_pending']) ?> مورد</div><div class="stat-meta">استودیوی هوشمند AI</div></div>
            <div class="stat-icon icon-purple">✨</div>
        </div>
    </div>

    <div class="card" style="margin-top:16px">
        <div class="card-header">
            <div class="card-title">وضعیت ثبت‌نام و ظرفیت کلاس‌های جاری واحد آموزش</div>
            <div style="display:flex;gap:8px">
                <a class="btn btn-primary btn-sm" href="<?= e(url('role-workstations')) ?>">میزکار ثبت‌نام گروهی من</a>
                <a class="btn btn-outline btn-sm" href="<?= e(url('academic-erp-core')) ?>">حضور و غیاب و کارنامه</a>
            </div>
        </div>
        <div class="table-wrap">
            <table>
                <thead><tr><th>کد اجرا</th><th>عنوان دوره</th><th>استاد</th><th>شروع</th><th>تکمیل ظرفیت</th></tr></thead>
                <tbody>
                <?php foreach ($recentRuns as $r): ?>
                    <tr>
                        <td><code><?= e($r['run_code']) ?></code></td>
                        <td><strong><?= e($r['course_title']) ?></strong></td>
                        <td><?= e($r['instructor_name'] ?? '—') ?></td>
                        <td><?= e($r['start_shamsi']) ?></td>
                        <td><?= fa($r['enrolled_count']) ?> از <?= fa($r['capacity']) ?> نفر</td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

<?php elseif ($curRoleKey === 'finance_manager'): ?>
    <!-- ==================== ۳. پیشخوان اختصاصی مدیر مالی و ذی‌حساب ==================== -->
    <div class="hero-banner">
        <div>
            <span class="badge badge-gold">حوزه تخصصی مالی، خزانه و مؤدیان • <?= e(Auth::roleLabel($curRoleKey)) ?></span>
            <h1>پیشخوان مدیریت مالی و حسابداری — <?= e($currentUser['full_name']) ?></h1>
            <p>کنترل تراز دفترکل ۴ سطحی، وصول صورتحساب‌ها و اقساط، چک‌های صیادی، محاسبه استرداد شهریه و ارسال به سامانه مؤدیان</p>
        </div>
        <div class="hero-actions">
            <a class="btn btn-gold" href="<?= e(url('finance')) ?>">💳 دفترکل، فاکتورها و خزانه</a>
            <a class="btn btn-primary" href="<?= e(url('tax-moadian')) ?>">🧾 سامانه مؤدیان مالیاتی</a>
            <a class="btn btn-outline" style="background:rgba(255,255,255,0.12);color:#fff" href="<?= e(url('role-workstations')) ?>">میزکار استرداد شهریه</a>
        </div>
    </div>

    <div class="grid grid-4">
        <div class="stat-card">
            <div><div class="stat-label">درآمد ثبت‌شده دفترکل</div><div class="stat-value" style="font-size:17px"><?= rial($kpis['revenue_rial']) ?></div><div class="stat-meta">تراز آزمایشی تجمیعی</div></div>
            <div class="stat-icon icon-green">💰</div>
        </div>
        <div class="stat-card">
            <div><div class="stat-label">اسناد و چک‌های صیادی</div><div class="stat-value"><?= fa($roleScoped['sayad_count']) ?> فقره</div><div class="stat-meta">پایش سررسید خزانه</div></div>
            <div class="stat-icon icon-gold">🏦</div>
        </div>
        <div class="stat-card">
            <div><div class="stat-label">صورتحساب‌های اخیر</div><div class="stat-value"><?= fa(count($roleScoped['finance_invoices'])) ?> فاکتور</div><div class="stat-meta">دارای احتساب ارزش افزوده</div></div>
            <div class="stat-icon icon-blue">🧾</div>
        </div>
        <div class="stat-card">
            <div><div class="stat-label">گزارش‌های تحلیلی مالی</div><div class="stat-value">فعال</div><div class="stat-meta"><a href="<?= e(url('bi')) ?>">ورود به گزارش‌ساز BI ←</a></div></div>
            <div class="stat-icon icon-purple">📊</div>
        </div>
    </div>

    <div class="card" style="margin-top:16px">
        <div class="card-header"><div class="card-title">آخرین صورتحساب‌های صادرشده در واحد مالی</div><a class="btn btn-primary btn-sm" href="<?= e(url('finance')) ?>">مدیریت کامل مالی</a></div>
        <div class="table-wrap">
            <table>
                <thead><tr><th>شماره فاکتور</th><th>مؤدی / پرداخت‌کننده</th><th>شرح</th><th>مبلغ کل</th><th>وضعیت</th></tr></thead>
                <tbody>
                <?php foreach ($roleScoped['finance_invoices'] as $inv): ?>
                    <tr>
                        <td><code><?= e($inv['invoice_number']) ?></code></td>
                        <td><strong><?= e($inv['full_name']) ?></strong></td>
                        <td><?= e($inv['item_description']) ?></td>
                        <td><?= rial((int)$inv['total_rial']) ?></td>
                        <td><span class="badge badge-info"><?= e($inv['status']) ?></span></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

<?php elseif ($curRoleKey === 'crm_manager'): ?>
    <!-- ==================== ۴. پیشخوان اختصاصی مدیر CRM، بازاریابی و ارتباط با اعضا ==================== -->
    <div class="hero-banner">
        <div>
            <span class="badge badge-gold">پذیرش و ارتباط با دانشجویان • <?= e(Auth::roleLabel($curRoleKey)) ?></span>
            <h1>پیشخوان پذیرش و ثبت‌نام دوره‌ها — <?= e($currentUser['full_name']) ?></h1>
            <p>پیگیری درخواست‌های آموزش، اطلاع‌رسانی دوره‌های حسابداری و همراهی متقاضیان از ثبت‌نام تا شروع کلاس</p>
        </div>
        <div class="hero-actions">
            <a class="btn btn-gold" href="<?= e(url('marketing-intel')) ?>">📱 کمپین شبکه‌های اجتماعی</a>
            <a class="btn btn-primary" href="<?= e(url('crm')) ?>">🤝 پیگیری درخواست‌های ثبت‌نام</a>
            <a class="btn btn-outline" style="background:rgba(255,255,255,0.12);color:#fff" href="<?= e(url('tms')) ?>">📚 دوره‌های فعال آدان</a>
        </div>
    </div>

    <div class="grid grid-4">
        <div class="stat-card">
            <div><div class="stat-label">دانشجویان آموزشگاه</div><div class="stat-value"><?= fa($kpis['learners_total']) ?> نفر</div><div class="stat-meta">پرونده‌های آموزشی فعال</div></div>
            <div class="stat-icon icon-gold">🏢</div>
        </div>
        <div class="stat-card">
            <div><div class="stat-label">کمپین‌های فعال شبکه‌های اجتماعی</div><div class="stat-value"><?= fa(count($roleScoped['social_posts'])) ?> پست اخیر</div><div class="stat-meta">اینستاگرام، لینکدین و تلگرام</div></div>
            <div class="stat-icon icon-purple">📣</div>
        </div>
        <div class="stat-card">
            <div><div class="stat-label">دوره‌های در حال ثبت‌نام</div><div class="stat-value"><?= fa($kpis['active_runs']) ?> کلاس</div><div class="stat-meta">آماده پذیرش دانشجو</div></div>
            <div class="stat-icon icon-teal">🎯</div>
        </div>
        <div class="stat-card">
            <div><div class="stat-label">پیگیری پذیرش</div><div class="stat-value">آماده</div><div class="stat-meta"><a href="<?= e(url('portal')) ?>">پرونده‌های آموزشی ←</a></div></div>
            <div class="stat-icon icon-blue">💼</div>
        </div>
    </div>

    <div class="card" style="margin-top:16px">
        <div class="card-header"><div class="card-title">آخرین اطلاع‌رسانی‌های دوره‌ها</div><a class="btn btn-primary btn-sm" href="<?= e(url('marketing-intel')) ?>">مدیریت اطلاع‌رسانی</a></div>
        <div class="table-wrap">
            <table>
                <thead><tr><th>پلتفرم</th><th>دوره هدف</th><th>بازدید</th><th>کلیک UTM</th><th>ثبت‌نام جذب‌شده</th></tr></thead>
                <tbody>
                <?php foreach ($roleScoped['social_posts'] as $sp): ?>
                    <tr>
                        <td><span class="badge badge-info"><?= e($sp['platform']) ?></span></td>
                        <td><strong><?= e($sp['target_course_title']) ?></strong></td>
                        <td><?= fa(number_format((int)$sp['impressions_count'])) ?></td>
                        <td><?= fa(number_format((int)$sp['clicks_count'])) ?></td>
                        <td><strong><?= fa($sp['enrollments_converted']) ?> نفر</strong></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

<?php elseif ($curRoleKey === 'instructor'): ?>
    <!-- ==================== ۵. پیشخوان کاملاً ایزوله ویژه استاد و مشاور آموزشی ==================== -->
    <div class="hero-banner">
        <div>
            <span class="badge badge-gold">پنل اختصاصی هیئت علمی و اساتید • <?= e(Auth::roleLabel($curRoleKey)) ?></span>
            <h1>سلام استاد گرامی، <?= e($currentUser['full_name']) ?> 👋</h1>
            <p>برنامه هفتگی کلاس‌های تدریس، طراحی درس و آزمونک در LMS، بررسی تکالیف دانشجویان و مشاهده قرارداد حق‌التدریس</p>
        </div>
        <div class="hero-actions">
            <a class="btn btn-gold" href="<?= e(url('lms')) ?>">🎬 ورود به کلاس و استودیوی LMS</a>
            <a class="btn btn-primary" href="<?= e(url('ai-studio')) ?>">✨ تولید جزوه و سؤال با AI</a>
            <a class="btn btn-outline" style="background:rgba(255,255,255,0.12);color:#fff" href="<?= e(url('instructor-contract-print')) ?>" target="_blank">📄 حکم و قرارداد تدریس من</a>
        </div>
    </div>

    <div class="grid grid-4">
        <div class="stat-card">
            <div><div class="stat-label">کلاس‌های تخصیص‌یافته به شما</div><div class="stat-value"><?= fa(count($roleScoped['instructor_runs'])) ?> کلاس</div><div class="stat-meta">نیمسال جاری آموزشی</div></div>
            <div class="stat-icon icon-teal">👨‍🏫</div>
        </div>
        <div class="stat-card">
            <div><div class="stat-label">تکالیف ارسالی دانشجویان</div><div class="stat-value"><?= fa(count($roleScoped['pending_assignments'])) ?> پرونده</div><div class="stat-meta">آماده تصحیح با روبریک AI</div></div>
            <div class="stat-icon icon-gold">📝</div>
        </div>
        <div class="stat-card">
            <div><div class="stat-label">وبینار و کلاس آنلاین زنده</div><div class="stat-value">فعال</div><div class="stat-meta"><a href="<?= e(url('virtual-class')) ?>">ورود به اتاق وبینار ←</a></div></div>
            <div class="stat-icon icon-blue">🎥</div>
        </div>
        <div class="stat-card">
            <div><div class="stat-label">توصیه‌نامه مهارتی و زمان آزاد</div><div class="stat-value">میزکار من</div><div class="stat-meta"><a href="<?= e(url('role-workstations')) ?>">ثبت زمان تدریس ←</a></div></div>
            <div class="stat-icon icon-purple">🏅</div>
        </div>
    </div>

    <div class="grid grid-2" style="margin-top:16px">
        <div class="card">
            <div class="card-header"><div class="card-title">برنامه کلاس‌های تدریس شما</div><a class="btn btn-outline btn-sm" href="<?= e(url('lms')) ?>">ورود به LMS</a></div>
            <div class="table-wrap">
                <table>
                    <thead><tr><th>کد کلاس</th><th>عنوان دوره</th><th>زمان‌بندی</th><th>ظرفیت</th></tr></thead>
                    <tbody>
                    <?php foreach ($roleScoped['instructor_runs'] as $ir): ?>
                        <tr>
                            <td><code><?= e($ir['run_code']) ?></code></td>
                            <td><strong><?= e($ir['course_title']) ?></strong></td>
                            <td><?= e($ir['schedule_text']) ?></td>
                            <td><?= fa($ir['enrolled_count']) ?> دانشجو</td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="card">
            <div class="card-header"><div class="card-title">تکالیف ارسالی دانشجویان جهت نمره‌دهی</div><a class="btn btn-gold btn-sm" href="<?= e(url('lms')) ?>">تصحیح در LMS</a></div>
            <div class="table-wrap">
                <table>
                    <thead><tr><th>دانشجو</th><th>عنوان تکلیف</th><th>وضعیت</th></tr></thead>
                    <tbody>
                    <?php foreach ($roleScoped['pending_assignments'] as $pa): ?>
                        <tr>
                            <td><strong><?= e($pa['full_name']) ?></strong></td>
                            <td><?= e($pa['title']) ?></td>
                            <td><span class="badge badge-info"><?= e($pa['status']) ?></span></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

<?php elseif ($curRoleKey === 'org_rep'): ?>
    <!-- ==================== ۶. پیشخوان کارشناس آموزش و ثبت‌نام ==================== -->
    <div class="hero-banner">
        <div>
            <span class="badge badge-gold">آموزش و ثبت‌نام دانشجویان • <?= e(Auth::roleLabel($curRoleKey)) ?></span>
            <h1>میزکار آموزشگاه آدان — <?= e($currentUser['full_name']) ?></h1>
            <p>پیگیری ثبت‌نام دانشجویان، وضعیت کلاس‌ها، حضور و غیاب و امور شهریه دوره‌های حسابداری</p>
        </div>
        <div class="hero-actions">
            <a class="btn btn-gold" href="<?= e(url('tms')) ?>">📚 مدیریت دوره‌ها و ثبت‌نام</a>
            <a class="btn btn-primary" href="<?= e(url('portal')) ?>">👥 پرونده‌های آموزشی</a>
            <a class="btn btn-outline" style="background:rgba(255,255,255,0.12);color:#fff" href="<?= e(url('finance')) ?>">🧾 شهریه و پرداخت‌ها</a>
        </div>
    </div>

    <div class="grid grid-4">
        <div class="stat-card">
            <div><div class="stat-label">ثبت‌نام‌های دوره‌ای</div><div class="stat-value"><?= fa(count($roleScoped['org_enrollments'])) ?> مورد</div><div class="stat-meta">در حال آموزش یا تکمیل‌شده</div></div>
            <div class="stat-icon icon-teal">👥</div>
        </div>
        <div class="stat-card">
            <div><div class="stat-label">صورتحساب‌های شهریه</div><div class="stat-value"><?= fa(count($roleScoped['org_invoices'])) ?> فاکتور</div><div class="stat-meta">قابل پیگیری در پرونده دانشجو</div></div>
            <div class="stat-icon icon-gold">🧾</div>
        </div>
        <div class="stat-card">
            <div><div class="stat-label">درخواست‌های آموزش</div><div class="stat-value">میزکار آدان</div><div class="stat-meta"><a href="<?= e(url('role-workstations')) ?>">بررسی درخواست‌ها ←</a></div></div>
            <div class="stat-icon icon-blue">✅</div>
        </div>
        <div class="stat-card">
            <div><div class="stat-label">یادگیری دانشجویان</div><div class="stat-value">کلاس و درس</div><div class="stat-meta"><a href="<?= e(url('lms')) ?>">پیگیری روند یادگیری ←</a></div></div>
            <div class="stat-icon icon-purple">💼</div>
        </div>
    </div>

    <div class="card" style="margin-top:16px">
        <div class="card-header"><div class="card-title">وضعیت ثبت‌نام، دوره و حضور دانشجویان</div><a class="btn btn-primary btn-sm" href="<?= e(url('portal')) ?>">پرونده‌های آموزشی</a></div>
        <div class="table-wrap">
            <table>
                <thead><tr><th>نام دانشجو</th><th>عنوان دوره</th><th>کد کلاس</th><th>حضور</th><th>وضعیت</th></tr></thead>
                <tbody>
                <?php foreach ($roleScoped['org_enrollments'] as $oe): ?>
                    <tr>
                        <td><strong><?= e($oe['full_name']) ?></strong></td>
                        <td><?= e($oe['course_title']) ?></td>
                        <td><code><?= e($oe['run_code']) ?></code></td>
                        <td><?= fa($oe['attendance_pct'] ?? 100) ?>٪</td>
                        <td><span class="badge badge-success"><?= e($oe['status']) ?></span></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

<?php else: ?>
    <!-- ==================== ۷. پیشخوان کاملاً شخصی ویژه فراگیر (بدون هیچ اطلاعات مدیریتی) ==================== -->
    <div class="hero-banner">
        <div>
            <span class="badge badge-gold">فضای یادگیری شخصی من • <?= e(Auth::roleLabel($curRoleKey)) ?> • سطح <?= fa($hud['level_num']) ?> (<?= e($hud['rank_title']) ?>)</span>
            <h1>سلام، <?= e($currentUser['full_name']) ?> عزیز! آماده ادامه یادگیری هستید؟ 🎓</h1>
            <p>مشاهده دوره‌های ثبت‌نام‌شده شما، ادامه ویدئوهای تعاملی LMS، مرور ۳ دقیقه‌ای کارت‌های لایتنر، آزمون‌ها و گواهی‌نامه‌های معتبر QR شما</p>
        </div>
        <div class="hero-actions">
            <a class="btn btn-gold" href="<?= e(url('lms')) ?>">▶️ ورود فوری به کلاس هوشمند (LMS)</a>
            <a class="btn btn-primary" href="<?= e(url('microlearning')) ?>">🧠 مرور ۳ دقیقه‌ای لایتنر</a>
            <a class="btn btn-outline" style="background:rgba(255,255,255,0.12);color:#fff" href="<?= e(url('exams')) ?>">🏅 آزمون و گواهی QR من</a>
        </div>
    </div>

    <div class="grid grid-4">
        <div class="stat-card">
            <div><div class="stat-label">دوره‌های ثبت‌نام‌شده من</div><div class="stat-value"><?= fa(max(1, count($roleScoped['my_enrollments']))) ?> دوره</div><div class="stat-meta">فعال در پرونده آموزشی من</div></div>
            <div class="stat-icon icon-teal">📚</div>
        </div>
        <div class="stat-card">
            <div><div class="stat-label">درس‌های تکمیل‌شده من در LMS</div><div class="stat-value"><?= fa($roleScoped['my_completed_lessons']) ?> درس</div><div class="stat-meta">همراه یادداشت ثانیه‌ای و آزمونک</div></div>
            <div class="stat-icon icon-blue">🎬</div>
        </div>
        <div class="stat-card">
            <div><div class="stat-label">امتیاز تجربه و سکه مهارت من</div><div class="stat-value"><?= fa(number_format($hud['xp_points'])) ?> XP</div><div class="stat-meta">🔥 <?= fa($hud['streak_days']) ?> روز پیوستگی • 🪙 <?= fa($hud['chamber_coins']) ?> سکه</div></div>
            <div class="stat-icon icon-gold">⭐</div>
        </div>
        <div class="stat-card">
            <div><div class="stat-label">گواهی‌نامه‌های معتبر QR من</div><div class="stat-value"><?= fa($roleScoped['my_certs_count']) ?> گواهی</div><div class="stat-meta"><a href="<?= e(url('exams')) ?>">مشاهده و استعلام گواهی‌نامه‌ها ←</a></div></div>
            <div class="stat-icon icon-purple">🏅</div>
        </div>
    </div>

    <?php
    // ★ v26.8 — ویترین «مربی هوشمند یادگیری من»: بریفینگ صوتی، منحنی فراموشی، کارت خودکار، آزمون خودساز و برنامه هفتگی
    $cBrief = is_array($coachBriefing ?? null) ? $coachBriefing : [];
    $cFeat  = is_array($coach['features'] ?? null) ? $coach['features'] : [];
    $cFor   = is_array($coach['forecast'] ?? null) ? $coach['forecast'] : [];
    $cPlan  = is_array($coach['plan'] ?? null) ? $coach['plan'] : [];
    $cCta = [
        'voice_briefing'  => ['🎙️ پخش با صدا', null],
        'personal_cards'  => ['🃏 ساخت کارت از یادداشت‌ها', ['tab' => 'mycards']],
        'self_quiz'       => ['🎯 ساخت آزمون خودساز', ['tab' => 'selfquiz']],
        'forgetting'      => ['🧠 مرور کارت‌های سررسیدشده', ['tab' => 'leitner']],
        'weekly_plan'     => ['🗓️ دیدن برنامه و تقویم', ['tab' => 'capsules']],
    ];
    ?>
    <div class="card" style="margin-bottom:16px;border:1.5px solid color-mix(in srgb, var(--primary) 32%, var(--border));background:linear-gradient(135deg,color-mix(in srgb,var(--primary) 8%,var(--surface)),color-mix(in srgb,#7c3aed 7%,var(--surface)))">
        <div class="card-header">
            <div class="card-title">🤖 مربی هوشمند یادگیری من — گزارش صوتی و تحلیل شخصی</div>
            <div style="display:flex;gap:6px;flex-wrap:wrap">
                <button type="button" class="btn btn-gold btn-sm" onclick="window.speakPersianReply && window.speakPersianReply(<?= js_attr($cBrief['speech_text'] ?? '') ?>)">🔊 پخش بریفینگ امروز</button>
                <button type="button" class="btn btn-outline btn-sm" onclick="window.stopPersianSpeech && window.stopPersianSpeech()">⏹ توقف</button>
                <button type="button" class="btn btn-primary btn-sm" onclick="window.runVoiceCommandText && window.runVoiceCommandText('بریفینگ امروز من')">📻 گزارش کامل با صدا</button>
            </div>
        </div>
        <div class="grid grid-2" style="gap:14px;align-items:start">
            <div>
                <p style="font-size:13px;line-height:2.05;margin:0 0 10px"><?= e($cBrief['narrative'] ?? 'برای شروع، بریفینگ صوتی امروز را پخش کنید.') ?></p>
                <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px">
                    <?php foreach (($cBrief['chips'] ?? []) as $cChip): ?>
                        <span class="badge badge-info"><?= e(is_array($cChip) ? (string)($cChip['text'] ?? '') : (string)$cChip) ?></span>
                    <?php endforeach; ?>
                </div>
                <div class="muted" style="font-size:12px;line-height:1.9">🎯 <?= e($cBrief['next_action'] ?? '') ?></div>
                <?php if (!empty($cFor['advice'])): ?>
                    <div class="alert alert-info" style="margin:10px 0 0;font-size:12.3px">🧠 <?= e($cFor['advice']) ?></div>
                <?php endif; ?>
                <div class="muted" style="font-size:11.5px;margin-top:8px">🎙️ طول این بریفینگ حدود <?= fa((int)($cBrief['est_duration_sec'] ?? 45)) ?> ثانیه است و با کد <?= e((string)($cBrief['report_code'] ?? '') !== '' ? (string)$cBrief['report_code'] : 'بریفینگ شخصی') ?> در گزارش‌های صوتی شما ثبت می‌شود.</div>
            </div>
            <div style="border:1px solid var(--border);border-radius:14px;padding:12px;background:var(--surface)">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;gap:8px;flex-wrap:wrap">
                    <strong style="font-size:12.6px">📉 منحنی فراموشی <?= fa((int)($cFor['horizon_days'] ?? 14)) ?> روزه کارت‌های من</strong>
                    <span class="badge <?= (int)($cFor['retention_pct'] ?? 0) >= 70 ? 'badge-success' : 'badge-danger' ?>">میانگین حفظ: <?= fa((int)round((float)($cFor['retention_pct'] ?? 0))) ?>٪</span>
                </div>
                <?php if (!empty($cFor['sparkline'])): ?>
                    <svg viewBox="0 0 300 74" preserveAspectRatio="none" style="width:100%;height:80px" role="img" aria-label="نمودار درصد حفظ مفهومی در روزهای آینده">
                        <defs>
                            <linearGradient id="coachSparkFill" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="0%" stop-color="#0f766e" stop-opacity=".30"/>
                                <stop offset="100%" stop-color="#0f766e" stop-opacity="0"/>
                            </linearGradient>
                        </defs>
                        <path d="<?= e($cFor['sparkline']) ?> L 300 74 L 0 74 Z" fill="url(#coachSparkFill)" stroke="none"/>
                        <path d="<?= e($cFor['sparkline']) ?>" fill="none" stroke="#0f766e" stroke-width="2.4" stroke-linecap="round"/>
                    </svg>
                <?php else: ?>
                    <p class="muted" style="font-size:12.5px;margin:0">برای دیدن این نمودار، حداقل یک کارت در جعبه لایتنر شما لازم است.</p>
                <?php endif; ?>
                <?php if (!empty($cFor['fading'])): ?>
                    <div style="margin-top:8px;font-size:12.4px;line-height:1.95">
                        <strong>کارت‌هایی که کمرنگ می‌شوند:</strong>
                        <?php foreach (array_slice($cFor['fading'], 0, 3) as $fCard): ?>
                            <div class="muted">• <?= e($fCard['prompt']) ?> — حفظ <?= fa((int)$fCard['retention_pct']) ?>٪<?php if (!empty($fCard['personal'])): ?> • کارت شخصی من<?php endif; ?></div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
                <div class="muted" style="font-size:11.6px;margin-top:6px">💡 <?= e($cFor['saved_note'] ?? '') ?></div>
                <a class="btn btn-outline btn-sm" href="<?= e(url('microlearning', ['tab' => 'leitner'])) ?>" style="margin-top:8px">🧠 مرور همین کارت‌ها در جعبه لایتنر</a>
            </div>
        </div>

        <?php if ($cFeat !== []): ?>
            <div style="border-top:1px dashed color-mix(in srgb,var(--primary) 30%,var(--border));margin-top:12px;padding-top:12px">
                <div style="font-size:12px;color:var(--text-muted);margin-bottom:8px">پنج قابلیت هوشمند فعال روی همین صفحه — همه فقط روی داده‌های شخصی شما:</div>
                <div class="grid grid-4" style="gap:10px">
                    <?php foreach ($cFeat as $cF): ?>
                        <?php $cKey = (string)($cF['key'] ?? ''); [$cLabel, $cQ] = $cCta[$cKey] ?? ['🚀 رفتن به بخش', null]; ?>
                        <div style="border:1px solid var(--border);border-radius:12px;padding:10px;background:var(--surface)">
                            <div style="font-size:12.6px;font-weight:700;margin-bottom:4px"><?= e($cF['icon'] ?? '✨') ?> <?= e($cF['title'] ?? '') ?></div>
                            <div style="font-size:11.8px;font-weight:600;color:var(--primary);margin-bottom:3px"><?= e($cF['state'] ?? '') ?></div>
                            <div class="muted" style="font-size:11.3px;line-height:1.7"><?= e($cF['hint'] ?? '') ?></div>
                            <?php if ($cQ === null): ?>
                                <button type="button" class="btn btn-gold btn-sm" style="margin-top:7px"
                                        onclick="window.speakPersianReply && window.speakPersianReply(<?= js_attr($cBrief['speech_text'] ?? '') ?>)"><?= e($cLabel) ?></button>
                            <?php else: ?>
                                <a class="btn <?= $cKey === 'self_quiz' ? 'btn-primary' : 'btn-gold' ?> btn-sm" style="margin-top:7px"
                                   href="<?= e(url('microlearning', $cQ)) ?>"><?= e($cLabel) ?></a>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>

        <?php if (!empty($cPlan['days'])): ?>
            <div style="margin-top:12px">
                <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;margin-bottom:8px">
                    <strong style="font-size:12.6px">🗓️ برنامه هفتگی تطبیقی من — <?= fa((int)$cPlan['total_minutes']) ?> دقیقه در ۷ روز</strong>
                    <span style="display:flex;gap:6px;flex-wrap:wrap">
                        <span class="badge badge-warning"><?= fa((int)$cPlan['pending_lessons']) ?> درس عقب‌افتاده</span>
                        <span class="badge badge-info"><?= fa((int)$cPlan['notes_count']) ?> یادداشت قابل تبدیل به کارت</span>
                    </span>
                </div>
                <div class="grid grid-4" style="gap:8px">
                    <?php foreach ($cPlan['days'] as $cDay): ?>
                        <div style="border:1px solid var(--border);border-radius:12px;padding:9px;background:var(--surface)">
                            <div style="display:flex;justify-content:space-between;gap:6px;font-size:12px;font-weight:700">
                                <span><?= e($cDay['label']) ?></span>
                                <span class="muted" style="font-weight:500"><?= fa((int)$cDay['minutes']) ?>′</span>
                            </div>
                            <?php foreach (array_slice($cDay['items'], 0, 3) as $cItem): ?>
                                <div style="font-size:11.3px;line-height:1.75">• <?= e(is_array($cItem) ? (string)($cItem['text'] ?? '') : (string)$cItem) ?></div>
                            <?php endforeach; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div class="muted" style="font-size:11.4px;margin-top:8px">📄 <?= e($cPlan['print_note'] ?? '') ?></div>
            </div>
        <?php endif; ?>
    </div>

    <div class="card" style="margin-top:16px">
        <div class="card-header">
            <div class="card-title">کلاس‌ها و مسیر یادگیری فعال من</div>
            <div style="display:flex;gap:8px">
                <a class="btn btn-primary btn-sm" href="<?= e(url('lms')) ?>">ادامه تماشای درس در LMS</a>
                <a class="btn btn-outline btn-sm" href="<?= e(url('tms')) ?>">ثبت‌نام در دوره جدید</a>
            </div>
        </div>
        <div class="table-wrap">
            <table>
                <thead><tr><th>عنوان دوره من</th><th>کد کلاس</th><th>برنامه برگزاری</th><th>وضعیت ثبت‌نام</th><th>ورود مستقیم</th></tr></thead>
                <tbody>
                <?php foreach ($roleScoped['my_enrollments'] as $me): ?>
                    <tr>
                        <td><strong><?= e($me['course_title']) ?></strong></td>
                        <td><code><?= e($me['run_code']) ?></code></td>
                        <td><?= e($me['schedule_text']) ?></td>
                        <td><span class="badge badge-success"><?= e($me['status']) ?></span></td>
                        <td><a class="btn btn-primary btn-sm" href="<?= e(url('lms', ['course_id' => (int)$me['course_id']])) ?>">▶️ ورود به کلاس</a></td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($roleScoped['my_enrollments'])): ?>
                    <tr>
                        <td colspan="5">شما هم‌اکنون به کلاس آزمایشی «جامع کاربردی اینکوترمز ۲۰۲۰» دسترسی دارید — <a href="<?= e(url('lms')) ?>"><strong>ورود به کلاس هوشمند LMS ←</strong></a></td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php endif; ?>
