<?php use App\Core\Auth; ?>
<div class="hero-banner">
    <div>
        <span class="badge badge-gold">مدیریت ارتباط با دانشجویان و سازمان‌ها (CRM)</span>
        <h1>CRM آموزشی: پذیرش، سازمان‌ها و قراردادهای آموزشی</h1>
        <p>پیگیری درخواست پذیرش دوره، سرنخ‌های آموزشی، ارتباط با سازمان‌های طرف قرارداد و فرصت‌های ثبت‌نام گروهی.</p>
    </div>
</div>

<?php if (!$canViewCampaigns): ?>
    <div class="alert alert-warning">
        <div>
            <strong>کنترل دسترسی نقش‌محور (RBAC):</strong> شما با نقش «<?= e(Auth::roleLabel()) ?>» وارد شده‌اید؛ <strong>فهرست کمپین‌های CRM برای نقش نمایندهٔ سازمان بسته است و دسترسی آن صرفاً مدیریتی است.</strong>
        </div>
        <a class="btn btn-outline btn-sm" href="<?= e(url('crm', ['section' => 'campaigns'])) ?>">تست قفل امنیتی کمپین</a>
    </div>
<?php endif; ?>

<?php if ($canViewCampaigns): ?>
<div class="card">
    <div class="card-header">
        <div class="card-title">🎓 درخواست‌های پذیرش دوره‌های آدان</div>
        <span class="badge badge-info"><?= fa(count($admissions)) ?> درخواست</span>
    </div>
    <div class="table-wrap">
        <table>
            <thead>
            <tr><th>متقاضی</th><th>دوره</th><th>ثبت درخواست</th><th>وضعیت</th><th>بررسی / ثبت‌نام</th></tr>
            </thead>
            <tbody>
            <?php foreach ($admissions as $admission): ?>
                <tr>
                    <td>
                        <strong><?= e($admission['full_name']) ?></strong>
                        <div class="muted"><?= e($admission['mobile']) ?></div>
                        <?php if (!empty($admission['prior_education'])): ?>
                            <div class="muted"><?= e($admission['prior_education']) ?></div>
                        <?php endif; ?>
                    </td>
                    <td><?= e($admission['course_title']) ?></td>
                    <td><?= e($admission['submitted_at']) ?></td>
                    <td>
                        <span class="badge <?= $admission['status'] === 'enrolled' ? 'badge-success' : 'badge-warning' ?>">
                            <?= e($admission['status']) ?>
                        </span>
                        <?php if (!empty($admission['username'])): ?>
                            <div class="muted">ورود: <code><?= e($admission['username']) ?></code></div>
                            <div class="muted">فاکتور: <?= e($admission['invoice_number'] ?? '') ?> (<?= e($admission['invoice_status'] ?? '') ?>)</div>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if (in_array($admission['status'], ['submitted', 'contacted', 'accepted'], true)): ?>
                            <form method="post" action="<?= e(url('crm')) ?>" style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:8px">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="update_admission_status">
                                <input type="hidden" name="admission_id" value="<?= (int)$admission['id'] ?>">
                                <select name="status" style="width:auto">
                                    <option value="contacted">در حال پیگیری</option>
                                    <option value="accepted" <?= $admission['status'] === 'accepted' ? 'selected' : '' ?>>پذیرفته‌شده</option>
                                    <option value="rejected">رد درخواست</option>
                                </select>
                                <input type="text" name="review_note" value="<?= e($admission['review_note'] ?? '') ?>" placeholder="یادداشت بررسی">
                                <button type="submit" class="btn btn-outline btn-sm">ثبت وضعیت</button>
                            </form>
                        <?php endif; ?>
                        <?php if ($admission['status'] === 'accepted'): ?>
                            <?php $matchingRuns = array_filter($admissionRuns, static fn($run) => (int)$run['course_id'] === (int)$admission['course_id'] && (int)$run['enrolled_count'] < (int)$run['capacity']); ?>
                            <?php if ($matchingRuns): ?>
                                <form method="post" action="<?= e(url('crm')) ?>" class="form-grid" style="align-items:end">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action" value="enroll_admission">
                                    <input type="hidden" name="admission_id" value="<?= (int)$admission['id'] ?>">
                                    <select name="run_id" required>
                                        <?php foreach ($matchingRuns as $run): ?>
                                            <option value="<?= (int)$run['id'] ?>">
                                                <?= e($run['run_code']) ?> — <?= e($run['term_label']) ?> (<?= fa($run['capacity'] - $run['enrolled_count']) ?> ظرفیت)
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <input type="password" name="initial_password" minlength="12" autocomplete="new-password" placeholder="گذرواژه اولیه، حداقل ۱۲ نویسه" required>
                                    <button type="submit" class="btn btn-primary btn-sm">ثبت‌نام و صدور فاکتور</button>
                                </form>
                            <?php else: ?>
                                <span class="muted">برای این دوره اجرای باز با ظرفیت خالی وجود ندارد.</span>
                            <?php endif; ?>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$admissions): ?>
                <tr><td colspan="5" class="muted">هنوز درخواست پذیرشی ثبت نشده است.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<!-- VISUAL KANBAN PIPELINE -->
<div class="card">
    <div class="card-header"><div class="card-title">📊 قیف فروش بصری قراردادهای سازمانی (Sales Funnel Kanban)</div></div>
    <?php
    $stages = [
        'lead' => 'سرنخ اولیه',
        'qualified' => 'ارزیابی نیاز',
        'proposal' => 'ارسال پروپوزال',
        'negotiation' => 'مذاکره نهایی',
        'won' => 'عقد قرارداد (موفق)',
    ];
    ?>
    <div class="kanban-row">
        <?php foreach ($stages as $sKey => $sLabel): ?>
            <div class="kanban-col">
                <div style="font-weight:800;font-size:13px;display:flex;justify-content:space-between">
                    <span><?= e($sLabel) ?></span>
                    <span class="badge badge-info">
                        <?= fa(count(array_filter($deals, static fn($d) => $d['stage'] === $sKey))) ?>
                    </span>
                </div>
                <?php foreach ($deals as $dl): ?>
                    <?php if ($dl['stage'] !== $sKey) continue; ?>
                    <div class="kanban-card">
                        <div style="font-weight:800;font-size:12.5px"><?= e($dl['title']) ?></div>
                        <div class="muted" style="font-size:11.5px;margin:4px 0"><?= e($dl['org_name']) ?></div>
                        <div style="font-size:12px;color:var(--primary);font-weight:700"><?= rial($dl['estimated_value_rial']) ?></div>
                        <div class="muted" style="font-size:11px;margin-top:4px">پیگیری بعدی: <?= e($dl['next_followup_shamsi']) ?></div>
                        <?php if ($canViewCampaigns): ?>
                            <form method="post" action="<?= e(url('crm')) ?>" style="margin-top:6px;display:flex;gap:4px">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="move_stage">
                                <input type="hidden" name="deal_id" value="<?= (int)$dl['id'] ?>">
                                <select name="stage" style="padding:3px 6px;font-size:11px">
                                    <?php foreach ($stages as $k => $v): ?>
                                        <option value="<?= e($k) ?>" <?= $k === $sKey ? 'selected' : '' ?>><?= e($v) ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <button type="submit" class="btn btn-outline btn-sm">انتقال</button>
                            </form>
                            <?php if ($dl['stage'] === 'won'): ?>
                                <form method="post" action="<?= e(url('crm')) ?>" style="margin-top:5px">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action" value="convert_deal_to_contract">
                                    <input type="hidden" name="deal_id" value="<?= (int)$dl['id'] ?>">
                                    <button type="submit" class="btn btn-primary btn-sm" style="width:100%">⚡ تبدیل به قرارداد رسمی</button>
                                </form>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<div class="grid grid-2">
    <!-- KEY CONTACTS & LEAD SCORING -->
    <div class="card">
        <div class="card-header"><div class="card-title">👔 مدیران کلیدی و امتیاز سرنخ (Lead Scoring)</div></div>
        <div class="table-wrap">
            <table>
                <thead><tr><th>نام مدیر / سازمان</th><th>آخرین تعامل</th><th>امتیاز سرنخ</th></tr></thead>
                <tbody>
                <?php foreach ($contacts as $ct): ?>
                    <tr>
                        <td>
                            <strong><?= e($ct['full_name']) ?></strong>
                            <div class="muted" style="font-size:11.5px"><?= e($ct['position_title']) ?> — <?= e($ct['org_name']) ?></div>
                        </td>
                        <td><?= e($ct['last_interaction']) ?></td>
                        <td><span class="badge badge-success"><?= fa($ct['lead_score']) ?> / ۱۰۰</span></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- CREATE DEAL OR VIEW CAMPAIGNS (MANAGEMENT ONLY) -->
    <?php if ($canViewCampaigns): ?>
        <div class="card">
            <div class="card-header"><div class="card-title">➕ ثبت فرصت فروش جدید + کمپین‌های مدیریتی CRM</div></div>
            <form method="post" action="<?= e(url('crm')) ?>" style="margin-bottom:16px">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="create_deal">
                <div class="form-grid">
                    <div class="form-group">
                        <label>سازمان دانش‌پذیر آدان:</label>
                        <select name="org_id">
                            <?php foreach ($orgs as $o): ?>
                                <option value="<?= (int)$o['id'] ?>"><?= e($o['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>ارزش برآوردی (ریال):</label>
                        <input type="number" name="estimated_value_rial" value="950000000">
                    </div>
                </div>
                <div class="form-group">
                    <label>عنوان فرصت آموزشی:</label>
                    <input type="text" name="title" required placeholder="مثلاً: بسته جامع آموزش صادرات ۲۰ کارشناس">
                </div>
                <input type="hidden" name="stage" value="proposal">
                <input type="hidden" name="probability_pct" value="70">
                <input type="hidden" name="next_followup_shamsi" value="۱۴۰۵/۰۸/۱۲">
                <button type="submit" class="btn btn-primary btn-sm">افزودن به قیف فروش</button>
            </form>

            <div style="border-top:1px solid var(--border);padding-top:12px">
                <strong style="font-size:13px">📣 کمپین‌های فعال CRM (ویژه نقش‌های مدیریتی):</strong>
                <?php foreach ($campaigns as $cmp): ?>
                    <div style="font-size:12.5px;margin-top:6px;display:flex;justify-content:space-between">
                        <span><?= e($cmp['title']) ?> (بخش: <?= e($cmp['segment_name']) ?>)</span>
                        <span class="badge badge-purple"><?= e($cmp['status']) ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endif; ?>
</div>
