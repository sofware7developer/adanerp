<?php use App\Core\Auth; ?>
<div class="hero-banner">
    <div>
        <span class="badge badge-gold">قراردادهای کلان بنگاه‌های عضو</span>
        <h1>قراردادهای سازمانی، سهمیه ظرفیت، تمدید و گردش تصویب</h1>
        <p>ثبت و پایش قراردادهای سالانه شرکت‌های صنعتی و صادراتی استان، اتصال مستقیم ظرفیت به پورتال سازمان و کنترل پرداخت‌های قراردادی.</p>
    </div>
</div>

<div class="grid grid-sidebar">
    <div class="card">
        <div class="card-header"><div class="card-title">📄 فهرست قراردادهای سازمانی و مصرف سهمیه نفر-دوره</div></div>
        <div class="table-wrap">
            <table>
                <thead>
                <tr>
                    <th>شماره / سازمان</th>
                    <th>مبلغ کل / وصولی</th>
                    <th>مصرف ظرفیت</th>
                    <th>اعتبار</th>
                    <th>مرحله تصویب</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($contracts as $cnt): ?>
                    <?php $pct = min(100, (int)round(((int)$cnt['seats_used'] / max(1, (int)$cnt['seat_quota'])) * 100)); ?>
                    <tr>
                        <td>
                            <strong><?= e($cnt['contract_no']) ?> — <?= e($cnt['org_name']) ?></strong>
                            <div class="muted" style="font-size:12px"><?= e($cnt['title']) ?></div>
                            <a class="btn btn-outline btn-sm" style="margin-top:4px" href="<?= e(url('contract-print?id=' . (int)$cnt['id'])) ?>" target="_blank">📜 چاپ قرارداد حقوقی تیپ</a>
                        </td>
                        <td>
                            <?= rial($cnt['total_amount_rial']) ?>
                            <div class="muted" style="font-size:11.5px">وصولی: <?= rial($cnt['paid_amount_rial']) ?></div>
                        </td>
                        <td style="min-width:130px">
                            <div style="font-size:11.5px;margin-bottom:3px"><?= fa($cnt['seats_used']) ?> از <?= fa($cnt['seat_quota']) ?> نفر (<?= fa($pct) ?>٪)</div>
                            <div class="progress-track"><div class="progress-fill" style="width:<?= $pct ?>%"></div></div>
                        </td>
                        <td><?= e($cnt['start_shamsi']) ?> تا <?= e($cnt['end_shamsi']) ?></td>
                        <td>
                            <span class="badge <?= $cnt['approval_stage'] === 'approved_active' ? 'badge-success' : 'badge-warning' ?>"><?= e($cnt['approval_stage']) ?></span>
                            <?php if ($cnt['approval_stage'] !== 'approved_active' && Auth::hasRole(['super_admin', 'finance_manager'])): ?>
                                <form method="post" action="<?= e(url('contracts')) ?>" style="margin-top:4px">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action" value="approve_contract">
                                    <input type="hidden" name="contract_id" value="<?= (int)$cnt['id'] ?>">
                                    <button type="submit" class="btn btn-primary btn-sm">تصویب نهایی</button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php if (Auth::hasRole(['super_admin', 'crm_manager', 'finance_manager', 'training_expert'])): ?>
        <div class="card">
            <div class="card-header"><div class="card-title">➕ تنظیم پیش‌نویس قرارداد سازمانی جدید</div></div>
            <form method="post" action="<?= e(url('contracts')) ?>">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="create_contract">
                <div class="form-group">
                    <label>سازمان طرف قرارداد:</label>
                    <select name="org_id">
                        <?php foreach ($orgs as $o): ?>
                            <option value="<?= (int)$o['id'] ?>"><?= e($o['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>عنوان قرارداد:</label>
                    <input type="text" name="title" required placeholder="قرارداد جامع آموزش صادرات و هوش مصنوعی">
                </div>
                <div class="form-grid">
                    <div class="form-group">
                        <label>مبلغ کل قرارداد (ریال):</label>
                        <input type="number" name="total_amount_rial" value="1650000000">
                    </div>
                    <div class="form-group">
                        <label>سقف ظرفیت (نفر-دوره):</label>
                        <input type="number" name="seat_quota" value="45">
                    </div>
                </div>
                <div class="form-group">
                    <label>شرح ردیف‌ها و تعهدات آموزشی:</label>
                    <textarea name="deliverables_summary" rows="3">اجرای ۴ کارگاه تخصصی + صدور گواهی QR دوزبانه</textarea>
                </div>
                <button type="submit" class="btn btn-primary" style="width:100%">ثبت قرارداد و ارسال به تایید مالی</button>
            </form>
        </div>
    <?php endif; ?>
</div>

<!-- v14.0 B2B CONTRACT QUOTA BURN-RATE MONITOR -->
<div class="card" style="margin-top:18px;border:1.5px solid rgba(201,146,39,0.35)">
    <div class="card-header">
        <div>
            <div class="card-title">پایشگر هوشمند نرخ مصرف سهمیه قراردادهای سازمانی (B2B Quota Burn-Rate &amp; Auto-Upsell Monitor)</div>
            <div class="muted" style="font-size:12px">مقایسه خودکار درصد زمان سپری‌شده سال قراردادی با درصد سهمیه مصرفی جهت جلوگیری از سوخت سهمیه یا پیشنهاد بهنگام الحاقیه</div>
        </div>
        <span class="badge badge-gold">ضدریزش قرارداد B2B</span>
    </div>
    <div class="table-wrap">
        <table>
            <thead><tr><th>سازمان طرف قرارداد</th><th>عنوان قرارداد</th><th>زمان سپری‌شده</th><th>سهمیه مصرف‌شده</th><th>تشخیص هوشمند وضعیت</th><th>اقدام خودکار اجراشده</th></tr></thead>
            <tbody>
            <?php foreach (($burnAlerts ?? []) as $ba): ?>
                <tr>
                    <td><strong><?= e($ba['org_name']) ?></strong></td>
                    <td><?= e($ba['contract_title']) ?></td>
                    <td><?= fa($ba['elapsed_year_pct']) ?>٪ سال</td>
                    <td><strong><?= fa($ba['quota_used_pct']) ?>٪ سهمیه</strong></td>
                    <td><span class="badge <?= (int)$ba['quota_used_pct'] < 40 ? 'badge-danger' : 'badge-success' ?>"><?= e($ba['burn_status']) ?></span></td>
                    <td style="font-size:12px"><?= e($ba['auto_triggered_offer']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

