<div class="hero-banner">
    <div>
        <span class="badge badge-gold">پرورش مدیران ارشد بنگاه‌ها</span>
        <h1>توسعه رهبری، شبیه‌ساز تصمیم‌گیری وزن‌دار، ۳۶۰ و منتورینگ</h1>
        <p>برنامه‌های مدیریتی ویژه اعضای هیئت‌مدیره و مدیران عامل صنایع استان همراه با ماتریس تصمیم‌گیری چندمعیاره وزن‌دار.</p>
    </div>
</div>

<?php foreach ($programs as $prg): ?>
    <?php $weights = json_decode((string)$prg['criteria_weights_json'], true) ?: []; ?>
    <div class="grid grid-sidebar">
        <div class="card">
            <div class="card-header">
                <div class="card-title">🏛️ شبیه‌ساز تعاملی تصمیم‌گیری استراتژیک با معیارهای وزن‌دار</div>
                <span class="badge badge-success">امتیاز کل موزون: <span id="leadershipWeightedScore">84.0 از ۱۰۰</span></span>
            </div>
            <p class="muted" style="margin-bottom:14px">
                لغزنده‌های زیر را تغییر دهید تا امتیاز موزون استراتژی سرمایه‌گذاری صادراتی شرکت بر پایه وزن معیارها به صورت زنده محاسبه شود:
            </p>
            <?php $i = 0; foreach ($weights as $crit => $weight): $i++; ?>
                <div style="margin-bottom:14px">
                    <div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:4px">
                        <strong><?= e($crit) ?> (وزن معیار: <?= fa($weight) ?>٪)</strong>
                        <span>امتیاز انتخابی: <strong id="sim_c<?= $i ?>_val">85</strong> / 100</span>
                    </div>
                    <input type="range" min="20" max="100" value="85" id="sim_c<?= $i ?>"
                           class="leadership-sim-input" data-weight="<?= (int)$weight ?>" style="width:100%">
                </div>
            <?php endforeach; ?>
        </div>

        <div class="card">
            <div class="card-header"><div class="card-title">📋 شناسنامه برنامه مدیریتی</div></div>
            <p><strong>عنوان برنامه:</strong> <?= e($prg['title']) ?></p>
            <p><strong>دوره / کوهورت:</strong> <?= e($prg['cohort_name']) ?> (<?= fa($prg['participants_count']) ?> مدیر ارشد)</p>
            <p><strong>میانگین ارزیابی ۳۶۰ درجه رهبری:</strong> <span class="badge badge-gold"><?= fa($prg['avg_360_score']) ?> از ۵</span></p>
            <div class="alert alert-info" style="margin-top:12px">
                <div><strong>تکلیف منتورینگ اجرایی:</strong> <?= e($prg['mentoring_assignment']) ?></div>
            </div>
        </div>
    </div>
<?php endforeach; ?>

<!-- v14.0 EXECUTIVE CEO CRISIS WAR-ROOM SIMULATOR -->
<div class="card" style="margin-top:18px;border:1.5px solid rgba(201,146,39,0.4)">
    <div class="card-header">
        <div>
            <div class="card-title">شبیه‌ساز اتاق جنگ بحران مدیران عامل و هیئت‌مدیره (Executive Crisis War-Room Simulator)</div>
            <div class="muted" style="font-size:12px">آزمون تصمیم‌گیری استراتژیک مدیران صنایع در برابر شوک‌های ارزی، لجستیکی و تعرفه‌های کربنی با داوری هوش مصنوعی</div>
        </div>
        <span class="badge badge-gold">Harvard-Style Case Engine</span>
    </div>
    <form method="post" action="<?= e(url('leadership')) ?>" class="grid grid-2" style="gap:10px;margin-bottom:14px" onsubmit="if(!window.location.protocol.startsWith('http')||typeof PAGES!=='undefined'){event.preventDefault();window.runWarRoomClient();}">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="run_warroom">
        <div>
            <label>سناریوی بحران کلان اقتصادی / صادراتی:</label>
            <select id="warShock" name="shock_scenario">
                <option>شوک جهش ۳۵٪ نرخ ارز مواد اولیه هم‌زمان با اعمال تعرفه کربن مرزی اروپا (EU CBAM)</option>
                <option>افزایش ناگهانی ۴۰٪ کرایه حمل کانتینری و اختلال کشتیرانی دریایی</option>
                <option>محدودیت ۴۵ روزه برق/گاز زمستانی شهرک صنعتی در اوج تعهد تحویل صادراتی</option>
            </select>
        </div>
        <div>
            <label>بسته استراتژیک مصوب مدیرعامل در اتاق جنگ:</label>
            <select id="warStrat" name="chosen_strategy">
                <option>پوشش سلف ارزی + انتقال ۴۰٪ سبد صادرات به اتحادیه تعرفه‌صفر اوراسیا + تغییر ترم به FCA</option>
                <option>توقف موقت صادرات، کاهش ظرفیت تولید و تمرکز صرف بر فروش ریالی داخلی</option>
            </select>
        </div>
        <div style="grid-column:1 / -1">
            <button type="submit" class="btn btn-gold">اجرای شبیه‌سازی بحران و دریافت داوری هیئت‌مدیره هوشمند</button>
        </div>
    </form>
    <div id="warClientBox" style="display:none;margin-bottom:12px;padding:12px;border-radius:10px;background:var(--surface-2);border:1px solid var(--gold);font-size:12.5px"></div>

    <div class="table-wrap">
        <table>
            <thead><tr><th>کد نشست</th><th>مدیر ارشد</th><th>سناریوی بحران</th><th>دوام نقدینگی</th><th>حفظ بازار صادرات</th><th>امتیاز تاب‌آوری</th><th>داوری هوش مصنوعی</th></tr></thead>
            <tbody>
            <?php foreach (($warSims ?? []) as $ws): ?>
                <tr>
                    <td><code><?= e($ws['sim_code']) ?></code></td>
                    <td><strong><?= e($ws['ceo_participant']) ?></strong></td>
                    <td style="font-size:12px"><?= e($ws['shock_scenario']) ?></td>
                    <td><strong><?= fa((string)$ws['cashflow_runway_months']) ?> ماه</strong></td>
                    <td><?= fa($ws['export_share_retention_pct']) ?>٪</td>
                    <td><span class="badge badge-success"><?= fa($ws['resilience_score']) ?> / ۱۰۰</span></td>
                    <td style="font-size:11.5px;max-width:300px"><?= e($ws['board_ai_critique']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

