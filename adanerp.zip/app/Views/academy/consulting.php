<?php use App\Core\Auth; ?>
<div class="hero-banner">
    <div>
        <span class="badge badge-gold">کلینیک مشاوره و منتورینگ تخصصی</span>
        <h1>مشاوره و منتورینگ: رزرو جلسه، دستور جلسه و یادداشت محرمانه</h1>
        <p>رزرو بازه‌های مشاوره تجاری/حقوقی/آموزشی، ثبت دستور جلسه، اقدامات پیگیری و حفاظت سخت‌گیرانه از یادداشت‌های محرمانه مشاور.</p>
    </div>
</div>

<div class="alert alert-info">
    <div>
        <strong>وضعیت تقویم و حریم محرمانگی:</strong> تقویم اسلات‌محور مشاور در نسخه فعلی بر اساس انتخاب بازه‌های زمانی از پیش تعریف‌شده عمل می‌کند (هماهنگ‌سازی خودکار دوطرفه با تقویم خارجی هنوز محدود است). همچنین <strong>یادداشت محرمانه مشاور صرفاً برای خود مشاور و مدیرکل نمایش داده می‌شود.</strong>
    </div>
</div>

<div class="grid grid-sidebar">
    <div class="card">
        <div class="card-header"><div class="card-title">🗂️ جلسات مشاوره و پیگیری مصوبات</div></div>
        <?php foreach ($sessions as $s): ?>
            <div style="border:1px solid var(--border);border-radius:14px;padding:15px;margin-bottom:14px">
                <div style="display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap">
                    <strong><?= e($s['topic']) ?></strong>
                    <span class="badge badge-info"><?= e($s['slot_label']) ?> | <?= e($s['status']) ?></span>
                </div>
                <div class="muted" style="font-size:12px;margin:5px 0">
                    مشاور: <?= e($s['consultant_name']) ?> | مراجع: <?= e($s['client_name']) ?>
                </div>
                <div style="font-size:13px"><strong>دستور جلسه:</strong> <?= e($s['agenda']) ?></div>
                <?php if (!empty($s['action_items'])): ?>
                    <div style="font-size:12.5px;color:var(--primary);margin-top:4px"><strong>تکلیف و پیگیری:</strong> <?= e($s['action_items']) ?></div>
                <?php endif; ?>

                <?php if ($canSeeConfidential): ?>
                    <form method="post" action="<?= e(url('consulting')) ?>" style="margin-top:10px;background:var(--surface-2);padding:10px;border-radius:10px">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="save_consultant_notes">
                        <input type="hidden" name="session_id" value="<?= (int)$s['id'] ?>">
                        <div class="form-group">
                            <label>🔐 یادداشت محرمانه مشاور (غیرقابل رؤیت برای مراجع):</label>
                            <textarea name="confidential_note" rows="2"><?= e($s['confidential_note'] ?? '') ?></textarea>
                        </div>
                        <div class="form-group">
                            <label>اقدامات پیگیری بعدی:</label>
                            <input type="text" name="action_items" value="<?= e($s['action_items'] ?? '') ?>">
                        </div>
                        <button type="submit" class="btn btn-primary btn-sm">ذخیره پرونده مشاوره</button>
                    </form>
                <?php else: ?>
                    <div class="muted" style="font-size:11.5px;margin-top:8px">🔒 یادداشت محرمانه مشاور به دلیل حفظ محرمانگی حرفه‌ای برای نقش شما نمایش داده نمی‌شود.</div>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="card">
        <div class="card-header"><div class="card-title">📅 رزرو نوبت مشاوره جدید</div></div>
        <form method="post" action="<?= e(url('consulting')) ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="book_session">
            <div class="form-group">
                <label>موضوع مشاوره:</label>
                <input type="text" name="topic" required placeholder="مثلاً: بررسی اسناد اعتبار اسنادی LC صادراتی">
            </div>
            <div class="form-group">
                <label>انتخاب بازه زمانی مشاور:</label>
                <select name="slot_label">
                    <option value="یکشنبه ۱۴۰۵/۰۸/۱۰ - ساعت ۱۵:۰۰ الی ۱۶:۳۰">یکشنبه ۱۴۰۵/۰۸/۱۰ — ۱۵:۰۰ الی ۱۶:۳۰</option>
                    <option value="سه‌شنبه ۱۴۰۵/۰۸/۱۲ - ساعت ۱۶:۳۰ الی ۱۸:۰۰">سه‌شنبه ۱۴۰۵/۰۸/۱۲ — ۱۶:۳۰ الی ۱۸:۰۰</option>
                    <option value="پنجشنبه ۱۴۰۵/۰۸/۱۴ - ساعت ۱۰:۰۰ الی ۱۱:۳۰">پنجشنبه ۱۴۰۵/۰۸/۱۴ — ۱۰:۰۰ الی ۱۱:۳۰</option>
                </select>
            </div>
            <div class="form-group">
                <label>شرح دستور جلسه (Agenda):</label>
                <textarea name="agenda" rows="3" required placeholder="پرسش‌ها و مستندات مورد بحث..."></textarea>
            </div>
            <button type="submit" class="btn btn-primary" style="width:100%">ثبت درخواست جلسه</button>
        </form>
    </div>
</div>
