<?php
use App\Core\Jalali;
use App\Core\QrSvg;

$board = $workspace['active_dashboard'];
$builder = $workspace['builder_result'];
$kpis = $workspace['executive_kpis'];
$goals = $workspace['goals'];
$verifyPayload = 'BI-BOARD-' . $board['id'] . '-' . Jalali::today();
?>
<div style="max-width:980px;margin:24px auto;padding:0 16px">
    <div class="no-print" style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
        <a href="<?= e(url('bi', ['dashboard_id' => (int)$board['id']])) ?>" class="btn btn-outline">← بازگشت به مرکز هوش تجاری</a>
        <button type="button" class="btn btn-primary" onclick="window.print()">🖨️ چاپ رسمی گزارش A4 / ذخیره PDF</button>
    </div>

    <div class="card" style="padding:32px;border:2px solid var(--border)">
        <div style="display:flex;justify-content:space-between;align-items:center;border-bottom:2px solid var(--primary);padding-bottom:16px;margin-bottom:22px">
            <div>
                <div class="muted" style="font-size:12px">گزارش رسمی تحلیلی هوش تجاری و پایش عملکرد سازمانی</div>
                <h1 style="font-size:21px;margin:4px 0"><?= e($board['title']) ?></h1>
                <div style="font-size:12.5px;color:var(--text-muted)">تاریخ صدور: <?= e(Jalali::today()) ?> • واحد صادرکننده: سامانه هوش تجاری مؤسسه آموزشی آدان</div>
            </div>
            <div style="text-align:center">
                <?= QrSvg::render($verifyPayload, 84) ?>
                <div style="font-size:10px;color:var(--text-muted);margin-top:3px">اصالت گزارش BI</div>
            </div>
        </div>

        <div class="grid grid-4" style="margin-bottom:20px">
            <div style="background:var(--surface-2);padding:12px;border-radius:10px">
                <div class="muted" style="font-size:11px">مجموع صورت‌حساب‌ها</div>
                <strong><?= fa(number_format((float)$kpis['total_revenue_rial'])) ?> ریال</strong>
            </div>
            <div style="background:var(--surface-2);padding:12px;border-radius:10px">
                <div class="muted" style="font-size:11px">پایپ‌لاین قراردادهای سازمانی</div>
                <strong><?= fa(number_format((float)$kpis['crm_pipeline_rial'])) ?> ریال</strong>
            </div>
            <div style="background:var(--surface-2);padding:12px;border-radius:10px">
                <div class="muted" style="font-size:11px">میانگین تحقق اهداف OKR</div>
                <strong><?= fa($kpis['avg_goal_pct']) ?>٪</strong>
            </div>
            <div style="background:var(--surface-2);padding:12px;border-radius:10px">
                <div class="muted" style="font-size:11px">شاخص رضایت دوره‌ها</div>
                <strong><?= fa($kpis['courses_satisfaction_pct']) ?>٪</strong>
            </div>
        </div>

        <h3 style="margin-bottom:10px">۱. جدول تفصیلی گزارش فعال: <?= e($builder['metric_label']) ?> بر اساس <?= e($builder['dimension_label']) ?></h3>
        <div class="table-wrap" style="margin-bottom:22px">
            <table>
                <thead>
                <tr>
                    <th>رتبه</th>
                    <th><?= e($builder['dimension_label']) ?></th>
                    <th><?= e($builder['metric_label']) ?></th>
                    <th>تعداد رکورد</th>
                    <th>سهم از کل</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($builder['rows'] as $r): ?>
                    <tr>
                        <td><?= fa($r['rank']) ?></td>
                        <td><strong><?= e($r['label']) ?></strong></td>
                        <td><?= fa(number_format((float)$r['value'])) ?></td>
                        <td><?= fa($r['records_cnt']) ?></td>
                        <td><?= fa($r['share_pct']) ?>٪</td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <h3 style="margin-bottom:10px">۲. کارنامه تحقق اهداف راهبردی (OKR)</h3>
        <div class="table-wrap">
            <table>
                <thead>
                <tr>
                    <th>کد هدف</th>
                    <th>عنوان هدف راهبردی</th>
                    <th>واحد مسئول</th>
                    <th>عملکرد فعلی</th>
                    <th>هدف مصوب</th>
                    <th>درصد تحقق</th>
                    <th>وضعیت</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($goals as $g): ?>
                    <tr>
                        <td><code><?= e($g['goal_code']) ?></code></td>
                        <td><?= e($g['title']) ?></td>
                        <td><?= e($g['department_owner']) ?></td>
                        <td><?= fa(number_format((float)$g['current_actual'])) ?> <?= e($g['unit_label']) ?></td>
                        <td><?= fa(number_format((float)$g['target_value'])) ?> <?= e($g['unit_label']) ?></td>
                        <td><strong><?= fa($g['achievement_pct']) ?>٪</strong></td>
                        <td><span class="badge badge-<?= e($g['rag_badge']) ?>"><?= e($g['status_label']) ?></span></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
