<?php
use App\Core\Jalali;

$kpis = $workspace['executive_kpis'];
$board = $workspace['active_dashboard'];
$dashboards = $workspace['dashboards'];
$widgets = $workspace['widgets'];
$builder = $workspace['builder_result'];
$goals = $workspace['goals'];
$anomalies = $workspace['anomalies'];
$martsJson = json_encode($workspace['data_marts'], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
$builderJson = json_encode($builder, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
$widgetsClientMap = [];
foreach ($widgets as $wRow) {
    $widgetsClientMap[(int)$wRow['id']] = [
        'id'         => (int)$wRow['id'],
        'title'      => $wRow['title'],
        'subtitle'   => $wRow['subtitle'],
        'chart_type' => $wRow['chart_type'],
        'col_span'   => (int)$wRow['col_span'],
        'palette'    => $wRow['color_palette'],
        'data'       => $wRow['live_data'],
    ];
}
$widgetsJson = json_encode($widgetsClientMap, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
?>
<style>
.bi-omni-shell {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius-lg);
    padding: 16px 18px;
    margin-bottom: 18px;
    box-shadow: var(--shadow-sm);
}
.bi-omni-row {
    display: flex;
    gap: 10px;
    align-items: center;
    flex-wrap: wrap;
}
.bi-omni-input {
    flex: 1;
    min-width: 260px;
    background: var(--surface-2);
    border: 1.5px solid var(--border);
    border-radius: 12px;
    padding: 10px 14px;
    font-size: 13.5px;
    color: var(--text);
    transition: border-color .2s, box-shadow .2s;
}
.bi-omni-input:focus {
    outline: none;
    border-color: var(--primary);
    box-shadow: 0 0 0 3px var(--primary-soft);
}
.bi-mic-btn {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    background: linear-gradient(135deg, #e11d48, #be123c);
    color: #fff;
    border: none;
    border-radius: 12px;
    padding: 10px 16px;
    font-weight: 700;
    font-size: 13px;
    cursor: pointer;
    box-shadow: 0 4px 12px rgba(225, 29, 72, .25);
    transition: transform .15s, box-shadow .2s;
}
.bi-mic-btn:hover { transform: translateY(-1px); }
.bi-mic-btn.recording {
    animation: biPulseMic 1.15s infinite;
    background: linear-gradient(135deg, #dc2626, #991b1b);
}
@keyframes biPulseMic {
    0% { box-shadow: 0 0 0 0 rgba(220, 38, 38, .55); }
    70% { box-shadow: 0 0 0 12px rgba(220, 38, 38, 0); }
    100% { box-shadow: 0 0 0 0 rgba(220, 38, 38, 0); }
}
.bi-chip-bar {
    display: flex;
    gap: 7px;
    flex-wrap: wrap;
    margin-top: 10px;
}
.bi-prompt-chip {
    background: var(--surface-2);
    border: 1px solid var(--border);
    color: var(--text-muted);
    padding: 4px 11px;
    border-radius: 999px;
    font-size: 12px;
    cursor: pointer;
    transition: all .15s;
}
.bi-prompt-chip:hover {
    border-color: var(--primary);
    color: var(--primary);
    background: var(--primary-soft);
}
.bi-mode-pill {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    font-size: 11.5px;
    font-weight: 700;
    padding: 3px 10px;
    border-radius: 999px;
    background: var(--primary-soft);
    color: var(--primary);
}
.bi-grid-12 {
    display: grid;
    grid-template-columns: repeat(12, minmax(0, 1fr));
    gap: 16px;
}
.bi-col-3 { grid-column: span 3; }
.bi-col-4 { grid-column: span 4; }
.bi-col-6 { grid-column: span 6; }
.bi-col-8 { grid-column: span 8; }
.bi-col-12 { grid-column: span 12; }
@media (max-width: 1100px) {
    .bi-col-3, .bi-col-4, .bi-col-6, .bi-col-8 { grid-column: span 6; }
}
@media (max-width: 760px) {
    .bi-col-3, .bi-col-4, .bi-col-6, .bi-col-8, .bi-col-12 { grid-column: span 12; }
}
.bi-widget-card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 15px 16px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    transition: transform .16s, box-shadow .16s, border-color .16s;
    position: relative;
}
.bi-widget-card[draggable="true"] { cursor: grab; }
.bi-widget-card.dragging { opacity: .45; transform: scale(.98); }
.bi-widget-card.drag-over {
    border: 2px dashed var(--primary);
    box-shadow: 0 0 0 4px var(--primary-soft);
}
.bi-dropzone {
    border: 2px dashed var(--border);
    border-radius: 13px;
    padding: 11px 13px;
    background: var(--surface-2);
    transition: all .18s;
    min-height: 54px;
}
.bi-dropzone.active-drop {
    border-color: var(--primary);
    background: var(--primary-soft);
    transform: scale(1.01);
}
.bi-drag-chip {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 6px 11px;
    margin: 3px;
    border-radius: 9px;
    font-size: 12px;
    font-weight: 600;
    background: var(--surface);
    border: 1px solid var(--border);
    cursor: grab;
    user-select: none;
    transition: all .14s;
}
.bi-drag-chip:hover {
    border-color: var(--primary);
    color: var(--primary);
    transform: translateY(-1px);
}
.bi-drag-chip.metric-chip { border-right: 3px solid #10b981; }
.bi-drag-chip.dim-chip { border-right: 3px solid #4f46e5; }
.bi-drag-chip.chart-chip { border-right: 3px solid #d97706; }
.bi-tab-nav {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
    margin-bottom: 16px;
    background: var(--surface);
    padding: 8px;
    border-radius: 14px;
    border: 1px solid var(--border);
}
.bi-tab-btn {
    border: none;
    background: transparent;
    color: var(--text-muted);
    font-weight: 700;
    font-size: 13px;
    padding: 8px 15px;
    border-radius: 10px;
    cursor: pointer;
    transition: all .16s;
}
.bi-tab-btn.active {
    background: var(--primary);
    color: #fff;
    box-shadow: 0 4px 12px rgba(79, 70, 229, .22);
}
.bi-canvas-drop-banner {
    border: 2px dashed var(--border);
    border-radius: 14px;
    padding: 12px 16px;
    text-align: center;
    color: var(--text-muted);
    font-size: 12.5px;
    margin-bottom: 16px;
    background: var(--surface);
    transition: all .2s;
}
.bi-canvas-drop-banner.active-drop {
    border-color: #10b981;
    background: rgba(16, 185, 129, .09);
    color: #059669;
    font-weight: 700;
}
.bi-mini-select {
    padding: 3px 7px !important;
    font-size: 11.5px !important;
    border-radius: 8px !important;
    width: auto !important;
    height: 28px !important;
}
</style>

<!-- HERO HEADER -->
<div class="hero-banner">
    <div>
        <span class="badge badge-gold">سامانه جامع هوش تجاری، تحلیل داده و تصمیم‌یاری مدیران</span>
        <h1>مرکز جامع هوش تجاری (BI)، گزارش‌ساز، داشبوردساز و هدف‌گذاری راهبردی</h1>
        <p>طراحی بلادرنگ انواع گزارش‌ها، جداول محوری، داشبوردهای مدیریتی و اهداف کمی (OKR) به ۴ روش یکپارچه: <strong>کلیکی، درگ‌انددراپ، فرمان صوتی فارسی و دستور متنی هوشمند</strong> با اتصال زنده به جداول عملیاتی.</p>
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
        <a class="btn btn-gold" id="biExportCsvTopBtn" href="<?= e(url('bi', ['export' => 'csv', 'dataset_key' => $builder['dataset_key'], 'dimension_field' => $builder['dimension_field'], 'metric_field' => $builder['metric_field'], 'agg_func' => $builder['agg_func']])) ?>">📥 خروجی Excel / CSV</a>
        <a class="btn btn-outline" style="background:rgba(255,255,255,.12);color:#fff;border-color:rgba(255,255,255,.28)" target="_blank" href="<?= e(url('bi-report-print', ['dashboard_id' => $dashboardId])) ?>">🖨️ چاپ رسمی A4 داشبورد</a>
        <button type="button" class="btn btn-outline" style="background:rgba(255,255,255,.12);color:#fff;border-color:rgba(255,255,255,.28)" onclick="speakExecutiveBiSummary()">🔊 روایت صوتی وضعیت</button>
    </div>
</div>

<!-- ۴ روش ساخت یکپارچه: نوار هوشمند متنی + میکروفون صوتی فارسی + شبیه‌ساز سریع -->
<div class="bi-omni-shell">
    <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;margin-bottom:10px">
        <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
            <strong style="font-size:14px">✨ دستیار چهارحالته ساخت گزارش، داشبورد و هدف:</strong>
            <span class="bi-mode-pill">🖱️ کلیکی</span>
            <span class="bi-mode-pill">🖐️ درگ و دراپ</span>
            <span class="bi-mode-pill">🎙️ فرمان صوتی</span>
            <span class="bi-mode-pill">⌨️ متن طبیعی فارسی</span>
        </div>
        <span id="biLiveStatusBadge" class="badge badge-success">آماده دریافت فرمان صوتی، متنی یا درگ‌انددراپ</span>
    </div>

    <form method="post" action="<?= e(url('bi', ['dashboard_id' => $dashboardId])) ?>" id="biOmniForm">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="nl_or_voice_build">
        <input type="hidden" name="build_mode" id="biBuildModeInput" value="text">
        <div class="bi-omni-row">
            <button type="button" class="bi-mic-btn" id="biVoiceMicBtn" onclick="toggleBiVoiceRecognition()">
                <span id="biMicIcon">🎙️</span>
                <span id="biMicLabel">فرمان صوتی فارسی</span>
            </button>
            <input type="text" name="natural_prompt" id="biNaturalPromptInput" class="bi-omni-input"
                   placeholder="بنویسید یا بگویید: مثلاً «نمودار حلقوی صورتحساب‌ها بر اساس وضعیت پرداخت» یا «داشبورد جدید پایش هیئت‌رییسه بساز» یا «هدف درآمد نیمسال را ۶۵۰ میلیون ریال ثبت کن»...">
            <button type="button" class="btn btn-outline" onclick="runInstantNlPreview('text')">⚡ پیش‌نمایش آنی بدون رفرش</button>
            <button type="submit" class="btn btn-primary">🚀 ساخت و ذخیره در سامانه</button>
        </div>
    </form>

    <div class="bi-chip-bar">
        <span class="muted" style="font-size:12px;align-self:center">نمونه‌های ۱-کلیکی (متنی / صوتی):</span>
        <button type="button" class="bi-prompt-chip" onclick="triggerSampleCommand('نمودار حلقوی صورتحساب‌ها بر اساس وضعیت پرداخت', 'text')">🍩 سهم وضعیت صورتحساب‌ها</button>
        <button type="button" class="bi-prompt-chip" onclick="triggerSampleCommand('قیف فروش سازمانی CRM و مبلغ قراردادهای پیشنهادی', 'text')">🔻 قیف فروش سازمانی CRM</button>
        <button type="button" class="bi-prompt-chip" onclick="triggerSampleCommand('مقایسه راداری بودجه دفاتر نمایندگی شهرستان‌ها', 'voice')">🎙️ شبیه‌ساز صوتی: رادار شعب استان</button>
        <button type="button" class="bi-prompt-chip" onclick="triggerSampleCommand('ویجت تعداد نامه‌های اتوماسیون اداری بر اساس فوریت به داشبورد اضافه شود', 'voice')">📌 افزودن صوتی ویجت به داشبورد</button>
        <button type="button" class="bi-prompt-chip" onclick="triggerSampleCommand('داشبورد جدید به نام پایش عملکرد فصلی هیئت‌رییسه بساز', 'text')">🗂️ ساخت متنی داشبورد جدید</button>
        <button type="button" class="bi-prompt-chip" onclick="triggerSampleCommand('هدف فروش قراردادهای سازمانی را ۱۸۰۰ میلیون ریال ثبت کن', 'voice')">🎯 ثبت صوتی هدف راهبردی</button>
    </div>
</div>

<!-- EXECUTIVE KPI SUMMARY STRIP -->
<div class="grid grid-4" style="margin-bottom:18px">
    <div class="stat-card">
        <div>
            <div class="muted" style="font-size:12px">مجموع صورت‌حساب‌های آموزشی</div>
            <div class="stat-value" style="font-size:21px;margin:4px 0"><?= fa(number_format((float)$kpis['total_revenue_rial'])) ?> <small style="font-size:11px">ریال</small></div>
            <span class="badge badge-success">متصل به خزانه زنده</span>
        </div>
    </div>
    <div class="stat-card">
        <div>
            <div class="muted" style="font-size:12px">ارزش پایپ‌لاین قراردادهای سازمانی</div>
            <div class="stat-value" style="font-size:21px;margin:4px 0"><?= fa(number_format((float)$kpis['crm_pipeline_rial'])) ?> <small style="font-size:11px">ریال</small></div>
            <span class="badge badge-info">مذاکرات فعال B2B</span>
        </div>
    </div>
    <div class="stat-card">
        <div>
            <div class="muted" style="font-size:12px">میانگین تحقق اهداف راهبردی (OKR)</div>
            <div class="stat-value" style="font-size:21px;margin:4px 0;color:var(--primary)"><?= fa($kpis['avg_goal_pct']) ?>٪</div>
            <span class="badge badge-gold"><?= fa(count($goals)) ?> شاخص هدف‌گذاری‌شده</span>
        </div>
    </div>
    <div class="stat-card">
        <div>
            <div class="muted" style="font-size:12px">زیست‌بوم گزارش و داشبورد</div>
            <div class="stat-value" style="font-size:21px;margin:4px 0"><?= fa($kpis['total_dashboards']) ?> داشبورد | <?= fa($kpis['total_reports']) ?> گزارش</div>
            <span class="badge badge-purple">رضایت دوره‌ها: <?= fa($kpis['courses_satisfaction_pct']) ?>٪</span>
        </div>
    </div>
</div>

<!-- TABS NAVIGATION -->
<div class="bi-tab-nav" role="tablist">
    <button type="button" class="bi-tab-btn <?= $activeTab === 'dashboards' ? 'active' : '' ?>" data-bi-tab="dashboards" onclick="switchBiStudioTab('dashboards', this)">🗂️ داشبورد و داشبوردساز (Drag &amp; Drop)</button>
    <button type="button" class="bi-tab-btn <?= $activeTab === 'builder' ? 'active' : '' ?>" data-bi-tab="builder" onclick="switchBiStudioTab('builder', this)">🛠️ گزارش‌ساز ۴ حالته و جدول پیوت</button>
    <button type="button" class="bi-tab-btn <?= $activeTab === 'catalog' ? 'active' : '' ?>" data-bi-tab="catalog" onclick="switchBiStudioTab('catalog', this)">📚 بانک جامع گزارش‌های آماده (<?= fa(count($workspace['preset_catalog']) + count($workspace['custom_reports'])) ?>)</button>
    <button type="button" class="bi-tab-btn <?= $activeTab === 'goals' ? 'active' : '' ?>" data-bi-tab="goals" onclick="switchBiStudioTab('goals', this)">🎯 هدف‌گذاری راهبردی (OKR) و عقربه تحقق</button>
    <button type="button" class="bi-tab-btn <?= $activeTab === 'whatif' ? 'active' : '' ?>" data-bi-tab="whatif" onclick="switchBiStudioTab('whatif', this)">🔮 شبیه‌ساز سناریو، ناهنجاری و ارسال خودکار</button>
</div>

<!-- ======================================================================= -->
<!-- TAB 1: EXECUTIVE DASHBOARDS & DRAG-AND-DROP DASHBOARD STUDIO           -->
<!-- ======================================================================= -->
<section id="biSection_dashboards" class="bi-studio-section" style="display:<?= $activeTab === 'dashboards' ? 'block' : 'none' ?>">
    <!-- نوار انتخاب داشبورد + ساخت داشبورد جدید + پالت درگ‌انددراپ ویجت -->
    <div class="card" style="margin-bottom:16px">
        <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;margin-bottom:12px">
            <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
                <strong style="font-size:13.5px">انتخاب تخته داشبورد:</strong>
                <?php foreach ($dashboards as $b): ?>
                    <a href="<?= e(url('bi', ['tab' => 'dashboards', 'dashboard_id' => (int)$b['id']])) ?>"
                       class="btn btn-sm <?= (int)$b['id'] === $dashboardId ? 'btn-primary' : 'btn-outline' ?>">
                        <?= e($b['title']) ?>
                    </a>
                <?php endforeach; ?>
            </div>
            <div style="display:flex;gap:8px;flex-wrap:wrap">
                <button type="button" class="btn btn-sm btn-outline" onclick="document.getElementById('newBoardCollapse').style.display = document.getElementById('newBoardCollapse').style.display === 'none' ? 'block' : 'none'">➕ ایجاد داشبورد جدید</button>
                <button type="button" class="btn btn-sm btn-gold" onclick="document.getElementById('widgetPaletteCollapse').style.display = document.getElementById('widgetPaletteCollapse').style.display === 'none' ? 'block' : 'none'">🧩 جعبه ابزار ویجت‌ها (کلیک و درگ‌انددراپ)</button>
            </div>
        </div>

        <!-- فرم سریع ساخت داشبورد جدید -->
        <div id="newBoardCollapse" style="display:none;border-top:1px solid var(--border);padding-top:12px;margin-top:10px">
            <form method="post" action="<?= e(url('bi')) ?>" class="grid grid-4" style="align-items:end">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="create_dashboard">
                <input type="hidden" name="created_via" value="click">
                <div>
                    <label>عنوان داشبورد جدید:</label>
                    <input type="text" name="title" required placeholder="مثلاً: داشبورد کمیسیون صادرات و گمرک">
                </div>
                <div>
                    <label>زیرعنوان توضیحی:</label>
                    <input type="text" name="subtitle" value="پایش لحظه‌ای شاخص‌های کلیدی و نمودارهای زنده">
                </div>
                <div>
                    <label>حوزه سازمانی:</label>
                    <select name="category">
                        <option value="مدیریت کلان">مدیریت کلان</option>
                        <option value="مالی و بودجه">مالی و بودجه</option>
                        <option value="آموزش و پژوهش">آموزش و پژوهش</option>
                        <option value="فروش و امور اعضا">فروش و امور اعضا</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary">ایجاد داشبورد با ویجت‌های پایه</button>
            </form>
        </div>

        <!-- پالت ویجت‌های آماده قابل کشیدن و رها کردن روی بوم داشبورد -->
        <div id="widgetPaletteCollapse" style="display:block;border-top:1px dashed var(--border);padding-top:12px;margin-top:8px">
            <div style="font-size:12.5px;color:var(--text-muted);margin-bottom:8px">
                🖐️ <strong>راهنمای درگ‌انددراپ و کلیک:</strong> هر یک از ویجت‌های آماده زیر را با ماوس بکشید و روی کادر نقطه‌چین بوم داشبورد رها کنید (یا روی آن دابل‌کلیک کنید)؛ همچنین می‌توانید کارت‌های داشبورد را بکشید و جابه‌جا کنید یا نوع نمودار و عرض هر کارت را درجا تغییر دهید:
            </div>
            <div>
                <span class="bi-drag-chip chart-chip" draggable="true"
                      ondragstart="onPaletteWidgetDragStart(event, {title:'تحلیل شهریه دوره‌ها به تفکیک شیوه اجرا',dataset_key:'courses_mart',dimension_field:'delivery_mode',metric_field:'tuition_rial',agg_func:'SUM',chart_type:'bar',col_span:6})"
                      ondblclick="dropNewWidgetAjax({title:'تحلیل شهریه دوره‌ها به تفکیک شیوه اجرا',dataset_key:'courses_mart',dimension_field:'delivery_mode',metric_field:'tuition_rial',agg_func:'SUM',chart_type:'bar',col_span:6,created_via:'click'})">📊 + ستونی شهریه شیوه برگزاری</span>

                <span class="bi-drag-chip chart-chip" draggable="true"
                      ondragstart="onPaletteWidgetDragStart(event, {title:'سهم روش‌های تسویه صورت‌حساب‌ها',dataset_key:'invoices_mart',dimension_field:'payment_mode',metric_field:'total_rial',agg_func:'SUM',chart_type:'donut',col_span:4})"
                      ondblclick="dropNewWidgetAjax({title:'سهم روش‌های تسویه صورت‌حساب‌ها',dataset_key:'invoices_mart',dimension_field:'payment_mode',metric_field:'total_rial',agg_func:'SUM',chart_type:'donut',col_span:4,created_via:'click'})">🍩 + حلقوی روش‌های تسویه</span>

                <span class="bi-drag-chip chart-chip" draggable="true"
                      ondragstart="onPaletteWidgetDragStart(event, {title:'قیف تبدیل مذاکرات سازمانی CRM',dataset_key:'crm_mart',dimension_field:'stage',metric_field:'estimated_value_rial',agg_func:'SUM',chart_type:'funnel',col_span:6})"
                      ondblclick="dropNewWidgetAjax({title:'قیف تبدیل مذاکرات سازمانی CRM',dataset_key:'crm_mart',dimension_field:'stage',metric_field:'estimated_value_rial',agg_func:'SUM',chart_type:'funnel',col_span:6,created_via:'click'})">🔻 + قیف فروش سازمانی</span>

                <span class="bi-drag-chip chart-chip" draggable="true"
                      ondragstart="onPaletteWidgetDragStart(event, {title:'رادار عملکرد بودجه دفاتر شهرستان‌ها',dataset_key:'branches_mart',dimension_field:'county_name',metric_field:'spent_budget_rial',agg_func:'SUM',chart_type:'radar',col_span:6})"
                      ondblclick="dropNewWidgetAjax({title:'رادار عملکرد بودجه دفاتر شهرستان‌ها',dataset_key:'branches_mart',dimension_field:'county_name',metric_field:'spent_budget_rial',agg_func:'SUM',chart_type:'radar',col_span:6,created_via:'click'})">🕸️ + رادار شعب شهرستان‌ها</span>

                <span class="bi-drag-chip chart-chip" draggable="true"
                      ondragstart="onPaletteWidgetDragStart(event, {title:'ماتریس حرارتی مکاتبات بر اساس فوریت',dataset_key:'oa_mart',dimension_field:'priority_level',metric_field:'id',agg_func:'COUNT',chart_type:'heatmap',col_span:4})"
                      ondblclick="dropNewWidgetAjax({title:'ماتریس حرارتی مکاتبات بر اساس فوریت',dataset_key:'oa_mart',dimension_field:'priority_level',metric_field:'id',agg_func:'COUNT',chart_type:'heatmap',col_span:4,created_via:'click'})">🟧 + ماتریس فوریت نامه‌ها</span>

                <span class="bi-drag-chip chart-chip" draggable="true"
                      ondragstart="onPaletteWidgetDragStart(event, {title:'تقاضای استخدام صنایع به تفکیک شهر',dataset_key:'career_mart',dimension_field:'city_location',metric_field:'applicants_count',agg_func:'SUM',chart_type:'hbar',col_span:4})"
                      ondblclick="dropNewWidgetAjax({title:'تقاضای استخدام صنایع به تفکیک شهر',dataset_key:'career_mart',dimension_field:'city_location',metric_field:'applicants_count',agg_func:'SUM',chart_type:'hbar',col_span:4,created_via:'click'})">💼 + افقی تقاضای اشتغال</span>
            </div>
        </div>
    </div>

    <!-- منطقه رهاسازی (Drop Target) برای افزودن درگ‌انددراپ ویجت جدید به بوم -->
    <div id="biDashboardDropBanner" class="bi-canvas-drop-banner"
         ondragover="event.preventDefault(); this.classList.add('active-drop');"
         ondragleave="this.classList.remove('active-drop');"
         ondrop="handlePaletteDropOnDashboard(event)">
        ➕ ویجت دلخواه را از نوار بالا بکشید و <strong>اینجا رها کنید</strong> تا بلادرنگ در پایگاه‌داده ذخیره و روی «<?= e($board['title']) ?>» ترسیم شود (یا کارت‌های زیر را با کشیدن جابه‌جا کنید)
    </div>

    <!-- شبکه ۱۲ ستونی زنده ویجت‌های قابل جابه‌جایی و تغییر اندازه -->
    <div class="bi-grid-12" id="biLiveDashboardGrid">
        <?php foreach ($widgets as $w):
            $wid = (int)$w['id'];
            $span = in_array((int)$w['col_span'], [3, 4, 6, 8, 12], true) ? (int)$w['col_span'] : 6;
        ?>
            <div class="bi-widget-card bi-col-<?= $span ?>" data-widget-id="<?= $wid ?>" data-col-span="<?= $span ?>" draggable="true">
                <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px;margin-bottom:8px">
                    <div>
                        <div style="font-weight:800;font-size:14px;color:var(--text)">⠿ <?= e($w['title']) ?></div>
                        <div class="muted" style="font-size:11.5px"><?= e($w['subtitle']) ?> • <span class="badge badge-info" style="font-size:10px"><?= e($w['live_data']['agg_func']) ?></span></div>
                    </div>
                    <div style="display:flex;gap:4px;align-items:center;flex-wrap:wrap">
                        <select class="bi-mini-select" title="تغییر آنی نوع نمودار" onchange="changeWidgetChartLive(<?= $wid ?>, this.value)">
                            <?php foreach ($workspace['chart_types'] as $ck => $cl): ?>
                                <option value="<?= e($ck) ?>" <?= $w['chart_type'] === $ck ? 'selected' : '' ?>><?= e($cl) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <select class="bi-mini-select" title="عرض کارت در گرید ۱۲ ستونی" onchange="changeWidgetSpanLive(<?= $wid ?>, this.value)">
                            <option value="4" <?= $span === 4 ? 'selected' : '' ?>>۱/۳ عرض</option>
                            <option value="6" <?= $span === 6 ? 'selected' : '' ?>>۱/۲ عرض</option>
                            <option value="8" <?= $span === 8 ? 'selected' : '' ?>>۲/۳ عرض</option>
                            <option value="12" <?= $span === 12 ? 'selected' : '' ?>>تمام‌عرض</option>
                        </select>
                        <form method="post" action="<?= e(url('bi', ['dashboard_id' => $dashboardId])) ?>" style="display:inline">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="delete_widget">
                            <input type="hidden" name="dashboard_id" value="<?= $dashboardId ?>">
                            <input type="hidden" name="widget_id" value="<?= $wid ?>">
                            <button type="submit" class="btn btn-sm btn-outline" style="padding:2px 7px;color:var(--danger)" title="حذف ویجت">✕</button>
                        </form>
                    </div>
                </div>

                <div id="biWidgetChartBox_<?= $wid ?>" style="min-height:215px;display:flex;align-items:center;justify-content:center"></div>

                <div style="display:flex;justify-content:space-between;align-items:center;font-size:11.5px;color:var(--text-muted);border-top:1px solid var(--border);padding-top:8px;margin-top:8px">
                    <span>صدرنشین: <strong><?= e($w['live_data']['summary']['top_item']) ?></strong></span>
                    <span>جمع کل: <strong><?= fa(number_format((float)$w['live_data']['summary']['grand_total'])) ?></strong> <?= e($w['live_data']['unit']) ?></span>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<!-- ======================================================================= -->
<!-- TAB 2: MULTI-MODAL REPORT BUILDER (CLICK + DRAG & DROP + TEXT + VOICE) -->
<!-- ======================================================================= -->
<section id="biSection_builder" class="bi-studio-section" style="display:<?= $activeTab === 'builder' ? 'block' : 'none' ?>">
    <div class="bi-grid-12">
        <!-- ستون راست: دیکشنری داده قابل درگ‌انددراپ + تنظیمات کلیکی -->
        <div class="bi-col-4">
            <div class="card">
                <div class="card-header">
                    <div class="card-title">🧲 دیکشنری داده (کلیک یا Drag &amp; Drop)</div>
                </div>

                <div class="form-group">
                    <label>۱. انتخاب مخزن داده عملیاتی (۱۰ حوزه کلان):</label>
                    <select id="rbDatasetSelect" onchange="onBuilderDatasetChange()">
                        <?php foreach ($workspace['data_marts'] as $mKey => $mMeta): ?>
                            <option value="<?= e($mKey) ?>" <?= $builder['dataset_key'] === $mKey ? 'selected' : '' ?>><?= e($mMeta['label']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div style="margin-bottom:10px">
                    <div style="font-size:12px;font-weight:700;margin-bottom:5px;color:var(--primary)">🟦 ابعاد دسته‌بندی (بکشید و در «ردیف‌ها» رها کنید یا کلیک کنید):</div>
                    <div id="rbDraggableDims"></div>
                </div>

                <div style="margin-bottom:12px">
                    <div style="font-size:12px;font-weight:700;margin-bottom:5px;color:#059669">🟩 شاخص‌های عددی (بکشید و در «مقادیر» رها کنید یا کلیک کنید):</div>
                    <div id="rbDraggableMetrics"></div>
                </div>

                <!-- مناطق رهاسازی درگ‌انددراپ مشابه ابزارهای حرفه‌ای BI -->
                <div class="bi-dropzone" id="dzDimension" style="margin-bottom:10px"
                     ondragover="event.preventDefault(); this.classList.add('active-drop');"
                     ondragleave="this.classList.remove('active-drop');"
                     ondrop="onBuilderZoneDrop(event, 'dimension')">
                    <div class="muted" style="font-size:11px">منطقه رهاسازی محور دسته‌بندی (GROUP BY):</div>
                    <select id="rbDimSelect" onchange="runBuilderLiveQuery()" style="margin-top:4px"></select>
                </div>

                <div class="bi-dropzone" id="dzMetric" style="margin-bottom:10px"
                     ondragover="event.preventDefault(); this.classList.add('active-drop');"
                     ondragleave="this.classList.remove('active-drop');"
                     ondrop="onBuilderZoneDrop(event, 'metric')">
                    <div class="muted" style="font-size:11px">منطقه رهاسازی شاخص عددی و تابع تجمیع:</div>
                    <div class="form-grid" style="margin-top:4px">
                        <select id="rbMetricSelect" onchange="runBuilderLiveQuery()"></select>
                        <select id="rbAggSelect" onchange="runBuilderLiveQuery()">
                            <?php foreach ($workspace['agg_funcs'] as $ak => $al): ?>
                                <option value="<?= e($ak) ?>" <?= $builder['agg_func'] === $ak ? 'selected' : '' ?>><?= e($al) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div class="form-grid">
                    <div class="form-group">
                        <label>نوع نمایش نمودار:</label>
                        <select id="rbChartSelect" onchange="runBuilderLiveQuery()">
                            <?php foreach ($workspace['chart_types'] as $ck => $cl): ?>
                                <option value="<?= e($ck) ?>" <?= $builder['chart_type'] === $ck ? 'selected' : '' ?>><?= e($cl) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>ترتیب مرتب‌سازی:</label>
                        <select id="rbSortSelect" onchange="runBuilderLiveQuery()">
                            <option value="DESC">نزولی (بیشترین به کمترین)</option>
                            <option value="ASC">صعودی (کمترین به بیشترین)</option>
                        </select>
                    </div>
                </div>

                <div class="form-grid">
                    <div class="form-group">
                        <label>فیلتر روی ستون (اختیاری):</label>
                        <select id="rbFilterField" onchange="runBuilderLiveQuery()">
                            <option value="">بدون فیلتر محدودکننده</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>عبارت جست‌وجو / فیلتر:</label>
                        <input type="text" id="rbFilterVal" placeholder="مثلاً: فوری یا paid" oninput="runBuilderLiveQuery()">
                    </div>
                </div>

                <!-- فرم ذخیره گزارش یا سنجاق به داشبورد -->
                <form method="post" action="<?= e(url('bi')) ?>" style="border-top:1px solid var(--border);padding-top:12px;margin-top:8px">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="save_custom_report">
                    <input type="hidden" name="created_via" id="rbSaveViaInput" value="drag_drop">
                    <input type="hidden" name="dataset_key" id="rbFormDataset" value="<?= e($builder['dataset_key']) ?>">
                    <input type="hidden" name="dimension_field" id="rbFormDim" value="<?= e($builder['dimension_field']) ?>">
                    <input type="hidden" name="metric_field" id="rbFormMetric" value="<?= e($builder['metric_field']) ?>">
                    <input type="hidden" name="agg_func" id="rbFormAgg" value="<?= e($builder['agg_func']) ?>">
                    <input type="hidden" name="chart_type" id="rbFormChart" value="<?= e($builder['chart_type']) ?>">
                    <div class="form-group">
                        <label>عنوان ذخیره در بانک گزارش‌ها:</label>
                        <input type="text" name="title" id="rbSaveTitle" required value="گزارش تحلیلی <?= e($builder['dataset_label']) ?>">
                    </div>
                    <div style="display:flex;gap:8px;flex-wrap:wrap">
                        <button type="submit" class="btn btn-primary" style="flex:1">💾 ذخیره گزارش + تحلیل AI</button>
                        <button type="button" class="btn btn-gold" onclick="pinCurrentBuilderToDashboard()">📌 افزودن به داشبورد</button>
                    </div>
                </form>
            </div>
        </div>

        <!-- ستون چپ: خروجی بلادرنگ نمودار + جدول پیوت حرارتی + SQL شفاف -->
        <div class="bi-col-8">
            <div class="card" style="margin-bottom:16px">
                <div class="card-header">
                    <div>
                        <div class="card-title" id="rbPreviewTitle"><?= e($builder['metric_label']) ?> بر اساس <?= e($builder['dimension_label']) ?></div>
                        <div class="muted" style="font-size:12px" id="rbPreviewMeta"><?= e($builder['dataset_label']) ?> • <?= e($builder['agg_label']) ?></div>
                    </div>
                    <div style="display:flex;gap:6px;flex-wrap:wrap">
                        <a class="btn btn-sm btn-outline" id="rbCsvBtn" href="<?= e(url('bi', ['export' => 'csv', 'dataset_key' => $builder['dataset_key']])) ?>">📥 Excel / CSV</a>
                        <a class="btn btn-sm btn-outline" id="rbJsonBtn" target="_blank" href="<?= e(url('bi', ['export' => 'json', 'dataset_key' => $builder['dataset_key']])) ?>">{ } JSON</a>
                        <a class="btn btn-sm btn-gold" id="rbPrintBtn" target="_blank" href="<?= e(url('bi-report-print', ['dashboard_id' => $dashboardId, 'dataset_key' => $builder['dataset_key'], 'dimension_field' => $builder['dimension_field'], 'metric_field' => $builder['metric_field'], 'agg_func' => $builder['agg_func'], 'chart_type' => $builder['chart_type']])) ?>">🖨️ چاپ رسمی گزارش</a>
                    </div>
                </div>

                <!-- نوار خلاصه آماری زنده گزارش -->
                <div class="grid grid-4" style="margin-bottom:14px">
                    <div style="background:var(--surface-2);padding:10px 12px;border-radius:11px">
                        <div class="muted" style="font-size:11px">مجموع کل شاخص</div>
                        <strong style="font-size:16px" id="rbSumTotal"><?= fa(number_format((float)$builder['summary']['grand_total'])) ?></strong>
                    </div>
                    <div style="background:var(--surface-2);padding:10px 12px;border-radius:11px">
                        <div class="muted" style="font-size:11px">میانگین هر دسته</div>
                        <strong style="font-size:16px" id="rbAvgVal"><?= fa(number_format((float)$builder['summary']['average_val'])) ?></strong>
                    </div>
                    <div style="background:var(--surface-2);padding:10px 12px;border-radius:11px">
                        <div class="muted" style="font-size:11px">بیشترین مقدار ثبت‌شده</div>
                        <strong style="font-size:16px;color:var(--primary)" id="rbMaxVal"><?= fa(number_format((float)$builder['summary']['max_val'])) ?></strong>
                    </div>
                    <div style="background:var(--surface-2);padding:10px 12px;border-radius:11px">
                        <div class="muted" style="font-size:11px">رتبه اول (صدرنشین)</div>
                        <strong style="font-size:14px;color:#059669" id="rbTopItem"><?= e($builder['summary']['top_item']) ?></strong>
                    </div>
                </div>

                <!-- بوم نمودار برداری تعاملی -->
                <div id="rbMainChartCanvas" style="min-height:285px;padding:10px;border:1px solid var(--border);border-radius:13px;margin-bottom:14px"></div>

                <!-- کادر روایت تحلیلی هوش مصنوعی -->
                <div id="rbAiNarrativeBox" class="alert alert-info" style="margin-bottom:14px">
                    <strong>💡 تحلیل تصمیم‌یار هوشمند (AI):</strong>
                    <span id="rbAiNarrativeText">گروه «<?= e($builder['summary']['top_item']) ?>» بیشترین سهم را در شاخص «<?= e($builder['metric_label']) ?>» به خود اختصاص داده است؛ تخصیص اولویت بودجه و ظرفیت اجرایی به این ردیف بیشترین بازدهی را ایجاد می‌کند.</span>
                </div>

                <!-- جدول پیوت حرارتی با نوار سهم درصدی -->
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
                    <strong style="font-size:13.5px">📋 جدول تحلیلی پیوت و سهم درصدی</strong>
                    <input type="text" id="rbTableQuickSearch" placeholder="جست‌وجوی آنی در ردیف‌های جدول..." style="max-width:240px;padding:5px 10px;font-size:12px" oninput="filterBuilderPivotRows(this.value)">
                </div>
                <div class="table-wrap">
                    <table>
                        <thead>
                        <tr>
                            <th>رتبه</th>
                            <th id="rbThDim"><?= e($builder['dimension_label']) ?></th>
                            <th id="rbThMetric"><?= e($builder['metric_label']) ?></th>
                            <th>تعداد رکورد</th>
                            <th>سهم از کل (Heatmap)</th>
                        </tr>
                        </thead>
                        <tbody id="rbPivotTableBody"></tbody>
                    </table>
                </div>

                <details style="margin-top:12px">
                    <summary class="muted" style="cursor:pointer;font-size:12px">🔍 مشاهده کد پرس‌وجوی امن تولیدشده (SQL Transparency)</summary>
                    <pre class="pre-box" id="rbSqlCodeBox" dir="ltr" style="margin-top:8px;font-size:12px"><?= e($builder['sql_preview']) ?></pre>
                </details>
            </div>
        </div>
    </div>
</section>

<!-- ======================================================================= -->
<!-- TAB 3: ENTERPRISE REPORT CATALOG (16 READY REPORTS + SAVED REPORTS)    -->
<!-- ======================================================================= -->
<section id="biSection_catalog" class="bi-studio-section" style="display:<?= $activeTab === 'catalog' ? 'block' : 'none' ?>">
    <div class="card" style="margin-bottom:16px">
        <div class="card-header">
            <div class="card-title">📚 کاتالوگ جامع گزارش‌های تحلیلی آماده به تفکیک واحد سازمانی</div>
            <div style="display:flex;gap:6px;flex-wrap:wrap">
                <button type="button" class="btn btn-sm btn-primary" onclick="filterCatalogCards('all')">همه حوزه‌ها</button>
                <button type="button" class="btn btn-sm btn-outline" onclick="filterCatalogCards('مالی و حسابداری')">مالی و حسابداری</button>
                <button type="button" class="btn btn-sm btn-outline" onclick="filterCatalogCards('آموزش و کیفیت')">آموزش و کیفیت</button>
                <button type="button" class="btn btn-sm btn-outline" onclick="filterCatalogCards('فروش سازمانی و اعضا')">فروش سازمانی و اعضا</button>
                <button type="button" class="btn btn-sm btn-outline" onclick="filterCatalogCards('کارت بازرگانی و شعب')">کارت بازرگانی و شعب</button>
                <button type="button" class="btn btn-sm btn-outline" onclick="filterCatalogCards('اتوماسیون اداری و اشتغال')">اتوماسیون اداری و اشتغال</button>
            </div>
        </div>

        <div class="grid grid-3" id="biCatalogCardsGrid">
            <?php foreach ($workspace['preset_catalog'] as $catItem): ?>
                <div class="card bi-cat-card" data-cat-group="<?= e($catItem['group']) ?>" style="padding:14px;background:var(--surface-2)">
                    <div style="display:flex;justify-content:space-between;margin-bottom:6px">
                        <span class="badge badge-info"><?= e($catItem['group']) ?></span>
                        <span class="badge badge-gold"><?= e($workspace['chart_types'][$catItem['chart']] ?? $catItem['chart']) ?></span>
                    </div>
                    <div style="font-weight:800;font-size:13.5px;margin-bottom:10px;line-height:1.7"><?= e($catItem['title']) ?></div>
                    <div style="display:flex;gap:6px;flex-wrap:wrap">
                        <button type="button" class="btn btn-sm btn-primary"
                                onclick="openPresetInBuilder('<?= e($catItem['dataset']) ?>','<?= e($catItem['dim']) ?>','<?= e($catItem['metric']) ?>','<?= e($catItem['agg']) ?>','<?= e($catItem['chart']) ?>','<?= e($catItem['title']) ?>')">
                            📊 اجرا در گزارش‌ساز زنده
                        </button>
                        <a class="btn btn-sm btn-outline" href="<?= e(url('bi', ['export' => 'csv', 'dataset_key' => $catItem['dataset'], 'dimension_field' => $catItem['dim'], 'metric_field' => $catItem['metric'], 'agg_func' => $catItem['agg']])) ?>">📥 Excel</a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="card">
        <div class="card-header"><div class="card-title">🗂️ گزارش‌های سفارشی ساخته‌شده توسط کاربران (کلیکی / درگ‌انددراپ / صوتی / متنی)</div></div>
        <div class="table-wrap">
            <table>
                <thead>
                <tr>
                    <th>کد گزارش</th>
                    <th>عنوان گزارش سفارشی</th>
                    <th>روش ساخت</th>
                    <th>نمودار</th>
                    <th>خلاصه تحلیل هوشمند AI</th>
                    <th>عملیات</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($workspace['custom_reports'] as $cr): ?>
                    <tr>
                        <td><code><?= e($cr['report_code']) ?></code></td>
                        <td><strong><?= e($cr['title']) ?></strong><div class="muted" style="font-size:11px"><?= e($cr['category']) ?> • <?= e($cr['created_by_name']) ?></div></td>
                        <td>
                            <span class="badge badge-purple">
                                <?= match ($cr['created_via']) {
                                    'voice' => '🎙️ صوتی',
                                    'text' => '⌨️ متنی',
                                    'drag_drop' => '🖐️ درگ‌انددراپ',
                                    default => '🖱️ کلیکی',
                                } ?>
                            </span>
                        </td>
                        <td><?= e($workspace['chart_types'][$cr['chart_type']] ?? $cr['chart_type']) ?></td>
                        <td style="max-width:340px;font-size:12px"><?= e($cr['ai_narrative']) ?></td>
                        <td>
                            <button type="button" class="btn btn-sm btn-primary"
                                    onclick="openPresetInBuilder('<?= e($cr['dataset_key']) ?>','<?= e($cr['dimension_field']) ?>','<?= e($cr['metric_field']) ?>','<?= e($cr['agg_func']) ?>','<?= e($cr['chart_type']) ?>','<?= e($cr['title']) ?>')">مشاهده زنده</button>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</section>

<!-- ======================================================================= -->
<!-- TAB 4: STRATEGIC GOAL SETTING (OKR / KPI GAUGES & CHECK-INS)           -->
<!-- ======================================================================= -->
<section id="biSection_goals" class="bi-studio-section" style="display:<?= $activeTab === 'goals' ? 'block' : 'none' ?>">
    <!-- نوار درگ‌انددراپ شاخص‌ها برای ساخت خودکار هدف کمی -->
    <div class="card" style="margin-bottom:16px">
        <div class="card-header">
            <div class="card-title">🎯 تعریف هدف جدید (OKR / تارگت کمی) با درگ‌انددراپ شاخص یا فرم کلیکی</div>
        </div>
        <div style="margin-bottom:10px;font-size:12.5px;color:var(--text-muted)">
            شاخص مورد نظر را بکشید و در کادر هدف رها کنید تا فرم هدف‌گذاری به صورت خودکار پر و ثبت شود:
            <div style="margin-top:6px">
                <?php foreach ($workspace['goal_sources'] as $gsKey => $gsMeta): ?>
                    <span class="bi-drag-chip metric-chip" draggable="true"
                          ondragstart="event.dataTransfer.setData('text/plain', JSON.stringify({source:'<?= e($gsKey) ?>',label:'<?= e($gsMeta['label']) ?>',unit:'<?= e($gsMeta['unit']) ?>'}))">
                        🎯 <?= e($gsMeta['label']) ?>
                    </span>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="bi-dropzone" style="margin-bottom:12px"
             ondragover="event.preventDefault(); this.classList.add('active-drop');"
             ondragleave="this.classList.remove('active-drop');"
             ondrop="onGoalSourceDrop(event)">
            <form method="post" action="<?= e(url('bi')) ?>" class="grid grid-4" style="align-items:end">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="create_goal">
                <input type="hidden" name="created_via" id="goalViaInput" value="click">
                <div>
                    <label>عنوان هدف راهبردی (Objective):</label>
                    <input type="text" name="title" id="goalTitleInput" required placeholder="مثلاً: تحقق سقف ۷۵۰ میلیون ریال درآمد دوره‌های صادرات">
                </div>
                <div>
                    <label>اتصال به شاخص زنده دیتابیس:</label>
                    <select name="live_metric_source" id="goalSourceSelect">
                        <?php foreach ($workspace['goal_sources'] as $gsKey => $gsMeta): ?>
                            <option value="<?= e($gsKey) ?>"><?= e($gsMeta['label']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label>مقدار هدف مقرر (Target):</label>
                    <input type="number" step="any" name="target_value" id="goalTargetInput" required value="750000000">
                </div>
                <div style="display:flex;gap:6px">
                    <input type="text" name="department_owner" placeholder="واحد مسئول" value="معاونت آموزش" style="flex:1">
                    <button type="submit" class="btn btn-primary">ثبت هدف</button>
                </div>
            </form>
        </div>
    </div>

    <!-- کارت‌های عقربه‌ای تحقق اهداف راهبردی -->
    <div class="grid grid-3">
        <?php foreach ($goals as $g):
            $pct = (float)$g['achievement_pct'];
            $clamped = max(0.0, min(100.0, $pct));
            $dashOffset = round(157 - (157 * ($clamped / 100.0)), 1);
            $strokeColor = $g['rag_badge'] === 'success' ? '#10b981' : ($g['rag_badge'] === 'gold' ? '#f59e0b' : '#ef4444');
        ?>
            <div class="card" style="display:flex;flex-direction:column;justify-content:space-between">
                <div>
                    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
                        <span class="badge badge-<?= e($g['rag_badge']) ?>"><?= e($g['status_label']) ?></span>
                        <span class="muted" style="font-size:11.5px"><?= e($g['department_owner']) ?> • <?= e($g['horizon_label']) ?></span>
                    </div>
                    <h3 style="font-size:14.5px;margin-bottom:8px;line-height:1.65"><?= e($g['title']) ?></h3>

                    <!-- عقربه نیم‌دایره برداری تحقق هدف -->
                    <div style="text-align:center;margin:6px 0">
                        <svg viewBox="0 0 140 82" style="width:165px;height:95px">
                            <path d="M 15 70 A 50 50 0 0 1 115 70" fill="none" stroke="var(--border)" stroke-width="11" stroke-linecap="round"/>
                            <path d="M 15 70 A 50 50 0 0 1 115 70" fill="none" stroke="<?= $strokeColor ?>" stroke-width="11" stroke-linecap="round"
                                  stroke-dasharray="157" stroke-dashoffset="<?= $dashOffset ?>"/>
                            <text x="65" y="62" text-anchor="middle" font-size="18" font-weight="800" fill="var(--text)"><?= fa($pct) ?>٪</text>
                        </svg>
                    </div>

                    <div style="font-size:12px;background:var(--surface-2);padding:9px 11px;border-radius:10px;line-height:1.9">
                        <div>عملکرد فعلی (زنده + تحقق ثبت‌شده): <strong><?= fa(number_format((float)$g['current_actual'])) ?></strong> <?= e($g['unit_label']) ?></div>
                        <div>هدف مصوب: <strong><?= fa(number_format((float)$g['target_value'])) ?></strong> <?= e($g['unit_label']) ?></div>
                        <div class="muted">نتیجه کلیدی: <?= e($g['key_results_note']) ?></div>
                    </div>
                </div>

                <form method="post" action="<?= e(url('bi')) ?>" style="display:flex;gap:6px;margin-top:10px;padding-top:10px;border-top:1px solid var(--border)">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="checkin_goal">
                    <input type="hidden" name="goal_id" value="<?= (int)$g['id'] ?>">
                    <input type="number" step="any" name="progress_delta" placeholder="+ ثبت پیشرفت جدید" required style="flex:1;padding:6px 9px;font-size:12px">
                    <button type="submit" class="btn btn-sm btn-outline">ثبت پیشرفت</button>
                </form>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<!-- ======================================================================= -->
<!-- TAB 5: WHAT-IF SIMULATOR, LIVE ANOMALY WATCHDOG & REPORT SCHEDULES     -->
<!-- ======================================================================= -->
<section id="biSection_whatif" class="bi-studio-section" style="display:<?= $activeTab === 'whatif' ? 'block' : 'none' ?>">
    <div class="grid grid-2" style="margin-bottom:18px">
        <!-- شبیه‌ساز تعاملی سناریو What-If -->
        <div class="card">
            <div class="card-header"><div class="card-title">🔮 شبیه‌ساز پیش‌بینی بودجه و تحلیل حساسیت (What-If)</div></div>
            <form method="post" action="<?= e(url('bi')) ?>">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="save_whatif">
                <div class="form-group">
                    <label>عنوان سناریوی تصمیم‌گیری:</label>
                    <input type="text" name="title" value="سناریوی گسترش دوره‌های صادراتی نیمسال آینده">
                </div>
                <div class="form-grid">
                    <div class="form-group">
                        <label>تغییر نرخ شهریه: <strong id="lblWiTuition">+۱۰٪</strong></label>
                        <input type="range" name="tuition_delta_pct" id="wiTuition" min="-30" max="50" value="10" oninput="recalcWhatIfLive()">
                    </div>
                    <div class="form-group">
                        <label>رشد جذب فراگیران: <strong id="lblWiEnroll">+۲۵٪</strong></label>
                        <input type="range" name="enrollment_growth_pct" id="wiEnroll" min="-20" max="100" value="25" oninput="recalcWhatIfLive()">
                    </div>
                    <div class="form-group">
                        <label>نرخ تبدیل قراردادهای سازمانی: <strong id="lblWiB2b">۳۰٪</strong></label>
                        <input type="range" name="b2b_conversion_pct" id="wiB2b" min="0" max="80" value="30" oninput="recalcWhatIfLive()">
                    </div>
                    <div class="form-group">
                        <label>تغییر هزینه‌های اجرایی: <strong id="lblWiCost">-۵٪</strong></label>
                        <input type="range" name="cost_change_pct" id="wiCost" min="-30" max="30" value="-5" oninput="recalcWhatIfLive()">
                    </div>
                </div>

                <div style="background:var(--surface-2);border-radius:12px;padding:14px;margin:10px 0">
                    <div style="display:flex;justify-content:space-between;margin-bottom:8px">
                        <span>درآمد کل پیش‌بینی‌شده:</span>
                        <strong style="font-size:16px;color:var(--primary)" id="wiOutRev">—</strong>
                    </div>
                    <div style="display:flex;justify-content:space-between;margin-bottom:8px">
                        <span>مازاد خالص عملیاتی (سود آموزشی):</span>
                        <strong style="font-size:16px;color:#059669" id="wiOutSurplus">—</strong>
                    </div>
                    <div id="wiCompareBars"></div>
                </div>

                <button type="submit" class="btn btn-primary" style="width:100%">ذخیره سناریو در آرشیو مدیریتی</button>
            </form>
        </div>

        <!-- رادار کشف خودکار ناهنجاری‌ها و هشدارهای مدیریتی -->
        <div class="card">
            <div class="card-header"><div class="card-title">🚨 پایش هوشمند گلوگاه‌ها و هشدارهای انحراف شاخص</div></div>
            <?php foreach ($anomalies as $an): ?>
                <div style="border:1px solid var(--border);border-radius:12px;padding:12px 14px;margin-bottom:10px;display:flex;justify-content:space-between;align-items:center;gap:10px">
                    <div>
                        <span class="badge badge-<?= e($an['severity']) ?>"><?= e($an['domain']) ?></span>
                        <div style="font-weight:700;margin-top:5px"><?= e($an['title']) ?></div>
                        <div class="muted" style="font-size:12px"><?= e($an['action']) ?></div>
                    </div>
                    <?= \App\Core\App::safeLink((string)$an['route'], 'اقدام ←', 'btn btn-sm btn-outline') ?: '<span class="badge badge-info" style="font-size:11px">این اقدام در حوزه کاری دیگری ثبت شده است</span>' ?>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- زمان‌بندی ارسال خودکار گزارش‌های دوره‌ای -->
    <div class="card">
        <div class="card-header"><div class="card-title">⏰ زمان‌بندی ارسال خودکار گزارش‌های مدیریتی به کارتابل و ایمیل</div></div>
        <form method="post" action="<?= e(url('bi')) ?>" class="grid grid-4" style="align-items:end;margin-bottom:14px">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="save_schedule">
            <div>
                <label>عنوان گزارش ارسالی:</label>
                <input type="text" name="report_title" required placeholder="خلاصه هفتگی وصولی و ثبت‌نام">
            </div>
            <div>
                <label>مخزن داده:</label>
                <select name="dataset_key">
                    <?php foreach ($workspace['data_marts'] as $mk => $mm): ?>
                        <option value="<?= e($mk) ?>"><?= e($mm['label']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label>گیرندگان سازمانی:</label>
                <input type="text" name="recipients_list" value="مدیریت مؤسسه، مدیر آموزش، مدیر مالی">
            </div>
            <button type="submit" class="btn btn-gold">+ ثبت برنامه ارسال خودکار</button>
        </form>

        <div class="table-wrap">
            <table>
                <thead>
                <tr>
                    <th>کد زمان‌بندی</th>
                    <th>عنوان گزارش</th>
                    <th>تناوب اجرا</th>
                    <th>کانال تحویل</th>
                    <th>گیرندگان</th>
                    <th>قالب خروجی</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($workspace['schedules'] as $sch): ?>
                    <tr>
                        <td><code><?= e($sch['schedule_code']) ?></code></td>
                        <td><strong><?= e($sch['report_title']) ?></strong></td>
                        <td><?= e($sch['frequency_label']) ?></td>
                        <td><?= e($sch['delivery_channel']) ?></td>
                        <td><?= e($sch['recipients_list']) ?></td>
                        <td><span class="badge badge-info"><?= e($sch['export_format']) ?></span></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</section>

<script>
(function () {
    const BI_MARTS = <?= $martsJson ?>;
    const BI_DASHBOARD_ID = <?= (int)$dashboardId ?>;
    const BI_API_URL = <?= json_encode(url('api/v1/bi-studio')) ?>;
    const BI_BASE_CSV_URL = <?= json_encode(url('bi')) ?>;
    const BI_PRINT_URL = <?= json_encode(url('bi-report-print')) ?>;
    const BI_BASE_REVENUE = <?= (float)max(250000000, $kpis['total_revenue_rial']) ?>;
    let BI_WIDGETS_STATE = <?= $widgetsJson ?>;
    let currentBuilderState = <?= $builderJson ?>;

    const PALETTES = ['#4f46e5', '#0d9488', '#d97706', '#e11d48', '#7c3aed', '#0284c7', '#059669', '#ea580c'];

    function toFaNum(val) {
        const s = typeof val === 'number' ? Math.round(val).toLocaleString('en-US') : String(val);
        return s.replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]);
    }

    function escHtml(str) {
        return String(str ?? '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
    }

    // موتور رندر ۹ نوع نمودار برداری تعاملی (ستونی، افقی، خطی، حلقوی، قیفی، راداری، عقربه‌ای، حرارتی، جدول)
    window.renderBiVectorChart = function (rows, chartType, unitLabel) {
        if (!rows || !rows.length) {
            return '<div class="muted" style="padding:30px;text-align:center">داده‌ای برای شرایط انتخابی یافت نشد.</div>';
        }
        const maxVal = Math.max(...rows.map(r => Number(r.value) || 0), 1);
        const total = rows.reduce((a, b) => a + (Number(b.value) || 0), 0) || 1;

        if (chartType === 'hbar') {
            return '<div style="width:100%;display:flex;flex-direction:column;gap:9px;padding:6px 4px">' + rows.slice(0, 7).map((r, i) => {
                const w = Math.max(4, Math.round((Number(r.value) / maxVal) * 100));
                const col = PALETTES[i % PALETTES.length];
                return `<div>
                    <div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:3px">
                        <strong>${escHtml(r.label)}</strong>
                        <span>${toFaNum(r.value)} <small class="muted">(${toFaNum(r.share_pct)}٪)</small></span>
                    </div>
                    <div style="height:12px;background:var(--surface-2);border-radius:99px;overflow:hidden">
                        <div style="width:${w}%;height:100%;background:${col};border-radius:99px"></div>
                    </div>
                </div>`;
            }).join('') + '</div>';
        }

        if (chartType === 'donut') {
            let offset = 0;
            const circ = 2 * Math.PI * 44;
            const arcs = rows.slice(0, 6).map((r, i) => {
                const pct = (Number(r.value) || 0) / total;
                const len = pct * circ;
                const seg = `<circle cx="60" cy="60" r="44" fill="none" stroke="${PALETTES[i % PALETTES.length]}" stroke-width="18" stroke-dasharray="${len.toFixed(1)} ${circ.toFixed(1)}" stroke-dashoffset="${(-offset).toFixed(1)}"><title>${escHtml(r.label)}: ${toFaNum(r.value)}</title></circle>`;
                offset += len;
                return seg;
            }).join('');
            const legend = rows.slice(0, 6).map((r, i) =>
                `<div style="display:flex;align-items:center;gap:6px;font-size:12px;margin-bottom:4px">
                    <span style="width:10px;height:10px;border-radius:3px;background:${PALETTES[i % PALETTES.length]};display:inline-block"></span>
                    <span>${escHtml(r.label)}: <strong>${toFaNum(r.share_pct)}٪</strong></span>
                </div>`
            ).join('');
            return `<div style="display:flex;align-items:center;justify-content:center;gap:20px;width:100%;flex-wrap:wrap">
                <svg viewBox="0 0 120 120" style="width:150px;height:150px;transform:rotate(-90deg)">${arcs}</svg>
                <div>${legend}</div>
            </div>`;
        }

        if (chartType === 'funnel') {
            return '<div style="width:100%;display:flex;flex-direction:column;align-items:center;gap:6px">' + rows.slice(0, 6).map((r, i) => {
                const wPct = Math.max(36, Math.round(100 - (i * 11)));
                return `<div style="width:${wPct}%;background:${PALETTES[i % PALETTES.length]};color:#fff;padding:7px 12px;border-radius:9px;display:flex;justify-content:space-between;font-size:12px;font-weight:700">
                    <span>${escHtml(r.label)}</span>
                    <span>${toFaNum(r.value)} (${toFaNum(r.share_pct)}٪)</span>
                </div>`;
            }).join('') + '</div>';
        }

        if (chartType === 'line') {
            const pts = rows.slice(0, 8);
            const W = 440, H = 185, padX = 36, padY = 24;
            const stepX = pts.length > 1 ? (W - padX * 2) / (pts.length - 1) : 0;
            const coords = pts.map((r, i) => ({
                x: padX + i * stepX,
                y: H - padY - ((Number(r.value) / maxVal) * (H - padY * 2)),
                r
            }));
            const poly = coords.map(c => `${c.x.toFixed(1)},${c.y.toFixed(1)}`).join(' ');
            const area = `${coords[0].x.toFixed(1)},${H - padY} ${poly} ${coords[coords.length - 1].x.toFixed(1)},${H - padY}`;
            const dots = coords.map(c =>
                `<circle cx="${c.x.toFixed(1)}" cy="${c.y.toFixed(1)}" r="5" fill="#4f46e5" stroke="#fff" stroke-width="2"><title>${escHtml(c.r.label)}: ${toFaNum(c.r.value)}</title></circle>
                 <text x="${c.x.toFixed(1)}" y="${H - 6}" text-anchor="middle" font-size="10" fill="currentColor">${escHtml(c.r.label.slice(0, 12))}</text>`
            ).join('');
            return `<svg viewBox="0 0 ${W} ${H}" style="width:100%;height:195px">
                <polygon points="${area}" fill="rgba(79,70,229,0.13)"/>
                <polyline points="${poly}" fill="none" stroke="#4f46e5" stroke-width="3" stroke-linecap="round"/>
                ${dots}
            </svg>`;
        }

        if (chartType === 'radar') {
            const items = rows.slice(0, 6);
            const cx = 110, cy = 100, R = 68, n = items.length;
            const axes = items.map((r, i) => {
                const ang = (Math.PI * 2 * i / n) - Math.PI / 2;
                const x = cx + Math.cos(ang) * R, y = cy + Math.sin(ang) * R;
                const vx = cx + Math.cos(ang) * R * Math.max(0.15, Number(r.value) / maxVal);
                const vy = cy + Math.sin(ang) * R * Math.max(0.15, Number(r.value) / maxVal);
                return { x, y, vx, vy, label: r.label, val: r.value };
            });
            const poly = axes.map(a => `${a.vx.toFixed(1)},${a.vy.toFixed(1)}`).join(' ');
            const lines = axes.map(a =>
                `<line x1="${cx}" y1="${cy}" x2="${a.x.toFixed(1)}" y2="${a.y.toFixed(1)}" stroke="var(--border)"/>
                 <text x="${a.x.toFixed(1)}" y="${a.y.toFixed(1)}" text-anchor="middle" font-size="9.5" fill="currentColor">${escHtml(a.label.slice(0, 14))}</text>`
            ).join('');
            return `<svg viewBox="0 0 220 200" style="width:100%;height:195px">
                <circle cx="${cx}" cy="${cy}" r="${R}" fill="none" stroke="var(--border)" stroke-dasharray="3 3"/>
                <circle cx="${cx}" cy="${cy}" r="${R * 0.5}" fill="none" stroke="var(--border)" stroke-dasharray="3 3"/>
                ${lines}
                <polygon points="${poly}" fill="rgba(13,148,136,0.25)" stroke="#0d9488" stroke-width="2.5"/>
            </svg>`;
        }

        if (chartType === 'gauge') {
            const topShare = Math.min(100, Math.round(Number(rows[0].share_pct) || 50));
            const off = (157 - (157 * topShare / 100)).toFixed(1);
            return `<div style="text-align:center;width:100%">
                <svg viewBox="0 0 150 90" style="width:185px;height:110px">
                    <path d="M 20 75 A 55 55 0 0 1 130 75" fill="none" stroke="var(--border)" stroke-width="12" stroke-linecap="round"/>
                    <path d="M 20 75 A 55 55 0 0 1 130 75" fill="none" stroke="#4f46e5" stroke-width="12" stroke-linecap="round" stroke-dasharray="157" stroke-dashoffset="${off}"/>
                    <text x="75" y="65" text-anchor="middle" font-size="18" font-weight="800" fill="currentColor">${toFaNum(topShare)}٪</text>
                </svg>
                <div style="font-size:12px">سهم دسته اول («${escHtml(rows[0].label)}») از کل</div>
            </div>`;
        }

        if (chartType === 'heatmap') {
            return '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:8px;width:100%">' + rows.map(r => {
                const alpha = (0.14 + 0.72 * (Number(r.value) / maxVal)).toFixed(2);
                return `<div style="background:rgba(79,70,229,${alpha});color:${alpha > 0.5 ? '#fff' : 'var(--text)'};padding:12px;border-radius:11px;text-align:center">
                    <div style="font-weight:700;font-size:12.5px">${escHtml(r.label)}</div>
                    <div style="font-size:15px;font-weight:900;margin-top:4px">${toFaNum(r.value)}</div>
                    <div style="font-size:11px;opacity:.9">${toFaNum(r.share_pct)}٪ سهم</div>
                </div>`;
            }).join('') + '</div>';
        }

        if (chartType === 'table') {
            return '<div class="table-wrap" style="width:100%"><table><thead><tr><th>عنوان</th><th>مقدار</th><th>سهم</th></tr></thead><tbody>' +
                rows.slice(0, 6).map(r => `<tr><td>${escHtml(r.label)}</td><td><strong>${toFaNum(r.value)}</strong></td><td>${toFaNum(r.share_pct)}٪</td></tr>`).join('') +
                '</tbody></table></div>';
        }

        // پیش‌فرض: نمودار ستونی عمودی (bar)
        const bars = rows.slice(0, 8);
        return '<div style="display:flex;align-items:flex-end;justify-content:space-around;gap:10px;width:100%;height:195px;padding:18px 8px 4px">' + bars.map((r, i) => {
            const hPct = Math.max(8, Math.round((Number(r.value) / maxVal) * 135));
            return `<div style="flex:1;display:flex;flex-direction:column;align-items:center;min-width:0" title="${escHtml(r.label)}: ${toFaNum(r.value)}">
                <span style="font-size:10.5px;font-weight:700;margin-bottom:4px">${toFaNum(r.share_pct)}٪</span>
                <div style="width:72%;max-width:44px;height:${hPct}px;background:${PALETTES[i % PALETTES.length]};border-radius:8px 8px 3px 3px;transition:height .25s"></div>
                <span style="font-size:11px;margin-top:6px;text-align:center;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:95%">${escHtml(r.label)}</span>
            </div>`;
        }).join('') + '</div>';
    };

    function renderAllDashboardWidgets() {
        Object.values(BI_WIDGETS_STATE).forEach(w => {
            const box = document.getElementById('biWidgetChartBox_' + w.id);
            if (box && w.data) {
                box.innerHTML = window.renderBiVectorChart(w.data.rows, w.chart_type, w.data.unit);
            }
        });
    }

    // تغییر آنی نوع نمودار یا عرض کارت در داشبورد + ذخیره خودکار در دیتابیس
    window.changeWidgetChartLive = function (wid, newType) {
        if (!BI_WIDGETS_STATE[wid]) return;
        BI_WIDGETS_STATE[wid].chart_type = newType;
        renderAllDashboardWidgets();
        fetch(BI_API_URL, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ op: 'reorder_widgets', ordered_ids: getCurrentGridOrder(), updates: { [wid]: { chart_type: newType } } })
        });
    };

    window.changeWidgetSpanLive = function (wid, spanVal) {
        const card = document.querySelector(`.bi-widget-card[data-widget-id="${wid}"]`);
        if (!card) return;
        card.className = 'bi-widget-card bi-col-' + spanVal;
        card.setAttribute('data-col-span', spanVal);
        fetch(BI_API_URL, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ op: 'reorder_widgets', ordered_ids: getCurrentGridOrder(), updates: { [wid]: { col_span: Number(spanVal) } } })
        });
    };

    function getCurrentGridOrder() {
        return Array.from(document.querySelectorAll('#biLiveDashboardGrid .bi-widget-card')).map(el => Number(el.getAttribute('data-widget-id')));
    }

    // درگ‌انددراپ واقعی کارت‌های ویجت روی گرید ۱۲ ستونی داشبورد
    let draggedCardEl = null;
    function bindDashboardDragAndDrop() {
        const cards = document.querySelectorAll('#biLiveDashboardGrid .bi-widget-card');
        cards.forEach(card => {
            card.ondragstart = function (e) {
                draggedCardEl = card;
                card.classList.add('dragging');
                e.dataTransfer.effectAllowed = 'move';
            };
            card.ondragend = function () {
                card.classList.remove('dragging');
                document.querySelectorAll('.bi-widget-card').forEach(c => c.classList.remove('drag-over'));
                draggedCardEl = null;
            };
            card.ondragover = function (e) {
                if (!draggedCardEl || draggedCardEl === card) return;
                e.preventDefault();
                card.classList.add('drag-over');
            };
            card.ondragleave = function () {
                card.classList.remove('drag-over');
            };
            card.ondrop = function (e) {
                e.preventDefault();
                card.classList.remove('drag-over');
                if (!draggedCardEl || draggedCardEl === card) return;
                const grid = document.getElementById('biLiveDashboardGrid');
                const all = Array.from(grid.children);
                if (all.indexOf(draggedCardEl) < all.indexOf(card)) {
                    card.after(draggedCardEl);
                } else {
                    card.before(draggedCardEl);
                }
                setStatusBadge('چیدمان جدید داشبورد با درگ‌انددراپ ذخیره شد');
                fetch(BI_API_URL, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({ op: 'reorder_widgets', ordered_ids: getCurrentGridOrder() })
                });
            };
        });
    }

    window.onPaletteWidgetDragStart = function (ev, spec) {
        ev.dataTransfer.setData('application/x-bi-widget', JSON.stringify(spec));
    };

    window.handlePaletteDropOnDashboard = function (ev) {
        ev.preventDefault();
        document.getElementById('biDashboardDropBanner').classList.remove('active-drop');
        const raw = ev.dataTransfer.getData('application/x-bi-widget');
        if (!raw) return;
        const spec = JSON.parse(raw);
        spec.created_via = 'drag_drop';
        dropNewWidgetAjax(spec);
    };

    window.dropNewWidgetAjax = function (spec) {
        setStatusBadge('در حال افزودن ویجت زنده به داشبورد...');
        fetch(BI_API_URL, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(Object.assign({ op: 'drop_new_widget', dashboard_id: BI_DASHBOARD_ID }, spec))
        }).then(r => r.json()).then(res => {
            if (!res.ok || !res.widget) return;
            const w = res.widget;
            BI_WIDGETS_STATE[w.id] = { id: w.id, title: w.title, subtitle: w.subtitle, chart_type: w.chart_type, col_span: Number(w.col_span), data: w.live_data };
            const div = document.createElement('div');
            div.className = 'bi-widget-card bi-col-' + w.col_span;
            div.setAttribute('data-widget-id', w.id);
            div.setAttribute('draggable', 'true');
            div.innerHTML = `
                <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:8px">
                    <div>
                        <div style="font-weight:800;font-size:14px">⠿ ${escHtml(w.title)}</div>
                        <div class="muted" style="font-size:11.5px">${escHtml(w.subtitle)}</div>
                    </div>
                    <span class="badge badge-success">افزوده‌شده زنده</span>
                </div>
                <div id="biWidgetChartBox_${w.id}" style="min-height:215px;display:flex;align-items:center;justify-content:center"></div>
                <div style="display:flex;justify-content:space-between;font-size:11.5px;color:var(--text-muted);border-top:1px solid var(--border);padding-top:8px;margin-top:8px">
                    <span>صدرنشین: <strong>${escHtml(w.live_data.summary.top_item)}</strong></span>
                    <span>جمع کل: <strong>${toFaNum(w.live_data.summary.grand_total)}</strong></span>
                </div>`;
            document.getElementById('biLiveDashboardGrid').prepend(div);
            renderAllDashboardWidgets();
            bindDashboardDragAndDrop();
            setStatusBadge('ویجت جدید روی بوم داشبورد قرار گرفت و در دیتابیس ذخیره شد');
        });
    };

    // دیکشنری و گزارش‌ساز ۴ حالته
    window.onBuilderDatasetChange = function () {
        populateBuilderSelectors();
        runBuilderLiveQuery();
    };

    function populateBuilderSelectors(preferredDim, preferredMetric) {
        const dsKey = document.getElementById('rbDatasetSelect').value;
        const mart = BI_MARTS[dsKey];
        if (!mart) return;

        const dimSel = document.getElementById('rbDimSelect');
        const metSel = document.getElementById('rbMetricSelect');
        const fltSel = document.getElementById('rbFilterField');
        const dimChips = document.getElementById('rbDraggableDims');
        const metChips = document.getElementById('rbDraggableMetrics');

        dimSel.innerHTML = '';
        dimChips.innerHTML = '';
        fltSel.innerHTML = '<option value="">بدون فیلتر محدودکننده</option>';

        Object.entries(mart.dimensions).forEach(([k, label]) => {
            dimSel.innerHTML += `<option value="${k}">${escHtml(label)}</option>`;
            fltSel.innerHTML += `<option value="${k}">${escHtml(label)}</option>`;
            const chip = document.createElement('span');
            chip.className = 'bi-drag-chip dim-chip';
            chip.draggable = true;
            chip.textContent = '🟦 ' + label;
            chip.ondragstart = e => e.dataTransfer.setData('text/plain', JSON.stringify({ kind: 'dim', field: k }));
            chip.onclick = () => { dimSel.value = k; document.getElementById('rbSaveViaInput').value = 'click'; runBuilderLiveQuery(); };
            dimChips.appendChild(chip);
        });

        metSel.innerHTML = '';
        metChips.innerHTML = '';
        Object.entries(mart.metrics).forEach(([k, label]) => {
            metSel.innerHTML += `<option value="${k}">${escHtml(label)}</option>`;
            const chip = document.createElement('span');
            chip.className = 'bi-drag-chip metric-chip';
            chip.draggable = true;
            chip.textContent = '🟩 ' + label;
            chip.ondragstart = e => e.dataTransfer.setData('text/plain', JSON.stringify({ kind: 'metric', field: k }));
            chip.onclick = () => { metSel.value = k; document.getElementById('rbSaveViaInput').value = 'click'; runBuilderLiveQuery(); };
            metChips.appendChild(chip);
        });

        if (preferredDim && mart.dimensions[preferredDim]) dimSel.value = preferredDim;
        if (preferredMetric && mart.metrics[preferredMetric]) metSel.value = preferredMetric;
    }

    window.onBuilderZoneDrop = function (ev, zoneType) {
        ev.preventDefault();
        ev.currentTarget.classList.remove('active-drop');
        try {
            const payload = JSON.parse(ev.dataTransfer.getData('text/plain'));
            if (zoneType === 'dimension' && payload.kind === 'dim') {
                document.getElementById('rbDimSelect').value = payload.field;
            } else if (zoneType === 'metric' && payload.kind === 'metric') {
                document.getElementById('rbMetricSelect').value = payload.field;
            }
            document.getElementById('rbSaveViaInput').value = 'drag_drop';
            setStatusBadge('فیلد با درگ‌انددراپ جایگذاری شد و گزارش بروزرسانی گردید');
            runBuilderLiveQuery();
        } catch (err) {}
    };

    window.runBuilderLiveQuery = function () {
        const spec = {
            op: 'query',
            dataset_key: document.getElementById('rbDatasetSelect').value,
            dimension_field: document.getElementById('rbDimSelect').value,
            metric_field: document.getElementById('rbMetricSelect').value,
            agg_func: document.getElementById('rbAggSelect').value,
            chart_type: document.getElementById('rbChartSelect').value,
            sort_dir: document.getElementById('rbSortSelect').value,
            filter_field: document.getElementById('rbFilterField').value,
            filter_op: 'CONTAINS',
            filter_val: document.getElementById('rbFilterVal').value
        };
        fetch(BI_API_URL, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(spec)
        }).then(r => r.json()).then(res => {
            if (res.ok && res.query) {
                applyBuilderResultToDom(res.query);
            }
        });
    };

    function applyBuilderResultToDom(q, customNarrative) {
        currentBuilderState = q;
        document.getElementById('rbPreviewTitle').textContent = q.metric_label + ' بر اساس ' + q.dimension_label;
        document.getElementById('rbPreviewMeta').textContent = q.dataset_label + ' • ' + q.agg_label;
        document.getElementById('rbSumTotal').textContent = toFaNum(q.summary.grand_total);
        document.getElementById('rbAvgVal').textContent = toFaNum(q.summary.average_val);
        document.getElementById('rbMaxVal').textContent = toFaNum(q.summary.max_val);
        document.getElementById('rbTopItem').textContent = q.summary.top_item;
        document.getElementById('rbThDim').textContent = q.dimension_label;
        document.getElementById('rbThMetric').textContent = q.metric_label;
        document.getElementById('rbSqlCodeBox').textContent = q.sql_preview;
        document.getElementById('rbMainChartCanvas').innerHTML = window.renderBiVectorChart(q.rows, q.chart_type, q.unit);

        document.getElementById('rbFormDataset').value = q.dataset_key;
        document.getElementById('rbFormDim').value = q.dimension_field;
        document.getElementById('rbFormMetric').value = q.metric_field;
        document.getElementById('rbFormAgg').value = q.agg_func;
        document.getElementById('rbFormChart').value = q.chart_type;
        document.getElementById('rbSaveTitle').value = q.metric_label + ' بر اساس ' + q.dimension_label;

        const qs = `dataset_key=${encodeURIComponent(q.dataset_key)}&dimension_field=${encodeURIComponent(q.dimension_field)}&metric_field=${encodeURIComponent(q.metric_field)}&agg_func=${encodeURIComponent(q.agg_func)}&chart_type=${encodeURIComponent(q.chart_type)}`;
        const sep = BI_BASE_CSV_URL.includes('?') ? '&' : '?';
        document.getElementById('rbCsvBtn').href = BI_BASE_CSV_URL + sep + 'export=csv&' + qs;
        document.getElementById('biExportCsvTopBtn').href = BI_BASE_CSV_URL + sep + 'export=csv&' + qs;
        document.getElementById('rbJsonBtn').href = BI_BASE_CSV_URL + sep + 'export=json&' + qs;
        document.getElementById('rbPrintBtn').href = BI_PRINT_URL + (BI_PRINT_URL.includes('?') ? '&' : '?') + `dashboard_id=${BI_DASHBOARD_ID}&` + qs;

        if (customNarrative) {
            document.getElementById('rbAiNarrativeText').textContent = customNarrative;
        }

        const tbody = document.getElementById('rbPivotTableBody');
        tbody.innerHTML = q.rows.map(r => `
            <tr>
                <td>${toFaNum(r.rank)}</td>
                <td><strong>${escHtml(r.label)}</strong></td>
                <td>${toFaNum(r.value)} <small class="muted">${escHtml(q.unit)}</small></td>
                <td>${toFaNum(r.records_cnt)}</td>
                <td style="min-width:155px">
                    <div style="display:flex;align-items:center;gap:8px">
                        <div style="flex:1;height:9px;background:var(--surface-2);border-radius:99px;overflow:hidden">
                            <div style="width:${Math.min(100, r.share_pct)}%;height:100%;background:var(--primary)"></div>
                        </div>
                        <strong style="font-size:12px">${toFaNum(r.share_pct)}٪</strong>
                    </div>
                </td>
            </tr>
        `).join('');
    }

    window.pinCurrentBuilderToDashboard = function () {
        dropNewWidgetAjax({
            title: currentBuilderState.metric_label + ' بر اساس ' + currentBuilderState.dimension_label,
            subtitle: currentBuilderState.dataset_label,
            dataset_key: currentBuilderState.dataset_key,
            dimension_field: currentBuilderState.dimension_field,
            metric_field: currentBuilderState.metric_field,
            agg_func: currentBuilderState.agg_func,
            chart_type: currentBuilderState.chart_type,
            col_span: 6,
            created_via: 'click'
        });
        switchBiStudioTab('dashboards', document.querySelector('[data-bi-tab="dashboards"]'));
    };

    window.openPresetInBuilder = function (ds, dim, met, agg, chart, title) {
        switchBiStudioTab('builder', document.querySelector('[data-bi-tab="builder"]'));
        document.getElementById('rbDatasetSelect').value = ds;
        populateBuilderSelectors(dim, met);
        document.getElementById('rbAggSelect').value = agg;
        document.getElementById('rbChartSelect').value = chart;
        runBuilderLiveQuery();
        setStatusBadge('گزارش «' + title + '» به صورت زنده بارگذاری شد');
    };

    window.filterCatalogCards = function (grp) {
        document.querySelectorAll('.bi-cat-card').forEach(c => {
            c.style.display = (grp === 'all' || c.getAttribute('data-cat-group') === grp) ? 'block' : 'none';
        });
    };

    window.filterBuilderPivotRows = function (term) {
        const q = term.trim().toLowerCase();
        document.querySelectorAll('#rbPivotTableBody tr').forEach(tr => {
            tr.style.display = tr.textContent.toLowerCase().includes(q) ? '' : 'none';
        });
    };

    // اجرای بلادرنگ متن طبیعی و فرمان صوتی فارسی
    window.runInstantNlPreview = function (mode) {
        const prompt = document.getElementById('biNaturalPromptInput').value.trim();
        if (!prompt) {
            setStatusBadge('لطفاً عبارت تحلیلی را بنویسید یا دکمه فرمان صوتی را بزنید');
            return;
        }
        const needPersist = /(داشبورد جدید|هدف|تارگت|ویجت|به داشبورد)/u.test(prompt);
        setStatusBadge('در حال تحلیل هوشمند دستور و اجرای پرس‌وجو...');
        fetch(BI_API_URL, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ op: 'nl_voice', prompt: prompt, mode: mode || 'text', dashboard_id: BI_DASHBOARD_ID, persist: needPersist ? 1 : 0 })
        }).then(r => r.json()).then(res => {
            if (!res.ok) return;
            if (res.intent === 'dashboard_created') {
                window.location.href = BI_BASE_CSV_URL + (BI_BASE_CSV_URL.includes('?') ? '&' : '?') + 'tab=dashboards&dashboard_id=' + res.dashboard_id;
                return;
            }
            if (res.intent === 'goal_created') {
                window.location.href = BI_BASE_CSV_URL + (BI_BASE_CSV_URL.includes('?') ? '&' : '?') + 'tab=goals';
                return;
            }
            if (res.intent === 'widget_pinned') {
                window.location.reload();
                return;
            }
            if (res.query) {
                switchBiStudioTab('builder', document.querySelector('[data-bi-tab="builder"]'));
                document.getElementById('rbDatasetSelect').value = res.query.dataset_key;
                populateBuilderSelectors(res.query.dimension_field, res.query.metric_field);
                document.getElementById('rbAggSelect').value = res.query.agg_func;
                document.getElementById('rbChartSelect').value = res.query.chart_type;
                applyBuilderResultToDom(res.query, res.ai_narrative);
                setStatusBadge(res.spoken_text || 'گزارش هوشمند ساخته شد');
                if (mode === 'voice' && window.speechSynthesis) {
                    const utt = new SpeechSynthesisUtterance(res.spoken_text);
                    utt.lang = 'fa-IR';
                    window.speechSynthesis.speak(utt);
                }
            }
        });
    };

    window.triggerSampleCommand = function (txt, mode) {
        document.getElementById('biNaturalPromptInput').value = txt;
        document.getElementById('biBuildModeInput').value = mode;
        runInstantNlPreview(mode);
    };

    // تشخیص گفتار زنده فارسی با Web Speech API
    let recognition = null;
    let isListening = false;
    window.toggleBiVoiceRecognition = function () {
        const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
        const btn = document.getElementById('biVoiceMicBtn');
        const lbl = document.getElementById('biMicLabel');
        document.getElementById('biBuildModeInput').value = 'voice';

        if (!SR) {
            const demoVoice = 'مقایسه راداری بودجه دفاتر نمایندگی شهرستان‌ها';
            document.getElementById('biNaturalPromptInput').value = demoVoice;
            setStatusBadge('مرورگر فاقد میکروفون زنده است؛ نمونه فرمان صوتی به صورت خودکار اجرا شد');
            runInstantNlPreview('voice');
            return;
        }
        if (isListening && recognition) {
            recognition.stop();
            return;
        }
        recognition = new SR();
        recognition.lang = 'fa-IR';
        recognition.interimResults = true;
        recognition.onstart = function () {
            isListening = true;
            btn.classList.add('recording');
            lbl.textContent = 'در حال شنیدن صدای شما...';
            setStatusBadge('🎙️ میکروفون فعال است — گزارش، داشبورد یا هدف مورد نظر را بیان کنید...');
        };
        recognition.onresult = function (event) {
            let transcript = '';
            for (let i = event.resultIndex; i < event.results.length; ++i) {
                transcript += event.results[i][0].transcript;
            }
            document.getElementById('biNaturalPromptInput').value = transcript;
        };
        recognition.onend = function () {
            isListening = false;
            btn.classList.remove('recording');
            lbl.textContent = 'فرمان صوتی فارسی';
            if (document.getElementById('biNaturalPromptInput').value.trim() !== '') {
                runInstantNlPreview('voice');
            }
        };
        recognition.start();
    };

    window.speakExecutiveBiSummary = function () {
        const msg = 'خلاصه مدیریتی هوش تجاری مؤسسه آموزشی آدان: میانگین تحقق اهداف راهبردی '
            + '<?= fa($kpis['avg_goal_pct']) ?> درصد و شاخص رضایت دوره‌ها <?= fa($kpis['courses_satisfaction_pct']) ?> درصد است. '
            + 'در گزارش فعال فعلی، دسته ' + (currentBuilderState.summary.top_item || '') + ' بیشترین سهم را دارد.';
        setStatusBadge('🔊 در حال خوانش صوتی گزارش مدیریتی...');
        if (window.speechSynthesis) {
            window.speechSynthesis.cancel();
            const u = new SpeechSynthesisUtterance(msg);
            u.lang = 'fa-IR';
            window.speechSynthesis.speak(u);
        }
    };

    // رهاسازی درگ‌انددراپ شاخص روی فرم هدف‌گذاری
    window.onGoalSourceDrop = function (ev) {
        ev.preventDefault();
        ev.currentTarget.classList.remove('active-drop');
        try {
            const p = JSON.parse(ev.dataTransfer.getData('text/plain'));
            document.getElementById('goalSourceSelect').value = p.source;
            document.getElementById('goalTitleInput').value = 'ارتقای ' + p.label + ' در دوره جاری';
            document.getElementById('goalViaInput').value = 'drag_drop';
            setStatusBadge('شاخص با درگ‌انددراپ در فرم هدف‌گذاری قرار گرفت');
        } catch (err) {}
    };

    // شبیه‌ساز بلادرنگ What-If
    window.recalcWhatIfLive = function () {
        const t = Number(document.getElementById('wiTuition').value);
        const e = Number(document.getElementById('wiEnroll').value);
        const b = Number(document.getElementById('wiB2b').value);
        const c = Number(document.getElementById('wiCost').value);

        document.getElementById('lblWiTuition').textContent = (t >= 0 ? '+' : '') + toFaNum(t) + '٪';
        document.getElementById('lblWiEnroll').textContent = (e >= 0 ? '+' : '') + toFaNum(e) + '٪';
        document.getElementById('lblWiB2b').textContent = toFaNum(b) + '٪';
        document.getElementById('lblWiCost').textContent = (c >= 0 ? '+' : '') + toFaNum(c) + '٪';

        const projRev = Math.round(BI_BASE_REVENUE * (1 + t / 100) * (1 + e / 100) * (1 + b / 250));
        const projCost = Math.round((BI_BASE_REVENUE * 0.58) * (1 + c / 100) * (1 + (e * 0.35) / 100));
        const surplus = projRev - projCost;

        document.getElementById('wiOutRev').textContent = toFaNum(projRev) + ' ریال';
        document.getElementById('wiOutSurplus').textContent = toFaNum(surplus) + ' ریال';

        const ratio = Math.min(100, Math.max(15, Math.round((projRev / (BI_BASE_REVENUE * 1.8)) * 100)));
        document.getElementById('wiCompareBars').innerHTML = `
            <div style="font-size:11.5px;margin-bottom:4px">مقایسه درآمد پایه فعلی با سناریوی شبیه‌سازی‌شده:</div>
            <div style="height:10px;background:var(--border);border-radius:99px;margin-bottom:6px;overflow:hidden">
                <div style="width:55%;height:100%;background:#64748b"></div>
            </div>
            <div style="height:12px;background:var(--border);border-radius:99px;overflow:hidden">
                <div style="width:${ratio}%;height:100%;background:#10b981;transition:width .2s"></div>
            </div>`;
    };

    window.switchBiStudioTab = function (tabId, btnEl) {
        document.querySelectorAll('.bi-studio-section').forEach(s => s.style.display = 'none');
        const target = document.getElementById('biSection_' + tabId);
        if (target) target.style.display = 'block';
        document.querySelectorAll('.bi-tab-btn').forEach(b => b.classList.remove('active'));
        if (btnEl) btnEl.classList.add('active');
    };

    function setStatusBadge(txt) {
        const el = document.getElementById('biLiveStatusBadge');
        if (el) el.textContent = txt;
    }

    // مقداردهی اولیه کامل هنگام بارگذاری صفحه
    renderAllDashboardWidgets();
    bindDashboardDragAndDrop();
    populateBuilderSelectors(currentBuilderState.dimension_field, currentBuilderState.metric_field);
    applyBuilderResultToDom(currentBuilderState);
    recalcWhatIfLive();
})();
</script>
