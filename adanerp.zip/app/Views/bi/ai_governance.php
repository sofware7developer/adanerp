<div class="hero-banner">
    <div>
        <span class="badge badge-gold">مرکز فرماندهی هوش مصنوعی و یکپارچه‌سازی</span>
        <h1>مدیریت درگاه هوش مصنوعی (AI) / Ollama، پرامپت‌ها، سهمیه، RAG و وب‌هوک</h1>
        <p>مدیریت متمرکز کلیدهای API سمت سرور، انتخاب مدل، لاگ مصرف توکن‌ها، مخزن دانش RAG مؤسسه آموزشی آدان، صف کارها و وب‌هوک‌ها.</p>
    </div>
    <form method="post" action="<?= e(url('ai-governance')) ?>">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="test_live_ai">
        <button type="submit" class="btn btn-gold">⚡ تست اتصال زنده درگاه AI</button>
    </form>
</div>

<div class="alert alert-warning">
    <div>
        <strong>امنیت کلیدها و وضعیت اتصال زنده:</strong> کلید API منحصراً سمت سرور در پایگاه داده نگهداری می‌شود و هرگز به مرورگر ارسال نمی‌گردد. <strong>وضعیت فعلی کلید AI: <?= $hasLiveKey ? '✅ کلید ثبت شده است' : '⚠️ کلید زنده هنوز وارد نشده (حالت شبیه‌ساز شفاف فعال است)' ?></strong> — اتصال زندهٔ درگاه AI / Ollama در محیط عملیاتی واقعی باید توسط مدیر فناوری اطلاعات تنظیم و با دکمه بالا آزموده شود.
    </div>
</div>

<?php if ($pingResult): ?>
    <div class="card" style="border-color:var(--primary)">
        <div class="card-header">
            <div class="card-title">نتیجه آزمون اتصال درگاه هوش مصنوعی</div>
            <span class="badge badge-info">حالت اجرا: <?= e($pingResult['mode']) ?></span>
        </div>
        <div class="pre-box"><?= e($pingResult['content']) ?></div>
    </div>
<?php endif; ?>

<div class="grid grid-2">
    <!-- GATEWAY CONFIG -->
    <div class="card">
        <div class="card-header"><div class="card-title">🔑 پیکربندی درگاه AI API و Ollama محلی</div></div>
        <form method="post" action="<?= e(url('ai-governance')) ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="save_gateway">
            <div class="form-grid">
                <div class="form-group">
                    <label>ارائه‌دهنده فعال:</label>
                    <select name="active_ai_provider">
                        <option value="ai" <?= $provider !== 'ollama' ? 'selected' : '' ?>>درگاه ابری AI API</option>
                        <option value="ollama" <?= $provider === 'ollama' ? 'selected' : '' ?>>Ollama Local (سرور محلی اتاق)</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>مدل پیش‌فرض:</label>
                    <select name="ai_default_model">
                        <option value="gpt-4o-mini" <?= ($aiModel ?? 'gpt-4o-mini') === 'gpt-4o-mini' ? 'selected' : '' ?>>gpt-4o-mini (سریع و اقتصادی)</option>
                        <option value="gpt-4o" <?= ($aiModel ?? '') === 'gpt-4o' ? 'selected' : '' ?>>gpt-4o (تحلیلی پیشرفته)</option>
                        <option value="gemini-2.0-flash" <?= ($aiModel ?? '') === 'gemini-2.0-flash' ? 'selected' : '' ?>>gemini-2.0-flash</option>
                        <option value="deepseek-chat" <?= ($aiModel ?? '') === 'deepseek-chat' ? 'selected' : '' ?>>deepseek-chat</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label>نشانی پایه درگاه AI API:</label>
                <input type="url" name="ai_base_url" value="<?= e($aiUrl ?? 'https://api.openai.com/v1') ?>" dir="ltr">
            </div>
            <div class="form-group">
                <label>کلید اختصاصی AI API Key (سمت سرور):</label>
                <input type="password" name="ai_api_key" value="<?= e($maskedKey) ?>" placeholder="sk-xxxxxxxxxxxxxxxxxxxxxxxx" dir="ltr">
            </div>
            <div class="form-group">
                <label>نشانی سرور محلی Ollama (در صورت انتخاب):</label>
                <input type="url" name="ollama_base_url" value="<?= e($ollamaUrl) ?>" dir="ltr">
            </div>
            <button type="submit" class="btn btn-primary">ذخیره تنظیمات دروازه AI</button>
        </form>
    </div>

    <!-- RAG KNOWLEDGE BASE -->
    <div class="card">
        <div class="card-header"><div class="card-title">🧠 مخزن دانش سازمانی (RAG) و دستورالعمل‌های داخلی</div></div>
        <form method="post" action="<?= e(url('ai-governance')) ?>" style="margin-bottom:14px">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="add_rag_doc">
            <div class="form-grid">
                <input type="text" name="title" required placeholder="عنوان مصوبه / آیین‌نامه">
                <input type="text" name="category" value="بخشنامه آموزشی">
            </div>
            <div class="form-group" style="margin-top:8px">
                <input type="text" name="keywords" required placeholder="کلیدواژه‌های بازیابی (مثلاً: تقسیط گمرک تخفیف)">
            </div>
            <div class="form-group">
                <textarea name="chunk_text" rows="2" required placeholder="متن مستند جهت تزریق به همراه هوشمند..."></textarea>
            </div>
            <button type="submit" class="btn btn-outline btn-sm">افزودن قطعه دانشی به RAG</button>
        </form>

        <?php foreach ($ragDocs as $rd): ?>
            <div style="border-top:1px solid var(--border);padding:8px 0;font-size:12.5px">
                <strong><?= e($rd['title']) ?></strong> <span class="badge badge-info"><?= e($rd['keywords']) ?></span>
                <div class="muted"><?= e($rd['chunk_text']) ?></div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- PROMPTS STUDIO + INTEGRATION READINESS MATRIX -->
<div class="grid grid-2">
    <div class="card">
        <div class="card-header"><div class="card-title">📝 مدیریت پرامپت‌های سازمانی و سهمیه توکن روزانه</div></div>
        <form method="post" action="<?= e(url('ai-governance')) ?>" style="margin-bottom:14px">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="save_prompt_template">
            <div class="form-grid">
                <input type="text" name="prompt_key" value="EXPORT_ADVISOR_FA" dir="ltr" required placeholder="کلید پرامپت">
                <input type="text" name="title" value="پرامپت مشاور قوانین صادراتی" required>
                <input type="text" name="model_name" value="gpt-4o-mini" dir="ltr" required>
                <input type="number" name="daily_token_quota" value="60000" required>
            </div>
            <div class="form-group" style="margin-top:8px">
                <textarea name="system_prompt" rows="2" required>شما مشاور ارشد قوانین گمرکی و مقررات تجارت خارجی مؤسسه آموزشی آدان هستید.</textarea>
            </div>
            <button type="submit" class="btn btn-gold btn-sm">ذخیره / به‌روزرسانی پرامپت سازمانی</button>
        </form>
        <?php foreach ($prompts as $pr): ?>
            <div style="border-top:1px solid var(--border);padding:7px 0;font-size:12px">
                <strong><?= e($pr['title']) ?></strong> (<code><?= e($pr['prompt_key']) ?></code>) — سقف روزانه: <?= fa($pr['daily_token_quota']) ?> توکن
                <div class="muted"><?= e($pr['system_prompt']) ?></div>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="card">
        <div class="card-header"><div class="card-title">🛡️ ماتریس شفاف وضعیت یکپارچه‌سازی‌های خارجی و حسابداری هزینه توکن AI</div></div>
        <?php foreach (($costByModule ?? []) as $cm):
            $tok = (int)$cm['total_tokens'];
            $usd = round(($tok / 1000000) * 0.60, 4);
            $rialCost = (int)round($usd * 610000);
        ?>
            <div style="display:flex;justify-content:space-between;background:var(--surface-2);padding:6px 10px;border-radius:8px;margin-bottom:6px;font-size:12px">
                <span><strong><?= e($cm['module_name']) ?></strong> (<?= fa($cm['calls_cnt']) ?> فراخوانی)</span>
                <span><?= fa(number_format($tok)) ?> توکن ≈ <strong>$<?= $usd ?></strong> (<?= rial($rialCost) ?>)</span>
            </div>
        <?php endforeach; ?>
        <?php foreach ($readinessMatrix as $rm): ?>
            <div style="border-bottom:1px solid var(--border);padding:8px 0;font-size:12.5px">
                <div style="display:flex;justify-content:space-between;align-items:center">
                    <strong><?= e($rm['subsystem']) ?></strong>
                    <span class="badge <?= e($rm['badge']) ?>"><?= e($rm['status']) ?></span>
                </div>
                <div class="muted" style="font-size:11.5px;margin-top:3px"><?= e($rm['note']) ?></div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- PROMPTS + USAGE LOGS + WEBHOOKS -->
<div class="grid grid-2">
    <div class="card">
        <div class="card-header"><div class="card-title">📊 لاگ مصرف توکن‌ها، مدل‌ها و تأخیر پاسخ</div></div>
        <div class="table-wrap">
            <table>
                <thead><tr><th>کاربر</th><th>ماژول</th><th>مدل</th><th>توکن کل</th><th>حالت</th></tr></thead>
                <tbody>
                <?php foreach ($usageLogs as $lg): ?>
                    <tr>
                        <td><?= e($lg['full_name'] ?? 'سیستم') ?></td>
                        <td><?= e($lg['module_name']) ?></td>
                        <td><code><?= e($lg['model_name']) ?></code></td>
                        <td><?= fa((int)$lg['prompt_tokens'] + (int)$lg['completion_tokens']) ?></td>
                        <td><span class="badge <?= $lg['execution_mode'] === 'live_api' ? 'badge-success' : 'badge-warning' ?>"><?= e($lg['execution_mode']) ?></span></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <div>
                <div class="card-title">صف کارها و پیش‌نویس وب‌هوک‌ها</div>
                <div class="muted" style="font-size:12px">ارسال وب‌هوک بیرونی پیاده‌سازی یا فعال نشده است؛ URLها فقط به‌صورت محلی نگهداری می‌شوند.</div>
            </div>
        </div>
        <form method="post" action="<?= e(url('ai-governance')) ?>" class="form-grid" style="margin-bottom:12px">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="add_webhook">
            <input type="text" name="name" required placeholder="نام سامانه مقصد">
            <input type="url" name="target_url" required placeholder="https://api.example.com/webhook" dir="ltr">
            <input type="hidden" name="event_trigger" value="certificate.issued">
            <button type="submit" class="btn btn-outline btn-sm">ثبت پیش‌نویس محلی</button>
        </form>
        <?php foreach ($webhooks as $wh): ?>
            <div style="border-top:1px solid var(--border);padding:8px 0;font-size:12.5px">
                <span class="badge <?= $wh['entry_kind'] === 'webhook' ? 'badge-warning' : 'badge-purple' ?>"><?= $wh['entry_kind'] === 'webhook' ? 'پیش‌نویس محلی' : e($wh['entry_kind']) ?></span>
                <strong><?= e($wh['name']) ?></strong> — <code><?= e($wh['event_trigger']) ?></code>
                <div class="muted"><?= e($wh['last_response']) ?></div>
            </div>
        <?php endforeach; ?>
    </div>
</div>
