<?php
$roleList = [
    'super_admin' => 'مدیرکل آموزش',
    'training_expert' => 'کارشناس آموزش',
    'finance_manager' => 'مدیر مالی',
    'crm_manager' => 'مدیر CRM',
    'instructor' => 'مدرس دوره',
    'org_rep' => 'نماینده سازمان',
    'learner' => 'فراگیر',
];
?>
<div class="hero-banner">
    <div>
        <span class="badge badge-gold">فاز عملیاتی استقرار | مرکز سلامت سرور، پشتیبان‌گیری SQL و ممیزی امنیتی (XAMPP &amp; cPanel)</span>
        <h1>⚙️ مرکز عملیات سامانه، پشتیبان‌گیری یک‌کلیکی SQL، Cron و ماتریس دسترسی RBAC</h1>
        <p>تهیه نسخه پشتیبان کامل UTF-8mb4 از پایگاه‌داده بدون نیاز به <code>exec/mysqldump</code> (ویژه هاست اشتراکی cPanel)، عیب‌یاب سرور و ماتریس دسترسی نقش‌ها.</p>
    </div>
    <div class="hero-actions">
        <a class="btn btn-gold" href="<?= e(url('system-ops', ['download_sql' => '1'])) ?>">💾 دانلود پشتیبان کامل SQL پایگاه‌داده</a>
        <a class="btn btn-outline" href="<?= e(url('system-ops', ['export_audit' => '1'])) ?>" style="background:#fff">📥 خروجی Excel/CSV لاگ ممیزی</a>
    </div>
</div>

<div class="grid grid-4">
    <div class="kpi-card">
        <div class="kpi-icon" style="background:#dcfce7;color:#15803d">🗄️</div>
        <div><div class="kpi-val"><?= fa($stats['tables']) ?></div><div class="kpi-lbl">جداول فعال MariaDB</div></div>
    </div>
    <div class="kpi-card">
        <div class="kpi-icon" style="background:#dbeafe;color:#1d4ed8">👥</div>
        <div><div class="kpi-val"><?= fa($stats['users']) ?></div><div class="kpi-lbl">حساب‌های کاربری و نقش‌ها</div></div>
    </div>
    <div class="kpi-card">
        <div class="kpi-icon" style="background:#fef3c7;color:#b45309">📚</div>
        <div><div class="kpi-val"><?= fa($stats['courses']) ?></div><div class="kpi-lbl">دوره‌های کاتالوگ آموزشی</div></div>
    </div>
    <div class="kpi-card">
        <div class="kpi-icon" style="background:#f3e8ff;color:#7e22ce">🛡️</div>
        <div><div class="kpi-val"><?= fa($stats['audit_logs']) ?></div><div class="kpi-lbl">وقایع ثبت‌شده ممیزی (Audit)</div></div>
    </div>
</div>

<div class="grid grid-sidebar">
    <!-- SERVER & CPANEL/XAMPP HEALTH DOCTOR -->
    <div class="card">
        <div class="card-header">
            <div class="card-title">🩺 عیب‌یاب زنده محیط اجرایی (XAMPP / cPanel Environment Doctor)</div>
            <span class="badge badge-success">پایش خودکار هسته</span>
        </div>
        <div class="table-wrap">
            <table>
                <thead>
                <tr>
                    <th>شاخص فنی</th>
                    <th>وضعیت شناسایی‌شده</th>
                    <th>تأیید</th>
                    <th>راهنمای بهره‌برداری</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($health as $h): ?>
                    <tr>
                        <td><strong><?= e($h['check']) ?></strong></td>
                        <td dir="ltr" style="text-align:right"><code><?= e($h['value']) ?></code></td>
                        <td><span class="badge <?= $h['ok'] ? 'badge-success' : 'badge-danger' ?>"><?= $h['ok'] ? 'سالم' : 'نیاز به بررسی' ?></span></td>
                        <td class="muted" style="font-size:12px"><?= e($h['hint']) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- CRON RUNNER & CPANEL COMMAND -->
    <div class="card">
        <div class="card-header"><div class="card-title">⏱️ اجرای وظایف زمان‌بندی‌شده (Cron Jobs)</div></div>
        <p style="font-size:12.5px;margin-bottom:10px">
            این فرایند گزارش میانگین نمره ثبت‌نام‌ها به تفکیک کانال جذب را از داده‌های واقعی تولید و زمان سپری‌شدهٔ گردش‌کارهای باز را از زمان ایجادشان محاسبه می‌کند. کارهای بدون پردازشگر به‌عنوان ناموفق ثبت می‌شوند؛ ارسال ایمیل یا پایش بازار در این Cron انجام نمی‌شود.
        </p>
        <div class="pre-box" dir="ltr" style="font-size:11.5px;text-align:left;margin-bottom:12px">/usr/local/bin/php /home/USERNAME/public_html/cron.php</div>
        <p style="font-size:12px;margin-bottom:6px">دستور ویندوز برای نصب فعلی XAMPP:</p>
        <div class="pre-box" dir="ltr" style="font-size:11.5px;text-align:left;margin-bottom:12px">E:\xampp4\php\php.exe E:\xampp4\htdocs\adanerp\cron.php</div>
        <p class="muted" style="font-size:12px">برای اجرای خودکار در ویندوز، این دستور را در Task Scheduler زمان‌بندی کنید. اجرای مستقیم از مرورگر غیرفعال است.</p>
        <form method="post" action="<?= e(url('system-ops')) ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="run_cron_now">
            <button type="submit" class="btn btn-primary" style="width:100%">▶️ اجرای فوری وظایف صف Cron در همین لحظه</button>
        </form>
        <?php if ($cronJobs !== []): ?>
            <div class="table-wrap" style="margin-top:14px">
                <table>
                    <thead><tr><th>کار</th><th>وضعیت</th><th>آخرین اجرا</th><th>آخرین نتیجه</th></tr></thead>
                    <tbody>
                    <?php foreach ($cronJobs as $job): ?>
                        <tr>
                            <td><?= e($job['name']) ?></td>
                            <td><span class="badge <?= $job['status'] === 'completed' ? 'badge-success' : ($job['status'] === 'failed' ? 'badge-danger' : 'badge-info') ?>"><?= e($job['status']) ?></span></td>
                            <td><?= e($job['last_run_at'] ?? '—') ?></td>
                            <td><?= e($job['last_response'] ?? '—') ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- VISUAL RBAC MATRIX ACROSS ALL 24 MODULES -->
<div class="card">
    <div class="card-header">
        <div class="card-title">🔐 ماتریس جامع کنترل دسترسی سطح مسیر (RBAC) در بخش‌های سامانه تخصصی سامانه</div>
        <span class="badge badge-info">اعمال اجباری در Router سمت سرور</span>
    </div>
    <div class="table-wrap">
        <table>
            <thead>
            <tr>
                <th>ماژول تخصصی</th>
                <?php foreach ($roleList as $rKey => $rTitle): ?>
                    <th style="text-align:center;font-size:11.5px"><?= e($rTitle) ?></th>
                <?php endforeach; ?>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($phases['modules'] as $mod): ?>
                <tr>
                    <td>
                        <a href="<?= e(url($mod['route'])) ?>" style="font-weight:800;color:var(--primary);text-decoration:none">
                            <?= e($mod['icon'] ?? '📌') ?> <?= e($mod['title']) ?>
                        </a>
                    </td>
                    <?php foreach ($roleList as $rKey => $rTitle): ?>
                        <?php $allowed = in_array($rKey, $mod['roles'], true); ?>
                        <td style="text-align:center">
                            <span class="badge <?= $allowed ? 'badge-success' : 'badge-danger' ?>"><?= $allowed ? '✓' : '—' ?></span>
                        </td>
                    <?php endforeach; ?>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
