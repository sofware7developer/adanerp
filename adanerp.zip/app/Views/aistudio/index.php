<div class="hero-banner">
    <div>
        <span class="badge badge-gold">استودیوی هوشمند AI</span>
        <h1>استودیوی تولید محتوا با AI، نسخه‌بندی و بازبینی انسانی</h1>
        <p>تولید پیش‌نویس سرفصل دوره، طرح درس، آزمون، خردآموزی، اسلاید و خلاصه همراه با استخراج متن از فایل‌های مرجع (DOCX/TXT/MD/CSV).</p>
    </div>
</div>

<div class="alert alert-warning">
    <div>
        <strong>گاردریل حاکمیتی اجباری:</strong> تمامی خروجی‌های تولیدشده توسط هوش مصنوعی صرفاً <strong>«پیش‌نویس اولیه (ai_draft)»</strong> هستند و انتشار نهایی آن‌ها بدون <strong>بازبینی و تأیید انسانی (Human-in-the-Loop)</strong> در سطح سرور مسدود است.
    </div>
</div>

<div class="grid grid-sidebar">
    <!-- GENERATOR FORM -->
    <div class="card">
        <div class="card-header"><div class="card-title">✨ میز کار تولید پیش‌نویس هوشمند با AI</div></div>
        <form method="post" action="<?= e(url('ai-studio')) ?>" enctype="multipart/form-data">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="generate_draft">
            <div class="form-grid">
                <div class="form-group">
                    <label>قالب خروجی آموزشی:</label>
                    <select name="content_kind">
                        <option value="course_draft">پیش‌نویس کامل سرفصل دوره</option>
                        <option value="lesson_plan">طرح درس استاندارد جلسه‌ای</option>
                        <option value="quiz">بانک سؤالات آزمون چهارگزینه‌ای و تشریحی</option>
                        <option value="microlearning">بسته خردآموزی ۵ دقیقه‌ای</option>
                        <option value="slides">ساختار اسلایدهای ارائه مدرس</option>
                        <option value="summary">خلاصه‌سازی اجرایی بخشنامه تجاری</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>پیوند به دوره کاتالوگ (اختیاری):</label>
                    <select name="course_id">
                        <option value="">— مستقل / دوره جدید —</option>
                        <?php foreach ($courses as $c): ?>
                            <option value="<?= (int)$c['id'] ?>">[<?= e($c['code']) ?>] <?= e($c['title']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label>عنوان بسته محتوایی:</label>
                <input type="text" name="title" required placeholder="مثلاً: طرح درس و آزمون کارگاه عملی تهاتر ارزی و کوتاژ صادراتی">
            </div>

            <div class="form-group">
                <label>شرح نیاز، سطح مخاطبان و نکات کلیدی مورد انتظار:</label>
                <textarea name="prompt_brief" rows="3" required placeholder="مخاطبان مدیران بازرگانی صنایع دانش‌پذیر آدان هستند؛ تمرکز بر مثال‌های واقعی گمرک و بانک مرکزی باشد..."></textarea>
            </div>

            <div class="form-group">
                <label>استخراج خودکار متن از فایل پیوست مرجع (.docx, .txt, .md, .csv):</label>
                <input type="file" name="source_file" accept=".docx,.txt,.md,.csv,.html">
            </div>

            <button type="submit" class="btn btn-primary">🤖 تولید پیش‌نویس اولیه در استودیوی AI</button>
        </form>
    </div>

    <!-- VERSION HISTORY LOG -->
    <div class="card">
        <div class="card-header"><div class="card-title">🕓 تاریخچه نسخه‌بندی محتوا و مقایسه تغییرات (Version & Diff)</div></div>
        <?php foreach ($versions as $v): ?>
            <div style="border-bottom:1px solid var(--border);padding:9px 0;font-size:12.5px">
                <span class="badge badge-purple">نسخه <?= fa($v['version_no']) ?></span>
                <strong><?= e($v['change_note']) ?></strong>
                <div class="muted">ویرایشگر: <?= e($v['full_name']) ?></div>
            </div>
        <?php endforeach; ?>
        <?php if (count($versions) >= 2): ?>
            <details style="margin-top:12px;background:#f8fafc;border:1px dashed var(--border);padding:10px;border-radius:10px;font-size:12px">
                <summary style="cursor:pointer;font-weight:700;color:var(--primary)">🔍 مقایسه متنی دو نسخه اخیر ثبت‌شده (Diff Viewer)</summary>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px">
                    <div style="background:#fef2f2;padding:8px;border-radius:8px"><strong>نسخه قبلی (v<?= fa($versions[1]['version_no']) ?>):</strong><br><?= nl2br(e(mb_substr((string)$versions[1]['body_snapshot'], 0, 260))) ?></div>
                    <div style="background:#f0fdf4;padding:8px;border-radius:8px"><strong>آخرین نسخه (v<?= fa($versions[0]['version_no']) ?>):</strong><br><?= nl2br(e(mb_substr((string)$versions[0]['body_snapshot'], 0, 260))) ?></div>
                </div>
            </details>
        <?php endif; ?>
    </div>
</div>

<!-- REVIEW & PUBLISH WORKBENCH -->
<div class="card">
    <div class="card-header"><div class="card-title">🧐 کارتابل بازبینی انسانی، ویرایش نسخه، خروجی Office و انتشار نهایی</div></div>
    <?php foreach ($items as $it): ?>
        <div style="border:1px solid var(--border);border-radius:14px;padding:16px;margin-bottom:16px">
            <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:10px">
                <div>
                    <span class="badge badge-info"><?= e($it['content_kind']) ?></span>
                    <strong style="font-size:15px;margin-right:6px"><?= e($it['title']) ?></strong>
                    <span class="badge badge-gold">نسخه فعلی: v<?= fa($it['current_version']) ?></span>
                </div>
                <div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center">
                    <a class="btn btn-outline btn-sm" href="<?= e(url('ai-studio?download_pptx=' . (int)$it['id'])) ?>">📊 دانلود PowerPoint (.pptx)</a>
                    <a class="btn btn-outline btn-sm" href="<?= e(url('ai-studio?download_docx=' . (int)$it['id'])) ?>">📄 دانلود Word (.docx)</a>
                    <span class="badge <?= $it['review_status'] === 'published' ? 'badge-success' : ($it['review_status'] === 'human_approved' ? 'badge-info' : 'badge-warning') ?>">
                        وضعیت: <?= e($it['review_status']) ?>
                    </span>
                </div>
            </div>

            <form method="post" action="<?= e(url('ai-studio')) ?>">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="save_human_revision">
                <input type="hidden" name="ai_content_id" value="<?= (int)$it['id'] ?>">
                <div class="form-group">
                    <textarea name="body_markdown" rows="5"><?= e($it['body_markdown']) ?></textarea>
                </div>
                <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center">
                    <input type="text" name="change_note" placeholder="یادداشت بازبینی این نسخه..." style="max-width:340px">
                    <select name="decision" style="width:230px">
                        <option value="human_approved">۱. ثبت ویرایش و تأیید انسانی</option>
                        <?php if ($it['review_status'] === 'human_approved' || $it['review_status'] === 'published'): ?>
                            <option value="published" selected>۲. انتشار نهایی در سامانه (تأیید شده)</option>
                        <?php endif; ?>
                    </select>
                    <button type="submit" class="btn btn-primary btn-sm">ذخیره نسخه جدید و اعمال تصمیم انسانی</button>
                </div>
            </form>
        </div>
    <?php endforeach; ?>
</div>
