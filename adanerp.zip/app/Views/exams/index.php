<?php
use App\Core\Auth;
use App\Core\QrSvg;
$stdCategoryCounts = array_count_values(array_column($stdCatalog ?? [], 'cat_key'));
$stdTestCount = count($stdCatalog ?? []);
$selfAssessmentCodes = ['MBTI', 'DISC', 'NEO_BIG5', 'EQ_BARON'];
$stdClientCatalog = $stdCatalog ?? [];
foreach ($stdClientCatalog as &$clientTest) {
    foreach ($clientTest['questions'] as &$clientQuestion) {
        unset($clientQuestion['correct']);
    }
    unset($clientQuestion);
}
unset($clientTest);
?>
<div class="hero-banner">
    <div>
        <span class="badge badge-gold">آزمون‌های داخلی، بانک سؤال و ثبت گواهی پایان دوره</span>
        <h1>آزمون‌های آموزشی آدان و سوابق ارزیابی</h1>
        <p>اجرای فوری ۱-کلیکی آزمون‌های معتبر شخصیت‌شناسی (MBTI, DISC, NEO, EQ)، استعدادیابی شغلی (هالند، کلیفتون، TKI، شاین، GMAT)، تعیین سطح زبان (انگلیسی CEFR، عربی، ترکی/روسی) و صلاحیت حرفه‌ای اتاق.</p>
    </div>
    <div class="stat-card" style="background:rgba(255,255,255,0.12);border-color:rgba(255,255,255,0.25);color:#fff;padding:12px 18px">
        <div>
            <div style="font-size:11.5px;opacity:0.85">تایمر معکوس زنده آزمون</div>
            <?php $timerMinutes = (int)($exam['duration_minutes'] ?? 25); ?>
            <div id="liveExamTimer" data-seconds="<?= $timerMinutes * 60 ?>" style="font-size:22px;font-weight:900" dir="ltr"><?= sprintf('%02d:%02d', intdiv($timerMinutes, 60), $timerMinutes % 60) ?></div>
        </div>
    </div>
</div>

<?php if (!empty($availableExams)): ?>
    <div class="card" style="margin-bottom:18px">
        <form method="get" action="<?= e(url('exams')) ?>" style="display:flex;gap:10px;align-items:end;flex-wrap:wrap">
            <div class="form-group" style="margin:0;min-width:280px;flex:1">
                <label>آزمون دوره</label>
                <select name="exam_id" onchange="this.form.submit()">
                    <?php foreach ($availableExams as $availableExam): ?>
                        <option value="<?= (int)$availableExam['id'] ?>" <?= (int)($exam['id'] ?? 0) === (int)$availableExam['id'] ? 'selected' : '' ?>>
                            <?= e($availableExam['course_title']) ?> — <?= e($availableExam['title']) ?>
                            <?= (int)$availableExam['is_active'] === 1 ? '' : ' (پیش‌نویس)' ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button type="submit" class="btn btn-outline btn-sm">نمایش آزمون</button>
            <span class="muted">دسترسی فراگیران از ثبت‌نام فعال در اجرای همان دوره تعیین می‌شود.</span>
        </form>
    </div>
<?php endif; ?>

<?php if (Auth::hasRole(['super_admin', 'training_expert'])): ?>
    <div class="card" style="margin-bottom:18px">
        <div class="card-header"><div class="card-title">تعریف و انتشار آزمون دوره</div></div>
        <form method="post" action="<?= e(url('exams')) ?>" class="form-grid">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="create_exam">
            <div class="form-group">
                <label>دوره</label>
                <select name="course_id" required>
                    <?php foreach ($courses as $course): ?>
                        <option value="<?= (int)$course['id'] ?>"><?= e($course['title']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group"><label>عنوان آزمون</label><input type="text" name="title" maxlength="200" required></div>
            <div class="form-group"><label>مدت (دقیقه)</label><input type="number" name="duration_minutes" min="1" max="600" value="60" required></div>
            <div class="form-group"><label>حداکثر تلاش</label><input type="number" name="max_attempts" min="1" max="10" value="2" required></div>
            <div class="form-group"><label>حدنصاب قبولی (از ۱۰۰)</label><input type="number" name="pass_score" min="1" max="100" step="0.01" value="70" required></div>
            <div style="align-self:end"><button type="submit" class="btn btn-primary">ساخت پیش‌نویس آزمون</button></div>
        </form>
        <?php if ($canEditExamSettings): ?>
            <form method="post" action="<?= e(url('exams')) ?>" class="form-grid" style="border-top:1px solid var(--border);margin-top:14px;padding-top:14px">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="update_exam">
                <input type="hidden" name="exam_id" value="<?= (int)$exam['id'] ?>">
                <div class="form-group">
                    <label>دوره</label>
                    <select name="course_id" required>
                        <?php foreach ($courses as $course): ?>
                            <option value="<?= (int)$course['id'] ?>" <?= (int)$exam['course_id'] === (int)$course['id'] ? 'selected' : '' ?>><?= e($course['title']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group"><label>عنوان آزمون پیش‌نویس</label><input type="text" name="title" maxlength="200" value="<?= e($exam['title']) ?>" required></div>
                <div class="form-group"><label>مدت (دقیقه)</label><input type="number" name="duration_minutes" min="1" max="600" value="<?= (int)$exam['duration_minutes'] ?>" required></div>
                <div class="form-group"><label>حداکثر تلاش</label><input type="number" name="max_attempts" min="1" max="10" value="<?= (int)$exam['max_attempts'] ?>" required></div>
                <div class="form-group"><label>حدنصاب قبولی</label><input type="number" name="pass_score" min="1" max="100" step="0.01" value="<?= e($exam['pass_score']) ?>" required></div>
                <div style="align-self:end"><button type="submit" class="btn btn-outline">ذخیره مشخصات آزمون</button></div>
            </form>
        <?php endif; ?>
        <?php foreach ($availableExams as $availableExam): ?>
            <?php if (Auth::hasRole(['super_admin', 'training_expert'])): ?>
                <form method="post" action="<?= e(url('exams')) ?>" style="display:inline-flex;gap:6px;align-items:center;margin:8px 8px 0 0">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="toggle_exam">
                    <input type="hidden" name="exam_id" value="<?= (int)$availableExam['id'] ?>">
                    <span><?= e($availableExam['course_title']) ?> — <?= e($availableExam['title']) ?></span>
                    <span class="badge <?= (int)$availableExam['is_active'] === 1 ? 'badge-success' : 'badge-gold' ?>"><?= (int)$availableExam['is_active'] === 1 ? 'منتشر' : 'پیش‌نویس' ?></span>
                    <button type="submit" class="btn btn-outline btn-sm"><?= (int)$availableExam['is_active'] === 1 ? 'لغو انتشار' : 'انتشار' ?></button>
                </form>
            <?php endif; ?>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<!-- ==================== STANDARDIZED TESTS HUB ==================== -->
<div class="card" style="margin-bottom:20px;border:1px solid rgba(15,118,110,0.28)">
    <div class="card-header" style="flex-wrap:wrap;gap:10px">
        <div>
            <div class="card-title" style="font-size:16px">مرکز آزمون‌های استاندارد و پیش‌ساخته (<?= fa($stdTestCount) ?> عنوان)</div>
            <div class="muted" style="font-size:12px;margin-top:3px">
                این خودارزیابی‌ها برای رشد آموزشی و گفت‌وگوی شغلی طراحی شده‌اند؛ آزمون رسمیِ هنجاریابی‌شده یا جایگزین تشخیص بالینی/پزشکی نیستند.
            </div>
        </div>
        <div style="display:flex;gap:6px;flex-wrap:wrap" id="stdCatTabs">
            <button type="button" class="btn btn-primary btn-sm std-tab-btn" data-cat="all" onclick="window.filterStdTests('all', this)">همه <?= fa($stdTestCount) ?> آزمون</button>
            <button type="button" class="btn btn-outline btn-sm std-tab-btn" data-cat="psych" onclick="window.filterStdTests('psych', this)">روان‌شناسی و شخصیت (<?= fa($stdCategoryCounts['psych'] ?? 0) ?>)</button>
            <button type="button" class="btn btn-outline btn-sm std-tab-btn" data-cat="career" onclick="window.filterStdTests('career', this)">شغلی، مدیریتی و هوش (<?= fa($stdCategoryCounts['career'] ?? 0) ?>)</button>
            <button type="button" class="btn btn-outline btn-sm std-tab-btn" data-cat="lang" onclick="window.filterStdTests('lang', this)">زبان (<?= fa($stdCategoryCounts['lang'] ?? 0) ?>)</button>
            <button type="button" class="btn btn-outline btn-sm std-tab-btn" data-cat="trade" onclick="window.filterStdTests('trade', this)">بازرگانی و دیجیتال (<?= fa($stdCategoryCounts['trade'] ?? 0) ?>)</button>
            <button type="button" class="btn btn-outline btn-sm std-tab-btn" data-cat="finance" onclick="window.filterStdTests('finance', this)">حسابداری، مالیات و حسابرسی (<?= fa($stdCategoryCounts['finance'] ?? 0) ?>)</button>
        </div>
    </div>

    <!-- LIVE INTERACTIVE RUNNER & INSTANT GRAPHICAL REPORT CARD STAGE -->
    <div id="stdInteractiveStage" style="display:none;margin-bottom:18px;padding:18px;border-radius:14px;background:linear-gradient(135deg,rgba(15,118,110,0.07),rgba(201,146,39,0.08));border:1.5px solid var(--primary)"></div>

    <div class="grid grid-4" style="gap:12px" id="stdCatalogGrid">
        <?php foreach (($stdCatalog ?? []) as $code => $st): ?>
            <div class="std-test-card" data-cat="<?= e($st['cat_key']) ?>" style="background:var(--surface-2);border:1px solid var(--border);border-radius:14px;padding:14px;display:flex;flex-direction:column;justify-content:space-between">
                <div>
                    <div style="display:flex;justify-content:space-between;align-items:center;gap:6px;margin-bottom:6px">
                        <span class="badge badge-info" style="font-size:10.5px"><?= e($st['cat_label']) ?></span>
                        <span class="muted" style="font-size:11px"><?= fa($st['minutes']) ?> دقیقه</span>
                    </div>
                    <h3 style="font-size:13.8px;line-height:1.55;margin:0 0 6px"><?= e($st['title']) ?></h3>
                    <div class="muted" style="font-size:11.5px;line-height:1.65;margin-bottom:10px"><?= e($st['summary']) ?></div>
                </div>

                <div style="display:flex;flex-direction:column;gap:6px">
                    <button type="button" class="btn btn-primary btn-sm" style="width:100%"
                            onclick="window.openStdRunner(<?= htmlspecialchars(json_encode($code), ENT_QUOTES, 'UTF-8') ?>, false)">
                        شروع تعاملی سؤالات آزمون
                    </button>

                    <div style="display:flex;gap:6px">
                        <form method="post" action="<?= e(url('exams')) ?>" style="flex:1"
                              onsubmit="if(!window.location.protocol.startsWith('http')){event.preventDefault();window.openStdRunner(<?= htmlspecialchars(json_encode($code), ENT_QUOTES, 'UTF-8') ?>, false);return false;}">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="run_standard_test">
                            <input type="hidden" name="test_code" value="<?= e($code) ?>">
                            <button type="submit" class="btn btn-gold btn-sm" style="width:100%;font-size:11px;padding:5px 6px"
                                    onclick="if(typeof PAGES!=='undefined'){event.preventDefault();window.openStdRunner(<?= htmlspecialchars(json_encode($code), ENT_QUOTES, 'UTF-8') ?>, false);}">
                                شروع آزمون و دریافت کارنامه
                            </button>
                        </form>

                        <?php if ($exam && (int)$exam['is_active'] === 0 && $st['cat_key'] !== 'psych' && Auth::hasRole(['super_admin', 'training_expert', 'instructor'])): ?>
                            <form method="post" action="<?= e(url('exams')) ?>" style="flex:1">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="clone_standard_to_bank">
                                <input type="hidden" name="test_code" value="<?= e($code) ?>">
                                <input type="hidden" name="exam_id" value="<?= (int)($exam['id'] ?? 0) ?>">
                                <button type="submit" class="btn btn-outline btn-sm" style="width:100%;font-size:11px;padding:5px 6px" title="کپی سؤالات این آزمون استاندارد به بانک سؤالات آزمون رسمی دوره">
                                    + بانک آزمون دوره
                                </button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- OFFICIAL SAVED PSYCHOMETRIC / LANGUAGE / CAREER REPORTS TABLE -->
<div class="card" style="margin-bottom:18px">
    <div class="card-header"><div class="card-title">آرشیو کارنامه‌های صادره آزمون‌های استاندارد (شخصیت‌شناسی، شغلی، زبان و مهارت)</div></div>
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>کد کارنامه</th>
                    <th>شرکت‌کننده</th>
                    <th>عنوان آزمون استاندارد</th>
                    <th>نتیجه نهایی / تیپ / سطح استاندارد</th>
                    <th>تکمیل پاسخ / نمره</th>
                    <th>دوره پیشنهادی متناظر در اتاق</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach (($stdResults ?? []) as $sr): ?>
                <tr>
                    <td><strong><?= e($sr['report_code']) ?></strong><div class="muted" style="font-size:11px"><?= e($sr['completed_shamsi']) ?></div></td>
                    <td><strong><?= e($sr['full_name'] ?? 'کاربر سامانه') ?></strong></td>
                    <td><?= e($sr['test_title']) ?></td>
                    <td><span class="badge badge-gold"><?= e($sr['result_badge']) ?></span></td>
                    <td><strong><?= in_array($sr['test_code'], $selfAssessmentCodes, true) ? 'تکمیل ' : 'نمره ' ?><?= fa($sr['score_pct']) ?>٪</strong></td>
                    <td><a href="<?= e(url('tms')) ?>" class="badge badge-info" style="text-decoration:none"><?= e($sr['recommended_course']) ?> ←</a></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<script type="application/json" id="stdCatalogJson"><?= json_encode($stdClientCatalog, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG) ?></script>

<div class="grid grid-2">
    <!-- TIMED EXAM RUNNER -->
    <div class="card">
        <?php if (!$exam): ?>
            <div class="alert alert-info">آزمونی برای نمایش وجود ندارد. فراگیر باید در اجرای دوره ثبت‌نام شده باشد و کارشناس آموزش آزمون دوره را منتشر کند.</div>
        <?php else: ?>
            <div class="card-header">
                <div class="card-title">📝 اجرای زنده: <?= e($exam['title']) ?></div>
                <span class="badge badge-info">حدنصاب قبولی: <?= fa($exam['pass_score']) ?> | سقف تلاش: <?= fa($exam['max_attempts']) ?> بار</span>
            </div>
            <?php if ((int)$exam['is_active'] !== 1): ?>
                <div class="alert alert-info">این آزمون پیش‌نویس است و هنوز برای فراگیران منتشر نشده است.</div>
            <?php elseif ($questions === []): ?>
                <div class="alert alert-info">برای این آزمون هنوز سؤالی ثبت نشده است.</div>
            <?php else: ?>
                <form method="post" action="<?= e(url('exams')) ?>" id="activeExamForm">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="submit_exam">
                    <input type="hidden" name="exam_id" value="<?= (int)$exam['id'] ?>">
                    <?php foreach ($questions as $idx => $q): ?>
                        <div style="border-bottom:1px solid var(--border);padding-bottom:12px;margin-bottom:12px">
                            <div style="font-weight:700;margin-bottom:6px">
                                سؤال <?= fa($idx + 1) ?> (<?= fa($q['points']) ?> نمره): <?= e($q['question_text']) ?>
                            </div>
                            <?php if ($q['question_type'] === 'mcq'): ?>
                                <?php foreach (['A' => $q['option_a'], 'B' => $q['option_b'], 'C' => $q['option_c'], 'D' => $q['option_d']] as $optKey => $optText): ?>
                                    <label style="display:block;font-size:13px;cursor:pointer;margin-bottom:4px">
                                        <input type="radio" name="q_<?= (int)$q['id'] ?>" value="<?= $optKey ?>">
                                        <?= e($optText) ?>
                                    </label>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <textarea name="q_<?= (int)$q['id'] ?>" rows="3" placeholder="پاسخ تشریحی خود را بنویسید..."></textarea>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                    <button type="submit" class="btn btn-primary">ثبت نهایی پاسخ‌نامه و تصحیح آنی تستی</button>
                </form>
            <?php endif; ?>
        <?php endif; ?>
    </div>

    <!-- DESCRIPTIVE REVIEW + ISSUE CERTIFICATE -->
    <div>
        <div class="card">
            <div class="card-header"><div class="card-title">📊 کارنامه‌ها و بازبینی تشریحی مدرس</div></div>
            <?php foreach ($attempts as $at): ?>
                <div style="border-bottom:1px solid var(--border);padding:9px 0">
                    <div style="display:flex;justify-content:space-between">
                        <strong><?= e($at['full_name']) ?> (تلاش <?= fa($at['attempt_no']) ?>)</strong>
                        <span class="badge badge-success">
                            نتیجه: <?= fa(number_format((float)($at['score_pct'] ?? 0), 2)) ?>٪
                        </span>
                    </div>
                    <?php if (!empty($at['descriptive_answer'])): ?>
                        <div style="font-size:12px;line-height:1.8;margin-top:6px;white-space:pre-wrap"><?= e($at['descriptive_answer']) ?></div>
                    <?php endif; ?>
                    <?php if ($at['status'] !== 'finalized' && Auth::hasRole(['super_admin', 'training_expert', 'instructor'])): ?>
                        <form method="post" action="<?= e(url('exams')) ?>" style="display:flex;gap:6px;margin-top:6px">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="grade_descriptive">
                            <input type="hidden" name="attempt_id" value="<?= (int)$at['id'] ?>">
                            <input type="number" name="descriptive_score" value="<?= min(26, $descriptiveMax) ?>" min="0" max="<?= e($descriptiveMax) ?>" step="0.01" style="width:90px">
                            <button type="submit" class="btn btn-outline btn-sm">ثبت نمره تشریحی</button>
                        </form>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>

        <?php if ($canEditBank): ?>
            <div class="card">
                <div class="card-header"><div class="card-title">بانک سؤال آزمون — افزودن و ویرایش پیش‌نویس</div></div>
                <div class="muted" style="font-size:12px;margin-bottom:12px">تا پیش از انتشار و ثبت اولین پاسخ‌نامه، امکان ویرایش یا حذف سؤال‌ها وجود دارد.</div>
                <?php foreach ($editableQuestions as $editableQuestion): ?>
                    <div style="border:1px solid var(--border);border-radius:12px;padding:12px;margin-bottom:12px">
                        <form method="post" action="<?= e(url('exams')) ?>">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="update_question">
                            <input type="hidden" name="exam_id" value="<?= (int)$exam['id'] ?>">
                            <input type="hidden" name="question_id" value="<?= (int)$editableQuestion['id'] ?>">
                            <div class="form-grid">
                                <div class="form-group">
                                    <label>نوع سؤال</label>
                                    <select name="question_type">
                                        <option value="mcq" <?= $editableQuestion['question_type'] === 'mcq' ? 'selected' : '' ?>>چهارگزینه‌ای</option>
                                        <option value="descriptive" <?= $editableQuestion['question_type'] === 'descriptive' ? 'selected' : '' ?>>تشریحی</option>
                                    </select>
                                </div>
                                <div class="form-group"><label>بارم</label><input type="number" name="points" value="<?= e($editableQuestion['points']) ?>" min="0.01" max="100" step="0.01" required></div>
                            </div>
                            <div class="form-group">
                                <label>صورت سؤال <?= fa($editableQuestion['id']) ?></label>
                                <textarea name="question_text" rows="2" maxlength="4000" required><?= e($editableQuestion['question_text']) ?></textarea>
                            </div>
                            <div class="form-grid">
                                <input type="text" name="opt_a" maxlength="255" value="<?= e($editableQuestion['option_a']) ?>" placeholder="گزینه A">
                                <input type="text" name="opt_b" maxlength="255" value="<?= e($editableQuestion['option_b']) ?>" placeholder="گزینه B">
                                <input type="text" name="opt_c" maxlength="255" value="<?= e($editableQuestion['option_c']) ?>" placeholder="گزینه C">
                                <input type="text" name="opt_d" maxlength="255" value="<?= e($editableQuestion['option_d']) ?>" placeholder="گزینه D">
                            </div>
                            <div style="display:flex;gap:8px;align-items:center;margin-top:8px;flex-wrap:wrap">
                                <label for="correct_<?= (int)$editableQuestion['id'] ?>">گزینه صحیح</label>
                                <select id="correct_<?= (int)$editableQuestion['id'] ?>" name="correct_option">
                                    <?php foreach (['A', 'B', 'C', 'D'] as $option): ?>
                                        <option value="<?= $option ?>" <?= $editableQuestion['correct_option'] === $option ? 'selected' : '' ?>><?= $option ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <button type="submit" class="btn btn-primary btn-sm">ذخیره ویرایش</button>
                            </div>
                        </form>
                        <form method="post" action="<?= e(url('exams')) ?>" style="margin-top:8px" onsubmit="return confirm('این سؤال حذف شود؟')">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="delete_question">
                            <input type="hidden" name="exam_id" value="<?= (int)$exam['id'] ?>">
                            <input type="hidden" name="question_id" value="<?= (int)$editableQuestion['id'] ?>">
                            <button type="submit" class="btn btn-danger btn-sm">حذف سؤال</button>
                        </form>
                    </div>
                <?php endforeach; ?>
                <div style="border-top:1px solid var(--border);padding-top:12px;margin-top:14px">
                <div class="card-title" style="font-size:14px;margin-bottom:10px">➕ افزودن سؤال جدید</div>
                <form method="post" action="<?= e(url('exams')) ?>">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="add_question">
                    <input type="hidden" name="exam_id" value="<?= (int)($exam['id'] ?? 0) ?>">
                    <div class="form-grid">
                        <select name="question_type">
                            <option value="mcq">چهارگزینه‌ای (تصحیح خودکار)</option>
                            <option value="descriptive">تشریحی (بازبینی استاد)</option>
                        </select>
                        <input type="number" name="points" value="20" min="5" max="100" placeholder="بارم نمره">
                    </div>
                    <div class="form-group" style="margin-top:8px">
                        <input type="text" name="question_text" required placeholder="صورت سؤال تخصصی (مثلاً: در ترم DDP وظیفه ترخیص وارداتی با کیست؟)">
                    </div>
                    <div class="form-grid">
                        <input type="text" name="opt_a" placeholder="گزینه A">
                        <input type="text" name="opt_b" placeholder="گزینه B">
                        <input type="text" name="opt_c" placeholder="گزینه C">
                        <input type="text" name="opt_d" placeholder="گزینه D">
                    </div>
                    <div class="form-group" style="margin-top:8px">
                        <label>گزینه صحیح (برای تستی):</label>
                        <select name="correct_option"><option value="A">A</option><option value="B">B</option><option value="C">C</option><option value="D">D</option></select>
                    </div>
                    <button type="submit" class="btn btn-gold btn-sm" style="width:100%">ثبت در بانک سؤالات</button>
                </form>
                </div>
            </div>
        <?php endif; ?>

        <?php if (Auth::hasRole(['super_admin', 'training_expert'])): ?>
            <div class="alert alert-info">
                تحلیل دشواری و قدرت تمیز سؤال پس از جمع‌آوری پاسخ‌های واقعی محاسبه می‌شود؛ در حال حاضر داده کالیبراسیون یا تأیید استانداردی ثبت نشده است.
            </div>

            <div class="card">
                <div class="card-header"><div class="card-title">🎖️ ثبت گواهی پایان دوره در سوابق آدان</div></div>
                <form method="post" action="<?= e(url('exams')) ?>">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="issue_certificate">
                    <div class="form-grid">
                        <div class="form-group">
                            <label>فراگیر:</label>
                            <select name="user_id">
                                <?php foreach ($users as $u): ?>
                                    <option value="<?= (int)$u['id'] ?>"><?= e($u['full_name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>دوره:</label>
                            <select name="course_id">
                                <?php foreach ($courses as $c): ?>
                                    <option value="<?= (int)$c['id'] ?>"><?= e($c['title']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>درجه ارزشیابی:</label>
                        <input type="text" name="grade_label" value="ممتاز (۹۶ از ۱۰۰)">
                    </div>
                    <button type="submit" class="btn btn-primary btn-sm">ثبت گواهی و ایجاد کد استعلام داخلی</button>
                </form>

                <form method="post" action="<?= e(url('exams')) ?>" style="margin-top:12px;padding-top:10px;border-top:1px dashed var(--border);display:flex;gap:8px;align-items:center">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="batch_issue_course">
                    <select name="course_id" style="flex:1">
                        <?php foreach ($courses as $c): ?>
                            <option value="<?= (int)$c['id'] ?>"><?= e($c['title']) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit" class="btn btn-gold btn-sm">📑 صدور گروهی کل کلاس</button>
                </form>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- CERTIFICATES REGISTRY + REVOCATION -->
<div class="card">
    <div class="card-header"><div class="card-title">📜 <?= \App\Core\Auth::role() === 'learner' ? 'گواهی‌نامه‌های من و لینک استعلام عمومی QR' : 'دفتر کل گواهی‌نامه‌های صادرشده، لینک استعلام عمومی QR و ابطال' ?></div></div>
    <div class="table-wrap">
        <table>
            <thead>
            <tr>
                <th>سریال یکتا / QR</th>
                <th>نام دارنده / دوره</th>
                <th>تاریخ صدور</th>
                <th>وضعیت اصالت</th>
                <th>عملیات استعلام<?= \App\Core\Auth::role() === 'learner' ? '' : ' / ابطال' ?></th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($certs as $ct): ?>
                <tr>
                    <td style="display:flex;align-items:center;gap:8px">
                        <?= QrSvg::render($ct['serial_code'], 52) ?>
                        <code><?= e($ct['serial_code']) ?></code>
                    </td>
                    <td><strong><?= e($ct['full_name']) ?></strong><div class="muted" style="font-size:12px"><?= e($ct['course_title']) ?></div></td>
                    <td><?= e($ct['issue_shamsi']) ?></td>
                    <td>
                        <span class="badge <?= $ct['status'] === 'valid' ? 'badge-success' : 'badge-danger' ?>">
                            <?= $ct['status'] === 'valid' ? 'معتبر در سوابق آدان' : 'لغوشده در سوابق آدان' ?>
                        </span>
                    </td>
                    <td>
                        <a class="btn btn-outline btn-sm" href="<?= e(url('verify', ['code' => $ct['serial_code']])) ?>">صفحه استعلام عمومی</a>
                        <?php if ($ct['status'] === 'valid' && Auth::hasRole(['super_admin', 'training_expert'])): ?>
                            <form method="post" action="<?= e(url('exams')) ?>" style="display:inline-flex;gap:4px;margin-right:4px">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="revoke_certificate">
                                <input type="hidden" name="cert_id" value="<?= (int)$ct['id'] ?>">
                                <input type="hidden" name="revoked_reason" value="ابطال بنا به مصوبه شورای آموزش">
                                <button type="submit" class="btn btn-danger btn-sm">ابطال</button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
