<?php
use App\Services\EnterpriseSettingsIamService;
$selectedUser = $selectedUser ?? null;
$editingRole = $editingRole ?? null;
?>
<div class="hero-banner">
    <div>
        <span class="badge badge-gold" style="margin-bottom:8px">مدیریت هویت، نقش‌های پویا، ماتریس سطوح دسترسی (RBAC) و استثنائات تک‌کاربره</span>
        <h1>مرکز جامع مدیریت کاربران، نقش‌های سازمانی و ماتریس سطوح دسترسی (IAM &amp; RBAC)</h1>
        <p>تعریف نقش‌های سازمانی سفارشی با محدوده دید داده (استانی / شعبه‌ای / شرکتی / فردی)، ویرایش ماتریس ۶گانه عملیات (مشاهده، ایجاد، ویرایش، حذف، تأیید، خروجی) و مدیریت حساب کاربران با ثبت کامل لاگ ممیزی.</p>
    </div>
    <div class="hero-actions">
        <a class="btn btn-gold" href="<?= e(url('system-settings')) ?>">🎨 تنظیمات تم، فونت و نرم‌افزار</a>
    </div>
</div>

<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:18px">
    <button type="button" class="btn <?= $activeTab === 'matrix' ? 'btn-gold' : 'btn-outline' ?> btn-sm iam-tab-btn" onclick="switchIamTab('matrix', this)">🛡️ ۱. ماتریس دیداری سطوح دسترسی (CRUD + تأیید + خروجی)</button>
    <button type="button" class="btn <?= $activeTab === 'roles' ? 'btn-gold' : 'btn-outline' ?> btn-sm iam-tab-btn" onclick="switchIamTab('roles', this)">🏛️ ۲. نقش‌های پایه و سازنده نقش سفارشی (Data Scope)</button>
    <button type="button" class="btn <?= $activeTab === 'users' ? 'btn-gold' : 'btn-outline' ?> btn-sm iam-tab-btn" onclick="switchIamTab('users', this)">👤 ۳. مدیریت کاربران و مجوزهای موردی (User Overrides)</button>
    <button type="button" class="btn <?= $activeTab === 'audit' ? 'btn-gold' : 'btn-outline' ?> btn-sm iam-tab-btn" onclick="switchIamTab('audit', this)">📜 ۴. لاگ تغییرناپذیر ممیزی امنیتی</button>
</div>

<!-- تب ۱: ماتریس سطح دسترسی -->
<div id="iamPanel_matrix" class="iam-panel" style="display:<?= $activeTab === 'matrix' ? 'block' : 'none' ?>">
    <div class="card">
        <div class="card-header" style="flex-wrap:wrap;gap:10px">
            <div class="card-title">🛡️ ماتریس دقیق مجوزهای نقش انتخابی: <code><?= e($selectedRole) ?></code></div>
            <form method="get" action="<?= e(url('iam-access')) ?>" style="display:flex;gap:8px;align-items:center">
                <input type="hidden" name="tab" value="matrix">
                <label style="margin:0;white-space:nowrap">انتخاب نقش جهت ویرایش:</label>
                <select name="role" onchange="this.form.submit()" style="width:auto;min-width:260px">
                    <?php foreach ($bundle['roles'] as $rItem): ?>
                        <option value="<?= e($rItem['role_slug']) ?>" <?= $rItem['role_slug'] === $selectedRole ? 'selected' : '' ?>>
                            <?= e($rItem['role_title_fa']) ?> (<?= e($rItem['role_slug']) ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </form>
        </div>

        <form method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="save_role_matrix">
            <input type="hidden" name="role_slug" value="<?= e($selectedRole) ?>">
            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>حوزه عملیاتی در ERP</th>
                            <th style="text-align:center">👁️ مشاهده (View)</th>
                            <th style="text-align:center">➕ ایجاد (Create)</th>
                            <th style="text-align:center">✏️ ویرایش (Edit)</th>
                            <th style="text-align:center">🗑️ حذف (Delete)</th>
                            <th style="text-align:center">✅ تأیید/امضا (Approve)</th>
                            <th style="text-align:center">📤 چاپ و اکسل (Export)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach (EnterpriseSettingsIamService::PERMISSION_DOMAINS as $domKey => $domLabel): ?>
                            <?php $row = $bundle['perm_map'][$domKey] ?? ['can_view' => 1, 'can_create' => 0, 'can_edit' => 0, 'can_delete' => 0, 'can_approve' => 0, 'can_export' => 0]; ?>
                            <tr>
                                <td><strong><?= e($domLabel) ?></strong><div class="muted" style="font-size:11.5px"><code><?= e($domKey) ?></code></div></td>
                                <td style="text-align:center"><input type="checkbox" name="perm[<?= e($domKey) ?>][view]" value="1" <?= !empty($row['can_view']) ? 'checked' : '' ?> style="width:18px;height:18px"></td>
                                <td style="text-align:center"><input type="checkbox" name="perm[<?= e($domKey) ?>][create]" value="1" <?= !empty($row['can_create']) ? 'checked' : '' ?> style="width:18px;height:18px"></td>
                                <td style="text-align:center"><input type="checkbox" name="perm[<?= e($domKey) ?>][edit]" value="1" <?= !empty($row['can_edit']) ? 'checked' : '' ?> style="width:18px;height:18px"></td>
                                <td style="text-align:center"><input type="checkbox" name="perm[<?= e($domKey) ?>][delete]" value="1" <?= !empty($row['can_delete']) ? 'checked' : '' ?> style="width:18px;height:18px"></td>
                                <td style="text-align:center"><input type="checkbox" name="perm[<?= e($domKey) ?>][approve]" value="1" <?= !empty($row['can_approve']) ? 'checked' : '' ?> style="width:18px;height:18px"></td>
                                <td style="text-align:center"><input type="checkbox" name="perm[<?= e($domKey) ?>][export]" value="1" <?= !empty($row['can_export']) ? 'checked' : '' ?> style="width:18px;height:18px"></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div style="margin-top:14px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px">
                <span class="muted" style="font-size:12px">🔒 سپر ایمنی هسته: مجوز ارسال کمپین انبوه بازاریابی برای نقش نماینده شرکت (<code>org_rep</code>) به صورت سیستمی مسدود می‌ماند.</span>
                <button type="submit" class="btn btn-primary">💾 ذخیره ماتریس دسترسی این نقش در پایگاه‌داده</button>
            </div>
        </form>
    </div>
</div>

<!-- تب ۲: نقش‌های سازمانی و ساخت نقش سفارشی -->
<div id="iamPanel_roles" class="iam-panel" style="display:<?= $activeTab === 'roles' ? 'block' : 'none' ?>">
    <div class="grid grid-2">
        <div class="card">
            <div class="card-header">
                <div class="card-title"><?= $editingRole ? '✏️ ویرایش مشخصات نقش' : '➕ تعریف نقش سازمانی سفارشی جدید' ?> + محدوده داده (Row-Level Scope)</div>
                <?php if ($editingRole): ?>
                    <a class="btn btn-outline btn-sm" href="<?= e(url('iam-access', ['tab' => 'roles'])) ?>">انصراف از ویرایش</a>
                <?php endif; ?>
            </div>
            <form method="post">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="<?= $editingRole ? 'update_managed_role' : 'create_custom_role' ?>">
                <div class="grid grid-2">
                    <div class="form-group">
                        <label>شناسه فنی نقش (Slug): <?= $editingRole ? '— پس از ایجاد ثابت است' : '' ?></label>
                        <input type="text" name="role_slug" value="<?= e($editingRole['role_slug'] ?? '') ?>" placeholder="مثلاً: internal_auditor" pattern="[a-zA-Z][a-zA-Z0-9_]{2,59}" maxlength="60" required dir="ltr" <?= $editingRole ? 'readonly' : '' ?>>
                    </div>
                    <div class="form-group">
                        <label>محدوده مجاز مشاهده رکوردها:</label>
                        <select name="data_scope">
                            <option value="global_province" <?= ($editingRole['data_scope'] ?? '') === 'global_province' ? 'selected' : '' ?>>کل استان و تمام دفاتر (Global)</option>
                            <option value="branch_only" <?= ($editingRole['data_scope'] ?? 'branch_only') === 'branch_only' ? 'selected' : '' ?>>فقط شعبه شهرستان مربوطه (Branch Scope)</option>
                            <option value="organization_only" <?= ($editingRole['data_scope'] ?? '') === 'organization_only' ? 'selected' : '' ?>>فقط کارکنان شرکت/کارخانه خود (Org Scope)</option>
                            <option value="own_records" <?= ($editingRole['data_scope'] ?? '') === 'own_records' ? 'selected' : '' ?>>فقط پرونده آموزشی و مالی شخصی (Self Scope)</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label>عنوان رسمی نقش به فارسی:</label>
                    <input type="text" name="role_title_fa" value="<?= e($editingRole['role_title_fa'] ?? '') ?>" maxlength="160" placeholder="مثلاً: حسابرس داخلی و ناظر قراردادهای آموزشی" required>
                </div>
                <div class="form-group">
                    <label>شرح وظایف و مرز دسترسی:</label>
                    <input type="text" name="description_note" value="<?= e($editingRole['description_note'] ?? '') ?>" maxlength="240" placeholder="مشاهده اسناد مالی و قراردادها بدون مجوز ویرایش یا حذف">
                </div>
                <button type="submit" class="btn btn-gold"><?= $editingRole ? 'ذخیره مشخصات نقش' : 'ایجاد نقش سازمانی جدید' ?></button>
            </form>
        </div>

        <div class="card">
            <div class="card-header"><div class="card-title">🏛️ فهرست کامل نقش‌های تعریف‌شده در سامانه (<?= fa(count($bundle['roles'])) ?> نقش)</div></div>
            <div class="table-wrap">
                <table>
                    <thead><tr><th>کد نقش</th><th>عنوان فارسی</th><th>محدوده داده</th><th>نوع</th><th>عملیات</th></tr></thead>
                    <tbody>
                        <?php foreach ($bundle['roles'] as $r): ?>
                            <tr>
                                <td><code><?= e($r['role_slug']) ?></code></td>
                                <td><strong><?= e($r['role_title_fa']) ?></strong><div class="muted" style="font-size:11.5px"><?= e($r['description_note']) ?></div></td>
                                <td><span class="badge badge-info"><?= e($r['data_scope']) ?></span></td>
                                <td><span class="badge badge-<?= (int)$r['is_system_builtin'] === 1 ? 'success' : 'gold' ?>"><?= (int)$r['is_system_builtin'] === 1 ? 'هسته سیستم' : 'سفارشی' ?></span></td>
                                <td style="display:flex;gap:6px;flex-wrap:wrap">
                                    <a class="btn btn-outline btn-sm" href="<?= e(url('iam-access', ['tab' => 'roles', 'edit_role' => $r['role_slug']])) ?>">ویرایش</a>
                                    <?php if ((int)$r['is_system_builtin'] !== 1): ?>
                                        <form method="post" onsubmit="return confirm('نقش سفارشی حذف شود؟ اگر کاربری به آن منتسب باشد، حذف انجام نمی‌شود.');">
                                            <?= csrf_field() ?>
                                            <input type="hidden" name="action" value="delete_custom_role">
                                            <input type="hidden" name="role_slug" value="<?= e($r['role_slug']) ?>">
                                            <button type="submit" class="btn btn-outline btn-sm">حذف</button>
                                        </form>
                                    <?php else: ?>
                                        <span class="muted" style="font-size:11px">نقش اصلی؛ حذف‌ناپذیر</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- تب ۳: مدیریت کاربران و استثنائات موردی -->
<div id="iamPanel_users" class="iam-panel" style="display:<?= $activeTab === 'users' ? 'block' : 'none' ?>">
    <div class="grid grid-2">
        <div class="card">
            <div class="card-header">
                <div class="card-title">👤 <?= $selectedUser ? 'ویرایش حساب کاربری و بازنشانی گذرواژه' : 'ایجاد حساب کاربری جدید' ?></div>
                <?php if ($selectedUser): ?>
                    <a class="btn btn-outline btn-sm" href="<?= e(url('iam-access', ['tab' => 'users'])) ?>">انصراف از ویرایش</a>
                <?php endif; ?>
            </div>
            <form method="post">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="upsert_user">
                <?php if ($selectedUser): ?>
                    <input type="hidden" name="user_id" value="<?= (int)$selectedUser['id'] ?>">
                <?php endif; ?>
                <div class="grid grid-2">
                    <div class="form-group"><label>نام کاربری:</label><input type="text" name="username" value="<?= e($selectedUser['username'] ?? '') ?>" placeholder="karshenas_yazd" minlength="3" maxlength="100" pattern="[a-zA-Z0-9_]+" required dir="ltr"></div>
                    <div class="form-group"><label>ایمیل سازمانی:</label><input type="email" name="email" value="<?= e($selectedUser['email'] ?? '') ?>" placeholder="staff@chamber-edu.ir" maxlength="190" required dir="ltr"></div>
                </div>
                <div class="grid grid-2">
                    <div class="form-group"><label>نام و نام خانوادگی کامل:</label><input type="text" name="full_name" value="<?= e($selectedUser['full_name'] ?? '') ?>" placeholder="مهندس آرش بهرامی" maxlength="180" required></div>
                    <div class="form-group">
                        <label>انتساب نقش سازمانی:</label>
                        <select name="role">
                            <?php foreach ($bundle['roles'] as $r): ?>
                                <option value="<?= e($r['role_slug']) ?>" <?= ($selectedUser['role'] ?? '') === $r['role_slug'] ? 'selected' : '' ?>><?= e($r['role_title_fa']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="grid grid-2">
                    <div class="form-group"><label>شماره همراه:</label><input type="text" name="mobile" value="<?= e($selectedUser['mobile'] ?? '') ?>" maxlength="25" dir="ltr"></div>
                    <div class="form-group">
                        <label>سازمان:</label>
                        <select name="org_id">
                            <option value="0">بدون سازمان</option>
                            <?php foreach ($bundle['organizations'] as $org): ?>
                                <option value="<?= (int)$org['id'] ?>" <?= (int)($selectedUser['org_id'] ?? 0) === (int)$org['id'] ? 'selected' : '' ?>><?= e($org['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <?php if ($selectedUser): ?>
                    <div class="form-group">
                        <label>وضعیت حساب:</label>
                        <select name="status">
                            <option value="active" <?= $selectedUser['status'] === 'active' ? 'selected' : '' ?>>فعال</option>
                            <option value="locked" <?= $selectedUser['status'] === 'locked' ? 'selected' : '' ?>>قفل‌شده</option>
                            <option value="inactive" <?= $selectedUser['status'] === 'inactive' ? 'selected' : '' ?>>غیرفعال</option>
                        </select>
                    </div>
                <?php endif; ?>
                <div class="form-group">
                    <label><?= $selectedUser ? 'گذرواژهٔ جدید (اختیاری؛ حداقل ۱۲ نویسه برای بازنشانی):' : 'گذرواژه اولیه (حداقل ۱۲ نویسه):' ?></label>
                    <input type="password" name="password" minlength="12" autocomplete="new-password" <?= $selectedUser ? '' : 'required' ?> dir="ltr">
                </div>
                <button type="submit" class="btn btn-primary"><?= $selectedUser ? 'ذخیره تغییرات کاربر' : 'ایجاد حساب کاربری' ?></button>
            </form>
        </div>

        <div class="card">
            <div class="card-header"><div class="card-title">🔑 اعطا یا سلب مجوز موردی تک‌کاربره (Per-User Route Override)</div></div>
            <form method="post">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="add_override">
                <div class="grid grid-2">
                    <div class="form-group">
                        <label>انتخاب کاربر:</label>
                        <select name="user_id">
                            <?php foreach ($bundle['users'] as $uRow): ?>
                                <option value="<?= (int)$uRow['id'] ?>"><?= e($uRow['full_name']) ?> (<?= e($uRow['role']) ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>نام مسیر (Route):</label>
                        <input type="text" name="route_or_perm" value="academic-erp-core" required dir="ltr">
                    </div>
                </div>
                <div class="grid grid-2">
                    <div class="form-group">
                        <label>نوع حکم دسترسی:</label>
                        <select name="effect_type">
                            <option value="allow">✅ مجوز دسترسی موردی (Allow)</option>
                            <option value="deny">⛔ مسدودیت صریح دسترسی (Deny)</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>علت مدیریتی / شماره نامه:</label>
                        <input type="text" name="reason_note" placeholder="ابلاغ کتبی مدیر آموزش جهت ثبت نمرات ترم" required>
                    </div>
                </div>
                <button type="submit" class="btn btn-gold">ثبت حکم دسترسی موردی</button>
            </form>
        </div>
    </div>

    <div class="card" style="margin-top:16px">
        <div class="card-header">
            <div class="card-title">📋 فهرست کاربران و استثنائات دسترسی ثبت‌شده (<?= fa(count($bundle['users'])) ?> کاربر)</div>
            <?php if ($selectedUser): ?>
                <a class="btn btn-outline btn-sm" href="<?= e(url('iam-access', ['tab' => 'users'])) ?>">ایجاد کاربر جدید</a>
            <?php endif; ?>
        </div>
        <div class="table-wrap">
            <table>
                <thead><tr><th>نام کامل</th><th>نام کاربری</th><th>ایمیل</th><th>نقش فعلی</th><th>سازمان متبوع</th><th>وضعیت</th><th>عملیات</th></tr></thead>
                <tbody>
                    <?php foreach ($bundle['users'] as $uRow): ?>
                        <tr>
                            <td><strong><?= e($uRow['full_name']) ?></strong></td>
                            <td><code><?= e($uRow['username']) ?></code></td>
                            <td dir="ltr"><?= e($uRow['email']) ?></td>
                            <td><span class="badge badge-info"><?= e($uRow['role']) ?></span></td>
                            <td><?= e($uRow['org_name'] ?? 'ستاد مرکزی مؤسسه آموزشی آدان') ?></td>
                            <td><span class="badge <?= $uRow['status'] === 'active' ? 'badge-success' : 'badge-warning' ?>"><?= e($uRow['status']) ?></span></td>
                            <td><a class="btn btn-outline btn-sm" href="<?= e(url('iam-access', ['tab' => 'users', 'edit_user' => (int)$uRow['id']])) ?>">ویرایش / تغییر رمز</a></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- تب ۴: لاگ ممیزی امنیتی -->
<div id="iamPanel_audit" class="iam-panel" style="display:<?= $activeTab === 'audit' ? 'block' : 'none' ?>">
    <div class="card">
        <div class="card-header"><div class="card-title">📜 آخرین رخدادهای ثبت‌شده در دفتر کل ممیزی امنیتی (Immutable Audit Trail)</div></div>
        <div class="table-wrap">
            <table>
                <thead><tr><th>ماژول</th><th>عملیات امنیتی</th><th>موجودیت</th><th>آدرس IP</th><th>زمان ثبت</th></tr></thead>
                <tbody>
                    <?php foreach ($bundle['audit_logs'] as $al): ?>
                        <tr>
                            <td><span class="badge badge-gold"><?= e($al['module'] ?? 'IAM') ?></span></td>
                            <td><code><?= e($al['action'] ?? '') ?></code></td>
                            <td><?= e($al['entity_type'] ?? '-') ?></td>
                            <td dir="ltr"><?= e($al['ip_address'] ?? '127.0.0.1') ?></td>
                            <td dir="ltr"><?= e($al['created_at'] ?? '') ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
function switchIamTab(tab, btn) {
    document.querySelectorAll('.iam-panel').forEach(p => p.style.display = 'none');
    document.getElementById('iamPanel_' + tab).style.display = 'block';
    document.querySelectorAll('.iam-tab-btn').forEach(b => { b.classList.remove('btn-gold'); b.classList.add('btn-outline'); });
    btn.classList.remove('btn-outline'); btn.classList.add('btn-gold');
}
</script>
