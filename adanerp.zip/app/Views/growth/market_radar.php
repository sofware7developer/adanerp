<?php
use App\Core\Auth;

$surveyInsights = $surveyInsights ?? [];
$competitorSummary = $competitorSummary ?? [];
$campaignSummary = $campaignSummary ?? [];
$manualMarketingTotals = $manualMarketingTotals ?? [];
$totalSomRevenue = array_sum(array_map(
    static fn($s) => (int)($s['som_target_rial'] ?? ((int)($s['som_learners'] ?? 50) * (int)($s['avg_willingness_to_pay_rial'] ?? 45000000))),
    $surveyInsights
));
?>
<div class="hero-banner">
    <div>
        <span class="badge badge-gold">ماژول بازاریابی، مدیریت کمپین و رادار بازار</span>
        <h1>میزکار بازاریابی و رادار بازار</h1>
        <p>
            تحقیق بازار، پایش سیگنال‌های وب عمومی، تحلیل رقبا، ثبت نیازسنجی، طراحی کمپین و <strong>تبدیل فرصت‌ها به دوره TMS و پیش‌نویس محتوا</strong>. آمار شبکه‌های اجتماعی از اتصال زنده دریافت نمی‌شود و تنها با ثبت دستی قابل گزارش است.
        </p>
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
        <?php if (\App\Core\App::canViewRoute('marketing-intel')): ?>
            <a href="<?= e(url('marketing-intel')) ?>" class="btn btn-outline" style="background:rgba(255,255,255,0.14);color:#fff;border-color:rgba(255,255,255,0.28)">📣 ورود به استودیوی کمپین و محتوا</a>
        <?php endif; ?>
        <form method="post" action="<?= e(url('market-radar')) ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="scan_live_web">
            <input type="text" name="keyword_query" value="هوش مصنوعی صادرات قرارداد بین‌المللی" required maxlength="160" aria-label="عبارت جست‌وجوی بازار">
            <button type="submit" class="btn btn-gold">🌐 پایش وب عمومی</button>
        </form>
    </div>
</div>

<!-- 4 EXECUTIVE MARKET RESEARCH KPI TILES -->
<div class="grid grid-4" style="margin-bottom:18px">
    <div class="stat-card">
        <div>
            <div class="stat-label">سیگنال‌های تقاضای ثبت‌شده</div>
            <div class="stat-value"><?= fa(count($signals)) ?> روند داغ</div>
            <div class="stat-meta">رکوردهای وب عمومی؛ تازگی و منبع را بررسی کنید</div>
        </div>
        <div class="stat-icon icon-teal">📡</div>
    </div>
    <div class="stat-card">
        <div>
            <div class="stat-label">فرصت‌های بکر اقیانوس آبی</div>
            <div class="stat-value"><?= fa($blueOceanCount) ?> شکاف طلایی</div>
            <div class="stat-meta">تطبیق خودکار با کاتالوگ فعلی TMS</div>
        </div>
        <div class="stat-icon icon-gold">🌊</div>
    </div>
    <div class="stat-card">
        <div>
            <div class="stat-label">دوره‌های رقیب ثبت‌شده</div>
            <div class="stat-value"><?= fa(count($competitorCourses)) ?> دوره رقیب</div>
            <div class="stat-meta">حداکثر ۳۰ رکورد اخیر؛ جزئیات منبع قابل بررسی است</div>
        </div>
        <div class="stat-icon icon-purple">🔭</div>
    </div>
    <div class="stat-card">
        <div>
            <div class="stat-label">مجموع برآوردهای SOM ثبت‌شده</div>
            <div class="stat-value"><?= empty($surveyInsights) ? '—' : fa(number_format((int)round($totalSomRevenue / 1000000))) ?> <small style="font-size:12px">میلیون ریال</small></div>
            <div class="stat-meta">جمع خام پژوهش‌ها؛ حوزه‌ها ممکن است هم‌پوشانی داشته باشند</div>
        </div>
        <div class="stat-icon icon-blue">📈</div>
    </div>
</div>

<div class="grid grid-3" style="margin-bottom:18px">
    <div class="stat-card">
        <div>
            <div class="stat-label">کمپین‌های ثبت‌شده</div>
            <div class="stat-value"><?= fa($campaignSummary['campaigns_count'] ?? 0) ?></div>
            <div class="stat-meta">در انتظار تأیید: <?= fa($campaignSummary['awaiting_approval_count'] ?? 0) ?> · زمان‌بندی محلی: <?= fa($campaignSummary['scheduled_count'] ?? 0) ?></div>
        </div>
        <div class="stat-icon icon-purple">📣</div>
    </div>
    <div class="stat-card">
        <div>
            <div class="stat-label">سرنخ‌های منتسب‌شده دستی</div>
            <div class="stat-value"><?= fa($manualMarketingTotals['leads'] ?? 0) ?></div>
            <div class="stat-meta">بر اساس داده‌ای که کاربر در استودیوی بازاریابی ثبت کرده است</div>
        </div>
        <div class="stat-icon icon-teal">🎯</div>
    </div>
    <div class="stat-card">
        <div>
            <div class="stat-label">ثبت‌نام منتسب‌شده دستی</div>
            <div class="stat-value"><?= fa($manualMarketingTotals['enrollments'] ?? 0) ?></div>
            <div class="stat-meta">رهگیری و انتشار خودکار شبکه‌ها متصل نیست</div>
        </div>
        <div class="stat-icon icon-gold">🧾</div>
    </div>
</div>

<div class="grid grid-2" style="gap:18px;margin-bottom:18px;align-items:start">
    <div class="card">
        <div class="card-header">
            <div class="card-title">📊 یافته‌های نیازسنجی و تحقیقات ثبت‌شده</div>
            <span class="badge badge-warning">منبع بیرونی به‌صورت خودکار راستی‌آزمایی نمی‌شود</span>
        </div>
        <?php if (empty($surveyInsights)): ?>
            <div class="alert alert-info">هنوز پژوهشی ثبت نشده است. منبع، حجم نمونه و درصدها را پس از گردآوری واقعی وارد کنید.</div>
        <?php else: ?>
            <div style="display:flex;flex-direction:column;gap:10px">
                <?php foreach (array_slice($surveyInsights, 0, 4) as $sv): ?>
                    <div style="padding:10px 12px;border-radius:12px;background:var(--surface-2);border:1px solid var(--border)">
                        <strong><?= e($sv['research_title'] ?? '') ?></strong>
                        <div class="muted" style="font-size:11.5px;margin-top:4px">
                            <?= e($sv['industry_segment'] ?? '') ?> · منبع ثبت‌شده: <?= e($sv['social_source'] ?? '') ?> · نمونه: <?= fa($sv['sample_size_orgs'] ?? 0) ?>
                        </div>
                        <div style="font-size:12px;margin-top:5px">
                            فوریت تقاضا: <?= fa($sv['demand_urgency_pct'] ?? 0) ?>٪ · احساس مثبت: <?= fa($sv['positive_sentiment_pct'] ?? 0) ?>٪ · WTP: <?= fa(number_format((int)($sv['willingness_to_pay_rial'] ?? 0))) ?> ریال
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <div class="card">
        <div class="card-header">
            <div class="card-title">🧭 نمای مقایسه رقبا بر پایه دوره‌های ثبت‌شده</div>
        </div>
        <div class="alert alert-info">این نما فقط رکوردهای محلی رقیب و دوره‌های ثبت‌شده را مقایسه می‌کند؛ کیفیت دوره و موقعیت رقابتی از روی قیمت به‌تنهایی استنتاج نمی‌شود.</div>
        <div class="table-wrap">
            <table>
                <thead><tr><th>رقیب</th><th>حوزه / پوشش</th><th>دوره ثبت‌شده</th><th>میانگین شهریه دوره</th></tr></thead>
                <tbody>
                <?php foreach (array_slice($competitorSummary, 0, 8) as $competitor): ?>
                    <tr>
                        <td><strong><?= e($competitor['name']) ?></strong></td>
                        <td><?= e($competitor['category']) ?><div class="muted" style="font-size:11px"><?= e($competitor['city_scope'] ?? '') ?></div></td>
                        <td><?= fa($competitor['courses_count']) ?></td>
                        <td><?= $competitor['avg_course_tuition_rial'] === null ? '—' : fa(number_format((int)$competitor['avg_course_tuition_rial'])) . ' ریال' ?></td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($competitorSummary)): ?>
                    <tr><td colspan="4" class="muted">پروفایل رقیبی ثبت نشده است.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- ==================== ROW 2: TAM / SAM / SOM CALCULATOR + B2B SURVEY ENGINE ==================== -->
<div class="grid grid-2" style="gap:18px;margin-bottom:18px;align-items:start">
    <div class="card">
        <div class="card-header">
            <div class="card-title">📐 ماشین‌حساب هوشمند اندازه بازار (TAM / SAM / SOM) و ثبت تحقیق میدانی</div>
        </div>
        <form method="post" action="<?= e(url('market-radar')) ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="save_survey_insight">
            <div class="form-grid">
                <div class="form-group">
                    <label>عنوان پژوهش بازار / نظرسنجی:</label>
                    <input type="text" name="survey_title" placeholder="مثلاً نیازسنجی مدیران صادرات" maxlength="190" required>
                </div>
                <div class="form-group">
                    <label>بخش صنعت هدف:</label>
                    <input type="text" name="industry_sector" placeholder="صنعت یا بخش مخاطب" maxlength="120" required>
                </div>
                <div class="form-group">
                    <label>منبع و روش گردآوری داده:</label>
                    <input type="text" name="survey_source" placeholder="مثلاً مصاحبه با مشتریان / CRM / پیمایش" maxlength="90" required>
                </div>
                <div class="form-group">
                    <label>حجم نمونه بررسی‌شده (شرکت/نفر):</label>
                    <input type="number" name="sample_size_orgs" min="1" max="100000" required>
                </div>
                <div class="form-group">
                    <label>فوریت تقاضای ثبت‌شده (٪):</label>
                    <input type="number" name="demand_urgency_pct" min="0" max="100" required>
                </div>
                <div class="form-group">
                    <label>احساس مثبت ثبت‌شده (٪):</label>
                    <input type="number" name="positive_sentiment_pct" min="0" max="100" required>
                </div>
                <div class="form-group">
                    <label>اندازه بازار بالقوه (TAM؛ نفر/ظرفیت): <strong id="lblTam">—</strong></label>
                    <input type="number" name="tam_learners" id="rngTam" min="1" max="100000000" required oninput="window.recalcMarketTam()">
                </div>
                <div class="form-group">
                    <label>بازار قابل‌دسترس (SAM؛ نفر/ظرفیت): <strong id="lblSam">—</strong></label>
                    <input type="number" name="sam_learners" id="rngSam" min="1" max="100000000" required oninput="window.recalcMarketTam()">
                </div>
                <div class="form-group">
                    <label>سهم قابل جذب (SOM؛ نفر): <strong id="lblSom">—</strong></label>
                    <input type="number" name="som_learners" id="rngSom" min="1" max="100000000" required oninput="window.recalcMarketTam()">
                </div>
                <div class="form-group">
                    <label>تمایل پرداخت هر نفر (WTP؛ ریال): <strong id="lblWtp">—</strong></label>
                    <input type="number" name="avg_willingness_to_pay_rial" id="rngWtp" min="1" max="1000000000" required oninput="window.recalcMarketTam()">
                </div>
            </div>
            <div class="form-group" style="margin-top:8px">
                <label>مهم‌ترین مهارت درخواستی استخراج‌شده از پرسشنامه‌ها:</label>
                <input type="text" name="top_requested_skill" maxlength="220" required>
            </div>
            <div class="form-group">
                <label>مسئله / نیاز اصلی پاسخ‌دهندگان:</label>
                <textarea name="key_pain_point" maxlength="5000" rows="2" required></textarea>
            </div>

            <div style="padding:12px;border-radius:12px;background:var(--primary-soft);margin:10px 0;display:flex;justify-content:space-between;align-items:center">
                <span>برآورد محاسباتی SOM × WTP (وابسته به داده‌های ورودی؛ تضمین فروش نیست):</span>
                <strong id="outSomTotalRial" style="font-size:16px;color:var(--primary)">—</strong>
            </div>
            <div class="alert alert-warning">اندازه بازار را بر مبنای تعداد نفر/ظرفیت آموزشی وارد کنید؛ کنترل سرور TAM ≥ SAM ≥ SOM را اعمال می‌کند. منبع و اعداد ثبت‌شده نیازمند اعتبارسنجی انسانی هستند.</div>
            <button type="submit" class="btn btn-primary btn-sm">💾 ثبت پژوهش و به‌روزرسانی بانک داده بازار</button>
        </form>
    </div>

    <div class="card">
        <div class="card-header">
            <div class="card-title">📊 یافته‌های تحقیق بازار ثبت‌شده</div>
            <span class="badge badge-warning">اعداد نمونه/قدیمی را پیش از استفاده راستی‌آزمایی کنید</span>
        </div>
        <div style="display:flex;flex-direction:column;gap:10px">
            <?php foreach ($surveyInsights as $sv): ?>
                <?php $estRevM = (int)round(((int)($sv['som_target_rial'] ?? 0)) / 1000000); ?>
                <div style="padding:12px;border-radius:12px;background:var(--surface-2);border:1px solid var(--border)">
                    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:5px">
                        <strong><?= e($sv['research_title'] ?? '') ?></strong>
                        <span class="badge badge-success">پتانسیل SOM: <?= fa(number_format($estRevM)) ?> میلیون ریال</span>
                    </div>
                    <div style="font-size:12px;color:var(--text-muted);margin-bottom:5px">
                        🏭 صنعت: <?= e($sv['industry_segment'] ?? '') ?> | منبع داده: <strong><?= e($sv['social_source'] ?? '') ?></strong>
                    </div>
                    <div style="font-size:12px">
                        🎯 نیاز اصلی: <strong style="color:var(--primary)"><?= e($sv['key_pain_point'] ?? '') ?></strong>
                        (نمونه: <?= fa($sv['sample_size_orgs'] ?? 0) ?> • فوریت: <?= fa($sv['demand_urgency_pct'] ?? 0) ?>٪ • احساس مثبت: <?= fa($sv['positive_sentiment_pct'] ?? 0) ?>٪)
                    </div>
                    <div class="muted" style="font-size:11px;margin-top:4px">
                        TAM: <?= fa(number_format((int)($sv['tam_provincial_rial'] ?? 0))) ?> ریال ·
                        SAM: <?= fa(number_format((int)($sv['sam_reachable_rial'] ?? 0))) ?> ریال ·
                        SOM: <?= fa(number_format((int)($sv['som_target_rial'] ?? 0))) ?> ریال ·
                        WTP: <?= fa(number_format((int)($sv['willingness_to_pay_rial'] ?? 0))) ?> ریال ·
                        ثبت: <?= e($sv['created_shamsi'] ?? '') ?>
                    </div>
                    <div class="muted" style="font-size:11px;margin-top:4px">راهبرد ثبت‌شده: <?= e($sv['ai_gtm_strategy'] ?? '') ?></div>
                </div>
            <?php endforeach; ?>
            <?php if (empty($surveyInsights)): ?>
                <div class="alert alert-info">هنوز یافته‌ای ثبت نشده است.</div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- ==================== ROW 3: CLOSED-LOOP 1-CLICK GTM FACTORY FROM AI RECOMMENDATIONS ==================== -->
<div class="card" style="margin-bottom:18px;border:2px solid rgba(16,185,129,0.4)">
    <div class="card-header">
        <div>
            <div class="card-title">🚀 چرخه ورود به بازار (تحقیق بازار ← دوره TMS ← درس LMS ← پیش‌نویس کمپین)</div>
            <div class="muted" style="font-size:12px;margin-top:3px">با یک کلیک، دوره و کلاس در TMS، سرفصل و آزمونک در LMS و ۴ پیش‌نویس تبلیغاتی ایجاد می‌شود؛ انتشار بیرونی کمپین متصل نیست.</div>
        </div>
        <form method="post" action="<?= e(url('market-radar')) ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="generate_ai_recommendations">
            <button type="submit" class="btn btn-gold btn-sm">✨ سنتز فرصت‌های اقیانوس آبی جدید با AI</button>
        </form>
    </div>

    <div class="table-wrap">
        <table>
            <thead>
            <tr>
                <th>عنوان دوره پیشنهادی (اقیانوس آبی)</th>
                <th>مخاطب هدف و توجیه تقاضا</th>
                <th>شهریه بهینه پیشنهادی</th>
                <th>اعتماد مدل</th>
                <th>اجرای چرخه کامل ورود به بازار (۱-کلیکی)</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($recommendations as $rec): ?>
                <tr>
                    <td>
                        <strong><?= e($rec['proposed_title']) ?></strong>
                        <div class="muted" style="font-size:11px">کد پیشنهادی: <?= e($rec['proposal_code'] ?? 'RD-101') ?> • <?= fa($rec['recommended_hours'] ?? 24) ?> ساعت</div>
                    </td>
                    <td style="max-width:300px;font-size:12px">
                        <div><strong><?= e($rec['target_audience']) ?></strong></div>
                        <div class="muted"><?= e(mb_substr((string)($rec['strategic_rationale'] ?? ''), 0, 105)) ?>...</div>
                    </td>
                    <td><strong><?= fa(number_format((int)$rec['suggested_tuition_rial'])) ?> ریال</strong></td>
                    <td><span class="badge badge-success"><?= fa($rec['ai_confidence_score'] ?? 94) ?>٪</span></td>
                    <td>
                        <form method="post" action="<?= e(url('market-radar')) ?>">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="launch_closed_loop_gtm">
                            <input type="hidden" name="topic_title" value="<?= e($rec['proposed_title']) ?>">
                            <input type="hidden" name="suggested_tuition_rial" value="<?= (int)$rec['suggested_tuition_rial'] ?>">
                            <input type="hidden" name="target_persona" value="<?= e($rec['target_audience']) ?>">
                            <button type="submit" class="btn btn-primary btn-sm">🚀 ساخت دوره TMS + درس LMS + پیش‌نویس کمپین</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- ==================== ROW 4: LIVE COMPETITOR CRAWLER + DISCOVERED DEMAND SIGNALS ==================== -->
<div class="grid grid-2" style="gap:18px;align-items:start">
    <div class="card">
        <div class="card-header"><div class="card-title">🏢 بانک رقبا و پایش وب عمومی</div></div>
        <div class="alert alert-info">اطلاعات پروفایل و دوره‌ها محلی است؛ پیش از تصمیم‌گیری، منبع و زمان آخرین بررسی را کنترل کنید. پایش فقط صفحات عمومی وب را می‌خواند.</div>
        <details style="margin-bottom:14px">
            <summary style="cursor:pointer;font-weight:800">افزودن یا به‌روزرسانی پروفایل رقیب</summary>
            <form method="post" action="<?= e(url('market-radar')) ?>" style="margin-top:10px">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="save_competitor">
                <div class="form-grid">
                    <input type="text" name="competitor_name" maxlength="180" required placeholder="نام مؤسسه">
                    <input type="text" name="category" maxlength="90" required placeholder="دسته / نوع رقیب">
                    <input type="url" name="website_url" maxlength="255" required placeholder="https://example.com">
                    <input type="text" name="city_scope" maxlength="80" placeholder="محدوده جغرافیایی">
                    <input type="number" name="avg_hourly_rate_rial" min="0" placeholder="نرخ ساعتی رقیب (ریال؛ اختیاری)">
                    <input type="text" name="delivery_model" maxlength="90" placeholder="حضوری، آنلاین یا ترکیبی">
                    <textarea name="key_strengths" maxlength="5000" rows="2" placeholder="نقاط قوت مشاهده‌شده"></textarea>
                    <textarea name="key_weaknesses" maxlength="5000" rows="2" placeholder="شکاف‌ها / نقاط ضعف مشاهده‌شده"></textarea>
                </div>
                <button type="submit" class="btn btn-primary btn-sm" style="margin-top:8px">ذخیره پروفایل</button>
            </form>
        </details>
        <div class="table-wrap" style="margin-bottom:16px">
            <table>
                <thead><tr><th>رقیب</th><th>گروه / محدوده</th><th>نرخ ساعتی ثبت‌شده</th><th>دوره‌های ثبت‌شده</th><th>آخرین بررسی</th><th>مشاهدات داخلی</th></tr></thead>
                <tbody>
                <?php foreach ($competitorSummary as $competitor): ?>
                    <tr>
                        <td><strong><?= e($competitor['name']) ?></strong><div class="muted" style="font-size:11px"><?= e($competitor['website_url']) ?></div></td>
                        <td><?= e($competitor['category']) ?><div class="muted" style="font-size:11px"><?= e($competitor['city_scope'] ?? '') ?> · <?= e($competitor['delivery_model'] ?? '') ?></div></td>
                        <td><?= $competitor['avg_hourly_rate_rial'] === null ? '—' : fa(number_format((int)$competitor['avg_hourly_rate_rial'])) . ' ریال' ?></td>
                        <td><?= fa($competitor['courses_count']) ?> · <?= $competitor['avg_course_tuition_rial'] === null ? 'بدون شهریه ثبت‌شده' : fa(number_format((int)$competitor['avg_course_tuition_rial'])) . ' ریال میانگین' ?></td>
                        <td><?= e($competitor['last_crawled_at'] ?? 'ثبت نشده') ?></td>
                        <td style="font-size:11px;max-width:180px">
                            <?= e(mb_substr((string)($competitor['key_strengths'] ?? ''), 0, 100)) ?>
                            <?php if (!empty($competitor['key_weaknesses'])): ?><div class="muted"><?= e(mb_substr((string)$competitor['key_weaknesses'], 0, 100)) ?></div><?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($competitorSummary)): ?>
                    <tr><td colspan="6" class="muted">هنوز رقیبی ثبت نشده است.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <details style="margin-bottom:14px">
            <summary style="cursor:pointer;font-weight:800">ثبت یا به‌روزرسانی یک دوره رقیب با منبع</summary>
            <?php if (empty($competitors)): ?>
                <div class="alert alert-info" style="margin-top:8px">ابتدا پروفایل یک رقیب را ثبت کنید.</div>
            <?php else: ?>
                <form method="post" action="<?= e(url('market-radar')) ?>" style="margin-top:10px">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="save_competitor_course">
                    <div class="form-grid">
                        <select name="competitor_id" required>
                            <?php foreach ($competitors as $competitor): ?>
                                <option value="<?= (int)$competitor['id'] ?>"><?= e($competitor['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <input type="text" name="course_title" maxlength="220" required placeholder="عنوان دوره مشاهده‌شده">
                        <input type="number" name="duration_hours" min="1" max="1000" placeholder="مدت (ساعت؛ اختیاری)">
                        <input type="number" name="tuition_rial" min="1" placeholder="شهریه (ریال؛ اختیاری)">
                        <input type="text" name="delivery_format" maxlength="60" placeholder="شیوه برگزاری">
                        <input type="url" name="source_url" maxlength="500" required placeholder="URL عمومی صفحه منبع">
                    </div>
                    <button type="submit" class="btn btn-outline btn-sm" style="margin-top:8px">ثبت اطلاعات مستند</button>
                </form>
            <?php endif; ?>
        </details>
        <h3 style="font-size:13px;margin:12px 0 8px">خزش اختیاری وب‌سایت برای استخراج دوره‌های عمومی</h3>
        <form method="post" action="<?= e(url('market-radar')) ?>" style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:14px">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="crawl_competitor">
            <input type="text" name="competitor_name" placeholder="نام رقیب" maxlength="180" style="max-width:170px" required>
            <input type="url" name="website_url" placeholder="نشانی صفحه عمومی دوره‌ها" maxlength="255" style="flex:1;min-width:190px" required>
            <button type="submit" class="btn btn-primary btn-sm">پایش صفحه عمومی</button>
        </form>
        <div class="table-wrap">
            <table>
                <thead><tr><th>مؤسسه رقیب</th><th>عنوان دوره استخراج‌شده</th><th>مدت</th><th>شهریه رقیب</th></tr></thead>
                <tbody>
                <?php foreach (array_slice($competitorCourses, 0, 8) as $cc): ?>
                    <tr>
                        <td><span class="badge badge-info"><?= e($cc['competitor_name']) ?></span></td>
                        <td><?= e($cc['course_title']) ?></td>
                        <td><?= empty($cc['duration_hours']) ? 'ثبت نشده' : fa($cc['duration_hours']) . ' ساعت' ?></td>
                        <td><?= $cc['tuition_rial'] === null ? 'ثبت نشده' : fa(number_format((int)$cc['tuition_rial'])) . ' ریال' ?></td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($competitorCourses)): ?>
                    <tr><td colspan="4" class="muted">هنوز دوره‌ای از وب‌سایت رقبا ثبت یا استخراج نشده است.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card">
        <div class="card-header"><div class="card-title">📡 سیگنال‌های وب عمومی و شکاف کاتالوگ</div></div>
        <div class="alert alert-warning">این فهرست شامل رکوردهای ذخیره‌شده است؛ ممکن است داده نمونه یا قدیمی باشد. منبع، نشانی و تاریخ هر سیگنال را پیش از استفاده بررسی کنید. شبکه‌های اجتماعی متصل نیستند.</div>
        <div class="table-wrap">
            <table>
                <thead><tr><th>موضوع پرتقاضا در بازار</th><th>فوریت تقاضا</th><th>وضعیت در کاتالوگ ما</th></tr></thead>
                <tbody>
                <?php foreach (array_slice($signals, 0, 8) as $sig): ?>
                    <tr>
                        <td>
                            <strong><?= e($sig['signal_title'] ?? '') ?></strong>
                            <div class="muted" style="font-size:11px"><?= e($sig['source_engine'] ?? '') ?></div>
                            <div class="muted" style="font-size:10px">جست‌وجو: <?= e($sig['keyword_query'] ?? '') ?> · تاریخ ثبت: <?= e($sig['discovered_shamsi'] ?? '') ?></div>
                            <?php if (!empty($sig['source_url'])): ?><div class="muted" style="font-size:10px;direction:ltr;text-align:right"><?= e($sig['source_url']) ?></div><?php endif; ?>
                        </td>
                        <td><span class="badge badge-gold"><?= fa($sig['demand_score'] ?? 90) ?>/۱۰۰</span></td>
                        <td>
                            <span class="badge <?= str_contains((string)($sig['catalog_gap_status'] ?? ''), 'شکاف') ? 'badge-success' : 'badge-info' ?>">
                                <?= e($sig['catalog_gap_status'] ?? 'اقیانوس آبی') ?>
                            </span>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($signals)): ?>
                    <tr><td colspan="3" class="muted">سیگنال بازاری ثبت نشده است؛ یک عبارت را از بالای صفحه پایش کنید.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
window.recalcMarketTam = function () {
    var tamValue = document.getElementById('rngTam').value;
    var samValue = document.getElementById('rngSam').value;
    var somValue = document.getElementById('rngSom').value;
    var wtpValue = document.getElementById('rngWtp').value;
    var tam = tamValue === '' ? 0 : parseInt(tamValue, 10);
    var sam = samValue === '' ? 0 : parseInt(samValue, 10);
    var som = somValue === '' ? 0 : parseInt(somValue, 10);
    var wtp = wtpValue === '' ? 0 : parseInt(wtpValue, 10);
    document.getElementById('lblTam').textContent = tam ? tam.toLocaleString('fa-IR') : '—';
    document.getElementById('lblSam').textContent = sam ? sam.toLocaleString('fa-IR') : '—';
    document.getElementById('lblSom').textContent = som ? som.toLocaleString('fa-IR') : '—';
    document.getElementById('lblWtp').textContent = wtp ? wtp.toLocaleString('fa-IR') : '—';
    document.getElementById('outSomTotalRial').textContent = som && wtp
        ? Math.round((som * wtp) / 1000000).toLocaleString('fa-IR') + ' میلیون ریال'
        : '—';
};
</script>
