<?php $isLearnerHelp = \App\Core\Auth::role() === 'learner'; ?>
<div class="hero-banner" style="background:linear-gradient(135deg, #061325 0%, #0f766e 58%, #b45309 100%)">
    <div>
        <span class="badge badge-gold" style="margin-bottom:8px">دانشنامه مرجع کل سیستم + موتور راهنمای اختصاصی و منحصربه‌فرد تک‌تک ۷۷ مسیر سامانه (F1)</span>
        <h1>مرکز جامع راهنما، مستندات بهره‌برداری، کتابچه ۸ نقش و فلوچارت‌های کل سامانه ERP</h1>
        <p>علاوه بر دکمه <strong>«❓ راهنمای همین صفحه (F1)»</strong> که در نوار بالا و پایین تک‌تک <strong><?= fa($totalGuides) ?> مسیر سامانه</strong> راهنمای گام‌به‌گام اختصاصی همان صفحه را باز می‌کند، در این مرکز می‌توانید کل معماری بخش‌های سامانه، ۱۶۰ جدول، دستورالعمل نقش‌ها و راهنمای استقرار را یکجا جست‌وجو یا چاپ نمایید.</p>
    </div>
    <div class="hero-actions">
        <a class="btn btn-gold" href="<?= e(url('help-manual-print')) ?>" target="_blank">🖨️ چاپ کتابچه کامل راهنمای سیستم (A4 PDF)</a>
        <button type="button" class="btn btn-outline" style="background:rgba(255,255,255,0.14);color:#fff;border-color:rgba(255,255,255,0.3)" data-open-modal="pageContextualHelpModal">❓ تست پنجره راهنمای صفحه فعلی (F1)</button>
    </div>
</div>

<!-- ۴ کارت آمار مستندات سامانه -->
<div class="grid grid-4" style="margin-bottom:18px">
    <div class="card" style="border-top:3px solid var(--primary)">
        <div class="muted" style="font-size:12px">راهنماهای منحصربه‌فرد صفحات</div>
        <div style="font-size:24px;font-weight:900;color:var(--primary);margin:4px 0"><?= fa($totalGuides) ?> راهنمای یکتا</div>
        <div class="muted" style="font-size:11.5px">پوشش ۱۰۰٪ مسیرهای داخلی، چاپی و عمومی</div>
    </div>
    <div class="card" style="border-top:3px solid var(--gold)">
        <div class="muted" style="font-size:12px">پوشش مستندات عملیاتی</div>
        <div style="font-size:22px;font-weight:900;color:var(--gold);margin:4px 0">پوشش ۱۰۰٪ بخش‌ها</div>
        <div class="muted" style="font-size:11.5px">همراه با جداول مرتبط و نکات طلایی</div>
    </div>
    <div class="card" style="border-top:3px solid #2563eb">
        <div class="muted" style="font-size:12px">کتابچه‌های عملیاتی نقش‌محور</div>
        <div style="font-size:24px;font-weight:900;color:#2563eb;margin:4px 0"><?= fa(count($playbooks)) ?> نقش سازمانی</div>
        <div class="muted" style="font-size:11.5px">شرح وظایف روزانه از مدیرکل تا فراگیر</div>
    </div>
    <div class="card" style="border-top:3px solid #059669">
        <div class="muted" style="font-size:12px">میانبرهای سراسری صفحه‌کلید</div>
        <div style="font-size:20px;font-weight:900;color:#059669;margin:6px 0" dir="ltr">F1 • Ctrl+K • Ctrl+Space</div>
        <div class="muted" style="font-size:11.5px">راهنمای صفحه، جست‌وجو و فرمان صوتی</div>
    </div>
</div>

<!-- ۵ تب جامع دانشنامه کل سیستم -->
<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:18px">
    <button type="button" class="btn <?= $activeTab === 'catalog' ? 'btn-gold' : 'btn-outline' ?> btn-sm hlp-tab-btn" onclick="switchHlpTab('catalog', this)">📖 ۱. دایرةالمعارف راهنمای تک‌تک ۷۷ صفحه (جست‌وجوی زنده)</button>
    <button type="button" class="btn <?= $activeTab === 'roles' ? 'btn-gold' : 'btn-outline' ?> btn-sm hlp-tab-btn" onclick="switchHlpTab('roles', this)">👥 ۲. کتابچه دستورالعمل روزانه ۸ نقش سازمانی</button>
    <button type="button" class="btn <?= $activeTab === 'flows' ? 'btn-gold' : 'btn-outline' ?> btn-sm hlp-tab-btn" onclick="switchHlpTab('flows', this)">🔄 ۳. نقشه جامع جریان کار و یکپارچگی ماژول‌ها</button>
    <button type="button" class="btn <?= $activeTab === 'deploy' ? 'btn-gold' : 'btn-outline' ?> btn-sm hlp-tab-btn" onclick="switchHlpTab('deploy', this)">🚀 ۴. راهنمای نصب XAMPP / cPanel، عیب‌یابی و کلیدهای میانبر</button>
    <button type="button" class="btn <?= $activeTab === 'admin_notes' ? 'btn-gold' : 'btn-outline' ?> btn-sm hlp-tab-btn" onclick="switchHlpTab('admin_notes', this)">✍️ ۵. ثبت یادداشت بومی استان روی راهنمای هر صفحه</button>
</div>

<!-- تب ۱: جست‌وجوی آنی در راهنمای منحصربه‌فرد تمام ۷۷ مسیر سامانه -->
<div id="hlpPanel_catalog" class="hlp-panel" style="display:<?= $activeTab === 'catalog' ? 'block' : 'none' ?>">
    <div class="card" style="margin-bottom:16px">
        <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
            <input type="text" id="instantHelpFilter" value="<?= e($searchQ) ?>"
                   onkeyup="filterHelpCardsInstant(this.value)"
                   placeholder="🔍 جست‌وجوی راهنما (مثلاً: مؤدیان، لایتنر، تم، سطح دسترسی، استرداد یا کاریابی...)"
                   style="flex:1;min-width:280px">
            <span class="badge badge-info" id="liveHelpCountBadge">نمایش <?= fa(count($allGuides)) ?> راهنمای یکتا</span>
        </div>
    </div>

    <div class="grid grid-2" id="helpCardsContainer">
        <?php foreach ($allGuides as $routeSlug => $g): ?>
            <div class="card help-guide-card" data-search="<?= e($routeSlug . ' ' . $g['title'] . ' ' . $g['category'] . ' ' . $g['mission'] . ' ' . implode(' ', $g['steps']) . ' ' . $g['golden_tip'] . ' ' . $g['tables']) ?>">
                <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:8px">
                    <span class="badge badge-info"><?= e($g['category']) ?></span>
                    <code style="font-size:11.5px">/<?= e($routeSlug) ?></code>
                </div>
                <h3 style="font-size:15px;margin-bottom:6px;color:var(--primary)"><?= e($g['title']) ?></h3>
                <p style="font-size:12.8px;margin-bottom:10px"><strong>🎯 هدف:</strong> <?= e($g['mission']) ?></p>
                <div style="background:var(--surface-2);border-radius:10px;padding:10px 12px;margin-bottom:10px;font-size:12.2px">
                    <?php foreach ($g['steps'] as $sIdx => $sTxt): ?>
                        <div style="margin-bottom:4px"><strong>گام <?= fa($sIdx + 1) ?>:</strong> <?= e($sTxt) ?></div>
                    <?php endforeach; ?>
                </div>
                <div style="font-size:12px;color:#b45309;margin-bottom:10px">💡 <strong>نکته کلیدی:</strong> <?= e($g['golden_tip']) ?></div>
                <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap;border-top:1px solid var(--border);padding-top:8px;font-size:11.5px">
                    <span class="muted">جداول: <code><?= e($g['tables']) ?></code></span>
                    <?php if (\App\Core\App::canViewRoute((string)$routeSlug)): ?>
                        <a class="btn btn-primary btn-sm" href="<?= e(url($routeSlug)) ?>">باز کردن این صفحه ←</a>
                    <?php else: ?>
                        <span class="badge badge-info" style="font-size:11px">🔒 راهنمای متنی — این بخش در حوزه دسترسی شما نیست</span>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- تب ۲: کتابچه عملیات استاندارد هر ۸ نقش سازمانی -->
<div id="hlpPanel_roles" class="hlp-panel" style="display:<?= $activeTab === 'roles' ? 'block' : 'none' ?>">
    <div class="grid grid-2">
        <?php foreach ($playbooks as $rSlug => $pb): ?>
            <div class="card">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
                    <h3 style="font-size:15.5px"><?= e($pb['title']) ?></h3>
                    <span class="badge badge-gold"><code><?= e($rSlug) ?></code></span>
                </div>
                <p style="font-size:13px;line-height:1.9"><?= e($pb['daily']) ?></p>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- تب ۳: معماری فرآیندهای سراسری کل سیستم -->
<div id="hlpPanel_flows" class="hlp-panel" style="display:<?= $activeTab === 'flows' ? 'block' : 'none' ?>">
    <div class="card" style="margin-bottom:16px">
        <div class="card-header"><div class="card-title">🔄 چرخه ۱: از پذیرش تا ارزیابی و ثبت سوابق آموزشی آدان</div></div>
        <p style="font-size:13.5px;line-height:2.1">
            <strong>۱. ثبت متقاضی و پیگیری پذیرش</strong> (<code>/admissions</code> و <code>/crm</code>) ⬅️
            <strong>۲. تعریف دوره و نوبت برگزاری</strong> (<code>/academic-erp-core</code> و <code>/tms</code>) ⬅️
            <strong>۳. ثبت‌نام و پیگیری پرداخت شهریه</strong> (<code>/role-workstations</code> و <code>/finance</code>) ⬅️
            <strong>۴. دسترسی به محتوای آموزشی و ثبت فعالیت یادگیری</strong> (<code>/lms</code> و <code>/microlearning</code>)؛ کلاس زنده متصل نیست.
            <strong>۵. برگزاری آزمون و ثبت نتیجه در سامانه</strong> (<code>/exams</code>)؛ پروکتورینگ متصل نیست.
            گواهی پایان دوره در سوابق آدان ثبت می‌شود؛ کاریابی و رزومه امکانات داخلی‌اند و همگام‌سازی یا استخدام خودکار انجام نمی‌شود.
        </p>
    </div>
    <div class="card" style="margin-bottom:16px">
        <div class="card-header"><div class="card-title">💳 چرخه ۲: یکپارچگی مالی، حسابداری ۴ سطحی، مالیات ماده ۸۶ و سامانه مؤدیان</div></div>
        <p style="font-size:13.5px;line-height:2.1">
            برخی عملیات مالی داخلی سند حسابداری ثبت می‌کنند؛ خروجی این صفحه CSV ساده است. اتصال به سپیدار یا سامانه مؤدیان، صدور شناسه مالیاتی و ارسال صورتحساب فعال نیست (<code>/tax-moadian</code>).
        </p>
    </div>
    <div class="card">
        <div class="card-header"><div class="card-title">🛡️ چرخه ۳: حاکمیت هوش مصنوعی AI، تم/فونت زنده و امنیت پویای RBAC</div></div>
        <p style="font-size:13.5px;line-height:2.1">
            قابلیت هوش مصنوعی فقط در صورت تنظیم کلید و نشانی ارائه‌دهنده فعال می‌شود؛ هنگام استفاده، درخواست‌ها به سرویس بیرونی تنظیم‌شده ارسال می‌شوند و نباید اطلاعات حساس فراگیران را وارد کرد. تنظیمات سامانه از <code>/system-settings</code> و دسترسی نقش‌ها از <code>/iam-access</code> مدیریت می‌شود.
        </p>
    </div>
</div>

<!-- تب ۴: راهنمای گام‌به‌گام استقرار در XAMPP و cPanel و کلیدهای میانبر -->
<div id="hlpPanel_deploy" class="hlp-panel" style="display:<?= $activeTab === 'deploy' ? 'block' : 'none' ?>">
    <div class="grid grid-2">
        <div class="card">
            <div class="card-header"><div class="card-title">🚀 راهنمای استقرار مستقیم با Import دیتابیس در XAMPP و cPanel (بدون صفحه نصب)</div></div>
            <div style="font-size:13px;line-height:2">
                <strong>۱. استخراج فایل‌ها:</strong> محتویات فایل <code>chamber-edu-xampp-cpanel.zip</code> را در پوشه <code>htdocs/chamber-edu</code> (در XAMPP) یا <code>public_html</code> (در cPanel) استخراج نمایید.<br>
                <strong>۲. Import مستقیم دیتابیس در phpMyAdmin:</strong> در <strong>XAMPP</strong> فایل یک‌کلیکی <code>database/xampp_oneclick_import.sql</code> (که دیتابیس <code>chamber_edu</code> را هم خودکار می‌سازد) و در <strong>cPanel</strong> پس از ساخت دیتابیس در <code>MySQL Databases</code> فایل <code>database/full_chamber_edu_xampp_cpanel.sql</code> (شامل هر ۱۶۰ جدول و داده‌های نمونه فارسی) را در <code>phpMyAdmin</code> مستقیماً <strong>Import</strong> نمایید.<br>
                <strong>۳. تنظیم فایل config/config.php (فقط در cPanel):</strong> در XAMPP مقادیر پیش‌فرض (<code>root</code> / بدون رمز / <code>chamber_edu</code>) از پیش تنظیم شده‌اند؛ در cPanel نام دیتابیس، نام کاربری، رمز عبور و کلید <code>AI</code> را در <code>config/config.php</code> وارد نمایید.<br>
                <strong>۴. ورود به سامانه:</strong> با نام کاربری <code>admin</code> و گذرواژه حساب مدیرکل وارد شوید؛ ورود با ایمیل پشتیبانی نمی‌شود.
            </div>
        </div>

        <div class="card">
            <div class="card-header"><div class="card-title">⌨️ جدول کلیدهای میانبر سراسری و ترفندهای سرعت کار</div></div>
            <div class="table-wrap">
                <table>
                    <thead><tr><th>کلید میانبر</th><th>عملکرد در تمام صفحات سامانه</th></tr></thead>
                    <tbody>
                        <tr><td dir="ltr"><code>F1</code></td><td>باز کردن فوری پنجره <strong>راهنمای اختصاصی و منحصربه‌فرد همان صفحه</strong></td></tr>
                        <tr><td dir="ltr"><code>Ctrl + K</code></td><td>باز کردن <strong>جست‌وجوی هوشمند نقش‌محور</strong> در کل سامانه</td></tr>
                        <tr><td dir="ltr"><code>Ctrl + Space</code></td><td>فعال‌سازی <strong>فرمانده صوتی فارسی</strong> جهت اجرای دستورات با صدا</td></tr>
                        <tr><td dir="ltr"><code>Esc</code></td><td>بستن فوری کلیه پنجره‌های مودال باز</td></tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- تب ۵: ویرایشگر یادداشت بومی استان روی راهنمای هر یک از ۷۷ صفحه -->
<div id="hlpPanel_admin_notes" class="hlp-panel" style="display:<?= $activeTab === 'admin_notes' ? 'block' : 'none' ?>">
<?php if (!$isLearnerHelp): ?>
    <div class="grid grid-2">
        <div class="card">
            <div class="card-header"><div class="card-title">✍️ افزودن دستورالعمل داخلی استان به پنجره راهنمای (F1) هر صفحه</div></div>
            <form method="post">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="save_page_sop">
                <div class="grid grid-2">
                    <div class="form-group">
                        <label>انتخاب صفحه مقصد از بین ۷۷ مسیر:</label>
                        <select name="route_key">
                            <?php foreach (\App\Services\ContextualHelpEncyclopediaService::getAllUniquePageGuides() as $rk => $gv): ?>
                                <option value="<?= e($rk) ?>">/<?= e($rk) ?> — <?= e($gv['title']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>داخلی کارشناس پشتیبان این بخش:</label>
                        <input type="text" name="contact_extension" value="داخلی ۲۱۵ — واحد آموزش" required>
                    </div>
                </div>
                <div class="form-group"><label>عنوان ابلاغیه / نکته بومی استان:</label><input type="text" name="local_sop_title" placeholder="مثلاً: ضابطه ارسال مدارک شعب شهرستان‌ها" required></div>
                <div class="form-group"><label>متن راهنمای تکمیلی که بالای پنجره F1 آن صفحه نمایش یابد:</label><textarea name="local_sop_body" rows="3" required placeholder="توضیحات اختصاصی واحد آموزش استان..."></textarea></div>
                <button type="submit" class="btn btn-gold">💾 ذخیره در راهنمای اختصاصی صفحه انتخابی</button>
            </form>
        </div>

        <div class="card">
            <div class="card-header"><div class="card-title">📌 یادداشت‌های بومی فعال و آخرین بازخوردهای کاربران</div></div>
            <?php foreach ($customNotes as $cn): ?>
                <div style="border:1px solid var(--border);border-radius:10px;padding:10px;margin-bottom:8px;font-size:12.5px">
                    <div style="display:flex;justify-content:space-between">
                        <strong><?= e($cn['local_sop_title']) ?></strong>
                        <code>/<?= e($cn['route_key']) ?></code>
                    </div>
                    <div class="muted" style="margin-top:4px"><?= e($cn['local_sop_body']) ?> (<?= e($cn['contact_extension']) ?>)</div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
<?php endif; ?>
</div>

<script>
function switchHlpTab(tab, btn) {
    document.querySelectorAll('.hlp-panel').forEach(p => p.style.display = 'none');
    document.getElementById('hlpPanel_' + tab).style.display = 'block';
    document.querySelectorAll('.hlp-tab-btn').forEach(b => { b.classList.remove('btn-gold'); b.classList.add('btn-outline'); });
    btn.classList.remove('btn-outline'); btn.classList.add('btn-gold');
}
function filterHelpCardsInstant(q) {
    const term = (q || '').trim().toLowerCase();
    let visible = 0;
    document.querySelectorAll('.help-guide-card').forEach(card => {
        const match = term === '' || card.getAttribute('data-search').toLowerCase().includes(term);
        card.style.display = match ? 'block' : 'none';
        if (match) visible++;
    });
    const b = document.getElementById('liveHelpCountBadge');
    if (b) b.textContent = 'نمایش ' + visible.toLocaleString('fa-IR') + ' راهنمای یکتا';
}
</script>
