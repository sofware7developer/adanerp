<?php use App\Core\QrSvg; ?>
<div class="card" style="max-width:880px;margin:0 auto">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px" class="no-print">
        <span class="badge badge-gold">رزومه رسمی و تاییدشده مرکز کاریابی مؤسسه آموزشی آدان (Adan Verified CV)</span>
        <button type="button" onclick="window.print()" class="btn btn-primary btn-sm">🖨️ چاپ یا ذخیره PDF رسمی A4</button>
    </div>

    <div class="cert-frame">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:16px;flex-wrap:wrap;border-bottom:2px solid #c99227;padding-bottom:14px;margin-bottom:16px">
            <div>
                <h1 style="font-size:22px;margin-bottom:4px"><?= e($profile['full_name'] ?? 'مهندس مهرداد شریفی') ?></h1>
                <div style="font-size:14.5px;font-weight:800;color:#0f766e"><?= e($profile['headline_title'] ?? '') ?></div>
                <div style="font-size:12.5px;margin-top:6px">
                    سابقه تخصصی: <strong><?= fa((int)($profile['experience_years'] ?? 6)) ?> سال</strong> |
                    حقوق مدنظر: <strong><?= fa((int)($profile['expected_salary_million'] ?? 62)) ?> میلیون تومان</strong> |
                    وضعیت: <strong><?= e($profile['availability_status'] ?? 'آماده همکاری') ?></strong>
                </div>
                <div style="font-size:12.5px;margin-top:4px">
                    زبان‌های تجاری: <?= e($profile['foreign_languages'] ?? '') ?> | رتبه گیمیفیکیشن اتاق: <strong><?= e($profile['gamification_xp_badge'] ?? '') ?></strong>
                </div>
            </div>
            <div style="text-align:center">
                <?= QrSvg::render(url('passport', ['u' => 'mehrdad-sharifi']), 108) ?>
                <div style="font-size:10.5px;margin-top:4px">استعلام اصالت پرونده مهارتی</div>
            </div>
        </div>

        <h3 style="font-size:15px;margin-bottom:8px">مهارت‌های کلیدی و نیمرخ حرفه‌ای (تاییدشده توسط واحد آموزش و کاریابی اتاق)</h3>
        <p style="font-size:13px;line-height:1.9;margin-bottom:14px">
            <strong>مهارت‌های عملیاتی:</strong> <?= e($profile['core_skills_csv'] ?? '') ?><br>
            <strong>نیمرخ سبک کاری (غیربالینی شغلی):</strong> <?= e($profile['work_style_nonclinical'] ?? '') ?>
        </p>

        <h3 style="font-size:15px;margin-bottom:8px">گواهی‌نامه‌های رسمی دارای کد رهگیری QR در بانک اطلاعات مؤسسه آموزشی آدان</h3>
        <div class="table-wrap">
            <table>
                <thead><tr><th>عنوان دوره مصوب</th><th>شماره سریال یکتا</th><th>مدت</th><th>درجه ارزشیابی</th><th>تاریخ صدور</th></tr></thead>
                <tbody>
                <?php foreach ($certs as $c): ?>
                    <tr>
                        <td><strong><?= e($c['course_title']) ?></strong></td>
                        <td dir="ltr"><code><?= e($c['serial_code']) ?></code></td>
                        <td><?= fa($c['hours_completed']) ?> ساعت</td>
                        <td><span class="badge badge-success"><?= e($c['grade_label']) ?></span></td>
                        <td><?= e($c['issue_shamsi']) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
