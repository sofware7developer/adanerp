<?php $isLearnerMicro = \App\Core\Auth::role() === 'learner'; ?>
<div class="hero-banner" style="background:linear-gradient(135deg, #0b1f3a 0%, #0f766e 60%, #1d4ed8 100%)">
    <div>
        <span class="badge badge-gold" style="margin-bottom:8px">پلتفرم جامع یادگیری خرد (Microlearning)، مرور فاصله‌دار SM-2/لایتنر و میکروپادکست مدیران</span>
        <h1>مرکز یادگیری خرد ۳ دقیقه‌ای، فلش‌کارت هوشمند لایتنر و تبدیل بخشنامه به میکرودرس با AI</h1>
        <p>طراحی‌شده ویژه مدیران پرمشغله صادرات، مالی و بازرگانی: یادگیری عمیق در کپسول‌های ۱۵۰ تا ۲۱۰ ثانیه‌ای، تثبیت علمی در حافظه بلندمدت با الگوریتم <strong>SuperMemo SM-2</strong>، شنیدن صوتی حین رانندگی و پاداش آنی <strong>XP + سکه مهارت</strong>.</p>
    </div>
    <div class="hero-actions">
        <button type="button" class="btn btn-gold" onclick="switchMicroTab('ai_studio', document.querySelectorAll('.micro-tab-btn')[3])">✨ تبدیل بخشنامه به کپسول ۳ دقیقه‌ای با AI</button>
        <?php if (\App\Core\App::canViewRoute('gamification-analytics')): ?>
        <a class="btn btn-outline" style="background:rgba(255,255,255,0.14);color:#fff;border-color:rgba(255,255,255,0.3)" href="<?= e(url('gamification-analytics')) ?>">🏆 کیف پول XP و لیگ یادگیری ←</a>
        <?php endif; ?>
    </div>
</div>

<!-- ۴ شاخص کلیدی یادگیری خرد -->
<div class="grid grid-4" style="margin-bottom:18px">
    <div class="card" style="border-top:3px solid var(--primary)">
        <div class="muted" style="font-size:12px">کپسول‌های میکرولرنینگ فعال</div>
        <div style="font-size:24px;font-weight:900;color:var(--primary);margin:4px 0"><?= fa(count($hub['capsules'])) ?> کپسول</div>
        <div class="muted" style="font-size:11.5px">میانگین زمان مطالعه: ۳ دقیقه (موبایل‌محور)</div>
    </div>
    <div class="card" style="border-top:3px solid var(--gold)">
        <div class="muted" style="font-size:12px">فلش‌کارت‌های موعد مرور امروز (SM-2)</div>
        <div style="font-size:24px;font-weight:900;color:var(--gold);margin:4px 0"><?= fa($hub['due_today_cnt']) ?> کارت 🔥</div>
        <div class="muted" style="font-size:11.5px">جلوگیری از منحنی فراموشی ابینگهاوس</div>
    </div>
    <div class="card" style="border-top:3px solid #2563eb">
        <div class="muted" style="font-size:12px">مجموع میکرودرس‌های تکمیل‌شده</div>
        <div style="font-size:24px;font-weight:900;color:#2563eb;margin:4px 0"><?= fa($hub['total_completions']) ?> نوبت</div>
        <div class="muted" style="font-size:11.5px">نرخ تکمیل ۸۹٪ (۳ برابر دوره‌های طولانی)</div>
    </div>
    <div class="card" style="border-top:3px solid #059669">
        <div class="muted" style="font-size:12px">نسخه‌های رفع شکاف مهارتی (ATS + آزمون)</div>
        <div style="font-size:24px;font-weight:900;color:#059669;margin:4px 0"><?= fa(count($hub['gap_links'])) ?> نسخه آنی</div>
        <div class="muted" style="font-size:11.5px">آموزش دقیقاً در لحظه نیاز شغلی</div>
    </div>
</div>

<!-- نوار ۵ تب تعاملی پلتفرم میکرولرنینگ -->
<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:18px">
    <button type="button" class="btn <?= $activeTab === 'capsules' ? 'btn-gold' : 'btn-outline' ?> btn-sm micro-tab-btn" onclick="switchMicroTab('capsules', this)">💊 ۱. کپسول‌های تعاملی ۳ دقیقه‌ای (Story Cards + Quiz)</button>
    <button type="button" class="btn <?= $activeTab === 'leitner' ? 'btn-gold' : 'btn-outline' ?> btn-sm micro-tab-btn" onclick="switchMicroTab('leitner', this)">🧠 ۲. جعبه لایتنر ۵ خانه‌ای و مرور فاصله‌دار (SM-2)</button>
    <button type="button" class="btn <?= $activeTab === 'challenge' ? 'btn-gold' : 'btn-outline' ?> btn-sm micro-tab-btn" onclick="switchMicroTab('challenge', this)">⚡ ۳. چالش ۶۰ ثانیه‌ای روزانه مدیران</button>
    <button type="button" class="btn <?= $activeTab === 'ai_studio' ? 'btn-gold' : 'btn-outline' ?> btn-sm micro-tab-btn" onclick="switchMicroTab('ai_studio', this)">🤖 ۴. استودیو AI تبدیل جزوه/بخشنامه به میکرودرس</button>
    <button type="button" class="btn <?= $activeTab === 'jobaids' ? 'btn-gold' : 'btn-outline' ?> btn-sm micro-tab-btn" onclick="switchMicroTab('jobaids', this)">🎧 ۵. میکروپادکست صوتی و تقلب‌نامه‌های رومیزی + رفع شکاف ATS</button>
    <?php if ($isLearnerMicro): ?>
        <button type="button" class="btn <?= $activeTab === 'mycards' ? 'btn-gold' : 'btn-outline' ?> btn-sm micro-tab-btn" onclick="switchMicroTab('mycards', this)">🃏 کارت‌های خودم — ساخت خودکار از یادداشت‌های من</button>
        <button type="button" class="btn <?= $activeTab === 'selfquiz' ? 'btn-gold' : 'btn-outline' ?> btn-sm micro-tab-btn" onclick="switchMicroTab('selfquiz', this)">🎯 آزمون خودساز — سنجش فوری از محتوای درس</button>
    <?php endif; ?>
</div>

<!-- تب ۱: کپسول‌های ۳ دقیقه‌ای با اسلایدر کارتی تعاملی و کوئیز تثبیت -->
<div id="microPanel_capsules" class="micro-panel" style="display:<?= $activeTab === 'capsules' ? 'block' : 'none' ?>">
    <div class="grid grid-2">
        <?php foreach ($hub['capsules'] as $cap): ?>
            <?php $cid = (int)$cap['id']; $done = in_array($cid, $hub['mastered_ids'], true); ?>
            <div class="card" style="border:1.5px solid <?= $done ? 'var(--success)' : 'rgba(15,118,110,0.28)' ?>">
                <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:10px">
                    <div style="display:flex;gap:6px;align-items:center">
                        <span class="badge badge-info"><?= e($cap['topic_domain']) ?></span>
                        <span class="badge badge-gold">⏱️ <?= fa(round((int)$cap['duration_seconds'] / 60, 1)) ?> دقیقه</span>
                        <span class="badge badge-success">+<?= fa($cap['xp_reward']) ?> XP</span>
                    </div>
                    <?php if ($done): ?>
                        <span class="badge badge-success">✅ تثبیت‌شده در پرونده شما</span>
                    <?php else: ?>
                        <code style="font-size:11.5px"><?= e($cap['capsule_code']) ?></code>
                    <?php endif; ?>
                </div>

                <h3 style="font-size:15.5px;margin-bottom:10px"><?= e($cap['title']) ?></h3>

                <!-- اسلایدر ۴ کارتی میکرولرنینگ (Hook -> Rule -> Example -> Instant Micro-Quiz) -->
                <div style="display:flex;gap:5px;margin-bottom:10px">
                    <button type="button" class="btn btn-primary btn-sm cap-step-btn-<?= $cid ?>" onclick="showCapStep(<?= $cid ?>, 1, this)">۱. مسئله کلیدی</button>
                    <button type="button" class="btn btn-outline btn-sm cap-step-btn-<?= $cid ?>" onclick="showCapStep(<?= $cid ?>, 2, this)">۲. قاعده طلایی</button>
                    <button type="button" class="btn btn-outline btn-sm cap-step-btn-<?= $cid ?>" onclick="showCapStep(<?= $cid ?>, 3, this)">۳. مثال صنعتی</button>
                    <button type="button" class="btn btn-outline btn-sm cap-step-btn-<?= $cid ?>" onclick="showCapStep(<?= $cid ?>, 4, this)">۴. تست ۱۰ ثانیه‌ای 🎯</button>
                </div>

                <div id="capStep_<?= $cid ?>_1" class="cap-slide-<?= $cid ?>" style="padding:13px;border-radius:12px;background:var(--surface-2);font-size:13px;min-height:84px">
                    <?= e($cap['slide_1_hook']) ?>
                </div>
                <div id="capStep_<?= $cid ?>_2" class="cap-slide-<?= $cid ?>" style="display:none;padding:13px;border-radius:12px;background:rgba(15,118,110,0.08);font-size:13px;min-height:84px">
                    <?= e($cap['slide_2_rule']) ?>
                </div>
                <div id="capStep_<?= $cid ?>_3" class="cap-slide-<?= $cid ?>" style="display:none;padding:13px;border-radius:12px;background:rgba(201,146,39,0.10);font-size:13px;min-height:84px">
                    <?= e($cap['slide_3_example']) ?>
                </div>
                <div id="capStep_<?= $cid ?>_4" class="cap-slide-<?= $cid ?>" style="display:none;padding:13px;border-radius:12px;border:1px dashed var(--primary);font-size:13px">
                    <form method="post">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="complete_capsule">
                        <input type="hidden" name="capsule_id" value="<?= $cid ?>">
                        <div style="font-weight:800;margin-bottom:8px">❓ <?= e($cap['quiz_question']) ?></div>
                        <label style="display:block;margin-bottom:5px;cursor:pointer"><input type="radio" name="selected_opt" value="A" style="width:auto;margin-left:6px"> الف) <?= e($cap['quiz_opt_a']) ?></label>
                        <label style="display:block;margin-bottom:5px;cursor:pointer"><input type="radio" name="selected_opt" value="B" checked style="width:auto;margin-left:6px"> ب) <?= e($cap['quiz_opt_b']) ?></label>
                        <label style="display:block;margin-bottom:10px;cursor:pointer"><input type="radio" name="selected_opt" value="C" style="width:auto;margin-left:6px"> ج) <?= e($cap['quiz_opt_c']) ?></label>
                        <button type="submit" class="btn btn-gold btn-sm">✅ ثبت پاسخ و دریافت +<?= fa($cap['xp_reward']) ?> XP</button>
                    </form>
                </div>

                <div style="margin-top:10px;display:flex;justify-content:space-between;align-items:center;font-size:12px" class="muted">
                    <span>👥 <?= fa($cap['completions_count']) ?> مدیر و کارشناس تکمیل کرده‌اند</span>
                    <button type="button" class="btn btn-outline btn-sm" style="padding:3px 9px;font-size:11.5px"
                            onclick="window.speakPersianReply(<?= js_attr($cap['title'] . '. ' . $cap['slide_2_rule']) ?>)">🔊 پخش صوتی کپسول</button>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- تب ۲: جعبه لایتنر گرافیکی — کارت دوطرفه با ورق‌خوردن سه‌بعدی -->
<style>
    .leitner-deck {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
        gap: 18px;
    }
    .fc {
        perspective: 1700px;
        height: 300px;
        border: 0;
        padding: 0;
        margin: 0;
        background: none;
        font: inherit;
        color: inherit;
        text-align: right;
        cursor: pointer;
    }
    .fc:focus-visible .fc-inner {
        outline: 3px solid var(--primary);
        outline-offset: 3px;
    }
    .fc-inner {
        position: relative;
        width: 100%;
        height: 100%;
        transition: transform .62s cubic-bezier(.42, .12, .18, 1);
    }
    .fc-3d .fc-inner { transform-style: preserve-3d; }
    .fc.is-flipped .fc-inner { transform: rotateY(180deg); }
    .fc-face {
        position: absolute;
        inset: 0;
        display: flex;
        flex-direction: column;
        gap: 9px;
        padding: 15px 16px;
        border-radius: 18px;
        overflow: hidden;
        box-shadow: 0 10px 26px rgba(15, 23, 42, .09);
    }
    .fc-3d .fc-face { backface-visibility: hidden; -webkit-backface-visibility: hidden; }
    .fc-face-front {
        border: 1.5px solid color-mix(in srgb, var(--primary) 34%, var(--border));
        background: linear-gradient(148deg, color-mix(in srgb, var(--primary) 12%, var(--surface)), var(--surface) 62%);
    }
    .fc-face-back {
        transform: rotateY(180deg);
        border: 1.5px solid color-mix(in srgb, var(--success) 55%, var(--border));
        background: linear-gradient(148deg, color-mix(in srgb, var(--success) 16%, var(--surface)), var(--surface) 60%);
    }
    .fc:not(.fc-3d) .fc-face { position: static; transform: none; }
    .fc:not(.fc-3d) { height: auto; }
    .fc:not(.fc-3d) .fc-face-back { display: none; }
    .fc:not(.fc-3d).is-flipped .fc-face-back { display: flex; margin-top: 10px; }
    .fc-topbar { display: flex; justify-content: space-between; align-items: center; gap: 8px; flex-wrap: wrap; }
    .fc-rail { display: flex; gap: 4px; align-items: center; }
    .fc-rail i {
        display: block;
        width: 27px;
        height: 8px;
        border-radius: 999px;
        background: color-mix(in srgb, var(--border) 78%, transparent);
    }
    .fc-rail i.on { background: linear-gradient(90deg, var(--gold), color-mix(in srgb, var(--gold) 62%, #fff)); }
    .fc-q {
        flex: 1;
        display: flex;
        align-items: center;
        font-weight: 800;
        font-size: 15.2px;
        line-height: 2;
        overflow: auto;
        padding-inline-end: 2px;
    }
    .fc-a {
        flex: 1;
        display: flex;
        align-items: center;
        font-size: 13.4px;
        line-height: 2.05;
        overflow: auto;
        color: var(--text);
        background: color-mix(in srgb, var(--surface) 65%, transparent);
        border-radius: 12px;
        padding: 10px 12px;
    }
    .fc-face-front::after {
        content: "";
        position: absolute;
        inset: 0;
        background: linear-gradient(128deg, color-mix(in srgb, var(--primary) 16%, transparent) 0%, transparent 46%);
        pointer-events: none;
    }
    .fc-coin {
        position: absolute;
        top: 13px;
        left: 13px;
        width: 30px;
        height: 30px;
        border-radius: 999px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 14px;
        color: #fff;
        background: linear-gradient(140deg, var(--primary), color-mix(in srgb, var(--primary) 55%, #000));
        box-shadow: 0 4px 12px rgba(15, 23, 42, .18);
    }
    .fc-rail i { position: relative; }
    .fc-rail i.on::after {
        content: "";
        position: absolute;
        inset: -2px 0;
        border-radius: 999px;
        background: color-mix(in srgb, var(--gold) 45%, transparent);
        filter: blur(5px);
        z-index: -1;
    }
    .fc-meta {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 8px;
        font-size: 11.4px;
        color: var(--text-dim);
        border-top: 1px dashed color-mix(in srgb, var(--border) 80%, transparent);
        padding-top: 8px;
    }
    .fc-hint { display: inline-flex; gap: 5px; align-items: center; font-weight: 700; color: var(--primary); }
    .fc-acts { display: flex; gap: 6px; flex-wrap: wrap; }
    @media (max-width: 640px) {
        .fc { height: 330px; }
    }
</style>

<div id="microPanel_leitner" class="micro-panel" style="display:<?= $activeTab === 'leitner' ? 'block' : 'none' ?>">
    <div class="alert alert-info" style="margin-bottom:16px;font-size:12.5px">
        🧠 <strong>جعبه لایتنر ۵ خانه‌ای با الگوریتم SuperMemo SM-2:</strong> روی هر کارت کلیک کنید (یا کلید Enter/Space) تا کارت ورق بخورد و پاسخ پشت آن نمایان شود؛ سپس میزان تسلط خود را انتخاب کنید تا خانه کارت، ضریب آسانی و فاصله مرور بعدی (۱، ۴، ۱۲ یا ۳۰ روز) به‌صورت خودکار به‌روز شود.
    </div>

    <?php if (empty($hub['flashcards'])): ?>
        <div class="card">
            <div class="card-header"><div class="card-title">🗂 جعبه لایتنر شما خالی است</div></div>
            <p class="muted" style="margin:0;font-size:13px">با تب «تبدیل بخشنامه به میکرودرس» یا مطالعه درس‌های LMS، فلش‌کارت‌های مرور فاصله‌دار برای شما ساخته می‌شود.</p>
        </div>
    <?php else: ?>
        <div class="leitner-deck">
            <?php foreach ($hub['flashcards'] as $fc): ?>
                <?php
                $fid = (int)$fc['id'];
                $box = max(1, min(5, (int)($fc['leitner_box'] ?? 1)));
                $rail = '';
                for ($bIdx = 1; $bIdx <= 5; $bIdx++) {
                    $rail .= '<i class="' . ($bIdx <= $box ? 'on' : '') . '" title="خانه ' . $bIdx . '"></i>';
                }
                ?>
                <div class="fc" id="fcCard_<?= $fid ?>" tabindex="0" role="button" aria-pressed="false"
                     aria-label="کارت لایتنر: با کلیک یا کلید Enter پاسخ را ببینید">
                    <div class="fc-inner">
                        <div class="fc-face fc-face-front">
                            <div class="fc-topbar">
                                <span class="badge badge-info"><?= e($fc['deck_category']) ?></span>
                                <span class="badge badge-warning">⏳ <?= e($fc['next_review_label']) ?></span>
                            </div>
                            <span class="fc-coin" aria-hidden="true">↻</span>
                            <div class="fc-rail" aria-label="خانه <?= fa($box) ?> از ۵"><?= $rail ?></div>
                            <div class="fc-q">❓ <?= e($fc['front_prompt']) ?></div>
                            <div class="fc-meta">
                                <span>خانه <?= fa($box) ?> از ۵ • مرورها: <?= fa((int)$fc['reviews_count']) ?> • ضریب آسانی: <?= fa(number_format((float)$fc['ease_factor'], 2, '.', '')) ?></span>
                                <span class="fc-hint">🔄 برای پاسخ، کارت را بچرخانید</span>
                            </div>
                        </div>

                        <div class="fc-face fc-face-back">
                            <div class="fc-topbar">
                                <span class="badge badge-success">💡 پاسخ پشت کارت</span>
                                <span class="badge badge-gold">📏 فاصله فعلی: <?= fa((int)$fc['interval_days']) ?> روز</span>
                            </div>
                            <div class="fc-a"><?= nl2br(e($fc['back_answer'])) ?></div>
                            <form method="post" class="fc-acts" action="<?= e(url('microlearning')) ?>" onclick="event.stopPropagation()">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="review_flashcard">
                                <input type="hidden" name="card_id" value="<?= $fid ?>">
                                <button type="submit" name="quality" value="again" class="btn btn-outline btn-sm">😓 سخت بود — خانه ۱ و مرور فردا</button>
                                <button type="submit" name="quality" value="good" class="btn btn-primary btn-sm">🤔 همان‌طور که بود (×۱٫۸)</button>
                                <button type="submit" name="quality" value="easy" class="btn btn-gold btn-sm">⚡ تسلط کامل (+۲۵ XP)</button>
                            </form>
                            <button type="button" class="btn btn-outline btn-sm" data-fc-unflip="<?= $fid ?>" style="align-self:flex-start">↩︎ روی صورت کارت</button>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        <script>
        (function () {
            var supports3d = window.CSS && CSS.supports && CSS.supports('transform-style', 'preserve-3d');
            function flip(card, force) {
                if (force === true) { card.classList.remove('is-flipped'); }
                else if (force === false) { card.classList.add('is-flipped'); }
                else { card.classList.toggle('is-flipped'); }
                card.setAttribute('aria-pressed', card.classList.contains('is-flipped') ? 'true' : 'false');
            }
            document.querySelectorAll('.fc').forEach(function (card) {
                if (supports3d) card.classList.add('fc-3d');
                card.addEventListener('click', function (ev) {
                    if (ev.target.closest('form') || ev.target.closest('[data-fc-unflip]')) return;
                    flip(card);
                });
                card.addEventListener('keydown', function (ev) {
                    if (ev.key === 'Enter' || ev.key === ' ' || ev.key === 'Spacebar') {
                        if (ev.target.closest('form')) return;
                        ev.preventDefault();
                        flip(card);
                    }
                    if (ev.key === 'Escape') flip(card, true);
                });
            });
            document.querySelectorAll('[data-fc-unflip]').forEach(function (btn) {
                btn.addEventListener('click', function (ev) {
                    ev.preventDefault();
                    var card = document.getElementById('fcCard_' + btn.getAttribute('data-fc-unflip'));
                    if (card) { card.classList.remove('is-flipped'); card.setAttribute('aria-pressed', 'false'); }
                });
            });
        })();
        </script>
    <?php endif; ?>
</div>


<!-- تب ۳: چالش ۶۰ ثانیه‌ای روزانه مدیران -->
<div id="microPanel_challenge" class="micro-panel" style="display:<?= $activeTab === 'challenge' ? 'block' : 'none' ?>">
    <?php foreach ($hub['challenges'] as $ch): ?>
        <div class="card" style="max-width:860px;border:2px solid var(--gold)">
            <div class="card-header">
                <div class="card-title">⚡ <?= e($ch['scenario_title']) ?></div>
                <div style="display:flex;gap:8px;align-items:center">
                    <span class="badge badge-danger" id="live60Timer">⏱️ تایمر معکوس: ۶۰ ثانیه</span>
                    <span class="badge badge-gold">پاداش ویژه: +<?= fa($ch['bonus_xp']) ?> XP</span>
                </div>
            </div>
            <p style="font-size:14px;line-height:1.95;padding:14px;background:var(--surface-2);border-radius:12px;margin-bottom:14px">
                <?= e($ch['scenario_case']) ?>
            </p>
            <form method="post">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="submit_daily_challenge">
                <input type="hidden" name="challenge_id" value="<?= (int)$ch['id'] ?>">
                <label style="display:block;padding:10px;border:1px solid var(--border);border-radius:10px;margin-bottom:8px;cursor:pointer"><input type="radio" name="picked_option" value="1" style="width:auto;margin-left:8px"> ۱) <?= e($ch['option_1']) ?></label>
                <label style="display:block;padding:10px;border:1px solid var(--border);border-radius:10px;margin-bottom:8px;cursor:pointer"><input type="radio" name="picked_option" value="2" checked style="width:auto;margin-left:8px"> ۲) <?= e($ch['option_2']) ?></label>
                <label style="display:block;padding:10px;border:1px solid var(--border);border-radius:10px;margin-bottom:14px;cursor:pointer"><input type="radio" name="picked_option" value="3" style="width:auto;margin-left:8px"> ۳) <?= e($ch['option_3']) ?></label>
                <button type="submit" class="btn btn-primary">🚀 ثبت تصمیم مدیریتی و مشاهده تحلیل حقوقی</button>
            </form>
        </div>
    <?php endforeach; ?>
</div>

<!-- تب ۴: استودیو هوش مصنوعی تبدیل متن بلند / بخشنامه به کپسول ۳ دقیقه‌ای -->
<div id="microPanel_ai_studio" class="micro-panel" style="display:<?= $activeTab === 'ai_studio' ? 'block' : 'none' ?>">
<?php if (!$isLearnerMicro): ?>
    <div class="card" style="max-width:860px">
        <div class="card-header">
            <div class="card-title">🤖 تبدیل خودکار بخشنامه گمرکی/مالیاتی یا جزوه طولانی به «کپسول ۳ دقیقه‌ای + فلش‌کارت لایتنر»</div>
            <span class="badge badge-info">AI Micro-Chunker</span>
        </div>
        <form method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="ai_generate_capsule">
            <div class="grid grid-3">
                <div class="form-group">
                    <label>عنوان کپسول میکرولرنینگ:</label>
                    <input type="text" name="topic_title" value="بخشنامه جدید تهاتر ارزی صادرکنندگان صنعتی ۱۴۰۵" required>
                </div>
                <div class="form-group">
                    <label>حوزه تخصصی:</label>
                    <select name="topic_domain">
                        <option>تجارت بین‌الملل</option>
                        <option>گمرک و لجستیک</option>
                        <option>مالیات و مؤدیان</option>
                        <option>هوش مصنوعی تجاری</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>زمان هدف مطالعه:</label>
                    <select name="duration_seconds">
                        <option value="120">۲ دقیقه (فوق فشرده)</option>
                        <option value="180" selected>۳ دقیقه (استاندارد طلایی)</option>
                        <option value="240">۴ دقیقه (همراه با مثال)</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label>متن خام بخشنامه، آیین‌نامه یا سرفصل طولانی جهت خردسازی هوشمند:</label>
                <textarea name="raw_source_text" rows="4" required>طبق دستورالعمل جدید تجاری، واحدهای تولیدی صادرکننده می‌توانند ۱۰۰ درصد پروانه صادراتی خود را بدون نوبت در تالار فرعی جهت واردات ماشین‌آلات خط تولید و مواد اولیه با معافیت کارمزد بانکی تهاتر نمایند.</textarea>
            </div>
            <button type="submit" class="btn btn-gold">✨ ساخت خودکار ۴ اسلاید میکرولرنینگ + فلش‌کارت لایتنر + تست تثبیت</button>
        </form>
    </div>
<?php endif; ?>
</div>

<!-- تب ۵: میکروپادکست‌های صوتی، تقلب‌نامه‌های رومیزی و نسخه‌های رفع شکاف مهارتی ATS -->
<div id="microPanel_jobaids" class="micro-panel" style="display:<?= $activeTab === 'jobaids' ? 'block' : 'none' ?>">
<?php if (!$isLearnerMicro): ?>
    <div class="grid grid-2" style="margin-bottom:16px">
        <div class="card">
            <div class="card-header"><div class="card-title">🎧 میکروپادکست‌های ۳ دقیقه‌ای و تقلب‌نامه‌های روی میز کارشناس (Job Aids)</div></div>
            <?php foreach ($hub['job_aids'] as $ja): ?>
                <div style="border:1px solid var(--border);border-radius:12px;padding:12px;margin-bottom:10px">
                    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
                        <span class="badge badge-gold"><?= e($ja['target_desk']) ?></span>
                        <button type="button" class="btn btn-primary btn-sm" onclick="window.speakPersianReply(<?= js_attr($ja['audio_script_summary']) ?>)">▶️ پخش پادکست صوتی</button>
                    </div>
                    <strong style="display:block;margin-bottom:4px"><?= e($ja['aid_title']) ?></strong>
                    <div style="font-size:12.5px;margin-bottom:4px"><?= e($ja['key_steps_summary']) ?></div>
                    <div class="muted" style="font-size:11.5px">🎙️ چکیده صوتی: <?= e($ja['audio_script_summary']) ?></div>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="card">
            <div class="card-header"><div class="card-title">🔗 تجویز هوشمند میکرودرس برای رفع فوری شکاف مهارتی آزمون و استخدام (ATS)</div></div>
            <?php foreach ($hub['gap_links'] as $gl): ?>
                <div style="border:1px solid var(--border);border-radius:12px;padding:12px;margin-bottom:10px">
                    <div style="display:flex;justify-content:space-between;margin-bottom:6px">
                        <span class="badge badge-warning"><?= e($gl['source_module']) ?></span>
                        <span class="badge badge-success">رفع شکاف در <?= fa($gl['estimated_fix_minutes']) ?> دقیقه</span>
                    </div>
                    <strong><?= e($gl['detected_gap_topic']) ?></strong>
                    <div class="muted" style="font-size:12px;margin:4px 0">کپسول تجویزی: <code><?= e($gl['prescribed_capsule_code']) ?></code> — <?= e($gl['impact_note']) ?></div>
                </div>
            <?php endforeach; ?>

            <hr style="border:none;border-top:1px solid var(--border);margin:14px 0">
            <form method="post">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="create_job_aid">
                <div class="form-group"><label>عنوان تقلب‌نامه ۱ صفحه‌ای جدید:</label><input type="text" name="aid_title" placeholder="مثلاً: جدول کنترلی گواهی مبدأ CT-3 اوراسیا" required></div>
                <div class="form-group"><label>گام‌های کلیدی روی میز کار:</label><input type="text" name="key_steps_summary" placeholder="۱. کد تعرفه | ۲. معیار مبدأ | ۳. تأیید مرجع صادرکننده" required></div>
                <button type="submit" class="btn btn-outline btn-sm">➕ ثبت تقلب‌نامه رومیزی جدید</button>
            </form>
        </div>
    </div>
<?php endif; ?>
</div>

<?php if ($isLearnerMicro): ?>
<!-- ═════════════ ★ v26.8 — تب «کارت‌های خودم» (تبدیل یادداشت‌ها به کارت مرور) ★ ═════════════ -->
<div id="microPanel_mycards" class="micro-panel" style="display:<?= $activeTab === 'mycards' ? 'block' : 'none' ?>">
    <div class="alert alert-info" style="margin-bottom:16px;font-size:12.5px">
        🤖 <strong>کارت‌سازی هوشمند از یادداشت‌های خودتان:</strong> سامانه یادداشت‌های ثانیه‌ای شما در LMS و درس‌های دوره‌هایتان را می‌خواند و برای هرکدام یک کارت مرور دوطرفه در خانه ۱ جعبه لایتنر می‌سازد. این کارت‌ها فقط مالکیت شما را دارند و در نمای هیچ کاربر دیگری نمایش داده نمی‌شوند.
    </div>

    <div class="grid grid-4" style="margin-bottom:16px">
        <div class="stat-card"><div><div class="stat-label">کارت‌های شخصی من</div><div class="stat-value"><?= fa(count($personalCards)) ?> کارت</div><div class="stat-meta">ساخته‌شده با AI از یادداشت‌ها و درس‌های من</div></div><div class="stat-icon icon-purple">🃏</div></div>
        <div class="stat-card"><div><div class="stat-label">یادداشت‌های قابل تبدیل</div><div class="stat-value"><?= fa((int)($coach['notes_count'] ?? 0)) ?> یادداشت</div><div class="stat-meta">هر یادداشت می‌تواند یک کارت شود</div></div><div class="stat-icon icon-teal">📝</div></div>
        <div class="stat-card"><div><div class="stat-label">میانگین حفظ فعلی</div><div class="stat-value"><?= fa((int)round((float)($coach['forecast']['retention_pct'] ?? 0))) ?>٪</div><div class="stat-meta">بر پایه فاصله و ضریب آسانی کارت‌ها</div></div><div class="stat-icon icon-gold">🧠</div></div>
        <div class="stat-card"><div><div class="stat-label">کارت‌های در معرض فراموشی</div><div class="stat-value"><?= fa(count((array)($coach['forecast']['fading'] ?? []))) ?> کارت</div><div class="stat-meta">اگر امروز مرور نشوند، خانه‌شان می‌افتد</div></div><div class="stat-icon icon-blue">⚠️</div></div>
    </div>

    <div class="card" style="margin-bottom:16px">
        <div class="card-header">
            <div class="card-title">🤖 ساخت کارت تازه</div>
            <form method="post" action="<?= e(url('microlearning')) ?>" style="display:flex;gap:8px;align-items:center;margin:0">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="generate_my_cards">
                <label style="font-size:12px" for="pcCount">تعداد:</label>
                <select id="pcCount" name="card_count" style="padding:6px 8px;border-radius:9px">
                    <option value="4">۴ کارت</option>
                    <option value="6" selected>۶ کارت</option>
                    <option value="8">۸ کارت</option>
                    <option value="12">۱۲ کارت (هفتۀ پرمشغله)</option>
                </select>
                <button type="submit" class="btn btn-gold btn-sm">🃏 از یادداشت‌ها و درس‌هایم کارت بساز</button>
            </form>
        </div>
        <div style="font-size:12.3px;color:var(--text-muted);line-height:1.9">
            کارت تکراری ساخته نمی‌شود: اگر از یک یادداشت کارت داشته باشید، همان رد می‌شود. برای شروع یادداشت‌ها، در پلیر LMS روی «یادداشت ثانیه‌ای» بزنید.
        </div>
    </div>

    <?php if ($personalCards === []): ?>
        <div class="card"><p class="muted" style="margin:0;font-size:13px">هنوز کارتی نساخته‌اید — دکمه طلایی بالا را بزنید تا نخستین کارت‌های شخصی شما در خانه ۱ جعبه لایتنر بنشیند.</p></div>
    <?php else: ?>
        <div class="leitner-deck">
            <?php foreach ($personalCards as $pc): ?>
                <?php
                $pid = (int)$pc['id'];
                $pbox = max(1, min(5, (int)($pc['leitner_box'] ?? 1)));
                $prail = '';
                for ($pb = 1; $pb <= 5; $pb++) {
                    $prail .= '<i class="' . ($pb <= $pbox ? 'on' : '') . '" title="خانه ' . $pb . '"></i>';
                }
                ?>
                <div class="fc" id="pcCard_<?= $pid ?>" tabindex="0" role="button" aria-pressed="false"
                     aria-label="کارت شخصی: با کلیک پاسخ را ببینید">
                    <div class="fc-inner">
                        <div class="fc-face fc-face-front">
                            <div class="fc-topbar">
                                <span class="badge badge-gold">کارت شخصی من</span>
                                <span class="badge badge-warning">⏳ <?= e($pc['next_review_label']) ?></span>
                            </div>
                            <span class="fc-coin" aria-hidden="true">↻</span>
                            <div class="fc-rail" aria-label="خانه <?= fa($pbox) ?> از ۵"><?= $prail ?></div>
                            <div class="fc-q"><?= e($pc['front_prompt']) ?></div>
                            <div class="fc-meta">
                                <span><?= e($pc['deck_category']) ?> • مرورها: <?= fa((int)$pc['reviews_count']) ?></span>
                                <span class="fc-hint">🔄 برای پاسخ، کارت را بچرخانید</span>
                            </div>
                        </div>
                        <div class="fc-face fc-face-back">
                            <div class="fc-topbar">
                                <span class="badge badge-success">💡 پاسخ</span>
                                <span class="badge badge-info">📏 فاصله: <?= fa((int)$pc['interval_days']) ?> روز</span>
                            </div>
                            <div class="fc-a"><?= nl2br(e($pc['back_answer'])) ?></div>
                            <form method="post" class="fc-acts" action="<?= e(url('microlearning')) ?>" onclick="event.stopPropagation()">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="review_flashcard">
                                <input type="hidden" name="card_id" value="<?= $pid ?>">
                                <button type="submit" name="quality" value="again" class="btn btn-outline btn-sm">😓 سخت بود</button>
                                <button type="submit" name="quality" value="good" class="btn btn-primary btn-sm">🤔 همان‌طور که بود</button>
                                <button type="submit" name="quality" value="easy" class="btn btn-gold btn-sm">⚡ تسلط کامل</button>
                            </form>
                            <form method="post" action="<?= e(url('microlearning')) ?>" onclick="event.stopPropagation()" style="display:flex;gap:6px;align-items:center">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="delete_my_card">
                                <input type="hidden" name="card_id" value="<?= $pid ?>">
                                <button type="submit" class="btn btn-outline btn-sm">🗑 حذف این کارت</button>
                                <button type="button" class="btn btn-outline btn-sm" data-fc-unflip="<?= $pid ?>">↩︎ روی صورت کارت</button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<!-- ═════════════ ★ v26.8 — تب «آزمون خودساز» ★ ═════════════ -->
<div id="microPanel_selfquiz" class="micro-panel" style="display:<?= $activeTab === 'selfquiz' ? 'block' : 'none' ?>">
    <div class="alert alert-info" style="margin-bottom:16px;font-size:12.5px">
        🎯 <strong>آزمون خودساز:</strong> سامانه از شناسنامه دوره و درس‌های خودتان (مدت، سطح، قالب درس، زمان لازم و…) تا ۶ سؤال چهارگزینه‌ای می‌سازد، همان لحظه تصحیح می‌کند و برای هر پاسخ، توضیح می‌دهد نکته از کجای داده‌های دوره آمده است. این آزمون نمره رسمی ندارد و فقط سنجش خودی است.
    </div>

    <div class="card" style="margin-bottom:16px">
        <div class="card-header"><div class="card-title">۱. یک دوره انتخاب کنید</div></div>
        <form method="post" action="<?= e(url('microlearning')) ?>" style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="quiz_generate">
            <select name="quiz_course_id" style="flex:1;min-width:240px;padding:8px;border-radius:10px">
                <?php $coursePool = $myCourses !== [] ? $myCourses : (($coach['courses'] ?? []) ?: []); ?>
                <?php foreach ($coursePool as $qc): ?>
                    <option value="<?= (int)$qc['id'] ?>"><?= e($qc['title']) ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="btn btn-primary btn-sm">🎯 ۶ سؤال بساز</button>
        </form>
    </div>

    <?php if (!empty($quizResult['rows'])): ?>
        <div class="card" style="margin-bottom:16px;border:1.5px solid <?= $quizResult['score_pct'] >= 60 ? 'rgba(15,118,110,.35)' : 'rgba(185,28,28,.3)' ?>">
            <div class="card-header">
                <div class="card-title">۲. نتیجه آزمون شما</div>
                <span class="badge <?= $quizResult['score_pct'] >= 60 ? 'badge-success' : 'badge-danger' ?>">
                    <?= fa((int)$quizResult['right']) ?> از <?= fa((int)$quizResult['total']) ?> صحیح • <?= fa((int)$quizResult['score_pct']) ?>٪ • +<?= fa((int)$quizResult['xp']) ?> XP
                </span>
            </div>
            <p style="font-size:13px;margin:0 0 12px"><?= e($quizResult['verdict']) ?></p>
            <div class="table-wrap">
                <table>
                    <thead><tr><th>#</th><th>سؤال</th><th>پاسخ شما</th><th>پاسخ صحیح</th><th>منبع / توضیح</th></tr></thead>
                    <tbody>
                    <?php foreach ($quizResult['rows'] as $qr): ?>
                        <tr>
                            <td><?= fa((int)$qr['n']) ?></td>
                            <td><?= e($qr['q']) ?></td>
                            <td><?= $qr['ok'] ? '<span class="badge badge-success">✓ ' . e($qr['picked']) . '</span>' : '<span class="badge badge-danger">✗ ' . e($qr['picked']) . '</span>' ?></td>
                            <td><strong><?= e($qr['correct']) ?></strong></td>
                            <td class="muted" style="font-size:12px"><?= e($qr['why']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px">
                <form method="post" action="<?= e(url('microlearning')) ?>" style="margin:0">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="generate_my_cards">
                    <input type="hidden" name="card_count" value="6">
                    <button type="submit" class="btn btn-gold btn-sm">🃏 <?= e($quizResult['next_step']) ?></button>
                </form>
                <button type="button" class="btn btn-outline btn-sm" onclick="switchMicroTab('leitner', document.querySelectorAll('.micro-tab-btn')[1])">🧠 رفتن به جعبه لایتنر</button>
            </div>
        </div>
    <?php elseif (!empty($quizDraft['questions'])): ?>
        <form method="post" action="<?= e(url('microlearning')) ?>" class="card">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="quiz_submit">
            <div class="card-header"><div class="card-title">۲. پاسخ دهید — <?= e($quizDraft['course_title']) ?></div>
                <span class="badge badge-info"><?= fa(count($quizDraft['questions'])) ?> سؤال</span></div>
            <?php foreach ($quizDraft['questions'] as $qi => $qq): ?>
                <fieldset style="border:1px solid var(--border);border-radius:14px;padding:12px 14px;margin-bottom:12px">
                    <legend style="font-size:12.5px;font-weight:700;padding:0 6px">سؤال <?= fa($qi + 1) ?>: <?= e($qq['q']) ?></legend>
                    <?php foreach ($qq['options'] as $oi => $opt): ?>
                        <label style="display:flex;gap:8px;align-items:center;font-size:13px;margin:5px 0">
                            <input type="radio" name="answers[<?= (int)$qi ?>]" value="<?= e($opt) ?>" <?= $oi === 0 ? '' : '' ?> required>
                            <span><?= e($opt) ?></span>
                        </label>
                    <?php endforeach; ?>
                </fieldset>
            <?php endforeach; ?>
            <button type="submit" class="btn btn-primary">✅ تصحیح و نمایش کارنامه</button>
        </form>
    <?php else: ?>
        <div class="card"><p class="muted" style="margin:0;font-size:13px">هنوز آزمونی نساخته‌اید؛ یک دوره را انتخاب و «۶ سؤال بساز» را بزنید.</p></div>
    <?php endif; ?>
</div>

<?php endif; ?>

<script>
function switchMicroTab(tab, btn) {
    document.querySelectorAll('.micro-panel').forEach(p => p.style.display = 'none');
    document.getElementById('microPanel_' + tab).style.display = 'block';
    document.querySelectorAll('.micro-tab-btn').forEach(b => { b.classList.remove('btn-gold'); b.classList.add('btn-outline'); });
    if (btn) { btn.classList.remove('btn-outline'); btn.classList.add('btn-gold'); }
}
function showCapStep(cid, step, btn) {
    document.querySelectorAll('.cap-slide-' + cid).forEach(el => el.style.display = 'none');
    document.getElementById('capStep_' + cid + '_' + step).style.display = 'block';
    document.querySelectorAll('.cap-step-btn-' + cid).forEach(b => { b.classList.remove('btn-primary'); b.classList.add('btn-outline'); });
    btn.classList.remove('btn-outline'); btn.classList.add('btn-primary');
}
function speakPersianText(txt) {
    if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
        const u = new SpeechSynthesisUtterance(txt);
        u.lang = 'fa-IR';
        u.rate = 1.05;
        window.speechSynthesis.speak(u);
    } else {
        alert(txt);
    }
}
(function(){
    let sec = 60;
    setInterval(function(){
        const el = document.getElementById('live60Timer');
        if (!el || el.offsetParent === null) return;
        if (sec > 0) sec--;
        el.textContent = '⏱️ تایمر معکوس: ' + sec.toLocaleString('fa-IR') + ' ثانیه';
    }, 1000);
})();
</script>
