<div class="hero-banner">
    <div>
        <span class="badge badge-gold">ماژول راهبردی ۴۱ | مغز متفکر و اتوپایلوت ERP سازمانی (Autonomous AI-Native ERP Core — 100 Tables)</span>
        <h1>هسته مرکزی ERP هوشمند: پیش‌بینی ۹۰ روزه، زمان‌بند بدون تداخل، ضدریزش RFM و قوانین خودران</h1>
        <p>
            ارتقای سامانه از «نرم‌افزار ثبت اطلاعات» به <strong>ERP خودران تصمیم‌ساز و اقدام‌گر</strong>: پایش بلادرنگ ناهنجاری‌ها، شبیه‌ساز جریان نقدینگی ۹۰ روزه، حل‌کننده محدودیت کلاس/استاد/سالن، پیش‌بینی ریزش اعضا (Churn) و تطبیق خودکار فارغ‌التحصیلان با کارخانجات استان.
        </p>
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
        <button type="button" class="btn btn-gold" onclick="window.runErpAutopilotClient('full_autopilot')">اجرای ۱-کلیکی تمام موتورهای هوشمند ERP</button>
        <button type="button" class="btn btn-outline" style="background:rgba(255,255,255,0.14);color:#fff;border-color:rgba(255,255,255,0.3)" onclick="window.openVoiceCommanderModal(false)">فرمان صوتی به مغز ERP</button>
    </div>
</div>

<!-- LIVE AUTOPILOT FEEDBACK BANNER -->
<div id="erpAutopilotFeedback" style="display:none;margin-bottom:16px;padding:16px 20px;border-radius:14px;background:linear-gradient(135deg,#0b1f3a,#0f766e);color:#fff;border:1.5px solid #fbbf24"></div>

<!-- 4 COGNITIVE ERP KPI TILES -->
<div class="grid grid-4" style="margin-bottom:18px">
    <div class="stat-card">
        <div>
            <div class="stat-label">شاخص بلوغ و ضریب هوش عملیاتی ERP</div>
            <div class="stat-value"><?= fa($scorecard['erp_iq_index']) ?> از ۱۰۰</div>
            <div class="stat-meta">۱۰۰ جدول فعال | تراز دفترکل: <?= fa($scorecard['ledger_drift_rial']) ?> ریال</div>
        </div>
        <div class="stat-icon icon-teal"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg></div>
    </div>

    <div class="stat-card">
        <div>
            <div class="stat-label">پیش‌بینی جریان نقدینگی ۹۰ روز آینده</div>
            <div class="stat-value"><?= rial($scorecard['forecast_90d_base']) ?></div>
            <div class="stat-meta">سقف خوش‌بینانه: <?= rial($scorecard['forecast_90d_opt']) ?></div>
        </div>
        <div class="stat-icon icon-gold"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg></div>
    </div>

    <div class="stat-card">
        <div>
            <div class="stat-label">بهره‌وری زمان‌بند هوشمند بدون تداخل</div>
            <div class="stat-value"><?= fa($scorecard['avg_seat_util_pct']) ?>٪ صندلی</div>
            <div class="stat-meta">صفر تداخل استاد، سالن و تجهیزات کارگاهی</div>
        </div>
        <div class="stat-icon icon-royal"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg></div>
    </div>

    <div class="stat-card">
        <div>
            <div class="stat-label">اجرای خودکار قوانین میان‌ماژولی</div>
            <div class="stat-value"><?= fa($scorecard['total_auto_runs']) ?> تراکنش خودران</div>
            <div class="stat-meta"><?= fa($scorecard['open_alerts']) ?> هشدار هوشمند آماده اقدام ۱-کلیکی</div>
        </div>
        <div class="stat-icon icon-purple"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg></div>
    </div>
</div>

<!-- SECTION 1: REAL-TIME ANOMALY, RISK & OPPORTUNITY RADAR WITH 1-CLICK SELF-HEALING -->
<div class="card" style="margin-bottom:18px;border:1.5px solid rgba(201,146,39,0.4)">
    <div class="card-header">
        <div>
            <div class="card-title">رادار بلادرنگ کشف ناهنجاری، ریسک مالی/تحصیلی و شکار فرصت (Self-Healing Anomaly Center)</div>
            <div class="muted" style="font-size:12px">تشخیص خودکار گلوگاه‌های درآمدی، چک‌های سررسید نزدیک، افت یادگیری SCORM و ریزش اعضای طلایی با اقدام اصلاحی ۱-کلیکی</div>
        </div>
        <span class="badge badge-gold">پایش زنده ۱۰۰ جدول</span>
    </div>
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>کد هشدار</th>
                    <th>سطح اهمیت</th>
                    <th>ماژول منشأ</th>
                    <th>تشخیص تحلیلی موتور هوش مصنوعی</th>
                    <th>اثر مالی برآوردی</th>
                    <th>تجویز خودکار ERP</th>
                    <th>اقدام ۱-کلیکی</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($alerts as $al): ?>
                <tr>
                    <td><code><?= e($al['alert_code']) ?></code></td>
                    <td>
                        <?php if ($al['severity'] === 'critical'): ?>
                            <span class="badge badge-danger">بحرانی فوری</span>
                        <?php elseif ($al['severity'] === 'opportunity'): ?>
                            <span class="badge badge-success">فرصت درآمدی</span>
                        <?php else: ?>
                            <span class="badge badge-gold">هشدار پیش‌بین</span>
                        <?php endif; ?>
                    </td>
                    <td><?php if (\App\Core\App::canViewRoute((string)$al['module_route'])): ?><a href="<?= e(url($al['module_route'])) ?>" class="badge badge-info"><?= e($al['module_route']) ?></a><?php else: ?><span class="badge badge-info"><?= e($al['module_route']) ?></span><?php endif; ?></td>
                    <td>
                        <strong><?= e($al['alert_title']) ?></strong>
                        <div class="muted" style="font-size:11.5px;margin-top:3px"><?= e($al['ai_diagnosis']) ?></div>
                    </td>
                    <td><strong><?= rial((int)$al['financial_impact_rial']) ?></strong></td>
                    <td style="font-size:12px"><?= e($al['prescribed_action']) ?></td>
                    <td>
                        <?php if ($al['status'] === 'resolved'): ?>
                            <span class="badge badge-success">رفع‌شده خودکار ✓</span>
                        <?php else: ?>
                            <form method="post" style="display:inline" onsubmit="if(!window.location.protocol.startsWith('http')||typeof PAGES!=='undefined'){event.preventDefault();window.runErpAutopilotClient('resolve_alert','<?= e($al['alert_code']) ?>',this);}">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="resolve_alert">
                                <input type="hidden" name="alert_id" value="<?= (int)$al['id'] ?>">
                                <button type="submit" class="btn btn-primary btn-sm">اجرای خودکار تجویز</button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- SECTION 2: 90-DAY MONTE-CARLO CFO FORECAST + AUTONOMOUS CROSS-MODULE EVENT RULES -->
<div class="grid grid-2" style="margin-bottom:18px">
    <div class="card">
        <div class="card-header">
            <div class="card-title">شبیه‌ساز پیش‌بینی ۹۰ روزه جریان نقدینگی و نقطه سربه‌سر (AI CFO Forecast)</div>
            <span class="badge badge-success">۳ سناریوی احتمالی</span>
        </div>
        <div style="display:flex;flex-direction:column;gap:12px">
            <div>
                <div style="display:flex;justify-content:space-between;font-size:12.5px;margin-bottom:4px">
                    <span>سناریوی خوش‌بینانه (تکمیل ظرفیت دوره‌های R&amp;D + تمدید B2B)</span>
                    <strong style="color:var(--success)"><?= rial($scorecard['forecast_90d_opt']) ?></strong>
                </div>
                <div style="height:10px;background:var(--surface-2);border-radius:99px;overflow:hidden"><div style="width:94%;height:100%;background:linear-gradient(90deg,#0f766e,#10b981)"></div></div>
            </div>
            <div>
                <div style="display:flex;justify-content:space-between;font-size:12.5px;margin-bottom:4px">
                    <span>سناریوی پایه مورد انتظار (روند فعلی ثبت‌نام و قراردادها)</span>
                    <strong style="color:var(--primary)"><?= rial($scorecard['forecast_90d_base']) ?></strong>
                </div>
                <div style="height:10px;background:var(--surface-2);border-radius:99px;overflow:hidden"><div style="width:76%;height:100%;background:linear-gradient(90deg,#1d4ed8,#3b82f6)"></div></div>
            </div>
            <div>
                <div style="display:flex;justify-content:space-between;font-size:12.5px;margin-bottom:4px">
                    <span>سناریوی محافظه‌کارانه (کف تضمین‌شده خزانه و چک‌های صیادی)</span>
                    <strong style="color:var(--gold)"><?= rial($scorecard['forecast_90d_pess']) ?></strong>
                </div>
                <div style="height:10px;background:var(--surface-2);border-radius:99px;overflow:hidden"><div style="width:60%;height:100%;background:linear-gradient(90deg,#b45309,#f59e0b)"></div></div>
            </div>
            <div class="alert alert-info" style="margin-top:4px;font-size:12px">
                <strong>تجویز هوشمند مدیر مالی (AI CFO):</strong> با انتقال ۱۸ متقاضی لیست انتظار دوره «NTSW و اظهار EPL» به نوبت عصر تالار خلیج فارس، خالص جریان ورودی خزانه در ماه جاری <strong>۸۹۶٬۰۰۰٬۰۰۰ ریال</strong> بدون هزینه ثابت جدید افزایش می‌یابد.
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <div class="card-title">گذرگاه قوانین خودران میان‌ماژولی (Event-Driven ERP Autopilot)</div>
            <span class="badge badge-purple">بدون دخالت دست</span>
        </div>
        <div style="display:flex;flex-direction:column;gap:8px">
            <?php foreach ($rules as $rl): ?>
                <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;padding:10px 12px;border-radius:10px;background:var(--surface-2);border:1px solid var(--border)">
                    <div>
                        <div style="font-weight:800;font-size:12.5px"><?= e($rl['rule_title']) ?></div>
                        <div class="muted" style="font-size:11.5px;margin-top:2px">
                            شرط: <?= e($rl['trigger_condition']) ?> ← مقصد: <strong><?= e($rl['target_modules']) ?></strong>
                        </div>
                    </div>
                    <form method="post" onsubmit="if(!window.location.protocol.startsWith('http')||typeof PAGES!=='undefined'){event.preventDefault();window.runErpAutopilotClient('trigger_rule','<?= e($rl['rule_code']) ?>');}">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="trigger_rule">
                        <input type="hidden" name="rule_id" value="<?= (int)$rl['id'] ?>">
                        <button type="submit" class="btn btn-outline btn-sm" style="white-space:nowrap">اجرای فوری (<?= fa($rl['executions_count']) ?>)</button>
                    </form>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- SECTION 3: CRM RFM + CHURN MATRIX & CONSTRAINT AUTO-SCHEDULER -->
<div class="grid grid-2" style="margin-bottom:18px">
    <div class="card">
        <div class="card-header" style="align-items:center">
            <div class="card-title">هوش پیش‌بینی ریزش اعضا (Churn) و بهترین دوره بعدی (CRM RFM + NBA)</div>
            <form method="post" onsubmit="if(!window.location.protocol.startsWith('http')||typeof PAGES!=='undefined'){event.preventDefault();window.runErpAutopilotClient('run_rfm');}">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="run_rfm">
                <button type="submit" class="btn btn-gold btn-sm">بازمحاسبه زنده RFM</button>
            </form>
        </div>
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>بنگاه اقتصادی عضو</th>
                        <th>خوشه RFM</th>
                        <th>احتمال ریزش</th>
                        <th>بهترین دوره پیشنهادی بعدی (NBA)</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($rfmRows as $rf): ?>
                    <tr>
                        <td>
                            <strong><?= e($rf['org_name']) ?></strong>
                            <div class="muted" style="font-size:11px">گردش مالی: <?= rial((int)$rf['monetary_rial']) ?></div>
                        </td>
                        <td><span class="badge badge-info"><?= e($rf['segment_label']) ?></span></td>
                        <td>
                            <span class="badge <?= (int)$rf['churn_probability_pct'] >= 40 ? 'badge-danger' : 'badge-success' ?>">
                                <?= fa($rf['churn_probability_pct']) ?>٪ ریسک
                            </span>
                        </td>
                        <td style="font-size:12px">
                            <?= e($rf['next_best_course']) ?>
                            <span class="badge badge-gold">مشوق <?= fa($rf['prescribed_discount_pct']) ?>٪</span>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card">
        <div class="card-header" style="align-items:center">
            <div class="card-title">زمان‌بند خودکار محدودیت‌محور کلاس × استاد × سالن (Zero-Conflict AI Scheduler)</div>
            <form method="post" onsubmit="if(!window.location.protocol.startsWith('http')||typeof PAGES!=='undefined'){event.preventDefault();window.runErpAutopilotClient('run_scheduler');}">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="run_scheduler">
                <button type="submit" class="btn btn-primary btn-sm">چیدمان خودکار بدون تداخل</button>
            </form>
        </div>
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>دوره</th>
                        <th>استاد و سالن تخصیص‌یافته</th>
                        <th>بازه زمانی بهینه</th>
                        <th>اشغال صندلی</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($schedules as $sc): ?>
                    <tr>
                        <td><strong><?= e($sc['course_title']) ?></strong></td>
                        <td style="font-size:12px"><?= e($sc['instructor_name']) ?><div class="muted"><?= e($sc['classroom_name']) ?></div></td>
                        <td style="font-size:12px"><?= e($sc['assigned_slot']) ?></td>
                        <td><span class="badge badge-success"><?= fa($sc['utilization_pct']) ?>٪ (<?= fa($sc['predicted_learners']) ?>/<?= fa($sc['room_capacity']) ?>)</span></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- SECTION 4: AI SKILL-GRAPH TO FACTORY JOB MATCHMAKER -->
<div class="card">
    <div class="card-header" style="align-items:center">
        <div>
            <div class="card-title">موتور گراف تطبیق هوشمند مهارت، کارنامه روان‌سنجی/زبان و اشتغال در صنایع عضو (AI Talent-to-Industry Graph)</div>
            <div class="muted" style="font-size:12px">تلاقی خودکار نتایج آزمون‌های استاندارد (MBTI / DISC / CEFR / Holland) و گواهی‌های QR با نیاز واقعی کارخانجات استان</div>
        </div>
        <form method="post" onsubmit="if(!window.location.protocol.startsWith('http')||typeof PAGES!=='undefined'){event.preventDefault();window.runErpAutopilotClient('run_matchmaker');}">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="run_matchmaker">
            <button type="submit" class="btn btn-gold btn-sm">اجرای تطبیق هوشمند جدید</button>
        </form>
    </div>
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>دانش‌آموخته / متخصص</th>
                    <th>نیمرخ روان‌شناختی و زبانی</th>
                    <th>بنگاه صنعتی مقصد</th>
                    <th>سمت پیشنهادی</th>
                    <th>امتیاز تطبیق گراف</th>
                    <th>میکرودوره تکمیلی پیشنهادی</th>
                    <th>وضعیت</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($matches as $m): ?>
                <tr>
                    <td><strong><?= e($m['candidate_name']) ?></strong></td>
                    <td><span class="badge badge-purple"><?= e($m['psychometric_badge']) ?></span></td>
                    <td><strong><?= e($m['target_company']) ?></strong></td>
                    <td><?= e($m['job_role_title']) ?></td>
                    <td><span class="badge badge-success"><?= fa($m['match_score_pct']) ?>٪ تطبیق</span></td>
                    <td style="font-size:12px"><?= e($m['recommended_gap_course']) ?></td>
                    <td><span class="badge badge-info"><?= e($m['status']) ?></span></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
