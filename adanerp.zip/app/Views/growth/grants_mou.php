<div class="hero-banner">
    <div>
        <span class="badge badge-gold">تسهیم شهریه یارانه‌ای صنایع کوچک و تفاهم‌نامه‌ها</span>
        <h1>مدیریت تفاهم‌نامه‌ها (MoU)، یارانه‌های آموزشی SMEها و حامیان مالی</h1>
        <p>تخصیص یارانه‌های حمایتی آموزش ویژه واحدهای صنعتی کوچک، پایش تفاهم‌نامه‌های دانشگاهی و بسته‌های اسپانسرینگ همایش‌ها.</p>
    </div>
</div>

<div class="grid grid-sidebar">
    <div class="card">
        <div class="card-header"><div class="card-title">🤝 تفاهم‌نامه‌ها، ردیف‌های یارانه‌ای و حامیان فعال</div></div>
        <div class="table-wrap">
            <table>
                <thead><tr><th>نوع / نهاد طرف تفاهم</th><th>عنوان طرح</th><th>سهم یارانه</th><th>اعتبار کل / جذب‌شده</th><th>انقضا</th></tr></thead>
                <tbody>
                <?php foreach ($items as $it): ?>
                    <tr>
                        <td><span class="badge badge-purple"><?= e($it['record_category']) ?></span><div><strong><?= e($it['partner_organization']) ?></strong></div></td>
                        <td><?= e($it['title']) ?></td>
                        <td><span class="badge badge-gold"><?= fa($it['subsidy_percent']) ?>٪ تخفیف یارانه</span></td>
                        <td><?= rial($it['utilized_rial']) ?> از <?= rial($it['allocated_budget_rial']) ?></td>
                        <td><?= e($it['expiry_shamsi']) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card">
        <div class="card-header"><div class="card-title">➕ ثبت تفاهم‌نامه / ردیف یارانه جدید</div></div>
        <form method="post" action="<?= e(url('grants-mou')) ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="create_grant">
            <div class="form-group">
                <select name="record_category">
                    <option value="یارانه آموزشی SME">یارانه آموزشی صنایع کوچک (SME)</option>
                    <option value="تفاهم‌نامه همکاری">تفاهم‌نامه مشترک نهاد/دانشگاه</option>
                    <option value="حامی مالی همایش">بسته حامی مالی (Sponsor)</option>
                </select>
            </div>
            <div class="form-group"><input type="text" name="partner_organization" value="صندوق ضمانت صادرات ایران" required></div>
            <div class="form-group"><input type="text" name="title" value="حمایت آموزشی پوشش ریسک صادراتی اعضای جدید" required></div>
            <div class="form-grid">
                <input type="number" name="subsidy_percent" value="50">
                <input type="number" name="allocated_budget_rial" value="950000000">
            </div>
            <div class="form-group" style="margin-top:8px"><input type="text" name="expiry_shamsi" value="۱۴۰۶/۰۳/۳۱" required></div>
            <button type="submit" class="btn btn-primary" style="width:100%">ثبت طرح حمایتی</button>
        </form>
    </div>
</div>

<!-- v14.0 AI SME SUBSIDY ROI OPTIMIZER -->
<div class="card" style="margin-top:18px;border:1.5px solid rgba(15,118,110,0.3)">
    <div class="card-header">
        <div>
            <div class="card-title">موتور رتبه‌بندی و تخصیص عادلانه یارانه آموزشی SME بر پایه ضریب بازگشت اقتصادی (AI Subsidy ROI Optimizer)</div>
            <div class="muted" style="font-size:12px">اولویت‌بندی شفاف و بدون سلیقه واحدهای تولیدی بر اساس اشتغال، آمادگی صادراتی و بازدهی بودجه حمایتی اتاق</div>
        </div>
        <span class="badge badge-success">تخصیص هوشمند مبتنی بر داده</span>
    </div>
    <form method="post" action="<?= e(url('grants-mou')) ?>" class="grid grid-4" style="gap:10px;align-items:end;margin-bottom:14px">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="score_sme_subsidy">
        <div><label>نام واحد تولیدی SME:</label><input type="text" name="sme_company_name" value="تولیدی قطعات دقیق پارس" required></div>
        <div><label>تعداد پرسنل بیمه:</label><input type="number" name="employees_count" value="54"></div>
        <div><label>شاخص آمادگی صادرات (۰-۱۰۰):</label><input type="number" name="export_readiness_idx" value="82"></div>
        <div><button type="submit" class="btn btn-gold" style="width:100%">محاسبه سهم یارانه مصوب</button><input type="hidden" name="requested_subsidy_pct" value="45"></div>
    </form>
    <div class="table-wrap">
        <table>
            <thead><tr><th>کد تخصیص</th><th>واحد صنعتی متقاضی</th><th>اشتغال</th><th>آمادگی صادرات</th><th>درصد یارانه مصوب AI</th><th>ضریب بازگشت اقتصادی</th><th>رتبه اولویت</th></tr></thead>
            <tbody>
            <?php foreach (($allocations ?? []) as $al): ?>
                <tr>
                    <td><code><?= e($al['alloc_code']) ?></code></td>
                    <td><strong><?= e($al['sme_company_name']) ?></strong></td>
                    <td><?= fa($al['employees_count']) ?> نفر</td>
                    <td><?= fa($al['export_readiness_idx']) ?>٪</td>
                    <td><span class="badge badge-gold"><?= fa($al['ai_approved_subsidy_pct']) ?>٪ یارانه</span></td>
                    <td><strong><?= fa((string)$al['economic_roi_multiplier']) ?> برابر</strong></td>
                    <td><span class="badge badge-success"><?= e($al['priority_rank_label']) ?></span></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

