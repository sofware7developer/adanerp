<?php use App\Core\QrSvg; ?>
<div class="card" style="max-width:920px;margin:0 auto">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px" class="no-print">
        <span class="badge badge-gold">کارنامه جامع رسمی آموزشی و ریزنمرات مؤسسه آموزشی آدان (Official Academic Transcript)</span>
        <button type="button" onclick="window.print()" class="btn btn-primary btn-sm">🖨️ چاپ یا ذخیره PDF رسمی A4</button>
    </div>

    <div class="cert-frame">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:16px;flex-wrap:wrap;border-bottom:2px solid #c99227;padding-bottom:14px;margin-bottom:16px">
            <div>
                <h1 style="font-size:21px;margin-bottom:4px">کارنامه رسمی ریزنمرات و وضعیت حضور دوره‌های تخصصی مؤسسه آموزشی آدان</h1>
                <div style="font-size:13.5px;color:#0f766e;font-weight:800">میانگیـن کل وزنی کارنامه: <?= fa($avgScore) ?> از ۱۰۰ | میانگین حضور در جلسات: <?= fa($avgAtt) ?>٪</div>
            </div>
            <div style="text-align:center">
                <?= QrSvg::render(url('verify', ['code' => 'CERT-ADN-1405-9001']), 96) ?>
                <div style="font-size:10.5px;margin-top:4px">اصالت کارنامه دیجیتال</div>
            </div>
        </div>

        <div class="table-wrap">
            <table>
                <thead><tr><th>شماره سریال</th><th>نام فراگیر</th><th>عنوان دوره مصوب</th><th>درصد حضور</th><th>نمره نهایی</th><th>وضعیت آیین‌نامه‌ای</th></tr></thead>
                <tbody>
                    <?php foreach ($records as $r): ?>
                        <tr>
                            <td><code><?= e($r['record_serial']) ?></code></td>
                            <td><strong><?= e($r['learner_name']) ?></strong></td>
                            <td><?= e($r['course_title']) ?></td>
                            <td><?= fa($r['attendance_pct']) ?>٪</td>
                            <td><strong><?= fa($r['weighted_total_score']) ?> / ۱۰۰</strong></td>
                            <td><?= e($r['academic_standing']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
