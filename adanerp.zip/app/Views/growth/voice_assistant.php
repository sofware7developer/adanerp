<?php use App\Core\Auth; ?>
<div class="hero-banner">
    <div>
        <span class="badge badge-gold">ماژول راهبردی ۴۰ | سیستم‌عامل صوتی فارسی سراسری (Global Persian Voice Action OS — Ctrl+Space)</span>
        <h1>مرکز فرماندهی صوتی سراسری، گزارش‌گیری سخنگو، ناوبری و اجرای خودکار دستورات</h1>
        <p>
            کنترل کامل تمام <strong>بخش‌های سامانه</strong> با فرمان صوتی فارسی (<code>Web Speech fa-IR + AI Whisper + پاسخ سخنگوی TTS</code>): انتقال فوری به ماژول‌ها، گزارش‌گیری زنده از ۹۵ جدول MariaDB، راهنمای گام‌به‌گام حساس به صفحه و اجرای واقعی فرایندها با صدا.
        </p>
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
        <button type="button" class="btn btn-gold" onclick="window.openVoiceCommanderModal(true)">شروع مکالمه و فرمان صوتی زنده</button>
        <button type="button" class="btn btn-outline" style="background:rgba(255,255,255,0.14);color:#fff;border-color:rgba(255,255,255,0.3)" onclick="window.startSystemGuidedTour()">اجرای تور تعاملی راهنمای سامانه</button>
    </div>
</div>

<!-- 4 VOICE OS KPI TILES -->
<div class="grid grid-4" style="margin-bottom:18px">
    <div class="stat-card">
        <div>
            <div class="stat-label">پوشش ناوبری صوتی فارسی</div>
            <div class="stat-value"><?= fa($stats['nav_routes']) ?> بخش و مسیر</div>
            <div class="stat-meta">تشخیص مرادف‌های محاوره‌ای و رسمی فارسی</div>
        </div>
        <div class="stat-icon icon-teal"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/></svg></div>
    </div>

    <div class="stat-card">
        <div>
            <div class="stat-label">کل دستورات صوتی ثبت‌شده</div>
            <div class="stat-value"><?= fa($stats['total_commands']) ?> فرمان</div>
            <div class="stat-meta">ثبت کامل ممیزی در voice_command_logs</div>
        </div>
        <div class="stat-icon icon-gold"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg></div>
    </div>

    <div class="stat-card">
        <div>
            <div class="stat-label">فرایندهای عملیاتی اجراشده با صدا</div>
            <div class="stat-value"><?= fa($stats['actions_run']) ?> عملیات زنده</div>
            <div class="stat-meta">زنجیره بخش‌های سامانهه، آزمون، اسکن وب و اکسل</div>
        </div>
        <div class="stat-icon icon-royal"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 11 12 14 22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg></div>
    </div>

    <div class="stat-card">
        <div>
            <div class="stat-label">گزارش‌های مدیریتی صوتی</div>
            <div class="stat-value"><?= fa($stats['reports_run']) ?> گزارش زنده</div>
            <div class="stat-meta">خوانش صوتی TTS + جدول شاخص‌های لحظه‌ای</div>
        </div>
        <div class="stat-icon icon-purple"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg></div>
    </div>
</div>

<!-- ══════════════════════════ ★ v26.8 — استودیوی گزارش‌ساز صوتی ══════════════════════════ -->
<div class="card" style="margin-bottom:18px;border:1.5px solid rgba(217,119,6,.38);background:linear-gradient(180deg,rgba(217,119,6,.055),transparent 42%)">
    <div class="card-header">
        <div class="card-title">🎙️ استودیوی گزارش‌ساز صوتی هوشمند — <?= fa($studioStats['kinds_available']) ?> گزارش آماده برای نقش «<?= e(Auth::roleLabel()) ?>»</div>
        <span class="badge badge-gold">روایت‌گر آفلاین • شاخص‌های زنده از MariaDB</span>
    </div>

    <div class="grid grid-4" style="margin-bottom:14px">
        <div class="stat-card"><div><div class="stat-label">گزارش‌های تولیدشده</div><div class="stat-value"><?= fa($studioStats['generated_total']) ?> گزارش</div><div class="stat-meta">بایگانی کامل با متن آماده خوانش</div></div><div class="stat-icon icon-gold">🗂️</div></div>
        <div class="stat-card"><div><div class="stat-label">تولید امروز</div><div class="stat-value"><?= fa($studioStats['generated_today']) ?> گزارش</div><div class="stat-meta">شامل گزارش‌های فرمان‌ صوتی و دستی</div></div><div class="stat-icon icon-teal">📈</div></div>
        <div class="stat-card"><div><div class="stat-label">مجموع زمان خوانش</div><div class="stat-value"><?= fa($studioStats['speech_minutes']) ?> دقیقه</div><div class="stat-meta">میانگین ۱۳ نویسه در ثانیه گفتار فارسی</div></div><div class="stat-icon icon-purple">⏱️</div></div>
        <div class="stat-card"><div><div class="stat-label">پرطرفدارترین گزارش</div><div class="stat-value" style="font-size:15px"><?= e(\App\Services\VoiceReportStudioService::titleOf((string)$studioStats['top_kind'])) ?></div><div class="stat-meta">انتخاب رایج کاربران این سامانه</div></div><div class="stat-icon icon-blue">🏆</div></div>
    </div>

    <?php foreach ($studioGroups as $groupName => $kinds): ?>
        <div style="margin-bottom:14px">
            <div style="font-weight:800;font-size:13px;margin:0 0 8px;padding-inline-start:4px;border-inline-start:3px solid var(--primary);padding-inline:8px 8px 0">📁 <?= e($groupName) ?> <span class="muted" style="font-weight:600;font-size:11.5px">(<?= fa(count($kinds)) ?> گزارش)</span></div>
            <div class="grid grid-3">
                <?php foreach ($kinds as $kindKey => $kd): ?>
                    <form method="post" action="<?= e(url('voice-assistant')) ?>" class="card" style="margin:0;display:flex;flex-direction:column;gap:8px">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="generate_voice_report">
                        <input type="hidden" name="kind" value="<?= e((string)$kindKey) ?>">
                        <div style="display:flex;align-items:center;gap:8px">
                            <span style="font-size:19px"><?= $kd['icon'] !== '' ? e($kd['icon']) : '🎙️' ?></span>
                            <strong style="font-size:13px;line-height:1.7"><?= e($kd['title']) ?></strong>
                        </div>
                        <div class="muted" style="font-size:11.8px;line-height:1.9"><?= e($kd['open']) ?></div>
                        <div style="display:flex;flex-wrap:wrap;gap:5px">
                            <?php foreach (array_slice($kd['metrics'], 0, 3) as $mm): ?>
                                <span style="font-size:10.8px;padding:2px 8px;border-radius:999px;background:var(--surface-2);border:1px solid var(--border)"><?= e($mm['label']) ?></span>
                            <?php endforeach; ?>
                            <span class="badge badge-info" style="font-size:10.5px"><?= fa(count($kd['metrics'])) ?> شاخص زنده</span>
                        </div>
                        <button type="submit" class="btn btn-gold btn-sm" style="margin-top:auto">🎙️ تولید، بایگانی و پخش صوتی</button>
                    </form>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endforeach; ?>

    <div class="muted" style="font-size:11.8px;line-height:1.95;border-top:1px dashed var(--border);padding-top:10px">
        🔒 هر کاربر تنها گزارش‌هایی را می‌بیند و تولید می‌کند که نقش سازمانی‌اش مجاز است؛ این فیلتر سمت سرور در
        <code>VoiceReportStudioService::generate()</code> هم اعمال می‌شود، پس ارسال مستقیم فرم، گزارش غیرمجاز نمی‌سازد.
        برای تولید با صدا کافی است بگویید: «گزارش <?= e((string)(reset($studioCatalog)['title'] ?? 'ضربان درآمد، هزینه و تراز دفتر کل')) ?>».
    </div>
</div>

<!-- INTERACTIVE CONSOLE ON PAGE -->
<div class="card" style="margin-bottom:18px;border:1.5px solid rgba(15,118,110,0.3)">
    <div class="card-header">
        <div class="card-title">کنسول زنده فرمان صوتی و متنی (اجرای بلادرنگ در کل سامانه — دکمه شناور پایین صفحه هم در تمام صفحات فعال است)</div>
        <span class="badge badge-success">کلید میانبر سراسری در تمام صفحات: Ctrl + Space</span>
    </div>

    <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-bottom:12px">
        <button type="button" class="btn btn-primary" onclick="window.toggleLiveSpeechRecognition('pageVoiceInp')">
            فعال‌سازی میکروفون فارسی (fa-IR)
        </button>
        <input type="text" id="pageVoiceInp" style="flex:1;min-width:260px" value="گزارش جامع مدیریتی کل سامانه رو بگو"
               placeholder="بگویید یا بنویسید: مثلاً «برو به رادار بازار»، «گزارش مالی بده»، «زنجیره خودکار هفت مرحله‌ای رو اجرا کن»...">
        <button type="button" class="btn btn-gold" onclick="window.runVoiceCommandText(document.getElementById('pageVoiceInp').value)">
            اجرای فوری فرمان و خوانش صوتی پاسخ
        </button>
    </div>

    <div id="pageVoiceOutputCard" style="display:none;margin-top:12px;padding:16px;border-radius:12px;background:var(--surface-2);border:1px solid var(--primary)"></div>
</div>

<!-- 4 PILLARS OF 1-CLICK & VOICE COMMANDS -->
<div class="grid grid-2" style="margin-bottom:18px">
    <div class="card">
        <div class="card-header"><div class="card-title">دستورات صوتی گزارش‌گیری مدیریتی و خروجی فوری</div></div>
        <div style="display:flex;flex-direction:column;gap:8px">
            <button type="button" class="btn btn-outline" style="justify-content:space-between;text-align:right" onclick="window.runVoiceCommandText('گزارش کامل مالی و وضعیت تراز حسابداری چهار سطحی رو بگو')">
                <span>«گزارش کامل مالی و وضعیت تراز حسابداری چهار سطحی رو بگو»</span><span class="badge badge-info">اجرا ◀</span>
            </button>
            <button type="button" class="btn btn-outline" style="justify-content:space-between;text-align:right" onclick="window.runVoiceCommandText('گزارش رادار بازار، رقبا و فرصت‌های اقیانوس آبی رو بده')">
                <span>«گزارش رادار بازار، رقبا و فرصت‌های اقیانوس آبی رو بده»</span><span class="badge badge-info">اجرا ◀</span>
            </button>
            <button type="button" class="btn btn-outline" style="justify-content:space-between;text-align:right" onclick="window.runVoiceCommandText('خلاصه وضعیت کلی سامانه و آمار اتاق رو بگو')">
                <span>«خلاصه وضعیت کلی سامانه و آمار اتاق رو بگو»</span><span class="badge badge-info">اجرا ◀</span>
            </button>
            <button type="button" class="btn btn-outline" style="justify-content:space-between;text-align:right" onclick="window.runVoiceCommandText('از جدول این صفحه خروجی اکسل بگیر')">
                <span>«از جدول این صفحه خروجی اکسل بگیر»</span><span class="badge badge-success">CSV ◀</span>
            </button>
        </div>
    </div>

    <div class="card">
        <div class="card-header"><div class="card-title">دستورات صوتی عملیاتی (تغییر واقعی در پایگاه‌داده)</div></div>
        <div style="display:flex;flex-direction:column;gap:8px">
            <button type="button" class="btn btn-outline" style="justify-content:space-between;text-align:right" onclick="window.runVoiceCommandText('زنجیره خودکار هفت مرحله‌ای کارت بازرگانی رو اجرا کن')">
                <span>«زنجیره خودکار هفت مرحله‌ای کارت بازرگانی رو اجرا کن»</span><span class="badge badge-gold">تراکنش بخش‌های سامانهه ◀</span>
            </button>
            <button type="button" class="btn btn-outline" style="justify-content:space-between;text-align:right" onclick="window.runVoiceCommandText('آزمون شخصیت شناسی MBTI رو اجرا کن و کارنامه بده')">
                <span>«آزمون شخصیت‌شناسی MBTI رو اجرا کن و کارنامه بده»</span><span class="badge badge-gold">کارنامه فوری ◀</span>
            </button>
            <button type="button" class="btn btn-outline" style="justify-content:space-between;text-align:right" onclick="window.runVoiceCommandText('تعیین سطح زبان انگلیسی کمبریج رو باز کن و نتیجه بده')">
                <span>«تعیین سطح زبان انگلیسی کمبریج رو باز کن و نتیجه بده»</span><span class="badge badge-gold">سطح CEFR ◀</span>
            </button>
            <button type="button" class="btn btn-outline" style="justify-content:space-between;text-align:right" onclick="window.runVoiceCommandText('پیشنهاد دوره جدید درباره صادرات هوشمند به اوراسیا بساز')">
                <span>«پیشنهاد دوره جدید درباره صادرات هوشمند به اوراسیا بساز»</span><span class="badge badge-gold">ساخت دوره R&amp;D ◀</span>
            </button>
        </div>
    </div>

    <div class="card">
        <div class="card-header"><div class="card-title">دستورات صوتی انتقال سریع بین بخش‌های سامانه سامانه</div></div>
        <div style="display:flex;flex-direction:column;gap:8px">
            <button type="button" class="btn btn-outline" style="justify-content:space-between;text-align:right" onclick="window.runVoiceCommandText('برو به رادار بازار و تحلیل رقبا')">
                <span>«برو به رادار بازار و تحلیل رقبا»</span><span class="badge badge-purple">ناوبری ◀</span>
            </button>
            <button type="button" class="btn btn-outline" style="justify-content:space-between;text-align:right" onclick="window.runVoiceCommandText('بخش آموزش الزامی کارت بازرگانی رو باز کن')">
                <span>«بخش آموزش الزامی کارت بازرگانی رو باز کن»</span><span class="badge badge-purple">ناوبری ◀</span>
            </button>
            <button type="button" class="btn btn-outline" style="justify-content:space-between;text-align:right" onclick="window.runVoiceCommandText('آکادمی تجارت بین الملل و ماشین حساب گمرک رو بیار')">
                <span>«آکادمی تجارت بین‌الملل و ماشین‌حساب گمرک رو بیار»</span><span class="badge badge-purple">ناوبری ◀</span>
            </button>
            <button type="button" class="btn btn-outline" style="justify-content:space-between;text-align:right" onclick="window.runVoiceCommandText('گزارش چاپی هیئت رئیسه رو باز کن')">
                <span>«گزارش چاپی هیئت‌رئیسه رو باز کن»</span><span class="badge badge-purple">چاپ A4 ◀</span>
            </button>
        </div>
    </div>

    <div class="card">
        <div class="card-header"><div class="card-title">راهنمای صوتی هوشمند، تور گام‌به‌گام و تنظیمات محیطی</div></div>
        <div style="display:flex;flex-direction:column;gap:8px">
            <button type="button" class="btn btn-outline" style="justify-content:space-between;text-align:right" onclick="window.runVoiceCommandText('راهنمای این بخش رو بگو و چیکار می‌تونم بکنم')">
                <span>«راهنمای این بخش رو بگو و چیکار می‌تونم بکنم؟»</span><span class="badge badge-success">راهنمای سخنگو ◀</span>
            </button>
            <button type="button" class="btn btn-outline" style="justify-content:space-between;text-align:right" onclick="window.startSystemGuidedTour()">
                <span>«تور سیستم و آموزش تصویری گام‌به‌گام سامانه رو شروع کن»</span><span class="badge badge-success">تور ۵ مرحله‌ای ◀</span>
            </button>
            <button type="button" class="btn btn-outline" style="justify-content:space-between;text-align:right" onclick="window.runVoiceCommandText('حالت شب و پوسته سامانه رو تغییر بده')">
                <span>«حالت شب و پوسته سامانه رو تغییر بده»</span><span class="badge badge-info">تغییر تم ◀</span>
            </button>
            <button type="button" class="btn btn-outline" style="justify-content:space-between;text-align:right" onclick="window.runVoiceCommandText('اسکن اینترنت برای هوش مصنوعی در گمرک و صادرات')">
                <span>«اسکن اینترنت برای هوش مصنوعی در گمرک و صادرات»</span><span class="badge badge-gold">کاوش وب ◀</span>
            </button>
        </div>
    </div>
</div>

<!-- ══════════════════════════ ★ v26.8 — بایگانی گزارش‌های صوتی و پذیرش قابلیت‌های فراگیر ══════════════════════════ -->
<div class="grid grid-2" style="margin-bottom:18px;align-items:start">
    <div class="card" style="margin:0">
        <div class="card-header">
            <div class="card-title">🗂️ بایگانی گزارش‌های صوتی (فقط گزارش‌های مجاز نقش شما)</div>
            <span class="badge badge-success"><?= fa(count($studioArchive)) ?> ردیف</span>
        </div>
        <div class="table-wrap">
            <table>
                <thead><tr><th>کد گزارش</th><th>عنوان</th><th>مخاطب</th><th>تاریخ</th><th>زمان خوانش</th><th>عملیات</th></tr></thead>
                <tbody>
                <?php foreach ($studioArchive as $ar): ?>
                    <tr data-code="<?= e($ar['report_code']) ?>" data-speech-id="vra-<?= (int)$ar['id'] ?>">
                        <td><code style="font-size:11px"><?= e($ar['report_code']) ?></code></td>
                        <td><strong><?= e($ar['report_title']) ?></strong></td>
                        <td><span class="badge badge-info"><?= e(Auth::roleLabel((string)$ar['audience_role'])) ?></span></td>
                        <td class="muted"><?= e($ar['created_shamsi']) ?></td>
                        <td><?= fa((int)ceil(((int)$ar['est_duration_sec']) / 15)) ?> ثانیه <span class="muted" style="font-size:11px">(<?= fa($ar['speech_chars']) ?> نویسه)</span></td>
                        <td style="white-space:nowrap">
                            <button type="button" class="btn btn-primary btn-sm" onclick="var t=document.getElementById('vra-<?= (int)$ar['id'] ?>');if(t&&window.speakPersianReply)window.speakPersianReply(t.textContent)">▶ پخش</button>
                            <a class="btn btn-outline btn-sm" href="<?= e(url('voice-assistant', ['action' => 'download_report', 'id' => (int)$ar['id']])) ?>">⬇ متن</a>
                        </td>
                    </tr>
                    <tr><td colspan="6" style="padding:0;border:0"><pre id="vra-<?= (int)$ar['id'] ?>" style="display:none;white-space:pre-wrap"><?= e($ar['narrative_text']) ?></pre></td></tr>
                <?php endforeach; ?>
                <?php if ($studioArchive === []): ?>
                    <tr><td colspan="6" class="muted">هنوز گزارشی تولید نکرده‌اید — از کارت‌های استودیو بالا، «تولید، بایگانی و پخش صوتی» را بزنید.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card" style="margin:0;border:1.5px solid rgba(15,118,110,.32)">
        <div class="card-header">
            <div class="card-title">🤝 پذیرش قابلیت‌های هوشمند در فضای فراگیر</div>
            <span class="badge badge-gold">میزان استفاده واقعی فراگیران از دستیار هوشمند</span>
        </div>
        <div class="grid grid-3" style="margin-bottom:12px">
            <div class="stat-card" style="padding:12px"><div><div class="stat-label">رویدادهای هوشمند</div><div class="stat-value"><?= fa($adoption['total_events']) ?></div></div></div>
            <div class="stat-card" style="padding:12px"><div><div class="stat-label">فراگیران فعال</div><div class="stat-value"><?= fa($adoption['active_learners']) ?></div></div></div>
            <div class="stat-card" style="padding:12px"><div><div class="stat-label">کارت شخصی AI</div><div class="stat-value"><?= fa($adoption['personal_cards']) ?></div></div></div>
        </div>
        <?php $maxUses = 1; foreach ($adoption['items'] as $it) { $maxUses = max($maxUses, (int)$it['uses']); } ?>
        <?php foreach ($adoption['items'] as $it): ?>
            <div style="margin-bottom:9px">
                <div style="display:flex;justify-content:space-between;font-size:12.2px;margin-bottom:3px">
                    <span><?= e($it['label']) ?></span>
                    <strong><?= fa($it['uses']) ?> بار • <?= fa($it['learners']) ?> فراگیر</strong>
                </div>
                <div style="height:8px;border-radius:999px;background:var(--surface-2);overflow:hidden">
                    <div style="height:100%;width:<?= (int)round(100 * (int)$it['uses'] / $maxUses) ?>%;background:linear-gradient(90deg,#0f766e,#f59e0b)"></div>
                </div>
            </div>
        <?php endforeach; ?>
        <?php if ($adoption['items'] === []): ?>
            <p class="muted" style="font-size:12.5px">هنوز رویدادی از قابلیت‌های هوشمند فضای فراگیر ثبت نشده است؛ با نخستین «بریفینگ صوتی» یا «کارت‌سازی از یادداشت‌ها» این نمودار پر می‌شود.</p>
        <?php endif; ?>
        <div class="muted" style="font-size:11.6px;line-height:1.95;border-top:1px dashed var(--border);padding-top:9px;margin-top:6px">
            💡 این کارت نشان می‌دهد فراگیران از کدام قابلیت هوشمند بیشتر استفاده می‌کنند تا بودجه محتوایی و اطلاع‌رسانی به همان‌جا معطوف شود. برای گزارش رسمی بگویید: «گزارش نرخ پذیرش قابلیت‌های هوشمند در فضای فراگیر».
        </div>
    </div>
</div>

<!-- AUDIT LOG OF EXECUTED VOICE COMMANDS -->
<div class="card">
    <div class="card-header"><div class="card-title">تاریخچه و لاگ ممیزی فرامین صوتی اجراشده در سامانه (جدول voice_command_logs)</div></div>
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>تاریخ</th>
                    <th>کاربر فرمان‌دهنده</th>
                    <th>متن فرمان صوتی دریافت‌شده</th>
                    <th>نوع نیت تشخیص‌داده‌شده</th>
                    <th>مقصد / عملیات انجام‌شده</th>
                    <th>پاسخ صوتی سامانه</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($logs as $lg): ?>
                <tr>
                    <td><?= e($lg['created_shamsi']) ?></td>
                    <td><strong><?= e($lg['full_name'] ?? 'مدیر سامانه') ?></strong></td>
                    <td>«<?= e($lg['spoken_text']) ?>»</td>
                    <td><span class="badge badge-info"><?= e($lg['detected_intent']) ?></span></td>
                    <td><strong><?= e($lg['action_summary']) ?></strong></td>
                    <td class="muted" style="font-size:12px"><?= e(mb_substr((string)$lg['spoken_response'], 0, 120, 'UTF-8')) ?>...</td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php if (($playedCode ?? '') !== ''): ?>
<script>
(function () {
    function tryPlay() {
        var row = document.querySelector('[data-code="<?= e($playedCode) ?>"]');
        if (!row) { return false; }
        var id = row.getAttribute('data-speech-id');
        var txt = id ? document.getElementById(id) : null;
        if (txt && window.speakPersianReply) {
            if (row.scrollIntoView) { row.scrollIntoView({ block: 'center' }); }
            window.speakPersianReply(txt.textContent);
            return true;
        }
        return false;
    }
    if (!tryPlay()) { setTimeout(tryPlay, 900); setTimeout(tryPlay, 2200); }
})();
</script>
<?php endif; ?>
