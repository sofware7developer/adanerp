<?php
use App\Services\EnterpriseSettingsIamService;
$activeTheme = $bundle['active_theme'];
$groupTitles = [
    'academic'        => '🎓 قوانین آموزشی، حدنصاب حضور، نمره قبولی و صدور گواهی QR',
    'finance'         => '💳 تنظیمات مالی، ارزش افزوده قانونی، کسور ماده ۸۶ و درگاه پرداخت',
    'ai_integrations' => '🤖 درگاه هوش مصنوعی AI، سپر حریم خصوصی PII و پیام‌رسان‌های بومی',
    'security'        => '🔐 سیاست‌های امنیتی نشست، رمز عبور، Brute-Force و حکمرانی',
];
?>
<div class="hero-banner" style="background:linear-gradient(135deg, var(--navy-900) 0%, var(--primary) 100%)">
    <div>
        <span class="badge badge-gold" style="margin-bottom:8px">استودیو زنده تم، تایپوگرافی، برندینگ سازمان (White-Label) و پیکربندی هسته ERP</span>
        <h1>مرکز جامع تنظیمات تم، فونت و پیکربندی سراسری نرم‌افزار ERP</h1>
        <p>هرگونه تغییر در پالت رنگی، حالت شب، خانواده و اندازه فونت فارسی، گردی کارت‌ها، تراکم جداول، عنوان سازمان و قوانین آموزشی/مالی مستقیماً در MariaDB ذخیره و در <strong>تمامی بخش‌های سامانه سامانه</strong> اعمال می‌گردد.</p>
    </div>
    <div class="hero-actions">
        <a class="btn btn-gold" href="<?= e(url('system-settings', ['export_json' => 1])) ?>">📥 دانلود فایل پشتیبان تنظیمات (JSON)</a>
        <a class="btn btn-outline" style="background:rgba(255,255,255,0.14);color:#fff;border-color:rgba(255,255,255,0.3)" href="<?= e(url('iam-access')) ?>">🔐 مدیریت کاربران و سطوح دسترسی ←</a>
    </div>
</div>

<!-- نوار ناوبری ۴ تب تنظیمات -->
<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:18px">
    <button type="button" class="btn <?= $activeTab === 'theme' ? 'btn-gold' : 'btn-outline' ?> btn-sm cfg-tab-btn" onclick="switchCfgTab('theme', this)">🎨 ۱. پالت‌های رنگی و پوسته‌های آماده (۶ تم)</button>
    <button type="button" class="btn <?= $activeTab === 'font' ? 'btn-gold' : 'btn-outline' ?> btn-sm cfg-tab-btn" onclick="switchCfgTab('font', this)">🔤 ۲. استودیو فونت، سایز قلم، تراکم و رنگ سفارشی</button>
    <button type="button" class="btn <?= $activeTab === 'software' ? 'btn-gold' : 'btn-outline' ?> btn-sm cfg-tab-btn" onclick="switchCfgTab('software', this)">⚙️ ۳. تنظیمات جامع نرم‌افزار (آموزشی، مالی، AI و امنیت)</button>
    <button type="button" class="btn <?= $activeTab === 'health' ? 'btn-gold' : 'btn-outline' ?> btn-sm cfg-tab-btn" onclick="switchCfgTab('health', this)">🩺 ۴. وضعیت محیط سرور، کش و سلامت ERP</button>
</div>

<!-- تب ۱: گالری پوسته‌های سازمانی ۱-کلیکی -->
<div id="cfgPanel_theme" class="cfg-panel" style="display:<?= $activeTab === 'theme' ? 'block' : 'none' ?>">
    <div class="grid grid-3">
        <?php foreach ($bundle['theme_presets'] as $tp): ?>
            <?php $isCurrent = ((int)$tp['is_active'] === 1); ?>
            <div class="card" style="border:2px solid <?= $isCurrent ? 'var(--gold)' : 'var(--border)' ?>;position:relative">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
                    <div style="display:flex;gap:6px;align-items:center">
                        <span style="width:24px;height:24px;border-radius:50%;background:<?= e($tp['sidebar_bg_hex']) ?>;display:inline-block;border:2px solid #fff;box-shadow:0 0 0 1px #cbd5e1"></span>
                        <span style="width:24px;height:24px;border-radius:50%;background:<?= e($tp['primary_hex']) ?>;display:inline-block;border:2px solid #fff;box-shadow:0 0 0 1px #cbd5e1"></span>
                        <span style="width:24px;height:24px;border-radius:50%;background:<?= e($tp['gold_accent_hex']) ?>;display:inline-block;border:2px solid #fff;box-shadow:0 0 0 1px #cbd5e1"></span>
                    </div>
                    <?php if ($isCurrent): ?>
                        <span class="badge badge-success">✓ پوسته فعال فعلی</span>
                    <?php else: ?>
                        <span class="badge badge-info"><?= $tp['color_mode'] === 'dark' ? '🌙 تیره' : '☀️ روشن' ?></span>
                    <?php endif; ?>
                </div>
                <h3 style="font-size:15px;margin-bottom:6px"><?= e($tp['theme_title']) ?></h3>
                <p class="muted" style="font-size:12px;margin-bottom:12px">
                    قلم: <strong><?= e($tp['font_family_key']) ?></strong> | سایز پایه: <strong><?= fa($tp['base_font_px']) ?>px</strong> | تراکم: <strong><?= e($tp['ui_density']) ?></strong> | گردی: <strong><?= fa($tp['border_radius_px']) ?>px</strong>
                </p>
                <div style="display:flex;gap:8px">
                    <button type="button" class="btn btn-outline btn-sm"
                            onclick="previewPresetClient('<?= e($tp['primary_hex']) ?>','<?= e($tp['gold_accent_hex']) ?>','<?= e($tp['sidebar_bg_hex']) ?>','<?= e($tp['color_mode']) ?>',<?= (int)$tp['base_font_px'] ?>,<?= (int)$tp['border_radius_px'] ?>)">👁️ پیش‌نمایش آنی</button>
                    <form method="post" style="margin:0;flex:1">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="activate_preset">
                        <input type="hidden" name="activate_preset_id" value="<?= (int)$tp['id'] ?>">
                        <button type="submit" class="btn btn-primary btn-sm" style="width:100%">اعمال سراسری این تم</button>
                    </form>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- تب ۲: استودیو سفارشی‌سازی کامل فونت، سایز، رنگ اختصاصی و برندینگ سازمان -->
<div id="cfgPanel_font" class="cfg-panel" style="display:<?= $activeTab === 'font' ? 'block' : 'none' ?>">
    <div class="grid grid-2">
        <div class="card">
            <div class="card-header">
                <div class="card-title">🔤 استودیو سفارشی فونت فارسی، اندازه قلم، رنگ‌های برند و عنوان سازمان</div>
                <span class="badge badge-gold">ذخیره پایدار در دیتابیس</span>
            </div>
            <form method="post" id="customThemeForm">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="save_custom_theme">
                <div class="grid grid-3">
                    <div class="form-group">
                        <label>رنگ اصلی برند (Primary):</label>
                        <input type="color" name="primary_hex" id="inpPrimaryHex" value="<?= e($activeTheme['primary_hex']) ?>" onchange="liveSyncFormPreview()" style="height:42px;padding:3px">
                    </div>
                    <div class="form-group">
                        <label>رنگ طلایی / تأکیدی (Accent):</label>
                        <input type="color" name="gold_accent_hex" id="inpGoldHex" value="<?= e($activeTheme['gold_accent_hex']) ?>" onchange="liveSyncFormPreview()" style="height:42px;padding:3px">
                    </div>
                    <div class="form-group">
                        <label>رنگ منوی کناری (Sidebar):</label>
                        <input type="color" name="sidebar_bg_hex" id="inpSidebarHex" value="<?= e($activeTheme['sidebar_bg_hex']) ?>" onchange="liveSyncFormPreview()" style="height:42px;padding:3px">
                    </div>
                </div>

                <div class="grid grid-2">
                    <div class="form-group">
                        <label>خانواده فونت سراسری نرم‌افزار:</label>
                        <select name="font_family_key" id="inpFontFamily" onchange="liveSyncFormPreview()">
                            <?php foreach (EnterpriseSettingsIamService::FONT_STACKS as $fk => $fCss): ?>
                                <option value="<?= e($fk) ?>" data-stack="<?= e($fCss) ?>" <?= $activeTheme['font_family_key'] === $fk ? 'selected' : '' ?>>
                                    <?= e(EnterpriseSettingsIamService::FONT_LABELS[$fk] ?? $fk) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>اندازه فونت پایه کل صفحات:</label>
                        <select name="base_font_px" id="inpFontPx" onchange="liveSyncFormPreview()">
                            <?php foreach ([13 => '۱۳ پیکسل (فشرده مدیریتی)', 14 => '۱۴ پیکسل (استاندارد پیش‌فرض)', 15 => '۱۵ پیکسل (خوانایی بالا)', 16 => '۱۶ پیکسل (درشت کنفرانسی)'] as $px => $lbl): ?>
                                <option value="<?= $px ?>" <?= (int)$activeTheme['base_font_px'] === $px ? 'selected' : '' ?>><?= e($lbl) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div class="grid grid-3">
                    <div class="form-group">
                        <label>فاصله خطوط متن (Line-Height):</label>
                        <select name="line_height_val" id="inpLineHeight" onchange="liveSyncFormPreview()">
                            <?php foreach (['1.65' => '۱.۶۵ (فشرده)', '1.75' => '۱.۷۵ (متعادل)', '1.85' => '۱.۸۵ (باز و خوانا)', '1.95' => '۱.۹۵ (خیلی باز)'] as $lhk => $lhv): ?>
                                <option value="<?= $lhk ?>" <?= (string)$activeTheme['line_height_val'] === $lhk ? 'selected' : '' ?>><?= e($lhv) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>تراکم جداول و فرم‌ها:</label>
                        <select name="ui_density">
                            <option value="compact" <?= $activeTheme['ui_density'] === 'compact' ? 'selected' : '' ?>>فشرده پرتراکم (Compact)</option>
                            <option value="comfortable" <?= $activeTheme['ui_density'] === 'comfortable' ? 'selected' : '' ?>>استاندارد متعادل (Comfortable)</option>
                            <option value="spacious" <?= $activeTheme['ui_density'] === 'spacious' ? 'selected' : '' ?>>فراخ مدیریتی (Spacious)</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>شعاع گردی کارت‌ها (px):</label>
                        <input type="number" name="border_radius_px" id="inpRadiusPx" min="4" max="26" value="<?= (int)$activeTheme['border_radius_px'] ?>" onchange="liveSyncFormPreview()">
                    </div>
                </div>

                <div class="grid grid-2">
                    <div class="form-group">
                        <label>حالت روشنایی پیش‌فرض:</label>
                        <select name="color_mode" id="inpColorMode" onchange="liveSyncFormPreview()">
                            <option value="light" <?= $activeTheme['color_mode'] === 'light' ? 'selected' : '' ?>>☀️ حالت روشن اداری (Light Mode)</option>
                            <option value="dark" <?= $activeTheme['color_mode'] === 'dark' ? 'selected' : '' ?>>🌙 حالت شب مدیریتی (Dark Mode)</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>نشان لوگو در سایدبار (حداکثر ۸ کاراکتر):</label>
                        <input type="text" name="brand_monogram" value="<?= e($activeTheme['brand_monogram']) ?>" required>
                    </div>
                </div>

                <div class="form-group">
                    <label>عنوان رسمی سازمان در هدر، سایدبار و سربرگ‌های چاپی (White-Label):</label>
                    <input type="text" name="brand_org_title" value="<?= e($activeTheme['brand_org_title']) ?>" required>
                </div>
                <div class="form-group">
                    <label>زیرعنوان واحد آموزش / آکادمی سازمانی:</label>
                    <input type="text" name="brand_unit_subtitle" value="<?= e($activeTheme['brand_unit_subtitle']) ?>" required>
                </div>

                <button type="submit" class="btn btn-gold">💾 ذخیره و اعمال سراسری فونت، تم و برندینگ در کل ERP</button>
            </form>
        </div>

        <div class="card" id="typographyLiveSandbox">
            <div class="card-header">
                <div class="card-title">👁️ بوم پیش‌نمایش زنده تایپوگرافی فارسی، ارقام مالی و اجزای رابط کاربری</div>
                <span class="badge badge-info">واکنش آنی بدون رفرش</span>
            </div>
            <p style="margin-bottom:12px">
                <strong>متن نمونه فارسی و دوزبانه:</strong> مرکز آموزش مؤسسه آموزشی آدان در نیمسال پاییز ۱۴۰۵ بیش از ۴۸ دوره تخصصی در حوزه <code>Incoterms 2020</code>، <code>UCP 600</code>، سامانه مؤدیان و هوش مصنوعی صادراتی با دقت تراز حسابداری <strong>۰ ریال مغایرت</strong> برگزار نموده است.
            </p>
            <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:14px">
                <span class="btn btn-primary btn-sm">دکمه اصلی برند</span>
                <span class="btn btn-gold btn-sm">دکمه طلایی تأکیدی</span>
                <span class="badge badge-success">تأیید نهایی نمره ۹۶ از ۱۰۰</span>
                <span class="badge badge-warning">شهریه: ۱۰۹,۰۰۰,۰۰۰ ریال</span>
            </div>
            <div class="table-wrap">
                <table>
                    <thead><tr><th>کد دوره</th><th>عنوان استاندارد</th><th>حدنصاب حضور</th><th>شهریه مصوب</th></tr></thead>
                    <tbody>
                        <tr><td><code>TRD-401</code></td><td>جامع تجارت بین‌الملل و اعتبار اسنادی</td><td><?= fa(80) ?>٪</td><td><?= rial(109000000) ?></td></tr>
                        <tr><td><code>TAX-205</code></td><td>سامانه مؤدیان و استرداد ارزش افزوده صادرات</td><td><?= fa(80) ?>٪</td><td><?= rial(69000000) ?></td></tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- تب ۳: تنظیمات جامع نرم‌افزار در ۴ گروه استاندارد ERP -->
<div id="cfgPanel_software" class="cfg-panel" style="display:<?= $activeTab === 'software' ? 'block' : 'none' ?>">
    <form method="post">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="save_software_settings">
        <div class="grid grid-2">
            <?php foreach ($groupTitles as $grpKey => $grpLabel): ?>
                <div class="card">
                    <div class="card-header">
                        <div class="card-title"><?= e($grpLabel) ?></div>
                    </div>
                    <?php foreach (($bundle['settings_groups'][$grpKey] ?? []) as $sRow): ?>
                        <div class="form-group">
                            <label><?= e($sRow['setting_label']) ?> <small class="muted">(<code><?= e($sRow['setting_key']) ?></code>)</small>:</label>
                            <input type="<?= $sRow['input_type'] === 'number' ? 'number' : 'text' ?>"
                                   name="cfg[<?= e($sRow['setting_key']) ?>]"
                                   value="<?= e($sRow['setting_value']) ?>" required>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endforeach; ?>
        </div>
        <div style="margin-top:14px;display:flex;justify-content:flex-end">
            <button type="submit" class="btn btn-primary">💾 ذخیره یکپارچه تمام تنظیمات نرم‌افزار در پایگاه‌داده</button>
        </div>
    </form>
</div>

<!-- تب ۴: وضعیت فنی و محیط اجرای سرور -->
<div id="cfgPanel_health" class="cfg-panel" style="display:<?= $activeTab === 'health' ? 'block' : 'none' ?>">
    <div class="grid grid-4">
        <div class="card"><div class="muted">نسخه مفسر PHP</div><h2 style="margin-top:6px;color:var(--primary)"><?= e(PHP_VERSION) ?></h2><div class="muted" style="font-size:12px">معماری MVC خالص بدون فریم‌ورک سنگین</div></div>
        <div class="card"><div class="muted">تعداد جداول فعال MariaDB</div><h2 style="margin-top:6px;color:var(--gold)"><?= fa(count(\App\Core\Database::fetchAll('SHOW TABLES'))) ?> جدول</h2><div class="muted" style="font-size:12px">کدگذاری کامل utf8mb4_unicode_ci</div></div>
        <div class="card"><div class="muted">بخش‌های تخصصی سامانه</div><h2 style="margin-top:6px;color:var(--primary)">پوشش یکپارچه</h2><div class="muted" style="font-size:12px">در ساختار یکپارچه سازمانی</div></div>
        <div class="card"><div class="muted">منطقه زمانی و موتور تاریخ</div><h2 style="margin-top:6px;color:var(--gold)"><?= e(date_default_timezone_get()) ?></h2><div class="muted" style="font-size:12px">تقویم شمسی دقیق بومی</div></div>
    </div>
</div>

<script>
function switchCfgTab(tab, btn) {
    document.querySelectorAll('.cfg-panel').forEach(p => p.style.display = 'none');
    document.getElementById('cfgPanel_' + tab).style.display = 'block';
    document.querySelectorAll('.cfg-tab-btn').forEach(b => { b.classList.remove('btn-gold'); b.classList.add('btn-outline'); });
    btn.classList.remove('btn-outline'); btn.classList.add('btn-gold');
}
function previewPresetClient(primary, gold, sidebar, mode, fontPx, radius, fontStack) {
    document.documentElement.style.setProperty('--primary', primary);
    document.documentElement.style.setProperty('--primary-hover', primary);
    document.documentElement.style.setProperty('--gold', gold);
    document.documentElement.style.setProperty('--navy-900', sidebar);
    document.documentElement.style.setProperty('--navy-950', sidebar);
    document.documentElement.style.setProperty('--radius', radius + 'px');
    document.documentElement.style.fontSize = fontPx + 'px';
    document.body.style.fontSize = fontPx + 'px';
    if (fontStack) {
        document.documentElement.style.setProperty('--erp-font-stack', fontStack);
    }
    document.documentElement.setAttribute('data-theme', mode === 'dark' ? 'dark' : 'light');
    try { localStorage.setItem('chamber_theme', mode === 'dark' ? 'dark' : 'light'); } catch (e) {}
}
function liveSyncFormPreview() {
    var sel = document.getElementById('inpFontFamily');
    var stack = sel && sel.options[sel.selectedIndex] ? sel.options[sel.selectedIndex].getAttribute('data-stack') : '';
    previewPresetClient(
        document.getElementById('inpPrimaryHex').value,
        document.getElementById('inpGoldHex').value,
        document.getElementById('inpSidebarHex').value,
        document.getElementById('inpColorMode').value,
        parseInt(document.getElementById('inpFontPx').value || '14', 10),
        parseInt(document.getElementById('inpRadiusPx').value || '16', 10),
        stack
    );
    document.body.style.lineHeight = document.getElementById('inpLineHeight').value;
}
</script>
