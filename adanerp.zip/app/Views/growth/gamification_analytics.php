<div class="hero-banner">
    <div>
        <span class="badge badge-gold">ماژول راهبردی ۴۴ | تحلیل رفتار یادگیری (xAPI / LBA) + موتور گیمیفیکیشن سراسری کل سامانه</span>
        <h1>رصدخانه هوشمند رفتار فراگیران، پیش‌بینی ترک دوره و گیمیفیکیشن سازمانی</h1>
        <p>ردیابی ریزدانه تمرکز، بازپخش ویدئو، ساعات اوج مطالعه و گلوگاه‌های آموزشی در تمامی بخش‌های سامانه همراه با کیف پول XP، سکه مهارتی، لیگ بین‌شرکتی صنایع، مأموریت‌ها و فروشگاه مشوق‌های واقعی مؤسسه آموزشی آدان.</p>
    </div>
    <div style="background:rgba(255,255,255,0.12);border:1px solid rgba(251,191,36,0.45);border-radius:14px;padding:14px 18px;min-width:265px">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
            <span class="badge badge-gold">سطح <?= fa($hud['level_num']) ?> — <?= e($hud['rank_title']) ?></span>
            <span style="font-weight:800;color:#fde68a">🔥 <?= fa($hud['streak_days']) ?> روز</span>
        </div>
        <div style="font-size:20px;font-weight:900;color:#fff;margin-bottom:6px">
            <?= fa(number_format($hud['xp_points'])) ?> XP <span style="font-size:13px;color:#fde68a">| 🪙 <?= fa(number_format($hud['chamber_coins'])) ?> سکه مهارت</span>
        </div>
        <div style="height:8px;border-radius:99px;background:rgba(255,255,255,0.22);overflow:hidden">
            <div style="height:100%;width:<?= (int)$hud['level_progress_pct'] ?>%;background:linear-gradient(90deg,#fbbf24,#34d399)"></div>
        </div>
        <div style="font-size:11px;color:rgba(255,255,255,0.85);margin-top:5px">پیشرفت تا سطح بعدی: <?= fa($hud['level_progress_pct']) ?>٪ (هدف: <?= fa(number_format($hud['next_level_xp'])) ?> XP)</div>
    </div>
</div>

<!-- KPI ROW -->
<div class="grid grid-4" style="margin-bottom:18px">
    <div class="stat-card">
        <div>
            <div class="stat-label">میانگین شاخص تمرکز فعال (Focus Index)</div>
            <div class="stat-value" style="color:var(--primary)"><?= fa($summary['avg_focus_pct']) ?>٪</div>
            <div class="muted" style="font-size:11.5px">سنجش از روی زمان ماندگاری و تعامل واقعی</div>
        </div>
    </div>
    <div class="stat-card">
        <div>
            <div class="stat-label">مجموع امتیاز تجربه زیست‌بوم (Total XP)</div>
            <div class="stat-value" style="color:#b45309"><?= fa(number_format($summary['total_ecosystem_xp'])) ?></div>
            <div class="muted" style="font-size:11.5px">در کل دوره‌ها، شبیه‌سازها و آزمون‌ها</div>
        </div>
    </div>
    <div class="stat-card">
        <div>
            <div class="stat-label">میانگین پیوستگی مطالعه (Daily Streak)</div>
            <div class="stat-value" style="color:#047857"><?= fa((string)$summary['avg_streak_days']) ?> روز</div>
            <div class="muted" style="font-size:11.5px">+۴۳٪ نرخ تکمیل دوره بالاتر در فراگیران مستمر</div>
        </div>
    </div>
    <div class="stat-card">
        <div>
            <div class="stat-label">فراگیران نیازمند مداخله فوری (At-Risk)</div>
            <div class="stat-value" style="color:#dc2626"><?= fa($summary['at_risk_count']) ?> نفر</div>
            <div class="muted" style="font-size:11.5px">شناسایی‌شده پیش از رهاسازی دوره</div>
        </div>
    </div>
</div>

<!-- VISUAL CHARTS ROW: FUNNEL + HOURLY RHYTHM -->
<div class="grid grid-2" style="margin-bottom:18px">
    <div class="card">
        <div class="card-header">
            <div class="card-title">📊 قیف رفتاری تبدیل یادگیری به مهارت عملیاتی (Behavioral Learning Funnel)</div>
            <span class="badge badge-info">تحلیل کوهورت ۱۴۰۵</span>
        </div>
        <svg viewBox="0 0 520 205" style="width:100%;height:auto">
            <?php
            $stages = [
                ['label' => 'ثبت‌نام و ورود اولیه به درس (LMS Login)', 'pct' => 100, 'w' => 484, 'c' => '#0f766e'],
                ['label' => 'عبور از نیمه محتوای ویدئویی و جزوات تعاملی', 'pct' => 86, 'w' => 452, 'c' => '#0d9488'],
                ['label' => 'مشارکت در شبیه‌سازها و آزمایشگاه اسناد صادراتی', 'pct' => 78, 'w' => 424, 'c' => '#14b8a6'],
                ['label' => 'قبولی در آزمون تطبیقی و اخذ گواهی QR', 'pct' => 74, 'w' => 398, 'c' => '#c99227'],
                ['label' => 'کاربست واقعی در پرونده کارت بازرگانی و صادرات', 'pct' => 64, 'w' => 372, 'c' => '#b45309'],
            ];
            foreach ($stages as $idx => $st):
                $y = 10 + ($idx * 38);
                $x = (520 - $st['w']) / 2;
            ?>
                <rect x="<?= $x ?>" y="<?= $y ?>" width="<?= $st['w'] ?>" height="29" rx="8" fill="<?= $st['c'] ?>" opacity="0.92"/>
                <text x="260" y="<?= $y + 19 ?>" text-anchor="middle" fill="#fff" font-size="12" font-weight="700" font-family="Tahoma,sans-serif">
                    <?= e($st['label']) ?> — <?= fa($st['pct']) ?>٪
                </text>
            <?php endforeach; ?>
        </svg>
    </div>

    <div class="card">
        <div class="card-header">
            <div class="card-title">⏰ ریتم ساعتی تمرکز و مطالعه مدیران و کارشناسان صنایع استان</div>
            <span class="badge badge-gold">اوج یادگیری: ۱۹ تا ۲۲ شب</span>
        </div>
        <svg viewBox="0 0 520 205" style="width:100%;height:auto">
            <line x1="40" y1="165" x2="495" y2="165" stroke="#cbd5e1" stroke-width="1.5"/>
            <?php
            $hours = [
                ['h' => '۰۸-۱۰', 'v' => 58],
                ['h' => '۱۰-۱۲', 'v' => 74],
                ['h' => '۱۲-۱۴', 'v' => 36],
                ['h' => '۱۴-۱۶', 'v' => 49],
                ['h' => '۱۶-۱۸', 'v' => 79],
                ['h' => '۱۸-۲۰', 'v' => 88],
                ['h' => '۲۰-۲۲', 'v' => 96],
                ['h' => '۲۲-۲۴', 'v' => 64],
            ];
            foreach ($hours as $i => $hr):
                $bx = 55 + ($i * 55);
                $bh = (int)round($hr['v'] * 1.35);
                $by = 165 - $bh;
                $fill = $hr['v'] >= 85 ? '#c99227' : '#0f766e';
            ?>
                <rect x="<?= $bx ?>" y="<?= $by ?>" width="34" height="<?= $bh ?>" rx="6" fill="<?= $fill ?>"/>
                <text x="<?= $bx + 17 ?>" y="<?= $by - 5 ?>" text-anchor="middle" fill="#0f172a" font-size="11" font-weight="700"><?= fa($hr['v']) ?>٪</text>
                <text x="<?= $bx + 17 ?>" y="185" text-anchor="middle" fill="#64748b" font-size="11"><?= e($hr['h']) ?></text>
            <?php endforeach; ?>
        </svg>
    </div>
</div>

<!-- EARLY WARNING AI DROPOUT RADAR -->
<div class="card" style="margin-bottom:18px;border:1.5px solid rgba(220,38,38,0.28)">
    <div class="card-header">
        <div>
            <div class="card-title">🚨 رادار هشدار زودهنگام افت انگیزه و ترک دوره (AI Early-Warning Drop-Off Predictor)</div>
            <div class="muted" style="font-size:12px">تشخیص خودکار فراگیران در معرض رهاسازی دوره بر اساس وقفه ورود، افت عمق اسکرول و توقف روی ویدئو + مداخله انگیزشی ۱-کلیکی</div>
        </div>
        <span class="badge badge-danger">پیشگیری فعال از ریزش</span>
    </div>
    <div class="table-wrap">
        <table>
            <thead><tr><th>فراگیر</th><th>سازمان عضو</th><th>دوره در حال گذراندن</th><th>تیپ رفتاری یادگیری (Persona)</th><th>شاخص درگیری</th><th>احتمال ترک دوره</th><th>وضعیت و اقدام هوشمند</th><th>مداخله</th></tr></thead>
            <tbody>
            <?php foreach ($predictions as $pr): ?>
                <tr>
                    <td><strong><?= e($pr['learner_name']) ?></strong></td>
                    <td><?= e($pr['org_name']) ?></td>
                    <td style="font-size:12px"><?= e($pr['enrolled_course']) ?></td>
                    <td><span class="badge badge-info"><?= e($pr['learning_persona']) ?></span></td>
                    <td><strong><?= fa($pr['engagement_score']) ?>٪</strong></td>
                    <td>
                        <span class="badge <?= (int)$pr['dropout_risk_pct'] >= 60 ? 'badge-danger' : 'badge-success' ?>">
                            <?= fa($pr['dropout_risk_pct']) ?>٪ ریسک
                        </span>
                    </td>
                    <td style="font-size:11.5px;max-width:290px"><?= e($pr['ai_intervention_status']) ?></td>
                    <td>
                        <form method="post" action="<?= e(url('gamification-analytics')) ?>">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="nudge_learner">
                            <input type="hidden" name="prediction_id" value="<?= (int)$pr['id'] ?>">
                            <button type="submit" class="btn btn-gold btn-sm">ارسال مشوق بازگشت</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- GAMIFICATION QUESTS + REWARD STORE -->
<div class="grid grid-2" style="margin-bottom:18px">
    <div class="card" style="border:1.5px solid rgba(201,146,39,0.4)">
        <div class="card-header">
            <div>
                <div class="card-title">🎯 تخته مأموریت‌ها و چالش‌های مهارتی میان‌ماژولی (Active Quests)</div>
                <div class="muted" style="font-size:11.5px">تکمیل چالش‌های عملیاتی در ماژول‌های سامانه و دریافت آنی XP و سکه مهارت</div>
            </div>
            <span class="badge badge-gold">گیمیفیکیشن عملیاتی</span>
        </div>
        <?php foreach ($quests as $q): ?>
            <div style="border:1px solid var(--border);border-radius:12px;padding:12px;margin-bottom:10px">
                <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap">
                    <div>
                        <span class="badge badge-info"><?= e($q['difficulty_tier']) ?></span>
                        <strong style="margin-right:6px"><?= e($q['title']) ?></strong>
                    </div>
                    <span class="badge badge-gold">+<?= fa($q['xp_reward']) ?> XP | 🪙 +<?= fa($q['coin_reward']) ?></span>
                </div>
                <div style="display:flex;justify-content:space-between;align-items:center;margin-top:10px;gap:10px">
                    <div style="flex:1">
                        <div class="progress-track"><div class="progress-fill" style="width:<?= (int)$q['progress_pct'] ?>%"></div></div>
                    </div>
                    <?php if ((int)$q['is_claimed'] === 1): ?>
                        <span class="badge badge-success">✓ پاداش دریافت شد</span>
                    <?php else: ?>
                        <form method="post" action="<?= e(url('gamification-analytics')) ?>">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="claim_quest">
                            <input type="hidden" name="quest_id" value="<?= (int)$q['id'] ?>">
                            <button type="submit" class="btn btn-primary btn-sm">دریافت پاداش</button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="card" style="border:1.5px solid rgba(15,118,110,0.38)">
        <div class="card-header">
            <div>
                <div class="card-title">🎁 فروشگاه مشوق‌ها و امتیازات ویژه مؤسسه آموزشی آدان (Adan Learning Rewards Store)</div>
                <div class="muted" style="font-size:11.5px">موجودی فعلی شما: <strong>🪙 <?= fa(number_format($hud['chamber_coins'])) ?> سکه مهارت</strong> — تبدیل به خدمات واقعی اتاق</div>
            </div>
            <span class="badge badge-success">صدور آنی کد واچر</span>
        </div>
        <?php foreach ($rewards as $rw): ?>
            <div style="border:1px solid var(--border);border-radius:12px;padding:12px;margin-bottom:10px;display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap">
                <div>
                    <span class="badge badge-purple"><?= e($rw['category_label']) ?></span>
                    <strong style="display:block;margin-top:4px"><?= e($rw['reward_title']) ?></strong>
                    <div class="muted" style="font-size:11.5px">ظرفیت باقی‌مانده: <?= fa($rw['stock_remaining']) ?> مورد | آخرین واچر: <code><?= e($rw['last_voucher_serial']) ?></code></div>
                </div>
                <form method="post" action="<?= e(url('gamification-analytics')) ?>">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="redeem_reward">
                    <input type="hidden" name="reward_id" value="<?= (int)$rw['id'] ?>">
                    <button type="submit" class="btn btn-gold btn-sm">🪙 <?= fa($rw['coin_cost']) ?> سکه — دریافت واچر</button>
                </form>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- LEADERBOARDS: INDIVIDUAL + CORPORATE LEAGUE -->
<div class="grid grid-2" style="margin-bottom:18px">
    <div class="card">
        <div class="card-header">
            <div class="card-title">🏆 تالار افتخارات انفرادی فراگیران برتر استان (Individual XP Leaderboard)</div>
            <span class="badge badge-gold">فصل پاییز ۱۴۰۵</span>
        </div>
        <div class="table-wrap">
            <table>
                <thead><tr><th>رتبه</th><th>نام فراگیر</th><th>بنگاه عضو</th><th>سطح و نشان</th><th>پیوستگی</th><th>امتیاز XP</th></tr></thead>
                <tbody>
                <?php foreach ($wallets as $idx => $w): ?>
                    <tr>
                        <td><strong>#<?= fa($idx + 1) ?></strong></td>
                        <td><strong><?= e($w['learner_name']) ?></strong></td>
                        <td style="font-size:12px"><?= e($w['org_name']) ?></td>
                        <td><span class="badge badge-gold">Lv.<?= fa($w['level_num']) ?> — <?= e($w['rank_title']) ?></span></td>
                        <td>🔥 <?= fa($w['streak_days']) ?> روز</td>
                        <td><strong><?= fa(number_format((int)$w['xp_points'])) ?> XP</strong></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <div class="card-title">🏭 لیگ یادگیری سازمانی بین کارخانجات و شرکت‌های طرف قرارداد مؤسسه آموزشی آدان (B2B League)</div>
            <span class="badge badge-success">رقابت سالم بنگاه‌ها</span>
        </div>
        <div class="table-wrap">
            <table>
                <thead><tr><th>جایگاه</th><th>نام سازمان / کارخانه عضو</th><th>پرسنل فعال</th><th>میانگین پیوستگی</th><th>مجموع امتیاز سازمان</th></tr></thead>
                <tbody>
                <?php foreach ($summary['org_league'] as $oidx => $org): ?>
                    <tr>
                        <td><span class="badge badge-gold">رتبه <?= fa($oidx + 1) ?></span></td>
                        <td><strong><?= e($org['org_name']) ?></strong></td>
                        <td><?= fa($org['active_learners']) ?> نفر</td>
                        <td><?= fa((string)$org['avg_org_streak']) ?> روز</td>
                        <td><strong><?= fa(number_format((int)$org['total_org_xp'])) ?> XP</strong></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- CONTENT FRICTION HEATMAP + LIVE xAPI TELEMETRY STREAM -->
<div class="card" style="margin-bottom:18px">
    <div class="card-header">
        <div>
            <div class="card-title">🔥 نقشه حرارتی نقاط گلوگاه محتوا و بازپخش مکرر ویدئوها (Content Friction &amp; Replay Heatmap)</div>
            <div class="muted" style="font-size:12px">شناسایی دقیق دقایقی از فیلم‌های آموزشی که فراگیران بیشترین عقب‌زدن (Rewind)، خطا یا خروج را داشته‌اند</div>
        </div>
        <span class="badge badge-info">بازخورد به اساتید و R&amp;D</span>
    </div>
    <div class="table-wrap">
        <table>
            <thead><tr><th>عنوان دوره</th><th>بخش / دقیقه دقیق گلوگاه</th><th>میانگین بازپخش</th><th>نرخ ریزش مقطعی</th><th>نرخ خطای تست</th><th>نسخه اصلاح آموزشی هوش مصنوعی</th></tr></thead>
            <tbody>
            <?php foreach ($heatmaps as $hm): ?>
                <tr>
                    <td><strong><?= e($hm['course_title']) ?></strong></td>
                    <td><code><?= e($hm['lesson_segment']) ?></code></td>
                    <td><?= fa((string)$hm['avg_rewind_count']) ?> بار</td>
                    <td><span class="badge <?= (int)$hm['dropoff_rate_pct'] >= 25 ? 'badge-danger' : 'badge-success' ?>"><?= fa($hm['dropoff_rate_pct']) ?>٪</span></td>
                    <td><?= fa($hm['quiz_error_rate_pct']) ?>٪</td>
                    <td style="font-size:12px"><?= e($hm['ai_pedagogical_fix']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <div>
            <div class="card-title">📡 جریان زنده رویدادهای رفتاری ثبت‌شده از سراسر ماژول‌های سامانه (Live xAPI Stream)</div>
            <div class="muted" style="font-size:12px">ثبت خودکار تعاملات یادگیری در تمام صفحات سامانه و تبدیل آن به امتیاز تجربه (XP)</div>
        </div>
        <form method="post" action="<?= e(url('gamification-analytics')) ?>" style="display:flex;gap:8px">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="log_study_pulse">
            <input type="hidden" name="module_route" value="lms">
            <input type="hidden" name="action_verb" value="مطالعه عمیق درس و حل تمرین تعاملی">
            <input type="hidden" name="dwell_seconds" value="1200">
            <button type="submit" class="btn btn-primary btn-sm">+ ثبت پالس مطالعه عمیق (+۵۵ XP)</button>
        </form>
    </div>
    <div class="table-wrap">
        <table>
            <thead><tr><th>فراگیر</th><th>ماژول مبدأ</th><th>رفتار ثبت‌شده (xAPI Verb)</th><th>مدت تمرکز</th><th>شاخص تمرکز</th><th>پاداش XP</th></tr></thead>
            <tbody>
            <?php foreach ($events as $ev): ?>
                <tr>
                    <td><strong><?= e($ev['learner_name']) ?></strong></td>
                    <td><code>/<?= e($ev['module_route']) ?></code></td>
                    <td><?= e($ev['action_verb']) ?></td>
                    <td><?= fa((int)round(((int)$ev['dwell_seconds']) / 60)) ?> دقیقه</td>
                    <td><span class="badge badge-success"><?= fa($ev['focus_index_pct']) ?>٪</span></td>
                    <td><span class="badge badge-gold">+<?= fa($ev['xp_awarded']) ?> XP</span></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
