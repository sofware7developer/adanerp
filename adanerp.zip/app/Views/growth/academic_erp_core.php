<?php $isLearnerAcad = \App\Core\Auth::role() === 'learner'; if ($isLearnerAcad && !in_array($activeTab, ['gradebook', 'terms'], true)) { $activeTab = 'gradebook'; } ?>
<div class="hero-banner">
    <div>
        <?php if ($isLearnerAcad): ?>
            <span class="badge badge-gold" style="margin-bottom:8px">پرونده آموزشی من — حضور، نمرات و کارنامه</span>
            <h1>وضعیت آموزشی دوره‌های من</h1>
            <p>درصد حضور، ریزنمرات وزن‌دار و وضعیت آیین‌نامه‌ای هر دوره‌ای که در آن ثبت‌نام کرده‌اید؛ برای چاپ کارنامه رسمی از دکمه روبه‌رو استفاده کنید. (ثبت و ویرایش حضور و نمره، تقویم ترم‌ها و قوانین پیش‌نیاز در اختیار کارکنان و مدرسان اتاق است.)</p>
        <?php else: ?>
        <span class="badge badge-gold" style="margin-bottom:8px">هسته استاندارد عملیات آموزشی ERP (Academic Registrar, Attendance, Gradebook &amp; Prerequisites)</span>
        <h1>مدیریت تقویم و ترم‌های آموزشی، حضور و غیاب جلسات، کارنامه نمرات و قوانین پیش‌نیاز</h1>
        <p>متصل به پارامترهای زنده تنظیمات نرم‌افزار: حدنصاب حضور الزامی <strong><?= fa($data['min_att']) ?>٪</strong> و حداقل نمره قبولی <strong><?= fa($data['min_pass']) ?> از ۱۰۰</strong> با فرمول وزن‌دار استاندارد (۲۰٪ فعالیت + ۳۰٪ پروژه عملی + ۵۰٪ آزمون پایانی).</p>
        <?php endif; ?>
    </div>
    <div class="hero-actions">
        <a class="btn btn-gold" href="<?= e(url('transcript-print')) ?>" target="_blank">🖨️ چاپ کارنامه رسمی آموزشی (A4 + QR)</a>
        <a class="btn btn-outline" style="background:rgba(255,255,255,0.14);color:#fff;border-color:rgba(255,255,255,0.3)" href="<?= e(url('helpdesk-sla')) ?>">🎧 میز خدمت و تیکتینگ SLA ←</a>
    </div>
</div>

<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:18px">
    <button type="button" class="btn <?= $activeTab === 'gradebook' ? 'btn-gold' : 'btn-outline' ?> btn-sm acad-tab-btn" onclick="switchAcadTab('gradebook', this)">📋 <?= $isLearnerAcad ? '۱. کارنامه و حضور و غیاب من' : '۱. دفتر دیجیتال حضور و غیاب و ثبت نمرات وزن‌دار' ?></button>
    <button type="button" class="btn <?= $activeTab === 'terms' ? 'btn-gold' : 'btn-outline' ?> btn-sm acad-tab-btn" onclick="switchAcadTab('terms', this)">📅 ۲. مدیریت سال و نیمسال‌های آموزشی و تقویم رسمی</button>
    <?php if (!$isLearnerAcad): ?>
    <button type="button" class="btn <?= $activeTab === 'prereq' ? 'btn-gold' : 'btn-outline' ?> btn-sm acad-tab-btn" onclick="switchAcadTab('prereq', this)">🔗 ۳. قوانین پیش‌نیاز دوره‌ها و صف هوشمند لیست انتظار</button>
    <?php endif; ?>
</div>

<!-- تب ۱: حضور و غیاب و لیست نمرات -->
<div id="acadPanel_gradebook" class="acad-panel" style="display:<?= $activeTab === 'gradebook' ? 'block' : 'none' ?>">
    <div class="grid grid-3" style="margin-bottom:16px">
<?php if (!$isLearnerAcad): ?>
        <div class="card">
            <div class="card-header"><div class="card-title">✍️ ثبت حضور کلاسی و ریزنمرات فراگیر</div></div>
            <form method="post">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="record_attendance_grade">
                <div class="form-group"><label>نام و نام خانوادگی فراگیر:</label><input type="text" name="learner_name" value="مهندس مهرداد شریفی" required></div>
                <div class="form-group"><label>عنوان دوره آموزشی:</label><input type="text" name="course_title" value="جامع قوانین اینکوترمز ۲۰۲۰ و UCP600" required></div>
                <div class="grid grid-2">
                    <div class="form-group"><label>کل جلسات دوره:</label><input type="number" name="sessions_total" value="10" min="1" max="50" required></div>
                    <div class="form-group"><label>جلسات حاضر فراگیر:</label><input type="number" name="sessions_attended" value="9" min="0" max="50" required></div>
                </div>
                <div class="grid grid-3">
                    <div class="form-group"><label>مستمر (۲۰٪):</label><input type="number" name="quiz_activity_score" value="90" min="0" max="100" required></div>
                    <div class="form-group"><label>پروژه (۳۰٪):</label><input type="number" name="practical_project_score" value="94" min="0" max="100" required></div>
                    <div class="form-group"><label>پایانی (۵۰٪):</label><input type="number" name="final_exam_score" value="92" min="0" max="100" required></div>
                </div>
                <button type="submit" class="btn btn-primary" style="width:100%">محاسبه نمره کل، کنترل غیبت و ثبت در کارنامه</button>
            </form>
        </div>
<?php endif; ?>

        <div class="card" style="grid-column:span 2">
            <div class="card-header">
                <div class="card-title">📊 دفتر جامع حضور و غیاب جلسات و وضعیت قبولی / مجوز صدور گواهی QR</div>
                <a class="btn btn-outline btn-sm" href="<?= e(url('transcript-print')) ?>" target="_blank">چاپ کارنامه A4</a>
            </div>
            <div class="table-wrap">
                <table>
                    <thead><tr><th>سریال</th><th>فراگیر</th><th>دوره آموزشی</th><th>حضور</th><th>مستمر/پروژه/پایانی</th><th>نمره کل</th><th>وضعیت آیین‌نامه‌ای</th></tr></thead>
                    <tbody>
                        <?php foreach ($data['gradebook'] as $g): ?>
                            <?php $blocked = str_contains($g['academic_standing'], '⛔') || str_contains($g['academic_standing'], 'مردود'); ?>
                            <tr>
                                <td><code><?= e($g['record_serial']) ?></code></td>
                                <td><strong><?= e($g['learner_name']) ?></strong></td>
                                <td><?= e($g['course_title']) ?></td>
                                <td><span class="badge badge-<?= (int)$g['attendance_pct'] >= $data['min_att'] ? 'success' : 'danger' ?>"><?= fa($g['attendance_pct']) ?>٪ (<?= fa($g['sessions_attended']) ?>/<?= fa($g['sessions_total']) ?>)</span></td>
                                <td><?= fa($g['quiz_activity_score']) ?> / <?= fa($g['practical_project_score']) ?> / <?= fa($g['final_exam_score']) ?></td>
                                <td><strong style="font-size:15px"><?= fa($g['weighted_total_score']) ?></strong></td>
                                <td><span class="badge badge-<?= $blocked ? 'danger' : 'success' ?>"><?= e($g['academic_standing']) ?></span></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- تب ۲: تقویم آموزشی و نیمسال‌ها -->
<div id="acadPanel_terms" class="acad-panel" style="display:<?= $activeTab === 'terms' ? 'block' : 'none' ?>">
    <div class="grid grid-3">
<?php if (!$isLearnerAcad): ?>
        <div class="card">
            <div class="card-header"><div class="card-title">📅 تعریف نیمسال آموزشی جدید</div></div>
            <form method="post">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="create_term">
                <div class="form-group"><label>کد نیمسال:</label><input type="text" name="term_code" value="TERM-1406-SUMMER" required dir="ltr"></div>
                <div class="form-group"><label>عنوان رسمی نیمسال:</label><input type="text" name="term_title" value="ترم تابستان ۱۴۰۶ — کارگاه‌های فشرده صادرات و هوش مصنوعی" required></div>
                <div class="form-group"><label>بازه ثبت‌نام عادی:</label><input type="text" name="registration_window" value="۱۴۰۶/۰۳/۲۰ لغایت ۱۴۰۶/۰۴/۰۵" required></div>
                <div class="form-group"><label>مهلت حذف و اضافه بدون جریمه:</label><input type="text" name="add_drop_deadline" value="تا ۷۲ ساعت پیش از جلسه اول" required></div>
                <div class="form-group"><label>بازه آزمون‌های پایانی:</label><input type="text" name="exams_window" value="۱۴۰۶/۰۶/۱۵ لغایت ۱۴۰۶/۰۶/۲۸" required></div>
                <div class="form-group"><label>سقف ظرفیت پذیرش نیمسال (نفر):</label><input type="number" name="target_capacity" value="650" required></div>
                <button type="submit" class="btn btn-gold" style="width:100%">ثبت نیمسال در تقویم آموزشی</button>
            </form>
        </div>
<?php endif; ?>
        <div class="card" style="grid-column:span 2">
            <div class="card-header"><div class="card-title">🏛️ تقویم مصوب نیمسال‌های آموزشی مؤسسه آموزشی آدان</div></div>
            <div class="table-wrap">
                <table>
                    <thead><tr><th>کد ترم</th><th>عنوان نیمسال</th><th>ثبت‌نام</th><th>حذف و اضافه</th><th>بازه امتحانات</th><th>ظرفیت</th><th>وضعیت</th></tr></thead>
                    <tbody>
                        <?php foreach ($data['terms'] as $t): ?>
                            <tr>
                                <td><code><?= e($t['term_code']) ?></code></td>
                                <td><strong><?= e($t['term_title']) ?></strong></td>
                                <td><?= e($t['registration_window']) ?></td>
                                <td><?= e($t['add_drop_deadline']) ?></td>
                                <td><?= e($t['exams_window']) ?></td>
                                <td><?= fa($t['target_capacity']) ?> نفر</td>
                                <td><span class="badge badge-success"><?= e($t['term_status']) ?></span></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- تب ۳: پیش‌نیازها و لیست انتظار -->
<div id="acadPanel_prereq" class="acad-panel" style="display:<?= $activeTab === 'prereq' ? 'block' : 'none' ?>">
<?php if (!$isLearnerAcad): ?>
    <div class="card">
        <div class="card-header"><div class="card-title">🔗 قواعد کنترل پیش‌نیاز دوره‌ها و مدیریت نوبت لیست انتظار (Waitlist Auto-Promotion)</div></div>
        <div class="table-wrap">
            <table>
                <thead><tr><th>کد قاعده</th><th>دوره هدف (پیشرفته)</th><th>پیش‌نیاز / شرط ورود الزامی</th><th>متقاضی در صف انتظار</th><th>امتیاز اولویت</th><th>وضعیت</th><th>عملیات</th></tr></thead>
                <tbody>
                    <?php foreach ($data['waitlist'] as $w): ?>
                        <tr>
                            <td><code><?= e($w['rule_or_queue_code']) ?></code></td>
                            <td><strong><?= e($w['target_course_title']) ?></strong></td>
                            <td><?= e($w['prerequisite_course_title']) ?></td>
                            <td><?= e($w['waitlist_applicant_name']) ?></td>
                            <td><span class="badge badge-gold"><?= fa($w['applicant_priority_score']) ?> امتیاز</span></td>
                            <td><span class="badge badge-info"><?= e($w['queue_status']) ?></span></td>
                            <td>
                                <form method="post" style="margin:0">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action" value="promote_waitlist">
                                    <input type="hidden" name="queue_id" value="<?= (int)$w['id'] ?>">
                                    <button type="submit" class="btn btn-primary btn-sm">ارتقا به ثبت‌نام قطعی</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php endif; ?>
</div>

<script>
function switchAcadTab(tab, btn) {
    document.querySelectorAll('.acad-panel').forEach(p => p.style.display = 'none');
    document.getElementById('acadPanel_' + tab).style.display = 'block';
    document.querySelectorAll('.acad-tab-btn').forEach(b => { b.classList.remove('btn-gold'); b.classList.add('btn-outline'); });
    btn.classList.remove('btn-outline'); btn.classList.add('btn-gold');
}
</script>
