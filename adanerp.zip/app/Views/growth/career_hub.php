<?php use App\Services\SmartRecruitmentService; ?>
<div class="hero-banner">
    <div>
        <span class="badge badge-gold">ماژول راهبردی ۴۶ و ۳۲ | زیست‌بوم جامع کاریابی، انتشار آگهی هوشمند، رزومه‌ساز رسمی و پایپ‌لاین ATS صنایع عضو</span>
        <h1>سامانه جامع کاریابی تخصصی، استودیو آگهی استخدام با AI و سیستم مدیریت متقاضیان (ATS)</h1>
        <p>پیوند مستقیم فارغ‌التحصیلان دارای گواهی QR و گذرنامه مهارتی اتاق با کارخانجات و شرکت‌های صادراتی عضو: از نگارش هوشمند آگهی و غربالگری هوش مصنوعی تا کانبان ۶ مرحله‌ای استخدام، مصاحبه و صدور Offer Letter رسمی.</p>
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
        <button type="button" class="btn btn-gold" onclick="window.switchCareerTab('post_ad')">➕ ثبت آگهی استخدام جدید (با AI)</button>
        <a class="btn btn-outline" style="background:rgba(255,255,255,0.14);color:#fff;border-color:rgba(255,255,255,0.35)" target="_blank" href="<?= e(url('cv-print')) ?>">🖨️ چاپ رزومه رسمی تاییدشده اتاق</a>
    </div>
</div>

<!-- KPI ROW -->
<div class="grid grid-4" style="margin-bottom:18px">
    <div class="stat-card">
        <div>
            <div class="stat-label">آگهی‌های شغلی تاییدشده فعال</div>
            <div class="stat-value" style="color:var(--primary)"><?= fa($hub['all_ads_cnt']) ?> موقعیت</div>
            <div class="muted" style="font-size:11.5px"><?= fa($hub['urgent_cnt']) ?> آگهی با برچسب «استخدام فوری 🔥»</div>
        </div>
    </div>
    <div class="stat-card">
        <div>
            <div class="stat-label">میانگین دقت تطبیق هوش مصنوعی (AI Fit)</div>
            <div class="stat-value" style="color:#b45309"><?= fa($hub['avg_match']) ?>٪</div>
            <div class="muted" style="font-size:11.5px">مبتنی بر گواهی QR + آزمون‌های استاندارد</div>
        </div>
    </div>
    <div class="stat-card">
        <div>
            <div class="stat-label">پرونده‌های فعال در پایپ‌لاین ATS</div>
            <div class="stat-value" style="color:#0369a1"><?= fa(count($hub['apps'])) ?> پرونده</div>
            <div class="muted" style="font-size:11.5px">در ۶ ایستگاه استاندارد جذب نیرو</div>
        </div>
    </div>
    <div class="stat-card">
        <div>
            <div class="stat-label">استخدام قطعی‌شده در صنایع عضو</div>
            <div class="stat-value" style="color:#047857"><?= fa($hub['hired_cnt']) ?> نفر</div>
            <div class="muted" style="font-size:11.5px">جذب مستقیم بدون واسطه در کارخانجات</div>
        </div>
    </div>
</div>

<!-- 6 NAVIGATION TABS -->
<?php
$cTabs = [
    'ads'        => '🔍 ۱. ویترین آگهی‌های شغلی و فیلتر هوشمند',
    'post_ad'    => '✨ ۲. ثبت آگهی کارفرما (نویسنده هوشمند AI)',
    'ats'        => '📋 ۳. کانبان ۶ مرحله‌ای متقاضیان (ATS)',
    'cv'         => '🎓 ۴. رزومه‌ساز حرفه‌ای متصل به گواهی QR',
    'interviews' => '🤝 ۵. اتاق مصاحبه و صدور پیشنهاد حقوق (Offer)',
    'benchmarks' => '📊 ۶. رادار حقوق ۱۴۰۵ و نمایشگاه کار اتاق',
];
?>
<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:18px">
    <?php foreach ($cTabs as $tk => $tl): ?>
        <button type="button"
                id="careerTabBtn_<?= e($tk) ?>"
                onclick="window.switchCareerTab('<?= e($tk) ?>')"
                class="btn <?= $activeTab === $tk ? 'btn-gold' : 'btn-outline' ?> btn-sm"
                style="font-weight:800">
            <?= e($tl) ?>
        </button>
    <?php endforeach; ?>
</div>

<script>
window.switchCareerTab = function(tabKey) {
    document.querySelectorAll('.career-hub-pane').forEach(function(el) {
        el.style.display = (el.id === 'careerPane_' + tabKey) ? 'block' : 'none';
    });
    document.querySelectorAll('[id^="careerTabBtn_"]').forEach(function(b) {
        b.classList.remove('btn-gold');
        b.classList.add('btn-outline');
    });
    var btn = document.getElementById('careerTabBtn_' + tabKey);
    if (btn) { btn.classList.remove('btn-outline'); btn.classList.add('btn-gold'); }
};

window.fillAiJobTemplate = function() {
    var title = (document.getElementById('adJobTitleInput') || {}).value || 'مدیر صادرات و قراردادهای بین‌المللی';
    var catEl = document.getElementById('adCatSelect');
    var cat = catEl ? catEl.value : 'export_trade';
    var templates = {
        export_trade: {
            skills: 'Incoterms 2020, UCP 600, مذاکره تجاری انگلیسی/روسی, قراردادهای ICC, رفع تعهد ارزی',
            cert: 'گواهی جامع آکادمی تجارت بین‌الملل و UCP 600 مؤسسه آموزشی آدان',
            desc: '🎯 مأموریت سمت «' + title + '»:\n• تدوین و اجرای برنامه صادراتی شرکت در بازارهای اوراسیا، عراق و خلیج فارس.\n• تنظیم قراردادهای فروش خارجی منطبق بر اینکوترمز ۲۰۲۰ و بررسی اسناد حمل اعتباری (UCP 600).\n• KPI نود روز اول: ثبت حداقل ۳ قرارداد تأمین مستمر صادراتی و کاهش ریسک تسویه ارزی.\n• امتیاز ویژه: دارندگان گواهی QR مؤسسه آموزشی آدان مستقیم وارد مصاحبه مدیرعامل می‌شوند.'
        },
        customs_logistics: {
            skills: 'سامانه جامع تجارت NTSW, اظهار گمرکی EPL, کد تعرفه HS, حمل چندوجهی, بیمه باربری کلوز A',
            cert: 'گواهی عملیاتی سامانه جامع تجارت و گمرک EPL اتاق',
            desc: '🎯 مأموریت سمت «' + title + '»:\n• مدیریت ثبت سفارش تا ترخیص قطعی محموله‌های وارداتی و صادراتی در سامانه‌های NTSW و EPL.\n• کنترل دقیق اسناد حمل، گواهی مبدأ ترجیحی و پیشگیری از هزینه دموراژ کانتینر.'
        },
        finance_tax: {
            skills: 'سامانه مؤدیان مالیاتی, استرداد ارزش افزوده صادرات, سپیدار و همکاران سیستم, ماده ۱۶۹',
            cert: 'گواهی تخصصی سامانه مؤدیان و دادرسی مالیاتی اتاق',
            desc: '🎯 مأموریت سمت «' + title + '»:\n• راهبری ارسال صورت‌حساب‌های الکترونیکی در کارپوشه مؤدیان و استرداد مالیات ارزش افزوده صادراتی.'
        }
    };
    var chosen = templates[cat] || templates.export_trade;
    document.getElementById('adSkillsInput').value = chosen.skills;
    document.getElementById('adCertInput').value = chosen.cert;
    document.getElementById('adDescTextarea').value = chosen.desc;
};

window.liveFilterJobCards = function() {
    var kw = ((document.getElementById('instantAdSearch') || {}).value || '').toLowerCase();
    var cat = ((document.getElementById('instantAdCat') || {}).value || 'all');
    document.querySelectorAll('.rich-job-card').forEach(function(card) {
        var matchCat = (cat === 'all' || card.getAttribute('data-cat') === cat);
        var matchKw = (!kw || card.textContent.toLowerCase().indexOf(kw) !== -1);
        card.style.display = (matchCat && matchKw) ? 'block' : 'none';
    });
};
</script>

<!-- ==================== TAB 1: SMART JOB ADS MARKETPLACE ==================== -->
<div id="careerPane_ads" class="career-hub-pane" style="display:<?= $activeTab === 'ads' ? 'block' : 'none' ?>">
    <div class="card" style="margin-bottom:16px;border:1.5px solid rgba(15,118,110,0.35)">
        <div class="grid grid-3" style="gap:10px;align-items:end">
            <div style="grid-column:span 2">
                <label>🔎 جست‌وجوی آنی در عنوان شغل، نام کارخانه، مهارت (Incoterms, NTSW, مؤدیان) یا شهر:</label>
                <input type="text" id="instantAdSearch" oninput="window.liveFilterJobCards()" value="<?= e($q) ?>" placeholder="مثلاً: مدیر صادرات، فولاد زاگرس، UCP 600، گمرک، دورکاری...">
            </div>
            <div>
                <label>فیلتر گروه شغلی تخصصی:</label>
                <select id="instantAdCat" onchange="window.liveFilterJobCards()">
                    <option value="all">همه حوزه‌های شغلی اتاق (<?= fa(count($hub['ads'])) ?> آگهی)</option>
                    <?php foreach (SmartRecruitmentService::JOB_CATEGORIES as $ck => $cl): ?>
                        <option value="<?= e($ck) ?>" <?= $cat === $ck ? 'selected' : '' ?>><?= e($cl) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
    </div>

    <div class="grid grid-2">
        <?php foreach ($hub['ads'] as $ad): ?>
            <div class="card rich-job-card" data-cat="<?= e($ad['category_slug']) ?>" style="margin-bottom:0;border:1.5px solid <?= (int)$ad['is_urgent'] === 1 ? 'rgba(201,146,39,0.55)' : 'var(--border)' ?>">
                <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px;flex-wrap:wrap;margin-bottom:8px">
                    <div>
                        <span class="badge badge-info"><?= e(SmartRecruitmentService::JOB_CATEGORIES[$ad['category_slug']] ?? 'بازرگانی') ?></span>
                        <?php if ((int)$ad['is_urgent'] === 1): ?>
                            <span class="badge badge-danger">🔥 استخدام فوری</span>
                        <?php endif; ?>
                        <span class="badge badge-success">✓ کارفرمای همکار آدان</span>
                    </div>
                    <code style="font-size:11.5px"><?= e($ad['ad_code']) ?></code>
                </div>

                <h3 style="font-size:16px;margin:6px 0"><?= e($ad['job_title']) ?></h3>
                <div style="font-weight:800;color:var(--primary);font-size:13px;margin-bottom:8px">
                    🏭 <?= e($ad['company_name']) ?> • 📍 <?= e($ad['city_location']) ?> • ⏱️ <?= e($ad['cooperation_type']) ?> (<?= e($ad['seniority_level']) ?>)
                </div>

                <div style="padding:9px 12px;border-radius:10px;background:var(--surface-2);margin-bottom:10px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
                    <span>💰 <strong>حقوق پیشنهادی: <?= fa($ad['salary_min_million']) ?> تا <?= fa($ad['salary_max_million']) ?> میلیون تومان</strong></span>
                    <span class="badge badge-gold">🎓 اولویت: <?= e($ad['required_chamber_cert']) ?></span>
                </div>

                <p style="font-size:12.5px;line-height:1.8;color:var(--text-muted);margin-bottom:10px"><?= nl2br(e($ad['job_description_ai'])) ?></p>

                <div style="display:flex;gap:5px;flex-wrap:wrap;margin-bottom:12px">
                    <?php foreach (explode(',', (string)$ad['required_skills_tags']) as $sk): ?>
                        <span style="font-size:11px;padding:3px 8px;border-radius:6px;background:rgba(15,118,110,0.08);border:1px solid rgba(15,118,110,0.2)"><?= e(trim($sk)) ?></span>
                    <?php endforeach; ?>
                </div>

                <div style="font-size:11.5px;color:#047857;margin-bottom:12px">✨ <strong>مزایای رفاهی:</strong> <?= e($ad['perks_badges']) ?></div>

                <div style="display:flex;justify-content:space-between;align-items:center;padding-top:10px;border-top:1px dashed var(--border);gap:8px;flex-wrap:wrap">
                    <span class="muted" style="font-size:11.5px">👁️ <?= fa($ad['views_count']) ?> بازدید | 👥 <?= fa($ad['applicants_count']) ?> رزومه ارسالی | ثبت: <?= e($ad['posted_shamsi']) ?></span>
                    <form method="post" action="<?= e(url('career-hub')) ?>" style="display:inline-flex;gap:6px">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="apply_smart_ad">
                        <input type="hidden" name="job_ad_id" value="<?= (int)$ad['id'] ?>">
                        <button type="submit" class="btn btn-gold btn-sm">🚀 ارسال ۱-کلیکی رزومه و گذرنامه QR</button>
                    </form>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- ==================== TAB 2: AI JOB AD PUBLISHING STUDIO ==================== -->
<div id="careerPane_post_ad" class="career-hub-pane" style="display:<?= $activeTab === 'post_ad' ? 'block' : 'none' ?>">
    <div class="card" style="border:1.5px solid rgba(201,146,39,0.48)">
        <div class="card-header">
            <div>
                <div class="card-title">✨ استودیو حرفه‌ای ثبت و انتشار آگهی استخدام ویژه شرکت‌ها و کارخانجات دانش‌پذیر آدان</div>
                <div class="muted" style="font-size:12px">عنوان شغل را بنویسید و روی «نگارش هوشمند با هوش مصنوعی» کلیک کنید تا شرح وظایف، مهارت‌ها و گواهی‌های مرتبط خودکار تکمیل شوند</div>
            </div>
            <button type="button" class="btn btn-gold btn-sm" onclick="window.fillAiJobTemplate()">🤖 نگارش خودکار شرح شغل با AI</button>
        </div>

        <form method="post" action="<?= e(url('career-hub')) ?>" class="grid grid-3" style="gap:12px">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="publish_job_ad">
            <div>
                <label>نام شرکت / کارخانه کارفرما:</label>
                <input type="text" name="company_name" value="هلدینگ صنعتی و صادراتی پارس زاگرس" required>
            </div>
            <div>
                <label>عنوان دقیق موقعیت شغلی:</label>
                <input type="text" id="adJobTitleInput" name="job_title" value="سرپرست صادرات، قراردادهای بین‌المللی و بازار اوراسیا" required>
            </div>
            <div>
                <label>دسته‌بندی تخصصی شغل:</label>
                <select id="adCatSelect" name="category_slug">
                    <?php foreach (SmartRecruitmentService::JOB_CATEGORIES as $ck => $cl): ?>
                        <option value="<?= e($ck) ?>"><?= e($cl) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label>نوع همکاری:</label>
                <select name="cooperation_type">
                    <option>تمام‌وقت</option>
                    <option>تمام‌وقت / هیبرید</option>
                    <option>پاره‌وقت / مشاوره‌ای</option>
                    <option>دورکاری کامل</option>
                    <option>کارآموزی منتهی به استخدام (طرح پویش)</option>
                </select>
            </div>
            <div>
                <label>سطح ارشدیت:</label>
                <select name="seniority_level">
                    <option>کارشناس ارشد</option>
                    <option>سرپرست / مدیر میانی</option>
                    <option>کارشناس</option>
                    <option>مدیر اجرایی (C-Level)</option>
                </select>
            </div>
            <div>
                <label>محل خدمت / شهرک صنعتی:</label>
                <input type="text" name="city_location" value="مرکز استان — دفتر مرکزی صادرات" required>
            </div>
            <div>
                <label>حداقل حقوق پایه (میلیون تومان):</label>
                <input type="number" name="salary_min_million" value="55" required>
            </div>
            <div>
                <label>حداکثر حقوق پایه (میلیون تومان):</label>
                <input type="number" name="salary_max_million" value="80" required>
            </div>
            <div>
                <label>گواهی دارای اولویت مؤسسه آموزشی آدان:</label>
                <input type="text" id="adCertInput" name="required_chamber_cert" value="گواهی جامع آکادمی تجارت بین‌الملل و UCP 600">
            </div>
            <div style="grid-column:span 2">
                <label>مهارت‌های کلیدی موردنیاز (جداشده با ویرگول):</label>
                <input type="text" id="adSkillsInput" name="required_skills_tags" value="Incoterms 2020, UCP 600, سامانه جامع تجارت NTSW, مذاکره انگلیسی B2B">
            </div>
            <div>
                <label>بسته مزایا و مشوق‌های رفاهی:</label>
                <input type="text" name="perks_badges" value="پورسانت دلاری صادرات، بیمه تکمیلی طلایی، ناهار و وام">
            </div>
            <div style="grid-column:1 / -1">
                <label>شرح کامل وظایف، شاخص‌های عملکرد ۹۰ روزه و شرایط احراز:</label>
                <textarea id="adDescTextarea" name="job_description_ai" rows="4">مسئولیت توسعه فروش صادراتی، مذاکره مستقیم با خریداران منطقه‌ای، بررسی اسناد حمل و هماهنگی با واحد لجستیک و گمرک.</textarea>
            </div>
            <div style="grid-column:1 / -1;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px">
                <label style="display:inline-flex;align-items:center;gap:6px;cursor:pointer">
                    <input type="checkbox" name="is_urgent" value="1" checked> نمایش با برچسب ویژه «🔥 استخدام فوری» در صدر ویترین اتاق و پورتال عمومی
                </label>
                <button type="submit" class="btn btn-primary">📢 انتشار رسمی آگهی و همرسانی خودکار به فارغ‌التحصیلان اتاق</button>
            </div>
        </form>
    </div>
</div>

<!-- ==================== TAB 3: 6-STAGE VISUAL ATS KANBAN ==================== -->
<div id="careerPane_ats" class="career-hub-pane" style="display:<?= $activeTab === 'ats' ? 'block' : 'none' ?>">
    <div class="card" style="border:1.5px solid rgba(15,118,110,0.4)">
        <div class="card-header">
            <div>
                <div class="card-title">📋 پایپ‌لاین بصری ۶ مرحله‌ای پیگیری متقاضیان استخدام (Visual Employer ATS Kanban)</div>
                <div class="muted" style="font-size:12px">غربالگری خودکار رزومه‌ها بر پایه گواهی‌های QR، تحلیل شکاف مهارتی و پیشبرد ۱-کلیکی تا استخدام قطعی</div>
            </div>
            <span class="badge badge-gold">۶ ایستگاه استاندارد جذب</span>
        </div>

        <div class="grid grid-3" style="gap:12px;margin-bottom:16px">
            <?php foreach (SmartRecruitmentService::ATS_STAGES as $stKey => $stLabel): ?>
                <div style="background:var(--surface-2);border:1px solid var(--border);border-radius:12px;padding:12px">
                    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
                        <strong style="font-size:12.5px"><?= e($stLabel) ?></strong>
                        <span class="badge badge-info"><?= fa(count($hub['kanban'][$stKey] ?? [])) ?></span>
                    </div>
                    <?php if (empty($hub['kanban'][$stKey])): ?>
                        <div class="muted" style="font-size:11.5px;padding:8px 0">بدون پرونده در این ایستگاه</div>
                    <?php else: ?>
                        <?php foreach ($hub['kanban'][$stKey] as $card): ?>
                            <div style="background:var(--surface);border:1px solid var(--border);border-radius:10px;padding:10px;margin-bottom:8px">
                                <div style="display:flex;justify-content:space-between;align-items:center">
                                    <strong><?= e($card['candidate_name']) ?></strong>
                                    <span class="badge badge-success"><?= fa($card['ai_match_score_pct']) ?>٪ تطابق</span>
                                </div>
                                <div style="font-size:11.5px;color:var(--primary);margin:4px 0"><?= e($card['job_title_snapshot']) ?> — <?= e($card['company_snapshot']) ?></div>
                                <div class="muted" style="font-size:11px;margin-bottom:8px"><?= e($card['skill_gap_prescription']) ?></div>
                                <?php if ($stKey !== 'hired'): ?>
                                    <form method="post" action="<?= e(url('career-hub')) ?>">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="action" value="advance_ats">
                                        <input type="hidden" name="app_id" value="<?= (int)$card['id'] ?>">
                                        <button type="submit" class="btn btn-gold btn-sm" style="width:100%">ارتقا به ایستگاه بعدی ←</button>
                                    </form>
                                <?php else: ?>
                                    <span class="badge badge-success" style="width:100%;text-align:center">🎉 استخدام نهایی ثبت شد</span>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- ==================== TAB 4: SMART VERIFIED CV BUILDER ==================== -->
<div id="careerPane_cv" class="career-hub-pane" style="display:<?= $activeTab === 'cv' ? 'block' : 'none' ?>">
    <?php $myCv = $hub['profiles'][0] ?? []; ?>
    <div class="card" style="border:1.5px solid rgba(201,146,39,0.45)">
        <div class="card-header">
            <div>
                <div class="card-title">🎓 رزومه‌ساز هوشمند کارجو (همگام‌سازی خودکار با گواهی‌های QR، آزمون‌های استاندارد و امتیاز XP)</div>
                <div class="muted" style="font-size:12px">برخلاف سایت‌های کاریابی معمولی که ادعاهای رزومه خوداظهاری است، در این سامانه گواهی‌ها و مهارت‌ها رسماً توسط مؤسسه آموزشی آدان مهروموم شده‌اند</div>
            </div>
            <a class="btn btn-gold btn-sm" target="_blank" href="<?= e(url('cv-print')) ?>">🖨️ نسخه چاپی رسمی دوزبانه رزومه</a>
        </div>

        <form method="post" action="<?= e(url('career-hub')) ?>" class="grid grid-3" style="gap:12px;margin-bottom:16px">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="save_candidate_cv">
            <div><label>نام و نام خانوادگی کارجو:</label><input type="text" name="full_name" value="<?= e($myCv['full_name'] ?? 'مهندس مهرداد شریفی') ?>" required></div>
            <div style="grid-column:span 2"><label>عنوان حرفه‌ای (Headline):</label><input type="text" name="headline_title" value="<?= e($myCv['headline_title'] ?? '') ?>" required></div>
            <div><label>سابقه کار مرتبط (سال):</label><input type="number" name="experience_years" value="<?= (int)($myCv['experience_years'] ?? 6) ?>"></div>
            <div><label>حقوق پایه مدنظر (میلیون تومان):</label><input type="number" name="expected_salary_million" value="<?= (int)($myCv['expected_salary_million'] ?? 62) ?>"></div>
            <div><label>شهر / مدل همکاری مورد علاقه:</label><input type="text" name="city_preference" value="<?= e($myCv['city_preference'] ?? 'مرکز استان / هیبرید') ?>"></div>
            <div style="grid-column:span 2"><label>تسلط زبان‌های تجاری:</label><input type="text" name="foreign_languages" value="<?= e($myCv['foreign_languages'] ?? '') ?>"></div>
            <div><label>سبک کاری (ارزیابی غیربالینی):</label><input type="text" value="<?= e($myCv['work_style_nonclinical'] ?? '') ?>" readonly></div>
            <div style="grid-column:1 / -1"><label>مهارت‌های تخصصی تاییدشده:</label><input type="text" name="core_skills_csv" value="<?= e($myCv['core_skills_csv'] ?? '') ?>"></div>
            <div style="grid-column:1 / -1">
                <button type="submit" class="btn btn-primary">💾 ذخیره و همگام‌سازی خودکار با گواهی‌های QR و کیف پول گیمیفیکیشن (+۴۵ XP)</button>
            </div>
        </form>
    </div>
</div>

<!-- ==================== TAB 5: INTERVIEW ROOM & OFFICIAL JOB OFFER ==================== -->
<div id="careerPane_interviews" class="career-hub-pane" style="display:<?= $activeTab === 'interviews' ? 'block' : 'none' ?>">
    <div class="grid grid-2" style="gap:16px">
        <div class="card">
            <div class="card-header"><div class="card-title">📅 زمان‌بندی مصاحبه تخصصی + سؤالات فنی هوش مصنوعی</div></div>
            <form method="post" action="<?= e(url('career-hub')) ?>" class="grid grid-2" style="gap:10px;margin-bottom:14px">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="schedule_interview">
                <div><label>نام کاندیدا:</label><input type="text" name="candidate_name" value="مهندس مهرداد شریفی" required></div>
                <div><label>شرکت کارفرما:</label><input type="text" name="company_name" value="مجتمع فولاد زاگرس" required></div>
                <div><label>عنوان سمت:</label><input type="text" name="job_title" value="مدیر صادرات و قراردادها" required></div>
                <div><label>نحوه برگزاری:</label><select name="interview_mode"><option>آنلاین (اتاق اسکای‌روم کاریابی اتاق)</option><option>حضوری در محل کارخانه</option></select></div>
                <div style="grid-column:1 / -1"><label>زمان جلسه مصاحبه:</label><input type="text" name="scheduled_shamsi" value="چهارشنبه ۱۴۰۵/۰۸/۰۷ ساعت ۱۱:۰۰ صبح"></div>
                <div style="grid-column:1 / -1"><button type="submit" class="btn btn-primary" style="width:100%">ثبت جلسه مصاحبه و تولید سؤالات تخصصی AI</button></div>
            </form>
            <?php foreach ($hub['interviews'] as $iv): ?>
                <div style="border:1px solid var(--border);border-radius:10px;padding:10px;margin-bottom:8px;font-size:12px">
                    <strong><?= e($iv['candidate_name']) ?> ← <?= e($iv['company_name']) ?></strong> (<?= e($iv['scheduled_shamsi']) ?>)
                    <div class="muted" style="margin-top:4px"><?= nl2br(e($iv['ai_tailored_questions'])) ?></div>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="card">
            <div class="card-header"><div class="card-title">📜 صدور رسمی «نامه پیشنهاد شغلی و حقوق» (Official Offer Letter)</div></div>
            <form method="post" action="<?= e(url('career-hub')) ?>" class="grid grid-2" style="gap:10px;margin-bottom:14px">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="issue_offer">
                <div><label>نام منتخب نهایی:</label><input type="text" name="candidate_name" value="مهندس مهرداد شریفی" required></div>
                <div><label>شرکت صادرکننده Offer:</label><input type="text" name="company_name" value="مجتمع فولاد و ذوب‌آهن زاگرس" required></div>
                <div><label>سمت پیشنهادی:</label><input type="text" name="position_title" value="مدیر صادرات و قراردادهای بین‌المللی" required></div>
                <div><label>حقوق پایه ماهانه (میلیون تومان):</label><input type="number" name="base_monthly_million" value="72" required></div>
                <div style="grid-column:1 / -1"><label>پورسانت صادراتی و مزایا:</label><input type="text" name="export_commission_note" value="۱.۵٪ پورسانت ارزی صادرات + بیمه تکمیلی طلایی + خودرو"></div>
                <div style="grid-column:1 / -1"><button type="submit" class="btn btn-gold" style="width:100%">صدور و ارسال رسمی Offer Letter</button></div>
            </form>
            <?php foreach ($hub['offers'] as $of): ?>
                <div style="border:1px solid rgba(15,118,110,0.35);border-radius:10px;padding:10px;margin-bottom:8px;font-size:12px">
                    <span class="badge badge-gold"><?= e($of['offer_serial']) ?></span>
                    <strong><?= e($of['candidate_name']) ?> — <?= e($of['position_title']) ?></strong> (<?= fa($of['base_monthly_million']) ?> میلیون تومان پایه)
                    <div style="color:#047857;margin-top:4px"><?= e($of['offer_status']) ?> | <?= e($of['export_commission_note']) ?></div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- ==================== TAB 6: SALARY BENCHMARKS & JOB FAIR BOOTHS ==================== -->
<div id="careerPane_benchmarks" class="career-hub-pane" style="display:<?= $activeTab === 'benchmarks' ? 'block' : 'none' ?>">
    <div class="card" style="margin-bottom:16px">
        <div class="card-header">
            <div class="card-title">📊 رادار مرجع حقوق و دستمزد مشاغل تخصصی بازرگانی و صنعتی استان در سال ۱۴۰۵</div>
            <span class="badge badge-info">راهنمای شفاف کارفرما و کارجو</span>
        </div>
        <div class="table-wrap">
            <table>
                <thead><tr><th>گروه شغلی تخصصی</th><th>کف بازار</th><th>میانه رایج</th><th>دهک بالای خبرگان</th><th>شاخص تقاضا</th><th>گواهی مؤثر در جهش حقوق</th></tr></thead>
                <tbody>
                <?php foreach ($hub['benchmarks'] as $bm): ?>
                    <tr>
                        <td><strong><?= e($bm['role_family']) ?></strong></td>
                        <td><?= fa($bm['min_million']) ?> میلیون</td>
                        <td><strong><?= fa($bm['median_million']) ?> میلیون تومان</strong></td>
                        <td><span class="badge badge-gold"><?= fa($bm['max_top_decile_million']) ?> میلیون تومان</span></td>
                        <td><span class="badge badge-success"><?= fa($bm['market_demand_index']) ?> / ۱۰۰</span></td>
                        <td style="font-size:12px"><?= e($bm['top_value_cert']) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card" style="border:1.5px solid rgba(201,146,39,0.45)">
        <div class="card-header">
            <div class="card-title">🏛️ غرفه‌های نمایشگاه کار و جذب سریع مؤسسه آموزشی آدان (Speed-Interview Booths)</div>
            <span class="badge badge-gold">ملاقات مستقیم ۱۰ دقیقه‌ای با مدیران کارخانجات</span>
        </div>
        <div class="grid grid-3" style="gap:12px">
            <?php foreach ($hub['booths'] as $bt): ?>
                <div style="border:1px solid var(--border);border-radius:12px;padding:14px">
                    <span class="badge badge-purple"><?= e($bt['booth_code']) ?> — <?= e($bt['industry_sector']) ?></span>
                    <h4 style="margin:8px 0"><?= e($bt['company_name']) ?></h4>
                    <div class="muted" style="font-size:12px;margin-bottom:8px">سمت‌های باز: <?= e($bt['featured_roles']) ?></div>
                    <div style="font-size:12px;margin-bottom:10px">ظرفیت مصاحبه فوری باقی‌مانده: <strong><?= fa($bt['speed_interview_slots_left']) ?> نوبت</strong></div>
                    <form method="post" action="<?= e(url('career-hub')) ?>">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="book_fair_booth">
                        <input type="hidden" name="booth_id" value="<?= (int)$bt['id'] ?>">
                        <button type="submit" class="btn btn-primary btn-sm" style="width:100%">رزرو نوبت مصاحبه حضوری در غرفه</button>
                    </form>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
