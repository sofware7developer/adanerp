<div class="hero-banner">
    <div>
        <span class="badge badge-gold">ماژول راهبردی ۳۶ | باشگاه دانش‌آموختگان مدیران صنایع + سازنده هوشمند کنسرسیوم صادراتی</span>
        <h1>باشگاه دانش‌آموختگان اتاق و موتور هوشمند تشکیل کنسرسیوم‌های صادراتی سه‌جانبه</h1>
        <p>
            هم‌افزایی خودکار بین دانش‌آموختگان دوره‌های عالی اتاق: جفت‌سازی هوشمند <strong>واحد تولیدی پیشرو + شرکت بسته‌بندی/لجستیک زنجیره سرد + شرکت مدیریت صادرات (EMC)</strong> بر اساس کد تعرفه گمرکی (<code>HS-Code</code>) برای فتح بازارهای صادراتی مشترک.
        </p>
    </div>
</div>

<!-- AI EXPORT CONSORTIUM BUILDER -->
<div class="card" style="margin-bottom:18px;border:1.5px solid rgba(15,118,110,0.3)">
    <div class="card-header">
        <div class="card-title">موتور هوشمند تشکیل کنسرسیوم صادراتی مکمل (AI Export Consortium Builder)</div>
        <span class="badge badge-success">پیشنهاد اساسنامه سه‌جانبه</span>
    </div>
    <form method="post" class="grid grid-3" style="gap:10px;align-items:end" onsubmit="if(!window.location.protocol.startsWith('http')||typeof PAGES!=='undefined'){event.preventDefault();window.buildConsortiumClient();}">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="build_consortium">
        <div>
            <label>بازار صادراتی هدف:</label>
            <select id="cnsMarket" name="target_market">
                <option>روسیه و قزاقستان (اتحادیه اوراسیا — تعرفه صفر)</option>
                <option>عمان، امارات و قطر (حوزه خلیج فارس)</option>
                <option>عراق و اقلیم کردستان</option>
                <option>اتحادیه اروپا (با استاندارد سبز CBAM)</option>
            </select>
        </div>
        <div>
            <label>خوشه کالایی و کد تعرفه (HS-Code):</label>
            <select id="cnsHs" name="hs_cluster">
                <option>HS 0802 / خشکبار، پسته، کشمش و زعفران</option>
                <option>HS 6907 / کاشی، سرامیک، سنگ و مصالح ساختمانی</option>
                <option>HS 3920 / محصولات پلیمری، بسته‌بندی و پتروشیمی</option>
                <option>HS 7214 / مقاطع فولادی، مفتول و صنایع فلزی</option>
            </select>
        </div>
        <div>
            <label>واحد تولیدی سرگروه (دانش‌آموخته اتاق):</label>
            <input type="text" id="cnsLead" name="lead_org" value="گروه صنعتی زرین‌صادر استان" required>
        </div>
        <div style="grid-column:1 / -1">
            <button type="submit" class="btn btn-gold">جفت‌سازی هوشمند شرکای مکمل (بسته‌بندی + لجستیک + EMC) و صدور پیش‌نویس کنسرسیوم</button>
        </div>
    </form>
    <div id="cnsClientOutput" style="display:none;margin-top:12px;padding:12px 14px;border-radius:10px;background:var(--surface-2);border:1px solid var(--gold);font-size:12.5px"></div>
</div>

<!-- ACTIVE EXPORT CONSORTIUMS TABLE -->
<div class="card" style="margin-bottom:18px">
    <div class="card-header"><div class="card-title">کنسرسیوم‌های صادراتی تشکیل‌شده در باشگاه دانش‌آموختگان (جدول export_consortium_groups)</div></div>
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>کد</th>
                    <th>عنوان کنسرسیوم و بازار هدف</th>
                    <th>تولیدکننده سرگروه</th>
                    <th>شریک بسته‌بندی و لجستیک</th>
                    <th>شرکت مدیریت صادرات (EMC)</th>
                    <th>هم‌افزایی</th>
                    <th>هدف سالانه ارزی</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach (($consortiums ?? []) as $cn): ?>
                <tr>
                    <td><code><?= e($cn['consortium_code']) ?></code></td>
                    <td><strong><?= e($cn['consortium_title']) ?></strong><div class="muted" style="font-size:11px"><?= e($cn['hs_code_cluster']) ?></div></td>
                    <td><?= e($cn['lead_producer_org']) ?></td>
                    <td><?= e($cn['packaging_logistics_org']) ?></td>
                    <td><?= e($cn['trading_house_org']) ?></td>
                    <td><span class="badge badge-success"><?= fa($cn['synergy_score_pct']) ?>٪</span></td>
                    <td><strong>$<?= number_format((int)$cn['annual_target_usd']) ?></strong></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- ALUMNI NETWORK COLLABORATION WALL -->
<div class="card">
    <div class="card-header"><div class="card-title">تابلوی تبادل فرصت‌های شغلی دانش‌آموختگان دوره‌های حسابداری</div></div>
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>عضو دانش‌آموخته</th>
                    <th>سمت و شرکت</th>
                    <th>نوع همکاری</th>
                    <th>شرح پیشنهاد تجاری</th>
                    <th>پاسخ‌ها</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach (($posts ?? []) as $p): ?>
                <tr>
                    <td><strong><?= e($p['author_name']) ?></strong></td>
                    <td><?= e($p['company_and_role']) ?></td>
                    <td><span class="badge badge-info"><?= e($p['collaboration_type']) ?></span></td>
                    <td><?= e($p['proposal_body']) ?></td>
                    <td><?= fa($p['responses_count']) ?> پاسخ</td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
