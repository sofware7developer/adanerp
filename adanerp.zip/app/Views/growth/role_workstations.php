<?php
use App\Core\Auth;
$allowedTabs = $allowedTabs ?? [Auth::role() ?: 'learner', 'guest'];
$roleTabs = [
    'super_admin'     => 'مدیرکل / دبیرکل (کارتابل امضا)',
    'training_expert' => 'کارشناس آموزش (ثبت‌نام گروهی)',
    'finance_manager' => 'مدیر مالی (استرداد و خزانه)',
    'crm_manager'     => 'مدیر CRM (پروپوزال سازمانی)',
    'instructor'      => 'استاد (توصیه‌نامه و تقویم تدریس)',
    'org_rep'         => 'نماینده کارخانه (سهمیه آموزشی شرکت)',
    'learner'         => 'فراگیر (برنامه توسعه فردی)',
    'guest'           => 'استعلام گروهی اصالت گواهی (QR)',
];
?>
<div class="hero-banner">
    <div>
        <span class="badge badge-gold">میزکار عملیاتی اختصاصی نقش شما • <?= e(Auth::roleLabel($currentRole ?? Auth::role())) ?></span>
        <h1>میزکار تخصصی «<?= e(Auth::roleLabel($currentRole ?? Auth::role())) ?>»</h1>
        <p>دسترسی این صفحه بر پایه کنترل دسترسی نقش‌محور (RBAC) محدود شده و صرفاً ابزارهای مجاز نقش سازمانی شما نمایش داده می‌شود.</p>
    </div>
</div>

<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:18px">
    <?php foreach ($roleTabs as $rKey => $rLabel): ?>
        <?php if (!in_array($rKey, $allowedTabs, true)) continue; ?>
        <button type="button"
                onclick="window.switchRoleCockpitTab('<?= e($rKey) ?>')"
                id="roleBtn_<?= e($rKey) ?>"
                class="btn <?= $activeTab === $rKey ? 'btn-gold' : 'btn-outline' ?> btn-sm"
                style="font-weight:800">
            <?= e($rLabel) ?>
        </button>
    <?php endforeach; ?>
</div>

<script>
window.switchRoleCockpitTab = function(key) {
    document.querySelectorAll('.role-cockpit-pane').forEach(function(p) {
        p.style.display = (p.id === 'rolePane_' + key) ? 'block' : 'none';
    });
    document.querySelectorAll('[id^="roleBtn_"]').forEach(function(b) {
        b.classList.remove('btn-gold');
        b.classList.add('btn-outline');
    });
    var active = document.getElementById('roleBtn_' + key);
    if (active) { active.classList.remove('btn-outline'); active.classList.add('btn-gold'); }
};
</script>

<!-- ==================== PANE 1: SUPER ADMIN ==================== -->
<?php if (in_array('super_admin', $allowedTabs, true)): ?>
<div id="rolePane_super_admin" class="role-cockpit-pane" style="display:<?= $activeTab === 'super_admin' ? 'block' : 'none' ?>">
    <div class="card" style="border:1.5px solid rgba(201,146,39,0.45)">
        <div class="card-header">
            <div>
                <div class="card-title">🖋️ میز امضای دیجیتال ۱-کلیکی مدیرکل و مدیرکل مؤسسه (Executive Sign-Off Inbox)</div>
                <div class="muted" style="font-size:12px">تجمیع قراردادهای کلان B2B، نامه‌های سیاستی کمیسیون‌ها به وزرا و صدور گروهی گواهی‌ها با امضای HMAC-SHA256</div>
            </div>
            <span class="badge badge-gold">دسترسی کامل ۴۴/بخش‌های سامانه</span>
        </div>
        <div class="table-wrap">
            <table>
                <thead><tr><th>شماره سند</th><th>طبقه پرونده</th><th>موضوع منتظر توشیح</th><th>مبلغ / دامنه اثر</th><th>وضعیت امضا</th><th>اقدام مدیرکل</th></tr></thead>
                <tbody>
                <?php foreach ($ws['exec_queue'] as $eq): ?>
                    <tr>
                        <td><code><?= e($eq['doc_ref_no']) ?></code></td>
                        <td><span class="badge badge-info"><?= e($eq['doc_category']) ?></span></td>
                        <td><strong><?= e($eq['subject_title']) ?></strong></td>
                        <td><?= e($eq['amount_or_impact']) ?></td>
                        <td>
                            <?php if ($eq['sign_status'] === 'signed'): ?>
                                <span class="badge badge-success">✓ امضا شده (<?= e(substr((string)$eq['signature_sha256'], 0, 12)) ?>...)</span>
                            <?php else: ?>
                                <span class="badge badge-gold">منتظر امضای مدیرکل</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($eq['sign_status'] !== 'signed'): ?>
                                <form method="post" action="<?= e(url('role-workstations')) ?>">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action" value="exec_sign">
                                    <input type="hidden" name="item_id" value="<?= (int)$eq['id'] ?>">
                                    <button type="submit" class="btn btn-primary btn-sm">توشیح و امضای SHA-256</button>
                                </form>
                            <?php else: ?>
                                <span class="muted" style="font-size:11.5px"><?= e($eq['signed_by_name']) ?></span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- ==================== PANE 2: TRAINING EXPERT ==================== -->
<?php if (in_array('training_expert', $allowedTabs, true)): ?>
<div id="rolePane_training_expert" class="role-cockpit-pane" style="display:<?= $activeTab === 'training_expert' ? 'block' : 'none' ?>">
    <div class="card" style="border:1.5px solid rgba(15,118,110,0.4)">
        <div class="card-header">
            <div>
                <div class="card-title">📋 ویزارد ثبت‌نام گروهی اکسل (کنترل کد ملی Mod-11) و چک‌لیست اجرای کلاس (T-7 تا T+1)</div>
                <div class="muted" style="font-size:12px">ثبت‌نام یک‌جای لیست کارمندان معرفی‌شده از سوی کارخانجات به همراه تکمیل ۱۰۰٪ چک‌لیست روز برگزاری</div>
            </div>
            <span class="badge badge-success">ابزار ویژه کارشناس آموزش</span>
        </div>
        <form method="post" action="<?= e(url('role-workstations')) ?>" class="grid grid-2" style="gap:12px;margin-bottom:16px">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="bulk_enroll">
            <div>
                <label>انتخاب کد اجرای دوره (Course Run):</label>
                <select name="run_code">
                    <?php foreach ($ws['runbooks'] as $rb): ?>
                        <option value="<?= e($rb['run_code']) ?>"><?= e($rb['run_code']) ?> — <?= e($rb['course_title']) ?></option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="btn btn-gold" style="margin-top:12px;width:100%">اجرای ثبت‌نام گروهی + تکمیل ۱۰۰٪ چک‌لیست کلاس</button>
            </div>
            <div>
                <label>ورودی دسته‌ای فراگیران (نام، کد ملی ۱۰ رقمی — ردیف نامعتبر خودکار پالایش می‌شود):</label>
                <textarea name="csv_lines" rows="3" dir="ltr">مهندس کاوه رضایی, 1079025413
سارا محمودی, 0060495219
ردیف آزمایشی نامعتبر, 1234567890</textarea>
            </div>
        </form>
        <div class="table-wrap">
            <table>
                <thead><tr><th>کد اجرا</th><th>عنوان دوره</th><th>لینک آنلاین</th><th>جزوه استاد</th><th>پیامک ۲۴ساعته</th><th>ثبت‌نام‌شده</th><th>آمادگی کل</th></tr></thead>
                <tbody>
                <?php foreach ($ws['runbooks'] as $rb): ?>
                    <tr>
                        <td><code><?= e($rb['run_code']) ?></code></td>
                        <td><strong><?= e($rb['course_title']) ?></strong></td>
                        <td><?= $rb['skyroom_link_ready'] ? '✅' : '⏳' ?></td>
                        <td><?= $rb['slides_uploaded'] ? '✅' : '⏳' ?></td>
                        <td><?= $rb['sms_24h_sent'] ? '✅ ارسال شد' : '⏳ منتظر ارسال' ?></td>
                        <td><strong><?= fa($rb['bulk_enrolled_count']) ?> نفر</strong></td>
                        <td><span class="badge badge-success"><?= fa($rb['readiness_pct']) ?>٪ آماده</span></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- ==================== PANE 3: FINANCE MANAGER ==================== -->
<?php if (in_array('finance_manager', $allowedTabs, true)): ?>
<div id="rolePane_finance_manager" class="role-cockpit-pane" style="display:<?= $activeTab === 'finance_manager' ? 'block' : 'none' ?>">
    <div class="card" style="border:1.5px solid rgba(15,118,110,0.4)">
        <div class="card-header">
            <div>
                <div class="card-title">💳 ماشین‌حساب آیین‌نامه استرداد شهریه و انصراف + ثبت خودکار سند معکوس ۴ سطحی تراز</div>
                <div class="muted" style="font-size:12px">بیش از ۷۲ ساعت مانده: ۰٪ جریمه | ۲۴ تا ۷۲ ساعت: ۱۵٪ کسر اداری | کمتر از ۲۴ ساعت: ۳۰٪ کسر + ثبت زوج آرتیکل تراز در دفترکل</div>
            </div>
            <span class="badge badge-gold">کنترل تراز ۰ ریال</span>
        </div>
        <form method="post" action="<?= e(url('role-workstations')) ?>" class="grid grid-4" style="gap:10px;align-items:end;margin-bottom:16px">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="process_refund">
            <div><label>نام متقاضی / شرکت:</label><input type="text" name="applicant_name" value="شرکت صنایع دقیق پارس" required></div>
            <div><label>شهریه پرداخت‌شده (ریال):</label><input type="number" name="paid_tuition_rial" value="52000000"></div>
            <div><label>فاصله تا شروع کلاس (ساعت):</label><input type="number" name="hours_before_start" value="40"></div>
            <div><input type="hidden" name="course_title" value="جامع اینکوترمز ۲۰۲۰"><button type="submit" class="btn btn-primary" style="width:100%">محاسبه و صدور سند استرداد</button></div>
        </form>
        <div class="table-wrap">
            <table>
                <thead><tr><th>کد استرداد</th><th>متقاضی</th><th>شهریه اولیه</th><th>زمان اعلام</th><th>کسر آیین‌نامه‌ای</th><th>خالص مستردشده</th><th>سند دفترکل</th></tr></thead>
                <tbody>
                <?php foreach ($ws['refunds'] as $rf): ?>
                    <tr>
                        <td><code><?= e($rf['refund_code']) ?></code></td>
                        <td><strong><?= e($rf['applicant_name']) ?></strong></td>
                        <td><?= rial((int)$rf['paid_tuition_rial']) ?></td>
                        <td><?= fa($rf['hours_before_start']) ?> ساعت قبل</td>
                        <td><span class="badge badge-info"><?= fa($rf['deduction_pct']) ?>٪ کسر</span></td>
                        <td><strong><?= rial((int)$rf['net_refund_rial']) ?></strong></td>
                        <td><code><?= e($rf['reversal_voucher_no']) ?></code></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- ==================== PANE 4: CRM MANAGER ==================== -->
<?php if (in_array('crm_manager', $allowedTabs, true)): ?>
<div id="rolePane_crm_manager" class="role-cockpit-pane" style="display:<?= $activeTab === 'crm_manager' ? 'block' : 'none' ?>">
    <div class="card" style="border:1.5px solid rgba(201,146,39,0.4)">
        <div class="card-header">
            <div>
                <div class="card-title">🤝 تایم‌لاین ۳۶۰ درجه مذاکرات بنگاه‌ها و صدور پروپوزال اختصاصی مدیرعامل کارخانه</div>
                <div class="muted" style="font-size:12px">ثبت کانال جذب (بله/ایتا/همایش/رهیاب وب)، برآورد احتمال برد و زمان تماس بعدی</div>
            </div>
            <span class="badge badge-gold">میزکار اختصاصی CRM</span>
        </div>
        <form method="post" action="<?= e(url('role-workstations')) ?>" class="grid grid-4" style="gap:10px;align-items:end;margin-bottom:16px">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="create_proposal">
            <div><label>نام کارخانه / هلدینگ هدف:</label><input type="text" name="company_name" value="هلدینگ کاشی و سرامیک کویر" required></div>
            <div><label>کانال منشأ سرنخ:</label><input type="text" name="channel_source" value="کمپین پیام‌رسان بله"></div>
            <div><label>ارزش بسته پیشنهادی (ریال):</label><input type="number" name="proposed_package_rial" value="780000000"></div>
            <div><input type="hidden" name="contact_summary" value="پروپوزال آموزش اختصاصی ۴۰ نفر واحد صادرات و گمرک"><button type="submit" class="btn btn-gold" style="width:100%">صدور پروپوزال B2B</button></div>
        </form>
        <div class="table-wrap">
            <table>
                <thead><tr><th>کد پروپوزال</th><th>بنگاه اقتصادی</th><th>کانال جذب</th><th>مبلغ پیشنهادی</th><th>احتمال عقد قرارداد</th><th>پیگیری بعدی</th></tr></thead>
                <tbody>
                <?php foreach ($ws['touchpoints'] as $tp): ?>
                    <tr>
                        <td><code><?= e($tp['proposal_code']) ?></code></td>
                        <td><strong><?= e($tp['company_name']) ?></strong></td>
                        <td><span class="badge badge-purple"><?= e($tp['channel_source']) ?></span></td>
                        <td><?= rial((int)$tp['proposed_package_rial']) ?></td>
                        <td><span class="badge badge-success"><?= fa($tp['win_probability_pct']) ?>٪</span></td>
                        <td><?= e($tp['next_followup_shamsi']) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- ==================== PANE 5: INSTRUCTOR ==================== -->
<?php if (in_array('instructor', $allowedTabs, true)): ?>
<div id="rolePane_instructor" class="role-cockpit-pane" style="display:<?= $activeTab === 'instructor' ? 'block' : 'none' ?>">
    <div class="card" style="border:1.5px solid rgba(15,118,110,0.4)">
        <div class="card-header">
            <div>
                <div class="card-title">🎓 میزکار اختصاصی استاد: اعلام ساعات آزاد تدریس + صدور توصیه‌نامه مهارتی رسمی (Endorsement)</div>
                <div class="muted" style="font-size:12px">تغذیه مستقیم موتور زمان‌بند خودکار کلاس‌ها + ثبت توصیه‌نامه رسمی استاد برای معرفی نفرات برتر به کارخانجات عضو</div>
            </div>
            <span class="badge badge-info">میزکار هیئت علمی اتاق</span>
        </div>
        <form method="post" action="<?= e(url('role-workstations')) ?>" class="grid grid-3" style="gap:10px;align-items:end;margin-bottom:16px">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="save_endorsement">
            <div><label>ساعات آزاد هفتگی استاد جهت زمان‌بندی:</label><input type="text" name="free_weekly_slots" value="یکشنبه‌ها و سه‌شنبه‌ها ۱۵ الی ۱۹" required></div>
            <div><label>نام فراگیر برگزیده کلاس:</label><input type="text" name="endorsed_learner_name" value="مهندس مهرداد شریفی" required></div>
            <div><input type="hidden" name="endorsed_skill_badge" value="مهارت عملی تنظیم قرارداد صادراتی ICC"><input type="hidden" name="recommendation_note" value="تأیید شایستگی عملی توسط استاد دوره جهت تصدی سرپرستی صادرات."><button type="submit" class="btn btn-primary" style="width:100%">ثبت تقویم آزاد و صدور توصیه‌نامه</button></div>
        </form>
        <div class="table-wrap">
            <table>
                <thead><tr><th>کد ثبت</th><th>استاد صادرکننده</th><th>ساعات آزاد اعلامی</th><th>فراگیر مورد تأیید</th><th>نشان مهارتی تأییدشده</th><th>متن توصیه‌نامه</th></tr></thead>
                <tbody>
                <?php foreach ($ws['endorsements'] as $en): ?>
                    <tr>
                        <td><code><?= e($en['record_code']) ?></code></td>
                        <td><strong><?= e($en['instructor_name']) ?></strong></td>
                        <td><?= e($en['free_weekly_slots']) ?></td>
                        <td><strong><?= e($en['endorsed_learner_name']) ?></strong></td>
                        <td><span class="badge badge-gold"><?= e($en['endorsed_skill_badge']) ?></span></td>
                        <td style="font-size:12px"><?= e($en['recommendation_note']) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- ==================== PANE 6: ORG REP (B2B HRD) ==================== -->
<?php if (in_array('org_rep', $allowedTabs, true)): ?>
<div id="rolePane_org_rep" class="role-cockpit-pane" style="display:<?= $activeTab === 'org_rep' ? 'block' : 'none' ?>">
    <div class="card" style="border:1.5px solid rgba(201,146,39,0.4)">
        <div class="card-header">
            <div>
                <div class="card-title">🏭 کارتابل نماینده آموزش کارخانه عضو: تأیید درخواست دوره پرسنل و کسر از سهمیه قرارداد</div>
                <div class="muted" style="font-size:12px">ایزوله‌سازی کامل سازمانی — نماینده هر کارخانه صرفاً پرسنل و سهمیه قرارداد شرکت خود را مدیریت می‌کند</div>
            </div>
            <span class="badge badge-gold">حفاظ امنیتی B2B فعال</span>
        </div>
        <div class="table-wrap">
            <table>
                <thead><tr><th>کد درخواست</th><th>سازمان عضو</th><th>کارمند متقاضی</th><th>واحد سازمانی</th><th>دوره درخواستی</th><th>وضعیت تأیید</th><th>اقدام نماینده</th></tr></thead>
                <tbody>
                <?php foreach ($ws['org_requests'] as $oq): ?>
                    <tr>
                        <td><code><?= e($oq['req_code']) ?></code></td>
                        <td><?= e($oq['org_name']) ?></td>
                        <td><strong><?= e($oq['employee_fullname']) ?></strong></td>
                        <td><?= e($oq['department_unit']) ?></td>
                        <td><?= e($oq['requested_course']) ?></td>
                        <td><span class="badge <?= (int)$oq['contract_quota_deducted'] === 1 ? 'badge-success' : 'badge-gold' ?>"><?= e($oq['hr_approval_status']) ?></span></td>
                        <td>
                            <?php if ((int)$oq['contract_quota_deducted'] === 0): ?>
                                <form method="post" action="<?= e(url('role-workstations')) ?>">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action" value="approve_org_req">
                                    <input type="hidden" name="req_id" value="<?= (int)$oq['id'] ?>">
                                    <button type="submit" class="btn btn-primary btn-sm">تأیید و کسر از سهمیه</button>
                                </form>
                            <?php else: ?>
                                <span class="badge badge-success">✓ نهایی شد</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- ==================== PANE 7: LEARNER ==================== -->
<?php if (in_array('learner', $allowedTabs, true)): ?>
<div id="rolePane_learner" class="role-cockpit-pane" style="display:<?= $activeTab === 'learner' ? 'block' : 'none' ?>">
    <div class="card" style="border:1.5px solid rgba(15,118,110,0.4)">
        <div class="card-header">
            <div>
                <div class="card-title">🚀 برنامه توسعه فردی ۹۰ روزه فراگیر (Personal IDP) متصل به کیف پول XP</div>
                <div class="muted" style="font-size:12px">تولیدشده به صورت خودکار از روی نتایج آزمون‌های استاندارد، هم‌درس هوشمند ویدئو و بازارگاه اشتغال</div>
            </div>
            <span class="badge badge-success">تیک‌خور با پاداش آنی XP</span>
        </div>
        <div class="table-wrap">
            <table>
                <thead><tr><th>گام</th><th>هدف عملیاتی توسعه فردی</th><th>منشأ تشخیص هوشمند</th><th>پاداش تکمیل</th><th>مهلت هدف</th><th>وضعیت انجام</th></tr></thead>
                <tbody>
                <?php foreach ($ws['idp_steps'] as $st): ?>
                    <tr>
                        <td><strong>گام <?= fa($st['step_order']) ?></strong></td>
                        <td><strong><?= e($st['milestone_title']) ?></strong></td>
                        <td><span class="badge badge-info"><?= e($st['source_diagnostic']) ?></span></td>
                        <td><span class="badge badge-gold">+<?= fa($st['xp_bonus']) ?> XP</span></td>
                        <td><?= e($st['target_shamsi']) ?></td>
                        <td>
                            <?php if ((int)$st['is_done'] === 1): ?>
                                <span class="badge badge-success">✓ انجام و XP واریز شد</span>
                            <?php else: ?>
                                <form method="post" action="<?= e(url('role-workstations')) ?>">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action" value="complete_idp">
                                    <input type="hidden" name="step_id" value="<?= (int)$st['id'] ?>">
                                    <button type="submit" class="btn btn-gold btn-sm">تکمیل گام (+<?= fa($st['xp_bonus']) ?> XP)</button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- ==================== PANE 8: LOCAL CERTIFICATE RECORD LOOKUP ==================== -->
<?php if (in_array('guest', $allowedTabs, true)): ?>
<div id="rolePane_guest" class="role-cockpit-pane" style="display:<?= $activeTab === 'guest' ? 'block' : 'none' ?>">
    <div class="card" style="border:1.5px solid rgba(201,146,39,0.45)">
        <div class="card-header">
            <div>
                <div class="card-title">بررسی گروهی وضعیت گواهی‌ها در سوابق آدان</div>
                <div class="muted" style="font-size:12px">این بررسی فقط رکورد محلی را می‌خواند و امضا یا اعتبار بیرونی را تأیید نمی‌کند.</div>
            </div>
            <span class="badge badge-warning">وضعیت محلی؛ بدون امضای مستقل</span>
        </div>
        <form method="get" action="<?= e(url('role-workstations')) ?>" style="display:flex;gap:10px;margin-bottom:14px;flex-wrap:wrap">
            <input type="hidden" name="tab" value="guest">
            <input type="text" name="batch_codes" value="<?= e($batchQuery) ?>" dir="ltr" style="flex:1" placeholder="شماره‌های گواهی، جداشده با کاما">
            <button type="submit" class="btn btn-outline">بررسی سوابق محلی</button>
        </form>
        <div class="table-wrap">
            <table>
                <thead><tr><th>شماره سریال</th><th>وضعیت ثبت‌شده</th><th>نام دارنده</th><th>عنوان دوره</th><th>چکیدهٔ محلی (در صورت وجود)</th></tr></thead>
                <tbody>
                <?php foreach ($batchResults as $br): ?>
                    <tr>
                        <td dir="ltr"><code><?= e($br['serial']) ?></code></td>
                        <td>
                            <?php if ($br['state'] === 'valid'): ?>
                                <span class="badge badge-success">✅ معتبر در سوابق آدان</span>
                            <?php elseif ($br['state'] === 'revoked'): ?>
                                <span class="badge badge-danger">❌ لغوشده در سوابق آدان</span>
                            <?php else: ?>
                                <span class="badge badge-warning">یافت نشد</span>
                            <?php endif; ?>
                        </td>
                        <td><strong><?= e($br['holder']) ?></strong></td>
                        <td><?= e($br['course']) ?></td>
                        <td dir="ltr"><code><?= $br['hash'] ? e(substr((string)$br['hash'], 0, 22)) . '...' : '-' ?></code></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>
