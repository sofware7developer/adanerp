<?php
use App\Core\QrSvg;
?>
<div class="no-print" style="max-width:860px;margin:0 auto 16px;display:flex;justify-content:space-between;align-items:center">
    <a href="<?= e(url('office-automation')) ?>" class="btn btn-outline btn-sm">← بازگشت به کارتابل اتوماسیون اداری</a>
    <button type="button" onclick="window.print()" class="btn btn-primary btn-sm">🖨️ چاپ رسمی نامه روی سربرگ A4 / ذخیره PDF</button>
</div>

<?php if ($letter): ?>
<div class="card" style="max-width:860px;margin:0 auto;padding:42px 48px;border:2px solid #cbd5e1;color:#0f172a;background:#ffffff">
    <div style="text-align:center;font-weight:700;font-size:15px;margin-bottom:14px">بسمه تعالی</div>

    <div style="display:flex;justify-content:space-between;align-items:center;border-bottom:2.5px solid #0f172a;padding-bottom:18px;margin-bottom:26px">
        <div style="display:flex;align-items:center;gap:14px">
            <div class="brand-crest" style="width:52px;height:52px;font-size:18px">آدان</div>
            <div>
                <div style="font-size:17px;font-weight:800;color:#0f172a">مؤسسه آموزشی آدان</div>
                <div style="font-size:12.5px;color:#475569;margin-top:3px">مرکز آموزش، پژوهش و دبیرخانه مکاتبات رسمی • واحد: <?= e($letter['sender_unit']) ?></div>
            </div>
        </div>
        <div style="text-align:right;font-size:12.5px;line-height:1.9;min-width:195px">
            <div>شماره نامه: <strong><?= e($letter['indicator_no']) ?></strong></div>
            <div>تاریخ صدور: <strong><?= e($letter['created_shamsi']) ?></strong></div>
            <div>پیوست: <strong><?= e($letter['attachment_note'] ?: 'ندارد') ?></strong></div>
            <div>طبقه / فوریت: <strong><?= e($letter['confidentiality']) ?> / <?= e($letter['priority_level']) ?></strong></div>
        </div>
    </div>

    <div style="margin-bottom:20px;font-size:14.5px;line-height:2">
        <div><strong>گیرنده کارتابل: <?= e($letter['recipient_name'] ?: $letter['recipient_org']) ?></strong></div>
        <?php if (!empty($letter['external_recipient'])): ?>
            <div><strong>مقصد بیرونی: <?= e($letter['external_recipient']) ?></strong></div>
        <?php endif; ?>
        <div><strong>موضوع: <?= e($letter['subject_title']) ?></strong></div>
    </div>

    <div style="font-size:14px;line-height:2.25;text-align:justify;min-height:210px;margin-bottom:32px;white-space:pre-line">
        <?= e($letter['letter_body']) ?>
    </div>

    <div style="display:flex;justify-content:space-between;align-items:flex-end;margin-top:36px;padding-top:20px;border-top:1px dashed #cbd5e1">
        <div style="text-align:center">
            <?= QrSvg::render('LETTER|' . $letter['indicator_no'] . '|' . $letter['qr_verify_code'], 92) ?>
            <div style="font-size:10.5px;color:#64748b;margin-top:4px">شناسه اصالت دبیرخانه: <code><?= e($letter['qr_verify_code']) ?></code></div>
        </div>
        <div style="text-align:center;min-width:240px">
            <div style="font-size:12.5px;color:#475569;margin-bottom:6px">با تشکر و تجدید احترام</div>
            <div style="font-size:14.5px;font-weight:800"><?= e($letter['signatory_name']) ?></div>
            <div style="margin-top:8px;display:inline-block;padding:3px 12px;border-radius:999px;background:#ecfdf5;color:#059669;font-size:11.5px;font-weight:700">
                ✓ <?= e($letter['sign_status']) ?>
            </div>
        </div>
    </div>

    <?php if (!empty($referrals)): ?>
        <div style="margin-top:26px;padding-top:14px;border-top:1px solid #e2e8f0;font-size:12px;color:#475569">
            <strong>رونوشت و هامش‌های ثبت‌شده در اتوماسیون اداری:</strong>
            <ul style="margin:6px 18px 0 0;line-height:1.9">
                <?php foreach ($referrals as $rf): ?>
                    <li><strong><?= e($rf['to_person_unit']) ?></strong> (<?= e($rf['action_command']) ?>): <?= e($rf['paraph_margin_note']) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>
</div>
<?php endif; ?>
