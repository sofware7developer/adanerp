<?php use App\Core\QrSvg; ?>
<div class="card" style="max-width:960px;margin:0 auto">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px" class="no-print">
        <span class="badge badge-gold">نسخه رسمی چاپی مستندات جامع سیستم (Master ERP Operations Manual — v21.0)</span>
        <button type="button" onclick="window.print()" class="btn btn-primary btn-sm">🖨️ چاپ یا ذخیره PDF کتابچه کامل (A4)</button>
    </div>

    <div class="cert-frame">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:16px;flex-wrap:wrap;border-bottom:2px solid #c99227;padding-bottom:14px;margin-bottom:18px">
            <div>
                <h1 style="font-size:21px;margin-bottom:4px">کتابچه جامع راهنمای بهره‌برداری، نقش‌های سازمانی و مستندات ۷۷ مسیر سامانه ERP</h1>
                <div style="font-size:13px;color:#0f766e;font-weight:800">نسخه مرجع v21.0 | بخش‌های سامانه تخصصی | بخش‌های تخصصی مهندسی | ۱۶۰ جدول فعال MariaDB</div>
            </div>
            <div style="text-align:center">
                <?= QrSvg::render(url('help-center'), 92) ?>
                <div style="font-size:10.5px;margin-top:4px">دانشنامه آنلاین</div>
            </div>
        </div>

        <h3 style="font-size:15px;margin-bottom:8px">بخش اول: دستورالعمل اجرایی ۸ نقش سازمانی</h3>
        <div class="table-wrap" style="margin-bottom:18px">
            <table>
                <thead><tr><th>نقش سازمانی</th><th>شرح وظایف و گردش‌کار استاندارد روزانه در سامانه</th></tr></thead>
                <tbody>
                    <?php foreach ($playbooks as $slug => $pb): ?>
                        <tr>
                            <td><strong><?= e($pb['title']) ?></strong><br><code><?= e($slug) ?></code></td>
                            <td><?= e($pb['daily']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <h3 style="font-size:15px;margin-bottom:8px">بخش دوم: فهرست کامل راهنمای اختصاصی تمام <?= fa(count($allGuides)) ?> مسیر سامانه</h3>
        <div class="table-wrap">
            <table>
                <thead><tr><th>مسیر</th><th>عنوان و هدف اختصاصی صفحه</th><th>نکته کلیدی کنترلی</th></tr></thead>
                <tbody>
                    <?php foreach ($allGuides as $rk => $g): ?>
                        <tr>
                            <td><code>/<?= e($rk) ?></code></td>
                            <td><strong><?= e($g['title']) ?></strong><br><span style="font-size:12px"><?= e($g['mission']) ?></span></td>
                            <td style="font-size:12px"><?= e($g['golden_tip']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
