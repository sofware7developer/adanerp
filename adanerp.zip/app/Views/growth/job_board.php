<div class="hero-banner">
    <div>
        <span class="badge badge-gold">اتصال مستقیم آموزش به اشتغال تخصصی صنایع استان</span>
        <h1>بازارگاه اشتغال تخصصی و همرسانی دانش‌آموختگان دارای گواهی به صنایع عضو</h1>
        <p>معرفی مستقیم فارغ‌التحصیلان دوره‌های مؤسسه آموزشی آدان (کارشناس صادرات، ترخیص‌کار، حسابدار مالیاتی) به فرصت‌های شغلی کارخانجات عضو.</p>
    </div>
</div>

<div class="grid grid-sidebar">
    <div class="card">
        <div class="card-header"><div class="card-title">💼 فرصت‌های شغلی تخصصی اعلام‌شده توسط شرکت‌های طرف قرارداد مؤسسه آموزشی آدان</div></div>
        <?php foreach ($jobs as $j): ?>
            <div style="border:1px solid var(--border);border-radius:14px;padding:14px;margin-bottom:12px;display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap">
                <div>
                    <strong><?= e($j['job_title']) ?></strong> — <span class="badge badge-purple"><?= e($j['org_name']) ?></span>
                    <div class="muted" style="font-size:12px;margin-top:4px">
                        گواهی موردنیاز: <strong><?= e($j['required_cert_code']) ?></strong> | محل: <?= e($j['city']) ?> | حقوق: <?= e($j['salary_range']) ?>
                    </div>
                </div>
                <div style="display:flex;gap:8px;align-items:center">
                    <span class="badge badge-success"><?= fa($j['matched_candidates']) ?> کاندیدای همرسانی‌شده</span>
                    <form method="post" action="<?= e(url('job-board')) ?>">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="apply_job">
                        <input type="hidden" name="job_id" value="<?= (int)$j['id'] ?>">
                        <button type="submit" class="btn btn-gold btn-sm">ارسال گذرنامه مهارت</button>
                    </form>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="card">
        <div class="card-header"><div class="card-title">➕ ثبت نیاز استخدامی بنگاه عضو</div></div>
        <form method="post" action="<?= e(url('job-board')) ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="post_job">
            <div class="form-group"><input type="text" name="org_name" value="مجتمع پتروشیمی و پلیمر استان" required></div>
            <div class="form-group"><input type="text" name="job_title" value="کارشناس قراردادهای بین‌المللی و اعتبارات اسنادی" required></div>
            <div class="form-group"><input type="text" name="required_cert_code" value="گواهی آکادمی تجارت بین‌الملل اتاق" required></div>
            <div class="form-grid">
                <input type="text" name="city" value="مرکز استان" required>
                <input type="text" name="salary_range" value="۴۰ تا ۵۵ میلیون تومان" required>
            </div>
            <button type="submit" class="btn btn-primary" style="margin-top:10px;width:100%">انتشار در بازارگاه اشتغال اتاق</button>
        </form>
    </div>
</div>

<!-- v15.0 AI CV-TO-JOB VECTOR MATCHER & INTERVIEW GENERATOR -->
<div class="card" style="margin-top:18px;border:1.5px solid rgba(15,118,110,0.35)">
    <div class="card-header">
        <div>
            <div class="card-title">🧠 همرسان برداری رزومه و تولیدکننده سؤالات مصاحبه فنی کارخانجات (AI CV Matcher &amp; Interview Guide)</div>
            <div class="muted" style="font-size:12px">تطبیق گواهی‌های رسمی اخذشده از اتاق با نیازمندی شغلی کارخانه عضو + تولید بسته سؤالات استاندارد مصاحبه</div>
        </div>
        <span class="badge badge-gold">تطبیق شایستگی ۹۶٪</span>
    </div>
    <form method="post" action="<?= e(url('job-board')) ?>" class="grid grid-4" style="gap:10px;align-items:end;margin-bottom:14px">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="ai_cv_interview">
        <div><label>نام دانش‌آموخته دارای گواهی:</label><input type="text" name="candidate_name" value="مهندس نیما فرهادی" required></div>
        <div><label>بنگاه صنعتی متقاضی جذب:</label><input type="text" name="target_company" value="مجتمع فولاد و ذوب‌آهن زاگرس" required></div>
        <div><label>سمت شغلی هدف:</label><input type="text" name="target_role" value="مسئول بازرگانی خارجی و سفارشات" required></div>
        <div><input type="hidden" name="verified_certs_summary" value="گواهی Incoterms 2020 + UCP600 + سامانه جامع تجارت"><button type="submit" class="btn btn-gold" style="width:100%">تولید کارنامه همرسانی و مصاحبه</button></div>
    </form>
    <div class="table-wrap">
        <table>
            <thead><tr><th>کد همرسانی</th><th>نام کاندیدا</th><th>کارفرمای عضو</th><th>سمت تخصصی</th><th>تشابه برداری</th><th>راهنمای سؤالات مصاحبه تخصصی تولیدشده</th></tr></thead>
            <tbody>
            <?php foreach (($cvMatches ?? []) as $cm): ?>
                <tr>
                    <td><code><?= e($cm['match_code']) ?></code></td>
                    <td><strong><?= e($cm['candidate_name']) ?></strong></td>
                    <td><?= e($cm['target_company']) ?></td>
                    <td><?= e($cm['target_role']) ?></td>
                    <td><span class="badge badge-success"><?= fa($cm['vector_similarity_pct']) ?>٪ تطابق</span></td>
                    <td style="font-size:11.5px;max-width:340px"><?= e($cm['generated_interview_guide']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

