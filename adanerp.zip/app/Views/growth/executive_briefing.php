<div class="hero-banner">
    <div>
        <span class="badge badge-gold">ماژول راهبردی ۴۲ | بولتن سخنگوی صبحگاهی مدیر مؤسسه آدان + موتور جست‌وجوی معنایی قوانین (RAG) + قیمت‌گذاری پویا</span>
        <h1>مرکز هوش اجرایی مدیرعامل: گزارش صوتی ۶۰ ثانیه‌ای، کاوشگر مواد قانونی (RAG) و قیمت‌گذاری پویا</h1>
        <p>
            سنتز لحظه‌ای کل <strong><?= fa($briefing['tables_count']) ?> جدول عملیاتی ERP</strong> در قالب گزارش صبحگاهی سخنگو ویژه رئیس و مدیرکل مؤسسه، موتور بازیابی استنادی مواد قانونی (مالیاتی، گمرکی، اینکوترمز و اتاق) و بهینه‌ساز قیمت‌گذاری پویا صندلی‌های آموزشی.
        </p>
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
        <button type="button" class="btn btn-gold" onclick="window.speakPersianReply(document.getElementById('ceoMorningText').textContent)">پخش صوتی گزارش ۶۰ ثانیه‌ای صبحگاهی مدیرعامل</button>
    </div>
</div>

<!-- 1. EXECUTIVE MORNING BRIEFING CARD -->
<div class="card" style="margin-bottom:18px;border:1.5px solid rgba(201,146,39,0.45);background:linear-gradient(120deg,rgba(11,31,58,0.04),rgba(201,146,39,0.08))">
    <div class="card-header" style="align-items:center">
        <div class="card-title">بولتن تحلیلی-سخنگوی صبحگاهی رئیس و مدیریت مؤسسه آدان (AI Executive Morning Briefing)</div>
        <span class="badge badge-success">زنده از روی <?= fa($briefing['tables_count']) ?> جدول</span>
    </div>
    <p id="ceoMorningText" style="font-size:13.5px;line-height:2;font-weight:600;margin-bottom:10px"><?= e($briefing['spoken_briefing']) ?></p>
</div>

<!-- 2. SEMANTIC LEGAL & CUSTOMS RAG ENGINE -->
<div class="card" style="margin-bottom:18px;border:1.5px solid rgba(15,118,110,0.32)">
    <div class="card-header">
        <div>
            <div class="card-title">موتور جست‌وجوی معنایی و استنادی قوانین تجاری، مالیاتی و بخشنامه‌های گمرکی (Enterprise Legal RAG)</div>
            <div class="muted" style="font-size:12px">بازیابی دقیق ماده قانونی و مرجع تصویب برای پاسخ‌گویی مستند به سؤالات فراگیران آدان</div>
        </div>
        <span class="badge badge-purple">استناد دقیق ماده قانونی</span>
    </div>
    <form method="get" action="<?= e(url('digital-twin-bi')) ?>" style="display:flex;gap:8px;margin-bottom:14px" onsubmit="if(!window.location.protocol.startsWith('http')||typeof PAGES!=='undefined'){event.preventDefault();window.filterRagClient();}">
        <input type="text" id="ragSearchInput" name="q" value="<?= e($ragQuery) ?>" placeholder="مثلاً: معافیت مالیات ارزش افزوده آموزش، تفاوت کلوز بیمه CIF و CIP، ماده ۲ قانون بهبود کسب‌وکار...">
        <button type="submit" class="btn btn-primary" style="white-space:nowrap">جست‌وجوی معنایی مستند</button>
    </form>

    <div class="grid grid-2" style="gap:12px" id="ragCardsContainer">
        <?php foreach ($ragResults as $rg): ?>
            <div class="rag-chunk-item" style="padding:14px;border-radius:12px;background:var(--surface-2);border:1px solid var(--border)">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
                    <span class="badge badge-info"><?= e($rg['clause_reference']) ?></span>
                    <span class="badge badge-success">تطابق معنایی: <?= fa($rg['relevance_pct']) ?>٪</span>
                </div>
                <div style="font-size:11.5px;color:var(--primary);font-weight:800;margin-bottom:4px"><?= e($rg['source_authority']) ?></div>
                <div style="font-size:12.5px;line-height:1.8"><?= e($rg['chunk_text']) ?></div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- 3. DYNAMIC YIELD PRICING ENGINE -->
<div class="card">
    <div class="card-header" style="align-items:center">
        <div>
            <div class="card-title">موتور قیمت‌گذاری پویا ظرفیت کلاس‌ها به سبک خطوط هوایی (AI Dynamic Yield Pricing)</div>
            <div class="muted" style="font-size:12px">تنظیم خودکار نرخ Early-Bird، تخفیف تکمیل صندلی ۷۲ ساعت پایانی و افتتاح کلاس دوم در تقاضای اوج</div>
        </div>
        <form method="post" action="<?= e(url('digital-twin-bi')) ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="recalc_yield_pricing">
            <button type="submit" class="btn btn-gold btn-sm">بازمحاسبه نرخ‌های پویا امروز</button>
        </form>
    </div>
    <div class="table-wrap">
        <table>
            <thead><tr><th>کد و عنوان دوره</th><th>شهریه پایه</th><th>تکمیل صندلی / زمان مانده</th><th>استراتژی تجویزی هوش مصنوعی</th><th>نرخ پویا فعلی</th><th>رشد درآمد خالص</th></tr></thead>
            <tbody>
            <?php foreach ($pricingRules as $pr): ?>
                <tr>
                    <td><strong><?= e($pr['course_title']) ?></strong><div class="muted" style="font-size:11px"><?= e($pr['course_code']) ?></div></td>
                    <td><?= rial($pr['base_tuition_rial']) ?></td>
                    <td><?= fa($pr['seat_fill_pct']) ?>٪ پر | <?= fa($pr['days_to_start']) ?> روز مانده</td>
                    <td><span class="badge badge-purple"><?= e($pr['ai_pricing_tier']) ?></span></td>
                    <td><strong><?= rial($pr['dynamic_tuition_rial']) ?></strong></td>
                    <td><span class="badge badge-success">+<?= fa($pr['projected_revenue_gain_pct']) ?>٪ رشد درآمد</span></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
