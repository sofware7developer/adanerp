<div class="hero-banner">
    <div>
        <span class="badge badge-gold">استانداردهای بین‌المللی کیفیت آموزش</span>
        <h1>تضمین کیفیت آموزش، ممیزی استاندارد ISO 21001 / ISO 10015 و ثبت CAPA</h1>
        <p>مدیریت شواهد ممیزی ایزو و مجوزهای رسمی آموزشی، ثبت عدم انطباق‌ها و پیگیری اقدامات اصلاحی و پیشگیرانه (CAPA).</p>
    </div>
</div>

<div class="grid grid-sidebar">
    <div class="card">
        <div class="card-header"><div class="card-title">🏅 دفتر ثبت ممیزی‌های کیفیت و اقدامات اصلاحی (CAPA)</div></div>
        <div class="table-wrap">
            <table>
                <thead><tr><th>استاندارد</th><th>بند ممیزی</th><th>نوع یافته</th><th>اقدام اصلاحی (CAPA)</th><th>وضعیت</th></tr></thead>
                <tbody>
                <?php foreach ($records as $r): ?>
                    <tr>
                        <td><code><?= e($r['standard_code']) ?></code></td>
                        <td><strong><?= e($r['clause_title']) ?></strong></td>
                        <td><span class="badge badge-info"><?= e($r['finding_type']) ?></span></td>
                        <td><?= e($r['capa_action']) ?></td>
                        <td><span class="badge badge-success"><?= e($r['status']) ?></span></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card">
        <div class="card-header"><div class="card-title">➕ ثبت یافته ممیزی و اقدام اصلاحی جدید</div></div>
        <form method="post" action="<?= e(url('iso-qa')) ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="add_qa_record">
            <div class="form-group">
                <select name="standard_code">
                    <option value="ISO 21001:2018">ISO 21001:2018 (سیستم مدیریت سازمان‌های آموزشی)</option>
                    <option value="ISO 10015:2019">ISO 10015:2019 (مدیریت شایستگی و توسعه افراد)</option>
                    <option value="ISO 29993:2017">ISO 29993:2017 (خدمات یادگیری غیررسمی)</option>
                </select>
            </div>
            <div class="form-group"><input type="text" name="clause_title" value="بند ۷.۲ — صلاحیت علمی و حرفه‌ای مدرسان مدعو" required></div>
            <div class="form-group">
                <select name="finding_type"><option value="انطباق کامل">انطباق کامل</option><option value="فرصت بهبود">فرصت بهبود</option><option value="عدم انطباق جزئی">عدم انطباق جزئی</option></select>
            </div>
            <div class="form-group"><textarea name="capa_action" rows="2" required>بازنگری فرم ارزشیابی پایان ترم اساتید در بخش تخصصی</textarea></div>
            <input type="hidden" name="owner_unit" value="واحد تضمین کیفیت آموزش">
            <button type="submit" class="btn btn-primary" style="width:100%">ثبت در پرونده ایزو</button>
        </form>
    </div>
</div>

<div class="card" style="margin-top:16px">
    <div class="card-header"><div class="card-title">🔍 ماتریس ریشه‌یابی سیستماتیک ۵ چرا (5-Whys Root Cause CAPA — الزام بند ۱۰.۱ استاندارد ISO 21001)</div></div>
    <div class="table-wrap">
        <table>
            <thead><tr><th>کد عدم انطباق</th><th>چرا ۱ (رخداد سطحی)</th><th>چرا ۲ ← چرا ۴ (ریشه فرایندی)</th><th>چرا ۵ (ریشه سیستمی و اقدام اصلاحی دائمی)</th><th>وضعیت اثربخشی</th></tr></thead>
            <tbody>
                <tr>
                    <td><strong>CAPA-1405-04</strong></td>
                    <td>افت ۱۲٪ نرخ تکمیل تکالیف عملی کارگاه LC</td>
                    <td>فشردگی تمرین‌ها در هفته پایانی بدون پیش‌آزمون تشخیصی</td>
                    <td>الزامی شدن کوئیز میانی در بخش تخصصی (LMS) پیش از باز شدن کارگاه شبیه‌ساز</td>
                    <td><span class="badge badge-success">✓ اثربخش و مختومه</span></td>
                </tr>
                <tr>
                    <td><strong>CAPA-1405-07</strong></td>
                    <td>تأخیر ۴۸ ساعته در صدور گواهی گروهی شرکت صنعتی</td>
                    <td>کنترل دستی تسویه چک صیادی شرکت با واحد مالی</td>
                    <td>اتصال خودکار زنجیره بخش‌های سامانهه  به دفترکل و صدور آنی گواهی QR</td>
                    <td><span class="badge badge-success">✓ مکانیزه کامل در v8.0</span></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
