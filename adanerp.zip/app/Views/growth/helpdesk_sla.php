<?php $isLearnerHd = \App\Core\Auth::role() === 'learner'; if ($isLearnerHd && in_array($activeTab, ['requests', 'templates'], true)) { $activeTab = 'tickets'; } ?>
<div class="hero-banner">
    <div>
        <span class="badge badge-gold" style="margin-bottom:8px">میز خدمت چندواحدی SLA، خدمات اداری فراگیران و موتور قالب پیامک/اعلان خودکار</span>
        <h1>مرکز میز خدمت، تیکتینگ پشتیبانی (SLA)، درخواست‌های آموزشی و قالب‌های اعلان</h1>
        <p>مدیریت زمان‌سنجیده تیکت‌های فراگیران و کارخانجات عضو، صدور گواهی اشتغال به تحصیل/دوره و ویرایش متغیرهای پویای پیامک‌های خدماتی و بازوهای بله و ایتا.</p>
    </div>
    <div class="hero-actions">
        <?= \App\Core\App::safeLink('academic-erp-core', '🎓 تقویم، حضور و غیاب و کارنامه', 'btn btn-gold') ?>
    </div>
</div>

<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:18px">
    <button type="button" class="btn <?= $activeTab === 'tickets' ? 'btn-gold' : 'btn-outline' ?> btn-sm hd-tab-btn" onclick="switchHdTab('tickets', this)">🎧 ۱. تیکتینگ چندواحدی با تضمین SLA</button>
<?php if (!$isLearnerHd): ?>
    <button type="button" class="btn <?= $activeTab === 'requests' ? 'btn-gold' : 'btn-outline' ?> btn-sm hd-tab-btn" onclick="switchHdTab('requests', this)">📄 ۲. گواهی اشتغال به دوره، معادل‌سازی و مرخصی آموزشی</button>
    <button type="button" class="btn <?= $activeTab === 'templates' ? 'btn-gold' : 'btn-outline' ?> btn-sm hd-tab-btn" onclick="switchHdTab('templates', this)">📲 ۳. قالب‌های پیامک و اعلان خودکار رویدادها</button>
<?php endif; ?>
</div>

<!-- تب ۱: تیکتینگ SLA -->
<div id="hdPanel_tickets" class="hd-panel" style="display:<?= $activeTab === 'tickets' ? 'block' : 'none' ?>">
    <div class="grid grid-3">
        <div class="card">
            <div class="card-header"><div class="card-title">➕ ثبت تیکت پشتیبانی جدید</div></div>
            <form method="post">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="create_ticket">
                <div class="form-group"><label>نام درخواست‌کننده:</label><input type="text" name="requester_name" value="مهندس مهرداد شریفی" required></div>
                <div class="form-group">
                    <label>واحد تخصصی مقصد:</label>
                    <select name="department_unit">
                        <option>آموزش و برنامه‌ریزی کلاس‌ها</option>
                        <option>امور مالی و فاکتور رسمی مؤدیان</option>
                        <option>امتحانات و صدور گواهی QR</option>
                        <option>پشتیبانی فنی کلاس آنلاین اسکای‌روم</option>
                        <option>واحد کاریابی و ارتباط با صنعت</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>سطح اولویت و SLA پاسخگویی:</label>
                    <select name="priority_level">
                        <option value="بالا (فوری)">🔥 بالا / فوری (SLA حداکثر ۴ ساعت)</option>
                        <option value="عادی">📋 عادی اداری (SLA حداکثر ۸ ساعت)</option>
                    </select>
                </div>
                <div class="form-group"><label>موضوع و شرح دقیق درخواست:</label><textarea name="subject_line" rows="3" required placeholder="شرح درخواست آموزشی، مالی یا فنی..."></textarea></div>
                <button type="submit" class="btn btn-primary" style="width:100%">ثبت تیکت و صدور کد رهگیری</button>
            </form>
        </div>

        <div class="card" style="grid-column:span 2">
            <div class="card-header"><div class="card-title">📬 کارتابل تیکت‌های فعال و پاسخ رسمی کارشناسان</div></div>
            <div class="table-wrap">
                <table>
                    <thead><tr><th>کد تیکت</th><th>درخواست‌کننده / واحد</th><th>شرح موضوع و پاسخ رسمی</th><th>SLA</th><th>وضعیت / ثبت پاسخ</th></tr></thead>
                    <tbody>
                        <?php foreach ($hd['tickets'] as $t): ?>
                            <tr>
                                <td><code><?= e($t['ticket_no']) ?></code><div class="muted" style="font-size:11px"><?= e($t['created_shamsi']) ?></div></td>
                                <td><strong><?= e($t['requester_name']) ?></strong><div class="muted" style="font-size:11.5px"><?= e($t['department_unit']) ?></div></td>
                                <td>
                                    <div><?= e($t['subject_line']) ?></div>
                                    <?php if (!empty($t['official_reply'])): ?>
                                        <div style="margin-top:6px;padding:6px 10px;border-radius:8px;background:var(--success-soft);font-size:12px"><strong>پاسخ واحد:</strong> <?= e($t['official_reply']) ?></div>
                                    <?php endif; ?>
                                </td>
                                <td><span class="badge badge-gold"><?= fa($t['sla_hours']) ?> ساعت</span></td>
                                <td>
                                    <span class="badge badge-<?= str_contains($t['ticket_status'], '✅') ? 'success' : 'warning' ?>"><?= e($t['ticket_status']) ?></span>
                                    <?php if (!$isLearnerHd && !str_contains($t['ticket_status'], '✅')): ?>
                                        <form method="post" style="margin-top:6px;display:flex;gap:4px">
                                            <?= csrf_field() ?>
                                            <input type="hidden" name="action" value="reply_ticket">
                                            <input type="hidden" name="ticket_id" value="<?= (int)$t['id'] ?>">
                                            <input type="text" name="official_reply" placeholder="پاسخ رسمی..." required style="padding:4px 8px;font-size:11.5px">
                                            <button type="submit" class="btn btn-primary btn-sm">ارسال</button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- تب ۲: درخواست‌های اداری فراگیران -->
<div id="hdPanel_requests" class="hd-panel" style="display:<?= $activeTab === 'requests' ? 'block' : 'none' ?>">
<?php if (!$isLearnerHd): ?>
    <div class="grid grid-2">
        <div class="card">
            <div class="card-header"><div class="card-title">📄 ثبت و صدور فوری گواهی اشتغال به تحصیل/دوره یا معادل‌سازی</div></div>
            <form method="post">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="save_admin_entry">
                <input type="hidden" name="record_category" value="student_request">
                <div class="form-group"><label>نام فراگیر متقاضی:</label><input type="text" name="applicant_or_event" value="مهندس مهرداد شریفی" required></div>
                <div class="form-group">
                    <label>نوع گواهی / درخواست اداری:</label>
                    <select name="request_type_or_channel">
                        <option>گواهی اشتغال به تحصیل/دوره رسمی جهت کارفرما یا بانک</option>
                        <option>درخواست معادل‌سازی گواهی دوره تخصصی پیشین</option>
                        <option>مرخصی موجه آموزشی و انتقال به کد بعدی دوره</option>
                    </select>
                </div>
                <div class="form-group"><label>شرح و مرجع مقصد گواهی:</label><textarea name="body_or_template" rows="3" required>جهت ارائه به مدیریت منابع انسانی مجتمع فولاد زاگرس مبنی بر شرکت فعال در دوره جامع تجارت بین‌الملل.</textarea></div>
                <button type="submit" class="btn btn-gold">صدور و ثبت در پرونده آموزشی</button>
            </form>
        </div>

        <div class="card">
            <div class="card-header"><div class="card-title">🗂️ فهرست گواهی‌های اشتغال به دوره و درخواست‌های اداری</div></div>
            <div class="table-wrap">
                <table>
                    <thead><tr><th>کد مدرک</th><th>متقاضی</th><th>نوع درخواست</th><th>وضعیت</th></tr></thead>
                    <tbody>
                        <?php foreach ($hd['requests'] as $rq): ?>
                            <tr>
                                <td><code><?= e($rq['entry_code']) ?></code></td>
                                <td><strong><?= e($rq['applicant_or_event']) ?></strong></td>
                                <td><?= e($rq['request_type_or_channel']) ?><div class="muted" style="font-size:11.5px"><?= e($rq['body_or_template']) ?></div></td>
                                <td><span class="badge badge-success"><?= e($rq['approval_state']) ?></span></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php endif; ?>
</div>

<!-- تب ۳: قالب‌های پیامک و اعلان خودکار -->
<?php if (!$isLearnerHd): ?>
<div id="hdPanel_templates" class="hd-panel" style="display:<?= $activeTab === 'templates' ? 'block' : 'none' ?>">
    <div class="grid grid-2">
        <div class="card">
            <div class="card-header"><div class="card-title">📲 افزودن قالب پیامک / اعلان رویداد محور جدید</div></div>
            <form method="post">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="save_admin_entry">
                <input type="hidden" name="record_category" value="notif_template">
                <div class="form-group"><label>رویداد ماشه‌چکان سیستم (Trigger):</label><input type="text" name="applicant_or_event" value="رویداد: یادآوری ۲۴ ساعت پیش از شروع کلاس" required></div>
                <div class="form-group"><label>کانال ارسال خودکار:</label><input type="text" name="request_type_or_channel" value="پیامک خدماتی + بازوی بله و ایتا" required></div>
                <div class="form-group"><label>متن قالب حاوی متغیرهای پویا:</label><textarea name="body_or_template" rows="3" required>یادآوری: فراگیر گرامی {full_name}، جلسه دوره «{course_title}» فردا ساعت {class_time} برگزار می‌گردد.</textarea></div>
                <button type="submit" class="btn btn-primary">ذخیره قالب اعلان سیستمی</button>
            </form>
        </div>

        <div class="card">
            <div class="card-header"><div class="card-title">🔔 قالب‌های فعال پیامک و اعلان خودکار ERP</div></div>
            <div class="table-wrap">
                <table>
                    <thead><tr><th>کد قالب</th><th>رویداد سیستم</th><th>متن پویا</th></tr></thead>
                    <tbody>
                        <?php foreach ($hd['templates'] as $tpl): ?>
                            <tr>
                                <td><code><?= e($tpl['entry_code']) ?></code><div class="badge badge-info" style="margin-top:4px"><?= e($tpl['request_type_or_channel']) ?></div></td>
                                <td><strong><?= e($tpl['applicant_or_event']) ?></strong></td>
                                <td style="font-size:12.5px"><?= e($tpl['body_or_template']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<script>
function switchHdTab(tab, btn) {
    document.querySelectorAll('.hd-panel').forEach(p => p.style.display = 'none');
    document.getElementById('hdPanel_' + tab).style.display = 'block';
    document.querySelectorAll('.hd-tab-btn').forEach(b => { b.classList.remove('btn-gold'); b.classList.add('btn-outline'); });
    btn.classList.remove('btn-outline'); btn.classList.add('btn-gold');
}
</script>
