<?php
$kpis = $bundle['kpis'];
?>
<div class="hero-banner">
    <div>
        <span class="badge badge-gold" style="margin-bottom:8px">دبیرخانه مرکزی و گردش مکاتبات بدون کاغذ</span>
        <h1>اتوماسیون اداری، کارتابل نامه‌ها و مکاتبات رسمی</h1>
        <p>ثبت و شماره‌گذاری خودکار نامه‌های وارده، صادره و داخلی، پاراف و ارجاع چندمرحله‌ای، امضای دیجیتال با سربرگ رسمی چاپی، مرخصی و مأموریت پرسنل و پیگیری مصوبات جلسات.</p>
    </div>
    <div class="hero-actions">
        <button type="button" class="btn btn-primary" onclick="switchOaTab('compose', document.getElementById('oaBtnCompose'))">+ ثبت و نگارش نامه جدید</button>
        <span class="badge" style="background:rgba(255,255,255,0.12);color:#fff;border-color:rgba(255,255,255,0.25)">کارتابل شخصی، دفتر اندیکاتور و گردش قابل پیگیری</span>
    </div>
</div>

<!-- شاخص‌های کلیدی اتوماسیون اداری -->
<div class="grid grid-4">
    <div class="stat-card">
        <div>
            <div class="stat-label">نامه‌های خوانده‌نشده</div>
            <div class="stat-value"><?= fa($kpis['unread_letters']) ?> نامه</div>
            <div class="stat-meta">ارسال‌شده مستقیم به کارتابل شما</div>
        </div>
        <div class="stat-icon icon-gold">📥</div>
    </div>
    <div class="stat-card">
        <div>
            <div class="stat-label">ارجاعات و پاراف‌های باز</div>
            <div class="stat-value"><?= fa($kpis['open_referrals']) ?> مورد</div>
            <div class="stat-meta">در دست اقدام واحدهای اجرایی</div>
        </div>
        <div class="stat-icon icon-gold">↪️</div>
    </div>
    <div class="stat-card">
        <div>
            <div class="stat-label">درخواست‌های اداری منتظر تأیید</div>
            <div class="stat-value"><?= fa($kpis['pending_requests']) ?> درخواست</div>
            <div class="stat-meta">مرخصی، حکم مأموریت و تنخواه</div>
        </div>
        <div class="stat-icon icon-purple">📋</div>
    </div>
    <div class="stat-card">
        <div>
            <div class="stat-label">صورت‌جلسات و مصوبات</div>
            <div class="stat-value"><?= fa($kpis['minutes_count']) ?> جلسه</div>
            <div class="stat-meta">پیگیری مسئول اقدام و مهلت اجرا</div>
        </div>
        <div class="stat-icon icon-green">🏛️</div>
    </div>
</div>

<!-- تب‌های اتوماسیون اداری -->
<div class="tabs">
    <button type="button" id="oaBtnInbox" class="tab-btn <?= $activeTab === 'inbox' ? 'active' : '' ?>" onclick="switchOaTab('inbox', this)">📥 کارتابل مکاتبات</button>
    <button type="button" id="oaBtnCompose" class="tab-btn <?= $activeTab === 'compose' ? 'active' : '' ?>" onclick="switchOaTab('compose', this)">✍️ ثبت نامه و قالب‌های آماده</button>
    <button type="button" id="oaBtnReferrals" class="tab-btn <?= $activeTab === 'referrals' ? 'active' : '' ?>" onclick="switchOaTab('referrals', this)">↪️ پاراف و گردش ارجاعات</button>
    <button type="button" id="oaBtnRequests" class="tab-btn <?= $activeTab === 'requests' ? 'active' : '' ?>" onclick="switchOaTab('requests', this)">🗂️ مرخصی، مأموریت و تنخواه</button>
    <button type="button" id="oaBtnMinutes" class="tab-btn <?= $activeTab === 'minutes' ? 'active' : '' ?>" onclick="switchOaTab('minutes', this)">📑 صورت‌جلسات و مصوبات</button>
</div>

<!-- تب ۱: کارتابل مکاتبات -->
<div id="oaPanel_inbox" class="oa-panel" style="display:<?= $activeTab === 'inbox' ? 'block' : 'none' ?>">
    <div class="card">
        <div class="card-header">
            <div class="card-title">کارتابل نامه‌های اداری و دفتر اندیکاتور دبیرخانه</div>
            <div style="display:flex;gap:6px;flex-wrap:wrap">
                <a href="<?= e(url('office-automation', ['tab' => 'inbox', 'box' => 'inbox'])) ?>" class="btn <?= $box === 'inbox' ? 'btn-primary' : 'btn-outline' ?> btn-sm">📥 وارده به کارتابل من</a>
                <a href="<?= e(url('office-automation', ['tab' => 'inbox', 'box' => 'sent'])) ?>" class="btn <?= $box === 'sent' ? 'btn-primary' : 'btn-outline' ?> btn-sm">📤 ارسالی‌های من</a>
                <a href="<?= e(url('office-automation', ['tab' => 'inbox', 'box' => 'archived'])) ?>" class="btn <?= $box === 'archived' ? 'btn-primary' : 'btn-outline' ?> btn-sm">🗄️ بایگانی من</a>
                <?php if ($canViewAll): ?>
                    <a href="<?= e(url('office-automation', ['tab' => 'inbox', 'box' => 'all'])) ?>" class="btn <?= $box === 'all' ? 'btn-primary' : 'btn-outline' ?> btn-sm">دفتر کل دبیرخانه</a>
                <?php endif; ?>
                <?php foreach (['all' => 'همه انواع', 'وارده' => 'وارده', 'صادره' => 'صادره', 'داخلی' => 'داخلی', 'urgent' => 'فوری / آنی'] as $filterKey => $filterLabel): ?>
                    <a href="<?= e(url('office-automation', ['tab' => 'inbox', 'box' => $box, 'filter' => $filterKey])) ?>" class="btn <?= $typeFilter === $filterKey ? ($filterKey === 'urgent' ? 'btn-gold' : 'btn-outline') : 'btn-outline' ?> btn-sm"><?= e($filterLabel) ?></a>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="table-wrap">
            <table>
                <thead>
                <tr>
                    <th>شماره اندیکاتور</th>
                    <th>نوع / فوریت</th>
                    <th>فرستنده ← گیرنده</th>
                    <th>موضوع و خلاصه نامه</th>
                    <th>امضا / دریافت</th>
                    <th>عملیات کارتابل</th>
                </tr>
                </thead>
                <tbody>
                <?php if (empty($bundle['letters'])): ?>
                    <tr><td colspan="6" class="muted" style="text-align:center;padding:24px">در این صندوق نامه‌ای وجود ندارد. برای ارسال، گیرنده را از فهرست همکاران انتخاب کنید.</td></tr>
                <?php endif; ?>
                <?php foreach ($bundle['letters'] as $ltr): ?>
                    <?php
                    $isUrgent = in_array($ltr['priority_level'], ['فوری', 'آنی'], true);
                    $isSigned = !str_contains($ltr['sign_status'], 'پیش‌نویس');
                    $isRecipient = (int)($ltr['recipient_user_id'] ?? 0) === $currentUserId;
                    $isUnread = $isRecipient && empty($ltr['read_at']);
                    ?>
                    <tr>
                        <td>
                            <strong><code><?= e($ltr['indicator_no']) ?></code></strong>
                            <div class="muted" style="font-size:11.5px"><?= e($ltr['created_shamsi']) ?></div>
                        </td>
                        <td>
                            <span class="badge badge-info"><?= e($ltr['letter_type']) ?></span>
                            <?php if ($isUrgent): ?>
                                <span class="badge badge-danger"><?= e($ltr['priority_level']) ?></span>
                            <?php endif; ?>
                            <?php if ($ltr['confidentiality'] !== 'عادی'): ?>
                                <span class="badge badge-warning"><?= e($ltr['confidentiality']) ?></span>
                            <?php endif; ?>
                        </td>
                        <td style="font-size:12.3px">
                            <div><strong>از:</strong> <?= e($ltr['sender_name'] ?: $ltr['sender_unit']) ?></div>
                            <div class="muted"><strong>به:</strong> <?= e($ltr['recipient_name'] ?: $ltr['recipient_org']) ?></div>
                            <?php if (!empty($ltr['external_recipient'])): ?>
                                <div class="muted"><strong>مقصد بیرونی:</strong> <?= e($ltr['external_recipient']) ?></div>
                            <?php endif; ?>
                        </td>
                        <td style="max-width:340px">
                            <strong><?= e($ltr['subject_title']) ?></strong>
                            <div class="muted" style="font-size:12px;margin-top:2px"><?= e(mb_substr($ltr['letter_body'], 0, 95)) ?>...</div>
                            <details style="margin-top:7px">
                                <summary style="cursor:pointer;color:var(--primary);font-size:12px">مشاهده متن کامل و پیوست</summary>
                                <div style="white-space:pre-line;line-height:1.9;padding:9px 0"><?= e($ltr['letter_body']) ?></div>
                                <div class="muted">پیوست: <?= e($ltr['attachment_note'] ?: 'ندارد') ?></div>
                                <?php if (!empty($ltr['reply_to_letter_id'])): ?>
                                    <div class="muted">در پاسخ به نامه شماره <?= e($ltr['reply_to_letter_id']) ?></div>
                                <?php endif; ?>
                            </details>
                        </td>
                        <td>
                            <span class="badge <?= $isSigned ? 'badge-success' : 'badge-warning' ?>"><?= e($ltr['sign_status']) ?></span>
                            <div class="muted" style="font-size:11.5px;margin-top:4px"><?= $isRecipient ? e($ltr['recipient_status']) : 'ارسال‌شده' ?></div>
                        </td>
                        <td>
                            <div style="display:flex;gap:5px;flex-wrap:wrap">
                                <a href="<?= e(url('letter-print', ['id' => $ltr['id']])) ?>" target="_blank" class="btn btn-outline btn-sm">🖨️ سربرگ چاپی</a>
                                <?php if (!$isSigned && ((int)($ltr['sender_user_id'] ?? 0) === $currentUserId || $canManageRequests)): ?>
                                    <form method="post" style="margin:0">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="action" value="sign_letter">
                                        <input type="hidden" name="letter_id" value="<?= (int)$ltr['id'] ?>">
                                        <button type="submit" class="btn btn-primary btn-sm">✒️ امضا و ثبت</button>
                                    </form>
                                <?php endif; ?>
                                <?php if ($isRecipient && $isUnread): ?>
                                    <form method="post" style="margin:0">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="action" value="mark_letter_read">
                                        <input type="hidden" name="letter_id" value="<?= (int)$ltr['id'] ?>">
                                        <button type="submit" class="btn btn-outline btn-sm">ثبت مطالعه</button>
                                    </form>
                                <?php endif; ?>
                                <?php if ($isRecipient && $box !== 'archived'): ?>
                                    <form method="post" style="margin:0">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="action" value="archive_letter">
                                        <input type="hidden" name="letter_id" value="<?= (int)$ltr['id'] ?>">
                                        <button type="submit" class="btn btn-outline btn-sm">بایگانی</button>
                                    </form>
                                <?php endif; ?>
                                <a href="<?= e(url('office-automation', ['tab' => 'compose', 'reply_to' => $ltr['id']])) ?>" class="btn btn-outline btn-sm">پاسخ</a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- تب ۲: ثبت و نگارش نامه جدید با قالب آماده + هوش مصنوعی -->
<div id="oaPanel_compose" class="oa-panel" style="display:<?= $activeTab === 'compose' ? 'block' : 'none' ?>">
    <div class="grid grid-sidebar">
        <div class="card">
            <div class="card-header">
                <div class="card-title">نگارش و شماره‌گذاری نامه رسمی جدید</div>
                <span class="badge badge-info">ثبت خودکار در دفتر اندیکاتور</span>
            </div>
            <form method="post">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="compose_letter">
                <?php if ($replyToId > 0): ?>
                    <input type="hidden" name="reply_to_letter_id" value="<?= $replyToId ?>">
                    <div class="alert alert-info" style="margin-bottom:14px">پاسخ به نامه <?= e($replyTo['indicator_no'] ?? '') ?> — <?= e($replyTo['subject_title'] ?? '') ?></div>
                <?php endif; ?>
                <div class="grid grid-3">
                    <div class="form-group">
                        <label>نوع مکاتبه:</label>
                        <select name="letter_type" id="oaType">
                            <option value="صادره">نامه صادره (خارج سازمانی)</option>
                            <option value="داخلی">یادداشت اداری داخلی</option>
                            <option value="وارده">ثبت نامه وارده به دبیرخانه</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>درجه فوریت:</label>
                        <select name="priority_level" id="oaPrio">
                            <option value="عادی">عادی</option>
                            <option value="فوری">فوری</option>
                            <option value="آنی">آنی (اقدام روزانه)</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>طبقه‌بندی محرمانگی:</label>
                        <select name="confidentiality">
                            <option value="عادی">عادی</option>
                            <option value="محرمانه">محرمانه</option>
                            <option value="خیلی محرمانه">خیلی محرمانه</option>
                        </select>
                    </div>
                </div>
                <div class="grid grid-2">
                    <div class="form-group">
                        <label>فرستنده بیرونی (فقط برای نامه وارده):</label>
                        <input type="text" name="sender_unit" value="" placeholder="برای نامه وارده، نام سازمان یا شخص فرستنده">
                    </div>
                    <div class="form-group">
                        <label for="oaRecipient">گیرنده داخلی / مسئول پیگیری:</label>
                        <select name="recipient_user_id" id="oaRecipient" required>
                            <option value="">انتخاب همکار گیرنده...</option>
                            <?php foreach ($bundle['recipients'] as $recipient): ?>
                                <option value="<?= (int)$recipient['id'] ?>" <?= (int)$recipient['id'] === $replyRecipientId ? 'selected' : '' ?>>
                                    <?= e($recipient['full_name'] . ' — ' . $recipient['role_label'] . ($recipient['job_title'] ? ' / ' . $recipient['job_title'] : '')) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label>مقصد بیرونی (در صورت صدور نامه برای سازمان دیگر):</label>
                    <input type="text" name="external_recipient" id="oaExternalRecipient" placeholder="نام سازمان یا شخص بیرونی؛ اختیاری">
                </div>
                <div class="grid grid-2">
                    <div class="form-group">
                        <label>موضوع رسمی نامه:</label>
                        <input type="text" name="subject_title" id="oaSubject" value="<?= $replyTo ? e('پاسخ: ' . $replyTo['subject_title']) : '' ?>" placeholder="عنوان دقیق مکاتبه اداری..." required>
                    </div>
                    <div class="form-group">
                        <label>شرح پیوست:</label>
                        <input type="text" name="attachment_note" value="ندارد">
                    </div>
                </div>
                <div class="form-group">
                    <label>متن رسمی نامه اداری:</label>
                    <textarea name="letter_body" id="oaBody" rows="6" placeholder="با سلام و احترام؛ ... (می‌توانید از دکمه‌های قالب آماده سمت چپ یا نگارش هوشمند با AI استفاده نمایید)"></textarea>
                </div>
                <div style="display:flex;gap:18px;flex-wrap:wrap;margin-bottom:14px;font-size:12.5px">
                    <label style="display:inline-flex;align-items:center;gap:6px;cursor:pointer">
                        <input type="checkbox" name="sign_immediately" value="1" checked> درج امضای دیجیتال و شماره رسمی بلافاصله پس از ثبت
                    </label>
                    <label style="display:inline-flex;align-items:center;gap:6px;cursor:pointer">
                        <input type="checkbox" name="use_ai_polish" value="1"> تکمیل و ویرایش ادبیات رسمی اداری توسط هوش مصنوعی (AI)
                    </label>
                </div>
                <button type="submit" class="btn btn-primary">ثبت در دفتر اندیکاتور دبیرخانه</button>
            </form>
        </div>

        <div class="card">
            <div class="card-header"><div class="card-title">قالب‌های آماده مکاتبات اداری</div></div>
            <p class="muted" style="font-size:12.5px;margin-bottom:12px">با انتخاب قالب، نوع نامه، مقصد بیرونی، موضوع و متن آماده می‌شود؛ گیرنده داخلی را از فهرست همکاران انتخاب کنید:</p>
            <?php foreach ($bundle['templates'] as $tplKey => $tpl): ?>
                <div style="padding:12px;border:1px solid var(--border);border-radius:11px;margin-bottom:9px;background:var(--surface-2)">
                    <div style="font-weight:700;font-size:13px;margin-bottom:4px"><?= e($tpl['label']) ?></div>
                    <div class="muted" style="font-size:11.8px;margin-bottom:8px"><?= e($tpl['subject']) ?></div>
                    <button type="button" class="btn btn-outline btn-sm"
                            data-type="<?= e($tpl['type']) ?>"
                            data-prio="<?= e($tpl['priority']) ?>"
                            data-rec="<?= e($tpl['recipient']) ?>"
                            data-sub="<?= e($tpl['subject']) ?>"
                            data-body="<?= e($tpl['body']) ?>"
                            onclick="fillOaTemplate(this)">جایگذاری این قالب در فرم</button>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- تب ۳: پاراف و ارجاعات کارتابل -->
<div id="oaPanel_referrals" class="oa-panel" style="display:<?= $activeTab === 'referrals' ? 'block' : 'none' ?>">
    <div class="grid grid-3">
        <div class="card">
            <div class="card-header"><div class="card-title">ثبت پاراف و ارجاع جدید</div></div>
            <form method="post">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="refer_letter">
                <div class="form-group">
                    <label>انتخاب نامه جهت ارجاع:</label>
                    <select name="letter_id">
                        <?php foreach ($bundle['letters'] as $ltr): ?>
                            <option value="<?= (int)$ltr['id'] ?>"><?= e($ltr['indicator_no'] . ' — ' . mb_substr($ltr['subject_title'], 0, 42)) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>ارجاع به همکار:</label>
                    <select name="to_user_id" required>
                        <option value="">انتخاب همکار مسئول اقدام...</option>
                        <?php foreach ($bundle['recipients'] as $recipient): ?>
                            <option value="<?= (int)$recipient['id'] ?>"><?= e($recipient['full_name'] . ' — ' . $recipient['role_label']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>دستور اقدام (هامش اداری):</label>
                    <select name="action_command">
                        <option value="جهت اقدام فوری">جهت اقدام فوری</option>
                        <option value="جهت بررسی و اعلام نظر">جهت بررسی و اعلام نظر کارشناسی</option>
                        <option value="جهت صدور دستور پرداخت">جهت بررسی مالی و صدور دستور پرداخت</option>
                        <option value="جهت استحضار و بهره‌برداری">جهت استحضار و بهره‌برداری</option>
                        <option value="بایگانی در پرونده">ضبط در پرونده و بایگانی</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>مهلت اقدام (شمسی):</label>
                    <input type="text" name="deadline_shamsi" value="<?= e($bundle['today']) ?>">
                </div>
                <div class="form-group">
                    <label>متن پی‌نوشت / پاراف مدیر:</label>
                    <textarea name="paraph_margin_note" rows="3" required placeholder="دستور اجرایی یا توضیحات تکمیلی خود را در حاشیه نامه بنویسید..."></textarea>
                </div>
                <button type="submit" class="btn btn-primary" style="width:100%">ارسال ارجاع به کارتابل مقصد</button>
            </form>
        </div>

        <div class="card" style="grid-column:span 2">
            <div class="card-header"><div class="card-title">زنجیره گردش ارجاعات و پی‌نوشت‌های ثبت‌شده</div></div>
            <div class="table-wrap">
                <table>
                    <thead>
                    <tr>
                        <th>نامه مرجع</th>
                        <th>ارجاع‌دهنده ← گیرنده</th>
                        <th>دستور هامش و پی‌نوشت</th>
                        <th>مهلت</th>
                        <th>وضعیت</th>
                        <th>اقدام</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($bundle['referrals'] as $ref): ?>
                        <?php $done = str_contains($ref['referral_status'], 'مختومه'); ?>
                        <tr>
                            <td>
                                <code><?= e($ref['indicator_no']) ?></code>
                                <div class="muted" style="font-size:11.5px"><?= e(mb_substr($ref['subject_title'], 0, 35)) ?>...</div>
                            </td>
                            <td style="font-size:12.2px">
                                <div><?= e($ref['from_user_name'] ?: $ref['from_person']) ?></div>
                                <div style="color:var(--primary);font-weight:600">← <?= e($ref['to_user_name'] ?: $ref['to_person_unit']) ?></div>
                            </td>
                            <td style="max-width:290px">
                                <span class="badge badge-gold"><?= e($ref['action_command']) ?></span>
                                <div style="font-size:12.2px;margin-top:4px"><?= e($ref['paraph_margin_note']) ?></div>
                            </td>
                            <td><?= e($ref['deadline_shamsi']) ?></td>
                            <td><span class="badge <?= $done ? 'badge-success' : 'badge-warning' ?>"><?= e($ref['referral_status']) ?></span></td>
                            <td>
                                <?php if (!$done && ((int)($ref['to_user_id'] ?? 0) === $currentUserId || $canManageRequests)): ?>
                                    <form method="post" style="margin:0">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="action" value="complete_referral">
                                        <input type="hidden" name="referral_id" value="<?= (int)$ref['id'] ?>">
                                        <button type="submit" class="btn btn-outline btn-sm">ثبت انجام و اختتام</button>
                                    </form>
                                <?php elseif ($done): ?>
                                    <span class="muted" style="font-size:11.5px">مختومه</span>
                                <?php else: ?>
                                    <span class="muted" style="font-size:11.5px">در انتظار اقدام گیرنده</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- تب ۴: درخواست‌های اداری پرسنل (مرخصی، مأموریت، تنخواه) -->
<div id="oaPanel_requests" class="oa-panel" style="display:<?= $activeTab === 'requests' ? 'block' : 'none' ?>">
    <div class="grid grid-3">
        <div class="card">
            <div class="card-header"><div class="card-title">ثبت درخواست اداری همکاران</div></div>
            <form method="post">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="submit_admin_request">
                <div class="form-group">
                    <label>نام متقاضی:</label>
                    <input type="text" value="<?= e($currentUserName) ?>" readonly>
                </div>
                <div class="form-group">
                    <label>واحد سازمانی:</label>
                    <input type="text" name="unit_name" value="واحد آموزش و پژوهش" required>
                </div>
                <div class="form-group">
                    <label>نوع درخواست اداری:</label>
                    <select name="req_category">
                        <option value="مرخصی استحقاقی / ساعتی">مرخصی استحقاقی / ساعتی</option>
                        <option value="حکم مأموریت اداری">حکم مأموریت اداری</option>
                        <option value="درخواست تنخواه و تدارکات">درخواست تنخواه و تدارکات</option>
                        <option value="گواهی اشتغال به کار / کسر از حقوق">گواهی اشتغال به کار / کسر از حقوق</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>بازه زمانی یا مبلغ مورد درخواست:</label>
                    <input type="text" name="date_range_or_amount" value="<?= e($bundle['today']) ?>" required>
                </div>
                <div class="form-group">
                    <label>علت و شرح درخواست:</label>
                    <textarea name="description_note" rows="3" required placeholder="توضیحات تکمیلی جهت استحضار مدیر واحد..."></textarea>
                </div>
                <button type="submit" class="btn btn-primary" style="width:100%">ثبت و ارسال به کارتابل مدیر</button>
            </form>
        </div>

        <div class="card" style="grid-column:span 2">
            <div class="card-header"><div class="card-title">کارتابل بررسی مرخصی‌ها، احکام مأموریت و تنخواه</div></div>
            <div class="table-wrap">
                <table>
                    <thead>
                    <tr>
                        <th>کد</th>
                        <th>متقاضی / واحد</th>
                        <th>نوع درخواست</th>
                        <th>مدت / مبلغ و شرح</th>
                        <th>وضعیت تأیید</th>
                        <th>تصمیم مدیریت</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($bundle['admin_requests'] as $req): ?>
                        <?php $pending = str_contains($req['approval_status'], 'منتظر'); ?>
                        <tr>
                            <td><code><?= e($req['req_code']) ?></code></td>
                            <td>
                                <strong><?= e($req['requester_name']) ?></strong>
                                <div class="muted" style="font-size:11.5px"><?= e($req['unit_name']) ?></div>
                            </td>
                            <td><span class="badge badge-info"><?= e($req['req_category']) ?></span></td>
                            <td style="max-width:260px">
                                <strong><?= e($req['date_range_or_amount']) ?></strong>
                                <div class="muted" style="font-size:12px"><?= e($req['description_note']) ?></div>
                            </td>
                            <td><span class="badge <?= $pending ? 'badge-warning' : 'badge-success' ?>"><?= e($req['approval_status']) ?></span></td>
                            <td>
                                <?php if ($pending && $canManageRequests): ?>
                                    <form method="post" style="margin:0;display:flex;gap:5px">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="action" value="decide_admin_request">
                                        <input type="hidden" name="req_id" value="<?= (int)$req['id'] ?>">
                                        <button type="submit" name="decision" value="approve" class="btn btn-primary btn-sm">تأیید</button>
                                        <button type="submit" name="decision" value="reject" class="btn btn-outline btn-sm">رد</button>
                                    </form>
                                <?php else: ?>
                                    <span class="muted" style="font-size:11.5px"><?= e($req['approver_note']) ?></span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- تب ۵: صورت‌جلسات رسمی و پیگیری مصوبات -->
<div id="oaPanel_minutes" class="oa-panel" style="display:<?= $activeTab === 'minutes' ? 'block' : 'none' ?>">
    <div class="grid grid-3">
        <div class="card">
            <div class="card-header"><div class="card-title">ثبت صورت‌جلسه و مصوبات جدید</div></div>
            <form method="post">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="record_minutes">
                <div class="form-group">
                    <label>عنوان رسمی جلسه / کمیسیون:</label>
                    <input type="text" name="meeting_title" placeholder="مثلاً: جلسه شورای برنامه‌ریزی دوره‌های صادراتی" required>
                </div>
                <div class="form-group">
                    <label>حاضرین جلسه:</label>
                    <input type="text" name="attendees_summary" value="مدیر آموزش، کارشناس مسئول، نماینده مالی و دبیر جلسه" required>
                </div>
                <div class="form-group">
                    <label>مسئول پیگیری و مهلت اجرا:</label>
                    <div class="grid grid-2" style="margin-bottom:0">
                        <input type="text" name="responsible_owner" value="واحد اجرایی آموزش" required>
                        <input type="text" name="due_shamsi" value="<?= e($bundle['today']) ?>" required>
                    </div>
                </div>
                <div class="form-group">
                    <label>شرح مصوبات کلیدی جلسه:</label>
                    <textarea name="key_resolutions" rows="4" required placeholder="بند ۱: ... | بند ۲: ..."></textarea>
                </div>
                <button type="submit" class="btn btn-primary" style="width:100%">ثبت و ابلاغ صورت‌جلسه رسمی</button>
            </form>
        </div>

        <div class="card" style="grid-column:span 2">
            <div class="card-header"><div class="card-title">دفتر ثبت صورت‌جلسات و پیگیری مصوبات ابلاغی</div></div>
            <?php foreach ($bundle['minutes'] as $min): ?>
                <div style="padding:15px 18px;border:1px solid var(--border);border-radius:12px;margin-bottom:12px;background:var(--surface-2)">
                    <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:6px">
                        <div>
                            <code><?= e($min['minute_code']) ?></code> • <strong style="font-size:14px"><?= e($min['meeting_title']) ?></strong>
                        </div>
                        <span class="badge badge-success"><?= e($min['execution_status']) ?></span>
                    </div>
                    <div class="muted" style="font-size:12px;margin-bottom:8px">
                        رئیس جلسه: <strong><?= e($min['chairperson']) ?></strong> • حاضرین: <?= e($min['attendees_summary']) ?> • مهلت اقدام: <strong><?= e($min['due_shamsi']) ?></strong> (مسئول: <?= e($min['responsible_owner']) ?>)
                    </div>
                    <div style="font-size:13px;line-height:1.85;background:var(--surface);padding:10px 12px;border-radius:9px;border:1px solid var(--border)">
                        <?= nl2br(e($min['key_resolutions'])) ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<script>
function switchOaTab(tab, btn) {
    document.querySelectorAll('.oa-panel').forEach(function (p) { p.style.display = 'none'; });
    var target = document.getElementById('oaPanel_' + tab);
    if (target) target.style.display = 'block';
    document.querySelectorAll('.tabs .tab-btn').forEach(function (b) { b.classList.remove('active'); });
    if (btn) btn.classList.add('active');
}
function fillOaTemplate(btn) {
    document.getElementById('oaType').value = btn.getAttribute('data-type');
    document.getElementById('oaPrio').value = btn.getAttribute('data-prio');
    document.getElementById('oaExternalRecipient').value = btn.getAttribute('data-rec');
    document.getElementById('oaSubject').value = btn.getAttribute('data-sub');
    document.getElementById('oaBody').value = btn.getAttribute('data-body');
    toggleOaTypeFields();
}
function toggleOaTypeFields() {
    var inbound = document.getElementById('oaType').value === 'وارده';
    document.querySelector('input[name="sender_unit"]').required = inbound;
}
document.getElementById('oaType').addEventListener('change', toggleOaTypeFields);
toggleOaTypeFields();
</script>
