<?php
use App\Core\App;
use App\Core\Auth;
use App\Core\Jalali;
use App\Services\EnterpriseSettingsIamService;
use App\Services\ModuleAiAdvisorService;

$liveTheme = EnterpriseSettingsIamService::getActiveThemeProfile();
$themeRev  = EnterpriseSettingsIamService::getThemeRevisionHash();
$activeModRoute = App::currentRoute() ?: 'dashboard';
$effectiveRoute = $currentRoute !== '' ? $currentRoute : 'dashboard';

$modPulse  = ModuleAiAdvisorService::getLiveModulePulse($activeModRoute);
$modAiSpec = $modPulse['spec'];
// ★ v26.8 — در فضای فراگیر نوار AI فقط «مربی یادگیری شخصی» است: بدون تکمیل فرم مدیریتی،
// بدون شاخص سازمانی و با همان پاسخ‌هایی که سمت سرور روی داده‌های خود کاربر ساخته می‌شوند.
$isLearnerShell = !empty($modPulse['is_learner']);
$canOpenStudio = \App\Core\Auth::hasRole(['super_admin', 'training_expert', 'finance_manager', 'crm_manager', 'instructor', 'org_rep']);
$smartBar  = \App\Services\ErpIntelligenceService::getContextualSmartBar($activeModRoute);

$modulesByRoute = [];
foreach ($phasesMeta['modules'] as $mItem) {
    $modulesByRoute[$mItem['route']] = $mItem;
}

$isManagerLayoutRole = Auth::hasRole(['super_admin', 'training_expert', 'finance_manager', 'crm_manager']);
$isLearnerLayoutRole = ((string)Auth::role()) === 'learner';
$activeGroupTitle = $isManagerLayoutRole ? 'پیشخوان مدیریتی و هوش تجاری' : 'پیشخوان و میزکار اختصاصی من';
$activePageShort  = $isManagerLayoutRole ? 'پیشخوان فرماندهی کلان' : 'پیشخوان اختصاصی من';

if ($isLearnerLayoutRole) {
    // breadcrumb فراگیر فقط بخش‌های آموزشی خودش را نشان می‌دهد
    $activeGroupTitle = 'فضای یادگیری من';
    $learnerSections = App::learnerNavSections();
    foreach ($learnerSections as $lsecKey => $lsec) {
        $lsecItems = is_array($lsec['items'] ?? null) ? $lsec['items'] : [];
        foreach ($lsecItems as $litemTmp) {
            if (($litemTmp['route'] ?? '') === $effectiveRoute) {
                $activeGroupTitle = $lsec['title'] ?? 'فضای یادگیری من';
                $activePageShort = $litemTmp['title'] ?? 'بخش آموزشی من';
                break 2;
            }
        }
    }
}

$navGroupsForCrumb = $isLearnerLayoutRole ? [] : ($phasesMeta['nav_groups'] ?? []);
foreach ($navGroupsForCrumb as $gKeyTmp => $gMeta) {
    if (in_array($effectiveRoute, $gMeta['routes'], true)) {
        $activeGroupTitle = ($gKeyTmp === 'executive_bi' && !$isManagerLayoutRole)
            ? 'پیشخوان و میزکار اختصاصی من'
            : $gMeta['title'];
        break;
    }
}
if ($effectiveRoute !== 'dashboard') {
    $activePageShort = $pageTitle ?? 'بخش عملیاتی';
    if (isset($modulesByRoute[$effectiveRoute])) {
        $activePageShort = preg_replace('/^[۰-۹0-9]+\.\s*/u', '', $modulesByRoute[$effectiveRoute]['title']);
    }
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl"
      <?= ($liveTheme['color_mode'] ?? 'light') === 'dark' ? 'data-theme="dark"' : 'data-theme="light"' ?>
      data-server-theme="<?= e($liveTheme['color_mode'] ?? 'light') ?>"
      data-theme-rev="<?= e($themeRev) ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($pageTitle ?? 'پیشخوان هوشمند') ?> | <?= e($liveTheme['brand_org_title'] ?? $chamberName) ?></title>
    <link rel="manifest" href="<?= e(App::basePath() . '/manifest.webmanifest') ?>">
    <link rel="stylesheet" href="<?= e(asset('css/app.css')) ?>?v=<?= e(asset_ver('css/app.css')) ?>.<?= e($themeRev) ?>">
    <?= EnterpriseSettingsIamService::renderLiveThemeCssBlock() ?>
    <script>
    // تضمین باز شدن آنی و بدون خطای دستیار هوشمند و نوار AI حتی پیش از بارگذاری کامل اسکریپت‌ها یا در حالت آفلاین
    window.__MOD_AI_SPEC = <?= js_json([
        'route'    => $activeModRoute,
        'title'    => $modAiSpec['title'],
        'prompts'  => $modAiSpec['prompts'],
        'autofill' => $modAiSpec['autofill'] ?? [],
        'engine'   => $modPulse['engine_label'],
        'learner'  => $isLearnerShell,
    ], JSON_UNESCAPED_UNICODE) ?>;

    window.chamberApiUrl = function (route) {
        var b = (document.body && document.body.getAttribute('data-base-url')) || '';
        return (b + '/index.php?r=' + String(route || '').replace(/^\/+/, '')).replace(/\/+/g, '/');
    };

    window.runChamberAiQuery = async function (promptText, outElId, inpElId) {
        var out = document.getElementById(outElId || 'modAiOut');
        var inp = inpElId ? document.getElementById(inpElId) : null;
        var q = (promptText || (inp ? inp.value : '') || '').trim();
        if (!q) q = (window.__MOD_AI_SPEC && window.__MOD_AI_SPEC.prompts && window.__MOD_AI_SPEC.prompts[0]) || 'تحلیل جامع این بخش را ارائه بده';
        if (inp) inp.value = q;
        if (out) {
            out.style.display = 'block';
            out.textContent = '⏳ در حال بررسی داده‌های مجاز این بخش و آماده‌سازی پاسخ...';
        }
        if (!window.location.protocol.startsWith('http')) {
            if (out) out.textContent = 'برای دریافت پاسخ دستیار، سامانه را از طریق وب‌سرور باز کنید.';
            return;
        }
        try {
            var fd = new FormData();
            fd.append('module_route', (window.__MOD_AI_SPEC && window.__MOD_AI_SPEC.route) || 'dashboard');
            fd.append('prompt', q);
            var csrfInp = document.querySelector('input[name="_csrf"]');
            if (csrfInp && csrfInp.value) fd.append('_csrf', csrfInp.value);

            var r = await fetch(window.chamberApiUrl('api/v1/module-ai'), {
                method: 'POST',
                body: fd,
                credentials: 'same-origin'
            });
            var d = await r.json();
            if (!r.ok) {
                throw new Error((d && (d.message || d.content)) || ('خطای سرور (' + r.status + ')'));
            }
            if (!d || typeof d.content !== 'string' || !d.content.trim()) {
                throw new Error((d && d.message) || 'پاسخ معتبری از سرویس دستیار دریافت نشد.');
            }
            if (out) {
                out.textContent = d.content;
            }
        } catch (err) {
            if (out) out.textContent = 'پاسخی دریافت نشد. اتصال سامانه یا تنظیمات سرویس هوش مصنوعی را بررسی کنید.'
                + (err && err.message ? '\n' + err.message : '');
        }
    };

    window.openCopilotModal = function (ev) {
        if (ev) ev.preventDefault();
        var m = document.getElementById('copilotModal');
        if (!m) return;
        m.classList.add('open');
        var out = document.getElementById('modAiOut');
        if (out && (!out.textContent || out.textContent.trim() === '')) {
            out.style.display = 'block';
            out.textContent = 'پرسش خود را بنویسید یا یکی از پیشنهادها را انتخاب کنید.';
        } else if (out) {
            out.style.display = 'block';
        }
        var inp = document.getElementById('modAiInput');
        if (inp) setTimeout(function () { inp.focus(); }, 60);
    };

    window.autoFillPageFormWithAi = function () {
        var spec = (window.__MOD_AI_SPEC && window.__MOD_AI_SPEC.autofill) || {};
        var filled = 0;
        var firstFilledEl = null;
        var forms = document.querySelectorAll('main.content-wrap form[method="post"], main.content-wrap form[method="POST"]');
        forms.forEach(function (f) {
            if (f.id === 'copilotQuickForm') return;
            f.querySelectorAll('input[type="text"], input[type="number"], input:not([type]), textarea').forEach(function (el) {
                if (el.readOnly || el.disabled || el.type === 'hidden') return;
                if (el.id === 'inlineModAiInput' || el.id === 'modAiInput' || el.classList.contains('dt-search-input')) return;
                var nm = (el.name || '').toLowerCase();
                if (!nm || nm === '_csrf') return;
                if (spec[el.name] !== undefined) {
                    el.value = spec[el.name];
                    filled++;
                } else if (!el.value.trim()) {
                    if (nm.indexOf('rial') !== -1 || nm.indexOf('amount') !== -1 || nm.indexOf('price') !== -1 || nm.indexOf('budget') !== -1) {
                        el.value = '45000000';
                    } else if (nm.indexOf('pct') !== -1 || nm.indexOf('percent') !== -1 || nm.indexOf('score') !== -1) {
                        el.value = '85';
                    } else if (nm.indexOf('count') !== -1 || nm.indexOf('hours') !== -1 || nm.indexOf('capacity') !== -1) {
                        el.value = '24';
                    } else if (nm.indexOf('shamsi') !== -1 || nm.indexOf('date') !== -1) {
                        el.value = '۱۴۰۵/۰۸/۲۵';
                    } else if (nm.indexOf('code') !== -1) {
                        el.value = 'AI-' + Math.floor(100 + Math.random() * 899);
                    } else if (el.tagName === 'TEXTAREA') {
                        el.value = 'پیش‌نویس آموزشی تهیه‌شده برای آموزشگاه حسابداری آدان؛ پیش از ثبت، اطلاعات را بررسی کنید.';
                    } else {
                        el.value = 'پیشنهاد آموزشی آدان';
                    }
                    filled++;
                }
                if (!firstFilledEl) firstFilledEl = el;
                el.style.borderColor = '#10b981';
                el.dispatchEvent(new Event('input', { bubbles: true }));
            });
        });
        if (firstFilledEl) {
            var hiddenTab = firstFilledEl.closest('.tab-panel:not(.active)');
            if (hiddenTab && hiddenTab.id) {
                var tBtn = document.querySelector('.tab-btn[data-tab="' + hiddenTab.id + '"]');
                if (tBtn) tBtn.click();
            }
            var hiddenModal = firstFilledEl.closest('.modal-backdrop:not(.open)');
            if (hiddenModal) hiddenModal.classList.add('open');
        }
        var box = document.getElementById('inlineModAiBody');
        var out = document.getElementById('inlineModAiOut');
        if (box) box.style.display = 'block';
        if (out) {
            out.style.display = 'block';
            out.textContent = filled > 0
                ? '✅ تکمیل هوشمند انجام شد: ' + filled.toLocaleString('fa-IR') + ' فیلد در فرم عملیاتی ثبت اطلاعات این صفحه با مقادیر پیشنهادی استاندارد AI پر شد. اکنون می‌توانید مقادیر را بازبینی و ثبت نهایی نمایید.'
                : 'ℹ️ تمام فیلدهای فرم این صفحه هم‌اکنون دارای مقدار هستند؛ از دکمه‌های تحلیل و پیش‌نویس AI در همین نوار استفاده نمایید.';
        }
    };
    </script>
</head>
<body data-base-url="<?= e(App::basePath()) ?>">
<div class="app-shell">
    <!-- ==================== STANDARD EDUCATIONAL ERP 8-PILLAR SIDEBAR ==================== -->
    <style>
        .sidebar-build-stamp {
            margin: 10px 14px 6px;
            padding: 7px 10px;
            border-radius: 10px;
            font-size: 11px;
            line-height: 1.7;
            text-align: center;
            color: rgba(226, 232, 240, .72);
            background: rgba(148, 163, 184, .12);
            border: 1px dashed rgba(148, 163, 184, .28);
        }
    </style>
    <aside class="sidebar" id="appSidebar">
        <div class="sidebar-brand">
            <div class="brand-row">
                <div class="brand-crest"><?= e($liveTheme['brand_monogram'] ?? 'ناب') ?></div>
                <div>
                    <div class="brand-title"><?= e($liveTheme['brand_org_title'] ?? $chamberName) ?></div>
                    <div class="brand-sub"><?= e($liveTheme['brand_unit_subtitle'] ?? $unitName) ?></div>
                </div>
            </div>
        </div>

        <?php $isLearnerShell = ((string)Auth::role()) === 'learner'; ?>
        <?php if (!$isLearnerShell): ?>
            <div class="sidebar-filter-box">
                <input type="text" id="sidebarModuleFilter" class="sidebar-filter-input" placeholder="🔍 جست‌وجوی سریع در منوهای ERP...">
            </div>
            <div class="sidebar-section-caption">
                <span>سرفصل‌های استاندارد ERP آموزشی</span>
                <span>۸ حوزه</span>
            </div>
        <?php else: ?>
            <div class="sidebar-section-caption">
                <span>فضای یادگیری شخصی</span>
                <span><?= fa(count(App::learnerAllowedRoutes())) ?> بخش</span>
            </div>
        <?php endif; ?>

        <nav class="sidebar-nav">
            <?php if ($isLearnerShell): ?>
                <?php $learnerAccents = ['my_learning' => '#0f766e', 'my_profile' => '#6366f1']; ?>
                <?php foreach (App::learnerNavSections() as $lgrpKey => $lsection): ?>
                    <?php
                    $lItems = array_values(array_filter($lsection['items'] ?? [], static fn($li) => isset($modulesByRoute[$li['route']])));
                    if (empty($lItems)) {
                        continue;
                    }
                    $lRoutes = array_column($lItems, 'route');
                    $lHasActive = in_array($effectiveRoute, $lRoutes, true);
                    $lSubtitle = $lgrpKey === 'my_learning'
                        ? 'دوره‌ها، کلاس مجازی، آزمون و شهریه من'
                        : 'پرونده آموزشی، مهارت‌ها و گذرنامه مهارت';
                    ?>
                    <div class="nav-group <?= $lHasActive ? 'has-active open' : '' ?>"
                         data-group-id="learner_<?= e($lgrpKey) ?>"
                         style="--grp-accent: <?= e($learnerAccents[$lgrpKey] ?? '#6366f1') ?>">
                        <button type="button" class="nav-group-btn" aria-expanded="<?= $lHasActive ? 'true' : 'false' ?>">
                            <div class="nav-group-head">
                                <div style="min-width:0">
                                    <div class="nav-group-title"><?= e($lsection['title']) ?></div>
                                    <div class="nav-group-sub"><?= e($lSubtitle) ?></div>
                                </div>
                            </div>
                            <div class="nav-group-meta">
                                <span class="nav-count-badge"><?= fa(count($lItems)) ?></span>
                                <span class="nav-chevron">▾</span>
                            </div>
                        </button>
                        <div class="nav-group-panel"><div class="nav-group-inner"><div class="nav-tree-list">
                            <?php foreach ($lItems as $litem): ?>
                                <a href="<?= e(url($litem['route'])) ?>"
                                   data-title="<?= e($litem['title']) ?>"
                                   class="nav-item <?= $effectiveRoute === $litem['route'] ? 'active' : '' ?>">
                                    <span><?= e($litem['title']) ?></span>
                                </a>
                            <?php endforeach; ?>
                        </div></div></div>
                    </div>
                <?php endforeach; ?>
                <div style="margin:14px 6px 6px;padding:11px 13px;border-radius:12px;background:rgba(148,163,184,.13);font-size:11.5px;line-height:1.95;color:#cbd5e1">
                    بخش‌های مدیریتی (امور مالی، امور اداری، پذیرش، کمپین‌ها، گزارش‌ها و تنظیمات) مخصوص کارکنان آموزشگاه آدان است.
                    همه ابزارهای یادگیری شما در همین منو قرار دارد.
                </div>
            <?php else: ?>
            <?php $navVisibleCount = 0; ?>
            <?php foreach (($phasesMeta['nav_groups'] ?? []) as $grpKey => $grpMeta): ?>
                <?php
                $grpMods = [];
                $grpHasActive = false;
                foreach ($grpMeta['routes'] as $rSlug) {
                    if (!isset($modulesByRoute[$rSlug])) {
                        continue;
                    }
                    // منوی کنونی دقیقاً با همان موتور RBAC روتر هم‌راستا می‌شود (نقش پایه + استثنای موردی کاربر + قفل‌های ایمنی)
                    // تا هیچ ماژولی که کاربر عملاً اجازه باز کردنش را ندارد، در منوی او نمایش داده نشود.
                    $canSee = EnterpriseSettingsIamService::checkDynamicRouteAccess(
                        (int)(Auth::id() ?? 0),
                        (string)Auth::role(),
                        $rSlug,
                        $modulesByRoute[$rSlug]['roles'] ?? []
                    );
                    if ($canSee) {
                        $navVisibleCount++;
                        $grpMods[] = $modulesByRoute[$rSlug];
                        if ($effectiveRoute === $rSlug) {
                            $grpHasActive = true;
                        }
                    }
                }
                if (empty($grpMods)) continue;
                $accentHex = $grpMeta['accent'] ?? '#6366f1';
                $grpDisplayTitle = ($grpKey === 'executive_bi' && !$isManagerLayoutRole)
                    ? 'پیشخوان و میزکار من'
                    : $grpMeta['title'];
                $grpDisplaySub = ($grpKey === 'executive_bi' && !$isManagerLayoutRole)
                    ? 'خلاصه فعالیت‌ها و وظایف اختصاصی شما'
                    : ($grpMeta['subtitle'] ?? '');
                ?>
                <div class="nav-group <?= $grpHasActive ? 'has-active open' : '' ?>"
                     data-group-id="<?= e($grpKey) ?>"
                     style="--grp-accent: <?= e($accentHex) ?>">
                    <button type="button" class="nav-group-btn" aria-expanded="<?= $grpHasActive ? 'true' : 'false' ?>">
                        <div class="nav-group-head">
                            <span class="nav-group-icon"><?= $grpMeta['icon'] ?></span>
                            <div style="min-width:0">
                                <div class="nav-group-title"><?= e($grpDisplayTitle) ?></div>
                                <?php if (!empty($grpDisplaySub)): ?>
                                    <div class="nav-group-sub"><?= e($grpDisplaySub) ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="nav-group-meta">
                            <span class="nav-count-badge"><?= fa(count($grpMods)) ?></span>
                            <span class="nav-chevron">▾</span>
                        </div>
                    </button>
                    <div class="nav-group-panel"><div class="nav-group-inner"><div class="nav-tree-list">
                        <?php foreach ($grpMods as $mod): ?>
                            <?php
                            $cleanModTitle = preg_replace('/^[۰-۹0-9]+\.\s*/u', '', $mod['title']);
                            if ($mod['route'] === 'dashboard' && !$isManagerLayoutRole) {
                                $cleanModTitle = 'پیشخوان اختصاصی من';
                            }
                            if ($mod['route'] === 'finance' && !Auth::hasRole(['super_admin', 'finance_manager'])) {
                                $cleanModTitle = 'صورتحساب و پرداخت شهریه من';
                            }
                            if ($mod['route'] === 'market-radar' && !Auth::hasRole(['super_admin', 'training_expert', 'crm_manager'])) {
                                $cleanModTitle = 'بازار آموزشی و فرصت‌های مهارتی';
                            }
                            ?>
                            <a href="<?= e(url($mod['route'])) ?>"
                               data-title="<?= e($cleanModTitle . ' ' . $mod['badge'] . ' ' . $grpMeta['title']) ?>"
                               class="nav-item <?= $effectiveRoute === $mod['route'] ? 'active' : '' ?>">
                                <span><?= e($cleanModTitle) ?></span>
                            </a>
                        <?php endforeach; ?>
                    </div></div></div>
                </div>
            <?php endforeach; ?>
            <?php endif; ?>
        </nav>
        <?php
        // چیپ نگارش سامانه (خوانده‌شده از config — بدون متن ثابت، تا نسخه هرگز واگرا نشود)
        $sideVer = (string)(\App\Core\App::config('app')['version'] ?? '');
        $sideVerNum = explode('-', $sideVer)[0] ?? '';
        ?>
        <?php if ($sideVerNum !== ''): ?>
            <div class="sidebar-build-stamp" title="شناسه نگارش: <?= e($sideVer) ?>">
                🏷️ نگارش <?= fa(str_replace('.', '٫', $sideVerNum)) ?> •
                <?php if (\App\Core\Auth::role() === 'learner'): ?>
                    فضای یادگیری شما
                <?php else: ?>
                    <?= fa((int)($navVisibleCount ?? 0)) ?> بخش — دقیقاً کار نقش «<?= e(\App\Core\Auth::roleLabel()) ?>»
                    <a href="<?= e(asset('docs/USER_HELP.html')) ?>#rolezone" target="_blank" rel="noopener"
                       style="color:inherit;text-decoration:underline;font-weight:800" title="چرا بقیهٔ بخش‌ها را نمی‌بینم؟">چرا؟</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </aside>
    <script>
    (function(){
        var sb = document.getElementById('appSidebar');
        if (!sb) return;
        try {
            var savedY = sessionStorage.getItem('chamber_sidebar_scroll');
            if (savedY !== null) sb.scrollTop = parseInt(savedY, 10) || 0;
            var act = sb.querySelector('.nav-item.active');
            if (act) {
                var sbRect = sb.getBoundingClientRect(), aRect = act.getBoundingClientRect();
                if (aRect.bottom > sbRect.bottom - 24 || aRect.top < sbRect.top + 80) {
                    act.scrollIntoView({ block: 'center', behavior: 'auto' });
                }
            }
        } catch (e) {}
    })();
    </script>

    <!-- ==================== CLEAN MAIN WORKSPACE ==================== -->
    <div class="main-area">
        <header class="topbar">
            <div class="topbar-right">
                <button type="button" class="icon-btn" id="mobileMenuBtn" title="جمع‌کردن یا بازکردن منوی کناری">
                    <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="15" y2="18"/></svg>
                </button>
                <div class="inline-crumb">
                    <span class="crumb-root"><?= e($activeGroupTitle) ?></span>
                    <span class="crumb-sep">/</span>
                    <span class="crumb-page"><?= e($activePageShort) ?></span>
                </div>
            </div>

            <div class="cmd-search-wrap">
                <button type="button" class="cmd-search-btn" data-open-modal="globalSearchModal"
                        onclick="var m=document.getElementById('globalSearchModal');if(m)m.classList.add('open');">
                    <span style="display:inline-flex;align-items:center;gap:7px">
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                        جست‌وجوی سریع در سامانه...
                    </span>
                    <span class="kbd">Ctrl+K</span>
                </button>
                <button type="button" class="cmd-mic-btn" onclick="if(window.openVoiceCommanderModal){window.openVoiceCommanderModal(false);}else{var vm=document.getElementById('globalVoiceModal');if(vm)vm.classList.add('open');}" title="فرمان صوتی فارسی (Ctrl+Space)">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/></svg>
                </button>
            </div>

            <div class="topbar-left">
                <?php $gHud = \App\Services\LearnerBehaviorGamificationService::getUserHudSnapshot((int)($currentUser['id'] ?? 1), (string)($currentUser['full_name'] ?? 'کاربر اتاق')); ?>
                <button type="button" class="xp-chip" data-open-modal="gamificationQuickModal"
                        onclick="var gm=document.getElementById('gamificationQuickModal');if(gm)gm.classList.add('open');"
                        title="امتیاز تجربه، سطح مهارتی و سکه شما">
                    <span style="color:var(--gold)">★</span>
                    <span id="topbarLiveXp"><?= fa(number_format($gHud['xp_points'])) ?></span>
                    <span class="muted" style="font-size:11px">XP</span>
                </button>

                <button type="button" class="ai-pill-btn" id="topCopilotTriggerBtn"
                        data-open-modal="copilotModal"
                        onclick="window.openCopilotModal(event)"
                        title="دستیار سازمانی و تحلیل اطلاعات همین صفحه">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3Z"/></svg>
                    <span>دستیار سازمانی</span>
                </button>

                <button type="button" class="icon-btn" id="quickThemeTriggerBtn" title="تغییر آنی رنگ، پوسته روشن/تیره و فونت فارسی">
                    <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="13.5" cy="6.5" r=".5" fill="currentColor"/><circle cx="17.5" cy="10.5" r=".5" fill="currentColor"/><circle cx="8.5" cy="7.5" r=".5" fill="currentColor"/><circle cx="6.5" cy="12.5" r=".5" fill="currentColor"/><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.93 0 1.65-.75 1.65-1.69 0-.44-.18-.84-.44-1.13-.29-.29-.44-.65-.44-1.13a1.64 1.64 0 0 1 1.67-1.67h2c3.05 0 5.56-2.5 5.56-5.55C21.97 6.01 17.46 2 12 2z"/></svg>
                </button>

                <button type="button" class="icon-btn" data-open-modal="pageContextualHelpModal"
                        onclick="var hm=document.getElementById('pageContextualHelpModal');if(hm)hm.classList.add('open');"
                        title="راهنمای اختصاصی همین صفحه (F1)">
                    <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
                </button>

                <button type="button" class="icon-btn" data-open-modal="notifModal"
                        onclick="var nm=document.getElementById('notifModal');if(nm)nm.classList.add('open');"
                        title="اعلان‌های سیستم">
                    <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
                    <?php if ($unreadCount > 0): ?>
                        <span class="notif-dot"><?= fa($unreadCount) ?></span>
                    <?php endif; ?>
                </button>

                <div class="user-profile-pill">
                    <span class="user-avatar-dot"><?= e(mb_substr((string)($currentUser['full_name'] ?? 'م'), 0, 1)) ?></span>
                    <span style="font-size:12.5px;font-weight:600"><?= e($currentUser['full_name'] ?? '') ?></span>
                    <a href="<?= e(url('logout')) ?>" class="icon-btn" style="width:28px;height:28px;border:0;background:transparent" title="خروج از حساب">
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
                    </a>
                </div>
            </div>
        </header>

        <!-- ==================== INSTANT LIVE APPEARANCE & FONT POPOVER ==================== -->
        <div class="quick-theme-popover no-print" id="quickThemePopover">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">
                <strong style="font-size:13.5px">🎨 شخصی‌سازی زنده ظاهر و فونت</strong>
                <button type="button" class="btn btn-outline btn-sm" id="themeToggleBtn" style="padding:4px 10px;font-size:11.5px">
                    🌓 تغییر روشن / تیره
                </button>
            </div>

            <div style="font-size:11.8px;color:var(--text-soft);font-weight:600">پالت رنگی سامانه (اعمال آنی + ذخیره خودکار):</div>
            <div class="swatch-row">
                <button type="button" class="swatch-dot" style="background:#0f766e" title="زمردی رسمی" onclick="window.applyInstantAppearance({primary_hex:'#0f766e',gold_accent_hex:'#d97706',sidebar_bg_hex:'#0f172a'})"></button>
                <button type="button" class="swatch-dot" style="background:#4f46e5" title="نیلی مدرن" onclick="window.applyInstantAppearance({primary_hex:'#4f46e5',gold_accent_hex:'#0ea5e9',sidebar_bg_hex:'#0f172a'})"></button>
                <button type="button" class="swatch-dot" style="background:#2563eb" title="آبی لاجوردی" onclick="window.applyInstantAppearance({primary_hex:'#2563eb',gold_accent_hex:'#f59e0b',sidebar_bg_hex:'#0c192c'})"></button>
                <button type="button" class="swatch-dot" style="background:#566d75" title="آبی فولادی" onclick="window.applyInstantAppearance({primary_hex:'#566d75',gold_accent_hex:'#b58a45',sidebar_bg_hex:'#17272d'})"></button>
                <button type="button" class="swatch-dot" style="background:#e11d48" title="یاقوتی مدرن" onclick="window.applyInstantAppearance({primary_hex:'#e11d48',gold_accent_hex:'#f59e0b',sidebar_bg_hex:'#18101d'})"></button>
                <button type="button" class="swatch-dot" style="background:#0284c7" title="فیروزه‌ای اقیانوسی" onclick="window.applyInstantAppearance({primary_hex:'#0284c7',gold_accent_hex:'#10b981',sidebar_bg_hex:'#0b192c'})"></button>
            </div>

            <div style="font-size:11.8px;color:var(--text-soft);font-weight:600;margin-top:14px">فونت فارسی سراسری (۱۰۰٪ محلی و آفلاین):</div>
            <div class="font-pill-grid">
                <button type="button" class="font-choice-btn" style="font-family:'Vazirmatn',sans-serif" onclick="window.applyInstantAppearance({font_family_key:'Vazirmatn'})">وزیرمتن (مدرن)</button>
                <button type="button" class="font-choice-btn" style="font-family:'Shabnam',sans-serif" onclick="window.applyInstantAppearance({font_family_key:'Shabnam_Modern'})">شبنم (لطیف)</button>
                <button type="button" class="font-choice-btn" style="font-family:'Sahel',sans-serif" onclick="window.applyInstantAppearance({font_family_key:'Sahel_Modern'})">ساحل (مطبوعاتی)</button>
                <button type="button" class="font-choice-btn" style="font-family:'Samim',sans-serif" onclick="window.applyInstantAppearance({font_family_key:'Samim_Editorial'})">صمیم (رسمی)</button>
            </div>

            <div style="display:flex;justify-content:space-between;align-items:center;margin-top:14px;padding-top:12px;border-top:1px solid var(--border)">
                <div style="display:flex;gap:5px">
                    <button type="button" class="btn btn-outline btn-sm" onclick="window.applyInstantAppearance({base_font_px:13})">ریز (۱۳)</button>
                    <button type="button" class="btn btn-outline btn-sm" onclick="window.applyInstantAppearance({base_font_px:14})">استاندارد</button>
                    <button type="button" class="btn btn-outline btn-sm" onclick="window.applyInstantAppearance({base_font_px:15})">درشت (۱۵)</button>
                </div>
                <?php if (\App\Core\App::canViewRoute('system-settings')): ?>
                    <a href="<?= e(url('system-settings')) ?>" style="font-size:11.5px;color:var(--primary);font-weight:600">تنظیمات کامل ←</a>
                <?php else: ?>
                    <span style="font-size:11.5px;color:var(--text-dim)">تنظیمات کلی سامانه در اختیار مدیرکل مؤسسه است</span>
                <?php endif; ?>
            </div>
        </div>

        <main class="content-wrap">
            <?php if ($flash): ?>
                <div class="alert alert-<?= e($flash['type']) ?>">
                    <div><strong>پیام سیستم:</strong> <?= e($flash['message']) ?></div>
                </div>
            <?php endif; ?>

            <!-- ==================== UNIVERSAL MODULE AI CO-WORKER STRIP (ALL PAGES) ==================== -->
            <section class="mod-ai-strip no-print" id="moduleInlineAiBar">
                <div class="mod-ai-strip-top">
                    <div style="display:flex;align-items:center;gap:9px;flex-wrap:wrap">
                        <span class="badge <?= $isLearnerShell ? 'badge-success' : 'badge-info' ?>" style="font-weight:700;padding:4px 10px"><?= $isLearnerShell ? 'مربی یادگیری' : 'دستیار تخصصی' ?></span>
                        <strong style="font-size:13px"><?= e($modAiSpec['title']) ?></strong>
                        <?php foreach ($modPulse['chips'] as $chipTxt): ?>
                            <span class="mod-ai-pulse-chip" style="font-size:11.2px;padding:2px 9px;border-radius:999px;background:var(--surface-2);border:1px solid var(--border);color:var(--text-muted)"><?= e($chipTxt) ?></span>
                        <?php endforeach; ?>
                    </div>
                    <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">
                        <?php if (!$isLearnerShell): ?>
                            <button type="button" class="btn btn-outline btn-sm" style="font-size:11.5px;padding:5px 10px"
                                    onclick="window.autoFillPageFormWithAi()"
                                    title="پیشنهاد برای تکمیل فیلدهای خالی فرم با داده‌های استاندارد">
                                پیشنهاد تکمیل فرم
                            </button>
                        <?php endif; ?>
                        <button type="button" class="btn btn-outline btn-sm" style="font-size:11.5px;padding:5px 10px"
                                onclick="var t=document.getElementById('inlineModAiOut');if(t&&t.textContent&&window.speakPersianReply){window.speakPersianReply(t.textContent);}">
                            <?= $isLearnerShell ? 'بریفینگ صوتی من' : 'پخش گزارش صوتی این بخش' ?>
                        </button>
                        <?php if ($canOpenStudio): ?>
                            <a class="btn btn-outline btn-sm" style="font-size:11.5px;padding:5px 10px" href="<?= e(url('voice-assistant')) ?>"
                               title="استودیوی گزارش‌ساز صوتی: تولید، بایگانی و پخش گزارش رسمی برای نقش‌های مجاز">استودیوی گزارش صوتی</a>
                        <?php endif; ?>
                        <button type="button" class="btn btn-primary btn-sm" style="font-size:11.5px;padding:5px 12px"
                                onclick="var b=document.getElementById('inlineModAiBody');if(b){b.style.display=(b.style.display==='none'?'block':'none');}">
                            راهنمای این بخش ▾
                        </button>
                    </div>
                </div>

                <div id="inlineModAiBody" style="display:none;margin-top:12px;padding-top:12px;border-top:1px dashed var(--border)">
                    <div class="mod-ai-strip-prompts" style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px">
                        <?php foreach ($modAiSpec['prompts'] as $qp): ?>
                            <button type="button" class="mod-ai-chip"
                                    data-p="<?= e($qp) ?>"
                                    onclick="document.getElementById('inlineModAiBody').style.display='block';window.runChamberAiQuery(this.dataset.p, 'inlineModAiOut', 'inlineModAiInput')">
                                <?= e($qp) ?>
                            </button>
                        <?php endforeach; ?>
                    </div>
                    <div style="display:flex;gap:8px;flex-wrap:wrap">
                        <input type="text" id="inlineModAiInput" value="<?= e($modAiSpec['prompts'][0]) ?>"
                               style="flex:1;min-width:240px"
                               placeholder="<?= $isLearnerShell ? 'سؤال درسی خود را بنویسید (فقط درباره یادگیری، مرور و برنامه خودتان)…' : 'دستور تحلیلی، نگارش نامه/سرفصل/سؤال یا پرسش درباره داده‌های همین صفحه…' ?>">
                        <button type="button" class="btn btn-outline btn-sm"
                                onclick="if(window.toggleLiveSpeechRecognition){window.toggleLiveSpeechRecognition('inlineModAiInput');}">
                            🎙️ فرمان صوتی
                        </button>
                        <button type="button" class="btn btn-primary btn-sm"
                                onclick="window.runChamberAiQuery(document.getElementById('inlineModAiInput').value, 'inlineModAiOut', 'inlineModAiInput')">
                            ارسال پرسش
                        </button>
                        <button type="button" class="btn btn-outline btn-sm"
                                onclick="var t=document.getElementById('inlineModAiOut').textContent;if(t&&navigator.clipboard)navigator.clipboard.writeText(t);">
                            📋 کپی
                        </button>
                        <button type="button" class="btn btn-outline btn-sm"
                                onclick="if(window.speakPersianReply)window.speakPersianReply(document.getElementById('inlineModAiOut').textContent);">
                            🔊 خوانش صوتی
                        </button>
                    </div>
                    <pre id="inlineModAiOut" class="pre-box" style="margin-top:10px;font-family:inherit;font-size:12.6px;line-height:1.9;white-space:pre-wrap">برای دریافت پاسخ، پرسش را بنویسید یا یکی از پیشنهادها را انتخاب کنید.</pre>
                </div>
            </section>

            <?= $content ?>
        </main>
    </div>
</div>

<!-- ==================== GLOBAL SEARCH MODAL (Ctrl+K) ==================== -->
<div class="modal-backdrop" id="globalSearchModal" onclick="if(event.target===this)this.classList.remove('open')">
    <div class="modal-box">
        <div class="card-header">
            <div class="card-title">🔍 جست‌وجوی هوشمند در کل سامانه</div>
            <button type="button" class="btn btn-outline btn-sm" data-close-modal onclick="document.getElementById('globalSearchModal').classList.remove('open')">بستن (Esc)</button>
        </div>
        <div class="form-group">
            <input type="text" id="globalSearchInput" placeholder="نام ماژول، دوره، گواهی یا موضوع (مثلاً: اینکوترمز، مالی، کاریابی، لایتنر)...">
        </div>
        <div id="globalSearchResults" style="margin-top:12px">
            <p class="muted" style="font-size:12.5px">عبارت مورد نظر را تایپ کنید تا نتایج متناسب با دسترسی نقش «<?= e(Auth::roleLabel()) ?>» نمایش داده شود.</p>
        </div>
    </div>
</div>

<!-- ==================== ZERO-ERROR UNIFIED SMART COPILOT & CONTEXTUAL AI MODAL ==================== -->
<div class="modal-backdrop" id="copilotModal" onclick="if(event.target===this)this.classList.remove('open')">
    <div class="modal-box" style="max-width:760px">
        <div class="card-header">
            <div>
                <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
                    <div class="card-title"><?= $isLearnerShell ? '🎓 همکار هوشمند مطالعه من' : '✨ دستیار هوشمند سازمانی و تحلیلگر زنده همین صفحه' ?></div>
                    <span class="badge badge-success" style="font-size:11px"><?= e($modPulse['engine_label']) ?></span>
                </div>
                <div class="muted" style="font-size:12px;margin-top:3px">حوزه تخصصی فعال: <?= e($modAiSpec['capability_tag'] ?? 'تحلیل داده‌های بخش جاری و پاسخ‌گویی تخصصی') ?> • <?= $isLearnerShell ? 'داده‌های این پاسخ فقط رکوردهای خودِ شماست' : 'شواهد محدود به داده‌های مجاز همین بخش است' ?></div>
            </div>
            <div style="display:flex;gap:6px;align-items:center">
                <?php if (Auth::hasRole(['super_admin', 'training_expert'])): ?>
                    <a href="<?= e(url('ai-governance')) ?>" class="btn btn-outline btn-sm" style="font-size:11.5px">⚙️ تنظیم کلید API / Ollama</a>
                <?php endif; ?>
                <button type="button" class="btn btn-outline btn-sm" data-close-modal onclick="document.getElementById('copilotModal').classList.remove('open')">بستن ✕</button>
            </div>
        </div>

        <div style="margin-bottom:14px;padding:14px;border-radius:12px;background:var(--surface-2);border:1px solid var(--border)">
            <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:8px">
                <div style="font-size:12.6px;font-weight:700">🎯 دستورات آماده ویژه بخش فعلی (<?= e($modAiSpec['title']) ?>):</div>
                <?php if (!$isLearnerShell): ?>
                    <button type="button" class="btn btn-outline btn-sm" style="font-size:11.2px;padding:4px 9px"
                            onclick="document.getElementById('copilotModal').classList.remove('open');window.autoFillPageFormWithAi();">
                        ⚡ تکمیل خودکار فرم صفحه با AI
                    </button>
                <?php else: ?>
                    <button type="button" class="btn btn-outline btn-sm" style="font-size:11.2px;padding:4px 9px"
                            onclick="document.getElementById('copilotModal').classList.remove('open');window.openVoiceCommanderModal(true);">
                        🎙️ فرمان صوتی یادگیری
                    </button>
                <?php endif; ?>
            </div>
            <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px">
                <?php foreach ($modAiSpec['prompts'] as $qp): ?>
                    <button type="button" class="btn btn-outline btn-sm"
                            onclick="window.runChamberAiQuery(this.dataset.p, 'modAiOut', 'modAiInput')"
                            data-p="<?= e($qp) ?>">✨ <?= e($qp) ?></button>
                <?php endforeach; ?>
            </div>
            <div style="display:flex;gap:8px;flex-wrap:wrap">
                <input type="text" id="modAiInput" value="<?= e($modAiSpec['prompts'][0]) ?>" style="flex:1;min-width:220px" placeholder="<?= $isLearnerShell ? 'مثلاً: امروز چه چیزی را مرور کنم؟' : 'پرسش تحلیلی، نگارش نامه/سرفصل یا دستور خود را بنویسید…' ?>">
                <button type="button" class="btn btn-outline btn-sm" onclick="if(window.toggleLiveSpeechRecognition)window.toggleLiveSpeechRecognition('modAiInput')">🎙️ صوتی</button>
                <button type="button" id="modAiRunBtn" class="btn btn-primary btn-sm"
                        onclick="window.runChamberAiQuery(document.getElementById('modAiInput').value, 'modAiOut', 'modAiInput')">تحلیل و اجرا</button>
            </div>
            <pre id="modAiOut" class="pre-box" style="display:block;margin-top:10px;font-family:inherit;font-size:12.5px;line-height:1.9;white-space:pre-wrap;max-height:260px;overflow-y:auto">برای دریافت پاسخ، پرسش را بنویسید یا یکی از پیشنهادها را انتخاب کنید.</pre>
        </div>

        <form id="copilotQuickForm" onsubmit="event.preventDefault();window.runChamberAiQuery(this.elements['prompt'].value, 'copilotQuickOutput', null);">
            <?= csrf_field() ?>
            <div class="form-group" style="margin-bottom:8px">
                <label><?= $isLearnerShell ? 'گفت‌وگوی آزاد با مربی هوشمند مطالعه (فقط درباره یادگیری، مرور و برنامه خودتان):' : 'گفت‌وگوی آزاد با همکار هوشمند سازمانی (متصل به دیتابیس زنده و دستورالعمل‌های داخلی مؤسسه آدان):' ?></label>
                <textarea name="prompt" rows="2" required placeholder="سؤال خود درباره قوانین آموزشی، مالی، مکاتبات اداری، گواهی QR یا طراحی دوره را بنویسید..."></textarea>
            </div>
            <div style="display:flex;gap:8px;align-items:center">
                <button type="submit" class="btn btn-primary btn-sm">ارسال به AI</button>
                <button type="button" class="btn btn-outline btn-sm" onclick="var o=document.getElementById('copilotQuickOutput');if(o&&o.textContent&&navigator.clipboard)navigator.clipboard.writeText(o.textContent);">📋 کپی پاسخ</button>
                <button type="button" class="btn btn-outline btn-sm" onclick="var o=document.getElementById('copilotQuickOutput');if(o&&window.speakPersianReply)window.speakPersianReply(o.textContent);">🔊 خوانش صوتی</button>
            </div>
        </form>
        <div id="copilotQuickOutput" class="pre-box" style="display:none;margin-top:12px;white-space:pre-wrap;line-height:1.9"></div>
    </div>
</div>

<!-- ==================== NOTIFICATIONS MODAL ==================== -->
<div class="modal-backdrop" id="notifModal" onclick="if(event.target===this)this.classList.remove('open')">
    <div class="modal-box">
        <div class="card-header">
            <div class="card-title">🔔 اعلان‌های شما (<?= e(Jalali::todayFull()) ?>)</div>
            <button type="button" class="btn btn-outline btn-sm" data-close-modal onclick="document.getElementById('notifModal').classList.remove('open')">بستن</button>
        </div>
        <?php foreach ($notifications as $n): ?>
            <div class="alert alert-<?= e($n['type'] === 'urgent' ? 'danger' : $n['type']) ?>" style="align-items:center">
                <div>
                    <div style="font-weight:700"><?= e($n['title']) ?></div>
                    <div style="font-size:12.5px;margin-top:2px"><?= e($n['body']) ?></div>
                </div>
                <?php if (!empty($n['link']) && \App\Core\App::canViewRoute((string)$n['link'])): ?>
                    <a class="btn btn-outline btn-sm" href="<?= e(url($n['link'])) ?>">مشاهده</a>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<div id="systemTourBanner" style="display:none;position:fixed;bottom:74px;left:22px;right:306px;z-index:260;background:var(--navy-900);color:#fff;padding:16px 20px;border-radius:16px;border:1px solid var(--gold);box-shadow:var(--shadow-lg)"></div>

<!-- ==================== VOICE COMMAND MODAL ==================== -->
<div class="modal-backdrop" id="globalVoiceModal" onclick="if(event.target===this)this.classList.remove('open')">
    <div class="modal-box" style="max-width:660px">
        <div class="card-header">
            <div>
                <div class="card-title">🎙️ دستیار صوتی فارسی (Ctrl+Space)</div>
                <div class="muted" style="font-size:12px">تشخیص گفتار فارسی + خوانش صوتی پاسخ + ناوبری هوشمند</div>
            </div>
            <button type="button" class="btn btn-outline btn-sm" onclick="document.getElementById('globalVoiceModal').classList.remove('open')">بستن</button>
        </div>

        <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;padding:12px 14px;border-radius:12px;background:var(--surface-2);border:1px solid var(--border);margin-bottom:12px;flex-wrap:wrap">
            <div style="display:flex;align-items:center;gap:10px">
                <button type="button" class="btn btn-primary btn-sm" id="voiceMicStartBtn" onclick="window.toggleLiveSpeechRecognition('globalVoiceInput')">
                    شروع شنیدن میکروفون
                </button>
                <div class="voice-wave-bars" id="modalWaveBars"><span></span><span></span><span></span><span></span><span></span></div>
                <span id="voiceStatusLabel" class="muted" style="font-size:12px">آماده دریافت فرمان...</span>
            </div>
            <label style="font-size:12px;display:inline-flex;align-items:center;gap:5px;cursor:pointer">
                <input type="checkbox" id="voiceTtsToggle" checked> پاسخ صوتی
            </label>
        </div>

        <form onsubmit="event.preventDefault();window.runVoiceCommandText(document.getElementById('globalVoiceInput').value);" style="display:flex;gap:8px;margin-bottom:12px">
            <input type="text" id="globalVoiceInput" value="گزارش کامل مالی و وضعیت تراز حسابداری چهار سطحی رو بگو" placeholder="فرمان خود را بگویید یا بنویسید...">
            <button type="submit" class="btn btn-primary btn-sm">اجرا</button>
        </form>

        <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:12px">
            <button type="button" class="btn btn-outline btn-sm" onclick="window.runVoiceCommandText('گزارش جامع مدیریتی کل سامانه رو بگو')">گزارش کلان مدیریتی</button>
            <button type="button" class="btn btn-outline btn-sm" onclick="window.runVoiceCommandText('گزارش کامل مالی و تراز حسابداری رو بگو')">گزارش زنده مالی</button>
            <button type="button" class="btn btn-outline btn-sm" onclick="window.runVoiceCommandText('راهنمای این بخش رو بگو')">راهنمای همین صفحه</button>
            <button type="button" class="btn btn-outline btn-sm" onclick="window.runVoiceCommandText('از جدول این صفحه خروجی اکسل بگیر')">خروجی اکسل جدول</button>
        </div>

        <div id="globalVoiceOutput" style="display:none;padding:14px;border-radius:12px;background:var(--surface-2);border:1px solid var(--primary)"></div>
    </div>
</div>

<!-- ==================== GAMIFICATION MODAL ==================== -->
<div class="modal-backdrop" id="gamificationQuickModal" onclick="if(event.target===this)this.classList.remove('open')">
    <div class="modal-box" style="max-width:620px">
        <div class="card-header">
            <div>
                <div class="card-title">🏆 پروفایل مهارتی و گیمیفیکیشن شما</div>
                <div class="muted" style="font-size:12px">هر فعالیت آموزشی، آزمون و مطالعه امتیاز XP و سکه مهارت ثبت می‌کند</div>
            </div>
            <button type="button" class="btn btn-outline btn-sm" data-close-modal onclick="document.getElementById('gamificationQuickModal').classList.remove('open')">بستن</button>
        </div>
        <div class="grid grid-3" style="margin-bottom:14px">
            <div class="stat-card" style="padding:14px"><div><div class="stat-label">سطح فعلی</div><strong style="color:var(--primary)">Lv.<?= fa($gHud['level_num']) ?> — <?= e($gHud['rank_title']) ?></strong></div></div>
            <div class="stat-card" style="padding:14px"><div><div class="stat-label">امتیاز کل</div><strong id="modalLiveXp"><?= fa(number_format($gHud['xp_points'])) ?> XP</strong></div></div>
            <div class="stat-card" style="padding:14px"><div><div class="stat-label">سکه مهارت</div><strong style="color:var(--gold)"><?= fa(number_format($gHud['chamber_coins'])) ?> سکه</strong></div></div>
        </div>
        <div style="margin-bottom:16px">
            <div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:6px">
                <span>پیشرفت تا سطح بعدی (<?= fa(number_format($gHud['next_level_xp'])) ?> XP)</span>
                <strong><?= fa($gHud['level_progress_pct']) ?>٪ • 🔥 <?= fa($gHud['streak_days']) ?> روز پیاپی</strong>
            </div>
            <div class="progress-track"><div class="progress-fill" style="width:<?= (int)$gHud['level_progress_pct'] ?>%"></div></div>
        </div>
        <div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap">
            <button type="button" class="btn btn-outline btn-sm" onclick="window.chamberRecordMicroXp(<?= js_attr($currentRoute ?: 'dashboard') ?>, 'ثبت تعامل فعال در بخش جاری', 35)">+ ثبت پالس مطالعه (+۳۵ XP)</button>
            <?php if (\App\Core\App::canViewRoute('gamification-analytics')): ?>
                <a href="<?= e(url('gamification-analytics')) ?>" class="btn btn-primary btn-sm">مشاهده داشبورد کامل رفتار و جوایز ←</a>
            <?php else: ?>
                <span style="font-size:11.5px;color:var(--text-dim);align-self:center">🏅 رتبه و سکه شما در «پرونده آموزشی» قابل مشاهده است</span>
            <?php endif; ?>
        </div>
    </div>
</div>

<?= \App\Services\ContextualHelpEncyclopediaService::renderPageHelpModalAndFloatingTrigger($currentRoute ?: 'dashboard', Auth::roleLabel()) ?>

<script src="<?= e(asset('js/app.js')) ?>?v=<?= e(asset_ver('js/app.js')) ?>.<?= e($themeRev) ?>"></script>
</body>
</html>
