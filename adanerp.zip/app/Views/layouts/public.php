<?php
use App\Core\App;
use App\Core\Auth;
use App\Core\Jalali;
use App\Services\EnterpriseSettingsIamService;

$pubLiveTheme = EnterpriseSettingsIamService::getActiveThemeProfile();
$pubThemeRev  = EnterpriseSettingsIamService::getThemeRevisionHash();
$pubRouteNow  = App::currentRoute() ?: 'public-home';
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl"
      <?= ($pubLiveTheme['color_mode'] ?? 'light') === 'dark' ? 'data-theme="dark"' : 'data-theme="light"' ?>
      data-server-theme="<?= e($pubLiveTheme['color_mode'] ?? 'light') ?>"
      data-theme-rev="<?= e($pubThemeRev) ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($pageTitle ?? 'پورتال عمومی') ?> | <?= e($pubLiveTheme['brand_org_title'] ?? $chamberName) ?></title>
    <link rel="manifest" href="<?= e(App::basePath() . '/manifest.webmanifest') ?>">
    <link rel="stylesheet" href="<?= e(asset('css/app.css')) ?>?v=<?= e(asset_ver('css/app.css')) ?>.<?= e($pubThemeRev) ?>">
    <?= EnterpriseSettingsIamService::renderLiveThemeCssBlock() ?>
</head>
<body class="public-bg" data-base-url="<?= e(App::basePath()) ?>">
<header class="topbar no-print">
    <div class="topbar-right">
        <div class="brand-crest" style="width:38px;height:38px;font-size:14px"><?= e($pubLiveTheme['brand_monogram'] ?? 'ناب') ?></div>
        <div>
            <div style="font-weight:700;font-size:14px"><?= e($pubLiveTheme['brand_org_title'] ?? $chamberName) ?></div>
            <div class="muted" style="font-size:11.5px"><?= e($pubLiveTheme['brand_unit_subtitle'] ?? $unitName) ?> • <?= e(Jalali::todayFull()) ?></div>
        </div>
    </div>
    <div class="topbar-left">
        <a class="btn btn-outline btn-sm" href="<?= e(url('public-home')) ?>">پورتال دوره‌ها</a>
        <a class="btn btn-outline btn-sm" href="<?= e(url('verify')) ?>">استعلام گواهی QR</a>
        <button type="button" class="icon-btn" data-open-modal="pageContextualHelpModal" title="راهنمای همین صفحه (F1)">❓</button>
        <button type="button" class="icon-btn" id="themeToggleBtn" title="تغییر حالت روشن / تیره">🌓</button>
        <?php if (Auth::check()): ?>
            <a class="btn btn-primary btn-sm" href="<?= e(url('dashboard')) ?>">پیشخوان من</a>
        <?php else: ?>
            <a class="btn btn-primary btn-sm" href="<?= e(url('login')) ?>">ورود به سامانه</a>
        <?php endif; ?>
    </div>
</header>

<main class="content-wrap">
    <?php if ($flash): ?>
        <div class="alert alert-<?= e($flash['type']) ?>">
            <div><?= e($flash['message']) ?></div>
        </div>
    <?php endif; ?>
    <?= $content ?>
</main>
<?= \App\Services\ContextualHelpEncyclopediaService::renderPageHelpModalAndFloatingTrigger($pubRouteNow, Auth::check() ? Auth::roleLabel() : 'مخاطب عمومی') ?>
<script src="<?= e(asset('js/app.js')) ?>?v=<?= e(asset_ver('js/app.js')) ?>.<?= e($pubThemeRev) ?>"></script>
</body>
</html>
