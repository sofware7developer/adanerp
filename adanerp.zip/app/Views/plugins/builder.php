<?php $latest = $pages[0] ?? []; ?>
<div class="hero-banner">
    <div>
        <span class="badge badge-gold">افزونه سراسری — وب‌سایت‌ساز و سازنده ویترین پورتال</span>
        <h1>وب‌سایت‌ساز پورتال آدان: پیش‌نمایش، نسخه‌بندی، انتشار و بازگردانی</h1>
        <p>ویرایش بی‌نیاز از کدنویسی صفحه اول پورتال عمومی با نگهداری تمام نسخه‌ها و قابلیت بازگشت آنی به نسخه قبلی.</p>
    </div>
    <a class="btn btn-gold" href="<?= e(url('public-home')) ?>">👁️ پیش‌نمایش زنده پورتال عمومی</a>
</div>

<div class="grid grid-sidebar">
    <div class="card">
        <div class="card-header"><div class="card-title">🎨 ایجاد و انتشار نسخه جدید صفحه اصلی پورتال</div></div>
        <form method="post" action="<?= e(url('portal-builder')) ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="create_version">
            <div class="form-group">
                <label>نوار اعلان بالای سایت:</label>
                <input type="text" name="announcement_bar" value="<?= e($latest['announcement_bar'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>تیتر اصلی قهرمان (Hero Title):</label>
                <input type="text" name="hero_title" value="<?= e($latest['hero_title'] ?? '') ?>" required>
            </div>
            <div class="form-group">
                <label>زیرتیتر معرفی مرکز آموزش آدان:</label>
                <textarea name="hero_subtitle" rows="2"><?= e($latest['hero_subtitle'] ?? '') ?></textarea>
            </div>
            <div class="form-group">
                <label>کارت‌های خدمات ویژه (جداشده با کاما):</label>
                <input type="text" name="boxes_csv" value="آکادمی تجارت بین‌الملل, استعلام گواهی QR, قراردادهای سازمانی, همراه هوشمند AI">
            </div>
            <button type="submit" class="btn btn-primary">ذخیره نسخه جدید و انتشار فوری</button>
        </form>
    </div>

    <div class="card">
        <div class="card-header"><div class="card-title">⏪ تاریخچه نسخه‌ها و بازگردانی (Version Rollback)</div></div>
        <?php foreach ($pages as $pg): ?>
            <div style="border:1px solid var(--border);border-radius:12px;padding:12px;margin-bottom:10px">
                <div style="display:flex;justify-content:space-between;align-items:center">
                    <strong>نسخه v<?= fa($pg['version_no']) ?> — ویرایشگر: <?= e($pg['full_name']) ?></strong>
                    <span class="badge <?= (int)$pg['is_published'] === 1 ? 'badge-success' : 'badge-info' ?>">
                        <?= (int)$pg['is_published'] === 1 ? 'منتشرشده فعلی' : 'آرشیو' ?>
                    </span>
                </div>
                <p class="muted" style="font-size:12px;margin:6px 0"><?= e($pg['hero_title']) ?></p>
                <?php if ((int)$pg['is_published'] !== 1): ?>
                    <form method="post" action="<?= e(url('portal-builder')) ?>">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="rollback_version">
                        <input type="hidden" name="page_id" value="<?= (int)$pg['id'] ?>">
                        <button type="submit" class="btn btn-outline btn-sm">↩️ بازگردانی و فعال‌سازی این نسخه</button>
                    </form>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>
</div>
