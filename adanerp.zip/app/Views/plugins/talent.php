<div class="hero-banner">
    <div>
        <span class="badge badge-gold">افزونه‌های استعداد، روان‌سنجی قطعی، ربات تلگرام و PWA</span>
        <h1>مرکز روان‌سنجی شغلی قطعی، گذرنامه استعداد، تلگرام و PWA</h1>
        <p>ارزیابی قطعی سبک مذاکره و کار، مدیریت حریم خصوصی گذرنامه مهارت، نشان‌های دیجیتال و اتصال ربات تلگرام و پوسته PWA.</p>
    </div>
    <a class="btn btn-gold" href="<?= e(url('passport', ['u' => $currentUser['public_passport_slug'] ?? 'mehrdad-sharifi'])) ?>">🎖️ مشاهده گذرنامه عمومی من</a>
</div>

<div class="alert alert-warning">
    <div>
        <strong>تذکر حرفه‌ای و فنی:</strong> ۱) آزمون روان‌سنجی زیر با <strong>فرمول ریاضی قطعی (Deterministic)</strong> نمره‌دهی می‌شود، نتایج محرمانه هستند و <strong>ابزار تشخیص بالینی یا روان‌پزشکی محسوب نمی‌شود.</strong> ۲) پوسته PWA نصب‌پذیر است و حالت آفلاین محدود پوسته را پوشش می‌دهد (محتوای حجیم آموزشی آفلاین کامل نیست).
    </div>
</div>

<div class="grid grid-2">
    <!-- DETERMINISTIC PSYCHOMETRICS -->
    <div class="card">
        <div class="card-header"><div class="card-title">🧠 آزمون سبک مذاکره تجاری و شایستگی رفتاری (نمره‌دهی قطعی)</div></div>
        <form method="post" action="<?= e(url('talent-psych')) ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="run_psychometric">
            <div class="form-group">
                <label>۱. اتکا به داده‌های آماری، تعرفه گمرکی و جزئیات قراردادی (۱ تا ۵):</label>
                <input type="number" name="q_analytical" value="5" min="1" max="5">
            </div>
            <div class="form-group">
                <label>۲. گرایش به ساخت توافق برد-برد و رابطه بلندمدت تجاری (۱ تا ۵):</label>
                <input type="number" name="q_collaborative" value="4" min="1" max="5">
            </div>
            <div class="form-group">
                <label>۳. سرعت جمع‌بندی و قاطعیت در مذاکرات دشوار (۱ تا ۵):</label>
                <input type="number" name="q_decisive" value="4" min="1" max="5">
            </div>
            <div class="form-group">
                <label>۴. تاب‌آوری در برابر نوسان ارزی و تغییرات مقرراتی (۱ تا ۵):</label>
                <input type="number" name="q_resilience" value="5" min="1" max="5">
            </div>
            <button type="submit" class="btn btn-primary">محاسبه قطعی نیمرخ مهارتی</button>
        </form>

        <?php foreach ($psychResults as $pr): ?>
            <div style="border-top:1px solid var(--border);margin-top:14px;padding-top:10px;font-size:12.5px">
                <strong><?= e($pr['full_name']) ?> — سبک غالب: <?= e($pr['dominant_style']) ?></strong>
                <div class="muted">تحلیلی: <?= fa($pr['analytical_score']) ?> | تعاملی: <?= fa($pr['collaborative_score']) ?> | قاطعیت: <?= fa($pr['decisive_score']) ?> | تاب‌آوری: <?= fa($pr['resilience_score']) ?></div>
            </div>
        <?php endforeach; ?>
    </div>

    <!-- PASSY PRIVACY + TELEGRAM BOT + PWA -->
    <div class="card">
        <div class="card-header"><div class="card-title">🎖️ حریم خصوصی گذرنامه استعداد + اتصال تلگرام و PWA</div></div>
        <form method="post" action="<?= e(url('talent-psych')) ?>" style="margin-bottom:16px">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="toggle_passport_privacy">
            <p style="font-size:13px;margin-bottom:8px">
                وضعیت فعلی پروفایل عمومی شما:
                <span class="badge <?= (int)($currentUser['passport_is_public'] ?? 0) === 1 ? 'badge-success' : 'badge-warning' ?>">
                    <?= (int)($currentUser['passport_is_public'] ?? 0) === 1 ? 'عمومی (قابل مشاهده با لینک اختصاصی)' : 'خصوصی (مخفی)' ?>
                </span>
            </p>
            <button type="submit" class="btn btn-outline btn-sm">تغییر وضعیت عمومی/خصوصی گذرنامه</button>
        </form>

        <div style="border-top:1px solid var(--border);padding-top:14px">
            <strong style="font-size:13px">✈️ شبیه‌ساز وب‌هوک ربات تلگرام (<code>POST /api/v1/telegram-webhook</code>):</strong>
            <form method="post" action="<?= e(url('talent-psych')) ?>" style="display:flex;gap:8px;margin-top:8px">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="simulate_telegram">
                <input type="text" name="bot_command" value="/cert CERT-ADN-1405-9001" dir="ltr">
                <button type="submit" class="btn btn-primary btn-sm">تست دستور</button>
            </form>
            <?php if ($botOutput): ?>
                <div class="pre-box" style="margin-top:10px;font-size:12px"><?= e($botOutput) ?></div>
            <?php endif; ?>
        </div>
    </div>
</div>
