<?php
$socialPosts = $socialPosts ?? [];
$platformsMeta = $platformsMeta ?? [];
$allCourses = $allCourses ?? [];
$marketingTotals = $marketingTotals ?? [];
$platformStats = $platformStats ?? [];
$manualSpend = (int)($marketingTotals['spend'] ?? 0);
$manualRevenue = (int)($marketingTotals['revenue'] ?? 0);
$manualRoas = $manualSpend > 0 ? $manualRevenue / $manualSpend : null;
?>
<div class="hero-banner">
    <div>
        <span class="badge badge-warning">ابزار محلی طراحی محتوا؛ هیچ کانال انتشاری متصل نیست</span>
        <h1>طراحی پیش‌نویس محتوای آموزشی و مدیریت محلی کمپین‌ها</h1>
        <p>محتوا و لینک‌های UTM در سامانه ذخیره می‌شوند؛ انتشار، زمان‌بندی بیرونی، پیامک و تحلیل عملکرد فقط پس از اتصال سرویس واقعی فعال خواهند شد.</p>
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
        <a href="<?= e(url('market-radar')) ?>" class="btn btn-outline" style="background:rgba(255,255,255,0.14);color:#fff;border-color:rgba(255,255,255,0.28)">🧭 تحقیق بازار و رصد رقبا</a>
        <form method="post" action="<?= e(url('marketing-intel')) ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="toggle_consent">
            <button type="submit" class="btn btn-gold">🔔 مدیریت رضایت دریافت پیام (مخاطب مجاز: <?= fa($optedInCount) ?> نفر)</button>
        </form>
    </div>
</div>

<div class="grid grid-4" style="margin-bottom:18px">
    <div class="stat-card">
        <div>
            <div class="stat-label">محتوای دارای آمار دستی</div>
            <div class="stat-value"><?= fa($marketingTotals['posts_count'] ?? 0) ?></div>
            <div class="stat-meta">ثبت‌شده توسط کاربر؛ اتصال مستقیم فعال نیست</div>
        </div>
        <div class="stat-icon icon-purple">📱</div>
    </div>
    <div class="stat-card">
        <div>
            <div class="stat-label">کلیک / سرنخ ثبت‌شده</div>
            <div class="stat-value"><?= fa($marketingTotals['clicks'] ?? 0) ?> / <?= fa($marketingTotals['leads'] ?? 0) ?></div>
            <div class="stat-meta">ورودی‌های دستی قیف بازاریابی</div>
        </div>
        <div class="stat-icon icon-blue">🔗</div>
    </div>
    <div class="stat-card">
        <div>
            <div class="stat-label">ثبت‌نام منتسب‌شده</div>
            <div class="stat-value"><?= fa($marketingTotals['enrollments'] ?? 0) ?></div>
            <div class="stat-meta">از آمار دستی محتوای انتخاب‌شده</div>
        </div>
        <div class="stat-icon icon-teal">🎯</div>
    </div>
    <div class="stat-card">
        <div>
            <div class="stat-label">بازده هزینه ثبت‌شده (ROAS)</div>
            <div class="stat-value"><?= $manualRoas === null ? '—' : fa(number_format($manualRoas, 2)) . '×' ?></div>
            <div class="stat-meta"><?= $manualRoas === null ? 'برای محاسبه، هزینه و درآمد دستی ثبت کنید' : 'درآمد دستی ÷ هزینه دستی' ?></div>
        </div>
        <div class="stat-icon icon-gold">💰</div>
    </div>
</div>
<div class="alert alert-info" style="margin-bottom:18px">شاخص‌های این صفحه فقط از داده‌هایی محاسبه می‌شوند که کاربر صریحاً به‌صورت دستی برای یک محتوا ثبت کرده است؛ انتشار، جمع‌آوری آمار و انتساب ثبت‌نام به شبکه‌ها به‌صورت خودکار متصل نیست.</div>

<!-- Local content drafts and preview; no external publishing is configured. -->
<div class="grid grid-2" style="gap:18px;margin-bottom:18px;align-items:start">
    <!-- RIGHT: AI MULTI-NETWORK CAMPAIGN BUILDER & LAUNCHER -->
    <div class="card">
        <div class="card-header">
            <div class="card-title">پیش‌نویس محلی محتوای دوره</div>
            <span class="badge badge-info">بدون ارسال بیرونی</span>
        </div>

        <form method="post" action="<?= e(url('marketing-intel')) ?>" id="social360Form">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="launch_360_social_campaign">

            <div class="form-grid">
                <div class="form-group">
                    <label>انتخاب دوره هدف جهت تبلیغ:</label>
                    <select name="course_title" id="socCourseSelect" onchange="window.refreshSocialLiveMockup()">
                        <?php foreach ($allCourses as $crs): ?>
                            <option value="<?= e($crs['title']) ?>"><?= e($crs['title']) ?></option>
                        <?php endforeach; ?>
                        <?php if (empty($allCourses)): ?>
                            <option value="دوره کاربردی حسابداری">دوره کاربردی حسابداری</option>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>عنوان کمپین یکپارچه:</label>
                    <input type="text" name="campaign_title" id="socCampTitle" value="معرفی دوره‌های مهارتی حسابداری آدان" oninput="window.refreshSocialLiveMockup()">
                </div>
                <div class="form-group">
                    <label>پرسونای مخاطب هدف:</label>
                    <select name="target_persona" id="socPersonaSelect" onchange="window.refreshSocialLiveMockup()">
                        <option value="هنرجویان حسابداری">هنرجویان حسابداری</option>
                        <option value="حسابداران شاغل و کمک‌حسابداران">حسابداران شاغل و کمک‌حسابداران</option>
                        <option value="مدیران مالی و صاحبان کسب‌وکار">مدیران مالی و صاحبان کسب‌وکار</option>
                        <option value="فارغ‌التحصیلان جویای کار در امور مالی">فارغ‌التحصیلان جویای کار در امور مالی</option>
                    </select>
                </div>
            </div>

            <div style="margin:12px 0">
                <label style="display:block;font-size:12.5px;font-weight:800;margin-bottom:8px">کانال‌های هدف برای پیش‌نمایش محتوا:</label>
                <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(165px,1fr));gap:8px">
                    <?php foreach ($platformsMeta as $pKey => $pm): ?>
                        <label style="display:flex;align-items:center;gap:7px;padding:8px 10px;border-radius:10px;background:var(--surface-2);border:1px solid var(--border);cursor:pointer;font-size:12px;font-weight:700"
                               onclick="window.previewPlatformTab('<?= e($pKey) ?>')">
                            <input type="checkbox" name="platforms[]" value="<?= e($pKey) ?>"
                                   <?= in_array($pKey, ['instagram', 'linkedin', 'telegram', 'whatsapp', 'eitaa_bale'], true) ? 'checked' : '' ?>>
                            <span><?= $pm['icon'] ?> <?= e($pm['label']) ?></span>
                        </label>
                    <?php endforeach; ?>
                </div>
            </div>

            <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px">
                <button type="button" class="btn btn-gold" onclick="window.fetchSocialDraftFromServer()">ساخت پیشنهاد متن برای پیش‌نویس‌ها</button>
                <button type="submit" class="btn btn-primary">ذخیره پیش‌نویس‌های انتخابی</button>
            </div>
        </form>

        <!-- SINGLE POST COMPOSER -->
        <div style="margin-top:18px;padding-top:16px;border-top:1px dashed var(--border)">
            <strong style="font-size:13px;display:block;margin-bottom:8px">ثبت پیش‌نویس محلی (همراه لینک UTM):</strong>
            <form method="post" action="<?= e(url('marketing-intel')) ?>">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="create_social_post">
                <div class="form-grid">
                    <select name="target_course_title" required>
                        <option value="">انتخاب دوره هدف</option>
                        <?php foreach ($allCourses as $course): ?>
                            <option value="<?= e($course['title']) ?>"><?= e($course['title']) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <select name="campaign_id">
                        <option value="0">بدون اتصال به کمپین</option>
                        <?php foreach ($campaigns as $campaign): ?>
                            <option value="<?= (int)$campaign['id'] ?>"><?= e($campaign['title']) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <select name="platform" id="singlePlatformSel">
                        <?php foreach ($platformsMeta as $pk => $pm): ?>
                            <option value="<?= e($pk) ?>"><?= $pm['icon'] ?> <?= e($pm['label']) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <input type="text" name="content_format" value="پیش‌نویس محتوای آموزشی">
                    <input type="text" name="hook_headline" required placeholder="تیتر / پیام اصلی">
                    <input type="text" name="scheduled_shamsi" placeholder="زمان پیشنهادی محلی؛ مثال ۱۴۰۵/۰۸/۰۶ ساعت ۱۹:۰۰">
                </div>
                <textarea name="caption_body" id="singleCaptionTextarea" maxlength="10000" rows="3" style="margin-top:8px" required placeholder="متن پست شبکه اجتماعی..."></textarea>
                <input type="text" name="hashtags" id="singleHashtagsInput" value="#آموزش_حسابداری #آدان" style="margin-top:6px">
                <div style="display:flex;gap:8px;margin-top:8px">
                    <span class="badge badge-warning">انتشار واقعی متصل نیست</span>
                    <button type="submit" class="btn btn-outline btn-sm">ذخیره پیش‌نویس</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Local content preview -->
    <div style="display:flex;flex-direction:column;gap:16px">
        <div class="card">
            <div class="card-header">
                <div class="card-title">📱 پیش‌نمایش محلی (در شبکه منتشر نمی‌شود)</div>
                <div style="display:flex;gap:5px;flex-wrap:wrap">
                    <button type="button" class="btn btn-primary btn-sm" onclick="window.previewPlatformTab('instagram')">📸 اینستاگرام</button>
                    <button type="button" class="btn btn-outline btn-sm" onclick="window.previewPlatformTab('linkedin')">💼 لینکدین</button>
                    <button type="button" class="btn btn-outline btn-sm" onclick="window.previewPlatformTab('telegram')">✈️ تلگرام</button>
                    <button type="button" class="btn btn-outline btn-sm" onclick="window.previewPlatformTab('whatsapp')">💬 واتساپ</button>
                </div>
            </div>

            <!-- Local preview frame -->
            <div style="max-width:390px;margin:0 auto;border:6px solid #1e293b;border-radius:28px;overflow:hidden;background:var(--surface);box-shadow:0 16px 36px rgba(15,23,42,0.16)">
                <div id="mockPhoneHeader" style="padding:12px 16px;background:linear-gradient(90deg,#833ab4,#fd1d1d,#fcb045);color:#fff;display:flex;justify-content:space-between;align-items:center;font-size:12.5px;font-weight:800">
                    <span id="mockPlatformName">Instagram • پیش‌نمایش محلی</span>
                    <span>نمونه</span>
                </div>

                <!-- VISUAL CREATIVE BANNER INSIDE PHONE -->
                <div style="padding:20px 18px;background:linear-gradient(135deg,#0b2545,#134e4a);color:#fff;text-align:center">
                    <span style="display:inline-block;padding:3px 10px;border-radius:999px;background:rgba(251,191,36,0.22);border:1px solid #fbbf24;color:#fde68a;font-size:11px;font-weight:700">
                        پیش‌نویس؛ جزئیات را بررسی کنید
                    </span>
                    <div id="mockVisualHeadline" style="font-size:15px;font-weight:900;margin:10px 0 6px;line-height:1.6">
                        دوره جامع کاربرد هوش مصنوعی در صادرات و گمرک
                    </div>
                    <div style="font-size:11.5px;opacity:0.85">محتوای نمونه؛ پیش از انتشار بازبینی شود</div>
                </div>

                <div style="padding:14px 16px">
                    <div style="display:flex;justify-content:space-between;margin-bottom:8px;font-size:16px">
                        <span>❤️ 💬 🚀</span>
                        <span>🔖</span>
                    </div>
                    <div id="mockCaptionText" style="font-size:12.5px;line-height:1.8;white-space:pre-line;color:var(--text)"></div>
                    <div id="mockHashtagsText" style="margin-top:8px;font-size:11.5px;color:#2563eb;font-weight:600">
                        #آموزش_حسابداری #آدان #مهارت_مالی
                    </div>
                    <div style="margin-top:10px;padding:8px 10px;border-radius:9px;background:var(--surface-2);font-size:11px;direction:ltr;text-align:left;overflow-x:auto">
                        <code id="mockUtmUrl">نشانی نمونه؛ رهگیری متصل نیست</code>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header"><div class="card-title">گزارش عملکرد کانال‌ها</div></div>
            <div class="table-wrap">
                <table>
                    <thead><tr><th>کانال</th><th>محتوا</th><th>بازدید</th><th>کلیک</th><th>CTR</th><th>سرنخ</th><th>ثبت‌نام</th><th>تبدیل سرنخ به ثبت‌نام</th><th>ROAS دستی</th></tr></thead>
                    <tbody>
                    <?php foreach ($platformStats as $stat): ?>
                        <?php $channelRoas = (int)$stat['spend'] > 0 ? (int)$stat['rev'] / (int)$stat['spend'] : null; ?>
                        <?php $channelCtr = (int)$stat['imp'] > 0 ? ((int)$stat['clk'] / (int)$stat['imp']) * 100 : null; ?>
                        <?php $channelEnrollRate = (int)$stat['lds'] > 0 ? ((int)$stat['conv'] / (int)$stat['lds']) * 100 : null; ?>
                        <?php $channelMeta = $platformsMeta[$stat['platform']] ?? ['icon' => '📣', 'label' => $stat['platform']]; ?>
                        <tr>
                            <td><?= $channelMeta['icon'] ?> <?= e($channelMeta['label']) ?></td>
                            <td><?= fa($stat['posts_cnt']) ?></td>
                            <td><?= fa($stat['imp']) ?></td>
                            <td><?= fa($stat['clk']) ?></td>
                            <td><?= $channelCtr === null ? '—' : fa(number_format($channelCtr, 1)) . '٪' ?></td>
                            <td><?= fa($stat['lds']) ?></td>
                            <td><?= fa($stat['conv']) ?></td>
                            <td><?= $channelEnrollRate === null ? '—' : fa(number_format($channelEnrollRate, 1)) . '٪' ?></td>
                            <td><?= $channelRoas === null ? '—' : fa(number_format($channelRoas, 2)) . '×' ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (empty($socialPosts)): ?>
                        <tr><td colspan="7" class="muted">هنوز پیش‌نویس محتوایی ثبت نشده است.</td></tr>
                    <?php endif; ?>
                    <?php if (empty($platformStats)): ?>
                        <tr><td colspan="9" class="muted">هنوز آمار دستی برای هیچ کانالی ثبت نشده است.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- LOCAL SOCIAL CONTENT CALENDAR; NO PUBLISHER OR ANALYTICS API IS CONNECTED -->
<div class="card" style="margin-bottom:18px">
    <div class="card-header">
        <div class="card-title">🗓️ پیش‌نویس محلی محتوای شبکه‌های اجتماعی</div>
        <span class="badge badge-warning">انتشار و آمار واقعی متصل نیست</span>
    </div>
    <div class="table-wrap">
        <table>
            <thead>
            <tr>
                <th>شبکه اجتماعی</th>
                <th>قالب / کمپین</th>
                <th>پیش‌نمایش کپشن و نشانی نمونه</th>
                <th>زمان پیشنهادی (بدون ارسال)</th>
                <th>آمار دستی ثبت‌شده</th>
                <th>هزینه / درآمد دستی</th>
                <th>وضعیت اتصال</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($socialPosts as $sp): ?>
                <?php $meta = $platformsMeta[$sp['platform']] ?? ['icon' => '📣', 'label' => $sp['platform']]; ?>
                <tr>
                    <td><strong><?= $meta['icon'] ?> <?= e($meta['label']) ?></strong></td>
                    <td>
                        <span class="badge badge-info"><?= e($sp['content_format'] ?? 'پست و استوری') ?></span>
                        <div class="muted" style="font-size:11.5px;margin-top:3px"><?= e($sp['target_course_title'] ?? '') ?></div>
                        <div class="muted" style="font-size:11px;margin-top:3px"><?= e($sp['campaign_title'] ?? 'بدون اتصال به کمپین') ?></div>
                    </td>
                    <td style="max-width:300px">
                        <div style="font-size:12px;line-height:1.5"><?= e(mb_substr((string)($sp['caption_body'] ?? ''), 0, 95)) ?>...</div>
                        <code style="font-size:10.5px;color:var(--primary)"><?= e($sp['utm_url'] ?? '') ?></code>
                    </td>
                    <td><?= e($sp['scheduled_shamsi']) ?></td>
                    <td style="font-size:12px">
                        <?php if (($sp['publish_status'] ?? '') === 'metrics_manual'): ?>
                            <?= fa($sp['impressions_count']) ?> بازدید · <?= fa($sp['clicks_count']) ?> کلیک · <?= fa($sp['leads_generated']) ?> سرنخ · <?= fa($sp['enrollments_converted']) ?> ثبت‌نام
                        <?php else: ?>
                            <span class="muted">ثبت نشده</span>
                        <?php endif; ?>
                    </td>
                    <td style="font-size:12px">
                        <?php if (($sp['publish_status'] ?? '') === 'metrics_manual'): ?>
                            <?= fa(number_format((int)$sp['spend_rial'])) ?> / <?= fa(number_format((int)$sp['revenue_rial'])) ?> ریال
                        <?php else: ?>
                            —
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if (($sp['publish_status'] ?? '') === 'metrics_manual'): ?>
                            <span class="badge badge-success">آمار دستی</span>
                        <?php elseif (($sp['publish_status'] ?? '') === 'simulated_published' || ($sp['publish_status'] ?? '') === 'published'): ?>
                            <span class="badge badge-warning">نمونهٔ قدیمی؛ انتشار واقعی تأیید نشده</span>
                        <?php elseif (($sp['publish_status'] ?? '') === 'scheduled_local'): ?>
                            <span class="badge badge-info">پیش‌نویس محلی؛ منتشر نشده</span>
                        <?php else: ?>
                            <form method="post" action="<?= e(url('marketing-intel')) ?>">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="publish_social_post">
                                <input type="hidden" name="post_id" value="<?= (int)$sp['id'] ?>">
                                <button type="submit" class="btn btn-outline btn-sm">ثبت در تقویم محلی</button>
                            </form>
                        <?php endif; ?>
                        <details style="margin-top:7px">
                            <summary style="cursor:pointer;font-size:11px">ثبت آمار گزارش‌شده</summary>
                            <form method="post" action="<?= e(url('marketing-intel')) ?>" style="min-width:250px;padding-top:8px">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="update_social_metrics">
                                <input type="hidden" name="post_id" value="<?= (int)$sp['id'] ?>">
                                <?php
                                $metricInputs = [
                                    'impressions_count' => 'بازدید',
                                    'engagements_count' => 'تعامل',
                                    'clicks_count' => 'کلیک',
                                    'leads_generated' => 'سرنخ',
                                    'enrollments_converted' => 'ثبت‌نام',
                                    'spend_rial' => 'هزینه (ریال)',
                                    'revenue_rial' => 'درآمد (ریال)',
                                ];
                                ?>
                                <?php foreach ($metricInputs as $metricName => $metricLabel): ?>
                                    <label style="display:block;margin:4px 0;font-size:11px"><?= e($metricLabel) ?>
                                        <input type="number" min="0" step="1" required name="<?= e($metricName) ?>"
                                               value="<?= ($sp['publish_status'] ?? '') === 'metrics_manual' ? (int)$sp[$metricName] : '' ?>">
                                    </label>
                                <?php endforeach; ?>
                                <button type="submit" class="btn btn-primary btn-sm">ثبت دستی</button>
                            </form>
                        </details>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Locally stored campaign drafts; no sending or analytics provider is connected. -->
<div class="card">
    <div class="card-header">
        <div class="card-title">پیش‌نویس دو نسخه پیام (A/B) برای بررسی انسانی</div>
    </div>
    <div class="grid grid-2" style="gap:16px;align-items:start">
        <form method="post" action="<?= e(url('marketing-intel')) ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="create_ab_campaign">
            <div class="form-grid">
                <input type="text" name="title" required placeholder="عنوان آزمون A/B کمپین آموزشی">
                <input type="text" name="segment_name" maxlength="140" required value="اعضای دارای کارت بازرگانی (Opt-in)">
                <input type="text" name="scheduled_shamsi" placeholder="زمان‌بندی پیشنهادی محلی">
                <select name="channel">
                    <option value="sms_sandbox">پیامک (شبیه‌سازی محلی)</option>
                    <option value="email_sandbox">ایمیل (شبیه‌سازی محلی)</option>
                    <option value="telegram_sandbox">تلگرام (شبیه‌سازی محلی)</option>
                </select>
            </div>
            <div class="form-group" style="margin-top:8px">
                <input type="text" name="variant_a_text" required placeholder="نسخه A (متن پیشنهادی آموزشی)...">
            </div>
            <div class="form-group">
                <input type="text" name="variant_b_text" required placeholder="نسخه B (متن پیشنهادی آموزشی)...">
            </div>
            <button type="submit" class="btn btn-primary btn-sm">ثبت پیش‌نویس محلی برای تأیید</button>
        </form>

        <div class="table-wrap">
            <table>
                <thead><tr><th>کمپین و نسخه‌ها</th><th>کانال نمونه</th><th>زمان‌بندی محلی</th><th>محتوای متصل</th><th>وضعیت محلی</th><th>تأیید / ویرایش</th></tr></thead>
                <tbody>
                <?php if (empty($campaigns)): ?>
                    <tr><td colspan="6" class="muted">هنوز کمپینی ثبت نشده است.</td></tr>
                <?php endif; ?>
                <?php foreach ($campaigns as $c): ?>
                    <tr>
                        <td>
                            <strong><?= e($c['title']) ?></strong>
                            <div class="muted" style="font-size:11px"><?= e($c['segment_name']) ?></div>
                            <details style="margin-top:5px">
                                <summary style="cursor:pointer;font-size:11px">مشاهده نسخه‌های A/B</summary>
                                <div style="font-size:11px;margin-top:5px"><strong>A:</strong> <?= e($c['variant_a_text']) ?></div>
                                <div style="font-size:11px;margin-top:5px"><strong>B:</strong> <?= e($c['variant_b_text']) ?></div>
                            </details>
                        </td>
                        <td><span class="badge badge-info"><?= e($c['channel']) ?></span></td>
                        <td><?= e($c['scheduled_shamsi'] ?? 'زمان‌بندی نشده') ?></td>
                        <td><?= fa($c['social_posts_count'] ?? 0) ?> پیش‌نویس</td>
                        <td>
                            <?php if (($c['status'] ?? '') === 'awaiting_approval'): ?>
                                <span class="badge badge-info">در انتظار تأیید</span>
                            <?php else: ?>
                                <span class="badge badge-warning">تأیید محلی؛ ارسال نشده</span>
                            <?php endif; ?>
                            <span class="badge badge-warning">آمار تبدیل واقعی پس از اتصال در دسترس است</span>
                        </td>
                        <td>
                            <?php if (($c['status'] ?? '') === 'awaiting_approval'): ?>
                                <form method="post" action="<?= e(url('marketing-intel')) ?>">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action" value="approve_and_send">
                                    <input type="hidden" name="campaign_id" value="<?= (int)$c['id'] ?>">
                                    <button type="submit" class="btn btn-gold btn-sm">تأیید پیش‌نویس محلی</button>
                                </form>
                                <details style="margin-top:7px">
                                    <summary style="cursor:pointer;font-size:11px">ویرایش پیش‌نویس</summary>
                                    <form method="post" action="<?= e(url('marketing-intel')) ?>" style="min-width:240px;padding-top:8px">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="action" value="update_ab_campaign">
                                        <input type="hidden" name="campaign_id" value="<?= (int)$c['id'] ?>">
                                        <input type="text" name="title" maxlength="200" required value="<?= e($c['title']) ?>">
                                        <input type="text" name="segment_name" maxlength="140" required value="<?= e($c['segment_name']) ?>" style="margin-top:5px">
                                        <select name="channel" style="margin-top:5px">
                                            <option value="sms_sandbox" <?= $c['channel'] === 'sms_sandbox' ? 'selected' : '' ?>>پیامک محلی</option>
                                            <option value="email_sandbox" <?= $c['channel'] === 'email_sandbox' ? 'selected' : '' ?>>ایمیل محلی</option>
                                            <option value="telegram_sandbox" <?= $c['channel'] === 'telegram_sandbox' ? 'selected' : '' ?>>تلگرام محلی</option>
                                        </select>
                                        <input type="text" name="scheduled_shamsi" maxlength="40" value="<?= e($c['scheduled_shamsi']) ?>" style="margin-top:5px">
                                        <textarea name="variant_a_text" maxlength="400" required rows="2" style="margin-top:5px"><?= e($c['variant_a_text']) ?></textarea>
                                        <textarea name="variant_b_text" maxlength="400" required rows="2" style="margin-top:5px"><?= e($c['variant_b_text']) ?></textarea>
                                        <button type="submit" class="btn btn-outline btn-sm" style="margin-top:5px">ذخیره ویرایش</button>
                                    </form>
                                </details>
                            <?php else: ?>
                                <span class="badge badge-warning">تأییدشدهٔ محلی؛ ارسال انجام نشده</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
window.__activePreviewPlatform = 'instagram';
window.previewPlatformTab = function (plat) {
    window.__activePreviewPlatform = plat || 'instagram';
    window.refreshSocialLiveMockup();
};
window.refreshSocialLiveMockup = function () {
    var plat = window.__activePreviewPlatform || 'instagram';
    var course = (document.getElementById('socCourseSelect') || {}).value || 'دوره حسابداری';
    var persona = (document.getElementById('socPersonaSelect') || {}).value || 'هنرجویان حسابداری';
    var hdr = document.getElementById('mockPhoneHeader');
    var pName = document.getElementById('mockPlatformName');
    var styles = {
    instagram: ['Instagram • پیش‌نمایش محلی', 'linear-gradient(90deg,#833ab4,#fd1d1d,#fcb045)'],
    linkedin:  ['LinkedIn • پیش‌نمایش محلی', 'linear-gradient(90deg,#0a66c2,#004182)'],
    telegram:  ['Telegram • پیش‌نمایش محلی', 'linear-gradient(90deg,#229ed9,#1b7db0)'],
    whatsapp:  ['WhatsApp • پیش‌نمایش محلی', 'linear-gradient(90deg,#128c7e,#25d366)'],
    eitaa_bale:['پیام‌رسان • پیش‌نمایش محلی', 'linear-gradient(90deg,#0d9488,#059669)']
    };
    var cfg = styles[plat] || styles.instagram;
    if (hdr) hdr.style.background = cfg[1];
    if (pName) pName.textContent = cfg[0];
    document.getElementById('mockVisualHeadline').textContent = course;
    var body = '🔥 ویژه ' + persona + ':\n'
        + 'اطلاعات دوره «' + course + '» را ببینید و برای جزئیات با آموزشگاه تماس بگیرید.\n'
        + 'پیش‌نویس تبلیغاتی است؛ جزئیات دوره را پیش از انتشار بررسی کنید.';
    document.getElementById('mockCaptionText').textContent = body;
    var singleTxt = document.getElementById('singleCaptionTextarea');
    if (singleTxt && !singleTxt.dataset.edited) singleTxt.value = body;
    document.getElementById('mockUtmUrl').textContent = 'لینک رهگیری پس از اتصال سرویس فعال می‌شود';
};
window.fetchSocialDraftFromServer = function () {
    var fd = new FormData();
    fd.append('ajax', '1');
    fd.append('course_title', document.getElementById('socCourseSelect').value);
    fd.append('persona', document.getElementById('socPersonaSelect').value);
    fetch(window.chamberApiUrl('marketing-intel'), { method: 'POST', body: fd, credentials: 'same-origin' })
        .then(function (r) { return r.json(); })
        .then(function (d) {
            if (d && d.ok && d.pack && d.pack[window.__activePreviewPlatform]) {
                var item = d.pack[window.__activePreviewPlatform];
                document.getElementById('mockCaptionText').textContent = item.body;
                document.getElementById('mockHashtagsText').textContent = item.hashtags;
                document.getElementById('singleCaptionTextarea').value = item.body;
            }
        }).catch(function () { window.refreshSocialLiveMockup(); });
};
document.addEventListener('DOMContentLoaded', window.refreshSocialLiveMockup);
</script>
