<div class="hero-banner">
    <div>
        <span class="badge badge-gold">قابلیت‌های سراسری — اسناد، فرم‌ساز پویا و امنیت</span>
        <h1>مخزن اسناد سازمانی، فرم‌ساز پویا و لاگ ممیزی امنیتی (Audit Trail)</h1>
        <p>آپلود و دانلود اسناد رسمی، رندر و ثبت پاسخ فرم‌های پویای JSON، کنترل دسترسی نقش‌ها (RBAC) و ردیابی کامل رخدادها.</p>
    </div>
</div>

<div class="grid grid-2">
    <!-- DOCUMENT VAULT -->
    <div class="card">
        <div class="card-header"><div class="card-title">📁 مخزن اسناد و بخشنامه‌های آموزشی</div></div>
        <form method="post" action="<?= e(url('workspace-tools')) ?>" enctype="multipart/form-data" style="margin-bottom:14px">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="upload_doc">
            <div class="form-grid">
                <input type="text" name="title" required placeholder="عنوان سند / بخشنامه">
                <select name="doc_category">
                    <option value="بخشنامه آموزشی">بخشنامه آموزشی</option>
                    <option value="قراردادها">قراردادها</option>
                    <option value="پژوهش">پژوهش</option>
                </select>
                <select name="access_scope">
                    <option value="staff">ویژه همکاران</option>
                    <option value="public">عمومی اعضا</option>
                </select>
            </div>
            <div class="form-group" style="margin-top:8px">
                <input type="file" name="doc_file">
            </div>
            <button type="submit" class="btn btn-primary btn-sm">بارگذاری در مخزن اسناد</button>
        </form>

        <?php foreach ($docs as $d): ?>
            <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-top:1px solid var(--border)">
                <div>
                    <strong><?= e($d['title']) ?></strong>
                    <div class="muted" style="font-size:11.5px"><?= e($d['doc_category']) ?> | سطح دسترسی: <?= e($d['access_scope']) ?></div>
                </div>
                <a class="btn btn-outline btn-sm" href="<?= e(url('workspace-tools', ['download_doc' => $d['id']])) ?>">📥 دانلود</a>
            </div>
        <?php endforeach; ?>
    </div>

    <!-- DYNAMIC FORM BUILDER + RENDERER -->
    <div class="card">
        <div class="card-header"><div class="card-title">🛠️ طراح گرافیکی فرم پویا + اجرای زنده</div></div>
        <form method="post" action="<?= e(url('workspace-tools')) ?>" style="margin-bottom:16px;padding-bottom:14px;border-bottom:1px solid var(--border)">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="create_dynamic_form">
            <div class="form-grid">
                <input type="text" name="title" value="فرم نیازسنجی دوره‌های حسابداری و امور مالی" required>
                <input type="text" name="module_link" value="competency" required placeholder="ماژول متصل">
            </div>
            <div class="form-grid" style="margin-top:8px">
                <input type="text" name="field1_label" value="نام سازمان و شناسه همکاری آموزشی" required>
                <input type="text" name="field2_label" value="ارزیابی کیفیت خدمات آموزشی" required>
                <input type="text" name="field3_label" value="پیشنهاد سرفصل‌های تخصصی" required>
            </div>
            <button type="submit" class="btn btn-gold btn-sm" style="margin-top:8px;width:100%">➕ ساخت و انتشار فوری فرم پویا</button>
        </form>

        <?php foreach ($forms as $fm): ?>
            <?php $fields = json_decode((string)$fm['fields_json'], true) ?: []; ?>
            <div style="margin-bottom:8px">
                <strong><?= e($fm['title']) ?></strong>
                <span class="badge badge-success">پاسخ‌های ثبت‌شده: <?= fa($fm['submissions_count']) ?></span>
            </div>
            <form method="post" action="<?= e(url('workspace-tools')) ?>">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="submit_dynamic_form">
                <input type="hidden" name="form_id" value="<?= (int)$fm['id'] ?>">
                <?php foreach ($fields as $fld): ?>
                    <div class="form-group">
                        <label><?= e($fld['label']) ?>:</label>
                        <?php if ($fld['type'] === 'select'): ?>
                            <select name="<?= e($fld['name']) ?>">
                                <?php foreach ($fld['options'] as $opt): ?>
                                    <option value="<?= e($opt) ?>"><?= e($opt) ?></option>
                                <?php endforeach; ?>
                            </select>
                        <?php elseif ($fld['type'] === 'textarea'): ?>
                            <textarea name="<?= e($fld['name']) ?>" rows="2"></textarea>
                        <?php else: ?>
                            <input type="text" name="<?= e($fld['name']) ?>" required>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
                <button type="submit" class="btn btn-primary btn-sm">ارسال فرم پویا</button>
            </form>
        <?php endforeach; ?>
    </div>
</div>

<!-- AUDIT TRAIL -->
<div class="card">
    <div class="card-header"><div class="card-title">🛡️ لاگ ممیزی امنیتی سامانه (Audit Log)</div></div>
    <div class="table-wrap">
        <table>
            <thead><tr><th>شناسه</th><th>ماژول</th><th>رویداد امنیتی</th><th>کاربر</th><th>نقش</th><th>IP</th></tr></thead>
            <tbody>
            <?php foreach ($auditLogs as $al): ?>
                <tr>
                    <td>#<?= fa($al['id']) ?></td>
                    <td><span class="badge badge-purple"><?= e($al['module']) ?></span></td>
                    <td><code><?= e($al['action']) ?></code></td>
                    <td><?= e($al['full_name'] ?? 'مهمان') ?></td>
                    <td><?= e($al['user_role']) ?></td>
                    <td dir="ltr" style="text-align:right"><?= e($al['ip_address']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
