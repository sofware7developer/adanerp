<?php
use App\Core\Auth;

$lmsHud = \App\Services\LearnerBehaviorGamificationService::getUserHudSnapshot(
    (int)(Auth::id() ?? 1),
    (string)(Auth::user()['full_name'] ?? 'فراگیر')
);
$firstQuiz = $interactiveQuizzes[0] ?? [
    'appear_at_sec'  => 145,
    'question_text'  => 'در قرارداد صادراتی تحویل روی عرشه کشتی (FOB)، مسئولیت بیمه دریایی اصلی با کدام طرف است؟',
    'opt_a'          => 'فروشنده (صادرکننده)',
    'opt_b'          => 'خریدار خارجی از لحظه عبور کالا از لبه کشتی',
    'opt_c'          => 'شرکت حمل فورواردر',
    'opt_d'          => 'بانک گشایش‌کننده اعتبار',
    'correct_opt'    => 'B',
    'ai_explanation' => 'در قاعده FOB اینکوترمز ۲۰۲۰ ریسک با بارگیری روی عرشه کشتی در بندر مبدأ به خریدار منتقل می‌شود.',
    'xp_reward'      => 35,
];
$quizOpts = [
    $firstQuiz['opt_a'] ?? 'گزینه اول',
    $firstQuiz['opt_b'] ?? 'گزینه دوم',
    $firstQuiz['opt_c'] ?? 'گزینه سوم',
    $firstQuiz['opt_d'] ?? 'گزینه چهارم',
];
$correctIdx = ['A' => 0, 'B' => 1, 'C' => 2, 'D' => 3][strtoupper((string)($firstQuiz['correct_opt'] ?? 'B'))] ?? 1;
$quizExpText = (string)($firstQuiz['ai_explanation'] ?? $firstQuiz['explanation'] ?? '');
?>
<div class="hero-banner">
    <div>
        <span class="badge badge-gold">استودیوی هوشمند یادگیری تعاملی • LMS نسل جدید</span>
        <h1>کلاس درس سینمایی هوشمند، آزمونک درون‌ویدئویی، همیار AI درس و تصحیح خودکار تکالیف</h1>
        <p>پیشرفت دوره: <strong><?= fa($progressPct) ?>٪</strong> | مطالعه ثبت‌شده: <strong><?= fa($totalMinutes) ?> دقیقه</strong> | واترمارک پویا: <code><?= e((Auth::user()['full_name'] ?? 'کاربر') . ' • ' . (Auth::user()['national_code'] ?? '0012345678')) ?></code></p>
    </div>
    <form method="get" action="<?= e(url('lms')) ?>" style="min-width:270px">
        <select name="course_id" onchange="this.form.submit()" style="background:#fff;color:#0f172a;font-weight:700">
            <?php foreach (($allCourses ?? []) as $crs): ?>
                <option value="<?= (int)$crs['id'] ?>" <?= ($activeCourseId ?? 1) === (int)$crs['id'] ? 'selected' : '' ?>>
                    📚 [<?= e($crs['code']) ?>] <?= e($crs['title']) ?>
                </option>
            <?php endforeach; ?>
        </select>
    </form>
</div>

<!-- GAMIFICATION & ADAPTIVE MASTERY HUD -->
<div class="card" style="margin-bottom:16px;display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;border:1.5px solid rgba(201,146,39,0.42)">
    <div>
        <span class="badge badge-gold">🔥 زنجیره مطالعه: <?= fa($lmsHud['streak_days']) ?> روز متوالی</span>
        <strong style="margin-right:8px">سطح <?= fa($lmsHud['level_num']) ?> (<?= e($lmsHud['rank_title']) ?>) — <?= fa(number_format($lmsHud['xp_points'])) ?> XP | 🪙 <?= fa(number_format($lmsHud['chamber_coins'])) ?> سکه مهارت</strong>
        <div class="muted" style="font-size:11.5px;margin-top:4px">
            تله‌متری xAPI فعال است: پاسخ به آزمونک درون‌ویدئویی، مرور فلش‌کارت هوشمند و تکمیل دروس، به صورت خودکار XP به پرونده مهارتی اضافه می‌کند.
        </div>
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
        <?php if (Auth::hasRole(['super_admin', 'training_expert', 'instructor'])): ?>
            <button type="button" class="btn btn-outline btn-sm" onclick="document.getElementById('aiLessonStudioBox').scrollIntoView({behavior:'smooth'})">🪄 استودیوی تولید محتوای استاد با AI</button>
        <?php endif; ?>
        <button type="button" class="btn btn-primary btn-sm" onclick="window.chamberRecordMicroXp('lms', 'تمرکز عمیق در کلاس هوشمند LMS', 45)">+۴۵ XP ثبت مطالعه</button>
    </div>
</div>

<!-- MAIN LMS WORKSPACE -->
<div class="grid grid-sidebar" id="lmsCinemaGrid" style="align-items:start">
    <!-- SIDEBAR: CHAPTERS & SEQUENTIAL LESSONS -->
    <div class="card">
        <div class="card-header">
            <div class="card-title">📖 سرفصل‌ها و قفل مرحله‌ای دروس</div>
            <span class="badge badge-success"><?= fa($progressPct) ?>٪ تکمیل</span>
        </div>
        <div class="progress-track" style="height:8px;margin-bottom:14px">
            <div class="progress-fill" style="width:<?= (int)$progressPct ?>%"></div>
        </div>

        <?php foreach ($chapters as $ch): ?>
            <div style="margin-bottom:12px">
                <div style="font-weight:800;font-size:12.5px;color:var(--primary);margin-bottom:6px">
                    فصل <?= fa($ch['sort_order']) ?>: <?= e($ch['title']) ?>
                </div>
                <div style="display:flex;flex-direction:column;gap:5px">
                    <?php foreach ($ch['lessons'] as $ls): ?>
                        <?php
                        $isDone = !empty($completedMap[(int)$ls['id']]);
                        $isActive = $activeLesson && (int)$activeLesson['id'] === (int)$ls['id'];
                        $isLocked = !empty($ls['is_locked']);
                        ?>
                        <?php if ($isLocked): ?>
                            <div style="padding:8px 10px;border-radius:10px;background:var(--surface-2);opacity:0.6;font-size:12px;display:flex;justify-content:space-between">
                                <span>🔒 <?= e($ls['title']) ?></span>
                                <span class="muted"><?= fa($ls['estimated_minutes'] ?? 30) ?> دقیقه</span>
                            </div>
                        <?php else: ?>
                            <a href="<?= e(url('lms', ['course_id' => $activeCourseId, 'lesson' => (int)$ls['id']])) ?>"
                               style="padding:8px 10px;border-radius:10px;text-decoration:none;color:var(--text);font-size:12.2px;font-weight:<?= $isActive ? '800' : '600' ?>;background:<?= $isActive ? 'var(--primary-soft)' : 'var(--surface-2)' ?>;border:1px solid <?= $isActive ? 'var(--primary)' : 'var(--border)' ?>;display:flex;justify-content:space-between;align-items:center">
                                <span><?= $isDone ? '✅' : '▶️' ?> <?= e($ls['title']) ?></span>
                                <span class="muted" style="font-size:11px"><?= fa($ls['estimated_minutes'] ?? 30) ?>د</span>
                            </a>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <!-- CENTER STAGE: SMART INTERACTIVE CINEMA PLAYER + AI CO-TUTOR + FLASHCARDS -->
    <div style="display:flex;flex-direction:column;gap:16px">
        <?php if ($activeLesson): ?>
            <div class="card">
                <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:12px">
                    <div>
                        <span class="badge badge-info">نوع محتوا: <?= e($activeLesson['content_type']) ?></span>
                        <h2 style="font-size:17px;margin-top:4px"><?= e($activeLesson['title']) ?></h2>
                    </div>
                    <div style="display:flex;gap:6px;flex-wrap:wrap">
                        <button type="button" class="btn btn-gold btn-sm" onclick="document.getElementById('inVideoQuizModal').style.display='flex'">⚡ نمایش آزمونک درون‌ویدئویی (+<?= fa($firstQuiz['xp_reward']) ?> XP)</button>
                        <button type="button" class="btn btn-outline btn-sm" onclick="window.toggleLmsTheater()">🖥 حالت سینمایی عریض</button>
                    </div>
                </div>

                <!-- INTERACTIVE CINEMA SCREEN WITH LIVE POP-UP QUIZ OVERLAY -->
                <div style="position:relative;border-radius:16px;overflow:hidden;background:linear-gradient(135deg,#091526,#0f2942,#134e4a);color:#fff;min-height:290px;padding:24px;display:flex;flex-direction:column;justify-content:space-between;border:1px solid rgba(255,255,255,0.14)">
                    <div style="display:flex;justify-content:space-between;align-items:center;font-size:11.5px;opacity:0.8">
                        <span>🛡 واترمارک امنیتی: <?= e(Auth::user()['full_name'] ?? 'فراگیر آدان') ?></span>
                        <span id="lmsSpeedBadge" style="padding:3px 9px;border-radius:999px;background:rgba(255,255,255,0.14)">سرعت پخش: ۱.۰x • کیفیت Full HD</span>
                    </div>

                    <div style="text-align:center;margin:20px auto;max-width:640px">
                        <button type="button" id="lmsPlayBtn" onclick="window.toggleSmartVideoPlay()"
                                style="width:68px;height:68px;border-radius:50%;border:2px solid rgba(255,255,255,0.5);background:rgba(16,185,129,0.28);color:#fff;font-size:24px;cursor:pointer;margin-bottom:12px">
                            ▶
                        </button>
                        <div style="font-size:15px;font-weight:800;margin-bottom:6px"><?= e($activeLesson['title']) ?></div>
                        <p style="font-size:12.5px;opacity:0.85;line-height:1.7">
                            <?= e(mb_substr(strip_tags((string)($activeLesson['body_html'] ?? '')), 0, 190)) ?>...
                        </p>
                    </div>

                    <!-- TIMELINE + CHAPTER MARKERS + CONTROLS -->
                    <div>
                        <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:8px;font-size:11px">
                            <span style="cursor:pointer;padding:2px 8px;border-radius:6px;background:rgba(255,255,255,0.14)" onclick="window.seekSmartVideo(15)">📍 ۰۰:۱۵ مفاهیم پایه</span>
                            <span style="cursor:pointer;padding:2px 8px;border-radius:6px;background:rgba(245,158,11,0.35);border:1px solid #fbbf24" onclick="document.getElementById('inVideoQuizModal').style.display='flex'">⚡ ۰۲:۲۵ ایستگاه آزمونک تعاملی</span>
                            <span style="cursor:pointer;padding:2px 8px;border-radius:6px;background:rgba(255,255,255,0.14)" onclick="window.seekSmartVideo(320)">📍 ۰۵:۲۰ مطالعه موردی گمرک</span>
                        </div>
                        <input type="range" id="lmsTimelineRange" min="0" max="600" value="95" style="width:100%" oninput="window.seekSmartVideo(this.value)">
                        <div style="display:flex;justify-content:space-between;align-items:center;margin-top:6px;font-size:12px">
                            <span id="lmsTimeReadout">۰۱:۳۵ / ۱۰:۰۰</span>
                            <div style="display:flex;gap:6px">
                                <button type="button" class="btn btn-outline btn-sm" style="color:#fff;border-color:rgba(255,255,255,0.3);padding:2px 8px" onclick="window.setLmsSpeed('1.0x')">۱x</button>
                                <button type="button" class="btn btn-outline btn-sm" style="color:#fff;border-color:rgba(255,255,255,0.3);padding:2px 8px" onclick="window.setLmsSpeed('1.5x')">۱.۵x</button>
                                <button type="button" class="btn btn-outline btn-sm" style="color:#fff;border-color:rgba(255,255,255,0.3);padding:2px 8px" onclick="window.setLmsSpeed('2.0x')">۲x</button>
                            </div>
                        </div>
                    </div>

                    <!-- IN-VIDEO INTERACTIVE POP-UP QUIZ OVERLAY -->
                    <div id="inVideoQuizModal" style="display:none;position:absolute;inset:0;background:rgba(9,21,38,0.94);padding:22px;flex-direction:column;justify-content:center;align-items:center;z-index:10">
                        <div style="max-width:560px;width:100%;background:var(--surface);color:var(--text);padding:20px;border-radius:16px;border:2px solid var(--gold)">
                            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
                                <span class="badge badge-gold">⚡ آزمونک هوشمند درون‌ویدئویی (+<?= fa($firstQuiz['xp_reward']) ?> XP)</span>
                                <button type="button" class="btn btn-outline btn-sm" onclick="document.getElementById('inVideoQuizModal').style.display='none'">ادامه ویدئو ✕</button>
                            </div>
                            <strong style="font-size:14px;display:block;margin-bottom:12px;line-height:1.7"><?= e($firstQuiz['question_text']) ?></strong>
                            <div style="display:flex;flex-direction:column;gap:7px">
                                <?php foreach ($quizOpts as $optIdx => $optText): ?>
                                    <button type="button" class="btn btn-outline" style="justify-content:flex-start;text-align:right"
                                            onclick="window.checkInVideoQuizAnswer(<?= (int)$optIdx ?>, <?= (int)$correctIdx ?>, <?= (int)$firstQuiz['xp_reward'] ?>)">
                                        <?= fa($optIdx + 1) ?>) <?= e($optText) ?>
                                    </button>
                                <?php endforeach; ?>
                            </div>
                            <div id="inVideoQuizFeedback" style="display:none;margin-top:10px;padding:10px;border-radius:10px;font-size:12.5px;background:var(--primary-soft)">
                                <?= e($quizExpText) ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- TRANSCRIPT SEARCH + LESSON COMPLETION FORM -->
                <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin-top:14px;padding:12px;background:var(--surface-2);border-radius:12px">
                    <div style="flex:1;min-width:240px;font-size:13px;line-height:1.8">
                        <strong>📄 متن کامل و قابل جست‌وجوی درس:</strong><br>
                        <?= e(strip_tags((string)($activeLesson['body_html'] ?? ''))) ?>
                    </div>
                    <form method="post" action="<?= e(url('lms', ['course_id' => $activeCourseId, 'lesson' => (int)$activeLesson['id']])) ?>">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="complete_lesson">
                        <input type="hidden" name="lesson_id" value="<?= (int)$activeLesson['id'] ?>">
                        <input type="hidden" name="spent_minutes" value="<?= max(15, (int)($activeLesson['estimated_minutes'] ?? 25)) ?>">
                        <button type="submit" class="btn btn-primary">✅ ثبت تکمیل درس و بازگشایی درس بعدی</button>
                    </form>
                </div>
            </div>
        <?php endif; ?>

        <!-- AI FLASHCARDS + TIMESTAMPED NOTES -->
        <div class="grid grid-2" style="gap:16px">
            <div class="card">
                <div class="card-header"><div class="card-title">🧠 فلش‌کارت‌های مرور هوشمند با الگوریتم تکرار فاصله‌دار (کلیک جهت برگرداندن)</div></div>
                <div style="display:flex;flex-direction:column;gap:10px">
                    <?php foreach ($studyCards as $sc): ?>
                        <div onclick="var ans=this.querySelector('.fc-back');ans.style.display=(ans.style.display==='none'?'block':'none')"
                             style="padding:12px;border-radius:12px;background:var(--surface-2);border:1px solid var(--border);cursor:pointer">
                            <div style="display:flex;justify-content:space-between;font-size:11px;margin-bottom:4px">
                                <span class="badge badge-info">پرسش کلیدی</span>
                                <span class="muted"><?= e($sc['mastery_tag'] ?? 'تسلط کاربردی') ?> • کلیک برای پاسخ</span>
                            </div>
                            <strong style="font-size:13px;line-height:1.6"><?= e($sc['title'] ?? '') ?></strong>
                            <div class="fc-back" style="display:none;margin-top:8px;padding-top:8px;border-top:1px dashed var(--border);color:var(--primary);font-size:12.5px;font-weight:600">
                                💡 پاسخ دقیق: <?= e($sc['content_body'] ?? '') ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="card">
                <div class="card-header"><div class="card-title">📝 دفترچه یادداشت ثانیه‌ای روی ویدئو (Timestamp Notes)</div></div>
                <?php if ($activeLesson): ?>
                    <form method="post" action="<?= e(url('lms', ['course_id' => $activeCourseId, 'lesson' => (int)$activeLesson['id']])) ?>" style="margin-bottom:12px">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="save_note">
                        <input type="hidden" name="lesson_id" value="<?= (int)$activeLesson['id'] ?>">
                        <input type="hidden" name="video_second" id="noteVideoSecondInput" value="95">
                        <div style="display:flex;gap:6px">
                            <input type="text" name="note_text" required placeholder="نکته کلیدی این ثانیه از ویدئو را بنویسید...">
                            <button type="submit" class="btn btn-primary btn-sm">ثبت در ثانیه جاری</button>
                        </div>
                    </form>
                <?php endif; ?>
                <?php foreach ($myNotes as $n): ?>
                    <div style="padding:8px 10px;border-radius:9px;background:var(--surface-2);margin-bottom:6px;font-size:12px">
                        <span class="badge badge-gold">⏱ <?= e($n['video_timestamp'] ?? '01:35') ?></span>
                        <span style="margin-right:6px"><?= e($n['note_body'] ?? '') ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <?php if (Auth::hasRole(['super_admin', 'training_expert', 'instructor'])): ?>
        <!-- INSTRUCTOR AI CONTENT GENERATOR STUDIO -->
        <div class="card" id="aiLessonStudioBox" style="border:1.5px solid color-mix(in srgb,var(--primary) 30%,var(--border))">
            <div class="card-header">
                <div class="card-title">🪄 استودیوی تولید خودکار درس تعاملی، آزمونک درون‌ویدئویی و فلش‌کارت با AI (ویژه اساتید و کارشناسان آموزش)</div>
            </div>
            <form method="post" action="<?= e(url('lms', ['course_id' => $activeCourseId])) ?>" style="display:flex;gap:10px;flex-wrap:wrap;align-items:center">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="ai_generate_lesson_pack">
                <input type="hidden" name="course_id" value="<?= (int)$activeCourseId ?>">
                <input type="text" name="lesson_topic" style="flex:1;min-width:260px"
                       value="مدیریت ریسک ارزی، تضامین بانکی و اعتبار اسنادی دیداری در صادرات"
                       placeholder="موضوع درس جدید را بنویسید تا AI درس + اسکریپت + آزمونک + فلش‌کارت بسازد...">
                <button type="submit" class="btn btn-primary">✨ تولید خودکار بسته کامل درس در LMS</button>
            </form>
        </div>
        <?php endif; ?>

        <!-- AI 4-AXIS RUBRIC ASSIGNMENT AUTO-GRADER + SCORM 1.2 LAB -->
        <div class="grid grid-2" style="gap:16px">
            <div class="card">
                <div class="card-header"><div class="card-title">🤖 تصحیح هوشمند تکالیف تشریحی با روبریک ۴ محوره AI</div></div>
                <div style="padding:10px;border-radius:10px;background:var(--surface-2);margin-bottom:10px">
                    <strong style="font-size:13px">ارسال پروژه عملیاتی و مطالعه موردی دوره</strong>
                    <form method="post" action="<?= e(url('lms', ['course_id' => $activeCourseId])) ?>" enctype="multipart/form-data" style="margin-top:8px;display:flex;flex-direction:column;gap:6px">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="submit_assignment">
                        <input type="text" name="assignment_title" value="پروژه تدوین قرارداد صادراتی بدون ریسک">
                        <textarea name="submission_text" rows="2" placeholder="پاسخ تحلیلی و پرونده عملیاتی خود را ثبت نمایید..."></textarea>
                        <button type="submit" class="btn btn-outline btn-sm">📤 ارسال تکلیف جهت ارزیابی</button>
                    </form>
                </div>

                <?php foreach ($submissions as $sub): ?>
                    <div style="padding:10px;border-radius:10px;border:1px solid var(--border);margin-top:8px;font-size:12px">
                        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
                            <strong>👤 <?= e($sub['full_name']) ?> — <?= e($sub['title']) ?></strong>
                            <span class="badge badge-success">نمره: <?= $sub['grade'] !== null ? fa($sub['grade']) : 'در انتظار' ?></span>
                        </div>
                        <?php if (!empty($sub['feedback'])): ?>
                            <div class="muted" style="margin-bottom:6px"><?= e($sub['feedback']) ?></div>
                        <?php endif; ?>
                        <?php if (Auth::hasRole(['super_admin', 'training_expert', 'instructor'])): ?>
                            <form method="post" action="<?= e(url('lms', ['course_id' => $activeCourseId])) ?>">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="ai_auto_grade_submission">
                                <input type="hidden" name="submission_id" value="<?= (int)$sub['id'] ?>">
                                <button type="submit" class="btn btn-gold btn-sm">🤖 تصحیح و نمره‌دهی خودکار با روبریک AI</button>
                            </form>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="card">
                <div class="card-header"><div class="card-title">📦 آزمایشگاه استاندارد SCORM 1.2 و بسته‌های تعاملی</div></div>
                <div class="alert alert-warning" style="margin-bottom:10px;font-size:12px">
                    <div>تجزیه خودکار مانیفست <code>imsmanifest.xml</code> و کنترل امنیتی فایل فشرده <code>.zip</code> فعال است؛ Runtime پایه <code>window.API</code> نیز در مرورگر بارگذاری شده است.</div>
                </div>
                <?php if (Auth::hasRole(['super_admin', 'training_expert', 'instructor'])): ?>
                    <form method="post" action="<?= e(url('lms', ['course_id' => $activeCourseId])) ?>" enctype="multipart/form-data" style="display:flex;flex-direction:column;gap:8px;margin-bottom:12px">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="upload_scorm">
                        <input type="hidden" name="course_id" value="<?= (int)$activeCourseId ?>">
                        <input type="text" name="title" placeholder="عنوان بسته استاندارد SCORM 1.2" required>
                        <input type="file" name="scorm_zip" accept=".zip" required>
                        <button type="submit" class="btn btn-primary btn-sm">بارگذاری و کالبدشکافی مانیفست SCORM</button>
                    </form>
                <?php endif; ?>
                <?php foreach (($scormTracks ?? []) as $sp): ?>
                    <div style="padding:8px 10px;border-radius:9px;background:var(--surface-2);font-size:12px;margin-bottom:6px">
                        📦 <strong><?= e($sp['sco_identifier']) ?></strong> — نمره CMI: <code><?= fa($sp['score_raw']) ?></code> (<?= e($sp['lesson_status']) ?>)
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

<script>
window.__lmsPlaying = false;
window.__lmsTimer = null;
window.API = {
    LMSInitialize: function(){ return 'true'; },
    LMSGetValue: function(){ return ''; },
    LMSSetValue: function(){ return 'true'; },
    LMSCommit: function(){ return 'true'; },
    LMSFinish: function(){ return 'true'; }
};
window.toggleSmartVideoPlay = function () {
    window.__lmsPlaying = !window.__lmsPlaying;
    var btn = document.getElementById('lmsPlayBtn');
    if (btn) btn.textContent = window.__lmsPlaying ? '⏸' : '▶';
    if (window.__lmsPlaying) {
        window.__lmsTimer = setInterval(function () {
            var rng = document.getElementById('lmsTimelineRange');
            if (!rng) return;
            var v = Math.min(600, parseInt(rng.value, 10) + 1);
            rng.value = v;
            window.seekSmartVideo(v);
            if (v === 145) {
                window.__lmsPlaying = false;
                if (btn) btn.textContent = '▶';
                clearInterval(window.__lmsTimer);
                document.getElementById('inVideoQuizModal').style.display = 'flex';
            }
        }, 1000);
    } else if (window.__lmsTimer) {
        clearInterval(window.__lmsTimer);
    }
};
window.seekSmartVideo = function (sec) {
    var s = parseInt(sec, 10) || 0;
    var mm = String(Math.floor(s / 60)).padStart(2, '0');
    var ss = String(s % 60).padStart(2, '0');
    var lbl = document.getElementById('lmsTimeReadout');
    if (lbl) lbl.textContent = mm + ':' + ss + ' / 10:00';
    var inp = document.getElementById('noteVideoSecondInput');
    if (inp) inp.value = String(s);
};
window.setLmsSpeed = function (sp) {
    var b = document.getElementById('lmsSpeedBadge');
    if (b) b.textContent = 'سرعت پخش: ' + sp + ' • کیفیت Full HD';
};
window.toggleLmsTheater = function () {
    var g = document.getElementById('lmsCinemaGrid');
    if (!g) return;
    g.style.gridTemplateColumns = (g.style.gridTemplateColumns === '1fr') ? '' : '1fr';
};
window.checkInVideoQuizAnswer = function (picked, correct, xp) {
    var fb = document.getElementById('inVideoQuizFeedback');
    if (fb) {
        fb.style.display = 'block';
        fb.innerHTML = (picked === correct ? '✅ <strong>آفرین! پاسخ کاملاً صحیح است.</strong> ' : '💡 <strong>نکته آموزشی کلیدی:</strong> ') + fb.textContent;
    }
    if (picked === correct && window.chamberRecordMicroXp) {
        window.chamberRecordMicroXp('lms', 'پاسخ صحیح به آزمونک تعاملی درون‌ویدئویی', xp || 35);
    }
};
</script>
