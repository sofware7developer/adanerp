<?php
use App\Core\Auth;
use App\Core\Jalali;

$isTmsAdmin = Auth::hasRole(['super_admin', 'training_expert']);

$isLearnerTms = Auth::role() === 'learner';
$canMarketing = Auth::hasRole(['super_admin', 'crm_manager', 'training_expert']);
$totalSeats = array_sum(array_map(static fn($r) => max(1, (int)$r['capacity']), $runs));
$filledSeats = array_sum(array_map(static fn($r) => (int)$r['actual_enrolled_count'], $runs));
$fillRatePct = $totalSeats > 0 ? min(100, (int)round(($filledSeats / $totalSeats) * 100)) : 74;
$avgTuition = count($allCoursesUnfiltered) > 0
    ? (int)round(array_sum(array_column($allCoursesUnfiltered, 'tuition_rial')) / count($allCoursesUnfiltered))
    : 48000000;
?>
<div class="hero-banner">
    <div>
        <span class="badge badge-gold"><?= $isTmsAdmin ? 'مدیریت دوره‌های آموزشگاه آدان' : 'دوره‌ها، تقویم آموزشی و ثبت‌نام' ?></span>
        <h1><?= $isTmsAdmin ? 'مدیریت دوره‌های حسابداری، ثبت‌نام و برنامه کلاس‌ها' : 'دوره‌های حسابداری و ثبت‌نام آموزشگاه آدان' ?></h1>
        <p><?= $isTmsAdmin ? 'تعریف دوره‌های حسابداری، مالیات، حقوق و دستمزد و نرم‌افزار مالی؛ مدیریت کلاس، شهریه، ظرفیت و فهرست انتظار.' : 'دوره‌های کاربردی حسابداری، تقویم کلاس‌ها، اطلاعات شهریه و ثبت‌نام آنلاین را ببینید.' ?></p>
    </div>
    <div class="hero-actions" style="display:flex;gap:8px;flex-wrap:wrap">
        <a class="btn btn-outline" style="background:rgba(255,255,255,0.14);color:#fff;border-color:rgba(255,255,255,0.28)" href="<?= e(url('class-card-print?run_id=1')) ?>" target="_blank">🪪 کارت ورود به کلاس (QR)</a>
        <?php if ($canMarketing): ?>
            <a class="btn btn-outline" style="background:rgba(255,255,255,0.14);color:#fff;border-color:rgba(255,255,255,0.28)" href="<?= e(url('marketing-intel')) ?>">📣 کمپین شبکه اجتماعی دوره</a>
        <?php endif; ?>
        <?php if ($isTmsAdmin): ?>
            <button type="button" class="btn btn-gold" onclick="document.getElementById('newCourseModal').classList.add('open')">➕ تعریف دوره جدید</button>
            <button type="button" class="btn btn-primary" onclick="document.getElementById('newRunModal').classList.add('open')">📅 تعریف اجرای کلاس</button>
        <?php endif; ?>
    </div>
</div>

<?php if ($isTmsAdmin): ?>
<!-- ==================== AI FULL-STACK COURSE ARCHITECT BAR ==================== -->
<div class="card" style="margin-bottom:18px;background:linear-gradient(135deg,color-mix(in srgb,var(--primary) 8%,var(--surface)),var(--surface));border:1.5px solid color-mix(in srgb,var(--primary) 30%,var(--border))">
    <form method="post" action="<?= e(url('tms')) ?>" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="ai_build_full_course">
        <div style="flex:1;min-width:260px">
            <div style="font-size:12.5px;font-weight:800;margin-bottom:5px;color:var(--primary)">
                🚀 کارخانه ۱-کلیکی ساخت خودکار دوره با هوش مصنوعی (تولید هم‌زمان دوره در TMS + کلاس + ۴ جلسه تقویم + ۴ درس و کوییز در LMS):
            </div>
            <input type="text" id="tmsAiPromptInp" name="ai_course_prompt"
                   value="دوره جامع حسابداری مقدماتی و ثبت اسناد مالی با تمرین عملی"
                   placeholder="عنوان یا ایده دوره را بنویسید یا با صدای فارسی بگویید...">
        </div>
        <div style="display:flex;gap:8px;align-items:center;padding-top:18px">
            <button type="button" class="btn btn-outline btn-sm" onclick="if(window.toggleLiveSpeechRecognition)window.toggleLiveSpeechRecognition('tmsAiPromptInp')">🎙️ فرمان صوتی</button>
            <button type="submit" class="btn btn-primary">✨ ساخت خودکار دوره کامل + دروس LMS</button>
        </div>
    </form>
</div>
<?php endif; ?>

<?php if (Auth::hasRole(['super_admin'])): ?>
<div class="card" style="margin-bottom:18px">
    <div class="card-header"><div class="card-title">تنظیم دسترسی API ثبت‌نام</div></div>
    <p class="muted">این API تا زمان تعریف توکن غیرفعال است. توکن حداقل ۳۲ نویسه‌ای را نگه دارید و در درخواست‌ها فقط با سربرگ <code>X-API-Token</code> بفرستید.</p>
    <form method="post" action="<?= e(url('tms')) ?>" style="display:flex;gap:8px;flex-wrap:wrap">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="save_enrollment_api_token">
        <input type="password" name="api_token" minlength="32" maxlength="200" autocomplete="new-password" required placeholder="توکن محرمانه حداقل ۳۲ نویسه">
        <button type="submit" class="btn btn-primary">ذخیره / تعویض توکن</button>
    </form>
    <form method="post" action="<?= e(url('tms')) ?>" style="margin-top:8px">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="disable_enrollment_api">
        <button type="submit" class="btn btn-outline">غیرفعال‌کردن API</button>
    </form>
</div>
<?php endif; ?>

<!-- ==================== 4 LIVE TMS EXECUTIVE KPI CARDS ==================== -->
<div class="grid grid-4" style="margin-bottom:18px">
    <div class="stat-card">
        <div>
            <div class="stat-label">کل دوره‌های کاتالوگ آموزشی</div>
            <div class="stat-value"><?= fa(count($allCoursesUnfiltered)) ?> دوره</div>
            <div class="stat-meta">در <?= fa(count($categories)) ?> گروه آموزشی آدان</div>
        </div>
        <div class="stat-icon icon-teal">📚</div>
    </div>
    <div class="stat-card">
        <div>
            <div class="stat-label">نرخ تکمیل صندلی کلاس‌های فعال</div>
            <div class="stat-value"><?= fa($fillRatePct) ?>٪</div>
            <div class="stat-meta"><?= fa($filledSeats) ?> ثبت‌نام از <?= fa($totalSeats) ?> ظرفیت کل</div>
        </div>
        <div class="stat-icon icon-gold">🎯</div>
    </div>
    <div class="stat-card">
        <div>
            <div class="stat-label">میانگین شهریه مصوب هر دوره</div>
            <div class="stat-value"><?= fa(number_format($avgTuition)) ?> <small style="font-size:12px">ریال</small></div>
            <div class="stat-meta">قابل تنظیم برای هر دوره و گروه دانشجویی</div>
        </div>
        <div class="stat-icon icon-purple">💎</div>
    </div>
    <div class="stat-card">
        <div>
            <div class="stat-label">دیپلم‌ها و مسیرهای یادگیری جامع</div>
            <div class="stat-value"><?= fa(count($learningPaths)) ?> مسیر</div>
            <div class="stat-meta">بسته‌های چنددوره‌ای مهارت‌محور</div>
        </div>
        <div class="stat-icon icon-blue">🧭</div>
    </div>
</div>

<div data-tab-group>
    <div class="tabs" style="flex-wrap:wrap">
        <button type="button" class="tab-btn active" data-tab="tab-catalog">📚 ویترین دوره‌ها<?= $isTmsAdmin ? ' و کانبان تصویب' : '' ?> (<?= fa(count($courses)) ?>)</button>
        <?php if (!$isLearnerTms): ?>
            <button type="button" class="tab-btn" data-tab="tab-paths">🧭 معماری مسیر یادگیری و دیپلم‌ها</button>
        <?php endif; ?>
        <?php if ($isTmsAdmin || Auth::hasRole(['finance_manager'])): ?>
            <button type="button" class="tab-btn" data-tab="tab-pricing">💎 قیمت‌گذاری پویا و نقطه سربه‌سر</button>
        <?php endif; ?>
        <button type="button" class="tab-btn" data-tab="tab-calendar">📅 تقویم شمسی جلسات</button>
        <?php if (!$isLearnerTms): ?>
            <button type="button" class="tab-btn" data-tab="tab-runs">🏫 مدیریت دوره‌های اجراشده (<?= fa(count($runs)) ?>)</button>
        <?php endif; ?>
        <button type="button" class="tab-btn" data-tab="tab-enroll">📝 ثبت‌نام در دوره و پرونده ثبت‌نام من</button>
    </div>

    <!-- ==================== TAB 1: MULTI-VIEW CATALOG + DRAG & DROP KANBAN ==================== -->
    <div class="tab-panel active" id="tab-catalog">
        <div class="card">
            <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:14px">
                <form method="get" action="<?= e(url('tms')) ?>" style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;flex:1">
                    <input type="text" name="q" value="<?= e($q) ?>" style="max-width:240px" placeholder="🔍 جست‌وجوی عنوان یا کد دوره...">
                    <select name="cat" style="width:auto">
                        <option value="0">همه دپارتمان‌ها</option>
                        <?php foreach ($categories as $cat): ?>
                            <option value="<?= (int)$cat['id'] ?>" <?= $catFilter === (int)$cat['id'] ? 'selected' : '' ?>><?= e($cat['title']) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <select name="st" style="width:auto">
                        <option value="">همه وضعیت‌ها</option>
                        <option value="published" <?= $statusFilter === 'published' ? 'selected' : '' ?>>منتشرشده (در حال ثبت‌نام)</option>
                        <option value="approved" <?= $statusFilter === 'approved' ? 'selected' : '' ?>>مصوب کمیته علمی</option>
                        <option value="under_review" <?= $statusFilter === 'under_review' ? 'selected' : '' ?>>در انتظار داوری</option>
                    </select>
                    <button type="submit" class="btn btn-primary btn-sm">فیلتر</button>
                    <a href="<?= e(url('tms')) ?>" class="btn btn-outline btn-sm">پاک‌سازی</a>
                </form>

                <div style="display:flex;gap:6px">
                    <button type="button" class="btn btn-primary btn-sm" id="btnViewCards" onclick="window.switchTmsView('cards')">🗂 نمای کارتی</button>
                    <?php if ($isTmsAdmin): ?>
                        <button type="button" class="btn btn-outline btn-sm" id="btnViewKanban" onclick="window.switchTmsView('kanban')">📋 کانبان Drag &amp; Drop</button>
                    <?php endif; ?>
                    <button type="button" class="btn btn-outline btn-sm" id="btnViewTable" onclick="window.switchTmsView('table')">📊 نمای جدولی</button>
                </div>
            </div>

            <!-- VIEW A: MODERN SHOWCASE CARDS -->
            <div id="tmsCardsView" class="grid grid-3" style="gap:16px">
                <?php foreach ($courses as $c): ?>
                    <?php
                    $netMemberFee = (int)round((int)$c['tuition_rial'] * (1 - ((int)$c['member_discount_pct'] / 100)));
                    ?>
                    <div style="background:var(--surface-2);border:1px solid var(--border);border-radius:16px;padding:16px;display:flex;flex-direction:column;justify-content:space-between;gap:12px">
                        <div>
                            <div style="display:flex;justify-content:space-between;align-items:center;gap:6px;margin-bottom:8px">
                                <span class="badge badge-info"><?= e($c['code']) ?></span>
                                <span class="badge <?= $c['workflow_status'] === 'published' ? 'badge-success' : 'badge-gold' ?>">
                                    <?= e($c['workflow_status']) ?>
                                </span>
                            </div>
                            <h3 style="font-size:14.5px;line-height:1.6;margin-bottom:6px"><?= e($c['title']) ?></h3>
                            <div class="muted" style="font-size:12px">
                                🏛 <?= e($c['category_title'] ?? 'آموزش تخصصی') ?> • ⏱ <?= fa($c['duration_hours']) ?> ساعت • 🎯 <?= e($c['delivery_mode']) ?>
                            </div>
                        </div>

                        <div style="background:var(--surface);padding:10px 12px;border-radius:12px;border:1px solid var(--border)">
                            <div style="display:flex;justify-content:space-between;font-size:12px">
                                <span class="muted">شهریه آزاد:</span>
                                <strong><?= fa(number_format((int)$c['tuition_rial'])) ?> ریال</strong>
                            </div>
                            <div style="display:flex;justify-content:space-between;font-size:12px;margin-top:4px;color:var(--primary)">
                                <span>تخفیف این دوره (<?= fa($c['member_discount_pct']) ?>٪):</span>
                                <strong><?= fa(number_format($netMemberFee)) ?> ریال</strong>
                            </div>
                        </div>

                        <div style="display:flex;justify-content:space-between;gap:6px;flex-wrap:wrap">
                            <?php if (\App\Core\App::canViewRoute('lms')): ?>
                                <a href="<?= e(url('lms?course_id=' . (int)$c['id'])) ?>" class="btn btn-primary btn-sm">🎓 ورود به کلاس LMS</a>
                            <?php endif; ?>
                            <?php if ($canMarketing): ?>
                                <a href="<?= e(url('marketing-intel')) ?>" class="btn btn-outline btn-sm">📣 ساخت کمپین</a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- VIEW B: INTERACTIVE DRAG & DROP WORKFLOW KANBAN BOARD -->
            <div id="tmsKanbanView" style="display:none">
                <div class="alert alert-info" style="margin-bottom:12px">
                    <div>🖐️ <strong>برد کانبان تعاملی گردش تصویب دوره‌ها:</strong> هر کارت دوره را با ماوس بکشید و در ستون وضعیت مقصد رها کنید تا بلافاصله بدون رفرش صفحه در دیتابیس MariaDB ذخیره شود!</div>
                </div>
                <?php
                $kanbanCols = [
                    'draft'        => ['پیش‌نویس اولیه', '#64748b'],
                    'under_review' => ['داوری کمیته علمی', '#d97706'],
                    'approved'     => ['مصوب آماده تقویم', '#2563eb'],
                    'published'    => ['منتشرشده (ثبت‌نام فعال)', '#059669'],
                ];
                ?>
                <div class="grid grid-4" style="gap:12px;align-items:start">
                    <?php foreach ($kanbanCols as $stKey => [$stLabel, $stColor]): ?>
                        <div class="tms-kanban-col" data-status="<?= e($stKey) ?>"
                             ondragover="event.preventDefault();this.style.borderColor='var(--primary)'"
                             ondragleave="this.style.borderColor='var(--border)'"
                             ondrop="window.dropCourseOnKanban(event, this)"
                             style="background:var(--surface-2);border:2px dashed var(--border);border-radius:14px;padding:12px;min-height:260px">
                            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;padding-bottom:8px;border-bottom:2px solid <?= e($stColor) ?>">
                                <strong style="font-size:12.8px"><?= e($stLabel) ?></strong>
                            </div>
                            <div class="tms-kanban-items" style="display:flex;flex-direction:column;gap:8px">
                                <?php foreach ($allCoursesUnfiltered as $kc): ?>
                                    <?php if ($kc['workflow_status'] === $stKey): ?>
                                        <div draggable="true"
                                             data-course-id="<?= (int)$kc['id'] ?>"
                                             ondragstart="event.dataTransfer.setData('text/plain', this.dataset.courseId);window.__draggedCourseCard=this;"
                                             style="background:var(--surface);border:1px solid var(--border);border-radius:10px;padding:10px;cursor:grab;box-shadow:var(--shadow-xs)">
                                            <div style="display:flex;justify-content:space-between;font-size:11px;margin-bottom:4px">
                                                <span class="badge badge-info"><?= e($kc['code']) ?></span>
                                                <span class="muted"><?= fa($kc['duration_hours']) ?> ساعت</span>
                                            </div>
                                            <div style="font-size:12.5px;font-weight:700;line-height:1.5"><?= e($kc['title']) ?></div>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- VIEW C: FULL ANALYTICAL TABLE + WORKFLOW TRANSITION -->
            <div id="tmsTableView" style="display:none">
                <div class="table-wrap">
                    <table>
                        <thead>
                        <tr>
                            <th>کد</th>
                            <th>عنوان دوره و دپارتمان</th>
                            <th>شیوه / مدت</th>
                            <th>شهریه و تخفیف ثبت‌نام</th>
                            <th>وضعیت گردش</th>
                            <th>تغییر وضعیت رسمی</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($courses as $c): ?>
                            <tr>
                                <td><strong><?= e($c['code']) ?></strong></td>
                                <td>
                                    <strong><?= e($c['title']) ?></strong>
                                    <div class="muted" style="font-size:11.5px"><?= e($c['category_title'] ?? '') ?> | سطح: <?= e($c['level']) ?></div>
                                </td>
                                <td><?= e($c['delivery_mode']) ?> (<?= fa($c['duration_hours']) ?> ساعت)</td>
                                <td>
                                    <?= fa(number_format((int)$c['tuition_rial'])) ?> ریال
                                    <?php if ((int)$c['member_discount_pct'] > 0): ?><span class="badge badge-gold"><?= fa($c['member_discount_pct']) ?>٪ تخفیف</span><?php endif; ?>
                                </td>
                                <td><span class="badge badge-info"><?= e($c['workflow_status']) ?></span></td>
                                <td>
                                    <?php if (Auth::hasRole(['super_admin', 'training_expert'])): ?>
                                        <form method="post" action="<?= e(url('tms')) ?>" style="display:flex;gap:5px">
                                            <?= csrf_field() ?>
                                            <input type="hidden" name="action" value="workflow_transition">
                                            <input type="hidden" name="course_id" value="<?= (int)$c['id'] ?>">
                                            <select name="next_status" style="width:auto;padding:4px 8px;font-size:11.5px">
                                                <option value="published">انتشار رسمی</option>
                                                <option value="approved">تأیید کمیته</option>
                                                <option value="under_review">بازبینی مجدد</option>
                                                <option value="archived">بایگانی</option>
                                            </select>
                                            <button type="submit" class="btn btn-primary btn-sm">ثبت</button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- ==================== TAB 2: VISUAL DRAG & DROP LEARNING PATH ARCHITECT ==================== -->
<?php if (!$isLearnerTms): ?>
    <div class="tab-panel" id="tab-paths">
        <div class="grid grid-2" style="gap:18px;align-items:start">
            <div class="card">
                <div class="card-header">
                    <div class="card-title">🧭 طراحی دیپلم مهارتی و مسیر یادگیری چنددوره‌ای (کلیک یا Drag &amp; Drop)</div>
                </div>
                <p class="muted" style="font-size:12.5px;margin-bottom:10px">
                    دوره‌های زیر را با ماوس بکشید و در «زنجیره مسیر یادگیری» رها کنید (یا روی هر دوره کلیک کنید) تا بسته جامع آموزشی ساخته شود:
                </p>
                <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:14px">
                    <?php foreach ($allCoursesUnfiltered as $pc): ?>
                        <button type="button" draggable="true" class="mod-ai-chip"
                                data-title="<?= e($pc['title']) ?>"
                                data-tuition="<?= (int)$pc['tuition_rial'] ?>"
                                ondragstart="event.dataTransfer.setData('text/plain', this.dataset.title + '||' + this.dataset.tuition)"
                                onclick="window.addCourseToPathChain(this.dataset.title, parseInt(this.dataset.tuition,10))">
                            ➕ <?= e($pc['title']) ?>
                        </button>
                    <?php endforeach; ?>
                </div>

                <form method="post" action="<?= e(url('tms')) ?>">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="save_learning_path">
                    <input type="hidden" name="courses_list" id="pathCoursesJsonInput" value="">

                    <div id="pathDropZone"
                         ondragover="event.preventDefault();this.style.borderColor='var(--primary)'"
                         ondragleave="this.style.borderColor='var(--border-strong)'"
                         ondrop="event.preventDefault();var raw=event.dataTransfer.getData('text/plain').split('||');window.addCourseToPathChain(raw[0], parseInt(raw[1]||'45000000',10));"
                         style="min-height:110px;padding:14px;border:2px dashed var(--border-strong);border-radius:14px;background:var(--surface-2);margin-bottom:12px">
                        <div id="pathSelectedList" style="display:flex;flex-direction:column;gap:7px;font-size:12.5px">
                            <span class="muted">هنوز دوره‌ای رها نشده است — روی تراشه‌های بالا کلیک کنید یا اینجا بکشید...</span>
                        </div>
                    </div>

                    <div class="form-grid">
                        <div class="form-group">
                            <label>عنوان دیپلم / مسیر جامع مهارتی:</label>
                            <input type="text" name="title" required placeholder="مثلاً: مسیر جامع حسابداری مالی">
                        </div>
                        <div class="form-group">
                            <label>گروه مخاطب هدف:</label>
                            <input type="text" name="target_persona" value="دانشجویان حسابداری و امور مالی">
                        </div>
                        <div class="form-group">
                            <label>شهریه بسته تخفیفی (ریال):</label>
                            <input type="number" name="bundle_tuition_rial" id="pathBundleTuition" value="98000000">
                        </div>
                        <div class="form-group">
                            <label>درصد تخفیف بسته جامع:</label>
                            <input type="number" name="discount_pct" value="25">
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary" style="margin-top:8px">💾 ذخیره مسیر یادگیری در کاتالوگ TMS</button>
                </form>
            </div>

            <div class="card">
                <div class="card-header"><div class="card-title">🏅 مسیرهای یادگیری و دوره‌های آدان</div></div>
                <div style="display:flex;flex-direction:column;gap:12px">
                    <?php foreach ($learningPaths as $lp): ?>
                        <?php $steps = json_decode((string)$lp['courses_json'], true) ?: []; ?>
                        <div style="padding:14px;border-radius:14px;background:var(--surface-2);border:1px solid var(--border)">
                            <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:6px">
                                <span class="badge badge-gold"><?= e($lp['level_badge']) ?></span>
                                <span class="badge badge-success"><?= fa($lp['discount_pct']) ?>٪ تخفیف بسته</span>
                            </div>
                            <strong style="font-size:14px;display:block;margin-bottom:6px"><?= e($lp['title']) ?></strong>
                            <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:8px">
                                <?php foreach ($steps as $idx => $stName): ?>
                                    <span style="font-size:11.5px;padding:3px 9px;border-radius:8px;background:var(--surface);border:1px solid var(--border)">
                                        گام <?= fa($idx + 1) ?>: <?= e($stName) ?>
                                    </span>
                                <?php endforeach; ?>
                            </div>
                            <div style="display:flex;justify-content:space-between;font-size:12px;color:var(--text-muted)">
                                <span>⏱ کل مدت: <?= fa($lp['total_hours']) ?> ساعت | 👥 <?= fa($lp['enrolled_learners']) ?> دانشجو</span>
                                <strong style="color:var(--primary)"><?= fa(number_format((int)$lp['bundle_tuition_rial'])) ?> ریال</strong>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>

<?php endif; ?>
    <!-- ==================== TAB 3: DYNAMIC PRICING & SVG BREAK-EVEN SIMULATOR ==================== -->
<?php if ($isTmsAdmin || Auth::hasRole(['finance_manager'])): ?>
    <div class="tab-panel" id="tab-pricing">
        <div class="grid grid-2" style="gap:18px;align-items:start">
            <div class="card">
                <div class="card-header"><div class="card-title">💎 آزمایشگاه هوشمند قیمت‌گذاری پویا و محاسبه نقطه سربه‌سر (Break-Even AI)</div></div>
                <form method="post" action="<?= e(url('tms')) ?>">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="save_pricing_scenario">
                    <div class="form-group">
                        <label>انتخاب دوره جهت شبیه‌سازی مالی:</label>
                        <select name="course_title">
                            <?php foreach ($allCoursesUnfiltered as $cOpt): ?>
                                <option value="<?= e($cOpt['title']) ?>"><?= e($cOpt['title']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-grid" style="margin-top:10px">
                        <div class="form-group">
                            <label>شهریه پایه هر نفر: <strong id="lblPrcFee">۵۲,۰۰۰,۰۰۰</strong> ریال</label>
                            <input type="range" name="base_tuition_rial" id="rngPrcFee" min="15000000" max="120000000" step="2000000" value="52000000" oninput="window.recalcTmsPricing()">
                        </div>
                        <div class="form-group">
                            <label>تخفیف ثبت‌نام: <strong id="lblPrcDisc">۰٪</strong></label>
                            <input type="range" name="member_discount_pct" id="rngPrcDisc" min="0" max="50" step="5" value="0" oninput="window.recalcTmsPricing()">
                        </div>
                        <div class="form-group">
                            <label>کل حق‌التدریس استاد: <strong id="lblPrcInst">۱۹۰,۰۰۰,۰۰۰</strong> ریال</label>
                            <input type="range" name="instructor_total_cost_rial" id="rngPrcInst" min="50000000" max="500000000" step="10000000" value="190000000" oninput="window.recalcTmsPricing()">
                        </div>
                        <div class="form-group">
                            <label>هزینه پذیرایی و اجرا: <strong id="lblPrcOps">۶۸,۰۰۰,۰۰۰</strong> ریال</label>
                            <input type="range" name="venue_ops_cost_rial" id="rngPrcOps" min="20000000" max="250000000" step="5000000" value="68000000" oninput="window.recalcTmsPricing()">
                        </div>
                    </div>
                    <input type="hidden" name="early_bird_pct" value="10">

                    <div class="grid grid-3" style="margin:14px 0;gap:10px">
                        <div style="padding:12px;border-radius:12px;background:var(--surface-2);border:1px solid var(--border);text-align:center">
                            <div class="muted" style="font-size:11.5px">نقطه سربه‌سر کلاس</div>
                            <strong id="outBreakevenSeats" style="font-size:18px;color:#d97706">۶ نفر</strong>
                        </div>
                        <div style="padding:12px;border-radius:12px;background:var(--surface-2);border:1px solid var(--border);text-align:center">
                            <div class="muted" style="font-size:11.5px">پیش‌بینی جذب (کشش تقاضا)</div>
                            <strong id="outPredSeats" style="font-size:18px;color:#2563eb">۲۸ نفر</strong>
                        </div>
                        <div style="padding:12px;border-radius:12px;background:var(--surface-2);border:1px solid var(--border);text-align:center">
                            <div class="muted" style="font-size:11.5px">مازاد خالص دوره</div>
                            <strong id="outNetSurplus" style="font-size:16px;color:#059669">۹۴۰ میلیون ریال</strong>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">💾 ثبت رسمی سناریوی قیمت‌گذاری در دیتابیس</button>
                </form>
            </div>

            <div class="card">
                <div class="card-header"><div class="card-title">📈 نمودار برداری نقطه سربه‌سر و سناریوهای ذخیره‌شده</div></div>
                <svg id="tmsBreakevenSvg" viewBox="0 0 460 190" style="width:100%;height:auto;background:var(--surface-2);border-radius:12px;padding:10px;margin-bottom:14px">
                    <line x1="40" y1="155" x2="435" y2="155" stroke="#94a3b8" stroke-width="1.2"/>
                    <line x1="40" y1="20" x2="40" y2="155" stroke="#94a3b8" stroke-width="1.2"/>
                    <line id="svgCostLine" x1="40" y1="108" x2="430" y2="108" stroke="#ef4444" stroke-width="2.5" stroke-dasharray="6,4"/>
                    <line id="svgRevLine" x1="40" y1="155" x2="430" y2="28" stroke="#10b981" stroke-width="3"/>
                    <circle id="svgBeDot" cx="145" cy="108" r="6" fill="#f59e0b" stroke="#fff" stroke-width="2"/>
                    <text x="330" y="24" fill="#10b981" font-size="11" font-weight="bold">خط درآمد کل شهریه</text>
                    <text x="330" y="100" fill="#ef4444" font-size="11" font-weight="bold">خط هزینه ثابت دوره</text>
                </svg>

                <?php foreach ($pricingScenarios as $ps): ?>
                    <div style="padding:10px 12px;border-radius:10px;background:var(--surface-2);border:1px solid var(--border);margin-bottom:8px;font-size:12px;display:flex;justify-content:space-between;align-items:center">
                        <div>
                            <strong><?= e($ps['course_title']) ?></strong>
                            <div class="muted">نقطه سربه‌سر: <?= fa($ps['breakeven_seats']) ?> نفر | پیش‌بینی ثبت‌نام: <?= fa($ps['predicted_enrollments']) ?> نفر</div>
                        </div>
                        <span class="badge badge-success">سود: <?= fa(number_format((int)$ps['projected_net_profit_rial'])) ?> ریال</span>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

<?php endif; ?>
    <!-- ==================== TAB 4: SHAMSI CALENDAR & WEEKLY TIMETABLE ==================== -->
    <div class="tab-panel" id="tab-calendar">
        <div class="card">
            <div class="card-header">
                <div class="card-title">📅 تقویم آموزشی شمسی و زمان‌بندی بدون تداخل جلسات — <?= e($calendar['title']) ?></div>
                <div style="display:flex;gap:6px">
                    <a class="btn btn-outline btn-sm" href="<?= e(url('tms', ['jy' => $jy, 'jm' => max(1, $jm - 1)])) ?>">◀ ماه قبل</a>
                    <a class="btn btn-outline btn-sm" href="<?= e(url('tms', ['jy' => $jy, 'jm' => min(12, $jm + 1)])) ?>">ماه بعد ▶</a>
                </div>
            </div>
            <div class="grid grid-4" style="gap:8px">
                <?php for ($d = 1; $d <= ($calendar['days_in_month'] ?? 30); $d++): ?>
                    <?php
                    $dateKey = sprintf('%04d/%02d/%02d', $jy, $jm, $d);
                    $dayFa = Jalali::digits($dateKey);
                    $evList = $calendar['events'][$dayFa] ?? ($calendar['events'][$dateKey] ?? []);
                    ?>
                    <div style="padding:9px 11px;border-radius:10px;background:<?= !empty($evList) ? 'var(--primary-soft)' : 'var(--surface-2)' ?>;border:1px solid <?= !empty($evList) ? 'var(--primary)' : 'var(--border)' ?>">
                        <div style="font-weight:800;font-size:12px"><?= fa($d) ?> <?= e($calendar['month_name'] ?? '') ?></div>
                        <?php foreach ($evList as $evItem): ?>
                            <div style="font-size:11px;color:var(--primary);margin-top:3px;font-weight:600">• <?= e($evItem) ?></div>
                        <?php endforeach; ?>
                    </div>
                <?php endfor; ?>
            </div>
        </div>
    </div>

    <!-- ==================== TAB 5: COHORT RUNS & CLASS SESSIONS ==================== -->
<?php if (!$isLearnerTms): ?>
    <div class="tab-panel" id="tab-runs">
        <div class="card">
            <div class="card-header"><div class="card-title">🏫 اجراهای فعال دوره‌ها (Cohorts)، ظرفیت صندلی و جلسات کلاسی</div></div>
            <div class="table-wrap">
                <table>
                    <thead>
                    <tr>
                        <th>کد اجرا</th>
                        <th>عنوان دوره</th>
                        <th>استاد / تالار</th>
                        <th>تاریخ شروع شمسی</th>
                        <th>تکمیل ظرفیت</th>
                        <th>وضعیت و گزارش اجرایی</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($runs as $r): ?>
                        <?php $pctFill = min(100, (int)round(((int)$r['actual_enrolled_count'] / max(1, (int)$r['capacity'])) * 100)); ?>
                        <tr>
                            <td>
                                <span class="badge badge-info"><?= e($r['run_code']) ?></span>
                                <div class="muted" style="font-size:11px"><?= e($r['status']) ?></div>
                            </td>
                            <td><strong><?= e($r['course_title']) ?></strong><div class="muted" style="font-size:11.5px"><?= e($r['schedule_text']) ?></div></td>
                            <td><?= e($r['instructor_name'] ?? 'استاد مدعو') ?> • <?= e($r['room_name'] ?? 'تالار اصلی') ?></td>
                            <td><?= e($r['start_shamsi']) ?></td>
                            <td>
                                <div style="font-size:12px;font-weight:700"><?= fa($r['actual_enrolled_count']) ?> از <?= fa($r['capacity']) ?> نفر (<?= fa($pctFill) ?>٪)</div>
                                <div class="progress-track" style="height:6px;margin-top:4px"><div class="progress-fill" style="width:<?= $pctFill ?>%"></div></div>
                            </td>
                            <td>
                                <?php if ($isTmsAdmin && in_array($r['status'], ['planning', 'registration'], true) && $r['start_date'] <= date('Y-m-d')): ?>
                                    <form method="post" action="<?= e(url('tms')) ?>" style="margin-bottom:5px">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="action" value="start_run">
                                        <input type="hidden" name="run_id" value="<?= (int)$r['id'] ?>">
                                        <button type="submit" class="btn btn-outline btn-sm">شروع اجرا</button>
                                    </form>
                                <?php elseif ($isTmsAdmin && $r['status'] === 'running' && $r['end_date'] <= date('Y-m-d')): ?>
                                    <form method="post" action="<?= e(url('tms')) ?>" style="margin-bottom:5px" onsubmit="return confirm('آیا برگزاری همه جلسات این دوره به پایان رسیده است؟')">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="action" value="complete_run">
                                        <input type="hidden" name="run_id" value="<?= (int)$r['id'] ?>">
                                        <button type="submit" class="btn btn-outline btn-sm">ثبت پایان دوره</button>
                                    </form>
                                <?php endif; ?>
                                <form method="post" action="<?= e(url('tms')) ?>" style="display:flex;gap:5px">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action" value="save_exec_report">
                                    <input type="hidden" name="run_id" value="<?= (int)$r['id'] ?>">
                                    <input type="text" name="execution_report" value="<?= e($r['execution_report'] ?? '') ?>" placeholder="ثبت یادداشت کیفی اجرا..." style="min-width:150px;padding:4px 8px;font-size:11.5px">
                                    <button type="submit" class="btn btn-outline btn-sm">ذخیره</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php if (Auth::hasRole(['super_admin', 'training_expert', 'instructor'])): ?>
                <form method="post" action="<?= e(url('tms')) ?>" class="card" style="margin-top:16px">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="create_session">
                    <div class="card-title" style="margin-bottom:10px">➕ برنامه‌ریزی جلسهٔ کلاس</div>
                    <div class="form-grid">
                        <div class="form-group">
                            <label>اجرای دوره</label>
                            <select name="run_id" required>
                                <?php foreach ($runs as $runOption): ?>
                                    <?php if ($runOption['status'] === 'registration' && $runOption['start_date'] > date('Y-m-d')): ?>
                                        <option value="<?= (int)$runOption['id'] ?>"><?= e($runOption['run_code']) ?> — <?= e($runOption['course_title']) ?></option>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group"><label>شماره جلسه</label><input type="number" name="session_number" min="1" required></div>
                        <div class="form-group"><label>عنوان جلسه</label><input type="text" name="title" required></div>
                        <div class="form-group"><label>تاریخ</label><input type="date" name="session_date" required></div>
                        <div class="form-group"><label>شروع</label><input type="time" name="start_time" value="14:00" required></div>
                        <div class="form-group"><label>پایان</label><input type="time" name="end_time" value="18:00" required></div>
                        <div class="form-group"><label>تالار / محل برگزاری</label><input type="text" name="room_or_link" value="کلاس آموزشگاه آدان" required></div>
                    </div>
                    <button type="submit" class="btn btn-primary btn-sm">ثبت جلسه</button>
                </form>
            <?php endif; ?>
            <div class="card-header" style="margin-top:16px"><div class="card-title">📋 جلسات و ثبت حضور و تأیید برگزاری</div></div>
            <?php foreach ($sessions as $session): ?>
                <?php
                $sessionEndTime = substr((string)($session['end_time'] ?? ''), 0, 5);
                $attendanceEditable = preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d$/', $sessionEndTime)
                    && ($session['session_date'] < date('Y-m-d')
                        || ($session['session_date'] === date('Y-m-d') && $sessionEndTime <= date('H:i')));
                ?>
                <details style="padding:10px 12px;border:1px solid var(--border);border-radius:10px;margin-bottom:8px">
                    <summary style="cursor:pointer;font-weight:700">
                        <?= e($session['course_title']) ?> — <?= e($session['title']) ?>
                        | <?= e($session['session_shamsi']) ?> <?= e($session['start_time']) ?> تا <?= e($session['end_time']) ?>
                        | <?= (int)$session['is_held'] === 1 ? 'برگزارشده' : 'برگزاری تأییدنشده' ?>
                    </summary>
                    <?php if (
                        $session['run_status'] === 'running'
                        && $attendanceEditable
                        && (int)$session['is_held'] !== 1
                        && Auth::hasRole(['super_admin', 'training_expert', 'instructor'])
                    ): ?>
                        <form method="post" action="<?= e(url('tms')) ?>" style="margin:8px 0">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="mark_session_held">
                            <input type="hidden" name="session_id" value="<?= (int)$session['id'] ?>">
                            <button type="submit" class="btn btn-outline btn-sm">تأیید برگزاری این جلسه</button>
                        </form>
                    <?php endif; ?>
                    <?php if (Auth::hasRole(['super_admin', 'training_expert', 'instructor'])): ?>
                        <?php $sessionAttendance = $attendanceBySession[(int)$session['id']] ?? []; ?>
                        <?php if ($sessionAttendance !== []): ?>
                            <div class="table-wrap" style="margin-top:8px">
                                <table>
                                    <thead><tr><th>فراگیر</th><th>وضعیت حضور</th><th></th></tr></thead>
                                    <tbody>
                                    <?php foreach ($sessionAttendance as $attendance): ?>
                                        <tr>
                                            <td><?= e($attendance['full_name']) ?></td>
                                            <td>
                                                <?php if ($attendanceEditable): ?>
                                                <form method="post" action="<?= e(url('tms')) ?>" style="display:flex;gap:8px;align-items:center">
                                                    <?= csrf_field() ?>
                                                    <input type="hidden" name="action" value="record_attendance">
                                                    <input type="hidden" name="session_id" value="<?= (int)$session['id'] ?>">
                                                    <input type="hidden" name="user_id" value="<?= (int)$attendance['user_id'] ?>">
                                                    <select name="att_status" style="max-width:180px">
                                                        <?php foreach (['present' => 'حاضر', 'late' => 'با تأخیر', 'absent' => 'غایب', 'excused' => 'موجه'] as $statusValue => $statusLabel): ?>
                                                            <option value="<?= e($statusValue) ?>" <?= ($attendance['attendance_status'] ?? 'present') === $statusValue ? 'selected' : '' ?>><?= e($statusLabel) ?></option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                    <button type="submit" class="btn btn-outline btn-sm">ثبت</button>
                                                </form>
                                                <?php else: ?>
                                                    <span class="muted">پس از پایان جلسه قابل ثبت است</span>
                                                <?php endif; ?>
                                            </td>
                                            <td></td>
                                        </tr>
                                    <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <p class="muted" style="margin:8px 0">برای این اجرا فراگیر فعال وجود ندارد؛ در صورت برگزاری جلسه، آن را صریحاً تأیید کنید.</p>
                        <?php endif; ?>
                    <?php endif; ?>
                </details>
            <?php endforeach; ?>
        </div>
    </div>

<?php endif; ?>
    <!-- ==================== TAB 6: ENROLLMENT, CSV BULK, WAITLIST & ATTENDANCE ==================== -->
    <div class="tab-panel" id="tab-enroll">
        <div class="grid grid-2" style="gap:16px;margin-bottom:16px">
            <div class="card">
                <div class="card-header"><div class="card-title">📝 ثبت‌نام انفرادی دانشجو (با تشخیص خودکار فهرست انتظار)</div></div>
                <form method="post" action="<?= e(url('tms')) ?>">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="enroll_single">
                    <div class="form-grid">
                        <div class="form-group">
                            <label>انتخاب اجرای دوره:</label>
                            <select name="run_id">
                                <?php foreach ($runs as $r): ?>
                                    <?php if ($r['status'] === 'registration' && $r['start_date'] > date('Y-m-d')): ?>
                                        <option value="<?= (int)$r['id'] ?>">[<?= e($r['run_code']) ?>] <?= e($r['course_title']) ?></option>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>انتخاب دانشجو:</label>
                            <select name="user_id">
                                <?php foreach ($learners as $l): ?>
                                    <option value="<?= (int)$l['id'] ?>"><?= e($l['full_name']) ?> (<?= e($l['job_title']) ?>)</option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary btn-sm" style="margin-top:8px">ثبت‌نام فوری در کلاس</button>
                </form>
            </div>

<?php if (!$isLearnerTms): ?>
            <div class="card">
                <div class="card-header"><div class="card-title">👥 ثبت‌نام گروهی دانشجویان</div></div>
                <form method="post" action="<?= e(url('tms')) ?>">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="bulk_group_enroll">
                    <div class="form-group">
                        <label>انتخاب اجرای دوره:</label>
                        <select name="run_id">
                            <?php foreach ($runs as $r): ?>
                                <?php if ($r['status'] === 'registration' && $r['start_date'] > date('Y-m-d')): ?>
                                    <option value="<?= (int)$r['id'] ?>">[<?= e($r['run_code']) ?>] <?= e($r['course_title']) ?></option>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group" style="margin-top:6px">
                        <label>هر خط: نام، موبایل، کد ملی، گذرواژه اولیه (کاربر جدید)</label>
                        <textarea name="csv_lines" rows="2" placeholder="نام,موبایل,کدملی,گذرواژه-حداقل-۱۲-نویسه"></textarea>
                    </div>
                    <button type="submit" class="btn btn-gold btn-sm">ثبت گروهی سهمیه سازمانی</button>
                </form>
            </div>
<?php endif; ?>
        </div>

        <div class="card">
            <div class="card-header"><div class="card-title">📋 فهرست ثبت‌نام‌کنندگان و ارتقای خودکار فهرست انتظار (Waitlist Auto-Promotion)</div></div>
            <div class="table-wrap">
                <table>
                    <thead>
                    <tr>
                        <th>دانشجو</th>
                        <th>معرف</th>
                        <th>دوره و کد اجرا</th>
                        <th>وضعیت ثبت‌نام</th>
                        <th>عملیات</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($enrollments as $en): ?>
                        <tr>
                            <td><strong><?= e($en['full_name']) ?></strong></td>
                            <td><?= e($en['org_name'] ?? 'ثبت‌نام آزاد') ?></td>
                            <td><?= e($en['course_title']) ?> (<code><?= e($en['run_code']) ?></code>)</td>
                            <td><span class="badge <?= $en['status'] === 'active' ? 'badge-success' : 'badge-gold' ?>"><?= e($en['status']) ?></span></td>
                            <td>
                                <?php if (Auth::hasRole(['super_admin', 'training_expert', 'org_rep'])): ?>
                                    <form method="post" action="<?= e(url('tms')) ?>" style="display:inline">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="action" value="cancel_enrollment">
                                        <input type="hidden" name="enrollment_id" value="<?= (int)$en['id'] ?>">
                                        <button type="submit" class="btn btn-outline btn-sm">انصراف و جایگزینی خودکار انتظار</button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php if (!$isLearnerTms): ?>
<!-- MODAL: NEW COURSE -->
<div class="modal-backdrop" id="newCourseModal" onclick="if(event.target===this)this.classList.remove('open')">
    <div class="modal-box">
        <div class="card-header">
            <div class="card-title">➕ تعریف دوره آموزشی جدید در کاتالوگ</div>
            <button type="button" class="btn btn-outline btn-sm" onclick="document.getElementById('newCourseModal').classList.remove('open')">بستن</button>
        </div>
        <form method="post" action="<?= e(url('tms')) ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="create_course">
            <div class="form-grid">
                <div class="form-group"><label>کد دوره:</label><input type="text" name="code" value="TRD-<?= rand(400, 899) ?>" required></div>
                <div class="form-group"><label>عنوان دوره:</label><input type="text" name="title" required placeholder="عنوان تخصصی دوره..."></div>
                <div class="form-group">
                    <label>دپارتمان:</label>
                    <select name="category_id">
                        <?php foreach ($categories as $cat): ?>
                            <option value="<?= (int)$cat['id'] ?>"><?= e($cat['title']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>سطح دوره:</label>
                    <select name="level">
                        <option value="مقدماتی">مقدماتی</option>
                        <option value="میانی" selected>میانی</option>
                        <option value="پیشرفته">پیشرفته</option>
                        <option value="مدیریتی ویژه">مدیریتی ویژه</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>شیوهٔ برگزاری:</label>
                    <select name="delivery_mode">
                        <option value="حضوری">حضوری</option>
                        <option value="آنلاین همزمان">آنلاین همزمان</option>
                        <option value="ترکیبی" selected>ترکیبی</option>
                        <option value="خودآموز LMS">خودآموز LMS</option>
                    </select>
                </div>
                <div class="form-group"><label>مدت مصوب (ساعت):</label><input type="number" name="duration_hours" min="1" max="1000" value="24" required></div>
                <div class="form-group"><label>شهریه پایه (ریال):</label><input type="number" name="tuition_rial" value="48000000"></div>
                <div class="form-group"><label>درصد تخفیف ثبت‌نام:</label><input type="number" name="member_discount_pct" min="0" max="100" value="0"></div>
            </div>
            <div class="form-group" style="margin-top:8px"><label>چکیده سرفصل‌ها:</label><textarea name="summary" rows="2"></textarea></div>
            <button type="submit" class="btn btn-primary" style="margin-top:8px">ثبت در کاتالوگ</button>
        </form>
    </div>
</div>

<!-- MODAL: NEW RUN -->
<div class="modal-backdrop" id="newRunModal" onclick="if(event.target===this)this.classList.remove('open')">
    <div class="modal-box">
        <div class="card-header">
            <div class="card-title">📅 تعریف اجرای جدید کلاس در تقویم</div>
            <button type="button" class="btn btn-outline btn-sm" onclick="document.getElementById('newRunModal').classList.remove('open')">بستن</button>
        </div>
        <form method="post" action="<?= e(url('tms')) ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="create_run">
            <div class="form-grid">
                <div class="form-group">
                    <label>دوره:</label>
                    <select name="course_id">
                        <?php foreach ($allCoursesUnfiltered as $c): ?>
                            <?php if (in_array($c['workflow_status'], ['approved', 'published'], true)): ?>
                                <option value="<?= (int)$c['id'] ?>"><?= e($c['title']) ?></option>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>تالار / کلاس:</label>
                    <select name="classroom_id">
                        <option value="0">بدون کلاس حضوری (آنلاین)</option>
                        <?php foreach ($classrooms as $cl): ?>
                            <option value="<?= (int)$cl['id'] ?>"><?= e($cl['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>مدرس مسئول:</label>
                    <select name="instructor_id" required>
                        <option value="">انتخاب مدرس</option>
                        <?php foreach ($instructors as $instructor): ?>
                            <option value="<?= (int)$instructor['id'] ?>"><?= e($instructor['full_name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group"><label>عنوان ترم:</label><input type="text" name="term_label" value="نیمسال دوم ۱۴۰۵"></div>
                <div class="form-group"><label>تاریخ شروع:</label><input type="date" name="start_date" min="<?= e(date('Y-m-d', strtotime('+1 day'))) ?>" value="<?= e(date('Y-m-d', strtotime('+7 days'))) ?>" required></div>
                <div class="form-group"><label>تاریخ پایان:</label><input type="date" name="end_date" min="<?= e(date('Y-m-d', strtotime('+1 day'))) ?>" value="<?= e(date('Y-m-d', strtotime('+28 days'))) ?>" required></div>
                <div class="form-group"><label>ظرفیت کلاس:</label><input type="number" name="capacity" min="1" value="30" required></div>
                <div class="form-group"><label>روز و ساعت برگزاری:</label><input type="text" name="schedule_text" value="دوشنبه‌ها ۱۶ الی ۲۰"></div>
            </div>
            <button type="submit" class="btn btn-primary" style="margin-top:8px">ثبت اجرای جدید</button>
        </form>
    </div>
</div>
<?php endif; ?>

<script>
window.switchTmsView = function (mode) {
    document.getElementById('tmsCardsView').style.display = mode === 'cards' ? 'grid' : 'none';
    document.getElementById('tmsKanbanView').style.display = mode === 'kanban' ? 'block' : 'none';
    document.getElementById('tmsTableView').style.display = mode === 'table' ? 'block' : 'none';
    ['Cards', 'Kanban', 'Table'].forEach(function (m) {
        var b = document.getElementById('btnView' + m);
        if (b) {
            b.className = (mode === m.toLowerCase()) ? 'btn btn-primary btn-sm' : 'btn btn-outline btn-sm';
        }
    });
};

window.dropCourseOnKanban = function (ev, colEl) {
    ev.preventDefault();
    colEl.style.borderColor = 'var(--border)';
    var cid = ev.dataTransfer.getData('text/plain');
    var nextStatus = colEl.getAttribute('data-status');
    if (window.__draggedCourseCard) {
        colEl.querySelector('.tms-kanban-items').appendChild(window.__draggedCourseCard);
    }
    var fd = new FormData();
    fd.append('ajax', '1');
    fd.append('op', 'kanban_move');
    fd.append('course_id', cid);
    fd.append('next_status', nextStatus);
    fetch(window.chamberApiUrl('tms'), { method: 'POST', body: fd, credentials: 'same-origin' }).catch(function(){});
};

window.__pathCourses = [];
window.__pathRawSum = 0;
window.addCourseToPathChain = function (title, tuition) {
    if (!title || window.__pathCourses.indexOf(title) !== -1) return;
    window.__pathCourses.push(title);
    window.__pathRawSum += (tuition || 45000000);
    document.getElementById('pathCoursesJsonInput').value = JSON.stringify(window.__pathCourses);
    document.getElementById('pathBundleTuition').value = Math.round(window.__pathRawSum * 0.75);
    var box = document.getElementById('pathSelectedList');
    box.innerHTML = window.__pathCourses.map(function (t, idx) {
        return '<div style="padding:7px 10px;border-radius:9px;background:var(--surface);border:1px solid var(--primary);font-weight:700">'
            + 'گام ' + (idx + 1).toLocaleString('fa-IR') + ': ' + t + '</div>';
    }).join('');
};

window.recalcTmsPricing = function () {
    var fee = parseInt(document.getElementById('rngPrcFee').value, 10) || 52000000;
    var disc = parseInt(document.getElementById('rngPrcDisc').value, 10) || 0;
    var inst = parseInt(document.getElementById('rngPrcInst').value, 10) || 190000000;
    var ops = parseInt(document.getElementById('rngPrcOps').value, 10) || 68000000;
    document.getElementById('lblPrcFee').textContent = fee.toLocaleString('fa-IR');
    document.getElementById('lblPrcDisc').textContent = disc.toLocaleString('fa-IR') + '٪';
    document.getElementById('lblPrcInst').textContent = inst.toLocaleString('fa-IR');
    document.getElementById('lblPrcOps').textContent = ops.toLocaleString('fa-IR');

    var netFee = Math.round(fee * (1 - (disc * 0.55) / 100));
    var fixed = inst + ops;
    var be = Math.max(1, Math.ceil(fixed / Math.max(1, netFee)));
    var seats = Math.max(be + 3, Math.round(35 - (fee / 8500000) + (disc * 0.22)));
    var profit = (seats * netFee) - fixed;

    document.getElementById('outBreakevenSeats').textContent = be.toLocaleString('fa-IR') + ' نفر';
    document.getElementById('outPredSeats').textContent = seats.toLocaleString('fa-IR') + ' نفر';
    document.getElementById('outNetSurplus').textContent = Math.round(profit / 1000000).toLocaleString('fa-IR') + ' میلیون ریال';
    var dot = document.getElementById('svgBeDot');
    if (dot) dot.setAttribute('cx', String(Math.min(390, Math.max(65, 45 + be * 11))));
};
</script>
