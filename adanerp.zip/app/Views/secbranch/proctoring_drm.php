<div class="hero-banner">
    <div>
        <span class="badge badge-warning">شبیه‌ساز محلی؛ پروکتورینگ و DRM متصل نیست</span>
        <h1>پیش‌نمایش آزمون تطبیقی و ثبت دستی رخداد</h1>
        <p>
            مقادیر این صفحه نمایشی‌اند؛ رخداد مرورگر، هویت داوطلب یا محتوای صفحه پایش نمی‌شود و واترمارک ضدکپی اعمال نمی‌گردد.
        </p>
    </div>
    <button type="button" class="btn btn-gold" onclick="window.startLiveCatSimulator()">اجرای پیش‌نمایش محلی CAT</button>
</div>

<!-- LOCAL CAT PREVIEW; NO PROCTORING SENSOR IS CONNECTED -->
<div class="grid grid-2" style="margin-bottom:18px">
    <div class="card" style="border:1.5px solid rgba(15,118,110,0.35)">
        <div class="card-header">
            <div class="card-title">پیش‌نمایش تعاملی محلی (بدون آزمون رسمی)</div>
            <span class="badge badge-purple" id="catLevelBadge">سطح دشواری فعلی: ۳ (متوسط رو به بالا)</span>
        </div>
        <div id="catInteractiveBox">
            <p class="muted" style="font-size:12.5px;margin-bottom:10px">
                در این موتور، با هر پاسخ صحیح سطح دشواری سؤال بعدی افزایش یافته و ضریب توانایی علمی شما (<code>θ</code>) دقیق‌تر محاسبه می‌شود:
            </p>
            <div id="catQuestionStage" style="padding:14px;border-radius:12px;background:var(--surface-2);border:1px solid var(--border)">
                <div style="font-weight:800;margin-bottom:8px" id="catQText">تمرین نمایشی ۱: در ثبت خرید نسیه ملزومات اداری، کدام حساب بستانکار می‌شود؟</div>
                <div style="display:flex;flex-direction:column;gap:6px" id="catOptionsWrap">
                    <button type="button" class="btn btn-outline" style="justify-content:flex-start" onclick="window.answerCatStep(true)">الف) حساب‌های پرداختنی</button>
                    <button type="button" class="btn btn-outline" style="justify-content:flex-start" onclick="window.answerCatStep(false)">ب) موجودی صندوق</button>
                    <button type="button" class="btn btn-outline" style="justify-content:flex-start" onclick="window.answerCatStep(false)">ج) سرمایه</button>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <div class="card-title">نمونهٔ نمایشی شاخص سلامت (بدون اندازه‌گیری واقعی)</div>
            <span class="badge badge-warning" id="liveIntegrityBadge">نمونهٔ نمایشی: ۱۰۰٪</span>
        </div>
        <div style="padding:14px;border-radius:12px;background:repeating-linear-gradient(-25deg,rgba(15,118,110,0.05),rgba(15,118,110,0.05) 40px,rgba(201,146,39,0.07) 40px,rgba(201,146,39,0.07) 80px);border:1px dashed var(--primary);margin-bottom:10px">
            <div style="font-size:11.5px;color:var(--primary);font-weight:800">نمونهٔ متنی واترمارک (اعمال نشده):</div>
            <div style="font-family:monospace;font-size:13px;margin-top:4px;opacity:0.8">DEMO-LOCAL | watermark inactive</div>
        </div>
        <div class="grid grid-2" style="gap:10px;font-size:12.5px">
            <div style="padding:10px;border-radius:10px;background:var(--surface-2)">
                <span class="muted">پایش خروج از تب مرورگر:</span>
                <strong style="display:block;font-size:18px;margin-top:3px" id="liveTabSwitchCount">غیرفعال</strong>
            </div>
            <div style="padding:10px;border-radius:10px;background:var(--surface-2)">
                <span class="muted">امتیاز تمرین نمایشی (محاسبه روان‌سنجی نیست):</span>
                <strong style="display:block;font-size:18px;margin-top:3px;color:var(--primary)" id="liveThetaDisplay">نمایشی</strong>
            </div>
        </div>
    </div>
</div>

<!-- ADAPTIVE CAT SESSIONS TABLE -->
<div class="card" style="margin-bottom:18px">
    <div class="card-header"><div class="card-title">داده‌های نمونهٔ CAT (آزمون رسمی یا پایش تقلب نیست)</div></div>
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>کد نشست</th>
                    <th>داوطلب</th>
                    <th>حوزه تخصصی آزمون</th>
                    <th>سطح نهایی (۱-۵)</th>
                    <th>توانایی (θ)</th>
                    <th>سطح تشخیص‌داده‌شده</th>
                    <th>خروج از تب / شباهت غلط‌ها</th>
                    <th>نمره سلامت</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach (($catSessions ?? []) as $cs): ?>
                <tr>
                    <td><code><?= e($cs['session_code']) ?></code></td>
                    <td><strong><?= e($cs['candidate_name']) ?></strong></td>
                    <td><?= e($cs['domain_title']) ?></td>
                    <td><span class="badge badge-purple">سطح <?= fa($cs['final_difficulty_level']) ?></span></td>
                    <td><code><?= e((string)$cs['theta_ability']) ?></code></td>
                    <td><strong><?= e($cs['cefr_or_mastery_band']) ?></strong></td>
                    <td style="font-size:12px"><?= fa($cs['tab_switches_detected']) ?> بار | شباهت: <?= fa($cs['collusion_similarity_pct']) ?>٪</td>
                    <td>
                        <span class="badge <?= (int)$cs['integrity_score'] >= 85 ? 'badge-success' : 'badge-danger' ?>">
                            <?= fa($cs['integrity_score']) ?>٪
                        </span>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- PROCTORING EVENTS LOG -->
<div class="card">
    <div class="card-header"><div class="card-title">رخدادهای واردشدهٔ دستی (سنسور مرورگر متصل نیست)</div></div>
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>شرکت‌کننده</th>
                    <th>آزمون / محتوا</th>
                    <th>نوع رخداد</th>
                    <th>سطح ریسک</th>
                    <th>مهر واترمارک</th>
                    <th>وضعیت بررسی</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach (($events ?? []) as $ev): ?>
                <tr>
                    <td><strong><?= e($ev['user_full_name']) ?></strong></td>
                    <td><?= e($ev['exam_or_lesson_title']) ?></td>
                    <td><?= e($ev['event_type']) ?></td>
                    <td><span class="badge badge-gold"><?= e($ev['risk_level']) ?></span></td>
                    <td><code><?= e($ev['watermark_stamp']) ?></code></td>
                    <td><?= e($ev['reviewer_decision']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
