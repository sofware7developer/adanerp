<div class="hero-banner">
    <div>
        <span class="badge badge-warning">اتصال شاهکار، OTP و PKI فعال نیست</span>
        <h1>آماده‌سازی یکپارچه‌سازی شاهکار و امضای دیجیتال</h1>
        <p>این بخش پیش‌نویس محلی و چکیدهٔ SHA-256 می‌سازد؛ هویت بررسی نمی‌شود و سند امضای قانونی/PKI دریافت نمی‌کند.</p>
    </div>
</div>

<div class="alert alert-info">
    ⚠️ <strong>حالت محلی:</strong> استعلام شاهکار، OTP و امضای دارای گواهی PKI به سرویس بیرونی متصل نیستند. هیچ هویت یا امضایی تأیید نمی‌شود.
</div>

<div class="grid grid-sidebar">
    <div class="card">
        <div class="card-header"><div class="card-title">پیش‌نویس‌های محلی (بدون تطبیق هویت یا امضای PKI)</div></div>
        <div class="table-wrap">
            <table>
                <thead><tr><th>کاربر سامانه</th><th>عنوان پیش‌نویس</th><th>وضعیت اتصال</th><th>چکیده محلی (نه امضای دیجیتال)</th><th>زمان ثبت</th></tr></thead>
                <tbody>
                <?php foreach ($logs as $l): ?>
                    <tr>
                        <td><strong><?= e($l['user_full_name']) ?></strong></td>
                        <td><?= e($l['document_title']) ?></td>
                        <td><span class="badge badge-warning"><?= e($l['shahkar_status']) ?></span></td>
                        <td dir="ltr"><code><?= e(substr($l['pki_hash_sha256'], 0, 20)) ?>...</code></td>
                        <td><?= e($l['signed_shamsi']) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card">
        <div class="card-header"><div class="card-title">ثبت پیش‌نویس و چکیدهٔ محلی</div></div>
        <form method="post" action="<?= e(url('sso-pki')) ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="sign_document">
            <div class="form-group"><label>عنوان پیش‌نویس:</label><input type="text" name="document_title" maxlength="200" required></div>
            <button type="submit" class="btn btn-outline" style="width:100%">ثبت محلی بدون امضا</button>
        </form>
    </div>
</div>

<!-- v15.0 ZERO-TRUST SECURITY SOC TELEMETRY -->
<div class="card" style="margin-top:18px;border:1.5px solid rgba(201,146,39,0.4)">
    <div class="card-header">
        <div>
            <div class="card-title">🛡️ مرکز عملیات امنیت و سپر ضدنفوذ نشست‌ها (Zero-Trust Security SOC &amp; Brute-Force Shield)</div>
            <div class="muted" style="font-size:12px">محاسبهٔ نمونه از داده‌های دستی؛ دادهٔ نشست واقعی خوانده نمی‌شود و قرنطینه‌ای انجام نمی‌شود.</div>
        </div>
        <span class="badge badge-warning">شبیه‌ساز محلی</span>
    </div>
    <form method="post" action="<?= e(url('sso-pki')) ?>" class="grid grid-4" style="gap:10px;align-items:end;margin-bottom:14px">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="scan_soc_event">
        <div><label>نام نمونهٔ کاربر (فقط ثبت محلی):</label><input type="text" name="actor_username" value="demo-user" dir="ltr"></div>
        <div><label>IP نمونه (بدون اتصال شبکه):</label><input type="text" name="client_ip" value="192.0.2.10" dir="ltr"></div>
        <div><label>تعداد خطای نمونه:</label><input type="number" name="failed_attempts" value="5"></div>
        <div><button type="submit" class="btn btn-outline" style="width:100%">محاسبهٔ امتیاز نمونه</button></div>
    </form>
    <div class="table-wrap">
        <table>
            <thead><tr><th>کد رخداد</th><th>کاربر نمونه</th><th>IP نمونه</th><th>امتیاز نمونه</th><th>طبقه‌بندی نمونه</th><th>اقدام (نمایشی)</th></tr></thead>
            <tbody>
            <?php foreach (($socEvents ?? []) as $se): ?>
                <tr>
                    <td><code><?= e($se['event_code']) ?></code></td>
                    <td dir="ltr"><strong><?= e($se['actor_username']) ?></strong></td>
                    <td dir="ltr"><code><?= e($se['client_ip']) ?></code></td>
                    <td><span class="badge <?= (int)$se['risk_score'] >= 60 ? 'badge-danger' : 'badge-success' ?>"><?= fa($se['risk_score']) ?> / ۱۰۰</span></td>
                    <td><?= e($se['threat_classification']) ?></td>
                    <td style="font-size:12px"><?= e($se['mitigation_action']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
