<?php use App\Core\Auth; ?>
<div class="hero-banner">
    <div>
        <span class="badge badge-gold">اتوماسیون فرایندها (BPMS) و زنجیره خودکار میان‌ماژولی</span>
        <h1>موتور گردش کار (BPMS)، قواعد ارجاع و گردش ثبت‌نام آموزشی</h1>
        <p>پیگیری فرایندهای آموزشگاه از ثبت‌نام و امور مالی تا پیشرفت یادگیری، آزمون و ثبت سوابق آموزشی.</p>
    </div>
    <?php if (Auth::hasRole(['super_admin'])): ?>
        <form method="post" action="<?= e(url('bpms')) ?>" class="form-grid" style="align-items:end">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="run_full_pipeline">
            <div><label>فراگیر:</label><select name="user_id" required>
                <?php foreach (($pipelineLearners ?? []) as $learner): ?>
                    <option value="<?= (int)$learner['id'] ?>"><?= e($learner['full_name']) ?></option>
                <?php endforeach; ?>
            </select></div>
            <div><label>دورهٔ دارای اجرای فعال/تکمیل‌شده:</label><select name="course_id" required>
                <?php foreach (($pipelineCourses ?? []) as $course): ?>
                    <option value="<?= (int)$course['id'] ?>"><?= e($course['title']) ?></option>
                <?php endforeach; ?>
            </select></div>
            <input type="hidden" name="attendance_pct" value="94">
            <input type="hidden" name="exam_score" value="91.5">
            <button type="submit" class="btn btn-gold" <?= empty($pipelineLearners) || empty($pipelineCourses) ? 'disabled' : '' ?>>⚡ اجرای گردش‌کار آموزشی</button>
        </form>
    <?php endif; ?>
</div>

<div class="grid grid-sidebar">
    <div class="card">
        <div class="card-header"><div class="card-title">⚙️ فرایندهای سازمانی فعال و تاریخچه گردش</div></div>
        <?php foreach ($workflows as $wf): ?>
            <?php
            $breach = (int)$wf['elapsed_hours'] > (int)$wf['sla_hours'];
            $hist = json_decode((string)$wf['history_json'], true) ?: [];
            ?>
            <div style="border:1px solid var(--border);border-radius:14px;padding:15px;margin-bottom:14px">
                <div style="display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap">
                    <div>
                        <span class="badge badge-purple"><?= e($wf['process_key']) ?></span>
                        <strong style="margin-right:6px"><?= e($wf['subject_label']) ?></strong>
                    </div>
                    <span class="badge <?= $wf['status'] === 'approved' ? 'badge-success' : ($breach ? 'badge-danger' : 'badge-info') ?>">
                        SLA: <?= fa($wf['elapsed_hours']) ?> از <?= fa($wf['sla_hours']) ?> ساعت | وضعیت: <?= e($wf['status']) ?>
                    </span>
                </div>
                <div class="muted" style="font-size:12px;margin:6px 0">مرحله فعلی: <?= e($wf['current_step']) ?> | نقش مسئول: <?= e($wf['assigned_role']) ?></div>

                <div style="background:var(--surface-2);border-radius:10px;padding:8px 12px;font-size:12px;margin-bottom:10px">
                    <?php foreach ($hist as $h): ?>
                        <div>• <strong><?= e($h['step']) ?></strong> — توسط <?= e($h['by']) ?> (<?= e($h['time']) ?>)</div>
                    <?php endforeach; ?>
                </div>

                <?php
                $wfRoles = array_values(array_filter(array_map('trim', preg_split('/[,+]/', (string)$wf['assigned_role']) ?: [])));
                $canApproveWorkflow = in_array((string)Auth::role(), $wfRoles, true);
                ?>
                <?php if ($wf['status'] === 'running' && $canApproveWorkflow): ?>
                    <form method="post" action="<?= e(url('bpms')) ?>" style="display:flex;gap:8px;flex-wrap:wrap">
                        <?= csrf_field() ?>
                        <input type="hidden" name="workflow_id" value="<?= (int)$wf['id'] ?>">
                        <input type="hidden" name="action" value="transition_workflow">
                        <input type="text" name="note" placeholder="هامش / دستور اداری..." style="max-width:300px">
                        <button type="submit" name="decision" value="approve" class="btn btn-primary btn-sm">✅ تأیید و ابلاغ</button>
                        <button type="submit" name="decision" value="reject" class="btn btn-danger btn-sm">↩️ رد / اصلاح</button>
                    </form>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="card">
        <div class="card-header"><div class="card-title">➕ آغاز نمونه فرایند جدید در BPMS</div></div>
        <form method="post" action="<?= e(url('bpms')) ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="start_workflow">
            <div class="form-group">
                <label>قالب فرایند:</label>
                <select name="process_key">
                    <option value="COURSE_APPROVAL">تصویب دوره آموزشی جدید</option>
                    <option value="CONTRACT_DISCOUNT">مجوز تخفیف ویژه قرارداد سازمانی</option>
                    <option value="EQUIPMENT_PURCHASE">درخواست تجهیز کارگاه آموزشی</option>
                </select>
            </div>
            <input type="hidden" name="process_title" value="فرایند مصوب واحد آموزش">
            <div class="form-group">
                <label>موضوع پرونده:</label>
                <input type="text" name="subject_label" required placeholder="مثلاً: تصویب دوره حسابداری مالی">
            </div>
            <div class="form-grid">
                <div class="form-group">
                    <label>نقش تأییدکننده:</label>
                    <select name="assigned_role">
                        <option value="super_admin">مدیرکل آموزش</option>
                        <option value="finance_manager">مدیر مالی</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>مهلت پاسخ SLA (ساعت):</label>
                    <input type="number" name="sla_hours" value="24">
                </div>
            </div>
            <div class="form-grid">
                <div class="form-group"><label>مبلغ پرونده (ریال، برای شرط amount_rial):</label><input type="number" min="0" name="amount_rial"></div>
                <div class="form-group"><label>درصد تخفیف (برای شرط discount_pct):</label><input type="number" min="0" max="100" step="0.1" name="discount_pct"></div>
                <div class="form-group"><label>دستهٔ بودجه (برای شرط budget_category):</label><input type="text" name="budget_category" value="IT_LAB" pattern="[A-Z0-9_]+"></div>
            </div>
            <button type="submit" class="btn btn-primary" style="width:100%">ارجاع به کارتابل</button>
        </form>
    </div>
</div>

<!-- CONDITIONAL & PARALLEL ROUTING RULES ENGINE -->
<div class="card">
    <div class="card-header">
        <div class="card-title">🔀 قواعد مسیریابی شرطی و موازی موتور BPMS (Conditional &amp; Parallel Routing Rules)</div>
        <span class="badge badge-gold">ارزیابی خودکار سقف مبلغ، درصد تخفیف و تأیید هم‌زمان</span>
    </div>
    <div class="table-wrap" style="margin-bottom:16px">
        <table>
            <thead>
            <tr>
                <th>عنوان قاعده مسیریابی</th>
                <th>کد فرایند</th>
                <th>شرط منطقی (Expression)</th>
                <th>الگوی مسیر</th>
                <th>نقش‌های مقصد</th>
                <th>مهلت SLA</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($routingRules as $rr): ?>
                <tr>
                    <td><strong><?= e($rr['rule_name']) ?></strong></td>
                    <td><code><?= e($rr['process_key']) ?></code></td>
                    <td dir="ltr" style="text-align:left"><code><?= e($rr['condition_expr']) ?></code></td>
                    <td>
                        <span class="badge <?= $rr['routing_mode'] === 'parallel' ? 'badge-purple' : 'badge-info' ?>">
                            <?= $rr['routing_mode'] === 'parallel' ? 'موازی هم‌زمان (Parallel)' : 'شرطی (Conditional)' ?>
                        </span>
                    </td>
                    <td><?= e($rr['target_roles']) ?></td>
                    <td><?= fa($rr['sla_hours']) ?> ساعت</td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <form method="post" action="<?= e(url('bpms')) ?>" class="form-grid" style="align-items:end">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="add_routing_rule">
        <div class="form-group">
            <label>عنوان قاعده جدید:</label>
            <input type="text" name="rule_name" value="تأیید موازی قرارداد بالای ۲ میلیارد ریال" required>
        </div>
        <div class="form-group">
            <label>فرایند:</label>
            <select name="process_key">
                <option value="CONTRACT_DISCOUNT">CONTRACT_DISCOUNT</option>
                <option value="COURSE_APPROVAL">COURSE_APPROVAL</option>
                <option value="EQUIPMENT_PURCHASE">EQUIPMENT_PURCHASE</option>
            </select>
        </div>
        <div class="form-group">
            <label>شرط منطقی:</label>
            <input type="text" name="condition_expr" value="amount_rial > 2000000000" dir="ltr" required>
        </div>
        <div class="form-group">
            <label>نوع مسیر:</label>
            <select name="routing_mode">
                <option value="parallel">موازی (Parallel)</option>
                <option value="conditional">شرطی (Conditional)</option>
            </select>
        </div>
        <input type="hidden" name="target_roles" value="finance_manager + super_admin">
        <input type="hidden" name="sla_hours" value="24">
        <button type="submit" class="btn btn-gold">➕ ثبت قاعده مسیریابی</button>
    </form>
</div>

<!-- v13.0 BPMS PROCESS MINING & BOTTLENECK DETECTOR -->
<div class="card" style="margin-top:18px;border:1.5px solid rgba(201,146,39,0.38)">
    <div class="card-header" style="align-items:center">
        <div>
            <div class="card-title">معدن‌کاوی هوشمند فرایندها، کشف گلوگاه توقف پرونده و رفع خودکار تأخیر SLA (AI Process Mining)</div>
            <div class="muted" style="font-size:12px">اندازه‌گیری زنده میانگین زمان توقف پرونده‌ها روی میز هر واحد سازمانی و فعال‌سازی مسیر موازی خودکار</div>
        </div>
        <span class="badge badge-gold">Process Mining Radar</span>
    </div>
    <div class="table-wrap">
        <table>
            <thead><tr><th>کد ایستگاه</th><th>واحد سازمانی / ایستگاه امضا</th><th>پرونده جاری</th><th>میانگین توقف</th><th>سقف SLA</th><th>وضعیت گلوگاه</th><th>اقدام خودکار</th></tr></thead>
            <tbody>
            <?php foreach (($miningStages ?? []) as $ms): ?>
                <tr>
                    <td><code><?= e($ms['stage_code']) ?></code></td>
                    <td><strong><?= e($ms['department_stage']) ?></strong></td>
                    <td><?= fa($ms['active_cases_count']) ?> پرونده</td>
                    <td><strong><?= fa((string)$ms['avg_dwell_hours']) ?> ساعت</strong></td>
                    <td><?= fa($ms['sla_target_hours']) ?> ساعت</td>
                    <td>
                        <span class="badge <?= (float)$ms['avg_dwell_hours'] > (float)$ms['sla_target_hours'] ? 'badge-danger' : 'badge-success' ?>">
                            <?= e($ms['bottleneck_severity']) ?>
                        </span>
                    </td>
                    <td>
                        <form method="post" action="<?= e(url('bpms')) ?>" style="display:inline">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="bypass_bottleneck">
                            <input type="hidden" name="stage_id" value="<?= (int)$ms['id'] ?>">
                            <button type="submit" class="btn btn-primary btn-sm">رفع خودکار گلوگاه</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
