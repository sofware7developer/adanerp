<?php use App\Core\Auth; ?>
<div class="hero-banner">
    <div>
        <span class="badge badge-gold">پیوند صنعت، دانشگاه و اتاق (پویش)</span>
        <h1>کارآموزی مهارتی و پروژه‌های صنعتی با ارزیابی Rubric</h1>
        <p>معرفی کارآموزان به واحدهای صنعتی و صادراتی دانش‌پذیر آدان، تحویل مرحله‌ای گزارش‌ها و ارزیابی چندمعیاره استاندارد (Rubric).</p>
    </div>
</div>

<?php foreach ($items as $it): ?>
    <?php $rubric = json_decode((string)$it['rubric_score_json'], true) ?: []; ?>
    <div class="card">
        <div class="card-header">
            <div class="card-title">🏭 <?= e($it['program_title']) ?> — سازمان میزبان: <?= e($it['host_org']) ?></div>
            <span class="badge badge-success">امتیاز کل روبریک: <?= fa($it['total_score']) ?> از ۱۰۰</span>
        </div>
        <p><strong>کارآموز / تیم:</strong> <?= e($it['intern_name']) ?> (<?= e($it['team_name']) ?>) | <strong>فاز فعلی:</strong> <?= e($it['milestone_stage']) ?> | فایل: <code><?= e($it['deliverable_file']) ?></code></p>

        <div class="grid grid-4" style="margin:12px 0">
            <?php foreach ($rubric as $rKey => $rVal): ?>
                <div class="stat-card" style="padding:10px"><div><div class="stat-label"><?= e($rKey) ?></div><strong><?= fa($rVal) ?> / ۲۵</strong></div></div>
            <?php endforeach; ?>
        </div>

        <div class="grid grid-2">
            <form method="post" action="<?= e(url('internships')) ?>">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="submit_milestone">
                <input type="hidden" name="internship_id" value="<?= (int)$it['id'] ?>">
                <div class="form-grid">
                    <input type="text" name="milestone_stage" value="<?= e($it['milestone_stage']) ?>">
                    <input type="text" name="deliverable_file" value="<?= e($it['deliverable_file'] ?? 'phase_report.pdf') ?>">
                </div>
                <button type="submit" class="btn btn-outline btn-sm" style="margin-top:8px">ثبت تحویل مرحله‌ای</button>
            </form>

            <?php if (Auth::hasRole(['super_admin', 'training_expert'])): ?>
                <form method="post" action="<?= e(url('internships')) ?>">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="save_rubric">
                    <input type="hidden" name="internship_id" value="<?= (int)$it['id'] ?>">
                    <div class="form-grid" style="grid-template-columns:repeat(4,1fr)">
                        <input type="number" name="r1" value="24" max="25" title="تحلیل بازار">
                        <input type="number" name="r2" value="23" max="25" title="قوانین گمرکی">
                        <input type="number" name="r3" value="23" max="25" title="مستندسازی">
                        <input type="number" name="r4" value="22" max="25" title="نظم تیمی">
                    </div>
                    <button type="submit" class="btn btn-primary btn-sm" style="margin-top:8px">ثبت ارزیابی Rubric</button>
                </form>
            <?php endif; ?>
        </div>
    </div>
<?php endforeach; ?>

<!-- v15.0 POOYESH TAX CREDIT ARTICLE 11 CALCULATOR -->
<?php if (Auth::hasRole(['super_admin', 'training_expert'])): ?>
<div class="card" style="margin-top:18px;border:1.5px solid rgba(15,118,110,0.35)">
    <div class="card-header">
        <div>
            <div class="card-title">🧾 برآورد داخلی هزینهٔ طرح پویش</div>
            <div class="muted" style="font-size:12px">این محاسبه صرفاً برآورد محلی است؛ تأیید واجدشرایط‌بودن یا صدور اعتبار رسمی مالیاتی انجام نمی‌شود.</div>
        </div>
        <span class="badge badge-warning">غیررسمی؛ نیازمند تأیید مالیاتی</span>
    </div>
    <form method="post" action="<?= e(url('internships')) ?>" class="grid grid-4" style="gap:10px;align-items:end;margin-bottom:14px">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="calc_pooyesh_tax">
        <div><label>نام واحد صنعتی میزبان:</label><input type="text" name="host_company" value="مجتمع ماشین‌سازی دقیق استان" required></div>
        <div><label>نام دانشجوی طرح پویش:</label><input type="text" name="intern_fullname" value="مهندس کیمیا نادری" required></div>
        <div><label>مدت دوره (ماه):</label><input type="number" name="duration_months" value="4"></div>
        <div><input type="hidden" name="monthly_stipend_rial" value="105000000"><button type="submit" class="btn btn-gold" style="width:100%">ثبت برآورد محلی</button></div>
    </form>
    <div class="table-wrap">
        <table>
            <thead><tr><th>کد برآورد</th><th>واحد صنعتی میزبان</th><th>کارآموز طرح پویش</th><th>مدت</th><th>جمع حق‌الزحمه واردشده</th><th>مبلغ محاسباتی غیررسمی</th><th>یادداشت مبنا</th></tr></thead>
            <tbody>
            <?php foreach (($taxClaims ?? []) as $tc): ?>
                <tr>
                    <td><code><?= e($tc['claim_code']) ?></code></td>
                    <td><strong><?= e($tc['host_company']) ?></strong></td>
                    <td><?= e($tc['intern_fullname']) ?></td>
                    <td><?= fa($tc['duration_months']) ?> ماه</td>
                    <td><?= rial((int)$tc['total_paid_rial']) ?></td>
                    <td><span class="badge badge-success"><?= rial((int)$tc['tax_credit_approved_rial']) ?></span></td>
                    <td style="font-size:11.5px"><?= e($tc['statutory_clause']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

