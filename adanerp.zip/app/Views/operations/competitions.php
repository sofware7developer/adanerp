<?php use App\Core\Auth; ?>
<div class="hero-banner">
    <div>
        <span class="badge badge-gold">لیگ مذاکرات و شبیه‌سازهای تجاری</span>
        <h1>مسابقات مهارتی، راندها، معیارهای وزن‌دار و داوری انسانی</h1>
        <p>جدول رده‌بندی تیم‌های شرکت‌کننده در لیگ مذاکرات تجاری مؤسسه آموزشی آدان و ثبت امتیاز هیئت داوران.</p>
    </div>
</div>

<div class="alert alert-info">
    <div>
        <strong>مرز معماری سامانه مسابقات:</strong> مدیریت راندهای مسابقه، تیم‌ها و محاسبه امتیازات داوری انسانی با معیارهای وزن‌دار کامل است؛ اما موتور بازی چندنفرهٔ بلادرنگ (Real-time Multiplayer WebSocket Engine) یک سامانه مستقل تخصصی محسوب می‌شود.
    </div>
</div>

<div class="card">
    <div class="card-header"><div class="card-title">🏆 جدول رده‌بندی (Leaderboard) و پنل داوری انسانی</div></div>
    <?php foreach ($teams as $idx => $tm): ?>
        <div style="border:1px solid var(--border);border-radius:14px;padding:15px;margin-bottom:12px">
            <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap">
                <div>
                    <span class="badge badge-gold">رتبه <?= fa($idx + 1) ?></span>
                    <strong style="margin-right:6px"><?= e($tm['team_name']) ?></strong> — <?= e($tm['title']) ?>
                </div>
                <span class="badge badge-success">امتیاز نهایی داوران: <?= fa($tm['jury_score']) ?></span>
            </div>
            <div class="muted" style="font-size:12px;margin:6px 0">راند فعلی: <?= e($tm['current_round']) ?> | نظر داور: <?= e($tm['judge_comment']) ?></div>

            <?php if (Auth::hasRole(['super_admin', 'training_expert'])): ?>
                <form method="post" action="<?= e(url('competitions')) ?>" class="form-grid" style="margin-top:8px;align-items:end">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="score_team">
                    <input type="hidden" name="comp_id" value="<?= (int)$tm['id'] ?>">
                    <input type="text" name="current_round" value="<?= e($tm['current_round']) ?>">
                    <input type="number" step="0.1" name="jury_score" value="<?= e($tm['jury_score']) ?>">
                    <input type="text" name="judge_comment" value="<?= e($tm['judge_comment']) ?>">
                    <button type="submit" class="btn btn-primary btn-sm">ثبت رأی داور</button>
                </form>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
</div>

<!-- v15.0 MULTI-QUARTER EXPORT STRATEGY BUSINESS SIMULATOR -->
<div class="card" style="margin-top:18px;border:1.5px solid rgba(201,146,39,0.4)">
    <div class="card-header">
        <div>
            <div class="card-title">📈 شبیه‌ساز فصلی رقابت صنعتی و صادراتی تیم‌ها (Turn-Based Export EBITDA &amp; Elo Simulator)</div>
            <div class="muted" style="font-size:12px">محاسبه نوبتی سود عملیاتی دلاری (EBITDA) و رتبه Elo تیم‌ها بر اساس نرخ‌گذاری صادراتی، پوشش ریسک ارزی و بودجه R&amp;D</div>
        </div>
        <span class="badge badge-gold">داور الگوریتمی فصلی</span>
    </div>
    <form method="post" action="<?= e(url('competitions')) ?>" class="grid grid-4" style="gap:10px;align-items:end;margin-bottom:14px">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="run_bizsim">
        <div><label>نام تیم شرکت‌کننده:</label><input type="text" name="team_name" value="تیم بازرگانی پیشگامان صنعت" required></div>
        <div><label>قیمت هر تن صادراتی (USD):</label><input type="number" name="export_pricing_usd" value="1280"></div>
        <div><label>پوشش سلف ارزی (%):</label><input type="number" name="fx_hedge_ratio_pct" value="72"></div>
        <div><input type="hidden" name="rnd_investment_pct" value="14"><button type="submit" class="btn btn-gold" style="width:100%">اجرای راند فصلی شبیه‌ساز</button></div>
    </form>
    <div class="table-wrap">
        <table>
            <thead><tr><th>کد راند</th><th>تیم صنعتی</th><th>فصل</th><th>پوشش ارزی</th><th>سود عملیاتی EBITDA</th><th>رتبه Elo</th><th>تحلیل داور هوشمند</th></tr></thead>
            <tbody>
            <?php foreach (($simRounds ?? []) as $sr): ?>
                <tr>
                    <td><code><?= e($sr['round_code']) ?></code></td>
                    <td><strong><?= e($sr['team_name']) ?></strong></td>
                    <td><?= e($sr['quarter_label']) ?></td>
                    <td><?= fa($sr['fx_hedge_ratio_pct']) ?>٪</td>
                    <td><strong>$<?= number_format((float)$sr['simulated_ebitda_usd']) ?></strong></td>
                    <td><span class="badge badge-success">Elo <?= fa($sr['elo_rating']) ?></span></td>
                    <td style="font-size:12px"><?= e($sr['ai_referee_note']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

