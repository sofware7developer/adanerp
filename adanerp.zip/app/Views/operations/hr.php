<?php use App\Core\Auth; ?>
<div class="hero-banner">
    <div>
        <span class="badge badge-gold">سرمایه انسانی داخلی واحد آموزش</span>
        <h1>منابع انسانی داخلی: وظایف، ارزیابی دوره‌ای، جانشینی و مرخصی</h1>
        <p>پرونده پرسنلی کارشناسان آموزش، ارزیابی KPI دوره‌ای، ماتریس جانشین‌پروری، درخواست مرخصی و خلاصه کارکرد.</p>
    </div>
</div>

<div class="alert alert-warning">
    <div>
        <strong>حدود کاربری ماژول HR:</strong> این ماژول ویژه مدیریت داخلی تیم واحد آموزش طراحی شده است و جایگزین نرم‌افزار رسمی حقوق و دستمزد قانونی (لیست بیمه تأمین اجتماعی و دیسکت مالیات حقوق کشور) نیست.
    </div>
</div>

<div class="grid grid-sidebar">
    <div class="card">
        <div class="card-header"><div class="card-title">🗂️ پرونده‌ها، مرخصی‌ها و ارزیابی‌های کارکنان</div></div>
        <div class="table-wrap">
            <table>
                <thead><tr><th>کارمند</th><th>نوع پرونده</th><th>عنوان و شرح</th><th>امتیاز KPI</th><th>وضعیت</th></tr></thead>
                <tbody>
                <?php foreach ($records as $rc): ?>
                    <tr>
                        <td><strong><?= e($rc['full_name']) ?></strong><div class="muted" style="font-size:11px"><?= e($rc['job_title']) ?></div></td>
                        <td><span class="badge badge-info"><?= e($rc['record_type']) ?></span></td>
                        <td><strong><?= e($rc['title']) ?></strong><div class="muted" style="font-size:12px"><?= e($rc['details']) ?></div></td>
                        <td><?= $rc['kpi_score'] ? fa($rc['kpi_score']) . ' / ۱۰۰' : '—' ?></td>
                        <td>
                            <span class="badge <?= $rc['status'] === 'approved' ? 'badge-success' : 'badge-warning' ?>"><?= e($rc['status']) ?></span>
                            <?php if ($rc['status'] === 'open' && Auth::hasRole(['super_admin'])): ?>
                                <form method="post" action="<?= e(url('hr')) ?>" style="margin-top:4px">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action" value="approve_hr">
                                    <input type="hidden" name="hr_id" value="<?= (int)$rc['id'] ?>">
                                    <button type="submit" class="btn btn-primary btn-sm">تأیید مدیر</button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card">
        <div class="card-header"><div class="card-title">➕ ثبت درخواست / رکورد جدید منابع انسانی</div></div>
        <form method="post" action="<?= e(url('hr')) ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="create_hr_record">
            <div class="form-group">
                <label>نوع ثبت:</label>
                <select name="record_type">
                    <option value="leave_request">درخواست مرخصی</option>
                    <option value="task">وظیفه اجرایی</option>
                    <option value="periodic_eval">ارزیابی عملکرد دوره‌ای</option>
                    <option value="succession">برنامه جانشین‌پروری</option>
                    <option value="payslip_note">خلاصه کارکرد / اضافه کار داخلی</option>
                </select>
            </div>
            <div class="form-group">
                <label>عنوان:</label>
                <input type="text" name="title" required placeholder="مثلاً: درخواست مرخصی ساعتی چهارشنبه">
            </div>
            <div class="form-group">
                <label>جزئیات:</label>
                <textarea name="details" rows="2"></textarea>
            </div>
            <div class="form-group">
                <label>امتیاز KPI (اختیاری ۰ تا ۱۰۰):</label>
                <input type="number" name="kpi_score" placeholder="92">
            </div>
            <button type="submit" class="btn btn-primary" style="width:100%">ثبت در پرونده پرسنلی</button>
        </form>
    </div>
</div>
