<?php use App\Core\QrSvg; ?>
<div class="card" style="max-width:900px;margin:0 auto">
    <?php if (!$profile || (int)$profile['passport_is_public'] !== 1): ?>
        <div class="alert alert-warning">
            گذرنامه استعداد این کاربر خصوصی تنظیم شده است یا در دسترس عموم قرار ندارد.
        </div>
    <?php else: ?>
        <div class="hero-banner">
            <div>
                <span class="badge badge-gold">گذرنامه دیجیتال مهارت و استعداد (پروفایل عمومی اختیاری)</span>
                <h1><?= e($profile['full_name']) ?></h1>
                <p><?= e($profile['job_title']) ?> | سازمان: <?= e($profile['org_name'] ?? 'آموزشگاه حسابداری آدان') ?></p>
            </div>
            <?= QrSvg::render('passport:' . $profile['public_passport_slug'], 102) ?>
        </div>

        <div class="grid grid-2">
            <div class="card">
                <div class="card-header"><div class="card-title">🎖️ نشان‌های مهارتی ثبت‌شده در آدان</div></div>
                <?php foreach ($badges as $b): ?>
                    <div class="stat-card" style="margin-bottom:10px">
                        <div>
                            <div style="font-weight:800"><?= e($b['badge_title']) ?></div>
                            <div class="muted" style="font-size:12px">حوزه مهارت: <?= e($b['skill_domain']) ?> | صدور: <?= e($b['issued_shamsi']) ?></div>
                        </div>
                        <span class="badge badge-gold"><?= e($b['badge_code']) ?></span>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="card">
                <div class="card-header"><div class="card-title">📜 گواهی‌نامه‌های ثبت‌شده در سوابق آموزشی</div></div>
                <?php foreach ($certs as $c): ?>
                    <div class="stat-card" style="margin-bottom:10px">
                        <div>
                            <div style="font-weight:800"><?= e($c['course_title']) ?></div>
                            <div class="muted" style="font-size:12px">درجه: <?= e($c['grade_label']) ?> | <?= fa($c['hours_completed']) ?> ساعت</div>
                        </div>
                        <a class="btn btn-outline btn-sm" href="<?= e(url('verify', ['code' => $c['serial_code']])) ?>">استعلام QR</a>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="card" style="margin-top:16px;border:1.5px solid rgba(15,118,110,0.35)">
            <div class="card-header">
                <div>
                    <div class="card-title">پیش‌نویس محلی گذرنامه مهارت و چکیده‌های SHA-256</div>
                    <div class="muted" style="font-size:12px">این داده‌ها امضای رمزنگاری‌شده ندارند و استاندارد W3C یا سرویس اعتبارسنجی بیرونی به آن‌ها متصل نیست.</div>
                </div>
                <a class="btn btn-outline btn-sm" target="_blank" href="<?= e(url('passport', ['u' => $profile['public_passport_slug'] ?: $profile['username'], 'openbadge' => 1])) ?>">دریافت پیش‌نویس محلی JSON (بدون امضا)</a>
            </div>
            <div class="table-wrap">
                <table>
                    <thead><tr><th>بلوک محلی</th><th>کد گواهی / نشان</th><th>وضعیت</th><th>چکیده SHA-256 محلی</th><th>تاریخ ثبت</th></tr></thead>
                    <tbody>
                    <?php foreach (($hashBlocks ?? []) as $hb): ?>
                        <tr>
                            <td><strong>#<?= fa($hb['block_height']) ?></strong></td>
                            <td><code><?= e($hb['cert_or_badge_code']) ?></code></td>
                            <td><span class="badge badge-warning">محلی؛ استاندارد یا امضا تأیید نشده</span></td>
                            <td dir="ltr"><code><?= e(substr($hb['block_sha256_hash'], 0, 24)) ?>...</code></td>
                            <td><?= e($hb['sealed_shamsi']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (empty($hashBlocks)): ?>
                        <tr><td colspan="5" class="muted">برای این پروفایل چکیدهٔ محلی ثبت نشده است.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>
</div>
