<?php use App\Core\QrSvg; ?>
<div class="card" style="max-width:860px;margin:0 auto">
    <div class="card-header">
        <div class="card-title">🔎 بررسی وضعیت گواهی‌نامه‌های صادرشده توسط آموزشگاه آدان</div>
        <button type="button" onclick="window.print()" class="btn btn-outline btn-sm no-print">🖨️ چاپ اطلاعات گواهی</button>
    </div>

    <form method="get" action="<?= e(url('verify')) ?>" class="no-print" style="display:flex;gap:10px;margin-bottom:20px;flex-wrap:wrap">
        <input type="text" name="code" value="<?= e($code) ?>" style="flex:1" placeholder="شماره سریال گواهی">
        <button type="submit" class="btn btn-primary">بررسی وضعیت گواهی</button>
    </form>

    <?php if (!$cert): ?>
        <div class="alert alert-danger">گواهی‌نامه‌ای با این شماره سریال در سامانهٔ آموزشگاه آدان ثبت نشده است.</div>
    <?php elseif ($cert['status'] === 'revoked'): ?>
        <div class="alert alert-danger">
            <div>
                <strong>❌ وضعیت ثبت‌شده: لغوشده</strong> گواهی شماره <code><?= e($cert['serial_code']) ?></code> متعلق به «<?= e($cert['full_name']) ?>» در سوابق آموزشگاه لغو شده است.<br>
                علت ابطال ثبت‌شده: <?= e($cert['revoked_reason']) ?>
            </div>
        </div>
    <?php else: ?>
        <div class="cert-frame">
            <div style="display:flex;justify-content:space-between;align-items:center;gap:16px;flex-wrap:wrap">
                <div>
                    <span class="badge badge-success" style="font-size:13px;margin-bottom:8px">✅ این شماره در سوابق آدان با وضعیت معتبر ثبت شده است</span>
                    <h2 style="font-size:21px;margin-bottom:8px"><?= e($chamberName) ?></h2>
                    <p style="font-size:14.5px;line-height:2">
                        بدین‌وسیله گواهی می‌شود جناب آقای / سرکار خانم <strong><?= e($cert['full_name']) ?></strong>
                        دوره تخصصی <strong>«<?= e($cert['course_title']) ?>»</strong> (کد استاندارد: <?= e($cert['course_code']) ?>)
                        به مدت <strong><?= fa($cert['hours_completed']) ?> ساعت آموزشی</strong> را در تاریخ <strong><?= e($cert['issue_shamsi']) ?></strong>
                        با درجه ارزشیابی <strong><?= e($cert['grade_label']) ?></strong> با موفقیت به پایان رسانده است.
                    </p>
                    <div style="margin-top:12px;font-size:13px">
                        شماره سریال ثبت یکتا: <strong><?= e($cert['serial_code']) ?></strong>
                    </div>
                    <div dir="ltr" style="margin-top:14px;padding-top:12px;border-top:1px dashed #cbd5e1;font-family:system-ui,sans-serif;font-size:12.5px;color:#334155;text-align:left">
                        <strong>ADAN ACCOUNTING INSTITUTE — TRAINING RECORD</strong><br>
                        This record shows that <strong><?= e($cert['full_name']) ?></strong> completed <strong><?= (int)$cert['hours_completed'] ?> hours</strong> in course code <strong><?= e($cert['course_code']) ?></strong> with grade <strong><?= e($cert['grade_label']) ?></strong>. Serial ID: <code><?= e($cert['serial_code']) ?></code>
                    </div>
                </div>
                <div style="text-align:center">
                    <svg width="86" height="86" viewBox="0 0 100 100" style="display:block;margin:0 auto 8px" aria-label="مهر برجسته اتاق">
                        <circle cx="50" cy="50" r="46" fill="#fef3c7" stroke="#c99227" stroke-width="4"/>
                        <circle cx="50" cy="50" r="37" fill="none" stroke="#b45309" stroke-dasharray="3 2" stroke-width="1.5"/>
                        <text x="50" y="47" text-anchor="middle" font-size="11" font-weight="bold" fill="#92400e">آموزشگاه آدان</text>
                        <text x="50" y="63" text-anchor="middle" font-size="9.5" font-weight="bold" fill="#92400e">ADAN</text>
                    </svg>
                    <?= QrSvg::render(url('verify', ['code' => $cert['serial_code']]), 128) ?>
                    <div style="font-size:11px;margin-top:4px">بررسی کد QR در سوابق آدان</div>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <div class="no-print" style="margin-top:22px;padding-top:18px;border-top:1.5px dashed var(--border)">
        <div style="font-weight:800;margin-bottom:8px">بررسی گروهی سریال‌ها در سوابق محلی آموزشگاه آدان</div>
        <form method="get" action="<?= e(url('verify')) ?>" style="display:flex;gap:8px;flex-wrap:wrap">
            <input type="hidden" name="code" value="<?= e($code) ?>">
            <input type="text" name="batch_codes" value="<?= e($batchCodes) ?>" dir="ltr" style="flex:1" placeholder="شماره‌های گواهی، جداشده با کاما">
            <button type="submit" class="btn btn-outline btn-sm">بررسی سوابق محلی</button>
        </form>
        <?php if (!empty($batchResults)): ?>
            <div class="table-wrap" style="margin-top:12px">
                <table>
                    <thead><tr><th>سریال</th><th>وضعیت ثبت‌شده</th><th>دارنده</th><th>دوره</th><th>چکیدهٔ محلی (در صورت وجود)</th></tr></thead>
                    <tbody>
                    <?php foreach ($batchResults as $br): ?>
                        <tr>
                            <td dir="ltr"><code><?= e($br['serial']) ?></code></td>
                            <td><span class="badge <?= $br['state'] === 'valid' ? 'badge-success' : 'badge-danger' ?>"><?= $br['state'] === 'valid' ? 'معتبر در سوابق آدان' : 'لغوشده / ناموجود' ?></span></td>
                            <td><?= e($br['holder']) ?></td>
                            <td><?= e($br['course']) ?></td>
                            <td dir="ltr"><code><?= $br['hash'] ? e(substr((string)$br['hash'], 0, 18)) . '...' : '-' ?></code></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>
