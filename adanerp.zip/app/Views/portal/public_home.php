<?php
$boxes = json_decode((string)($page['featured_boxes_json'] ?? '[]'), true) ?: [];
?>
<?php if (!empty($page['announcement_bar'])): ?>
    <div class="alert alert-warning" style="font-weight:700">
        <span>📢 <?= e($page['announcement_bar']) ?></span>
        <span class="badge badge-gold">نسخه فعال پورتال: v<?= fa($page['version_no'] ?? 1) ?></span>
    </div>
<?php endif; ?>

<div class="hero-banner">
    <div>
        <span class="badge badge-gold">ویترین عمومی پورتال (متصل به وب‌سایت‌ساز نسخه‌دار)</span>
        <h1><?= e($page['hero_title'] ?? 'آموزشگاه حسابداری آدان') ?></h1>
        <p><?= e($page['hero_subtitle'] ?? 'آموزش کاربردی حسابداری، مالیات، حقوق و دستمزد و نرم‌افزارهای مالی؛ از مبانی تا ورود مطمئن به بازار کار.') ?></p>
    </div>
    <div class="hero-actions">
        <a class="btn btn-gold" href="<?= e(url('login')) ?>">ورود دانشجویان</a>
        <a class="btn btn-outline" style="background:rgba(255,255,255,0.12);color:#fff" href="<?= e(url('verify')) ?>">استعلام گواهی QR</a>
    </div>
</div>

<!-- PUBLIC ADMISSIONS INTAKE -->
<div class="card" style="margin-bottom:18px;border:1.5px solid rgba(15,118,110,0.35)">
    <div class="card-header">
        <div class="card-title">درخواست پذیرش در دوره‌های آموزشگاه آدان</div>
        <span class="badge badge-gold">بررسی توسط واحد آموزش</span>
    </div>
    <form method="post" action="<?= e(url('public-home')) ?>" class="grid grid-4" style="gap:10px;align-items:end">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="submit_admission">
        <div><label>نام و نام خانوادگی:</label><input type="text" name="full_name" required></div>
        <div><label>شماره همراه:</label><input type="tel" name="mobile" required autocomplete="tel"></div>
        <div>
            <label>دوره مورد درخواست:</label>
            <select name="course_id" required>
                <?php foreach ($courses as $course): ?>
                    <option value="<?= (int)$course['id'] ?>"><?= e($course['title']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div><label>سابقه یا توضیح (اختیاری):</label><input type="text" name="prior_education"></div>
        <div><button type="submit" class="btn btn-primary" style="width:100%">ثبت درخواست پذیرش</button></div>
    </form>
</div>

<div class="grid grid-4">
    <?php foreach ($boxes as $bx): ?>
        <div class="stat-card">
            <div>
                <div class="stat-label">خدمت آموزشی آدان</div>
                <div style="font-weight:800;font-size:15px;margin-top:4px"><?= e($bx) ?></div>
            </div>
            <div class="stat-icon icon-teal">🏫</div>
        </div>
    <?php endforeach; ?>
</div>

<div class="card">
    <div class="card-header"><div class="card-title">📚 دوره‌های تخصصی در حال ثبت‌نام ترم جاری</div></div>
    <div class="grid grid-3">
        <?php foreach ($courses as $c): ?>
            <div style="border:1px solid var(--border);border-radius:14px;padding:16px">
                <span class="badge badge-info"><?= e($c['code']) ?> | <?= e($c['delivery_mode']) ?></span>
                <h3 style="font-size:15px;margin:8px 0"><?= e($c['title']) ?></h3>
                <p class="muted" style="font-size:12.5px;margin-bottom:10px"><?= e($c['summary']) ?></p>
                <div style="display:flex;justify-content:space-between;align-items:center">
                    <strong><?= rial($c['tuition_rial']) ?></strong>
                    <?php if ((int)$c['member_discount_pct'] > 0): ?>
                        <span class="badge badge-gold"><?= fa($c['member_discount_pct']) ?>٪ تخفیف ثبت‌نام</span>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<div class="card" style="margin-top:18px">
    <div class="card-header"><div class="card-title">مسیر یادگیری در آموزشگاه آدان</div></div>
    <div class="grid grid-3">
        <div><strong>۱. انتخاب دوره</strong><p class="muted">از دوره‌های حسابداری، مالیات، حقوق و دستمزد یا نرم‌افزارهای مالی انتخاب کنید.</p></div>
        <div><strong>۲. ثبت‌نام و شروع کلاس</strong><p class="muted">برای راهنمایی درباره پیش‌نیاز، زمان‌بندی و شهریه با آموزشگاه در تماس باشید.</p></div>
        <div><strong>۳. آزمون و دریافت گواهی</strong><p class="muted">پس از تکمیل دوره و ارزیابی، گواهی آموزشی خود را دریافت کنید.</p></div>
    </div>
</div>
