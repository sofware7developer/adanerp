<?php use App\Core\Auth; ?>
<div class="hero-banner">
    <div>
        <span class="badge badge-gold">پرونده آموزشی و میز خدمت دانشجوی آدان</span>
        <h1>پورتال دانشجویان آموزشگاه حسابداری آدان</h1>
        <p>مشاهده دوره‌های ثبت‌نام‌شده، گواهی‌نامه‌ها، برنامه کلاس، درخواست‌های پشتیبانی و پیگیری امور آموزشی.</p>
    </div>
    <div class="hero-actions">
        <a class="btn btn-gold" href="<?= e(url('lms')) ?>">ورود به کلاس درس (LMS)</a>
        <a class="btn btn-primary" href="<?= e(url('portal?export_ics=1')) ?>">📅 تقویم موبایل (.ics)</a>
        <?php if (Auth::hasRole(['org_rep', 'super_admin', 'training_expert'])): ?>
            <a class="btn btn-outline" style="background:rgba(255,255,255,0.16);color:#fff" href="<?= e(url('portal?export_org_report=1')) ?>">📊 گزارش دانشجویان (CSV)</a>
        <?php endif; ?>
    </div>
</div>

<?php $prtHud = \App\Services\LearnerBehaviorGamificationService::getUserHudSnapshot((int)(Auth::id() ?? 1), (string)(Auth::user()['full_name'] ?? 'فراگیر')); ?>
<div class="card" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;border:1.5px solid rgba(201,146,39,0.42)">
    <div>
        <span class="badge badge-gold">🏆 پیشرفت آموزشی و امتیازهای یادگیری</span>
        <strong style="margin-right:8px">سطح <?= fa($prtHud['level_num']) ?> (<?= e($prtHud['rank_title']) ?>): <?= fa(number_format($prtHud['xp_points'])) ?> امتیاز | پیوستگی: <?= fa($prtHud['streak_days']) ?> روز 🔥</strong>
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
        <a class="btn btn-outline btn-sm" href="<?= e(url('passport?u=mehrdad-sharifi&openbadge=1')) ?>" target="_blank">🏅 نشان Open Badges v3 (JSON-LD)</a>
    </div>
</div>

<?php if (!empty($orgContracts) && Auth::hasRole(['org_rep', 'super_admin', 'training_expert'])): ?>
    <div class="card">
        <div class="card-header">
            <div class="card-title">🏭 وضعیت سهمیه قراردادهای آموزشی سازمان شما (متصل به بخش تخصصی)</div>
            <span class="badge badge-info"><?= e($currentUser['org_name'] ?? 'آموزشگاه حسابداری آدان') ?></span>
        </div>
        <?php foreach ($orgContracts as $oc): ?>
            <?php $pct = min(100, (int)round(((int)$oc['seats_used'] / max(1, (int)$oc['seat_quota'])) * 100)); ?>
            <div style="margin-bottom:10px">
                <div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:5px">
                    <strong><?= e($oc['contract_no']) ?> — <?= e($oc['title']) ?></strong>
                    <span>مصرف سهمیه: <?= fa($oc['seats_used']) ?> از <?= fa($oc['seat_quota']) ?> نفر (<?= fa($pct) ?>٪)</span>
                </div>
                <div class="progress-track"><div class="progress-fill" style="width:<?= $pct ?>%"></div></div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<div class="grid grid-2">
    <!-- MY COURSES & CERTS -->
    <div class="card">
        <div class="card-header"><div class="card-title">🎓 دوره‌های ثبت‌نام‌شده و برنامه کلاسی</div></div>
        <?php foreach ($myCourses as $mc): ?>
            <div style="border-bottom:1px solid var(--border);padding:10px 0">
                <div style="display:flex;justify-content:space-between">
                    <strong><?= e($mc['course_title']) ?></strong>
                    <span class="badge badge-success">پیشرفت: <?= fa($mc['progress_pct']) ?>٪</span>
                </div>
                <div class="muted" style="font-size:12px">شروع: <?= e($mc['start_shamsi']) ?> | <?= e($mc['schedule_text']) ?></div>
            </div>
        <?php endforeach; ?>

        <div style="margin-top:16px">
            <strong>🎖️ گواهی‌نامه‌های صادرشده شما:</strong>
            <?php foreach ($myCerts as $ct): ?>
                <div style="margin-top:8px;display:flex;justify-content:space-between;align-items:center">
                    <span><?= e($ct['course_title']) ?> (<code><?= e($ct['serial_code']) ?></code>)</span>
                    <a class="btn btn-outline btn-sm" href="<?= e(url('verify', ['code' => $ct['serial_code']])) ?>">مشاهده QR</a>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <?php if (Auth::hasRole(['org_rep', 'super_admin', 'training_expert'])): ?>
    <div class="card">
        <div class="card-header">
            <div class="card-title">👥 مدیریت دانشجویان ثبت‌شده</div>
        </div>
        <form method="post" action="<?= e(url('portal')) ?>" style="margin-bottom:14px">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="add_org_employee">
            <div class="form-grid">
                <div class="form-group">
                    <label>نام و نام خانوادگی دانشجو:</label>
                    <input type="text" name="full_name" required placeholder="نام و نام خانوادگی">
                </div>
                <div class="form-group">
                    <label>وضعیت آموزشی:</label>
                    <input type="text" name="job_title" value="دانشجو">
                </div>
                <div class="form-group">
                    <label>گذرواژه اولیه (حداقل ۱۲ نویسه):</label>
                    <input type="password" name="password" minlength="12" autocomplete="new-password" required>
                </div>
            </div>
            <button type="submit" class="btn btn-primary btn-sm">افزودن دانشجو</button>
        </form>

        <div class="table-wrap">
            <table>
                <thead><tr><th>نام دانشجو</th><th>وضعیت آموزشی</th><th>تلفن</th></tr></thead>
                <tbody>
                <?php foreach ($orgEmployees as $emp): ?>
                    <tr>
                        <td><strong><?= e($emp['full_name']) ?></strong></td>
                        <td><?= e($emp['job_title']) ?></td>
                        <td><?= e($emp['mobile']) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- SUPPORT TICKETS -->
<div class="card">
    <div class="card-header"><div class="card-title">🎧 پشتیبانی آموزشی دانشجویان</div></div>
    <form method="post" action="<?= e(url('portal')) ?>" class="form-grid" style="align-items:end;margin-bottom:14px">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="create_ticket">
        <div class="form-group">
            <label>موضوع درخواست:</label>
            <input type="text" name="subject" required placeholder="درخواست صدور معرفی‌نامه یا اصلاح مشخصات">
        </div>
        <div class="form-group">
            <label>واحد مقصد:</label>
            <select name="department">
                <option value="آموزش و گواهی‌نامه‌ها">آموزش و گواهی‌نامه‌ها</option>
                <option value="قراردادهای سازمانی">قراردادهای سازمانی</option>
                <option value="امور مالی و اقساط">امور مالی و اقساط</option>
            </select>
        </div>
        <div class="form-group">
            <label>متن پیام:</label>
            <input type="text" name="message" required placeholder="شرح درخواست...">
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-primary">ارسال تیکت</button>
        </div>
    </form>

    <?php foreach ($tickets as $tk): ?>
        <div class="alert alert-info">
            <div>
                <strong><?= e($tk['subject']) ?></strong> — <?= e($tk['message']) ?>
                <?php if (!empty($tk['reply_text'])): ?>
                    <div style="color:var(--primary);margin-top:4px">پاسخ کارشناس: <?= e($tk['reply_text']) ?></div>
                <?php endif; ?>
            </div>
            <span class="badge badge-success"><?= e($tk['status']) ?></span>
        </div>
    <?php endforeach; ?>
</div>
