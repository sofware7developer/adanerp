<?php use App\Core\Auth; ?>
<div class="hero-banner">
    <div>
        <span class="badge badge-gold">سرمایه علمی و اساتید اتاق</span>
        <h1>بانک مدرسان، موتور تطبیق با دوره، صلاحیت و حق‌التدریس</h1>
        <p>پرونده و سوابق تدریس، نرخ ساعتی، امتیاز ارزیابی فراگیران، اعلام دسترس‌پذیری، تأیید کمیته صلاحیت و گردش پرداخت حق‌التدریس.</p>
    </div>
</div>

<div class="grid grid-2">
    <?php foreach ($instructors as $ins): ?>
        <div class="card">
            <div class="card-header">
                <div class="card-title">👨‍🏫 <?= e($ins['full_name']) ?> — <?= e($ins['degree']) ?></div>
                <div style="display:flex;gap:6px;align-items:center">
                    <a class="btn btn-outline btn-sm" href="<?= e(url('instructor-contract-print?id=' . (int)$ins['id'])) ?>" target="_blank">📄 قرارداد و گواهی ماده ۸۶</a>
                    <span class="badge badge-success">امتیاز: <?= fa($ins['avg_rating']) ?> از ۵</span>
                </div>
            </div>
            <p style="font-size:13px;margin-bottom:10px"><?= e($ins['bio']) ?></p>
            <form method="post" action="<?= e(url('instructors')) ?>">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="update_profile">
                <input type="hidden" name="instructor_user_id" value="<?= (int)$ins['user_id'] ?>">
                <div class="form-group">
                    <label>حوزه‌های تخصصی و کلیدواژه‌های تدریس:</label>
                    <input type="text" name="specialties" value="<?= e($ins['specialties']) ?>">
                </div>
                <div class="form-grid">
                    <div class="form-group">
                        <label>نرخ ساعتی حق‌التدریس (ریال):</label>
                        <input type="number" name="hourly_rate_rial" value="<?= (int)$ins['hourly_rate_rial'] ?>">
                    </div>
                    <div class="form-group">
                        <label>وضعیت صلاحیت کمیته علمی:</label>
                        <select name="qualification_status">
                            <option value="committee_approved" <?= $ins['qualification_status'] === 'committee_approved' ? 'selected' : '' ?>>تأیید رسمی کمیته علمی</option>
                            <option value="conditional" <?= $ins['qualification_status'] === 'conditional' ? 'selected' : '' ?>>مشروط</option>
                            <option value="pending" <?= $ins['qualification_status'] === 'pending' ? 'selected' : '' ?>>در حال بررسی</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label>پنجره زمانی دسترس‌پذیری اعلام‌شده:</label>
                    <input type="text" name="availability_slots" value="<?= e($ins['availability_slots']) ?>">
                </div>
                <button type="submit" class="btn btn-primary btn-sm">ذخیره پرونده و دسترس‌پذیری مدرس</button>
            </form>
        </div>
    <?php endforeach; ?>

    <!-- INSTRUCTOR MATCHING ENGINE -->
    <div class="card">
        <div class="card-header"><div class="card-title">🎯 موتور تطبیق هوشمند مدرس با دوره‌های کاتالوگ</div></div>
        <div class="table-wrap">
            <table>
                <thead>
                <tr>
                    <th>دوره آموزشی</th>
                    <th>مدرس پیشنهادی</th>
                    <th>شاخص تطبیق</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($matches as $m): ?>
                    <tr>
                        <td><strong>[<?= e($m['code']) ?>]</strong> <?= e($m['course']) ?></td>
                        <td><?= e($m['instructor']) ?><div class="muted" style="font-size:11px"><?= e($m['slots']) ?></div></td>
                        <td><span class="badge badge-success"><?= fa($m['score']) ?>٪ تطابق</span></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- PAYOUT WORKFLOW -->
<div class="card">
    <div class="card-header"><div class="card-title">💳 گردش محاسبه و تسویه حق‌التدریس مدرسان</div></div>
    <?php if (Auth::hasRole(['super_admin', 'finance_manager', 'training_expert'])): ?>
        <form method="post" action="<?= e(url('instructors')) ?>" class="form-grid" style="align-items:end;margin-bottom:16px">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="create_payout">
            <input type="hidden" name="instructor_user_id" value="<?= (int)($instructors[0]['user_id'] ?? 5) ?>">
            <div class="form-group">
                <label>اجرای دوره:</label>
                <select name="run_id">
                    <?php foreach ($runs as $r): ?>
                        <option value="<?= (int)$r['id'] ?>"><?= e($r['run_code']) ?> — <?= e($r['title']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>ساعات تدریس:</label>
                <input type="number" name="hours_taught" value="16" min="1">
            </div>
            <div class="form-group">
                <label>نرخ ساعتی (ریال):</label>
                <input type="number" name="hourly_rate" value="15000000">
            </div>
            <div class="form-group">
                <label>وضعیت مالی:</label>
                <select name="status">
                    <option value="verified">تأیید کارکرد آموزش</option>
                    <option value="approved_finance">تأیید مدیر مالی</option>
                    <option value="paid">پرداخت نهایی شده</option>
                </select>
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary">ثبت سند حق‌التدریس</button>
            </div>
        </form>
    <?php endif; ?>

    <div class="table-wrap">
        <table>
            <thead>
            <tr>
                <th>مدرس</th>
                <th>اجرا</th>
                <th>ساعت</th>
                <th>ناخالص</th>
                <th>کسور مالیاتی (۱۰٪)</th>
                <th>خالص پرداختی</th>
                <th>وضعیت / شناسه</th>
            </tr>
            </thead>
            <tbody>
                <?php foreach ($payouts as $p): ?>
                <tr>
                    <td><strong><?= e($p['full_name']) ?></strong></td>
                    <td><?= e($p['run_code'] ?? '—') ?></td>
                    <td><?= fa($p['hours_taught']) ?> ساعت</td>
                    <td><?= rial($p['gross_amount_rial']) ?></td>
                    <td><?= rial($p['tax_deduction_rial']) ?></td>
                    <td><strong><?= rial($p['net_amount_rial']) ?></strong></td>
                    <td><span class="badge badge-info"><?= e($p['status']) ?> <?= e($p['payment_ref'] ?? '') ?></span></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- v13.0 COMPOSITE INSTRUCTOR IMPACT & DYNAMIC HONORARIUM ENGINE -->
<div class="card" style="margin-top:18px;border:1.5px solid rgba(15,118,110,0.3)">
    <div class="card-header" style="align-items:center">
        <div>
            <div class="card-title">ماتریس هوشمند مرجعیت علمی اساتید و تعیین خودکار پایه حق‌التدریس (AI Instructor Impact Index)</div>
            <div class="muted" style="font-size:12px">فرمول وزنی ۴ شاخص: ۴۰٪ رضایت کرکپاتریک + ۳۰٪ نرخ قبولی آزمون + ۲۰٪ بازگشت مجدد فراگیران + ۱۰٪ نظم SLA</div>
        </div>
        <form method="post" action="<?= e(url('instructors')) ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="recalc_impact">
            <button type="submit" class="btn btn-gold btn-sm">بازمحاسبه رتبه و نرخ ساعتی ۱۴۰۵</button>
        </form>
    </div>
    <div class="table-wrap">
        <table>
            <thead><tr><th>استاد</th><th>کرکپاتریک (از ۵)</th><th>قبولی کلاس</th><th>نرخ بازگشت فراگیر</th><th>امتیاز کل مرجعیت</th><th>رتبه علمی</th><th>پایه حق‌التدریس ساعتی پیشنهادی</th></tr></thead>
            <tbody>
            <?php foreach (($impactScores ?? []) as $im): ?>
                <tr>
                    <td><strong><?= e($im['instructor_name']) ?></strong></td>
                    <td><?= fa((string)$im['kirkpatrick_avg']) ?></td>
                    <td><?= fa($im['exam_pass_rate_pct']) ?>٪</td>
                    <td><?= fa($im['repeat_retention_pct']) ?>٪</td>
                    <td><span class="badge badge-success"><?= fa($im['composite_impact_score']) ?> از ۱۰۰</span></td>
                    <td><span class="badge badge-purple"><?= e($im['academic_tier_badge']) ?></span></td>
                    <td><strong><?= rial($im['suggested_hourly_rial']) ?></strong></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
