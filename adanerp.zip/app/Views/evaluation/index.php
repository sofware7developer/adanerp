<div class="hero-banner">
    <div>
        <span class="badge badge-gold">سنجش اثربخشی و بازگشت سرمایه (ROI)</span>
        <h1>ارزیابی دوره‌ها، مدل ۴ سطحی کرکپاتریک، ROI و ارزیابی ۳۶۰ درجه</h1>
        <p>سنجش واکنش (سطح ۱)، یادگیری پیش/پس‌آزمون (سطح ۲)، انتقال رفتار به محیط کار (سطح ۳)، منافع ریالی و ROI (سطح ۴) و ارزیابی ۳۶۰ درجه.</p>
    </div>
</div>

<div class="alert alert-info">
    <div>
        <strong>نکته روش‌شناختی ROI:</strong> داده‌های هزینه اجرای برنامه و منافع ریالی برآوردشده بنگاه‌ها تا حدی به صورت دستی توسط کارشناس اثربخشی و مدیر آموزش سازمان وارد می‌شوند و شاخص بازگشت سرمایه بر اساس فرمول استاندارد <code>((فایده ریالی - هزینه کل) / هزینه کل) × ۱۰۰</code> محاسبه می‌گردد.
    </div>
</div>

<div class="grid grid-sidebar">
    <div class="card">
        <div class="card-header"><div class="card-title">📊 کارنامه اثربخشی کرکپاتریک و ROI دوره‌های اجراشده</div></div>
        <?php foreach ($evals as $ev): ?>
            <?php
            $gain = round((float)$ev['post_test_score'] - (float)$ev['pre_test_score'], 1);
            $cost = max(1, (int)$ev['program_cost_rial']);
            $roi = round((((int)$ev['estimated_benefit_rial'] - $cost) / $cost) * 100, 1);
            ?>
            <div style="border:1px solid var(--border);border-radius:14px;padding:15px;margin-bottom:14px">
                <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
                    <strong>[<?= e($ev['course_code']) ?>] <?= e($ev['course_title']) ?></strong>
                    <span class="badge badge-success">نرخ بازگشت سرمایه (ROI): +<?= fa($roi) ?>٪</span>
                </div>
                <div class="grid grid-4" style="margin:12px 0 8px">
                    <div class="stat-card" style="padding:10px"><div><div class="stat-label">سطح ۱ (رضایت)</div><strong><?= fa($ev['kirkpatrick_l1_reaction']) ?> / ۵</strong></div></div>
                    <div class="stat-card" style="padding:10px"><div><div class="stat-label">سطح ۲ (رشد آزمون)</div><strong>+<?= fa($gain) ?> نمره</strong></div></div>
                    <div class="stat-card" style="padding:10px"><div><div class="stat-label">سطح ۳ (انتقال کار)</div><strong><?= fa($ev['kirkpatrick_l3_behavior']) ?> / ۵</strong></div></div>
                    <div class="stat-card" style="padding:10px"><div><div class="stat-label">فایده برآوردی</div><strong style="font-size:12px"><?= rial($ev['estimated_benefit_rial']) ?></strong></div></div>
                </div>
                <div style="font-size:12.5px"><strong>پیگیری انتقال یادگیری به محیط کار:</strong> <?= e($ev['transfer_notes']) ?></div>
                <div class="muted" style="font-size:12px;margin-top:4px"><strong>چکیده ۳۶۰ درجه:</strong> <?= e($ev['feedback_360_summary']) ?></div>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="card">
        <div class="card-header"><div class="card-title">➕ ثبت پرونده ارزیابی کرکپاتریک، ۳۶۰ و ROI</div></div>
        <form method="post" action="<?= e(url('evaluation')) ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="add_evaluation">
            <div class="form-group">
                <label>انتخاب دوره:</label>
                <select name="course_id">
                    <?php foreach ($courses as $c): ?>
                        <option value="<?= (int)$c['id'] ?>">[<?= e($c['code']) ?>] <?= e($c['title']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-grid">
                <div class="form-group">
                    <label>سطح ۱ واکنش (از ۵):</label>
                    <input type="number" step="0.1" name="kirkpatrick_l1_reaction" value="4.8">
                </div>
                <div class="form-group">
                    <label>میانگین پیش‌آزمون:</label>
                    <input type="number" step="0.5" name="pre_test_score" value="46">
                </div>
                <div class="form-group">
                    <label>میانگین پس‌آزمون:</label>
                    <input type="number" step="0.5" name="post_test_score" value="88">
                </div>
                <div class="form-group">
                    <label>سطح ۳ رفتار شغلی (از ۵):</label>
                    <input type="number" step="0.1" name="kirkpatrick_l3_behavior" value="4.4">
                </div>
            </div>
            <div class="form-grid">
                <div class="form-group">
                    <label>هزینه کل دوره (ریال):</label>
                    <input type="number" name="program_cost_rial" value="320000000">
                </div>
                <div class="form-group">
                    <label>منفعت ریالی برآوردی (ریال):</label>
                    <input type="number" name="estimated_benefit_rial" value="980000000">
                </div>
            </div>
            <div class="form-group">
                <label>گزارش انتقال یادگیری پس از دوره:</label>
                <input type="text" name="transfer_notes" value="بهبود ملموس شاخص عملکرد صادراتی پس از ۶۰ روز">
            </div>
            <div class="form-group">
                <label>خلاصه ارزیابی ۳۶۰ درجه (مدیر، همتا، خودارزیابی):</label>
                <input type="text" name="feedback_360_summary" value="ارزیابی همسو با میانگین ۴.۵ از ۵">
            </div>
            <button type="submit" class="btn btn-primary" style="width:100%">محاسبه ROI و ثبت ارزیابی</button>
        </form>
    </div>
</div>
