<?php
use App\Core\Jalali;
use App\Core\QrSvg;
?>
<div class="card" style="border:3px double #0b192c;max-width:920px;margin:0 auto">
    <div style="display:flex;justify-content:space-between;align-items:center;border-bottom:2px solid #0b192c;padding-bottom:14px;margin-bottom:16px">
        <div>
            <h2 style="font-size:20px;font-weight:900">صورتحساب خدمات آموزشی — مؤسسه آموزشی آدان</h2>
            <p class="muted" style="font-size:12.5px">این سند بر اساس اطلاعات ثبت‌شده در سامانه آدان تهیه شده است.</p>
        </div>
        <div style="text-align:left">
            <div style="font-weight:900;font-size:15px">شماره فاکتور: <code><?= e($invoice['invoice_number']) ?></code></div>
            <div style="font-size:12.5px">تاریخ صدور: <?= e(Jalali::today()) ?></div>
            <button type="button" class="btn btn-gold btn-sm" onclick="window.print()" style="margin-top:6px">🖨️ چاپ / ذخیره PDF رسمی</button>
        </div>
    </div>

    <div class="grid grid-2" style="margin-bottom:16px">
        <div style="background:#f8fafc;padding:12px;border-radius:10px;border:1px solid var(--border);font-size:13px">
            <strong>مشخصات خریدار / متقاضی آموزش:</strong><br>
            نام و نام خانوادگی: <strong><?= e($invoice['full_name']) ?></strong><br>
            کد ملی: <?= fa($invoice['national_code'] ?? '—') ?> | تلفن همراه: <?= fa($invoice['mobile'] ?? '—') ?>
        </div>
        <div style="background:#f8fafc;padding:12px;border-radius:10px;border:1px solid var(--border);font-size:13px">
            <strong>مشخصات سازمان:</strong><br>
            نام حقوقی شرکت: <strong><?= e($invoice['org_name'] ?? 'شخص حقیقی / آزاد') ?></strong><br>
            شناسه ملی: <?= fa($invoice['org_national_id'] ?? '—') ?>
        </div>
    </div>

    <div class="table-wrap" style="margin-bottom:16px">
        <table>
            <thead>
            <tr>
                <th>ردیف</th>
                <th>شرح کالا / خدمات آموزشی</th>
                <th>مبلغ پایه</th>
                <th>تخفیف عضویت / کوپن</th>
                <th>مالیات ارزش افزوده (۱۰٪)</th>
                <th>جمع کل قابل پرداخت</th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <td>۱</td>
                <td><strong><?= e($invoice['item_description']) ?></strong></td>
                <td><?= rial($invoice['subtotal_rial']) ?></td>
                <td><?= rial($invoice['discount_rial']) ?></td>
                <td><?= rial($invoice['vat_rial']) ?></td>
                <td><strong><?= rial($invoice['total_rial']) ?></strong></td>
            </tr>
            </tbody>
        </table>
    </div>

    <div style="display:flex;justify-content:space-between;align-items:center;gap:16px">
        <div style="font-size:12.5px">
            <div>وضعیت تسویه صورتحساب: <span class="badge badge-info"><?= e($invoice['status']) ?></span> | روش پرداخت: <?= e($invoice['payment_mode']) ?></div>
            <p class="muted" style="margin-top:8px">
                توجه: ثبت این صورتحساب به معنی ارسال آن به سامانه مالیاتی یا اتصال به درگاه پرداخت نیست.
            </p>
            <a href="<?= e(url('finance')) ?>" class="btn btn-outline btn-sm" style="margin-top:8px">بازگشت به ماژول مالی</a>
        </div>
        <div style="text-align:center">
            <?= QrSvg::render(url('invoice-print', ['id' => $invoice['id']]), 105) ?>
            <div class="muted" style="font-size:10.5px">شناسه اصالت صورتحساب</div>
        </div>
    </div>
</div>
