<?php
use App\Core\Auth;
$isFinAdmin = $isFinAdmin ?? Auth::hasRole(['super_admin', 'finance_manager']);
$myPaidSum = array_sum(array_map(static function ($invoice): int {
    return match ($invoice['status'] ?? '') {
        'paid', 'refund_requested' => (int)$invoice['total_rial'],
        'partial' => (int)($invoice['paid_installments_rial'] ?? 0),
        default => 0,
    };
}, $invoices));
$myUnpaidSum = array_sum(array_map(static function ($invoice): int {
    return match ($invoice['status'] ?? '') {
        'unpaid' => (int)$invoice['total_rial'],
        'partial' => max(0, (int)$invoice['total_rial'] - (int)($invoice['paid_installments_rial'] ?? 0)),
        default => 0,
    };
}, $invoices));
?>
<div class="hero-banner">
    <div>
        <span class="badge badge-gold"><?= $isFinAdmin ? 'مدیریت مالی آموزش، خزانه و دفترکل ۴ سطحی' : 'وضعیت شهریه و صورتحساب‌های اختصاصی من' ?></span>
        <h1><?= $isFinAdmin ? 'مدیریت مالی آموزش، فاکتور مالیاتی قابل چاپ، اقساط، سودآوری و تراز آزمایشی' : 'صورتحساب‌های شهریه، تقسیط و رسیدهای پرداخت من' ?></h1>
        <p><?= $isFinAdmin ? 'صدور و چاپ صورتحساب رسمی ارزش افزوده، وصول اقساط با ثبت خودکار سند، تحلیل سودآوری دوره‌ها و تراز آزمایشی دفترکل.' : 'مشاهده و پرداخت صورتحساب‌ها و اقساط آموزشی اختصاصی حساب شما به همراه چاپ فاکتور رسمی.' ?></p>
    </div>
</div>

<?php if ($isFinAdmin): ?>
<div class="grid grid-4">
    <div class="kpi-card">
        <div class="kpi-icon" style="background:#dcfce7;color:#15803d">💰</div>
        <div><div class="kpi-val"><?= rial($sumRev) ?></div><div class="kpi-lbl">جمع درآمدهای ثبت‌شده دفترکل</div></div>
    </div>
    <div class="kpi-card">
        <div class="kpi-icon" style="background:#fee2e2;color:#b91c1c">📉</div>
        <div><div class="kpi-val"><?= rial($sumExp) ?></div><div class="kpi-lbl">جمع هزینه‌های مستقیم آموزشی</div></div>
    </div>
    <div class="kpi-card">
        <div class="kpi-icon" style="background:#dbeafe;color:#1d4ed8">📊</div>
        <div><div class="kpi-val"><?= rial($sumRev - $sumExp - $sumRefund) ?></div><div class="kpi-lbl">مازاد خالص پس از هزینه‌ها و استردادها</div></div>
    </div>
    <div class="kpi-card">
        <div class="kpi-icon" style="background:#fef3c7;color:#b45309">🏦</div>
        <div><div class="kpi-val"><?= rial($sumBudget) ?></div><div class="kpi-lbl">سقف بودجه مصوب سالانه</div></div>
    </div>
</div>
<?php else: ?>
<div class="grid grid-3" style="margin-bottom:16px">
    <div class="stat-card"><div><div class="stat-label">کل صورتحساب‌های من</div><div class="stat-value"><?= fa(count($invoices)) ?> فاکتور</div></div><div class="stat-icon icon-blue">🧾</div></div>
    <div class="stat-card"><div><div class="stat-label">پرداخت‌شده من</div><div class="stat-value"><?= rial($myPaidSum) ?></div></div><div class="stat-icon icon-green">✅</div></div>
    <div class="stat-card"><div><div class="stat-label">مانده قابل پرداخت من</div><div class="stat-value"><?= rial($myUnpaidSum) ?></div></div><div class="stat-icon icon-gold">💳</div></div>
</div>
<?php endif; ?>

<div class="grid grid-sidebar">
    <div>
        <div class="card">
            <div class="card-header"><div class="card-title">🧾 صورتحساب‌های رسمی، چاپ مالیاتی و مدیریت استرداد</div></div>
            <div class="table-wrap">
                <table>
                    <thead>
                    <tr>
                        <th>شماره فاکتور</th>
                        <th>مشتری / سازمان</th>
                        <th>مبلغ کل (با ۱۰٪ VAT)</th>
                        <th>وضعیت</th>
                        <th>چاپ رسمی / استرداد</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($invoices as $inv): ?>
                        <tr>
                            <td><code><?= e($inv['invoice_number']) ?></code></td>
                            <td>
                                <strong><?= e($inv['full_name']) ?></strong>
                                <div class="muted" style="font-size:11.5px"><?= e($inv['item_description']) ?></div>
                            </td>
                            <td><strong><?= rial($inv['total_rial']) ?></strong></td>
                            <td>
                                <span class="badge <?= $inv['status'] === 'paid' ? 'badge-success' : (in_array($inv['status'], ['refund_requested', 'refunded'], true) ? 'badge-info' : 'badge-warning') ?>"><?= e($inv['status']) ?></span>
                                <?php if (!empty($inv['payment_reference'])): ?><div class="muted" style="font-size:11px">رسید: <?= e($inv['payment_reference']) ?></div><?php endif; ?>
                                <?php if (!empty($inv['refund_payment_reference'])): ?><div class="muted" style="font-size:11px">رسید استرداد: <?= e($inv['refund_payment_reference']) ?></div><?php endif; ?>
                            </td>
                            <td>
                                <a class="btn btn-gold btn-sm" href="<?= e(url('invoice-print', ['id' => $inv['id']])) ?>">🖨️ چاپ رسمی</a>
                                <?php if ($inv['status'] === 'unpaid' && $inv['payment_mode'] === 'cash_gateway_sim'): ?>
                                    <form method="post" action="<?= e(url('finance')) ?>" style="display:inline-flex;margin-right:4px">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="action" value="simulate_gateway_pay">
                                        <input type="hidden" name="invoice_id" value="<?= (int)$inv['id'] ?>">
                                        <button type="submit" class="btn btn-outline btn-sm">ثبت تراکنش آزمایشی (بدون تسویه)</button>
                                    </form>
                                <?php endif; ?>
                                <?php if ($isFinAdmin && $inv['status'] === 'unpaid' && in_array($inv['payment_mode'], ['cash_gateway_sim', 'corporate_contract'], true)): ?>
                                    <form method="post" action="<?= e(url('finance')) ?>" style="display:inline-flex;gap:4px;margin-right:4px;flex-wrap:wrap">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="action" value="confirm_invoice_payment">
                                        <input type="hidden" name="invoice_id" value="<?= (int)$inv['id'] ?>">
                                        <input type="text" name="payment_reference" required minlength="6" maxlength="80" pattern="[A-Za-z0-9-]{6,80}" placeholder="رسید بانکی/قراردادی" aria-label="رسید بانکی یا قراردادی">
                                        <button type="submit" class="btn btn-outline btn-sm">تأیید وصول</button>
                                    </form>
                                <?php endif; ?>
                                <?php if ($inv['status'] === 'paid'): ?>
                                    <form method="post" action="<?= e(url('finance')) ?>" style="display:inline-flex;margin-right:4px">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="action" value="request_refund">
                                        <input type="hidden" name="invoice_id" value="<?= (int)$inv['id'] ?>">
                                        <input type="text" name="refund_reason" required maxlength="255" placeholder="علت استرداد" aria-label="علت استرداد">
                                        <button type="submit" class="btn btn-outline btn-sm">استرداد</button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php if ($isFinAdmin): ?>
                <?php $refundRequests = array_values(array_filter($invoices, static fn($invoice) => $invoice['status'] === 'refund_requested')); ?>
                <?php if ($refundRequests !== []): ?>
                    <div class="card" style="margin:14px">
                        <div class="card-header"><div class="card-title">درخواست‌های استرداد؛ ثبت انجام فقط پس از حواله واقعی</div></div>
                        <?php foreach ($refundRequests as $refund): ?>
                            <div style="padding:10px 0;border-top:1px solid var(--border)">
                                <strong><?= e($refund['invoice_number']) ?></strong>
                                <span><?= rial($refund['total_rial']) ?></span>
                                <div class="muted">علت: <?= e($refund['refund_reason'] ?? '') ?></div>
                                <form method="post" action="<?= e(url('finance')) ?>" style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action" value="confirm_refund">
                                    <input type="hidden" name="invoice_id" value="<?= (int)$refund['id'] ?>">
                                    <input type="text" name="refund_payment_reference" required minlength="6" maxlength="80" pattern="[A-Za-z0-9-]{6,80}" placeholder="شماره پیگیری حواله بانکی">
                                    <button type="submit" class="btn btn-outline btn-sm">ثبت انجام استرداد</button>
                                </form>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>

        <?php if (Auth::hasRole(['super_admin', 'finance_manager', 'training_expert'])): ?>
        <!-- COURSE PROFITABILITY MATRIX -->
        <div class="card">
            <div class="card-header"><div class="card-title">📈 جدول سودآوری تفکیکی دوره‌های آموزشی (درآمد، هزینه مستقیم و حاشیه سود)</div></div>
            <div class="table-wrap">
                <table>
                    <thead>
                    <tr>
                        <th>کد و عنوان دوره</th>
                        <th>درآمد محقق‌شده</th>
                        <th>هزینه مستقیم ثبت‌شده</th>
                        <th>سود / مازاد خالص دوره</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($profitability as $pr): ?>
                        <?php $net = (int)$pr['revenue_rial'] - (int)$pr['expense_rial']; ?>
                        <tr>
                            <td><strong>[<?= e($pr['code']) ?>] <?= e($pr['title']) ?></strong></td>
                            <td><?= rial($pr['revenue_rial']) ?></td>
                            <td><?= rial($pr['expense_rial']) ?></td>
                            <td><span class="badge <?= $net >= 0 ? 'badge-success' : 'badge-danger' ?>"><?= rial($net) ?></span></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <?php endif; ?>

        <?php if ($isFinAdmin): ?>
        <!-- GENERAL LEDGER TRIAL BALANCE -->
        <div class="card">
            <div class="card-header"><div class="card-title">⚖️ تراز آزمایشی سرفصل‌های دفترکل مالی آموزش (Trial Balance)</div></div>
            <div class="table-wrap">
                <table>
                    <thead>
                    <tr>
                        <th>سرفصل حسابداری</th>
                        <th>جمع گردش بدهکار</th>
                        <th>جمع گردش بستانکار</th>
                        <th>مانده خالص حساب</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($trialBalance as $tb): ?>
                        <tr>
                            <td><strong><?= e($tb['account_head']) ?></strong></td>
                            <td><?= rial($tb['sum_debit']) ?></td>
                            <td><?= rial($tb['sum_credit']) ?></td>
                            <td><strong><?= rial($tb['net_balance']) ?></strong></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div>
        <?php endif; ?>
        <?php if ($isFinAdmin || Auth::hasRole(['training_expert', 'org_rep'])): ?>
        <div class="card">
            <div class="card-header"><div class="card-title">➕ صدور فاکتور جدید با کد تخفیف و تقسیط</div></div>
            <form method="post" action="<?= e(url('finance')) ?>">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="create_invoice">
                <div class="form-group">
                    <label>شرح ردیف خدمات آموزشی:</label>
                    <input type="text" name="item_description" value="ثبت‌نام دوره حسابداری آدان" required>
                </div>
                <div class="form-group">
                    <label>مبلغ پایه قبل از تخفیف و مالیات (ریال):</label>
                    <input type="number" name="subtotal_rial" value="65000000" required>
                </div>
                <div class="form-group">
                    <label>کد تخفیف:</label>
                    <input type="text" name="discount_code" value="">
                </div>
                <div class="form-group">
                    <label>شیوه تسویه:</label>
                    <select name="payment_mode">
                        <option value="installment">تقسیط دو مرحله‌ای (ایجاد خودکار اقساط)</option>
                        <option value="cash_gateway_sim">نقدی (شبیه‌ساز درگاه بانکی)</option>
                        <option value="corporate_contract">کسر از قرارداد سازمانی</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary" style="width:100%">محاسبه مالیات و صدور فاکتور</button>
            </form>
        </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header"><div class="card-title">💳 سررسید و وصول اقساط (<?= fa(count($installments)) ?> قسط)</div></div>
            <?php foreach ($installments as $ins): ?>
                <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid var(--border);font-size:12.5px">
                    <div>
                        <span><code><?= e($ins['invoice_number']) ?></code> — قسط <?= fa($ins['installment_no']) ?></span>
                        <div class="muted"><?= rial($ins['amount_rial']) ?> (<?= e($ins['due_shamsi']) ?>)</div>
                    </div>
                    <?php if ($ins['status'] !== 'paid' && $isFinAdmin): ?>
                        <form method="post" action="<?= e(url('finance')) ?>">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="settle_installment">
                            <input type="hidden" name="installment_id" value="<?= (int)$ins['id'] ?>">
                            <input type="text" name="payment_reference" required minlength="6" maxlength="80" pattern="[A-Za-z0-9-]{6,80}" placeholder="شماره پیگیری بانکی" aria-label="شماره پیگیری بانکی">
                            <button type="submit" class="btn btn-gold btn-sm">تأیید وصول پس از بررسی بانک</button>
                        </form>
                    <?php elseif ($ins['status'] !== 'paid'): ?>
                        <span class="badge badge-warning">در انتظار تأیید واحد مالی</span>
                    <?php else: ?>
                        <span class="badge badge-success">تسویه شد</span>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>

        <?php if (Auth::hasRole(['super_admin', 'finance_manager'])): ?>
            <div class="card">
                <div class="card-header"><div class="card-title">🏦 تطبیق CSV بانکی فقط با تراکنش‌های واقعی ثبت‌شده</div></div>
                <form method="post" action="<?= e(url('finance')) ?>" style="margin-bottom:10px">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="reconcile_bank_csv">
                    <div class="form-group">
                        <label>ردیف‌های فایل بانک (کد رهگیری, مبلغ ریال). تراکنش آزمایشی در این تطبیق پذیرفته نمی‌شود:</label>
                        <textarea name="bank_csv" rows="2" dir="ltr" required placeholder="BANK-REFERENCE,AMOUNT_RIAL"></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary btn-sm" style="width:100%">اجرای تطبیق و آشتی بانکی</button>
                </form>
                <?php foreach ($transactions as $tx): ?>
                    <div style="display:flex;justify-content:space-between;padding:5px 0;border-top:1px solid var(--border);font-size:11.5px">
                        <span><code><?= e($tx['ref_id']) ?></code> (<?= rial($tx['amount_rial']) ?>)</span>
                        <span class="badge <?= (int)$tx['is_reconciled'] === 1 ? 'badge-success' : 'badge-warning' ?>">
                            <?= (int)$tx['is_reconciled'] === 1 ? 'تطبیق‌شده' : 'منتظر آشتی' ?>
                        </span>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="card">
                <div class="card-header"><div class="card-title">🧾 خزانه چک‌های صیادی ۱۶ رقمی بنگاه‌ها</div></div>
                <form method="post" action="<?= e(url('finance')) ?>" style="margin-bottom:10px">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="register_sayad_cheque">
                    <div class="form-group"><input type="text" name="sayad_16digit" value="3055889911223344" dir="ltr" placeholder="شناسه ۱۶ رقمی صیادی" required></div>
                    <div class="form-group"><input type="text" name="drawer_company" value="شرکت پتروشیمی اروند (دانش‌پذیر آدان)" required></div>
                    <div class="form-grid">
                        <input type="text" name="bank_name" value="بانک تجارت" required>
                        <input type="number" name="amount_rial" value="360000000" required>
                    </div>
                    <div class="form-grid" style="margin-top:6px">
                        <input type="text" name="due_shamsi" value="۱۴۰۵/۰۹/۱۰" required>
                        <select name="inquiry_color"><option value="سفید - خوش‌حساب">وضعیت سفید صیاد</option><option value="زرد - یک فقره برگشتی">وضعیت زرد صیاد</option></select>
                    </div>
                    <button type="submit" class="btn btn-primary btn-sm" style="width:100%;margin-top:8px">ثبت چک صیادی در خزانه</button>
                </form>
                <?php foreach (($sayadCheques ?? []) as $ch): ?>
                    <div style="border-top:1px solid var(--border);padding:8px 0;font-size:12px">
                        <div style="display:flex;justify-content:space-between"><strong><?= e($ch['drawer_company']) ?></strong><span><?= rial($ch['amount_rial']) ?></span></div>
                        <div class="muted">صیاد: <code><?= e($ch['sayad_16digit']) ?></code> | سررسید: <?= e($ch['due_shamsi']) ?></div>
                        <div style="display:flex;justify-content:space-between;align-items:center;margin-top:4px">
                            <span class="badge badge-info"><?= e($ch['inquiry_color']) ?></span>
                            <?php if ($ch['clearance_status'] !== 'وصول شده به دفترکل'): ?>
                                <form method="post" action="<?= e(url('finance')) ?>"><?= csrf_field() ?><input type="hidden" name="action" value="clear_sayad_cheque"><input type="hidden" name="cheque_id" value="<?= (int)$ch['id'] ?>"><button class="btn btn-outline btn-sm" type="submit">وصول به دفترکل</button></form>
                            <?php else: ?>
                                <span class="badge badge-success">وصول‌شده</span>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="card">
                <div class="card-header"><div class="card-title">📝 ثبت سند جدید در دفترکل</div></div>
                <form method="post" action="<?= e(url('finance')) ?>">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="add_ledger">
                    <div class="form-group">
                        <label>نوع سند:</label>
                        <select name="entry_type">
                            <option value="expense">هزینه برگزاری دوره (بدهکار)</option>
                            <option value="revenue">درآمد آموزشی (بستانکار)</option>
                            <option value="budget_alloc">تخصیص ردیف بودجه</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>سرفصل حساب:</label>
                        <input type="text" name="account_head" value="پذیرایی و تدارکات کارگاه آموزشی" required>
                    </div>
                    <div class="form-group">
                        <label>مبلغ (ریال):</label>
                        <input type="number" name="amount_rial" value="18000000" required>
                    </div>
                    <div class="form-group">
                        <label>شرح سند:</label>
                        <input type="text" name="description" value="تدارکات دوره پاییز ۱۴۰۵" required>
                    </div>
                    <button type="submit" class="btn btn-gold" style="width:100%">ثبت در دفترکل</button>
                </form>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php if ($isFinAdmin): ?>
<!-- 4-LEVEL IRANIAN CHART OF ACCOUNTS DOUBLE-ENTRY VOUCHERS -->
<div class="grid grid-sidebar" style="margin-top:18px">
    <div class="card">
        <div class="card-header"><div class="card-title">🧾 دفتر روزنامه اسناد حسابداری دوطرفه ۴ سطحی استاندارد ایران (گروه / کل / معین / تفصیلی)</div></div>
        <div class="table-wrap">
            <table>
                <thead><tr><th>شماره و تاریخ سند</th><th>گروه / کل / معین</th><th>تفصیلی شناور و مرکز هزینه</th><th>بدهکار (ریال)</th><th>بستانکار (ریال)</th><th>تراز کنترل</th></tr></thead>
                <tbody>
                <?php foreach (($vouchers4Level ?? []) as $vc): ?>
                    <tr>
                        <td><strong><?= e($vc['voucher_no']) ?></strong><div class="muted" style="font-size:11px"><?= e($vc['voucher_shamsi']) ?></div></td>
                        <td><div><strong><?= e($vc['group_code']) ?> | کل: <?= e($vc['kol_account']) ?></strong></div><div class="muted" style="font-size:11.5px">معین: <?= e($vc['moein_account']) ?></div></td>
                        <td><strong><?= e($vc['tafsili_entity']) ?></strong><div class="muted" style="font-size:11px"><?= e($vc['voucher_desc']) ?></div></td>
                        <td><?= rial($vc['debit_rial']) ?></td>
                        <td><?= rial($vc['credit_rial']) ?></td>
                        <td><span class="badge badge-success">✓ تراز دوطرفه</span></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card">
        <div class="card-header"><div class="card-title">⚖️ صدور سند حسابداری ۴ سطحی تراز (Debit = Credit)</div></div>
        <form method="post" action="<?= e(url('finance')) ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="create_double_voucher">
            <div class="form-grid">
                <div><label>سطح ۱ — گروه حساب:</label><input type="text" name="group_code" value="۱-دارایی جاری" required></div>
                <div><label>سطح ۲ — حساب کل:</label><input type="text" name="kol_account" value="۱۱۱۰-موجودی نقد و بانک‌های اتاق" required></div>
            </div>
            <div class="form-grid" style="margin-top:6px">
                <div><label>سطح ۳ — حساب معین:</label><input type="text" name="moein_account" value="۱۱۱۰۴-حساب تمرکز درآمد آموزش" required></div>
                <div><label>سطح ۴ — تفصیلی شناور / مرکز هزینه:</label><input type="text" name="tafsili_entity" value="TF-90412 — واحد آموزش بازرگانی" required></div>
            </div>
            <div class="form-grid" style="margin-top:6px">
                <div><label>مبلغ بدهکار (ریال):</label><input type="number" name="debit_rial" value="64000000" required></div>
                <div><label>مبلغ بستانکار (ریال):</label><input type="number" name="credit_rial" value="64000000" required></div>
            </div>
            <div class="form-group" style="margin-top:6px"><input type="text" name="voucher_desc" value="ثبت قطعی درآمد دوره جامع صادرات به اوراسیا" required></div>
            <button type="submit" class="btn btn-primary" style="width:100%">کنترل تراز ریاضی و ثبت سند دوطرفه</button>
        </form>
    </div>
</div>

<?php endif; ?>
