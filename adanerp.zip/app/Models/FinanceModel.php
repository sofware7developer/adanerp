<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\App;
use App\Core\Auth;
use App\Core\Database;
use App\Core\Jalali;

final class FinanceModel extends BaseModel
{
    protected string $table = 'invoices';

    public function getInvoiceDetails(int $invoiceId): ?array
    {
        $inv = Database::fetchOne(
            'SELECT i.*, u.full_name, u.national_code, u.mobile, o.name AS org_name, o.national_id AS org_national_id
             FROM invoices i
             JOIN users u ON u.id = i.user_id
             LEFT JOIN organizations o ON o.id = i.org_id
             WHERE i.id = ? LIMIT 1',
            [$invoiceId]
        );
        if (!$inv) {
            return null;
        }
        $inv['installments'] = Database::fetchAll(
            'SELECT * FROM invoice_installments WHERE invoice_id = ? ORDER BY installment_no ASC',
            [$invoiceId]
        );
        return $inv;
    }

    public function issueEventInvoice(int $eventId, int $userId, ?int $orgId = null): ?array
    {
        $ev = Database::fetchOne('SELECT * FROM events WHERE id = ?', [$eventId]);
        if (!$ev || (int)$ev['price_rial'] <= 0) {
            return null;
        }

        $existing = Database::fetchOne(
            'SELECT * FROM invoices WHERE event_id = ? AND user_id = ? ORDER BY id DESC LIMIT 1',
            [$eventId, $userId]
        );
        if ($existing) {
            return $existing;
        }
        if (
            $ev['status'] !== 'open'
            || $ev['event_date'] < date('Y-m-d')
            || (int)$ev['registered_count'] >= (int)$ev['capacity']
        ) {
            return null;
        }

        $sub = (int)$ev['price_rial'];
        $vat = (int)round($sub * 0.10);
        $total = $sub + $vat;
        $invNo = 'INV-EVT-' . date('Y') . '-' . strtoupper(bin2hex(random_bytes(6)));

        $invId = Database::insert(
            'INSERT INTO invoices (invoice_number, user_id, org_id, event_id, item_description, subtotal_rial, discount_rial, vat_rial, total_rial, payment_mode, status)
             VALUES (?, ?, ?, ?, ?, ?, 0, ?, ?, "cash_gateway_sim", "unpaid")',
            [$invNo, $userId, $orgId, $eventId, 'ثبت‌نام برنامه آموزشی: ' . $ev['title'], $sub, $vat, $total]
        );
        Auth::audit('FINANCE', 'EVENT_INVOICE_CREATED', 'invoice', $invId, ['event_id' => $eventId, 'total' => $total]);
        return $this->find($invId);
    }

    public function simulateSignedGatewayPayment(int $invoiceId): ?array
    {
        $pdo = Database::connection();
        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare('SELECT * FROM invoices WHERE id = ? FOR UPDATE');
            $stmt->execute([$invoiceId]);
            $inv = $stmt->fetch(\PDO::FETCH_ASSOC);
            if (!$inv || $inv['payment_mode'] !== 'cash_gateway_sim' || $inv['status'] !== 'unpaid') {
                $pdo->rollBack();
                return null;
            }
            $existingStmt = $pdo->prepare(
                'SELECT id FROM payment_transactions WHERE invoice_id = ? AND gateway_mode = "sandbox_hmac_signed" LIMIT 1'
            );
            $existingStmt->execute([$invoiceId]);
            if ($existingStmt->fetchColumn() !== false) {
                $pdo->rollBack();
                return null;
            }

            $secret = (string)App::config('app_secret', '');
            $authority = 'AUTH-ADN-SBX-' . strtoupper(bin2hex(random_bytes(8)));
            $refId = 'ADN-SBX-' . strtoupper(bin2hex(random_bytes(8)));
            $sig = hash_hmac('sha256', $inv['invoice_number'] . '|' . $inv['total_rial'] . '|' . $refId, $secret);
            $insert = $pdo->prepare(
                'INSERT INTO payment_transactions (invoice_id, authority_code, ref_id, amount_rial, gateway_mode, hmac_signature, is_reconciled)
                 VALUES (?, ?, ?, ?, "sandbox_hmac_signed", ?, 0)'
            );
            $insert->execute([$invoiceId, $authority, $refId, (int)$inv['total_rial'], $sig]);
            $pdo->commit();
        } catch (\Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }
        Auth::audit('FINANCE', 'GATEWAY_SANDBOX_SIMULATED', 'invoice', $invoiceId, ['ref_id' => $refId]);

        return ['ref_id' => $refId, 'signature' => $sig, 'invoice_number' => $inv['invoice_number']];
    }

    public function reconcileBankCsv(string $csvLines): array
    {
        $lines = preg_split('/\R/', trim($csvLines)) ?: [];
        $matched = 0;
        $unmatched = 0;

        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '') {
                continue;
            }
            $parts = array_map('trim', explode(',', $line));
            $refId = $parts[0] ?? '';
            $amount = filter_var($parts[1] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
            if (count($parts) !== 2 || $refId === '' || $amount === false) {
                $unmatched++;
                continue;
            }

            $matches = Database::fetchAll(
                'SELECT id FROM payment_transactions
                 WHERE ref_id = ? AND amount_rial = ? AND is_reconciled = 0
                   AND gateway_mode IN ("zarinpal_verified", "behpardakht_verified", "sadad_verified")
                 ORDER BY id ASC LIMIT 2',
                [$refId, $amount]
            );
            if (count($matches) === 1) {
                $changed = Database::execute(
                    'UPDATE payment_transactions SET is_reconciled = 1, reconciled_at = NOW()
                     WHERE id = ? AND is_reconciled = 0
                       AND gateway_mode IN ("zarinpal_verified", "behpardakht_verified", "sadad_verified")',
                    [(int)$matches[0]['id']]
                );
                if ($changed === 1) {
                    $matched++;
                } else {
                    $unmatched++;
                }
            } else {
                $unmatched++;
            }
        }

        Auth::audit('FINANCE', 'BANK_RECONCILIATION_RUN', 'payment_transactions', null, ['matched' => $matched, 'unmatched' => $unmatched]);
        return ['matched' => $matched, 'unmatched' => $unmatched];
    }

    public function settleInstallment(int $installmentId, string $paymentReference): bool
    {
        if (!preg_match('/^[A-Za-z0-9-]{6,80}$/', $paymentReference)) {
            return false;
        }

        $pdo = Database::connection();
        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare(
                'SELECT ins.*, i.invoice_number, i.status AS invoice_status
                 FROM invoice_installments ins JOIN invoices i ON i.id = ins.invoice_id
                 WHERE ins.id = ? FOR UPDATE'
            );
            $stmt->execute([$installmentId]);
            $ins = $stmt->fetch(\PDO::FETCH_ASSOC);
            if (!$ins || $ins['status'] === 'paid' || !in_array($ins['invoice_status'], ['unpaid', 'partial'], true)) {
                $pdo->rollBack();
                return false;
            }

            $referenceStmt = $pdo->prepare('SELECT id FROM invoice_installments WHERE payment_reference = ? FOR UPDATE');
            $referenceStmt->execute([$paymentReference]);
            if ($referenceStmt->fetchColumn() !== false) {
                $pdo->rollBack();
                return false;
            }

            $update = $pdo->prepare(
                'UPDATE invoice_installments SET status = "paid", payment_reference = ? WHERE id = ? AND status <> "paid"'
            );
            $update->execute([$paymentReference, $installmentId]);
            if ($update->rowCount() !== 1) {
                $pdo->rollBack();
                return false;
            }
            $ledger = $pdo->prepare(
                'INSERT INTO ledger_entries (entry_date, entry_shamsi, account_head, entry_type, debit_rial, credit_rial, description)
                 VALUES (CURDATE(), ?, "وصول اقساط شهریه آموزشی", "revenue", 0, ?, ?)'
            );
            $ledger->execute([
                Jalali::today(),
                (int)$ins['amount_rial'],
                'تأیید دستی وصول قسط شماره ' . $ins['installment_no'] . ' فاکتور ' . $ins['invoice_number'] . '؛ پیگیری ' . $paymentReference,
            ]);

            $remainingStmt = $pdo->prepare(
                'SELECT COUNT(*) FROM invoice_installments WHERE invoice_id = ? AND status <> "paid"'
            );
            $remainingStmt->execute([(int)$ins['invoice_id']]);
            $remaining = (int)$remainingStmt->fetchColumn();
            $pdo->prepare('UPDATE invoices SET status = ? WHERE id = ?')
                ->execute([$remaining === 0 ? 'paid' : 'partial', (int)$ins['invoice_id']]);
            $pdo->commit();
        } catch (\Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }
        Auth::audit('FINANCE', 'INSTALLMENT_SETTLED', 'installment', $installmentId, ['invoice' => $ins['invoice_number']]);
        return true;
    }

    public function confirmRefund(int $invoiceId, string $refundPaymentReference): bool
    {
        if ($invoiceId <= 0 || !preg_match('/^[A-Za-z0-9-]{6,80}$/', $refundPaymentReference)) {
            return false;
        }

        $pdo = Database::connection();
        $pdo->beginTransaction();
        try {
            $invoiceStmt = $pdo->prepare('SELECT * FROM invoices WHERE id = ? FOR UPDATE');
            $invoiceStmt->execute([$invoiceId]);
            $invoice = $invoiceStmt->fetch(\PDO::FETCH_ASSOC);
            if (!$invoice || $invoice['status'] !== 'refund_requested' || $invoice['refund_payment_reference'] !== null) {
                $pdo->rollBack();
                return false;
            }

            $referenceStmt = $pdo->prepare('SELECT id FROM invoices WHERE refund_payment_reference = ? FOR UPDATE');
            $referenceStmt->execute([$refundPaymentReference]);
            if ($referenceStmt->fetchColumn() !== false) {
                $pdo->rollBack();
                return false;
            }

            $updateStmt = $pdo->prepare(
                'UPDATE invoices SET status = "refunded", refund_payment_reference = ?
                 WHERE id = ? AND status = "refund_requested" AND refund_payment_reference IS NULL'
            );
            $updateStmt->execute([$refundPaymentReference, $invoiceId]);
            if ($updateStmt->rowCount() !== 1) {
                $pdo->rollBack();
                return false;
            }
            $ledgerStmt = $pdo->prepare(
                'INSERT INTO ledger_entries (entry_date, entry_shamsi, account_head, entry_type, debit_rial, credit_rial, description)
                 VALUES (CURDATE(), ?, "استرداد شهریه آموزشی", "refund", ?, 0, ?)'
            );
            $ledgerStmt->execute([
                Jalali::today(),
                (int)$invoice['total_rial'],
                'استرداد کامل فاکتور ' . $invoice['invoice_number'] . '؛ پیگیری بانکی ' . $refundPaymentReference,
            ]);
            $pdo->commit();
        } catch (\Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }

        Auth::audit('FINANCE', 'REFUND_CONFIRMED', 'invoice', $invoiceId, ['refund_reference' => $refundPaymentReference]);
        return true;
    }

    public function confirmInvoicePayment(int $invoiceId, string $paymentReference): bool
    {
        if ($invoiceId <= 0 || !preg_match('/^[A-Za-z0-9-]{6,80}$/', $paymentReference)) {
            return false;
        }

        $pdo = Database::connection();
        $pdo->beginTransaction();
        try {
            $invoiceStmt = $pdo->prepare('SELECT * FROM invoices WHERE id = ? FOR UPDATE');
            $invoiceStmt->execute([$invoiceId]);
            $invoice = $invoiceStmt->fetch(\PDO::FETCH_ASSOC);
            if (
                !$invoice || $invoice['status'] !== 'unpaid'
                || !in_array($invoice['payment_mode'], ['cash_gateway_sim', 'corporate_contract'], true)
            ) {
                $pdo->rollBack();
                return false;
            }

            $referenceStmt = $pdo->prepare('SELECT id FROM invoices WHERE payment_reference = ? FOR UPDATE');
            $referenceStmt->execute([$paymentReference]);
            if ($referenceStmt->fetchColumn() !== false) {
                $pdo->rollBack();
                return false;
            }

            $updateStmt = $pdo->prepare(
                'UPDATE invoices SET status = "paid", payment_reference = ?
                 WHERE id = ? AND status = "unpaid" AND payment_reference IS NULL'
            );
            $updateStmt->execute([$paymentReference, $invoiceId]);
            if ($updateStmt->rowCount() !== 1) {
                $pdo->rollBack();
                return false;
            }
            $ledgerStmt = $pdo->prepare(
                'INSERT INTO ledger_entries (entry_date, entry_shamsi, account_head, entry_type, debit_rial, credit_rial, description)
                 VALUES (CURDATE(), ?, "وصول شهریه آموزشی", "revenue", 0, ?, ?)'
            );
            $ledgerStmt->execute([
                Jalali::today(),
                (int)$invoice['total_rial'],
                'تأیید دستی وصول فاکتور ' . $invoice['invoice_number'] . '؛ پیگیری ' . $paymentReference,
            ]);
            $pdo->commit();
        } catch (\Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }

        Auth::audit('FINANCE', 'INVOICE_PAYMENT_CONFIRMED', 'invoice', $invoiceId, ['payment_reference' => $paymentReference]);
        return true;
    }

    public function getCourseProfitability(): array
    {
        return Database::fetchAll(
            'SELECT c.id, c.code, c.title,
                    COALESCE(SUM(CASE WHEN l.entry_type = "revenue" THEN l.credit_rial ELSE 0 END), 0) AS revenue_rial,
                    COALESCE(SUM(CASE WHEN l.entry_type = "expense" THEN l.debit_rial ELSE 0 END), 0) AS expense_rial
             FROM courses c
             LEFT JOIN ledger_entries l ON l.course_id = c.id
             GROUP BY c.id, c.code, c.title
             ORDER BY revenue_rial DESC'
        );
    }

    public function getTrialBalance(): array
    {
        return Database::fetchAll(
            'SELECT account_head,
                    SUM(debit_rial) AS sum_debit,
                    SUM(credit_rial) AS sum_credit,
                    (SUM(credit_rial) - SUM(debit_rial)) AS net_balance
             FROM ledger_entries
             GROUP BY account_head
             ORDER BY sum_credit DESC, sum_debit DESC'
        );
    }
}
