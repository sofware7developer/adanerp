<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Database;

abstract class BaseModel
{
    protected string $table = '';
    protected string $primaryKey = 'id';

    public function all(string $orderBy = 'id DESC'): array
    {
        return Database::fetchAll("SELECT * FROM `{$this->table}` ORDER BY {$orderBy}");
    }

    public function find(int $id): ?array
    {
        return Database::fetchOne("SELECT * FROM `{$this->table}` WHERE `{$this->primaryKey}` = ? LIMIT 1", [$id]);
    }

    public function count(string $where = '1=1', array $params = []): int
    {
        return (int)Database::scalar("SELECT COUNT(*) FROM `{$this->table}` WHERE {$where}", $params);
    }

    public function delete(int $id): int
    {
        return Database::execute("DELETE FROM `{$this->table}` WHERE `{$this->primaryKey}` = ?", [$id]);
    }
}
