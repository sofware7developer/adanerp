<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Auth;
use App\Core\Database;

final class CourseModel extends BaseModel
{
    protected string $table = 'courses';

    public function getFilteredCatalog(string $search = '', int $categoryId = 0, string $status = ''): array
    {
        $where = ['1=1'];
        $params = [];

        if ($search !== '') {
            $where[] = '(c.title LIKE ? OR c.code LIKE ? OR c.summary LIKE ?)';
            $like = '%' . $search . '%';
            array_push($params, $like, $like, $like);
        }
        if ($categoryId > 0) {
            $where[] = 'c.category_id = ?';
            $params[] = $categoryId;
        }
        if ($status !== '') {
            $where[] = 'c.workflow_status = ?';
            $params[] = $status;
        }

        $sql = 'SELECT c.*, cc.title AS category_title, cc.color AS category_color
                FROM courses c
                JOIN course_categories cc ON cc.id = c.category_id
                WHERE ' . implode(' AND ', $where) . '
                ORDER BY c.id DESC';

        return Database::fetchAll($sql, $params);
    }

    /**
     * ثبت‌نام گروهی از CSV (هر خط: نام, موبایل, کد ملی, گذرواژه اولیه برای کاربر جدید)
     * در صورت تکمیل ظرفیت، مازاد افراد به صورت خودکار وارد فهرست انتظار (waitlist) می‌شوند
     */
    public function importBulkGroupEnrollments(int $runId, ?int $orgId, string $csvLines): array
    {
        $lines = preg_split('/\R/', trim($csvLines)) ?: [];
        $activeAdded = 0;
        $waitAdded = 0;
        $rejected = 0;
        $pdo = Database::connection();
        $pdo->beginTransaction();
        try {
            $runStmt = $pdo->prepare(
                'SELECT r.*, c.workflow_status
                 FROM course_runs r JOIN courses c ON c.id = r.course_id
                 WHERE r.id = ? FOR UPDATE'
            );
            $runStmt->execute([$runId]);
            $run = $runStmt->fetch(\PDO::FETCH_ASSOC);
            if (
                !$run || $run['status'] !== 'registration'
                || $run['workflow_status'] !== 'published'
                || $run['start_date'] <= date('Y-m-d')
            ) {
                $pdo->rollBack();
                return ['active' => 0, 'waitlist' => 0, 'rejected' => count(array_filter($lines, 'strlen'))];
            }

            $countStmt = $pdo->prepare('SELECT COUNT(*) FROM enrollments WHERE run_id = ? AND status = "active"');
            $countStmt->execute([$runId]);
            $currentEnrolled = (int)$countStmt->fetchColumn();
            $capacity = (int)$run['capacity'];

            foreach ($lines as $line) {
                $line = trim($line);
                if ($line === '') {
                    continue;
                }
                $parts = array_map('trim', explode(',', $line));
                $fullName = $parts[0] ?? '';
                if ($fullName === '') {
                    $rejected++;
                    continue;
                }

                $mobile = ($parts[1] ?? '') ?: null;
                $national = ($parts[2] ?? '') ?: null;
                $userSql = 'SELECT id, org_id, status FROM users WHERE role = "learner" AND '
                    . ($national !== null ? 'national_code = ?' : 'full_name = ?')
                    . ' ORDER BY id ASC LIMIT 1 FOR UPDATE';
                $userStmt = $pdo->prepare($userSql);
                $userStmt->execute([$national ?? $fullName]);
                $user = $userStmt->fetch(\PDO::FETCH_ASSOC);

                if ($user && ($user['status'] !== 'active'
                    || ($orgId !== null && (int)($user['org_id'] ?? 0) !== $orgId))) {
                    $rejected++;
                    continue;
                }

                if ($user) {
                    $uid = (int)$user['id'];
                } else {
                    $password = $parts[3] ?? '';
                    if (strlen($password) < 12) {
                        $rejected++;
                        continue;
                    }
                    $uname = 'member_' . bin2hex(random_bytes(6));
                    $insertUser = $pdo->prepare(
                        'INSERT INTO users (org_id, username, email, mobile, national_code, password_hash, full_name, role, job_title)
                         VALUES (?, ?, ?, ?, ?, ?, ?, "learner", "معرفی‌شده ثبت‌نام گروهی")'
                    );
                    $insertUser->execute([
                        $orgId,
                        $uname,
                        $uname . '@students.adan.local',
                        $mobile,
                        $national,
                        password_hash($password, PASSWORD_DEFAULT),
                        $fullName,
                    ]);
                    $uid = (int)$pdo->lastInsertId();
                }

                $existsStmt = $pdo->prepare('SELECT id FROM enrollments WHERE run_id = ? AND user_id = ? FOR UPDATE');
                $existsStmt->execute([$runId, $uid]);
                if ($existsStmt->fetchColumn() !== false) {
                    $rejected++;
                    continue;
                }

                $status = $currentEnrolled < $capacity ? 'active' : 'waitlist';
                $insertEnrollment = $pdo->prepare(
                    'INSERT INTO enrollments (run_id, user_id, org_id, source, status) VALUES (?, ?, ?, "bulk_org", ?)'
                );
                $insertEnrollment->execute([$runId, $uid, $orgId, $status]);
                if ($status === 'active') {
                    $currentEnrolled++;
                    $activeAdded++;
                } else {
                    $waitAdded++;
                }
            }

            $pdo->prepare('UPDATE course_runs SET enrolled_count = ? WHERE id = ?')->execute([$currentEnrolled, $runId]);
            $pdo->commit();
        } catch (\Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }

        return ['active' => $activeAdded, 'waitlist' => $waitAdded, 'rejected' => $rejected];
    }

    /**
     * انصراف فراگیر و ارتقای خودکار نفر اول فهرست انتظار (Waitlist Auto-Promotion)
     */
    public function cancelAndPromoteWaitlist(int $enrollmentId): string
    {
        $pdo = Database::connection();
        $pdo->beginTransaction();
        try {
            $enrollmentStmt = $pdo->prepare('SELECT run_id, status FROM enrollments WHERE id = ? FOR UPDATE');
            $enrollmentStmt->execute([$enrollmentId]);
            $enrollment = $enrollmentStmt->fetch(\PDO::FETCH_ASSOC);
            if (!$enrollment) {
                $pdo->rollBack();
                return 'ردیف ثبت‌نام یافت نشد.';
            }

            $runId = (int)$enrollment['run_id'];
            $runStmt = $pdo->prepare('SELECT id, status, start_date FROM course_runs WHERE id = ? FOR UPDATE');
            $runStmt->execute([$runId]);
            $run = $runStmt->fetch(\PDO::FETCH_ASSOC);
            if (!$run) {
                $pdo->rollBack();
                return 'اجرای دوره برای این ثبت‌نام پیدا نشد.';
            }
            if (!in_array($enrollment['status'], ['active', 'waitlist'], true)) {
                $pdo->rollBack();
                return 'این ثبت‌نام قبلاً لغو شده یا به پایان رسیده است.';
            }

            $pdo->prepare('UPDATE enrollments SET status = "cancelled" WHERE id = ?')->execute([$enrollmentId]);
            $promoted = null;
            if (
                $enrollment['status'] === 'active'
                && $run['status'] === 'registration'
                && $run['start_date'] > date('Y-m-d')
            ) {
                $waitStmt = $pdo->prepare(
                    'SELECT e.id, e.user_id, u.full_name
                     FROM enrollments e
                     JOIN users u ON u.id = e.user_id
                     WHERE e.run_id = ? AND e.status = "waitlist"
                     ORDER BY e.id ASC LIMIT 1 FOR UPDATE'
                );
                $waitStmt->execute([$runId]);
                $promoted = $waitStmt->fetch(\PDO::FETCH_ASSOC);
                if ($promoted) {
                    $pdo->prepare('UPDATE enrollments SET status = "active" WHERE id = ?')
                        ->execute([(int)$promoted['id']]);
                    $pdo->prepare(
                        'INSERT INTO notifications (user_id, target_role, title, body, type, link)
                         VALUES (?, "learner", "ارتقای خودکار از فهرست انتظار", "ظرفیت دوره باز شد و ثبت‌نام شما به وضعیت قطعی تغییر یافت.", "success", "tms")'
                    )->execute([(int)$promoted['user_id']]);
                }
            }

            $countStmt = $pdo->prepare('SELECT COUNT(*) FROM enrollments WHERE run_id = ? AND status = "active"');
            $countStmt->execute([$runId]);
            $activeCount = (int)$countStmt->fetchColumn();
            $pdo->prepare('UPDATE course_runs SET enrolled_count = ? WHERE id = ?')->execute([$activeCount, $runId]);
            $pdo->commit();
        } catch (\Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }

        if ($promoted) {
            Auth::audit('TMS', 'WAITLIST_AUTO_PROMOTED', 'enrollment', (int)$promoted['id'], ['run_id' => $runId]);
            return 'انصراف ثبت شد و «' . $promoted['full_name'] . '» به صورت خودکار از فهرست انتظار به ثبت‌نام قطعی ارتقا یافت!';
        }

        if ($enrollment['status'] === 'waitlist') {
            return 'درخواست حضور در فهرست انتظار لغو شد.';
        }
        return $run['status'] === 'registration' && $run['start_date'] > date('Y-m-d')
            ? 'انصراف ثبت شد و یک صندلی به ظرفیت آزاد دوره بازگشت.'
            : 'انصراف ثبت شد؛ چون مهلت ثبت‌نام پایان یافته، نفر جدیدی از فهرست انتظار جایگزین نشد.';
    }
}
