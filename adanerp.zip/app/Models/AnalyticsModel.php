<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Database;

final class AnalyticsModel
{
    /**
     * محاسبه مختصات هندسی نمودار رادار ۵ محوره شایستگی (SVG Spider Chart)
     */
    public static function buildCompetencyRadarSvgData(int $cx = 160, int $cy = 150, int $maxRadius = 105, int $userId = 0): array
    {
        $sql = $userId > 0
            ? 'SELECT comp.code, comp.title, AVG(ca.current_level) AS avg_cur, AVG(ca.target_level) AS avg_tar
               FROM competencies comp LEFT JOIN competency_assessments ca ON ca.competency_id = comp.id AND ca.user_id = ?
               GROUP BY comp.id, comp.code, comp.title ORDER BY comp.id ASC LIMIT 5'
            : 'SELECT comp.code, comp.title, AVG(ca.current_level) AS avg_cur, AVG(ca.target_level) AS avg_tar
               FROM competencies comp LEFT JOIN competency_assessments ca ON ca.competency_id = comp.id
               GROUP BY comp.id, comp.code, comp.title ORDER BY comp.id ASC LIMIT 5';
        $rows = Database::fetchAll($sql, $userId > 0 ? [$userId] : []);

        $n = max(3, count($rows));
        $axes = [];
        $curPts = [];
        $tarPts = [];

        foreach ($rows as $i => $row) {
            $angle = (-M_PI / 2) + (2 * M_PI * $i / $n);
            $curVal = max(1.0, min(5.0, (float)($row['avg_cur'] ?: 2.5)));
            $tarVal = max(1.0, min(5.0, (float)($row['avg_tar'] ?: 4.5)));

            $axX = round($cx + $maxRadius * cos($angle), 1);
            $axY = round($cy + $maxRadius * sin($angle), 1);
            $lblX = round($cx + ($maxRadius + 24) * cos($angle), 1);
            $lblY = round($cy + ($maxRadius + 18) * sin($angle), 1);

            $cR = ($curVal / 5.0) * $maxRadius;
            $tR = ($tarVal / 5.0) * $maxRadius;

            $curPts[] = round($cx + $cR * cos($angle), 1) . ',' . round($cy + $cR * sin($angle), 1);
            $tarPts[] = round($cx + $tR * cos($angle), 1) . ',' . round($cy + $tR * sin($angle), 1);

            $axes[] = [
                'code' => $row['code'],
                'x' => $axX,
                'y' => $axY,
                'lx' => $lblX,
                'ly' => $lblY,
                'cur' => round($curVal, 1),
                'tar' => round($tarVal, 1),
            ];
        }

        return [
            'cx' => $cx,
            'cy' => $cy,
            'r' => $maxRadius,
            'axes' => $axes,
            'current_points' => implode(' ', $curPts),
            'target_points' => implode(' ', $tarPts),
        ];
    }

    /**
     * جدول وضعیت واقعی یکپارچه‌سازی‌های بیرونی سامانه (بدون هیچ ادعای غیرواقعی)
     */
    public static function getIntegrationReadiness(): array
    {
        $hasAvalKey = trim(Database::setting('ai_api_key', Database::setting('avalai_api_key', ''))) !== '';
        $hasSearchKey = trim(Database::setting('search_api_key', '')) !== '';

        return [
            [
                'subsystem' => 'درگاه هوش مصنوعی AI API',
                'status' => $hasAvalKey ? 'کلید ثبت شده (آماده تست زنده)' : 'حالت شبیه‌ساز شفاف (کلید ثبت نشده)',
                'badge' => $hasAvalKey ? 'badge-success' : 'badge-warning',
                'note' => 'کلیدها سمت سرور نگهداری می‌شوند؛ اتصال زنده محیط عملیاتی از بخش تنظیمات درگاه AI قابل آزمون است.',
            ],
            [
                'subsystem' => 'درگاه پرداخت شاپرک و آشتی حسابداری',
                'status' => 'شبیه‌ساز / ثبت سند دستی',
                'badge' => 'badge-warning',
                'note' => 'اتصال زنده درگاه و آشتی بانکی کامل نشده است؛ صدور بلیت رویداد پولی بدون پرداخت مسدود است.',
            ],
            [
                'subsystem' => 'بارگذاری و اجرای بسته SCORM (LMS)',
                'status' => 'بارگذاری و تجزیه مانیفست فعال',
                'badge' => 'badge-info',
                'note' => 'پلیر پایه window.API تعبیه شده اما Runtime کامل استاندارد CMI هنوز تأیید نهایی نشده است.',
            ],
            [
                'subsystem' => 'ارسال پیامک، ایمیل و تلگرام بازاریابی',
                'status' => 'ثبت محلی؛ ارسال واقعی متصل نیست',
                'badge' => 'badge-warning',
                'note' => 'هیچ پیامکی، ایمیلی یا پیام تلگرامی از این سامانه ارسال نمی‌شود؛ اتصال و آزمون ارائه‌دهنده هنوز پیاده‌سازی نشده است.',
            ],
            [
                'subsystem' => 'جست‌وجوی وب تحلیل بازار (ایران/اروپا)',
                'status' => $hasSearchKey ? 'کلید Search API ثبت شده' : 'ثبت URL دستی فعال',
                'badge' => $hasSearchKey ? 'badge-success' : 'badge-info',
                'note' => 'جست‌وجوی زنده خودکار بدون کلید معتبر Search API ادعا نمی‌شود.',
            ],
        ];
    }
}
