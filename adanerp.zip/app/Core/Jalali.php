<?php
declare(strict_types=1);

namespace App\Core;

final class Jalali
{
    public const MONTHS = [
        1 => 'فروردین', 2 => 'اردیبهشت', 3 => 'خرداد',
        4 => 'تیر', 5 => 'مرداد', 6 => 'شهریور',
        7 => 'مهر', 8 => 'آبان', 9 => 'آذر',
        10 => 'دی', 11 => 'بهمن', 12 => 'اسفند',
    ];

    public const WEEKDAYS = ['شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه'];

    public static function toJalali(int $gy, int $gm, int $gd): array
    {
        $g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
        $gy2 = ($gm > 2) ? ($gy + 1) : $gy;
        $days = 355666 + (365 * $gy)
            + intdiv($gy2 + 3, 4)
            - intdiv($gy2 + 99, 100)
            + intdiv($gy2 + 399, 400)
            + $gd + $g_d_m[$gm - 1];
        $jy = -1595 + (33 * intdiv($days, 12053));
        $days %= 12053;
        $jy += 4 * intdiv($days, 1461);
        $days %= 1461;
        if ($days > 365) {
            $jy += intdiv($days - 1, 365);
            $days = ($days - 1) % 365;
        }
        if ($days < 186) {
            $jm = 1 + intdiv($days, 31);
            $jd = 1 + ($days % 31);
        } else {
            $jm = 7 + intdiv($days - 186, 30);
            $jd = 1 + (($days - 186) % 30);
        }
        return [$jy, $jm, $jd];
    }

    public static function toGregorian(int $jy, int $jm, int $jd): array
    {
        $jy += 1595;
        $days = -355668 + (365 * $jy) + (intdiv($jy, 33) * 8) + intdiv(($jy % 33) + 3, 4) + $jd
            + (($jm < 7) ? ($jm - 1) * 31 : (($jm - 7) * 30) + 186);
        $gy = 400 * intdiv($days, 146097);
        $days %= 146097;
        if ($days > 36524) {
            $gy += 100 * intdiv(--$days, 36524);
            $days %= 36524;
            if ($days >= 365) {
                $days++;
            }
        }
        $gy += 4 * intdiv($days, 1461);
        $days %= 1461;
        if ($days > 365) {
            $gy += intdiv($days - 1, 365);
            $days = ($days - 1) % 365;
        }
        $gd = $days + 1;
        $sal_a = [0, 31, (($gy % 4 === 0 && $gy % 100 !== 0) || ($gy % 400 === 0)) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
        for ($gm = 0; $gm < 13 && $gd > $sal_a[$gm]; $gm++) {
            $gd -= $sal_a[$gm];
        }
        return [$gy, $gm, $gd];
    }

    public static function today(bool $persianDigits = true): string
    {
        [$jy, $jm, $jd] = self::toJalali((int)date('Y'), (int)date('n'), (int)date('j'));
        $formatted = sprintf('%04d/%02d/%02d', $jy, $jm, $jd);
        return $persianDigits ? self::digits($formatted) : $formatted;
    }

    public static function todayFull(): string
    {
        [$jy, $jm, $jd] = self::toJalali((int)date('Y'), (int)date('n'), (int)date('j'));
        $w = ((int)date('w') + 1) % 7;
        return self::WEEKDAYS[$w] . ' ' . self::digits((string)$jd) . ' ' . self::MONTHS[$jm] . ' ' . self::digits((string)$jy);
    }

    public static function fromGregorianString(?string $dateStr): string
    {
        if (!$dateStr) {
            return '—';
        }
        $ts = strtotime($dateStr);
        if ($ts === false) {
            return self::digits($dateStr);
        }
        [$jy, $jm, $jd] = self::toJalali((int)date('Y', $ts), (int)date('n', $ts), (int)date('j', $ts));
        return self::digits(sprintf('%04d/%02d/%02d', $jy, $jm, $jd));
    }

    public static function digits(string|int|float $input): string
    {
        return strtr((string)$input, [
            '0' => '۰', '1' => '۱', '2' => '۲', '3' => '۳', '4' => '۴',
            '5' => '۵', '6' => '۶', '7' => '۷', '8' => '۸', '9' => '۹',
        ]);
    }

    public static function rial(int|float|string $amount): string
    {
        $val = (float)$amount;
        return self::digits(number_format($val, 0, '.', ',')) . ' ریال';
    }

    public static function buildMonthCalendar(int $jy, int $jm, array $eventsByDate = []): array
    {
        [$gy, $gm, $gd] = self::toGregorian($jy, $jm, 1);
        $firstTs = mktime(0, 0, 0, $gm, $gd, $gy);
        $startWeekday = ((int)date('w', $firstTs) + 1) % 7; // شنبه = 0
        $daysInMonth = ($jm <= 6) ? 31 : (($jm <= 11) ? 30 : 29);

        $cells = [];
        for ($i = 0; $i < $startWeekday; $i++) {
            $cells[] = null;
        }
        for ($d = 1; $d <= $daysInMonth; $d++) {
            $keyFa = self::digits(sprintf('%04d/%02d/%02d', $jy, $jm, $d));
            $cells[] = [
                'day' => $d,
                'day_fa' => self::digits($d),
                'date_fa' => $keyFa,
                'items' => $eventsByDate[$keyFa] ?? [],
            ];
        }
        return [
            'year' => $jy,
            'month' => $jm,
            'month_name' => self::MONTHS[$jm] ?? 'آبان',
            'title' => (self::MONTHS[$jm] ?? 'آبان') . ' ' . self::digits($jy),
            'cells' => $cells,
        ];
    }
}
