<?php
declare(strict_types=1);

namespace App\Core;

/**
 * موتور اعتبارسنجی ریاضی شناسه‌های رسمی جمهوری اسلامی ایران و بانکداری بین‌المللی
 * ۱. کد ملی ۱۰ رقمی اشخاص حقیقی (الگوریتم رقم کنترل مدول ۱۱)
 * ۲. شناسه ملی ۱۱ رقمی اشخاص حقوقی / شرکت‌ها
 * ۳. شماره شبا ۲۶ کاراکتری بانکی ایران (استاندارد ISO 7064 Mod 97-10)
 * ۴. شناسه ۱۶ رقمی چک صیادی و کد پستی ۱۰ رقمی ایران
 */
final class IranValidator
{
    public static function normalizeDigits(string $input): string
    {
        return strtr(trim($input), [
            '۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4',
            '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
            '٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4',
            '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9',
        ]);
    }

    public static function isValidNationalCode(string $raw): bool
    {
        $code = preg_replace('/\D+/', '', self::normalizeDigits($raw));
        if (strlen($code) !== 10 || preg_match('/^(\d)\1{9}$/', $code)) {
            return false;
        }
        $sum = 0;
        for ($i = 0; $i < 9; $i++) {
            $sum += ((int)$code[$i]) * (10 - $i);
        }
        $rem = $sum % 11;
        $check = (int)$code[9];
        return ($rem < 2 && $check === $rem) || ($rem >= 2 && $check === (11 - $rem));
    }

    public static function isValidLegalEntityId(string $raw): bool
    {
        $code = preg_replace('/\D+/', '', self::normalizeDigits($raw));
        if (strlen($code) !== 11 || preg_match('/^(\d)\1{10}$/', $code)) {
            return false;
        }
        $weights = [29, 27, 23, 19, 17, 29, 27, 23, 19, 17];
        $base = ((int)$code[9]) + 2;
        $sum = 0;
        for ($i = 0; $i < 10; $i++) {
            $sum += (((int)$code[$i]) + $base) * $weights[$i];
        }
        $rem = $sum % 11;
        if ($rem === 10) {
            $rem = 0;
        }
        return $rem === (int)$code[10];
    }

    public static function isValidIranIban(string $raw): bool
    {
        $iban = strtoupper((string)preg_replace('/\s+/', '', self::normalizeDigits($raw)));
        if (!preg_match('/^IR\d{24}$/', $iban)) {
            return false;
        }
        // جابه‌جایی ۴ کاراکتر اول به انتها و تبدیل I=18, R=27 طبق ISO 7064 Mod 97-10
        $rearranged = substr($iban, 4) . '1827' . substr($iban, 2, 2);
        $mod = 0;
        $len = strlen($rearranged);
        for ($i = 0; $i < $len; $i++) {
            $mod = ($mod * 10 + (int)$rearranged[$i]) % 97;
        }
        return $mod === 1;
    }

    public static function generateValidDemoNationalCode(int $seed = 123456789): string
    {
        $nine = str_pad((string)abs($seed % 899999999 + 100000000), 9, '0', STR_PAD_LEFT);
        $sum = 0;
        for ($i = 0; $i < 9; $i++) {
            $sum += ((int)$nine[$i]) * (10 - $i);
        }
        $rem = $sum % 11;
        $check = $rem < 2 ? $rem : (11 - $rem);
        return $nine . (string)$check;
    }

    public static function generateValidDemoLegalId(string $tenDigits = '1010329485'): string
    {
        $ten = str_pad(substr(preg_replace('/\D+/', '', $tenDigits), 0, 10), 10, '0', STR_PAD_LEFT);
        $weights = [29, 27, 23, 19, 17, 29, 27, 23, 19, 17];
        $base = ((int)$ten[9]) + 2;
        $sum = 0;
        for ($i = 0; $i < 10; $i++) {
            $sum += (((int)$ten[$i]) + $base) * $weights[$i];
        }
        $rem = $sum % 11;
        if ($rem === 10) {
            $rem = 0;
        }
        return $ten . (string)$rem;
    }

    public static function generateValidIranIban(string $account22Digits = '0170000000123456789012'): string
    {
        $bban = str_pad(preg_replace('/\D+/', '', $account22Digits), 22, '0', STR_PAD_LEFT);
        $temp = $bban . '182700';
        $mod = 0;
        for ($i = 0, $n = strlen($temp); $i < $n; $i++) {
            $mod = ($mod * 10 + (int)$temp[$i]) % 97;
        }
        $check = str_pad((string)(98 - $mod), 2, '0', STR_PAD_LEFT);
        return 'IR' . $check . $bban;
    }
}
