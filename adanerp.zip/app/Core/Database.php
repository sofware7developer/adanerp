<?php
declare(strict_types=1);

namespace App\Core;

use PDO;
use PDOException;

final class Database
{
    private static bool $healAttempted = false;
    private static ?PDO $pdo = null;

    public static function connection(): PDO
    {
        if (self::$pdo !== null) {
            return self::$pdo;
        }

        $cfg = App::config('db');
        $primaryHost = (string)($cfg['host'] ?? '127.0.0.1');
        $hostsToTry = [$primaryHost];
        if ($primaryHost === '127.0.0.1') {
            $hostsToTry[] = 'localhost';
        } elseif ($primaryHost === 'localhost') {
            $hostsToTry[] = '127.0.0.1';
        }

        $options = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci',
        ];

        $lastException = null;
        foreach ($hostsToTry as $hostCandidate) {
            try {
                $dsn = sprintf(
                    'mysql:host=%s;port=%d;dbname=%s;charset=%s',
                    $hostCandidate,
                    (int)($cfg['port'] ?? 3306),
                    $cfg['database'] ?? 'adanerpdb',
                    $cfg['charset'] ?? 'utf8mb4'
                );
                self::$pdo = new PDO(
                    $dsn,
                    (string)($cfg['username'] ?? 'root'),
                    (string)($cfg['password'] ?? ''),
                    $options
                );
                return self::$pdo;
            } catch (PDOException $e) {
                $lastException = $e;
            }
        }

        throw $lastException ?? new PDOException('Database connection failed.');
    }

    /**
     * بررسی مستقیم اتصال، همگام‌سازی خودکار جداول جدید در دیتابیس‌های قبلی XAMPP/cPanel بدون حذف داده
     * و نمایش صفحه راهنمای Import در صورت خالی بودن کامل دیتابیس (بدون هیچ‌گونه صفحه نصب وب)
     */
    public static function ensureImportedOrRenderGuide(): void
    {
        try {
            $pdo = self::connection();
            $stmt = $pdo->query("SHOW TABLES LIKE 'users'");
            if ($stmt !== false && $stmt->fetchColumn() !== false) {
                self::autoSyncMissingSchemaIfNeeded($pdo);
                self::applyAdanEventsMigration($pdo);
                self::applyAdanInstituteMigration($pdo);
                self::applyAdanInstituteBrandCleanupMigration($pdo);
                self::applyStudentAdmissionsMigration($pdo);
                self::applyIntegrationDisclosureMigration($pdo);
                self::applyEnrollmentCountSyncMigration($pdo);
                self::applyInstallmentPaymentReferenceMigration($pdo);
                self::applyFinanceIntegrityMigration($pdo);
                self::applyInvoicePaymentReferenceMigration($pdo);
                self::applyIntegrationReadinessMigration($pdo);
                self::applyIntegrationReadinessV3Migration($pdo);
                self::applyIntegrationReadinessV4Migration($pdo);
                self::applyIntegrationReadinessV5Migration($pdo);
                self::applyIntegrationReadinessV6Migration($pdo);
                self::clearDefaultEnrollmentApiToken($pdo);
                return;
            }
            $reason = 'اتصال به دیتابیس برقرار است، اما فایل SQL جداول هنوز در این دیتابیس Import نشده است.';
        } catch (\Throwable $e) {
            $reason = 'عدم برقراری اتصال با دیتابیس: ' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8');
        }

        http_response_code(503);
        $cfg = App::config('db');
        $dbName = htmlspecialchars((string)($cfg['database'] ?? 'adanerpdb'), ENT_QUOTES, 'UTF-8');
        $dbHost = htmlspecialchars((string)($cfg['host'] ?? '127.0.0.1'), ENT_QUOTES, 'UTF-8');
        $dbUser = htmlspecialchars((string)($cfg['username'] ?? 'root'), ENT_QUOTES, 'UTF-8');
        echo '<!DOCTYPE html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
            . '<title>آماده‌سازی پایگاه‌داده از طریق Import مستقیم SQL</title>'
            . '<style>body{font-family:Tahoma,sans-serif;background:#0f172a;color:#f8fafc;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;padding:20px}'
            . '.box{max-width:740px;background:#1e293b;border:1px solid #334155;border-radius:18px;padding:30px;line-height:2;box-shadow:0 20px 50px rgba(0,0,0,.4)}'
            . 'code{background:#0f172a;color:#fbbf24;padding:2px 8px;border-radius:6px;direction:ltr;display:inline-block;font-size:13px}'
            . '.err{background:rgba(239,68,68,.15);border:1px solid rgba(239,68,68,.4);color:#fecaca;padding:10px 14px;border-radius:10px;margin:14px 0;font-size:13px}'
            . 'a.btn{display:inline-block;margin-top:16px;background:#4f46e5;color:#fff;text-decoration:none;padding:10px 22px;border-radius:10px;font-weight:bold}</style></head><body>'
            . '<div class="box"><h2 style="margin-top:0;color:#fbbf24">🗄️ راه‌اندازی مستقیم با Import دیتابیس (بدون صفحه نصب)</h2>'
            . '<div class="err">' . $reason . '</div>'
            . '<div><strong>گام ۱ (در XAMPP یک‌کلیکی):</strong> وارد <code>phpMyAdmin</code> شوید، از منوی بالا <strong>Import</strong> را بزنید و فایل <code>database/xampp_oneclick_import.sql</code> را انتخاب و Import کنید.</div>'
            . '<div style="margin-top:8px"><strong>گام ۲ (در هاست cPanel):</strong> در بخش <code>MySQL Databases</code> دیتابیس و کاربر را بسازید، در <code>phpMyAdmin</code> دیتابیس ساخته‌شده را باز کرده و فایل <code>database/full_chamber_edu_xampp_cpanel.sql</code> را Import کنید؛ سپس مشخصات دیتابیس را در <code>config/config.php</code> قرار دهید.</div>'
            . '<div style="margin-top:10px;font-size:12.5px;color:#94a3b8">تنظیمات فعلی در <code>config/config.php</code>: میزبان <code>' . $dbHost . '</code> | دیتابیس <code>' . $dbName . '</code> | کاربر <code>' . $dbUser . '</code></div>'
            . '<a class="btn" href="">🔄 دیتابیس را Import کردم — ورود مستقیم به سامانه</a></div></body></html>';
        exit;
    }

    private static function applyAdanInstituteMigration(PDO $pdo): void
    {
        $marker = $pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_key = 'adan_institute_migration_v3' LIMIT 1");
        $marker->execute();
        if ($marker->fetchColumn() === 'done') {
            return;
        }

        $pdo->beginTransaction();
        $setting = $pdo->prepare('UPDATE system_settings SET setting_value = ? WHERE setting_key = ? AND setting_value = ?');
        $setting->execute(['مؤسسه آموزشی آدان', 'chamber_name', 'اتاق بازرگانی، صنایع، معادن و کشاورزی استان']);
        $setting->execute(['آموزش تخصصی حسابداری و امور مالی', 'unit_name', 'مرکز هوشمند آموزش و توسعه سرمایه انسانی (ناب)']);

        $theme = $pdo->prepare(
            "UPDATE erp_ui_theme_profiles
             SET theme_title = CASE WHEN theme_title = ? THEN ? ELSE theme_title END,
                 brand_org_title = CASE WHEN brand_org_title = ? THEN ? ELSE brand_org_title END,
                 brand_unit_subtitle = CASE WHEN brand_unit_subtitle IN (?, ?) THEN ? ELSE brand_unit_subtitle END,
                 brand_monogram = CASE WHEN brand_monogram = ? THEN ? ELSE brand_monogram END
             WHERE is_active = 1"
        );
        $theme->execute([
            'زمردی و طلایی اتاق بازرگانی (پوسته رسمی پیش‌فرض)', 'سبز آدان (پوسته پیش‌فرض)',
            'اتاق بازرگانی، صنایع، معادن و کشاورزی استان', 'مؤسسه آموزشی آدان',
            'مرکز هوشمند آموزش و توسعه سرمایه انسانی (ناب)',
            'مرکز هوشمند آموزش و توسعه سرمایه انسانی',
            'آموزش تخصصی حسابداری و امور مالی',
            'ناب', 'آدان',
        ]);

        $category = $pdo->prepare(
            'UPDATE course_categories SET title = ?, slug = ?, description = ? WHERE id = ? AND slug = ?'
        );
        $categorySlugExists = $pdo->prepare('SELECT id FROM course_categories WHERE slug = ? AND id <> ? LIMIT 1');
        $categoryRows = [
            ['حسابداری مقدماتی و مالی', 'accounting-basics', 'مبانی حسابداری، ثبت اسناد و چرخه مالی', 1, 'international-trade'],
            ['حسابداری پیشرفته و مدیریت', 'accounting-management', 'حسابداری شرکت‌ها، بهای تمام‌شده و گزارش‌های مدیریتی', 2, 'leadership-mba'],
            ['مالیات، حقوق و دستمزد', 'tax-payroll', 'مالیات، بیمه، حقوق و دستمزد و قوانین مالی', 3, 'finance-tax'],
            ['نرم‌افزار و مهارت‌های مالی', 'accounting-software', 'کاربرد نرم‌افزارهای حسابداری و ابزارهای دیجیتال مالی', 4, 'ai-digital-trade'],
        ];
        foreach ($categoryRows as [$title, $slug, $description, $id, $oldSlug]) {
            $categorySlugExists->execute([$slug, $id]);
            $safeSlug = $categorySlugExists->fetchColumn() === false ? $slug : $oldSlug;
            $category->execute([$title, $safeSlug, $description, $id, $oldSlug]);
        }

        $courses = [
            [1, 'TRD-101', 'دوره جامع مدیریت صادرات، اینکوترمز ۲۰۲۰ و اسناد حمل بین‌المللی', 1, 'ACC-101', 'حسابداری مقدماتی و چرخه کامل حسابداری', 'مقدماتی', 'بدون پیش‌نیاز', 'آشنایی با اصول ثبت اسناد، دفتر روزنامه و کل، تراز آزمایشی و تهیه صورت‌های مالی پایه.'],
            [2, 'TRD-204', 'مدیریت ریسک ارزی، پیمان‌سپاری و رفع تعهد ارزی صادرکنندگان', 1, 'ACC-201', 'حسابداری شرکت‌ها و تهیه صورت‌های مالی', 'میانی', 'آشنایی مقدماتی با حسابداری', 'ثبت رویدادهای مالی شرکت، اصلاح حساب‌ها و تهیه صورت‌های مالی پایان دوره به‌صورت عملی.'],
            [3, 'AID-301', 'هوش مصنوعی کاربردی در بازاریابی صادراتی و کشف خریداران خارجی', 4, 'ACC-301', 'کارگاه عملی نرم‌افزار حسابداری و ثبت اسناد', 'مقدماتی', 'آشنایی با مبانی حسابداری', 'تمرین ثبت اسناد، تعریف سرفصل‌ها، دریافت و پرداخت و تهیه گزارش در نرم‌افزار حسابداری.'],
            [4, 'TAX-110', 'کارگاه جامع سامانه مؤدیان، پایانه‌های فروشگاهی و مالیات ارزش افزوده', 3, 'TAX-110', 'مالیات بر ارزش افزوده و اظهارنامه عملکرد', 'میانی', 'آشنایی مقدماتی با حسابداری', 'آموزش کاربردی اسناد مالیاتی، ارزش افزوده و آماده‌سازی اظهارنامه با پرونده‌های تمرینی.'],
            [5, 'LDR-401', 'برنامه عالی توسعه رهبری و تصمیم‌گیری استراتژیک مدیران صنایع', 2, 'ACC-401', 'حسابداری صنعتی و بهای تمام‌شده', 'پیشرفته', 'گذراندن حسابداری مقدماتی', 'محاسبه بهای تمام‌شده، سربار، نقطه سربه‌سر و تحلیل اطلاعات برای تصمیم‌های مدیریتی.'],
            [6, 'TRD-309', 'مقررات مکانیسم تعدیل کربن مرزی اتحادیه اروپا (CBAM) برای صادرکنندگان فولاد و سیمان', 3, 'TAX-301', 'حقوق و دستمزد، بیمه و مالیات حقوق', 'میانی', 'آشنایی مقدماتی با حسابداری', 'محاسبه حقوق و مزایا، کسورات، بیمه و مالیات حقوق با تمرین‌های ماهانه.'],
            [7, 'AI-47D57', 'دوره جامع استاندارد کربن مرزی اتحادیه اروپا (EU CBAM) و گزارش‌دهی ردپای کربن صنایع صادراتی استان با ۲۴ ساعت کارگاه عملی', 2, 'ACC-501', 'حسابداری پایداری و گزارشگری ردپای کربن', 'پیشرفته', 'آشنایی با حسابداری شرکت‌ها', 'آشنایی با سنجش و گزارشگری هزینه‌های محیط‌زیستی، بهای کربن و اطلاعات پایداری در صورت‌های مالی و گزارش‌های مدیریتی.'],
        ];
        $findCourse = $pdo->prepare('SELECT title, code FROM courses WHERE id = ? LIMIT 1');
        $codeExists = $pdo->prepare('SELECT id FROM courses WHERE code = ? AND id <> ? LIMIT 1');
        $courseUpdate = $pdo->prepare(
            'UPDATE courses SET category_id = ?, code = ?, title = ?, level = ?, member_discount_pct = 0,
             prerequisite_text = ?, reviewer_note = ?, summary = ? WHERE id = ?'
        );
        foreach ($courses as [$id, $oldCode, $oldTitle, $categoryId, $newCode, $newTitle, $level, $prerequisite, $summary]) {
            $findCourse->execute([$id]);
            $current = $findCourse->fetch(PDO::FETCH_ASSOC);
            if (!$current || $current['code'] !== $oldCode || $current['title'] !== $oldTitle) {
                continue;
            }
            $codeExists->execute([$newCode, $id]);
            $safeCode = $codeExists->fetchColumn() === false ? $newCode : $oldCode;
            $courseUpdate->execute([
                $categoryId, $safeCode, $newTitle, $level, $prerequisite,
                'محتوای نمونه مؤسسه آموزشی آدان', $summary, $id,
            ]);
        }

        $classroom = $pdo->prepare('UPDATE classrooms SET name = ?, equipment = ? WHERE id = ? AND name = ?');
        $classroom->execute(['کلاس آموزشی آدان', 'ویدئوپروژکتور، تخته هوشمند و تجهیزات برگزاری کلاس', 1, 'تالار خلیج فارس (طبقه دوم اتاق)']);
        $classroom->execute(['کارگاه نرم‌افزار حسابداری', 'رایانه‌های آموزشی و نرم‌افزارهای حسابداری', 2, 'کارگاه هوشمند دیجیتال و کامپیوتر ابوریحان']);
        $classroom->execute(['کلاس کارگاهی مالی', 'تجهیزات ارائه و تمرین گروهی پرونده‌های مالی', 3, 'سالن VIP مذاکرات بین‌الملل نقش‌جهان']);

        $portal = $pdo->prepare(
            "UPDATE portal_pages
             SET hero_title = ?, hero_subtitle = ?, announcement_bar = ?, featured_boxes_json = ?
             WHERE slug = 'home' AND hero_title IN (?, ?)"
        );
        $portal->execute([
            'آموزشگاه حسابداری آدان',
            'آموزش کاربردی حسابداری، مالیات، حقوق و دستمزد و نرم‌افزارهای مالی؛ از مبانی تا ورود مطمئن به بازار کار.',
            'ثبت‌نام دوره‌های جدید حسابداری و مالی آغاز شد.',
            '["دوره‌های حسابداری و امور مالی","آموزش مالیات و حقوق و دستمزد","کارگاه عملی نرم‌افزار حسابداری","آزمون و گواهی پایان دوره"]',
            'مرکز هوشمند آموزش و توسعه شایستگی‌های تجاری اتاق بازرگانی استان',
            'پورتال جامع آموزش اتاق بازرگانی استان (نسخه اولیه)',
        ]);

        $event = $pdo->prepare(
            'UPDATE events SET title = ?, event_type = ?, speakers = ?, venue = ?
             WHERE id = ? AND title = ? AND event_type = ?'
        );
        $event->execute([
            'کارگاه رایگان ثبت اسناد و چرخه حسابداری',
            'کارگاه آموزشی',
            'مدرس حسابداری آدان',
            'آموزشگاه حسابداری آدان',
            1,
            'نشست تخصصی فرصت‌های صادراتی موافقت‌نامه تجارت آزاد ایران و اوراسیا (ویژه اعضا - رایگان)',
            'نشست هیئت تجاری',
        ]);
        $event->execute([
            'نشست تخصصی حسابداری و گزارشگری مالی',
            'نشست تخصصی',
            'مدرسان و کارشناسان حسابداری',
            'آموزشگاه حسابداری آدان',
            2,
            'همایش سالانه مدیران مالی و چشم‌انداز اقتصادی و ارزی ۱۴۰۶ (دارای تعرفه ثبت‌نام)',
            'همایش استانی',
        ]);

        $finish = $pdo->prepare(
            "INSERT INTO system_settings (setting_key, setting_value, category)
             VALUES ('adan_institute_migration_v2', 'done', 'general'),
                    ('adan_institute_migration_v3', 'done', 'general')
             ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)"
        );
        $finish->execute();
        $pdo->commit();
    }

    private static function applyAdanInstituteBrandCleanupMigration(PDO $pdo): void
    {
        $marker = $pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_key = 'adan_institute_brand_migration_v4' LIMIT 1");
        $marker->execute();
        if ($marker->fetchColumn() === 'done') {
            return;
        }

        $replacements = [
            'مرکز هوشمند آموزش و توسعه سرمایه انسانی (ناب)' => 'آموزش تخصصی حسابداری و امور مالی',
            'مرکز هوشمند آموزش و توسعه سرمایه انسانی' => 'آموزش تخصصی حسابداری و امور مالی',
            'مرکز هوشمند آموزش و توسعه شایستگی‌های تجاری اتاق بازرگانی استان' => 'آموزشگاه حسابداری آدان',
            'مرکز هوشمند آموزش و توسعه شایستگی‌های تجاری مؤسسه آموزشی آدان' => 'آموزشگاه حسابداری آدان',
            'پورتال جامع آموزش اتاق بازرگانی استان (نسخه اولیه)' => 'پورتال آموزش حسابداری آدان (نسخه اولیه)',
            'پورتال جامع آموزش مؤسسه آموزشی آدان (نسخه اولیه)' => 'پورتال آموزش حسابداری آدان (نسخه اولیه)',
            'ماده ۱ قانون اتاق' => 'مأموریت آموزشی مؤسسه',
            'قانون اتاق بازرگانی' => 'چارچوب قوانین مالی و آموزشی',
            'اتاق بازرگانی بین‌المللی' => 'نهاد بین‌المللی ICC',
            'اتاق بازرگانی بین المللی' => 'نهاد بین‌المللی ICC',
            'گواهی مبدأ گواهی‌شده توسط اتاق بازرگانی' => 'گواهی مبدأ تأییدشده توسط مرجع مجاز',
            'گواهی مبدأ اتاق بازرگانی' => 'گواهی مبدأ صادره از مرجع مجاز',
            'مهر اتاق بازرگانی' => 'تأیید مرجع صادرکننده',
            'کارفرمای تاییدشده اتاق' => 'کارفرمای همکار آدان',
            'کارفرمای تایید شده اتاق' => 'کارفرمای همکار آدان',
            'تخفیف ویژه دارندگان کارت بازرگانی و عضویت اتاق' => 'تخفیف ویژه ثبت‌نام گروهی دوره‌های حسابداری',
            'اعتبار کارت بازرگانی یا عضویت سالانه شرکت' => 'اطلاعات سازمان و سابقه همکاری آموزشی',
            'کد عضویت اتاق' => 'شناسه همکاری آموزشی',
            'عضویت اتاق' => 'همکاری آموزشی با آدان',
            'عضو هیئت رئیسه اتاق' => 'منتور ارشد مؤسسه آموزشی آدان',
            'عضو هیئت‌رئیسه اتاق' => 'منتور ارشد مؤسسه آموزشی آدان',
            'سبد آموزشی اتاق' => 'سبد آموزشی آدان',
            'ضوابط حکمرانی اتاق' => 'ضوابط حکمرانی مؤسسه',
            'استاد، مشاور صنعتی و ارزیاب رسمی اتاق' => 'مدرس، مشاور صنعتی و ارزیاب رسمی آدان',
            'کانال رسمی تلگرام اتاق' => 'کانال رسمی آموزشی آدان',
            'ریاست اتاق' => 'مدیریت مؤسسه آدان',
            'دبیرکل اتاق' => 'مدیرکل مؤسسه',
            'هیئت رئیسه اتاق' => 'مدیریت مؤسسه آدان',
            'پورتال اتاق' => 'پورتال آدان',
            'دوره‌های اتاق' => 'دوره‌های آدان',
            'اعضای اتاق بازرگانی' => 'فراگیران آدان',
            'عضو اتاق بازرگانی' => 'دانش‌پذیر آدان',
            'کارکنان اتاق بازرگانی' => 'کارکنان مؤسسه آدان',
            'رئیس و اعضای محترم هیئت‌رئیسه اتاق بازرگانی استان' => 'مدیریت مؤسسه آموزشی آدان',
            'هیئت‌رئیسه اتاق بازرگانی' => 'مدیریت مؤسسه آموزشی آدان',
            'رئیس اتاق بازرگانی' => 'مدیر مؤسسه آموزشی آدان',
            'اتاق‌های بازرگانی' => 'مؤسسات آموزشی',
            'اتاق های بازرگانی' => 'مؤسسات آموزشی',
            'اتاق بازرگانی، صنایع، معادن و کشاورزی استان' => 'مؤسسه آموزشی آدان',
            'اتاق بازرگانی استان' => 'مؤسسه آموزشی آدان',
            'اتاق بازرگانی ایران' => 'مؤسسه آموزشی آدان',
            'اتاق بازرگانی بغداد یا دبی' => 'مؤسسه آموزشی آدان',
            'اتاق بازرگانی بغداد' => 'مؤسسه آموزشی آدان',
            'اعضای اتاق' => 'فراگیران آدان',
            'عضو اتاق' => 'دانش‌پذیر آدان',
            'کارکنان اتاق' => 'کارکنان مؤسسه آدان',
            'رئیس اتاق' => 'مدیر مؤسسه آدان',
            'هیئت‌رئیسه اتاق' => 'مدیریت مؤسسه آدان',
            '#اتاق_بازرگانی_استان' => '#آموزش_حسابداری_آدان',
            '#اتاق_بازرگانی' => '#آموزش_حسابداری_آدان',
            'اتاق_بازرگانی' => 'آموزش_حسابداری_آدان',
            'اتاق بازرگانی' => 'مؤسسه آموزشی آدان',
            'Chamber Smart Edu ERP' => 'Adan Accounting Education ERP',
            'Verified Chamber CV' => 'Adan Verified CV',
            'Chamber CV' => 'Adan CV',
            'ChamberCoin' => 'Adan Learning Rewards',
            'Chamber of Commerce' => 'Adan Accounting Institute',
        ];

        $likeTerms = array_keys($replacements);
        $columns = $pdo->query(
            "SELECT TABLE_NAME, COLUMN_NAME
             FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE()
               AND DATA_TYPE IN ('char', 'varchar', 'tinytext', 'text', 'mediumtext', 'longtext', 'json')
             ORDER BY TABLE_NAME, ORDINAL_POSITION"
        )->fetchAll(PDO::FETCH_ASSOC);

        $pdo->beginTransaction();
        foreach ($columns as $column) {
            $tableName = str_replace('`', '``', (string)$column['TABLE_NAME']);
            $columnName = str_replace('`', '``', (string)$column['COLUMN_NAME']);
            $expression = "`{$columnName}`";
            $replacementParams = [];
            foreach ($replacements as $oldValue => $newValue) {
                $expression = "REPLACE({$expression}, ?, ?)";
                $replacementParams[] = $oldValue;
                $replacementParams[] = $newValue;
            }

            $where = implode(' OR ', array_fill(0, count($likeTerms), "`{$columnName}` LIKE ?"));
            $statement = $pdo->prepare(
                "UPDATE `{$tableName}` SET `{$columnName}` = {$expression} WHERE {$where}"
            );
            $statement->execute(array_merge(
                $replacementParams,
                array_map(static fn(string $term): string => '%' . $term . '%', $likeTerms)
            ));
        }

        $pdo->prepare(
            "UPDATE system_settings
             SET setting_value = 'آموزش تخصصی حسابداری و امور مالی'
             WHERE setting_key = 'unit_name'
               AND setting_value = 'مرکز هوشمند آموزش و توسعه سرمایه انسانی (ناب)'"
        )->execute();
        $pdo->prepare(
            "UPDATE erp_ui_theme_profiles
             SET theme_title = 'سبز آدان (پوسته پیش‌فرض)'
             WHERE theme_title IN (
                 'زمردی و طلایی اتاق بازرگانی (پوسته رسمی پیش‌فرض)',
                 'زمردی و طلایی اتاق بازرگانی (پالت رسمی کلاسیک)'
             )"
        )->execute();

        $finish = $pdo->prepare(
            "INSERT INTO system_settings (setting_key, setting_value, category)
             VALUES ('adan_institute_brand_migration_v4', 'done', 'general')
             ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)"
        );
        $finish->execute();
        $pdo->commit();
    }

    private static function applyAdanEventsMigration(PDO $pdo): void
    {
        $marker = $pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_key = 'adan_events_migration_v4' LIMIT 1");
        $marker->execute();
        if ($marker->fetchColumn() === 'done') {
            return;
        }

        $pdo->exec(
            "ALTER TABLE events MODIFY event_type
             ENUM('همایش استانی','نشست هیئت تجاری','سمینار تخصصی','کارگاه رایگان اعضا',
                  'کارگاه آموزشی','نشست تخصصی','جلسه رفع اشکال')
             DEFAULT 'کارگاه آموزشی',
             MODIFY venue VARCHAR(200) DEFAULT 'آموزشگاه حسابداری آدان'"
        );

        $eventType = $pdo->prepare(
            "UPDATE events SET event_type = ?
             WHERE id = ? AND title = ? AND (event_type = '' OR event_type IS NULL)"
        );
        $eventType->execute(['کارگاه آموزشی', 1, 'کارگاه رایگان ثبت اسناد و چرخه حسابداری']);
        $eventType->execute(['نشست تخصصی', 2, 'نشست تخصصی حسابداری و گزارشگری مالی']);

        $newSampleTicketCode = 'TKT-ADN-1405-7001';
        $ticketCodeExists = $pdo->prepare('SELECT id FROM event_tickets WHERE ticket_code = ? AND id <> 1 LIMIT 1');
        $ticketCodeExists->execute([$newSampleTicketCode]);
        if ($ticketCodeExists->fetchColumn() === false) {
            $sampleTicket = $pdo->prepare(
                'UPDATE event_tickets SET ticket_code = ?, feedback_comment = ?
                 WHERE id = 1 AND event_id = 1 AND ticket_code = ?'
            );
            $sampleTicket->execute([
                $newSampleTicketCode,
                'تمرین ثبت اسناد و چرخه حسابداری کاربردی بود.',
                'TKT-EURASIA-1405-7001',
            ]);
        }

        $finish = $pdo->prepare(
            "INSERT INTO system_settings (setting_key, setting_value, category)
             VALUES ('adan_events_migration_v4', 'done', 'general')
             ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)"
        );
        $finish->execute();
    }

    private static function applyStudentAdmissionsMigration(PDO $pdo): void
    {
        $marker = $pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_key = 'student_admissions_migration_v1' LIMIT 1");
        $marker->execute();
        if ($marker->fetchColumn() === 'done') {
            return;
        }

        $pdo->exec(
            "CREATE TABLE IF NOT EXISTS student_admissions (
                id INT AUTO_INCREMENT PRIMARY KEY,
                full_name VARCHAR(160) NOT NULL,
                mobile VARCHAR(30) NOT NULL,
                course_id INT NOT NULL,
                prior_education VARCHAR(255) NULL,
                status ENUM('submitted','contacted','accepted','rejected','enrolled') DEFAULT 'submitted',
                review_note VARCHAR(500) NULL,
                user_id INT NULL,
                enrollment_id INT NULL,
                invoice_id INT NULL,
                submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_admission_status (status, submitted_at),
                INDEX idx_admission_course (course_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        );
        $finish = $pdo->prepare(
            "INSERT INTO system_settings (setting_key, setting_value, category)
             VALUES ('student_admissions_migration_v1', 'done', 'general')
             ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)"
        );
        $finish->execute();
    }

    private static function applyIntegrationDisclosureMigration(PDO $pdo): void
    {
        $marker = $pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_key = 'integration_disclosure_migration_v1' LIMIT 1");
        $marker->execute();
        if ($marker->fetchColumn() === 'done') {
            return;
        }

        $pdo->exec(
            "UPDATE virtual_class_rooms
             SET online_participants = 0, synced_attendance_count = 0, recording_url = NULL, connection_mode = 'not_configured'
             WHERE connection_mode = 'sandbox_sso'"
        );
        $pdo->exec(
            "UPDATE tax_moadian_packets
             SET tax_unique_id_22 = '', submission_status = 'پیش‌نویس محلی - ارسال نشده'
             WHERE submission_status LIKE '%Sandbox%'"
        );
        $pdo->exec(
            "UPDATE iran_messenger_dispatches
             SET sent_count = 0, delivery_mode = 'ثبت محلی - ارسال نشده'
             WHERE delivery_mode LIKE '%Sandbox%' OR delivery_mode LIKE '%کلید%'"
        );
        $finish = $pdo->prepare(
            "INSERT INTO system_settings (setting_key, setting_value, category)
             VALUES ('integration_disclosure_migration_v1', 'done', 'general')
             ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)"
        );
        $finish->execute();
    }

    private static function applyEnrollmentCountSyncMigration(PDO $pdo): void
    {
        $marker = $pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_key = 'enrollment_count_sync_v1' LIMIT 1");
        $marker->execute();
        if ($marker->fetchColumn() === 'done') {
            return;
        }

        $pdo->beginTransaction();
        try {
            $pdo->exec(
                'UPDATE course_runs r
                 SET enrolled_count = (
                     SELECT COUNT(*) FROM enrollments e
                     WHERE e.run_id = r.id AND e.status = "active"
                 )'
            );
            $finish = $pdo->prepare(
                "INSERT INTO system_settings (setting_key, setting_value, category)
                 VALUES ('enrollment_count_sync_v1', 'done', 'general')
                 ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)"
            );
            $finish->execute();
            $pdo->commit();
        } catch (\Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }
    }

    private static function applyInstallmentPaymentReferenceMigration(PDO $pdo): void
    {
        $marker = $pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_key = 'installment_payment_reference_v1' LIMIT 1");
        $marker->execute();
        if ($marker->fetchColumn() === 'done') {
            return;
        }

        self::ensureSchemaColumn($pdo, 'invoice_installments', 'payment_reference', 'VARCHAR(100) NULL');
        self::ensureSchemaUniqueIndex($pdo, 'invoice_installments', 'uq_installment_payment_reference', 'payment_reference');
        $finish = $pdo->prepare(
            "INSERT INTO system_settings (setting_key, setting_value, category)
             VALUES ('installment_payment_reference_v1', 'done', 'general')
             ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)"
        );
        $finish->execute();
    }

    private static function clearDefaultEnrollmentApiToken(PDO $pdo): void
    {
        $stmt = $pdo->prepare(
            'UPDATE system_settings SET setting_value = ""
             WHERE setting_key = "enrollment_api_token" AND setting_value = ?'
        );
        $stmt->execute(['CHAMBER-API-2026-SECURE-TOKEN']);
    }

    private static function applyFinanceIntegrityMigration(PDO $pdo): void
    {
        $marker = $pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_key = 'finance_integrity_v1' LIMIT 1");
        $marker->execute();
        if ($marker->fetchColumn() === 'done') {
            return;
        }

        self::ensureSchemaColumn($pdo, 'invoices', 'refund_payment_reference', 'VARCHAR(100) NULL');
        self::ensureSchemaUniqueIndex($pdo, 'invoices', 'uq_invoice_refund_payment_reference', 'refund_payment_reference');
        $pdo->exec(
            "UPDATE payment_transactions
             SET is_reconciled = 0, reconciled_at = NULL
             WHERE gateway_mode = 'sandbox_hmac_signed'"
        );
        $finish = $pdo->prepare(
            "INSERT INTO system_settings (setting_key, setting_value, category)
             VALUES ('finance_integrity_v1', 'done', 'general')
             ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)"
        );
        $finish->execute();
    }

    private static function applyInvoicePaymentReferenceMigration(PDO $pdo): void
    {
        $marker = $pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_key = 'invoice_payment_reference_v1' LIMIT 1");
        $marker->execute();
        if ($marker->fetchColumn() === 'done') {
            return;
        }

        self::ensureSchemaColumn($pdo, 'invoices', 'payment_reference', 'VARCHAR(100) NULL');
        self::ensureSchemaUniqueIndex($pdo, 'invoices', 'uq_invoice_payment_reference', 'payment_reference');
        $finish = $pdo->prepare(
            "INSERT INTO system_settings (setting_key, setting_value, category)
             VALUES ('invoice_payment_reference_v1', 'done', 'general')
             ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)"
        );
        $finish->execute();
    }

    private static function ensureSchemaColumn(PDO $pdo, string $table, string $column, string $definition): void
    {
        $check = static fn() => $pdo->query(
            'SHOW COLUMNS FROM `' . $table . '` LIKE ' . $pdo->quote($column)
        );
        $stmt = $check();
        if ($stmt !== false && $stmt->fetchColumn() !== false) {
            return;
        }

        try {
            $pdo->exec('ALTER TABLE `' . $table . '` ADD COLUMN `' . $column . '` ' . $definition);
        } catch (PDOException $e) {
            $stmt = $check();
            if ($stmt === false || $stmt->fetchColumn() === false) {
                throw $e;
            }
        }
    }

    private static function ensureSchemaUniqueIndex(PDO $pdo, string $table, string $index, string $column): void
    {
        $check = static fn() => $pdo->query(
            'SHOW INDEX FROM `' . $table . '` WHERE Key_name = ' . $pdo->quote($index)
        );
        $stmt = $check();
        if ($stmt !== false && $stmt->fetchColumn() !== false) {
            return;
        }

        try {
            $pdo->exec('ALTER TABLE `' . $table . '` ADD UNIQUE KEY `' . $index . '` (`' . $column . '`)');
        } catch (PDOException $e) {
            $stmt = $check();
            if ($stmt === false || $stmt->fetchColumn() === false) {
                throw $e;
            }
        }
    }

    private static function ensureSchemaIndex(PDO $pdo, string $table, string $index, string $columns): void
    {
        $check = $pdo->prepare(
            'SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ?'
        );
        $check->execute([$table, $index]);
        if ((int)$check->fetchColumn() > 0) {
            return;
        }

        try {
            $pdo->exec('CREATE INDEX `' . $index . '` ON `' . $table . '` (' . $columns . ')');
        } catch (PDOException $e) {
            $check->execute([$table, $index]);
            if ((int)$check->fetchColumn() === 0) {
                throw $e;
            }
        }
    }

    private static function applyIntegrationReadinessMigration(PDO $pdo): void
    {
        $marker = $pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_key = 'integration_readiness_v2' LIMIT 1");
        $marker->execute();
        if ($marker->fetchColumn() === 'done') {
            return;
        }

        $pdo->exec(
            "UPDATE social_media_posts
             SET publish_status = CASE
                     WHEN publish_status IN ('published', 'simulated_published') THEN 'simulated_published'
                     WHEN publish_status IN ('scheduled', 'scheduled_local') THEN 'scheduled_local'
                     ELSE 'draft_local'
                 END,
                 impressions_count = 0, engagements_count = 0, clicks_count = 0,
                 leads_generated = 0, enrollments_converted = 0, spend_rial = 0, revenue_rial = 0"
        );
        $pdo->exec(
            "UPDATE marketing_campaigns
             SET conversion_a_pct = NULL, conversion_b_pct = NULL,
                 status = CASE WHEN status = 'sent_simulated' THEN 'scheduled' ELSE status END"
        );
        $pdo->exec(
            "UPDATE sso_pki_logs
             SET user_full_name = 'کاربر محلی', national_code = '', mobile_number = '',
                 shahkar_status = 'شبیه‌سازی محلی - شاهکار و امضای PKI متصل نیست'"
        );
        $pdo->exec(
            "UPDATE security_soc_telemetry
             SET client_ip = '0.0.0.0', geo_and_device = 'ارزیابی دستی/محلی',
                 threat_classification = 'نمونه - پایش زنده متصل نیست',
                 mitigation_action = 'شبیه‌سازی - هیچ نشست یا IP قرنطینه نشده'"
        );
        $pdo->exec(
            "UPDATE proctoring_events
             SET watermark_stamp = 'DEMO-LOCAL | حسگر و DRM فعال نیست',
                 reviewer_decision = 'ثبت دستی/نمونه - سلامت آزمون احراز نشده'"
        );
        $finish = $pdo->prepare(
            "INSERT INTO system_settings (setting_key, setting_value, category)
             VALUES ('integration_readiness_v2', 'done', 'general')
             ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)"
        );
        $finish->execute();
    }

    private static function applyIntegrationReadinessV3Migration(PDO $pdo): void
    {
        $marker = $pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_key = 'integration_readiness_v3' LIMIT 1");
        $marker->execute();
        if ($marker->fetchColumn() === 'done') {
            return;
        }

        $pdo->exec(
            "UPDATE virtual_class_rooms
             SET online_participants = 0, synced_attendance_count = 0,
                 recording_url = NULL, connection_mode = 'not_configured'"
        );
        $pdo->exec(
            "UPDATE tax_moadian_packets
             SET tax_unique_id_22 = '', submission_status = 'پیش‌نویس محلی - ارسال نشده'"
        );
        $pdo->exec(
            "UPDATE iran_messenger_dispatches
             SET sent_count = 0, delivery_mode = 'ثبت محلی - ارسال نشده'"
        );
        $pdo->exec(
            "UPDATE ocr_financial_scans
             SET moadian_vat_status = 'رکورد محلی/قدیمی - وضعیت مالیاتی تأیید نشده'"
        );
        $finish = $pdo->prepare(
            "INSERT INTO system_settings (setting_key, setting_value, category)
             VALUES ('integration_readiness_v3', 'done', 'general')
             ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)"
        );
        $finish->execute();
    }

    private static function applyIntegrationReadinessV4Migration(PDO $pdo): void
    {
        $marker = $pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_key = 'integration_readiness_v4' LIMIT 1");
        $marker->execute();
        if ($marker->fetchColumn() === 'done') {
            return;
        }

        $pdo->exec(
            "UPDATE ocr_financial_scans
             SET detected_amount_rial = 0, detected_sayad_or_ref = '', detected_iban = '',
                 checksum_verified = 0, booked_voucher_no = '',
                 moadian_vat_status = 'نتایج قدیمی پاک‌سازی شد؛ OCR یا ثبت مالی انجام نشده'
             WHERE moadian_vat_status = 'رکورد محلی/قدیمی - وضعیت مالیاتی تأیید نشده'"
        );
        $finish = $pdo->prepare(
            "INSERT INTO system_settings (setting_key, setting_value, category)
             VALUES ('integration_readiness_v4', 'done', 'general')
             ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)"
        );
        $finish->execute();
    }

    private static function applyIntegrationReadinessV5Migration(PDO $pdo): void
    {
        $marker = $pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_key = 'integration_readiness_v5' LIMIT 1");
        $marker->execute();
        if ($marker->fetchColumn() === 'done') {
            return;
        }

        $pdo->exec(
            "UPDATE national_bus_inquiries
             SET trace_code = CONCAT('LOCAL-OLD-', id),
                 identifier_queried = 'ذخیره نشد (حریم خصوصی)',
                 math_checksum_valid = 0,
                 gateway_execution_mode = 'رکورد قدیمی پاک‌سازی شد؛ استعلام انجام‌نشده',
                 response_summary = 'پاسخ قدیمی پاک‌سازی شد؛ استعلام بیرونی انجام نشده',
                 customs_duty_pct = NULL"
        );
        $pdo->exec(
            "UPDATE verifiable_credential_blocks
             SET w3c_standard_version = 'چکیده محلی؛ استاندارد یا امضای W3C تأیید نشده'"
        );
        $finish = $pdo->prepare(
            "INSERT INTO system_settings (setting_key, setting_value, category)
             VALUES ('integration_readiness_v5', 'done', 'general')
             ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)"
        );
        $finish->execute();
    }

    private static function applyIntegrationReadinessV6Migration(PDO $pdo): void
    {
        $marker = $pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_key = 'integration_readiness_v6' LIMIT 1");
        $marker->execute();
        if ($marker->fetchColumn() === 'done') {
            return;
        }

        $pdo->exec(
            "ALTER TABLE webhooks_and_jobs
             MODIFY status ENUM('active','queued','completed','failed','draft_local') DEFAULT 'draft_local',
             MODIFY last_response VARCHAR(255) DEFAULT 'پیش‌نویس محلی؛ ارسال بیرونی فعال نیست'"
        );
        $pdo->exec(
            "UPDATE webhooks_and_jobs
             SET status = 'draft_local', last_response = 'پیش‌نویس محلی؛ هیچ درخواست بیرونی ارسال نشده',
                 target_url_or_handler = CASE
                     WHEN target_url_or_handler LIKE '%chamber.local%' THEN 'https://example.invalid/adan-webhook'
                     ELSE target_url_or_handler
                 END
             WHERE entry_kind = 'webhook'"
        );
        $pdo->exec(
            "UPDATE rag_documents
             SET title = 'ضوابط حضور و ارزیابی دوره‌های آدان',
                 chunk_text = 'برای دریافت گواهی پایان دورهٔ آموزشگاه آدان، حضور حداقل ۸۰ درصد ساعات دوره و کسب حداقل نمرهٔ قبولی ۷۰ از ۱۰۰ لازم است. وضعیت گواهی فقط در سوابق داخلی آموزشگاه قابل مشاهده است و این گواهی جایگزین مجوز یا تأییدیهٔ مرجع رسمی نیست.'
             WHERE title = 'ضوابط حدنصاب حضور و صدور گواهی‌نامه معتبر QR'"
        );
        $finish = $pdo->prepare(
            "INSERT INTO system_settings (setting_key, setting_value, category)
             VALUES ('integration_readiness_v6', 'done', 'general')
             ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)"
        );
        $finish->execute();
    }

    /**
     * فهرست جداول حیاتی که هسته سامانه و صفحات فراگیر به آن‌ها تکیه می‌کنند.
     * اگر در دیتابیس ایمپورت‌شده‌ی کاربر (XAMPP/cPanel) حتی یکی از این جداول نبود،
     * ساختار باقی‌مانده به‌صورت Idempotent و بدون حذف داده‌ها ساخته می‌شود.
     */
    private const CRITICAL_TABLES = [
        'users', 'courses', 'enrollments', 'course_runs', 'social_media_posts', 'bi_dashboards',
        'oa_letters', 'oa_letter_referrals', 'oa_admin_requests', 'academic_terms_calendar', 'erp_ui_theme_profiles', 'tms_learning_paths',
        'tms_pricing_scenarios', 'lms_interactive_quizzes', 'lms_lessons', 'lms_learner_notes',
        'lms_ai_study_cards', 'lms_assignments', 'lms_discussions', 'marketing_campaigns',
        'market_surveys_insights', 'exam_attempts', 'certificates', 'erp_helpdesk_tickets',
        'competency_assessments', 'academic_attendance_gradebook',
        'voice_report_archive', 'learner_ai_telemetry',
    ];

    /**
     * ★ v26.8 — ستون‌های افزوده‌شده در نسخه‌های تازه: روی دیتابیس‌های قدیمی‌تر به‌صورت
     * Idempotent ساخته می‌شوند تا نصب با ایمپورت نسخه قبلی هم بدون خطا بالا بیاید.
     */
    private const CRITICAL_COLUMNS = [
        'oa_letters' => [
            'sender_user_id' => 'INT NULL DEFAULT NULL',
            'recipient_user_id' => 'INT NULL DEFAULT NULL',
            'reply_to_letter_id' => 'INT NULL DEFAULT NULL',
            'recipient_status' => "VARCHAR(40) NOT NULL DEFAULT 'خوانده‌نشده'",
            'read_at' => 'DATETIME NULL DEFAULT NULL',
            'archived_at' => 'DATETIME NULL DEFAULT NULL',
            'external_recipient' => 'VARCHAR(160) NULL DEFAULT NULL',
        ],
        'oa_letter_referrals' => [
            'from_user_id' => 'INT NULL DEFAULT NULL',
            'to_user_id' => 'INT NULL DEFAULT NULL',
        ],
        'oa_admin_requests' => [
            'requester_user_id' => 'INT NULL DEFAULT NULL',
        ],
        'webhooks_and_jobs' => [
            'last_run_at' => 'DATETIME NULL DEFAULT NULL',
        ],
        'micro_spaced_flashcards' => [
            'owner_user_id' => 'INT NULL DEFAULT NULL',
            'source_kind'   => "VARCHAR(30) NOT NULL DEFAULT 'catalog'",
            'source_ref'    => 'VARCHAR(190) NULL DEFAULT NULL',
        ],
    ];

    /**
     * فهرست ستون‌های جاافتاده در جداول حیاتی (بدون شکست در صورت نبود دسترسی DDL)
     */
    public static function missingColumns(?PDO $pdo = null): array
    {
        $gaps = [];
        try {
            $pdo = $pdo ?? self::connection();
            foreach (self::CRITICAL_COLUMNS as $table => $cols) {
                foreach (array_keys($cols) as $col) {
                    try {
                        $stmt = $pdo->prepare(
                            'SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?'
                        );
                        $stmt->execute([$table, $col]);
                        if ((int)$stmt->fetchColumn() === 0) {
                            $gaps[$table][] = $col;
                        }
                    } catch (\Throwable) {
                        // جدول در دسترس نیست — ترمیم جداول خودش این را جبران می‌کند
                    }
                }
            }
        } catch (\Throwable) {
            return [];
        }
        return $gaps;
    }

    /**
     * افزودن ستون‌های جاافتاده بدون هیچ آسیبی به داده‌های موجود
     */
    public static function healMissingColumns(): bool
    {
        $did = false;
        try {
            $pdo = self::connection();
            foreach (self::missingColumns($pdo) as $table => $cols) {
                foreach ($cols as $col) {
                    $ddl = (self::CRITICAL_COLUMNS[$table][$col] ?? 'TEXT NULL');
                    try {
                        $pdo->exec('ALTER TABLE `' . $table . '` ADD COLUMN `' . $col . '` ' . $ddl);
                        $did = true;
                    } catch (\Throwable) {
                        // MySQL فاقد ADD COLUMN IF NOT EXISTS است؛ تلاش دوباره بی‌ضرر است
                    }
                }
            }
        } catch (\Throwable) {
            return $did;
        }
        return $did;
    }

    /**
     * آیا همه جداول حیاتی در دیتابیس فعلی وجود دارند؟ (یک پرس‌وجوی سبک و ایندکس‌شده)
     */
    public static function missingCriticalTables(?PDO $pdo = null): array
    {
        try {
            $pdo = $pdo ?? self::connection();
            $in = implode(',', array_fill(0, count(self::CRITICAL_TABLES), '?'));
            $stmt = $pdo->prepare(
                "SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN ($in)"
            );
            $stmt->execute(self::CRITICAL_TABLES);
            $found = array_map('strval', $stmt->fetchAll(\PDO::FETCH_COLUMN));
            return array_values(array_diff(self::CRITICAL_TABLES, $found));
        } catch (\Throwable) {
            return [];
        }
    }

    /**
     * ترمیم خودکار ساختار: جداول جاافتاده را از روی schema.sql + seed.sql می‌سازد (INSERT IGNORE — بدون خرابی داده).
     */
    public static function healMissingTables(): bool
    {
        try {
            $pdo = self::connection();
            $pdo->exec('SET FOREIGN_KEY_CHECKS = 0');
            foreach (['database/schema.sql', 'database/seed.sql'] as $relSql) {
                $sqlPath = App::rootPath($relSql);
                if (is_file($sqlPath)) {
                    self::runMultiStatementSql($pdo, (string)file_get_contents($sqlPath));
                }
            }
            self::healMissingColumns();
            $pdo->exec('SET FOREIGN_KEY_CHECKS = 1');
            $_SESSION['_schema_v26_ready'] = 1;
            return true;
        } catch (\Throwable) {
            return false;
        }
    }

    private static function autoSyncMissingSchemaIfNeeded(PDO $pdo): void
    {
        try {
            // ★ v26.6 — تشخیص مبتنی بر «مجموعه جداول» به‌جای چند جدول قدیمی:
            // در دیتابیس‌هایی که جداول نسخه‌های جدید (مثل tms_learning_paths یا lms_interactive_quizzes)
            // در آن‌ها وجود ندارد، خطای «Table doesn't exist» در صفحات فراگیر دیده می‌شد.
            $missing = self::missingCriticalTables($pdo);
            $needsSync = !empty($missing);

            if ($needsSync) {
                self::healMissingTables();
            }

            // ★ v26.8 — هم‌گام‌سازی ستون‌های افزوده‌شده (مثل کارت‌های لایتنر شخصی فراگیر)
            if (!empty(self::missingColumns($pdo))) {
                self::healMissingColumns();
            }
            self::ensureSchemaIndex($pdo, 'oa_letters', 'idx_oa_letters_recipient_inbox', '`recipient_user_id`, `archived_at`, `id`');
            self::ensureSchemaIndex($pdo, 'oa_letters', 'idx_oa_letters_sender_outbox', '`sender_user_id`, `id`');
            self::ensureSchemaIndex($pdo, 'oa_letter_referrals', 'idx_oa_referrals_assignee', '`to_user_id`, `referral_status`');
            self::ensureSchemaIndex($pdo, 'oa_letter_referrals', 'idx_oa_referrals_letter', '`letter_id`, `id`');

            // پاک‌سازی خودکار عناوین قدیمی در دیتابیس‌های قبلاً ایمپورت‌شده
            $pdo->exec("UPDATE erp_system_settings SET setting_label = REPLACE(setting_label, 'AvalAI', 'AI') WHERE setting_label LIKE '%AvalAI%'");
            $_SESSION['_schema_v26_ready'] = 1;
        } catch (\Throwable) {
            // ادامه ایمن در صورت محدودیت دسترسی DDL کاربر دیتابیس
        }
    }

    private static function runMultiStatementSql(PDO $pdo, string $rawSql): void
    {
        $lines = preg_split("/\r\n|\n|\r/", $rawSql) ?: [];
        $buf = '';
        foreach ($lines as $line) {
            $trim = trim($line);
            if ($trim === '' || str_starts_with($trim, '--') || str_starts_with($trim, '#')) {
                continue;
            }
            $buf .= $line . "\n";
            if (str_ends_with($trim, ';')) {
                try {
                    $pdo->exec($buf);
                } catch (\Throwable) {
                }
                $buf = '';
            }
        }
        if (trim($buf) !== '') {
            try {
                $pdo->exec($buf);
            } catch (\Throwable) {
            }
        }
    }

    public static function fetchAll(string $sql, array $params = []): array
    {
        $stmt = self::connection()->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /**
     * ★ v26.6 — خواندن مقاوم: اگر جدولی در دیتابیس کاربر وجود نداشت، یک‌بار ساختار ترمیم و پرس‌وجو تکرار می‌شود؛
     * در نهایت به‌جای خطای SQL، نتیجه خالی برگردانده می‌شود تا صفحه کاربر (مثلاً فراگیر) هرگز نشکند.
     */
    public static function fetchAllSafe(string $sql, array $params = [], array $default = []): array
    {
        try {
            $stmt = self::connection()->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll();
        } catch (\Throwable $e) {
            if (!str_contains(strtolower($e->getMessage()), 'exist') || self::$healAttempted) {
                return $default;
            }
            self::$healAttempted = true;
            if (self::healMissingTables()) {
                try {
                    $stmt = self::connection()->prepare($sql);
                    $stmt->execute($params);
                    return $stmt->fetchAll();
                } catch (\Throwable) {
                    return $default;
                }
            }
            return $default;
        }
    }

    public static function fetchOneSafe(string $sql, array $params = []): ?array
    {
        foreach (self::fetchAllSafe($sql, $params, []) as $row) {
            return $row;
        }
        return null;
    }

    public static function scalarSafe(string $sql, array $params = [], mixed $default = 0): mixed
    {
        try {
            $stmt = self::connection()->prepare($sql);
            $stmt->execute($params);
            $val = $stmt->fetchColumn();
            return $val !== false && $val !== null ? $val : $default;
        } catch (\Throwable) {
            return $default;
        }
    }

    public static function fetchOne(string $sql, array $params = []): ?array
    {
        $stmt = self::connection()->prepare($sql);
        $stmt->execute($params);
        $row = $stmt->fetch();
        return $row !== false ? $row : null;
    }

    public static function scalar(string $sql, array $params = [], mixed $default = 0): mixed
    {
        $stmt = self::connection()->prepare($sql);
        $stmt->execute($params);
        $val = $stmt->fetchColumn();
        return $val !== false && $val !== null ? $val : $default;
    }

    public static function execute(string $sql, array $params = []): int
    {
        $stmt = self::connection()->prepare($sql);
        $stmt->execute($params);
        return $stmt->rowCount();
    }

    public static function insert(string $sql, array $params = []): int
    {
        $pdo = self::connection();
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return (int)$pdo->lastInsertId();
    }

    public static function setting(string $key, string $default = ''): string
    {
        try {
            $row = self::fetchOne('SELECT setting_value FROM system_settings WHERE setting_key = ?', [$key]);
            return $row !== null ? (string)$row['setting_value'] : $default;
        } catch (PDOException) {
            return $default;
        }
    }

    public static function saveSetting(string $key, string $value, string $category = 'general'): void
    {
        self::execute(
            'INSERT INTO system_settings (setting_key, setting_value, category) VALUES (?, ?, ?)
             ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), category = VALUES(category)',
            [$key, $value, $category]
        );
    }

    /**
     * اجرای امن فایل‌های SQL چنددستوری در وب‌اینستالر XAMPP و cPanel
     */
    public static function importSqlFile(PDO $pdo, string $filePath): int
    {
        $raw = (string)file_get_contents($filePath);
        $lines = preg_split('/\R/', $raw) ?: [];
        $clean = [];
        foreach ($lines as $line) {
            $trimmed = ltrim($line);
            if ($trimmed === '' || str_starts_with($trimmed, '--')) {
                continue;
            }
            $clean[] = $line;
        }
        $sql = implode("\n", $clean);

        $statements = [];
        $buffer = '';
        $inString = false;
        $quoteChar = '';
        $len = strlen($sql);

        for ($i = 0; $i < $len; $i++) {
            $ch = $sql[$i];
            if ($inString) {
                if ($ch === '\\' && ($i + 1) < $len) {
                    $buffer .= $ch . $sql[++$i];
                    continue;
                }
                if ($ch === $quoteChar) {
                    $inString = false;
                }
                $buffer .= $ch;
            } else {
                if ($ch === '\'' || $ch === '"') {
                    $inString = true;
                    $quoteChar = $ch;
                    $buffer .= $ch;
                } elseif ($ch === ';') {
                    $stmt = trim($buffer);
                    if ($stmt !== '') {
                        $statements[] = $stmt;
                    }
                    $buffer = '';
                } else {
                    $buffer .= $ch;
                }
            }
        }
        if (trim($buffer) !== '') {
            $statements[] = trim($buffer);
        }

        $executed = 0;
        foreach ($statements as $statement) {
            $pdo->exec($statement);
            $executed++;
        }
        return $executed;
    }
}
