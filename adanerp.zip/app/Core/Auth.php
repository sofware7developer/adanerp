<?php
declare(strict_types=1);

namespace App\Core;

final class Auth
{
    public const ROLE_LABELS = [
        'super_admin'     => 'مدیر مؤسسه آدان',
        'training_expert' => 'مدیر آموزشگاه',
        'finance_manager' => 'مسئول مالی و شهریه',
        'crm_manager'     => 'مسئول پذیرش و ارتباط با دانشجویان',
        'instructor'      => 'مدرس حسابداری',
        'org_rep'         => 'کارشناس آموزش و ثبت‌نام',
        'learner'         => 'دانشجو',
    ];

    public static function user(): ?array
    {
        if (empty($_SESSION['user_id'])) {
            return null;
        }
        static $cachedUser = null;
        static $cachedId = null;
        $uid = (int)$_SESSION['user_id'];
        if ($cachedUser !== null && $cachedId === $uid) {
            return $cachedUser;
        }
        $row = Database::fetchOne(
            'SELECT u.*, o.name AS org_name, o.chamber_member_code, o.annual_quota_hours, o.used_quota_hours
             FROM users u
             LEFT JOIN organizations o ON o.id = u.org_id
             WHERE u.id = ? LIMIT 1',
            [$uid]
        );
        if (!$row) {
            unset($_SESSION['user_id']);
            return null;
        }
        $cachedId = $uid;
        $cachedUser = $row;
        return $row;
    }

    public static function id(): int
    {
        $u = self::user();
        return $u ? (int)$u['id'] : 0;
    }

    public static function role(): string
    {
        $u = self::user();
        return $u ? (string)$u['role'] : 'guest';
    }

    public static function roleLabel(?string $role = null): string
    {
        $r = $role ?? self::role();
        return self::ROLE_LABELS[$r] ?? $r;
    }

    public static function check(): bool
    {
        return self::user() !== null;
    }

    public static function hasRole(array|string $roles): bool
    {
        $u = self::user();
        if (!$u) {
            return false;
        }
        if ($u['role'] === 'super_admin') {
            return true;
        }
        $list = is_array($roles) ? $roles : [$roles];
        return in_array($u['role'], $list, true);
    }

    /**
     * بررسی قفل موقت ورود (Brute-Force Protection)
     */
    public static function isLockedOut(string $username, string $ip): array
    {
        $sec = App::config('security');
        $max = (int)($sec['max_login_attempts'] ?? 5);
        $mins = (int)($sec['lockout_minutes'] ?? 15);

        $count = (int)Database::scalar(
            "SELECT COUNT(*) FROM login_attempts
             WHERE (identifier = ? OR ip_address = ?)
               AND is_success = 0
               AND attempted_at >= DATE_SUB(NOW(), INTERVAL {$mins} MINUTE)",
            [$username, $ip]
        );

        return [
            'locked' => $count >= $max,
            'failed_count' => $count,
            'max' => $max,
            'minutes' => $mins,
        ];
    }

    public static function attempt(string $username, string $password): array
    {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
        $lock = self::isLockedOut($username, $ip);
        if ($lock['locked']) {
            self::audit('Auth', 'LOGIN_BLOCKED_LOCKOUT', 'user', null, ['username' => $username]);
            return [
                'ok' => false,
                'message' => 'حساب یا نشانی شما به دلیل ' . Jalali::digits($lock['failed_count'])
                    . ' تلاش ناموفق به مدت ' . Jalali::digits($lock['minutes']) . ' دقیقه به صورت موقت قفل شده است.',
            ];
        }

        $user = Database::fetchOne(
            'SELECT * FROM users WHERE username = ? LIMIT 1',
            [$username]
        );

        if (!$user || !password_verify($password, (string)$user['password_hash'])) {
            Database::execute(
                'INSERT INTO login_attempts (identifier, ip_address, is_success) VALUES (?, ?, 0)',
                [$username, $ip]
            );
            $newFailed = $lock['failed_count'] + 1;
            $rem = max(0, $lock['max'] - $newFailed);
            self::audit('Auth', 'LOGIN_FAILED', 'user', $user ? (int)$user['id'] : null, ['username' => $username]);
            return [
                'ok' => false,
                'message' => 'نام کاربری یا گذرواژه نادرست است. تلاش مجاز باقی‌مانده قبل از قفل موقت: ' . Jalali::digits($rem),
            ];
        }

        if ($user['status'] !== 'active') {
            return ['ok' => false, 'message' => 'وضعیت این حساب کاربری غیرفعال یا مسدود است.'];
        }

        session_regenerate_id(true);
        $_SESSION['user_id'] = (int)$user['id'];

        Database::execute(
            'DELETE FROM login_attempts WHERE identifier = ? AND is_success = 0',
            [$username]
        );
        Database::execute(
            'INSERT INTO login_attempts (identifier, ip_address, is_success) VALUES (?, ?, 1)',
            [$username, $ip]
        );
        Database::execute('UPDATE users SET last_login_at = NOW() WHERE id = ?', [(int)$user['id']]);
        self::audit('Auth', 'LOGIN_SUCCESS', 'user', (int)$user['id'], ['username' => $user['username']]);

        return ['ok' => true, 'user' => $user];
    }

    public static function logout(): void
    {
        if (self::check()) {
            self::audit('Auth', 'LOGOUT', 'user', self::id(), []);
        }
        $_SESSION = [];
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_destroy();
        }
    }

    public static function audit(string $module, string $action, ?string $entityType = null, ?int $entityId = null, array $details = []): void
    {
        try {
            $u = self::user();
            Database::execute(
                'INSERT INTO audit_logs (user_id, user_role, module, action, entity_type, entity_id, details_json, ip_address)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                [
                    $u ? (int)$u['id'] : null,
                    $u ? (string)$u['role'] : 'guest',
                    $module,
                    $action,
                    $entityType,
                    $entityId,
                    json_encode($details, JSON_UNESCAPED_UNICODE),
                    $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
                ]
            );
        } catch (\Throwable) {
            // جلوگیری از توقف سامانه در خطای ثانویه لاگ
        }
    }
}
