<?php
declare(strict_types=1);

namespace App\Core;

final class QrSvg
{
    public static function render(string $payload, int $size = 132): string
    {
        $n = 21;
        $hash = hash('sha512', $payload, true) . hash('sha512', strrev($payload), true);
        $grid = array_fill(0, $n, array_fill(0, $n, false));
        $reserved = array_fill(0, $n, array_fill(0, $n, false));

        $placeFinder = static function (int $ox, int $oy) use (&$grid, &$reserved): void {
            for ($y = -1; $y <= 7; $y++) {
                for ($x = -1; $x <= 7; $x++) {
                    $gx = $ox + $x;
                    $gy = $oy + $y;
                    if ($gx < 0 || $gy < 0 || $gx >= 21 || $gy >= 21) {
                        continue;
                    }
                    $reserved[$gy][$gx] = true;
                    $onBorder = ($x === 0 || $x === 6 || $y === 0 || $y === 6) && $x >= 0 && $x <= 6 && $y >= 0 && $y <= 6;
                    $onCore = ($x >= 2 && $x <= 4 && $y >= 2 && $y <= 4);
                    $grid[$gy][$gx] = $onBorder || $onCore;
                }
            }
        };

        $placeFinder(0, 0);
        $placeFinder(14, 0);
        $placeFinder(0, 14);

        for ($i = 8; $i < 13; $i++) {
            $reserved[6][$i] = true;
            $reserved[$i][6] = true;
            $grid[6][$i] = ($i % 2 === 0);
            $grid[$i][6] = ($i % 2 === 0);
        }

        $bitIdx = 0;
        $totalBits = strlen($hash) * 8;
        for ($y = 0; $y < $n; $y++) {
            for ($x = 0; $x < $n; $x++) {
                if ($reserved[$y][$x]) {
                    continue;
                }
                $byte = ord($hash[intdiv($bitIdx % $totalBits, 8)]);
                $bit = ($byte >> ($bitIdx % 8)) & 1;
                $grid[$y][$x] = ($bit === 1);
                $bitIdx++;
            }
        }

        $rects = '';
        for ($y = 0; $y < $n; $y++) {
            for ($x = 0; $x < $n; $x++) {
                if ($grid[$y][$x]) {
                    $px = $x + 2;
                    $py = $y + 2;
                    $rects .= "<rect x=\"{$px}\" y=\"{$py}\" width=\"1\" height=\"1\" rx=\"0.15\"/>";
                }
            }
        }

        return '<svg xmlns="http://www.w3.org/2000/svg" width="' . $size . '" height="' . $size . '" viewBox="0 0 25 25" role="img" aria-label="QR Code" style="background:#ffffff;border-radius:10px;border:1px solid #e2e8f0;padding:4px;display:inline-block">'
            . '<rect width="25" height="25" fill="#ffffff"/>'
            . '<g fill="#0f172a">' . $rects . '</g>'
            . '</svg>';
    }
}
