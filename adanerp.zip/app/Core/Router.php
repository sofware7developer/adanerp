<?php
declare(strict_types=1);

namespace App\Core;

final class Router
{
    private array $routes = [];

    public function any(string $route, array $handler, array $roles = [], bool $public = false, bool $csrfExempt = false): void
    {
        $clean = trim($route, '/');
        $this->routes[$clean] = [
            'handler' => $handler,
            'roles' => $roles,
            'public' => $public,
            'csrfExempt' => $csrfExempt,
        ];
    }

    public function dispatch(string $route): void
    {
        $clean = trim($route, '/');
        if (!isset($this->routes[$clean])) {
            http_response_code(404);
            $this->renderErrorPage(404, 'مسیر درخواستی یافت نشد', 'صفحهٔ موردنظر در سامانهٔ آموزشگاه حسابداری آدان وجود ندارد یا جابه‌جا شده است.');
            return;
        }

        $meta = $this->routes[$clean];

        if (!$meta['public'] && !Auth::check()) {
            header('Location: ' . App::url('login'));
            exit;
        }

        if (!$meta['public'] && !empty($meta['roles']) && !\App\Services\EnterpriseSettingsIamService::checkDynamicRouteAccess(Auth::id(), Auth::role(), $clean, $meta['roles'])) {
            Auth::audit('RBAC', 'ACCESS_DENIED_403', 'route', null, ['route' => $clean]);
            http_response_code(403);
            $policyNote = App::rbacNote(Auth::role());
            $this->renderErrorPage(
                403,
                'عدم دسترسی بر اساس نقش سازمانی (RBAC 403)',
                'نقش کاربری فعلی شما (' . Auth::roleLabel() . ') مجوز مشاهده یا انجام عملیات در این بخش را ندارد.'
                . ($policyNote !== '' ? ' شرح وظایف نقش شما: ' . $policyNote : '')
                . ' اگر لازم است این بخش برای شما باز شود، مدیرکل از «کاربران، نقش‌ها و سطوح دسترسی» مجوز موردی ثبت می‌کند.'
            );
            return;
        }

        // ★ v26.9 — سیاست زیرماژول‌ها و فرمان‌ها (tabs / actions) در همین تنگنا اعمال می‌شود،
        //             پس پنهان‌سازی با CSS/JS نیست و ارسال مستقیم فرم هم رد می‌شود.
        $rbacRole = Auth::check() ? (string)Auth::role() : '';
        if ($rbacRole !== '' && $rbacRole !== 'super_admin') {
            $allowedTabs = App::rbacTabs($rbacRole, $clean);
            if ($allowedTabs !== null) {
                foreach (['GET', 'POST'] as $src) {
                    $key = strtolower($src);
                    if ($key === 'get') {
                        if (isset($_GET['tab']) && !in_array((string)$_GET['tab'], $allowedTabs, true)) {
                            $_GET['tab'] = $allowedTabs[0];
                            $_REQUEST['tab'] = $allowedTabs[0];
                        }
                    } elseif (isset($_POST['tab']) && !in_array((string)$_POST['tab'], $allowedTabs, true)) {
                        $_POST['tab'] = $allowedTabs[0];
                        $_REQUEST['tab'] = $allowedTabs[0];
                    }
                }
            }
        }
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && $rbacRole !== '' && $rbacRole !== 'super_admin') {
            $postedAction = trim((string)($_POST['action'] ?? ''));
            $needRoles = App::rbacActionRoles($clean, $postedAction);
            if ($needRoles !== null && !in_array($rbacRole, $needRoles, true)) {
                Auth::audit('RBAC', 'ACTION_DENIED_BY_POLICY_403', 'route', null, [
                    'route'  => $clean,
                    'action' => $postedAction,
                    'role'   => $rbacRole,
                    'note'   => 'اقدام خارج از سطح دسترسی نقش (سیاست v26.9)',
                ]);
                $wantsJson = str_contains((string)($_SERVER['HTTP_ACCEPT'] ?? ''), 'application/json')
                    || strtolower((string)($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '')) === 'xmlhttprequest';
                if ($wantsJson) {
                    http_response_code(403);
                    header('Content-Type: application/json; charset=utf-8');
                    echo json_encode([
                        'ok' => false,
                        'error' => 'action_not_allowed',
                        'message' => 'این فرمان برای نقش سازمانی «' . Auth::roleLabel() . '» تعریف نشده است.',
                    ], JSON_UNESCAPED_UNICODE);
                    return;
                }
                $_SESSION['_flash'] = [
                    'type' => 'danger',
                    'message' => 'دسترسی ۴۰۳ — فرمان «' . $postedAction . '» خارج از سطح دسترسی نقش شماست و ثبت نشد.',
                ];
                header('Location: ' . App::url($clean));
                exit;
            }
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$meta['csrfExempt'] && !Csrf::verify()) {
            $_SESSION['_flash'] = ['type' => 'danger', 'message' => 'خطای امنیتی CSRF: توکن فرم نامعتبر بود.'];
            header('Location: ' . App::url($clean));
            exit;
        }

        [$class, $method] = $meta['handler'];
        $instance = new $class();
        $instance->$method();
    }

    private function renderErrorPage(int $code, string $title, string $desc): void
    {
        $back = App::url(Auth::check() ? 'dashboard' : 'login');
        echo '<!DOCTYPE html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
            . '<title>' . e($title) . '</title><link rel="stylesheet" href="' . asset('css/app.css') . '"></head>'
            . '<body class="public-bg" style="display:flex;align-items:center;justify-content:center;min-height:100vh;padding:24px">'
            . '<div class="card" style="max-width:540px;text-align:center;padding:40px">'
            . '<div class="badge badge-danger" style="font-size:15px;margin-bottom:14px">کد وضعیت ' . fa($code) . '</div>'
            . '<h2 style="margin-bottom:12px">' . e($title) . '</h2>'
            . '<p class="muted" style="line-height:1.9;margin-bottom:24px">' . e($desc) . '</p>'
            . '<a class="btn btn-primary" href="' . e($back) . '">بازگشت به داشبورد اصلی</a>'
            . '</div></body></html>';
    }
}
