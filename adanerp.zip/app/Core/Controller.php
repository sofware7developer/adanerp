<?php
declare(strict_types=1);

namespace App\Core;

abstract class Controller
{
    protected function render(string $__viewName, array $__viewVars = [], string $__layoutName = 'app'): void
    {
        $__viewFile = App::rootPath('app/Views/' . $__viewName . '.php');
        if (!is_file($__viewFile)) {
            http_response_code(500);
            echo 'View not found: ' . e($__viewName);
            return;
        }

        $currentUser = Auth::user();
        $chamberName = Database::setting('chamber_name', 'مؤسسه آموزشی آدان');
        if ($chamberName === 'اتاق بازرگانی، صنایع، معادن و کشاورزی استان') {
            $chamberName = 'مؤسسه آموزشی آدان';
        }
        $unitName = Database::setting('unit_name', 'آموزش تخصصی حسابداری و امور مالی');
        if ($unitName === 'مرکز هوشمند آموزش و توسعه سرمایه انسانی (ناب)') {
            $unitName = 'آموزش تخصصی حسابداری و امور مالی';
        }
        $phasesMeta = App::phases();
        $currentRoute = App::currentRoute();
        $flash = $_SESSION['_flash'] ?? null;
        unset($_SESSION['_flash']);

        $notifications = [];
        $unreadCount = 0;
        if ($currentUser) {
            $notifications = Database::fetchAll(
                'SELECT * FROM notifications
                 WHERE user_id = ? OR target_role = ? OR target_role IS NULL
                 ORDER BY id DESC LIMIT 6',
                [(int)$currentUser['id'], (string)$currentUser['role']]
            );
            $unreadCount = count(array_filter($notifications, static fn($n) => (int)$n['is_read'] === 0));
        }

        extract($__viewVars, EXTR_OVERWRITE);

        ob_start();
        require $__viewFile;
        $content = ob_get_clean();

        $__layoutFile = App::rootPath('app/Views/layouts/' . $__layoutName . '.php');
        require $__layoutFile;
    }

    protected function flash(string $type, string $message): void
    {
        $_SESSION['_flash'] = ['type' => $type, 'message' => $message];
    }

    protected function redirect(string $route, array|string $query = [], string $flashType = 'success'): never
    {
        if (is_string($query)) {
            if ($query !== '') {
                $this->flash($flashType, $query);
            }
            header('Location: ' . App::url($route));
            exit;
        }
        header('Location: ' . App::url($route, $query));
        exit;
    }

    protected function json(array $payload, int $status = 200): never
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        exit;
    }

    protected function requireCsrf(): void
    {
        if (!Csrf::verify()) {
            $this->flash('danger', 'نشست امنیتی (CSRF Token) منقضی یا نامعتبر است. لطفاً دوباره تلاش کنید.');
            $this->redirect(App::currentRoute());
        }
    }

    /**
     * نقش‌های کاری سازمان (هر چیزی جز فراگیر) — برای گاردهای اقدامات مدیریتی/مدرسی
     */
    protected const STAFF_ROLES = ['super_admin', 'training_expert', 'finance_manager', 'crm_manager', 'instructor', 'org_rep'];

    /**
     * ★ v26.6 — اصل «فراگیر فقط سرویس خود»: اقدامات مدیریتی و مدرسی (ثبت حضور و غیاب، نمره و کارنامه،
     * تصویب دوره، قیمت‌گذاری، ایجاد کاربر/نقش، پاسخ رسمی میز خدمت، تولید محتوای درس و ...) برای نقش فراگیر
     * پیش از هر اثر روی دیتابیس با پاسخ ۴۰۳ متوقف و در لاگ ممیزی ثبت می‌شود.
     */
    protected function denyLearnerActions(string $action, array $staffOnlyActions, string $backRoute = ''): void
    {
        if ($action === '' || !in_array($action, $staffOnlyActions, true)) {
            return;
        }
        if ((string)Auth::role() !== 'learner') {
            return;
        }
        try {
            Auth::audit('RBAC', 'LEARNER_STAFF_ACTION_BLOCKED', 'route', null, [
                'route'  => App::currentRoute(),
                'action' => $action,
                'note'   => 'تلاش فراگیر برای انجام اقدام مدیریتی/مدرسی',
            ]);
        } catch (\Throwable) {
            // لاگ ممیزی هرگز نباید جریان امنیتی را بشکند
        }
        $this->requireRole(self::STAFF_ROLES, $backRoute);
    }

    /**
     * گارد دسترسی سخت‌گیرانه سمت سرور (RBAC سطح عملیات): اگر نقش کاربر فعلی در فهرست مجاز نبود،
     * پاسخ HTTP 403 برگردانده و از اجرای عملیات (حتی با ارسال مستقیم POST) جلوگیری می‌شود.
     */
    protected function requireRole(array $roles, string $backRoute = ''): void
    {
        if (Auth::hasRole($roles)) {
            return;
        }
        $back = App::url($backRoute !== '' ? $backRoute : (App::currentRoute() ?: 'dashboard'));
        http_response_code(403);
        echo '<!DOCTYPE html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>عدم دسترسی ۴۰۳</title></head>'
            . '<body style="font-family:Tahoma,\'Vazirmatn\',sans-serif;display:flex;align-items:center;justify-content:center;min-height:90vh;background:#f6f8fb;margin:0;padding:24px">'
            . '<div style="max-width:540px;text-align:center;background:#fff;border:1px solid #e2e8f0;border-radius:16px;padding:34px;box-shadow:0 10px 30px rgba(15,23,42,.06)">'
            . '<div style="display:inline-block;background:#fee2e2;color:#b91c1c;border-radius:999px;padding:6px 14px;font-weight:700;margin-bottom:12px">کد وضعیت ۴۰۳ — RBAC</div>'
            . '<h2 style="margin:0 0 10px;color:#0f172a;font-size:19px">دسترسی به این عملیات برای نقش سازمانی شما مجاز نیست</h2>'
            . '<p style="color:#475569;line-height:1.9;margin:0 0 18px">این بخش/عملیات مدیریتی محدود به نقش‌های مشخصی است و تلاش برای اجرای آن در سامانه ثبت و ممیزی شد. در صورت نیاز، مدیرکل آموزش می‌تواند از «کاربران، نقش‌ها و سطوح دسترسی» مجوز موردی صادر کند.</p>'
            . '<a href="' . e($back) . '" style="display:inline-block;background:#0f766e;color:#fff;text-decoration:none;border-radius:10px;padding:10px 18px;font-weight:700">بازگشت به پیشخوان</a>'
            . '</div></body></html>';
        exit;
    }

    protected function exportCsv(string $filename, array $headers, array $rows): never
    {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        $out = fopen('php://output', 'wb');
        // افزودن UTF-8 BOM برای نمایش صحیح حروف فارسی در اکسل ویندوز
        fwrite($out, "\xEF\xBB\xBF");
        fputcsv($out, $headers);
        foreach ($rows as $row) {
            fputcsv($out, $row);
        }
        fclose($out);
        exit;
    }
}
