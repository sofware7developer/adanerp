<?php
declare(strict_types=1);

use App\Core\App;
use App\Core\Csrf;
use App\Core\Jalali;

function e(mixed $val): string
{
    return htmlspecialchars((string)($val ?? ''), ENT_QUOTES, 'UTF-8');
}

function url(string $route = '', array $query = []): string
{
    return App::url($route, $query);
}

/**
 * ★ v26.8 — امضای نسخه دارایی‌ها: نگارش اپ + زمان آخرین تغییر فایل.
 * تا مرورگر/CDN هرگز اسکریپت یا استایل قدیمی (مثلاً موتور پخش گفتارِ اصلاح‌شده) را نگه ندارد.
 */
/**
 * ★ v26.8.2 — رشته امن برای تزریق در JS داخل attribute یا <script>.
 * دو کاری که json_encode خام نمی‌کند:
 *  ۱) خروجی json_encode را یک‌بار یک‌بار با ENT_QUOTES خنثی می‌کند تا هیچ کوتیشنی،
 *     مقدار onclick="…" را نشکند (خطای `Uncaught SyntaxError: Unexpected end of input` از همین‌جا می‌آمد).
 *  ۲) اگر داده نامعتبر UTF-8 باشد json_encode همان‌جا false می‌دهد و خروجی خالی، جاوااسکریپت را
 *     نصفه می‌گذارد؛ پیش از کدگذاری، متن سالم‌سازی می‌شود تا هرگز رشته‌ای نیمه تولید نشود.
 */
function js_attr(string|int|float|null $val): string
{
    $raw = (string)($val ?? '');
    if (!preg_match('//u', $raw)) {
        $raw = (string)@iconv('UTF-8', 'UTF-8//IGNORE', $raw);
    }
    $json = json_encode($raw, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG);
    if (!is_string($json)) {
        return '&quot;&quot;';
    }
    // نکته حیاتی: خودِ JSON با ENT_QUOTES escapes می‌شود؛ وگرنه کوتیشن بیرونیِ رشته JSON،
    // مقدار onclick="…" را می‌شکند (همان ریشه‌ی Unexpected end of input).
    return htmlspecialchars($json, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/** معادل js_attr برای آرایه/شیء (داده‌های ساختاریافته) — خروجی همیشه JSON معتبر و HTML-امن است */
function js_json(mixed $val): string
{
    $json = json_encode($val, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
    if (is_string($json)) {
        return $json;
    }
    // داده نامعتبر UTF-8 داخل آرایه: عنصر‌به‌عنصر اصلاح می‌شود تا بلوک اسکریپت هرگز نشکند
    $clean = static function ($v) use (&$clean) {
        if (is_array($v)) { return array_map($clean, $v); }
        if (is_string($v) && !preg_match('//u', $v)) { return (string)@iconv('UTF-8', 'UTF-8//IGNORE', $v); }
        return $v;
    };
    $json = json_encode($clean($val), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
    return is_string($json) ? $json : 'null';
}

function asset_ver(string $relPath): string
{
    $ver = (string)(App::config('app')['version'] ?? '');
    $num = (string)preg_replace('/[^0-9.]+/', '', $ver);
    $num = trim($num, '.') ?: '1';
    // App::basePath مسیر وب است؛ ریشه فایل‌سیستم از App::rootPath (و در نبودش از محل همین فایل) خوانده می‌شود
    $root = method_exists(App::class, 'rootPath') ? (string)App::rootPath() : dirname(__DIR__, 2);
    $file = rtrim($root, '/') . '/assets/' . ltrim($relPath, '/');
    clearstatcache(true, $file);
    $mtime = is_file($file) ? (string)filemtime($file) : '0';
    return $num . '.' . $mtime;
}

function asset(string $path): string
{
    return App::asset($path);
}

function fa(string|int|float|null $val): string
{
    return Jalali::digits((string)($val ?? '0'));
}

function rial(int|float|string|null $amount): string
{
    return Jalali::rial($amount ?? 0);
}

function csrf_field(): string
{
    return Csrf::field();
}
