<?php
declare(strict_types=1);

namespace App\Core;

final class App
{
    private static array $config = [];
    private static array $phases = [];
    private static ?array $rbacPolicy = null;
    private static string $rootPath = '';

    public static function boot(string $rootPath): void
    {
        self::$rootPath = rtrim($rootPath, '/\\');
        $cfgFile = self::$rootPath . '/config/config.php';
        if (!is_file($cfgFile)) {
            $cfgFile = self::$rootPath . '/config/config.sample.php';
        }
        self::$config = require $cfgFile;
        self::$phases = require self::$rootPath . '/config/phases.php';
        $rbacFile = self::$rootPath . '/config/rbac_policy.php';
        self::$rbacPolicy = is_file($rbacFile) ? (array)require $rbacFile : [];

        date_default_timezone_set((string)(self::$config['app']['timezone'] ?? 'Asia/Tehran'));

        if (session_status() === PHP_SESSION_NONE) {
            $sessName = (string)(self::$config['security']['session_name'] ?? 'CHAMBER_EDU_SESS');
            $isHttps = (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off')
                || (strtolower((string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')) === 'https')
                || ((int)($_SERVER['SERVER_PORT'] ?? 80) === 443);

            session_name($sessName);
            session_set_cookie_params([
                'httponly' => true,
                'secure'   => $isHttps,
                'samesite' => $isHttps ? 'None' : 'Lax',
                'path'     => '/',
            ]);
            session_start();

            if ($isHttps && !headers_sent()) {
                header(
                    sprintf(
                        'Set-Cookie: %s=%s; Path=/; Secure; HttpOnly; SameSite=None; Partitioned',
                        rawurlencode(session_name()),
                        rawurlencode(session_id())
                    ),
                    false
                );
            }
        }
    }

    public static function rootPath(string $sub = ''): string
    {
        return $sub === '' ? self::$rootPath : self::$rootPath . '/' . ltrim($sub, '/\\');
    }

    public static function config(?string $section = null, mixed $default = []): mixed
    {
        if ($section === null) {
            return self::$config;
        }
        return self::$config[$section] ?? $default;
    }

    public static function phases(): array
    {
        return self::$phases;
    }

    /**
     * ★ v26.9 — سیاست تفکیک نقش‌ها (config/rbac_policy.php) در یک نگاه.
     * اگر فایل سیاست نبود، همهچیز مثل قبل کار می‌کند (آرایۀ خالی = وتویی وجود ندارد).
     */
    public static function rbacPolicy(): array
    {
        if (self::$rbacPolicy === null) {
            $f = self::$rootPath . '/config/rbac_policy.php';
            self::$rbacPolicy = is_file($f) ? (array)require $f : [];
        }
        return self::$rbacPolicy;
    }

    /** آیا سیاست، این نقش را از این مسیر منویی بیرون انداخته است؟ (null = نظر ندارد) */
    public static function rbacRouteVeto(string $role, string $route): ?bool
    {
        $pol = self::rbacPolicy();
        if ($role === 'super_admin' || $route === '') {
            return null;
        }
        $denies = (array)($pol['deny'] ?? []);
        if (isset($denies[$route]) && in_array($role, (array)$denies[$route], true)) {
            return true;
        }
        $allow = (array)($pol['allow'] ?? []);
        if (isset($allow[$role])) {
            $moduleRoutes = [];
            foreach ((self::phases()['modules'] ?? []) as $m) {
                if (isset($m['route'])) {
                    $moduleRoutes[(string)$m['route']] = true;
                }
            }
            if (isset($moduleRoutes[$route]) && !in_array($route, (array)$allow[$role], true)) {
                return true;
            }
        }
        $excl = (array)($allow['training_expert_exclude'] ?? []);
        if ($role === 'training_expert' && isset($moduleRoutes[$route]) && in_array($route, $excl, true)) {
            return true;
        }
        return null;
    }

    /** تب‌های مجاز این نقش در این ماژول (null = سیاستی نیست، همان رفتار همیشگی) */
    public static function rbacTabs(?string $role, string $route): ?array
    {
        if ($role === null || $role === 'super_admin') {
            return null;
        }
        $tabs = (array)(self::rbacPolicy()['tabs'] ?? []);
        $per = (array)($tabs[$route] ?? []);
        if (!isset($per[$role])) {
            return null;
        }
        $list = array_values(array_filter((array)$per[$role], 'is_string'));
        return $list === [] ? null : $list;
    }

    /** نقش‌های مجاز یک اکشن/فرمان در یک ماژول (null = محدودیتی ثبت نشده) */
    public static function rbacActionRoles(string $route, string $action): ?array
    {
        if ($action === '') {
            return null;
        }
        $acts = (array)(self::rbacPolicy()['actions'] ?? []);
        $per = (array)($acts[$route] ?? []);
        if ($per === []) {
            return null;
        }
        if (isset($per[$action]) && is_array($per[$action])) {
            return $per[$action] === [] ? null : $per[$action];
        }
        if (isset($per['*']) && is_array($per['*'])) {
            return $per['*'] === [] ? null : $per['*'];
        }
        return null;
    }

    /** توضیح سیاست برای صفحۀ ۴۰۳ و راهنما */
    public static function rbacNote(string $role): string
    {
        return (string)(self::rbacPolicy()['notes'][$role] ?? '');
    }

    /**
     * بخش‌ها و آیتم‌های منوی ساده‌شده فراگیر (فقط دوره و امور مرتبط با یادگیری او)
     */
    public static function learnerNavSections(): array
    {
        return self::$phases['learner_nav'] ?? [];
    }

    /**
     * فهرست کامل مسیرهای مجاز فراگیر = آیتم‌های منو + مسیرهای کمکی چاپ و استعلام
     */
    public static function learnerAllowedRoutes(): array
    {
        static $cache = null;
        if ($cache !== null) {
            return $cache;
        }
        $routes = [];
        foreach (self::learnerNavSections() as $section) {
            foreach ($section['items'] as $item) {
                $routes[] = $item['route'];
            }
        }
        foreach ((self::$phases['learner_aux_routes'] ?? []) as $aux) {
            $routes[] = $aux;
        }
        $cache = $routes;
        return $cache;
    }

    /**
     * آیا این مسیر برای نقش فراگیر مجاز است؟ (مسیرهای API و عمومی مستثنا هستند)
     */
    public static function isLearnerRouteAllowed(string $route): bool
    {
        if ($route === '' || str_starts_with($route, 'api/') || $route === 'logout') {
            return true;
        }
        return in_array($route, self::learnerAllowedRoutes(), true);
    }

    public static function basePath(): string
    {
        $documentRoot = realpath((string)($_SERVER['DOCUMENT_ROOT'] ?? ''));
        $appRoot = realpath(self::$rootPath);
        if ($documentRoot !== false && $appRoot !== false) {
            $documentRoot = rtrim(str_replace('\\', '/', $documentRoot), '/');
            $appRoot = rtrim(str_replace('\\', '/', $appRoot), '/');
            $documentRootLength = strlen($documentRoot);

            if (
                strncasecmp($appRoot, $documentRoot, $documentRootLength) === 0
                && ($appRoot === $documentRoot || ($appRoot[$documentRootLength] ?? '') === '/')
            ) {
                $relativePath = trim(substr($appRoot, $documentRootLength), '/');
                return $relativePath === '' ? '' : '/' . $relativePath;
            }
        }

        $scriptName = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '/index.php');
        $dir = rtrim(dirname($scriptName), '/.');
        return $dir === '' ? '' : $dir;
    }

    /**
     * نقشه مسیر → پیکربندی ماژول (برای یافتن نقش‌های استاتیک هر مسیر)
     */
    private static function modulesByRoute(): array
    {
        static $map = null;
        if ($map !== null) {
            return $map;
        }
        $map = [];
        foreach ((self::$phases['modules'] ?? []) as $mod) {
            if (!empty($mod['route'])) {
                $map[$mod['route']] = $mod;
            }
        }
        return $map;
    }

    /**
     * آیا کاربر فعلی مجاز است این مسیر را باز کند؟
     * دقیقاً همان موتور دسترسی روتر و منو (شامل قفل نقش فراگیر و استثنای‌های IAM) —
     * تا هیچ لینک میان‌بری در هدر، فوتر، راهنمای صفحه یا صفحات چاپی به خطای 403 ختم نشود.
     */
    public static function canViewRoute(string $route): bool
    {
        if ($route === '' || $route === 'login' || $route === 'logout' || str_starts_with($route, 'api/')) {
            return true;
        }
        $uid = (int)(\App\Core\Auth::id() ?: 0);
        $role = (string)\App\Core\Auth::role();
        if ($uid <= 0 || $role === '') {
            return true; // زمینه عمومی/بدون نشست (مثلاً صفحه چاپی بدون لاگین)
        }
        $staticRoles = self::modulesByRoute()[$route]['roles'] ?? [];
        return \App\Services\EnterpriseSettingsIamService::checkDynamicRouteAccess($uid, $role, $route, $staticRoles);
    }

    /**
     * لینک میان‌بر امن: اگر مسیر برای نقش فعلی مجاز نباشد، خروجی خالی برمی‌گردد.
     */
    public static function safeLink(string $route, string $label, string $class = 'btn btn-outline btn-sm'): string
    {
        if (!self::canViewRoute($route)) {
            return '';
        }
        return '<a class="' . e($class) . '" href="' . e(self::url($route)) . '">' . $label . '</a>';
    }

    public static function url(string $route = '', array $query = []): string
    {
        $base = self::basePath();
        $parts = explode('?', trim($route, '/'), 2);
        $clean = $parts[0];
        $routeQuery = [];
        if (isset($parts[1])) {
            parse_str($parts[1], $routeQuery);
        }

        if ($clean === '') {
            $path = $base . '/';
            $query = array_merge($routeQuery, $query);
        } else {
            $path = $base . '/index.php';
            $query = ['r' => $clean] + array_merge($routeQuery, $query);
        }

        $path = preg_replace('#/+#', '/', $path) ?: '/';
        if ($query !== []) {
            $path .= '?' . http_build_query($query);
        }

        return $path;
    }

    public static function asset(string $relPath): string
    {
        $base = self::basePath();
        $path = $base . '/assets/' . ltrim($relPath, '/');
        return preg_replace('#/+#', '/', $path) ?: '/assets/' . ltrim($relPath, '/');
    }

    public static function currentRoute(): string
    {
        if (!empty($_GET['r']) && is_string($_GET['r'])) {
            return trim($_GET['r'], '/');
        }
        $uri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
        $base = self::basePath();
        if ($base !== '' && str_starts_with($uri, $base)) {
            $uri = substr($uri, strlen($base));
        }
        if (str_starts_with($uri, '/index.php')) {
            $uri = substr($uri, strlen('/index.php'));
        }
        return trim($uri, '/');
    }
}
