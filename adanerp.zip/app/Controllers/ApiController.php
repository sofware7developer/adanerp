<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\App;
use App\Core\Auth;
use App\Core\Controller;
use App\Core\Csrf;
use App\Core\Database;
use App\Services\AvalAiService;

final class ApiController extends Controller
{
    /**
     * ★ v26.9 — نگهبان مشترک وب‌سرویس‌های درون‌سامانه‌ای.
     * این مسیرها از shell لاگین‌شده صدا زده می‌شوند؛ پس (الف) ناشناس ۴۰۱ می‌گیرد،
     * (ب) اگر نقش‌های مجاز داده شود، خارج از آن‌ها ۴۰۳ می‌گیرد،
     * (پ) و اگر مسیر ماژولِ درخواستی برای نقش باز نباشد، همان‌جا رد می‌شود.
     */
    private function guardInternalApi(array $roles = []): int
    {
        if (!\App\Core\Auth::check()) {
            $this->json(['ok' => false, 'error' => 'auth_required', 'message' => 'این سرویس فقط برای کاربران واردشده به سامانه است.'], 401);
        }
        $role = (string)\App\Core\Auth::role();
        if ($roles !== [] && !in_array($role, $roles, true) && $role !== 'super_admin') {
            $this->json(['ok' => false, 'error' => 'role_not_allowed', 'message' => 'این سرویس برای نقش شما فعال نیست.'], 403);
        }
        return (int)\App\Core\Auth::id();
    }

    private function guardModuleAccess(string $route): void
    {
        if ($route === '' || \App\Core\App::currentRoute() === $route) {
            return;
        }
        $modules = [];
        foreach ((\App\Core\App::phases()['modules'] ?? []) as $m) {
            if (isset($m['route'])) {
                $modules[(string)$m['route']] = (array)($m['roles'] ?? []);
            }
        }
        if (!isset($modules[$route])) {
            return;
        }
        if (!\App\Services\EnterpriseSettingsIamService::checkDynamicRouteAccess(
            (int)\App\Core\Auth::id(), (string)\App\Core\Auth::role(), $route, $modules[$route])) {
            $this->json(['ok' => false, 'error' => 'module_not_allowed', 'message' => 'دسترسی به داده‌های این بخش برای نقش شما مجاز نیست.'], 403);
        }
    }

    public function search(): void
    {
        $uid = $this->guardInternalApi();
        $q = trim((string)($_GET['q'] ?? ''));
        if (mb_strlen($q) < 2) {
            $this->json(['items' => []]);
        }

        $synonyms = [
            'ترخیص' => 'صادرات',
            'کوتاژ' => 'صادرات',
            'گمرک' => 'صادرات',
            'ارز' => 'صادرات',
            'نیما' => 'صادرات',
            'مالیات' => 'مؤدیان',
            'چک' => 'مالی',
            'کارت' => 'بازرگانی',
        ];
        $expanded = $q;
        foreach ($synonyms as $k => $v) {
            if (mb_stripos($q, $k) !== false) {
                $expanded = $v;
                break;
            }
        }

        $items = [];
        $phases = App::phases();
        $uidForSearch = (int)(Auth::id() ?: 0);
        $roleForSearch = (string)Auth::role();
        foreach ($phases['modules'] as $m) {
            $hay = $m['title'] . ' ' . $m['badge'];
            // جست‌وجوی سراسری دقیقاً با همان موتور دسترسی منو و روتر هم‌راستاست
            // تا هیچ نتیجه‌ای که کاربر اجازه باز کردنش را ندارد (مثلاً برای فراگیر) نمایش داده نشود.
            $canOpenModule = \App\Services\EnterpriseSettingsIamService::checkDynamicRouteAccess(
                $uidForSearch,
                $roleForSearch,
                (string)$m['route'],
                $m['roles'] ?? []
            );
            if ($canOpenModule && (mb_stripos($hay, $q) !== false || mb_stripos($hay, $expanded) !== false)) {
                $items[] = [
                    'type' => 'ماژول سامانه',
                    'title' => $m['title'],
                    'subtitle' => 'حوزه تخصصی: ' . $m['badge'],
                    'url' => App::url($m['route']),
                ];
            }
        }

        $like = '%' . $q . '%';
        $likeExp = '%' . $expanded . '%';
        foreach (Database::fetchAll('SELECT code, title, level FROM courses WHERE title LIKE ? OR title LIKE ? OR code LIKE ? LIMIT 4', [$like, $likeExp, $like]) as $c) {
            $items[] = [
                'type' => 'دوره آموزشی',
                'title' => $c['title'],
                'subtitle' => 'کد دوره: ' . $c['code'] . ' | سطح: ' . $c['level'],
                'url' => App::url('tms'),
            ];
        }

        foreach (Database::fetchAll('SELECT title, content_type FROM lms_lessons WHERE title LIKE ? OR title LIKE ? LIMIT 3', [$like, $likeExp]) as $les) {
            $items[] = [
                'type' => 'درس LMS',
                'title' => $les['title'],
                'subtitle' => 'نوع محتوا: ' . $les['content_type'],
                'url' => App::url('lms'),
            ];
        }

        if (\App\Services\EnterpriseSettingsIamService::checkDynamicRouteAccess($uidForSearch, $roleForSearch, 'instructors', ['super_admin', 'training_expert', 'finance_manager', 'instructor'])) {
            foreach (Database::fetchAll('SELECT u.full_name, ip.specialties FROM instructor_profiles ip JOIN users u ON u.id = ip.user_id WHERE u.full_name LIKE ? OR ip.specialties LIKE ? OR ip.specialties LIKE ? LIMIT 3', [$like, $like, $likeExp]) as $ins) {
                $items[] = [
                    'type' => 'استاد اتاق',
                    'title' => $ins['full_name'],
                    'subtitle' => 'تخصص: ' . $ins['specialties'],
                    'url' => App::url('instructors'),
                ];
            }
        }

        if (\App\Services\EnterpriseSettingsIamService::checkDynamicRouteAccess($uidForSearch, $roleForSearch, 'library', ['super_admin', 'training_expert', 'instructor', 'org_rep', 'learner'])) {
            foreach (Database::fetchAll('SELECT title, category FROM library_items WHERE title LIKE ? OR title LIKE ? LIMIT 3', [$like, $likeExp]) as $bk) {
                $items[] = [
                    'type' => 'مرکز دانش و کتابخانه',
                    'title' => $bk['title'],
                    'subtitle' => 'دسته: ' . $bk['category'],
                    'url' => App::url('library'),
                ];
            }
        }

        foreach (Database::fetchAll('SELECT serial_code, status FROM certificates WHERE serial_code LIKE ? LIMIT 3', [$like]) as $cert) {
            $items[] = [
                'type' => 'گواهی‌نامه QR',
                'title' => 'استعلام سریال ' . $cert['serial_code'],
                'subtitle' => 'وضعیت: ' . ($cert['status'] === 'valid' ? 'معتبر در سوابق آدان' : 'لغوشده در سوابق آدان'),
                'url' => App::url('verify', ['code' => $cert['serial_code']]),
            ];
        }

        if (Auth::hasRole(['super_admin', 'finance_manager', 'training_expert'])) {
            foreach (Database::fetchAll('SELECT invoice_number, item_description FROM invoices WHERE invoice_number LIKE ? OR item_description LIKE ? LIMIT 2', [$like, $like]) as $inv) {
                $items[] = [
                    'type' => 'فاکتور رسمی',
                    'title' => 'صورتحساب ' . $inv['invoice_number'],
                    'subtitle' => $inv['item_description'],
                    'url' => App::url('finance'),
                ];
            }
        }

        if (Auth::hasRole(['super_admin', 'crm_manager', 'training_expert'])) {
            foreach (Database::fetchAll('SELECT name, chamber_member_code FROM organizations WHERE name LIKE ? OR chamber_member_code LIKE ? LIMIT 3', [$like, $like]) as $org) {
                $items[] = [
                    'type' => 'سازمان دانش‌پذیر آدان',
                    'title' => $org['name'],
                    'subtitle' => 'شناسه سازمان: ' . $org['chamber_member_code'],
                    'url' => App::url('crm'),
                ];
            }
        }

        $this->json(['items' => array_slice($items, 0, 14)]);
    }

    public function copilot(): void
    {
        $this->guardInternalApi();
        $raw = json_decode((string)file_get_contents('php://input'), true);
        $data = is_array($raw) ? array_merge($_POST, $raw) : $_POST;

        $prompt = trim((string)($data['prompt'] ?? 'وضعیت شاخص‌های کلیدی این بخش را تحلیل کن و ۳ پیشنهاد اجرایی بده.'));
        $route = trim((string)($data['module_route'] ?? App::currentRoute() ?: 'dashboard'));
        if ($prompt === '') {
            $prompt = 'وضعیت شاخص‌های کلیدی این بخش را تحلیل کن و ۳ پیشنهاد اجرایی بده.';
        }

        while (ob_get_level() > 0) {
            ob_end_clean();
        }
        $res = \App\Services\ModuleAiAdvisorService::analyzeModule($route, $prompt);
        $this->json($res);
    }

    public function courses(): void
    {
        $rows = Database::fetchAll(
            "SELECT c.id, c.code, c.title, c.level, c.delivery_mode, c.duration_hours, c.tuition_rial, c.member_discount_pct,
                    cc.title AS category_title
             FROM courses c
             JOIN course_categories cc ON cc.id = c.category_id
             WHERE c.workflow_status = 'published'
             ORDER BY c.id DESC"
        );
        $this->json([
            'ok' => true,
            'chamber' => Database::setting('chamber_name'),
            'count' => count($rows),
            'courses' => $rows,
        ]);
    }

    public function apiEnroll(): void
    {
        $expectedToken = Database::setting('enrollment_api_token');
        if (strlen($expectedToken) < 32) {
            $this->json(['ok' => false, 'error' => 'api_not_configured'], 503);
        }
        $provided = $_SERVER['HTTP_X_API_TOKEN'] ?? '';
        if (!hash_equals($expectedToken, (string)$provided)) {
            $this->json(['ok' => false, 'error' => 'Invalid API Token (X-API-Token)'], 401);
        }

        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
            $this->json(['ok' => false, 'error' => 'method_not_allowed'], 405);
        }

        $body = (string)file_get_contents('php://input');
        $raw = json_decode($body, true);
        if (!is_array($raw)) {
            $raw = $_POST;
        }
        $runId = filter_var($raw['run_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        $userId = filter_var($raw['user_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        if ($runId === false || $runId === null || $userId === false || $userId === null) {
            $this->json(['ok' => false, 'error' => 'run_id_and_user_id_required'], 400);
        }

        $pdo = Database::connection();
        $pdo->beginTransaction();
        try {
            $runStmt = $pdo->prepare(
                'SELECT r.*, c.workflow_status
                 FROM course_runs r JOIN courses c ON c.id = r.course_id
                 WHERE r.id = ? FOR UPDATE'
            );
            $runStmt->execute([$runId]);
            $run = $runStmt->fetch(\PDO::FETCH_ASSOC);
            if (!$run) {
                $pdo->rollBack();
                $this->json(['ok' => false, 'error' => 'course_run_not_found'], 404);
            }
            if ($run['status'] !== 'registration' || !in_array($run['workflow_status'], ['approved', 'published'], true)) {
                $pdo->rollBack();
                $this->json(['ok' => false, 'error' => 'course_run_not_open_for_registration'], 409);
            }

            $learnerStmt = $pdo->prepare('SELECT id, org_id FROM users WHERE id = ? AND role = "learner" AND status = "active" FOR UPDATE');
            $learnerStmt->execute([$userId]);
            $learner = $learnerStmt->fetch(\PDO::FETCH_ASSOC);
            if (!$learner) {
                $pdo->rollBack();
                $this->json(['ok' => false, 'error' => 'active_learner_not_found'], 404);
            }

            $existsStmt = $pdo->prepare('SELECT id, status FROM enrollments WHERE run_id = ? AND user_id = ? FOR UPDATE');
            $existsStmt->execute([$runId, $userId]);
            $exists = $existsStmt->fetch(\PDO::FETCH_ASSOC);
            if ($exists) {
                $pdo->rollBack();
                if (in_array($exists['status'], ['active', 'waitlist'], true)) {
                    $this->json(['ok' => true, 'status' => $exists['status'], 'message' => 'قبلاً در این اجرا ثبت شده است']);
                }
                $this->json(['ok' => false, 'error' => 'learner_already_has_enrollment'], 409);
            }

            $countStmt = $pdo->prepare('SELECT COUNT(*) FROM enrollments WHERE run_id = ? AND status = "active"');
            $countStmt->execute([$runId]);
            $activeCount = (int)$countStmt->fetchColumn();
            $status = $activeCount >= (int)$run['capacity'] ? 'waitlist' : 'active';
            $insertStmt = $pdo->prepare(
                'INSERT INTO enrollments (run_id, user_id, org_id, source, status) VALUES (?, ?, ?, "api", ?)'
            );
            $insertStmt->execute([$runId, $userId, $learner['org_id'], $status]);
            $id = (int)$pdo->lastInsertId();
            $pdo->prepare('UPDATE course_runs SET enrolled_count = ? WHERE id = ?')
                ->execute([$activeCount + ($status === 'active' ? 1 : 0), $runId]);
            $pdo->commit();
        } catch (\Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }
        Auth::audit('TMS_API', 'API_ENROLLMENT_CREATED', 'enrollment', $id, ['run_id' => $runId, 'status' => $status]);

        $this->json([
            'ok' => true,
            'enrollment_id' => $id,
            'enrollment_status' => $status,
            'message' => $status === 'waitlist' ? 'ظرفیت تکمیل بود؛ فراگیر در فهرست انتظار قرار گرفت.' : 'ثبت‌نام API با موفقیت انجام شد.',
        ], 201);
    }

    public function telegramWebhook(): void
    {
        $body = json_decode((string)file_get_contents('php://input'), true) ?: $_POST;
        $text = trim((string)($body['message']['text'] ?? $body['command'] ?? '/start'));

        if (str_starts_with($text, '/courses')) {
            $courses = Database::fetchAll("SELECT code, title FROM courses WHERE workflow_status='published' LIMIT 4");
            $lines = array_map(static fn($c) => "• [{$c['code']}] {$c['title']}", $courses);
            $reply = "📚 دوره‌های در حال ثبت‌نام آموزشگاه حسابداری آدان:\n" . implode("\n", $lines);
        } elseif (str_starts_with($text, '/cert')) {
            $parts = preg_split('/\s+/', $text);
            $serial = $parts[1] ?? 'CERT-ADN-1405-9001';
            $cert = Database::fetchOne(
                'SELECT cert.*, u.full_name, c.title AS course_title
                 FROM certificates cert
                 JOIN users u ON u.id = cert.user_id
                 JOIN courses c ON c.id = cert.course_id
                 WHERE cert.serial_code = ?',
                [$serial]
            );
            $reply = $cert
                ? ($cert['status'] === 'valid'
                    ? "✅ گواهی معتبر آموزشگاه\nنام: {$cert['full_name']}\nدوره: {$cert['course_title']}\nتاریخ صدور: {$cert['issue_shamsi']}"
                    : "❌ گواهی با سریال {$serial} ابطال شده است. علت: {$cert['revoked_reason']}")
                : "⚠️ گواهی‌نامه‌ای با سریال {$serial} یافت نشد.";
        } else {
            $reply = "📚 به ربات اطلاع‌رسانی آموزشگاه حسابداری آدان خوش آمدید!\nدستورات فعال:\n/courses — فهرست دوره‌های فعال\n/cert <شماره گواهی> — بررسی وضعیت گواهی";
        }

        $this->json(['ok' => true, 'command_received' => $text, 'bot_reply' => $reply]);
    }

    public function scormCmi(): void
    {
        // ★ v26.9 — ثبت پیشرفت اسکورم فقط برای صاحب رکورد (نه با فرض کاربر ۱)
        $uid = $this->guardInternalApi();
        $lessonId = max(1, (int)($_REQUEST['lesson_id'] ?? 3));
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $raw = json_decode((string)file_get_contents('php://input'), true);
            $payload = is_array($raw) ? $raw : $_POST;
            $saved = \App\Services\ScormService::saveCmiState($uid, $lessonId, $payload);
            Auth::audit('LMS_SCORM', 'SCORM_CMI_COMMIT', 'lesson', $lessonId, ['status' => $saved['cmi.core.lesson_status']]);
            $this->json(['ok' => true, 'cmi' => $saved]);
        }

        $this->json(['ok' => true, 'cmi' => \App\Services\ScormService::getCmiState($uid, $lessonId)]);
    }

    public function moduleAi(): void
    {
        $this->guardInternalApi();
        $raw = json_decode((string)file_get_contents('php://input'), true);
        $data = is_array($raw) ? array_merge($_POST, $raw) : $_POST;

        $route = trim((string)($data['module_route'] ?? 'dashboard'));
        $prompt = trim((string)($data['prompt'] ?? 'وضعیت فعلی داده‌های این ماژول را تحلیل کن.'));
        if ($prompt === '') {
            $prompt = 'وضعیت فعلی داده‌های این ماژول را تحلیل کن.';
        }
        while (ob_get_level() > 0) {
            ob_end_clean();
        }
        $res = \App\Services\ModuleAiAdvisorService::analyzeModule($route, $prompt);
        $this->json($res);
    }

    public function voiceCommand(): void
    {
        // ★ v26.9 — بدون نشستِ واردشده، کاربری (و بدتر: کاربر ۱ = مدیرکل) فرض نمی‌شود
        $uid = $this->guardInternalApi();
        $raw = json_decode((string)file_get_contents('php://input'), true) ?: $_POST;
        $text = trim((string)($raw['text'] ?? $raw['spoken_text'] ?? 'گزارش وضعیت دوره‌ها'));
        $currentRoute = trim((string)($raw['current_route'] ?? 'dashboard'));
        $res = \App\Services\VoiceCommandService::processCommand($uid, $text !== '' ? $text : 'گزارش وضعیت دوره‌ها', $currentRoute);
        $this->json($res);
    }

    public function voiceTranscribe(): void
    {
        $this->guardInternalApi();
        if (empty($_FILES['audio']['tmp_name'])) {
            $this->json(['ok' => false, 'message' => 'فایل صوتی ارسال نشده است.']);
        }
        $res = \App\Services\VoiceCommandService::transcribeAudioFile(
            (string)$_FILES['audio']['tmp_name'],
            (string)($_FILES['audio']['type'] ?? 'audio/webm')
        );
        $this->json($res);
    }

    public function gamificationPing(): void
    {
        // ★ v26.9 — تلمتری/XP فقط برای صاحب حساب ثبت می‌شود (نه با فرض «کاربر ۱»)
        $uidPing = $this->guardInternalApi();
        $u = Auth::user();
        $res = \App\Services\LearnerBehaviorGamificationService::recordTelemetryAndAwardXp(
            $uidPing,
            (string)($u['full_name'] ?? 'فراگیر فعال'),
            trim((string)($_POST['module_route'] ?? 'dashboard')),
            trim((string)($_POST['action_verb'] ?? 'مطالعه فعال و تعامل محتوایی')),
            (int)($_POST['dwell_seconds'] ?? 240),
            (int)($_POST['scroll_depth_pct'] ?? 92),
            (int)($_POST['xp_bonus'] ?? 35)
        );
        $this->json($res);
    }

    public function quickTheme(): void
    {
        // ★ v26.9 — تم/فونت یک تنظیم کاربری است؛ ناشناس نباید آن را بنویسد
        $this->guardInternalApi();
        $raw = json_decode((string)file_get_contents('php://input'), true) ?: $_POST;
        $u = Auth::user();
        $actor = (string)($u['full_name'] ?? 'کاربر سامانه');
        $res = \App\Services\EnterpriseSettingsIamService::quickUpdateAppearance($raw, $actor);
        $this->json([
            'ok'    => true,
            'theme' => $res['theme'],
            'rev'   => \App\Services\EnterpriseSettingsIamService::getThemeRevisionHash(),
        ]);
    }
}
