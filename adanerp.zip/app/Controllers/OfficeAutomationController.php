<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Services\OfficeAutomationService;

final class OfficeAutomationController extends Controller
{
    private const VIEW_ALL_ROLES = ['super_admin', 'training_expert', 'finance_manager', 'crm_manager'];
    private const REQUEST_MANAGER_ROLES = ['super_admin', 'training_expert', 'finance_manager'];

    public function index(): void
    {
        $user = Auth::user();
        $actor = (string)($user['full_name'] ?? 'مدیرکل آموزش');
        $userId = (int)($user['id'] ?? 0);
        $role = Auth::role();
        $canViewAll = in_array($role, self::VIEW_ALL_ROLES, true);
        $canManageRequests = in_array($role, self::REQUEST_MANAGER_ROLES, true);
        $activeTab = trim((string)($_GET['tab'] ?? 'inbox'));
        $typeFilter = trim((string)($_GET['filter'] ?? 'all'));
        $box = trim((string)($_GET['box'] ?? 'inbox'));
        if (!in_array($box, ['inbox', 'sent', 'archived', 'all'], true) || ($box === 'all' && !$canViewAll)) {
            $box = 'inbox';
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $action = (string)($_POST['action'] ?? '');

            if ($action === 'compose_letter') {
                $res = OfficeAutomationService::composeLetter($_POST, $userId, $actor, $role);
                if (empty($res['ok'])) {
                    $this->redirect('office-automation?tab=compose', (string)($res['error'] ?? 'ثبت نامه انجام نشد.'), 'danger');
                }
                $this->redirect(
                    'office-automation?tab=inbox&box=sent',
                    'نامه با شماره «' . $res['indicator_no'] . '» برای «' . $res['recipient'] . '» ارسال شد.'
                );
            }

            if ($action === 'sign_letter') {
                $ok = OfficeAutomationService::signAndSealLetter(
                    (int)($_POST['letter_id'] ?? 0),
                    $userId,
                    $actor,
                    $canManageRequests
                );
                $this->redirect(
                    'office-automation?tab=inbox&box=' . ($ok ? 'sent' : 'inbox'),
                    $ok ? 'امضای نامه ثبت شد.' : 'این نامه پیش‌نویس قابل امضا نیست یا اجازه امضای آن را ندارید.',
                    $ok ? 'success' : 'danger'
                );
            }

            if ($action === 'refer_letter') {
                $res = OfficeAutomationService::referLetter($_POST, $userId, $actor, $canViewAll);
                if (empty($res['ok'])) {
                    $this->redirect('office-automation?tab=referrals', (string)($res['error'] ?? 'ارجاع نامه انجام نشد.'), 'danger');
                }
                $this->redirect('office-automation?tab=referrals', 'نامه با دستور پاراف به «' . $res['to'] . '» ارجاع شد.');
            }

            if ($action === 'complete_referral') {
                $ok = OfficeAutomationService::completeReferral(
                    (int)($_POST['referral_id'] ?? 0),
                    $userId,
                    $canManageRequests
                );
                $this->redirect(
                    'office-automation?tab=referrals',
                    $ok ? 'اقدام ارجاع ثبت و پرونده مختومه شد.' : 'این ارجاع به شما واگذار نشده یا قبلاً مختومه شده است.',
                    $ok ? 'success' : 'danger'
                );
            }

            if ($action === 'mark_letter_read') {
                $ok = OfficeAutomationService::markLetterRead((int)($_POST['letter_id'] ?? 0), $userId);
                $this->redirect(
                    'office-automation?tab=inbox',
                    $ok ? 'نامه به‌عنوان خوانده‌شده ثبت شد.' : 'نامه در کارتابل شما نیست یا قبلاً خوانده شده است.',
                    $ok ? 'success' : 'danger'
                );
            }

            if ($action === 'archive_letter') {
                $ok = OfficeAutomationService::archiveLetter((int)($_POST['letter_id'] ?? 0), $userId);
                $this->redirect(
                    'office-automation?tab=inbox',
                    $ok ? 'نامه به بایگانی شخصی شما منتقل شد.' : 'انتقال نامه به بایگانی انجام نشد.',
                    $ok ? 'success' : 'danger'
                );
            }

            if ($action === 'submit_admin_request') {
                $res = OfficeAutomationService::submitAdminRequest($_POST, $userId, $actor);
                $this->redirect('office-automation?tab=requests', 'درخواست اداری با کد پیگیری «' . $res['req_code'] . '» ثبت شد.');
            }

            if ($action === 'decide_admin_request') {
                if (!$canManageRequests) {
                    $this->redirect('office-automation?tab=requests', 'تصمیم‌گیری درباره درخواست‌ها فقط برای مدیران مجاز است.', 'danger');
                }
                $ok = OfficeAutomationService::decideAdminRequest(
                    (int)($_POST['req_id'] ?? 0),
                    (string)($_POST['decision'] ?? 'approve'),
                    $actor
                );
                $this->redirect(
                    'office-automation?tab=requests',
                    $ok ? 'نتیجه بررسی مدیریت ثبت شد.' : 'درخواست در وضعیت انتظار نیست یا قبلاً بررسی شده است.',
                    $ok ? 'success' : 'danger'
                );
            }

            if ($action === 'record_minutes') {
                $res = OfficeAutomationService::recordMeetingMinutes($_POST, $actor);
                $this->redirect('office-automation?tab=minutes', 'صورت‌جلسه رسمی با شناسه «' . $res['minute_code'] . '» ثبت و ابلاغ شد.');
            }
        }

        $bundle = OfficeAutomationService::getWorkspaceBundle(
            $typeFilter,
            $userId,
            $canViewAll,
            $canManageRequests,
            $box
        );
        $replyTo = null;
        $replyRecipientId = 0;
        $replyToId = (int)($_GET['reply_to'] ?? 0);
        if ($replyToId > 0) {
            $replyData = OfficeAutomationService::getLetterWithReferrals($replyToId, $userId, $canViewAll);
            $replyTo = $replyData['letter'];
            if ($replyTo) {
                $replyRecipientId = (int)($replyTo['sender_user_id'] ?? 0) === $userId
                    ? (int)($replyTo['recipient_user_id'] ?? 0)
                    : (int)($replyTo['sender_user_id'] ?? 0);
            }
        }

        $this->render('growth/office_automation', [
            'pageTitle' => 'اتوماسیون اداری، کارتابل مکاتبات و دبیرخانه',
            'activeTab' => $activeTab,
            'typeFilter' => $typeFilter,
            'box' => $box,
            'canViewAll' => $canViewAll,
            'canManageRequests' => $canManageRequests,
            'currentUserId' => $userId,
            'currentUserName' => $actor,
            'replyTo' => $replyTo,
            'replyToId' => $replyTo ? (int)$replyTo['id'] : 0,
            'replyRecipientId' => $replyRecipientId,
            'bundle' => $bundle,
        ]);
    }

    public function letterPrint(): void
    {
        $id = max(1, (int)($_GET['id'] ?? 1));
        $role = Auth::role();
        $canViewAll = in_array($role, self::VIEW_ALL_ROLES, true);
        $data = OfficeAutomationService::getLetterWithReferrals($id, Auth::id(), $canViewAll);
        if (empty($data['letter'])) {
            $this->redirect('office-automation?tab=inbox', 'نامه یافت نشد یا اجازه مشاهده آن را ندارید.', 'danger');
        }
        $this->render('growth/letter_print', [
            'pageTitle' => 'چاپ سربرگ رسمی مکاتبات اداری — ' . $data['letter']['indicator_no'],
            'letter' => $data['letter'],
            'referrals' => $data['referrals'],
        ], 'public');
    }
}
