<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Services\SmartRecruitmentService;

final class CareerHubController extends Controller
{
    public function index(): void
    {
        $uid = max(1, (int)(Auth::id() ?? 7));
        $u = Auth::user();
        $activeTab = trim((string)($_GET['tab'] ?? 'ads'));

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $action = (string)($_POST['action'] ?? '');

            if ($action === 'publish_job_ad') {
                $res = SmartRecruitmentService::publishRichJobAd($_POST);
                $this->redirect('career-hub?tab=ads', 'آگهی استخدام «' . $res['job_title'] . '» با کد ' . $res['ad_code'] . ' و شرح شغل هوشمند منتشر شد.');
            }

            if ($action === 'save_candidate_cv') {
                $res = SmartRecruitmentService::saveOrSyncCandidateCv($uid, $_POST);
                $this->redirect('career-hub?tab=cv', 'رزومه حرفه‌ای شما با گواهی‌های QR و امتیاز گیمیفیکیشن همگام‌سازی و ذخیره شد (+۴۵ XP).');
            }

            if ($action === 'apply_smart_ad' || $action === 'apply_job') {
                $adId = (int)($_POST['job_ad_id'] ?? $_POST['job_id'] ?? 1);
                $res = SmartRecruitmentService::submitSmartApplication(
                    $adId,
                    $uid,
                    (string)($u['full_name'] ?? 'مهندس مهرداد شریفی'),
                    (string)($_POST['candidate_note'] ?? '')
                );
                $this->redirect(
                    'career-hub?tab=ats',
                    'رزومه تاییدشده ارسال و وارد پایپ‌لاین ATS کارفرما شد (کد رهگیری: ' . ($res['tracking_code'] ?? '-') . ' | امتیاز تطابق هوش مصنوعی: ' . ($res['match_score_pct'] ?? 94) . '٪ + ۴۰ XP).'
                );
            }

            if ($action === 'advance_ats') {
                $res = SmartRecruitmentService::advanceAtsStage((int)$_POST['app_id']);
                $this->redirect('career-hub?tab=ats', 'پرونده استخدامی ' . ($res['tracking_code'] ?? '') . ' به مرحله «' . ($res['stage_label'] ?? '') . '» ارتقا یافت.');
            }

            if ($action === 'schedule_interview') {
                $res = SmartRecruitmentService::scheduleSmartInterview(
                    (string)($_POST['candidate_name'] ?? 'مهندس مهرداد شریفی'),
                    (string)($_POST['company_name'] ?? 'مجتمع فولاد زاگرس'),
                    (string)($_POST['job_title'] ?? 'مدیر صادرات'),
                    (string)($_POST['interview_mode'] ?? 'آنلاین (اسکای‌روم اتاق)'),
                    (string)($_POST['scheduled_shamsi'] ?? 'چهارشنبه ۱۴۰۵/۰۸/۰۷ ساعت ۱۱:۰۰')
                );
                $this->redirect('career-hub?tab=interviews', 'جلسه مصاحبه تخصصی (' . $res['interview_code'] . ') به همراه سؤالات پیشنهادی AI ثبت شد.');
            }

            if ($action === 'issue_offer') {
                $res = SmartRecruitmentService::issueOfficialJobOffer(
                    (string)($_POST['candidate_name'] ?? 'مهندس مهرداد شریفی'),
                    (string)($_POST['company_name'] ?? 'مجتمع فولاد زاگرس'),
                    (string)($_POST['position_title'] ?? 'مدیر صادرات و قراردادها'),
                    (int)($_POST['base_monthly_million'] ?? 68),
                    (string)($_POST['export_commission_note'] ?? 'پورسانت ارزی + بیمه تکمیلی طلایی')
                );
                $this->redirect('career-hub?tab=interviews', 'نامه رسمی پیشنهاد شغلی (Offer Letter شماره ' . $res['offer_serial'] . ') صادر و ارسال گردید.');
            }

            if ($action === 'book_fair_booth') {
                $res = SmartRecruitmentService::reserveJobFairSlot((int)$_POST['booth_id']);
                $this->redirect(
                    'career-hub?tab=benchmarks',
                    $res['ok']
                        ? ('نوبت مصاحبه ده دقیقه‌ای در غرفه «' . $res['company_name'] . '» رزرو شد (ظرفیت باقی‌مانده: ' . $res['slots_left'] . ').')
                        : ($res['message'] ?? 'تکمیل ظرفیت.')
                );
            }
        }

        $q = trim((string)($_GET['q'] ?? ''));
        $cat = trim((string)($_GET['cat'] ?? 'all'));
        $hub = SmartRecruitmentService::getFullHubData($q, $cat);

        $this->render('growth/career_hub', [
            'pageTitle' => 'سامانه جامع هوشمند کاریابی، استودیو آگهی استخدام، رزومه‌ساز تاییدشده و پایپ‌لاین ATS',
            'activeTab' => $activeTab,
            'q'         => $q,
            'cat'       => $cat,
            'hub'       => $hub,
        ]);
    }

    public function cvPrint(): void
    {
        $profile = Database::fetchOne('SELECT * FROM career_candidate_profiles ORDER BY id ASC LIMIT 1');
        $certs = Database::fetchAll(
            'SELECT cert.*, c.title AS course_title FROM certificates cert JOIN courses c ON c.id = cert.course_id WHERE cert.status = "valid" LIMIT 4'
        );
        $this->render('growth/cv_print', [
            'pageTitle' => 'چاپ رزومه و سوابق آموزشی آدان',
            'profile'   => $profile,
            'certs'     => $certs,
        ], 'public');
    }
}
