<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Core\Jalali;

final class EventController extends Controller
{
    public function index(): void
    {
        $canManageEvents = Auth::hasRole(['super_admin', 'training_expert', 'finance_manager', 'crm_manager']);

        if (isset($_GET['export']) && $_GET['export'] === 'attendees') {
            if (!$canManageEvents) {
                $this->flash('danger', 'خروجی فهرست ثبت‌نام فقط برای کارکنان مجاز است.');
                $this->redirect('events');
            }
            $exportRows = Database::fetchAll(
                'SELECT e.title AS برنامه_آموزشی, u.full_name AS فراگیر, t.ticket_code AS کد_بلیت, t.checked_in_at AS زمان_ورود, t.feedback_score AS امتیاز_رضایت
                 FROM event_tickets t JOIN events e ON e.id = t.event_id JOIN users u ON u.id = t.user_id'
            );
            $this->exportCsv('adan_training_attendees.csv', ['برنامه_آموزشی','فراگیر','کد_بلیت','زمان_ورود','امتیاز_رضایت'], $exportRows);
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $action = (string)($_POST['action'] ?? '');

            if ($action === 'submit_feedback') {
                $ticketId = (int)($_POST['ticket_id'] ?? 0);
                $ticket = Database::fetchOne('SELECT user_id FROM event_tickets WHERE id = ?', [$ticketId]);
                if (!$ticket || (!$canManageEvents && (int)$ticket['user_id'] !== Auth::id())) {
                    $this->flash('danger', 'این بلیت برای ثبت یا ویرایش بازخورد در دسترس شما نیست.');
                    $this->redirect('events');
                }
                Database::execute(
                    'UPDATE event_tickets SET feedback_score = ?, feedback_comment = ? WHERE id = ?',
                    [max(1, min(5, (int)($_POST['feedback_score'] ?? 5))), trim((string)($_POST['feedback_comment'] ?? '')), $ticketId]
                );
                $this->flash('success', 'بازخورد و امتیاز ارزیابی رویداد ثبت شد.');
                $this->redirect('events');
            }

            if ($action === 'create_event' && Auth::hasRole(['super_admin', 'training_expert', 'crm_manager'])) {
                $title = trim((string)($_POST['title'] ?? ''));
                $eventType = (string)($_POST['event_type'] ?? '');
                $speakers = trim((string)($_POST['speakers'] ?? ''));
                $eventDate = trim((string)($_POST['event_date'] ?? ''));
                $venue = trim((string)($_POST['venue'] ?? ''));
                $capacity = filter_var($_POST['capacity'] ?? null, FILTER_VALIDATE_INT);
                $price = filter_var($_POST['price_rial'] ?? null, FILTER_VALIDATE_INT);
                $validEventTypes = ['کارگاه آموزشی', 'نشست تخصصی', 'جلسه رفع اشکال'];
                $dateParts = explode('-', $eventDate);
                $validDate = count($dateParts) === 3
                    && ctype_digit($dateParts[0])
                    && ctype_digit($dateParts[1])
                    && ctype_digit($dateParts[2])
                    && checkdate((int)$dateParts[1], (int)$dateParts[2], (int)$dateParts[0]);

                if (
                    $title === '' || $speakers === '' || $venue === ''
                    || !in_array($eventType, $validEventTypes, true)
                    || !$validDate || $capacity === false || $capacity < 1
                    || $price === false || $price < 0 || $eventDate < date('Y-m-d')
                ) {
                    $this->flash('danger', 'عنوان، مدرس، تاریخ امروز یا آینده، مکان، ظرفیت مثبت و تعرفه معتبر را وارد کنید.');
                    $this->redirect('events');
                }

                $code = 'EVT-ADN-' . strtoupper(bin2hex(random_bytes(4)));
                Database::insert(
                    'INSERT INTO events (code, title, event_type, speakers, event_date, event_shamsi, venue, capacity, price_rial, estimated_cost_rial)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0)',
                    [
                        $code,
                        $title,
                        $eventType,
                        $speakers,
                        $eventDate,
                        Jalali::fromGregorianString($eventDate),
                        $venue,
                        $capacity,
                        $price,
                    ]
                );
                $this->flash('success', 'برنامه آموزشی جدید در تقویم آدان ثبت شد.');
                $this->redirect('events');
            }

            if ($action === 'create_event') {
                $this->flash('danger', 'اجازه تعریف برنامه آموزشی را ندارید.');
                $this->redirect('events');
            }

            if ($action === 'issue_event_invoice') {
                $finModel = new \App\Models\FinanceModel();
                $inv = $finModel->issueEventInvoice((int)$_POST['event_id'], Auth::id(), Auth::user()['org_id'] ?? null);
                if ($inv) {
                    $this->flash('info', 'پیش‌فاکتور ثبت‌نام برنامه آموزشی شماره ' . $inv['invoice_number'] . ' صادر شد. پس از تسویه، بلیت QR را دریافت کنید.');
                    $this->redirect('finance');
                }
                $this->flash('warning', 'برای این برنامه آموزشی امکان صدور پیش‌فاکتور وجود ندارد.');
                $this->redirect('events');
            }

            if ($action === 'register_event') {
                $evId = (int)$_POST['event_id'];
                $ev = Database::fetchOne('SELECT * FROM events WHERE id = ?', [$evId]);
                if (!$ev) {
                    $this->flash('danger', 'برنامه آموزشی انتخاب‌شده یافت نشد.');
                    $this->redirect('events');
                }
                if (
                    $ev['status'] !== 'open'
                    || $ev['event_date'] < date('Y-m-d')
                    || (int)$ev['registered_count'] >= (int)$ev['capacity']
                ) {
                    $this->flash('warning', 'ثبت‌نام این برنامه بسته شده یا ظرفیت آن تکمیل است.');
                    $this->redirect('events');
                }

                $paidStatus = 'free';
                if ((int)$ev['price_rial'] > 0) {
                    $paidInvoice = Database::fetchOne(
                        'SELECT * FROM invoices WHERE event_id = ? AND user_id = ? AND status = "paid" LIMIT 1',
                        [$evId, Auth::id()]
                    );
                    if (!$paidInvoice) {
                        Auth::audit('EVENTS', 'PAID_EVENT_TICKET_BLOCKED_NO_PAYMENT', 'event', $evId, ['price' => $ev['price_rial']]);
                        $this->flash(
                            'warning',
                            'برای دریافت بلیت این برنامه پولی، ابتدا پیش‌فاکتور ثبت‌نام را صادر و تسویه کنید؛ سپس دوباره ثبت‌نام را انجام دهید.'
                        );
                        $this->redirect('events');
                    }
                    $paidStatus = 'paid';
                }

                $exists = Database::fetchOne('SELECT * FROM event_tickets WHERE event_id = ? AND user_id = ?', [$evId, Auth::id()]);
                if ($exists) {
                    $this->flash('info', 'بلیت QR شما قبلاً با کد «' . $exists['ticket_code'] . '» صادر شده است.');
                } else {
                    $code = 'TKT-ADN-' . strtoupper(bin2hex(random_bytes(3)));
                    Database::insert(
                        'INSERT INTO event_tickets (event_id, user_id, ticket_code, paid_status) VALUES (?, ?, ?, ?)',
                        [$evId, Auth::id(), $code, $paidStatus]
                    );
                    Database::execute('UPDATE events SET registered_count = registered_count + 1 WHERE id = ?', [$evId]);
                    Auth::audit('EVENTS', strtoupper($paidStatus) . '_TICKET_ISSUED', 'event', $evId, ['ticket_code' => $code]);
                    $this->flash('success', 'ثبت‌نام انجام شد و بلیت ورود QR با کد «' . $code . '» صادر گردید.');
                }
                $this->redirect('events');
            }

            if ($action === 'qr_checkin' && Auth::hasRole(['super_admin', 'training_expert', 'crm_manager'])) {
                $code = trim((string)$_POST['ticket_code']);
                $tkt = Database::fetchOne('SELECT * FROM event_tickets WHERE ticket_code = ?', [$code]);
                if (!$tkt) {
                    $this->flash('danger', 'کد بلیت QR در سامانه یافت نشد!');
                } else {
                    Database::execute('UPDATE event_tickets SET checked_in_at = NOW() WHERE id = ?', [(int)$tkt['id']]);
                    Auth::audit('EVENTS', 'QR_CHECKIN_CONFIRMED', 'ticket', (int)$tkt['id'], ['code' => $code]);
                    $this->flash('success', 'ورود شرکت‌کننده با کد بلیت «' . $code . '» با موفقیت در میز پذیرش ثبت شد.');
                }
                $this->redirect('events');
            }
        }

        $events = Database::fetchAll('SELECT * FROM events ORDER BY id ASC');
        $ticketQuery = 'SELECT t.*, e.title AS event_title, u.full_name
                        FROM event_tickets t
                        JOIN events e ON e.id = t.event_id
                        JOIN users u ON u.id = t.user_id';
        $ticketParams = [];
        if (!$canManageEvents) {
            $ticketQuery .= ' WHERE t.user_id = ?';
            $ticketParams[] = Auth::id();
        }
        $ticketQuery .= ' ORDER BY t.id DESC';
        $tickets = Database::fetchAll($ticketQuery, $ticketParams);

        $this->render('events/index', [
            'pageTitle' => 'برنامه‌ها و کارگاه‌های آموزشی آدان',
            'events' => $events,
            'tickets' => $tickets,
            'canManageEvents' => $canManageEvents,
            'canCreateEvents' => Auth::hasRole(['super_admin', 'training_expert', 'crm_manager']),
            'defaultEventDate' => date('Y-m-d', strtotime('+7 days')),
        ]);
    }
}
