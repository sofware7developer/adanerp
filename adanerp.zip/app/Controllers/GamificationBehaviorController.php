<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Services\LearnerBehaviorGamificationService;

final class GamificationBehaviorController extends Controller
{
    public function index(): void
    {
        $uid = max(1, (int)Auth::id());
        $u = Auth::user();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $action = (string)($_POST['action'] ?? '');

            if ($action === 'claim_quest') {
                $res = LearnerBehaviorGamificationService::claimQuestReward($uid, (int)$_POST['quest_id']);
                $this->redirect(
                    'gamification-analytics',
                    $res['ok']
                        ? ('پاداش مأموریت ' . $res['quest_code'] . ' به کیف پول شما واریز شد (+' . $res['xp_added'] . ' XP و +' . $res['coins_added'] . ' سکه مهارت).')
                        : ($res['message'] ?? 'خطا در دریافت پاداش.')
                );
            }

            if ($action === 'redeem_reward') {
                $res = LearnerBehaviorGamificationService::redeemStoreReward($uid, (int)$_POST['reward_id']);
                $this->redirect(
                    'gamification-analytics',
                    $res['ok']
                        ? ('مشوق «' . $res['reward_title'] . '» صادر شد — کد واچر اختصاصی: ' . $res['voucher_serial'])
                        : ($res['message'] ?? 'موجودی سکه کافی نیست.')
                );
            }

            if ($action === 'nudge_learner') {
                $res = LearnerBehaviorGamificationService::triggerDropoutIntervention((int)$_POST['prediction_id']);
                $this->redirect('gamification-analytics', $res['status_note'] ?? 'مداخله انگیزشی هوشمند ارسال شد.');
            }

            if ($action === 'log_study_pulse') {
                $res = LearnerBehaviorGamificationService::recordTelemetryAndAwardXp(
                    $uid,
                    (string)($u['full_name'] ?? 'فراگیر فعال'),
                    (string)($_POST['module_route'] ?? 'lms'),
                    (string)($_POST['action_verb'] ?? 'تکمیل تمرین تعاملی و یادداشت‌برداری'),
                    (int)($_POST['dwell_seconds'] ?? 900),
                    96,
                    55
                );
                $this->redirect('gamification-analytics', 'رویداد رفتاری xAPI ثبت شد (شاخص تمرکز: ' . $res['focus_index_pct'] . '٪ | پاداش: +' . $res['xp_added'] . ' XP).');
            }
        }

        $hud = LearnerBehaviorGamificationService::getUserHudSnapshot($uid, $u['full_name'] ?? 'کاربر اتاق');
        $summary = LearnerBehaviorGamificationService::getExecutiveAnalyticsSummary();

        $this->render('growth/gamification_analytics', [
            'pageTitle' => 'مرکز جامع تحلیل رفتار فراگیران (xAPI / LBA)، پیش‌بینی افت انگیزه و موتور گیمیفیکیشن سازمانی',
            'hud' => $hud,
            'summary' => $summary,
            'wallets' => Database::fetchAll('SELECT * FROM gamification_wallets ORDER BY xp_points DESC'),
            'quests' => Database::fetchAll('SELECT * FROM gamification_quests ORDER BY id ASC'),
            'rewards' => Database::fetchAll('SELECT * FROM gamification_reward_store ORDER BY coin_cost ASC'),
            'predictions' => Database::fetchAll('SELECT * FROM learner_dropout_predictions ORDER BY dropout_risk_pct DESC'),
            'heatmaps' => Database::fetchAll('SELECT * FROM content_friction_heatmaps ORDER BY dropoff_rate_pct DESC'),
            'events' => Database::fetchAll('SELECT * FROM learner_behavior_events ORDER BY id DESC LIMIT 10'),
        ]);
    }
}
