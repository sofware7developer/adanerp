<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Services\RoleCockpitService;

final class RoleWorkstationController extends Controller
{
    public function index(): void
    {
        $u = Auth::user();
        $currentRole = Auth::role() ?: 'learner';

        // تفکیک سخت‌گیرانه سطح دسترسی: فقط مدیرکل (super_admin) مجاز به مشاهده و سوئیچ بین تمام میزکارهاست؛
        // سایر نقش‌ها صرفاً به میزکار تخصصی خودشان (و درگاه عمومی استعلام گواهی) دسترسی دارند!
        $allowedTabs = $currentRole === 'super_admin'
            ? ['super_admin', 'training_expert', 'finance_manager', 'crm_manager', 'instructor', 'org_rep', 'learner', 'guest']
            : [$currentRole, 'guest'];

        $requestedTab = trim((string)($_GET['tab'] ?? $currentRole));
        $activeTab = in_array($requestedTab, $allowedTabs, true) ? $requestedTab : $currentRole;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $action = (string)($_POST['action'] ?? '');

            if ($action === 'exec_sign') {
                $this->requireRole(['super_admin'], 'role-workstations');
                $res = RoleCockpitService::signExecutiveItem((int)$_POST['item_id'], (string)($u['full_name'] ?? 'مدیرکل آموزش'));
                $this->redirect('role-workstations?tab=super_admin', 'سند ' . ($res['doc_ref_no'] ?? '') . ' با امضای دیجیتال SHA-256 مدیرکل توشیح و صادر شد.');
            }

            if ($action === 'bulk_enroll') {
                $this->requireRole(['super_admin', 'training_expert'], 'role-workstations');
                $res = RoleCockpitService::runBulkEnrollmentAndChecklist(
                    (string)($_POST['run_code'] ?? 'RUN-1405-A1'),
                    (string)($_POST['csv_lines'] ?? '')
                );
                $this->redirect(
                    'role-workstations?tab=training_expert',
                    'ویزارد گروهی اجرا شد: ' . $res['valid_enrolled'] . ' کد ملی معتبر ثبت‌نام شد (' . $res['rejected_invalid_melli'] . ' کد نامعتبر رد شد) — آمادگی کلاس ۱۰۰٪.'
                );
            }

            if ($action === 'process_refund') {
                $this->requireRole(['super_admin', 'finance_manager'], 'role-workstations');
                $res = RoleCockpitService::processStatutoryTuitionRefund(
                    (string)($_POST['applicant_name'] ?? 'متقاضی دوره'),
                    (string)($_POST['course_title'] ?? 'جامع اینکوترمز ۲۰۲۰'),
                    (int)($_POST['paid_tuition_rial'] ?? 52000000),
                    (int)($_POST['hours_before_start'] ?? 40)
                );
                $this->redirect(
                    'role-workstations?tab=finance_manager',
                    'استرداد آیین‌نامه‌ای ثبت شد (' . $res['refund_code'] . ' | کسر ' . $res['deduction_pct'] . '٪ | خالص قابل پرداخت: ' . number_format($res['net_refund_rial']) . ' ریال + سند دوبل ' . $res['voucher_base'] . ').'
                );
            }

            if ($action === 'create_proposal') {
                $this->requireRole(['super_admin', 'crm_manager'], 'role-workstations');
                $res = RoleCockpitService::createB2bProposalTouchpoint(
                    (string)($_POST['company_name'] ?? 'مجتمع صنعتی عضو'),
                    (string)($_POST['channel_source'] ?? 'جلسه حضوری B2B'),
                    (int)($_POST['proposed_package_rial'] ?? 750000000),
                    (string)($_POST['contact_summary'] ?? 'ارسال بسته اختصاصی آموزش صادرات و مؤدیان')
                );
                $this->redirect('role-workstations?tab=crm_manager', 'پروپوزال اختصاصی ' . $res['proposal_code'] . ' صادر و در تایم‌لاین ۳۶۰ بنگاه ثبت شد.');
            }

            if ($action === 'save_endorsement') {
                $this->requireRole(['super_admin', 'training_expert', 'instructor'], 'role-workstations');
                $res = RoleCockpitService::saveInstructorEndorsementAndSlots(
                    (string)($u['full_name'] ?? 'دکتر فرهاد رستگار'),
                    (string)($_POST['free_weekly_slots'] ?? 'یکشنبه و سه‌شنبه ۱۶ تا ۲۰'),
                    (string)($_POST['endorsed_learner_name'] ?? 'مهندس مهرداد شریفی'),
                    (string)($_POST['endorsed_skill_badge'] ?? 'تسلط عملی بر قراردادهای صادراتی ICC'),
                    (string)($_POST['recommendation_note'] ?? 'عملکرد ممتاز در کارگاه عملی و آماده معرفی به واحد صادرات کارخانجات.')
                );
                $this->redirect('role-workstations?tab=instructor', 'زمان آزاد تدریس و توصیه‌نامه رسمی استاد (' . $res['record_code'] . ') ثبت گردید.');
            }

            if ($action === 'approve_org_req') {
                $this->requireRole(['super_admin', 'training_expert', 'org_rep'], 'role-workstations');
                $res = RoleCockpitService::approveEmployeeQuotaRequest((int)$_POST['req_id']);
                $this->redirect('role-workstations?tab=org_rep', 'درخواست آموزشی «' . ($res['employee'] ?? '') . '» تأیید و از سهمیه قرارداد شرکت کسر شد.');
            }

            if ($action === 'complete_idp') {
                $this->requireRole(['super_admin', 'learner', 'org_rep'], 'role-workstations');
                $res = RoleCockpitService::completeLearnerIdpStep((int)$_POST['step_id'], (int)(Auth::id() ?? 7));
                $this->redirect('role-workstations?tab=learner', 'گام توسعه فردی تکمیل شد و +' . ($res['xp_awarded'] ?? 50) . ' XP به کیف پول شما افزوده شد.');
            }
        }

        $batchQuery = trim((string)($_GET['batch_codes'] ?? 'CERT-ADN-1405-9001, CERT-ADN-1405-8100'));
        $batchResults = RoleCockpitService::batchVerifyCertificates($batchQuery);

        $this->render('growth/role_workstations', [
            'pageTitle'   => 'میزکار اختصاصی ' . Auth::roleLabel($currentRole),
            'activeTab'   => $activeTab,
            'allowedTabs' => $allowedTabs,
            'currentRole' => $currentRole,
            'ws'          => RoleCockpitService::getAllRoleWorkstationData(),
            'batchQuery'  => $batchQuery,
            'batchResults'=> $batchResults,
        ]);
    }
}
