<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;

final class CorporateController extends Controller
{
    public function crm(): void
    {
        // مسدودسازی صریح بخش کمپین‌های CRM برای نماینده سازمان طبق نیازمندی امنیتی
        if (Auth::role() === 'org_rep' && (($_GET['section'] ?? '') === 'campaigns')) {
            Auth::audit('CRM', 'CRM_CAMPAIGNS_BLOCKED_FOR_ORG_REP', 'campaign', null, []);
            http_response_code(403);
            $this->flash('danger', 'فهرست کمپین‌های CRM برای نقش نمایندهٔ سازمان بسته است؛ دسترسی آن صرفاً مدیریتی است.');
            $this->redirect('crm');
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && Auth::hasRole(['super_admin', 'crm_manager', 'training_expert'])) {
            $action = (string)($_POST['action'] ?? '');

            if ($action === 'update_admission_status') {
                $admissionId = (int)($_POST['admission_id'] ?? 0);
                $status = (string)($_POST['status'] ?? '');
                if (!in_array($status, ['contacted', 'accepted', 'rejected'], true)) {
                    $this->flash('danger', 'وضعیت درخواست پذیرش نامعتبر است.');
                    $this->redirect('crm');
                }
                $changed = Database::execute(
                    'UPDATE student_admissions
                     SET status = ?, review_note = ?
                     WHERE id = ? AND status IN ("submitted", "contacted", "accepted")',
                    [$status, trim((string)($_POST['review_note'] ?? '')), $admissionId]
                );
                if ($changed !== 1) {
                    $current = Database::fetchOne(
                        'SELECT id FROM student_admissions
                         WHERE id = ? AND status IN ("submitted", "contacted", "accepted")',
                        [$admissionId]
                    );
                    if ($current) {
                        $this->flash('info', 'وضعیت درخواست تغییری نکرد.');
                    } else {
                        $this->flash('danger', 'درخواست پذیرش پیدا نشد یا وضعیت آن دیگر قابل تغییر نیست.');
                    }
                    $this->redirect('crm');
                }
                Auth::audit('ADMISSIONS', 'ADMISSION_STATUS_UPDATED', 'student_admission', $admissionId, ['status' => $status]);
                $this->flash('success', 'وضعیت درخواست پذیرش به‌روزرسانی شد.');
                $this->redirect('crm');
            }

            if ($action === 'enroll_admission') {
                $admissionId = (int)($_POST['admission_id'] ?? 0);
                $password = (string)($_POST['initial_password'] ?? '');
                if (strlen($password) < 12) {
                    $this->flash('danger', 'گذرواژه اولیه باید حداقل ۱۲ نویسه داشته باشد.');
                    $this->redirect('crm');
                }

                $runId = (int)($_POST['run_id'] ?? 0);
                $pdo = Database::connection();
                $pdo->beginTransaction();
                try {
                    $admissionStmt = $pdo->prepare(
                        'SELECT a.*, c.title AS course_title, c.tuition_rial
                         FROM student_admissions a
                         JOIN courses c ON c.id = a.course_id
                         WHERE a.id = ? AND a.status = "accepted" AND a.user_id IS NULL
                         FOR UPDATE'
                    );
                    $admissionStmt->execute([$admissionId]);
                    $admission = $admissionStmt->fetch(\PDO::FETCH_ASSOC);
                    if (!$admission) {
                        $pdo->rollBack();
                        $this->flash('danger', 'درخواست پذیرفته‌شدهٔ قابل ثبت‌نام پیدا نشد.');
                        $this->redirect('crm');
                    }

                    $runStmt = $pdo->prepare(
                        'SELECT id, course_id, status, capacity
                         FROM course_runs WHERE id = ? FOR UPDATE'
                    );
                    $runStmt->execute([$runId]);
                    $run = $runStmt->fetch(\PDO::FETCH_ASSOC);
                    $activeCount = 0;
                    if ($run) {
                        $countStmt = $pdo->prepare(
                            'SELECT COUNT(*) FROM enrollments WHERE run_id = ? AND status = "active"'
                        );
                        $countStmt->execute([$runId]);
                        $activeCount = (int)$countStmt->fetchColumn();
                    }
                    if (
                        !$run || (int)$run['course_id'] !== (int)$admission['course_id']
                        || $run['status'] !== 'registration' || $activeCount >= (int)$run['capacity']
                    ) {
                        $pdo->rollBack();
                        $this->flash('danger', 'اجرای انتخاب‌شده برای این دوره باز نیست یا ظرفیت آن تکمیل شده است.');
                        $this->redirect('crm');
                    }

                    $username = 'adn_' . bin2hex(random_bytes(6));
                    $userId = Database::insert(
                        'INSERT INTO users (username, email, mobile, password_hash, full_name, role, job_title)
                         VALUES (?, ?, ?, ?, ?, "learner", "دانشجوی آدان")',
                        [
                            $username,
                            $username . '@students.adan.local',
                            $admission['mobile'],
                            password_hash($password, PASSWORD_DEFAULT),
                            $admission['full_name'],
                        ]
                    );
                    $enrollmentId = Database::insert(
                        'INSERT INTO enrollments (run_id, user_id, source, status, progress_pct, attendance_pct)
                         VALUES (?, ?, "web", "active", 0, 0)',
                        [$runId, $userId]
                    );
                    Database::execute('UPDATE course_runs SET enrolled_count = ? WHERE id = ?', [$activeCount + 1, $runId]);

                    $subtotal = max(0, (int)$admission['tuition_rial']);
                    $vatRate = max(0, min(100, (int)Database::setting('vat_percent', '10')));
                    $vat = (int)round($subtotal * $vatRate / 100);
                    $invoiceNo = 'INV-ADN-' . date('Y') . '-' . strtoupper(bin2hex(random_bytes(4)));
                    $invoiceId = Database::insert(
                        'INSERT INTO invoices
                         (invoice_number, user_id, item_description, subtotal_rial, discount_rial, vat_rial, total_rial, payment_mode, status)
                         VALUES (?, ?, ?, ?, 0, ?, ?, "cash_gateway_sim", "unpaid")',
                        [
                            $invoiceNo,
                            $userId,
                            'شهریه دوره: ' . $admission['course_title'],
                            $subtotal,
                            $vat,
                            $subtotal + $vat,
                        ]
                    );
                    Database::execute('UPDATE enrollments SET invoice_id = ? WHERE id = ?', [$invoiceId, $enrollmentId]);
                    Database::execute(
                        'UPDATE student_admissions
                         SET status = "enrolled", user_id = ?, enrollment_id = ?, invoice_id = ?
                         WHERE id = ? AND status = "accepted" AND user_id IS NULL',
                        [$userId, $enrollmentId, $invoiceId, $admissionId]
                    );
                    $pdo->commit();
                } catch (\Throwable $e) {
                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                    }
                    throw $e;
                }

                Auth::audit('ADMISSIONS', 'ADMISSION_ENROLLED', 'student_admission', $admissionId, ['user_id' => $userId, 'invoice_id' => $invoiceId]);
                $this->flash('success', "ثبت‌نام انجام شد؛ نام کاربری دانشجو {$username} است و فاکتور شهریه {$invoiceNo} با وضعیت پرداخت‌نشده صادر شد.");
                $this->redirect('crm');
            }

            if ($action === 'create_deal') {
                Database::insert(
                    'INSERT INTO crm_deals (org_id, title, estimated_value_rial, stage, probability_pct, next_followup_shamsi, owner_user_id, notes)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                    [
                        (int)$_POST['org_id'],
                        trim((string)$_POST['title']),
                        (int)$_POST['estimated_value_rial'],
                        (string)$_POST['stage'],
                        (int)$_POST['probability_pct'],
                        trim((string)$_POST['next_followup_shamsi']),
                        Auth::id(),
                        trim((string)($_POST['notes'] ?? '')),
                    ]
                );
                $this->flash('success', 'فرصت فروش سازمانی جدید در قیف CRM ثبت گردید.');
                $this->redirect('crm');
            }

            if ($action === 'move_stage') {
                $stage = (string)($_POST['stage'] ?? '');
                if (!in_array($stage, ['lead', 'qualified', 'proposal', 'negotiation', 'won', 'lost'], true)) {
                    $this->flash('danger', 'مرحلهٔ انتخاب‌شده برای فرصت فروش معتبر نیست.');
                    $this->redirect('crm');
                }
                Database::execute('UPDATE crm_deals SET stage = ? WHERE id = ?', [$stage, (int)($_POST['deal_id'] ?? 0)]);
                $this->flash('success', 'مرحله فرصت فروش در قیف CRM به‌روزرسانی شد.');
                $this->redirect('crm');
            }

            if ($action === 'convert_deal_to_contract') {
                $dealId = (int)($_POST['deal_id'] ?? 0);
                $pdo = Database::connection();
                $pdo->beginTransaction();
                try {
                    $dealStmt = $pdo->prepare('SELECT * FROM crm_deals WHERE id = ? FOR UPDATE');
                    $dealStmt->execute([$dealId]);
                    $deal = $dealStmt->fetch(\PDO::FETCH_ASSOC);
                    if (!$deal || $deal['stage'] !== 'won') {
                        $pdo->rollBack();
                        $this->flash('danger', 'فقط فرصت فروشِ برنده را می‌توان به قرارداد تبدیل کرد.');
                        $this->redirect('crm');
                    }

                    $marker = 'تبدیل خودکار از فرصت برنده CRM شماره #' . $dealId;
                    $existing = $pdo->prepare('SELECT contract_no FROM corporate_contracts WHERE deliverables_summary = ? LIMIT 1');
                    $existing->execute([$marker]);
                    $existingContractNo = $existing->fetchColumn();
                    if ($existingContractNo !== false) {
                        $pdo->commit();
                        $this->flash('info', "این فرصت قبلاً به قرارداد {$existingContractNo} تبدیل شده است.");
                        $this->redirect('contracts');
                    }

                    $cno = 'CNT-1405-' . strtoupper(bin2hex(random_bytes(4)));
                    Database::insert(
                        'INSERT INTO corporate_contracts (contract_no, org_id, title, total_amount_rial, paid_amount_rial, seat_quota, start_shamsi, end_shamsi, approval_stage, deliverables_summary)
                         VALUES (?, ?, ?, ?, 0, 30, "۱۴۰۵/۰۸/۰۱", "۱۴۰۶/۰۷/۳۰", "approved_active", ?)',
                        [$cno, (int)$deal['org_id'], $deal['title'], (int)$deal['estimated_value_rial'], $marker]
                    );
                    $pdo->commit();
                    $this->flash('success', "فرصت فروش برنده با یک کلیک به قرارداد فعال شماره {$cno} تبدیل شد.");
                } catch (\Throwable $e) {
                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                    }
                    throw $e;
                }
                $this->redirect('contracts');
            }
        }

        $orgs = Database::fetchAll('SELECT * FROM organizations ORDER BY id ASC');
        $contacts = Database::fetchAll(
            'SELECT c.*, o.name AS org_name FROM crm_contacts c LEFT JOIN organizations o ON o.id = c.org_id ORDER BY c.lead_score DESC'
        );
        $deals = Database::fetchAll(
            'SELECT d.*, o.name AS org_name FROM crm_deals d JOIN organizations o ON o.id = d.org_id ORDER BY d.id DESC'
        );
        $admissions = Database::fetchAll(
            'SELECT a.*, c.title AS course_title, u.username, i.invoice_number, i.status AS invoice_status
             FROM student_admissions a
             JOIN courses c ON c.id = a.course_id
             LEFT JOIN users u ON u.id = a.user_id
             LEFT JOIN invoices i ON i.id = a.invoice_id
             ORDER BY a.submitted_at DESC'
        );
        $admissionRuns = Database::fetchAll(
            'SELECT r.id, r.course_id, r.run_code, r.term_label, r.capacity,
                    (SELECT COUNT(*) FROM enrollments e WHERE e.run_id = r.id AND e.status = "active") AS enrolled_count,
                    c.title AS course_title
             FROM course_runs r
             JOIN courses c ON c.id = r.course_id
             WHERE r.status = "registration"
             ORDER BY r.start_date ASC'
        );

        // کمپین‌ها صرفاً برای نقش‌های مدیریتی واکشی می‌شوند
        $canViewCampaigns = Auth::hasRole(['super_admin', 'crm_manager', 'training_expert']);
        $campaigns = $canViewCampaigns ? Database::fetchAll('SELECT * FROM marketing_campaigns ORDER BY id DESC') : [];

        $this->render('corporate/crm', [
            'pageTitle' => 'CRM آموزشی، پذیرش و قراردادهای آموزشگاه آدان',
            'orgs' => $orgs,
            'contacts' => $contacts,
            'deals' => $deals,
            'admissions' => $admissions,
            'admissionRuns' => $admissionRuns,
            'canViewCampaigns' => $canViewCampaigns,
            'campaigns' => $campaigns,
        ]);
    }

    public function contracts(): void
    {
        $role = Auth::role();
        $orgScope = $role === 'org_rep' ? (int)(Auth::user()['org_id'] ?? 0) : null;

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && Auth::hasRole(['super_admin', 'crm_manager', 'finance_manager', 'training_expert'])) {
            $action = (string)($_POST['action'] ?? '');

            if ($action === 'create_contract') {
                $no = 'CNT-1405-' . rand(500, 999);
                Database::insert(
                    'INSERT INTO corporate_contracts (contract_no, org_id, title, total_amount_rial, paid_amount_rial, seat_quota, start_shamsi, end_shamsi, approval_stage, deliverables_summary)
                     VALUES (?, ?, ?, ?, 0, ?, "۱۴۰۵/۰۸/۰۱", "۱۴۰۶/۰۷/۳۰", "finance_review", ?)',
                    [
                        $no,
                        (int)$_POST['org_id'],
                        trim((string)$_POST['title']),
                        (int)$_POST['total_amount_rial'],
                        (int)$_POST['seat_quota'],
                        trim((string)$_POST['deliverables_summary']),
                    ]
                );
                Auth::audit('CONTRACTS', 'CONTRACT_CREATED', 'contract', null, ['contract_no' => $no]);
                $this->flash('success', "قرارداد سازمانی شماره {$no} ثبت و وارد گردش تصویب مالی شد.");
                $this->redirect('contracts');
            }

            if ($action === 'approve_contract') {
                Database::execute(
                    'UPDATE corporate_contracts SET approval_stage = "approved_active" WHERE id = ?',
                    [(int)$_POST['contract_id']]
                );
                $this->flash('success', 'قرارداد سازمانی تصویب نهایی شد و سقف سهمیه آن در داشبورد سازمان فعال گردید.');
                $this->redirect('contracts');
            }
        }

        $contracts = $orgScope !== null
            ? Database::fetchAll('SELECT c.*, o.name AS org_name FROM corporate_contracts c JOIN organizations o ON o.id = c.org_id WHERE c.org_id = ? ORDER BY c.id DESC', [$orgScope])
            : Database::fetchAll('SELECT c.*, o.name AS org_name FROM corporate_contracts c JOIN organizations o ON o.id = c.org_id ORDER BY c.id DESC');

        $orgs = Database::fetchAll('SELECT id, name FROM organizations ORDER BY id ASC');
        $burnAlerts = Database::fetchAll('SELECT * FROM b2b_quota_burn_alerts ORDER BY id ASC');

        $this->render('corporate/contracts', [
            'pageTitle' => 'مدیریت قراردادهای سازمانی، پایش هوشمند نرخ مصرف سهمیه و الحاقیه خودکار',
            'contracts' => $contracts,
            'orgs' => $orgs,
            'burnAlerts' => $burnAlerts,
        ]);
    }
}
