<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Core\Jalali;
use App\Services\VoiceCommandService;
use App\Services\VoiceReportStudioService;

/**
 * ★ مرکز فرماندهی صوتی + استودیوی گزارش‌ساز صوتی (نسخه v26.8)
 *
 * این صفحه یک صفحه مدیریتی است: فقط نقش‌های ستون (غير از فراگیر) می‌توانند وارد آن شوند و
 * فهرست گزارش‌ها بر اساس نقشِ همان کاربر فیلتر می‌شود؛ بنابراین مدیر مالی گزارش شایع CRM
 * را نمی‌بیند و نماینده بنگاه فقط گزارش‌های مجاز خود را می‌تواند تولید کند.
 */
final class VoiceAssistantController extends Controller
{
    public function index(): void
    {
        // ★ v26.8 — قفل سمت سرور: مرکز فرماندهی صوتی و استودیوی گزارش، ویژه نقش‌های ستون
        $this->requireRole(self::STAFF_ROLES, 'dashboard');

        $user = Auth::user() ?: [];
        $role = (string)Auth::role();
        $lastResult = null;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $action = (string)($_POST['action'] ?? '');

            if ($action === 'generate_voice_report') {
                $kind = trim((string)($_POST['kind'] ?? ''));
                $rep = VoiceReportStudioService::generate($kind, $user, 'browser_tts');
                if (empty($rep['ok'])) {
                    $this->redirect('voice-assistant', (string)($rep['message'] ?? 'تولید گزارش ناموفق بود.'), 'error');
                }
                $this->redirect(
                    'voice-assistant?played=' . rawurlencode((string)$rep['report_code']),
                    '🎙️ گزارش «' . $rep['title'] . '» تولید و بایگانی شد — مدت تقریبی خوانش '
                        . Jalali::digits((string)$rep['est_duration_sec']) . ' ثانیه ('
                        . Jalali::digits((string)$rep['speech_chars']) . ' نویسه).'
                );
            }

            if ($action === 'execute_voice_form') {
                $cmd = trim((string)($_POST['spoken_text'] ?? ''));
                $lastResult = VoiceCommandService::processCommand((int)Auth::id(), $cmd, 'voice-assistant');
            }
        }

        // دانلود متن یک گزارش بایگانی‌شده (فقط گزارش‌های مجاز همان نقش — کنترل داخل سرویس)
        if (isset($_GET['action'], $_GET['id']) && $_GET['action'] === 'download_report') {
            $row = VoiceReportStudioService::archiveById((int)$_GET['id']);
            if ($row === null) {
                $this->requireRole(self::STAFF_ROLES, 'voice-assistant');
                http_response_code(404);
                echo 'گزارشی با این شناسه در دسترس شما نیست.';
                return;
            }
            while (ob_get_level() > 0) {
                ob_end_clean();
            }
            header('Content-Type: text/plain; charset=utf-8');
            header('Content-Disposition: attachment; filename="' . preg_replace('/[^A-Za-z0-9_\-]/', '', (string)$row['report_code']) . '.txt"');
            echo VoiceReportStudioService::asTextFile($row);
            return;
        }

        $logs = Database::fetchAllSafe(
            'SELECT v.*, u.full_name
             FROM voice_command_logs v
             LEFT JOIN users u ON u.id = v.user_id
             ORDER BY v.id DESC LIMIT 30',
            [],
            []
        );

        $stats = [
            'total_commands' => (int)Database::scalarSafe('SELECT COUNT(*) FROM voice_command_logs'),
            'actions_run' => (int)Database::scalarSafe("SELECT COUNT(*) FROM voice_command_logs WHERE detected_intent = 'EXECUTE_ACTION'"),
            'reports_run' => (int)Database::scalarSafe("SELECT COUNT(*) FROM voice_command_logs WHERE detected_intent = 'LIVE_REPORT'"),
            'nav_routes' => count(VoiceCommandService::getNavigationDictionary()),
        ];

        $this->render('growth/voice_assistant', [
            'pageTitle' => 'مرکز فرماندهی صوتی سراسری، استودیوی گزارش‌ساز صوتی و اجرای خودکار دستورات',
            'logs' => $logs,
            'stats' => $stats,
            'lastResult' => $lastResult,
            'studioCatalog' => VoiceReportStudioService::catalogForRole($role),
            'studioGroups' => VoiceReportStudioService::groupsForRole($role),
            'studioStats' => VoiceReportStudioService::stats(),
            'studioArchive' => VoiceReportStudioService::archive($user, 14),
            'adoption' => VoiceReportStudioService::adoptionBundle(),
            'playedCode' => trim((string)($_GET['played'] ?? '')),
        ]);
    }
}
