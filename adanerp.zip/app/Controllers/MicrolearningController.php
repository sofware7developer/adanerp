<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Services\LearnerCoachService;
use App\Core\Database;
use App\Core\Jalali;
use App\Services\MicrolearningEngineService;

final class MicrolearningController extends Controller
{
    public function index(): void
    {
        $uid = max(1, (int)(Auth::id() ?? 7));
        $u = Auth::user();
        $uname = (string)($u['full_name'] ?? 'مهندس مهرداد شریفی');
        $activeTab = trim((string)($_GET['tab'] ?? 'capsules'));

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $action = (string)($_POST['action'] ?? '');

            // ★ v26.6 — قفل سمت سرور: این اکشن‌ها اقدام مدیریتی/مدرسی‌اند و برای نقش فراگیر ۴۰۳ برمی‌گردند
            $this->denyLearnerActions($action, ['ai_generate_capsule', 'create_job_aid'], 'microlearning');

            // ★ v26.8 — قابلیت‌های هوشمند «خودی» فراگیر: اثر فقط روی کارت‌ها و پرونده خود کاربر
            if ($action === 'generate_my_cards') {
                $res = LearnerCoachService::generatePersonalCards($uid, (int)($_POST['card_count'] ?? 6));
                $this->redirect(
                    'microlearning?tab=mycards',
                    '🃏 ' . $res['message'] . ' اکنون می‌توانید آن‌ها را در همین تب یا در جعبه لایتنر مرور کنید.'
                );
            }

            if ($action === 'delete_my_card') {
                $ok = LearnerCoachService::deletePersonalCard($uid, (int)($_POST['card_id'] ?? 0));
                $this->redirect(
                    'microlearning?tab=mycards',
                    $ok ? 'کارت شخصی حذف شد و از برنامه مرور شما خارج گردید.' : 'چنین کارتی در مجموعه شخصی شما پیدا نشد.',
                    $ok ? 'success' : 'error'
                );
            }

            if ($action === 'quiz_generate') {
                $quiz = LearnerCoachService::buildSelfQuiz($uid, (int)($_POST['quiz_course_id'] ?? 0));
                if (empty($quiz['ok'])) {
                    $this->redirect('microlearning?tab=selfquiz', (string)($quiz['message'] ?? 'سؤالی ساخته نشد.'), 'error');
                }
                $_SESSION['self_quiz'] = $quiz;
                unset($_SESSION['self_quiz_result']);
                $this->redirect(
                    'microlearning?tab=selfquiz',
                    '🎯 ' . Jalali::digits((string)count($quiz['questions'])) . ' سؤال از داده‌های واقعی دوره «'
                        . $quiz['course_title'] . '» ساخته شد — پاسخ دهید و همان لحظه تصحیح شوید.'
                );
            }

            if ($action === 'quiz_submit') {
                $quiz = is_array($_SESSION['self_quiz'] ?? null) ? (array)$_SESSION['self_quiz'] : [];
                $grade = LearnerCoachService::gradeSelfQuiz($uid, $uname, $quiz, (array)($_POST['answers'] ?? []));
                if (empty($grade['ok'])) {
                    $this->redirect('microlearning?tab=selfquiz', 'ابتدا باید سؤالات را بسازید.', 'error');
                }
                $_SESSION['self_quiz_result'] = $grade;
                $this->redirect(
                    'microlearning?tab=selfquiz',
                    'نتیجه آزمون خودساز: ' . Jalali::digits((string)$grade['right']) . ' از ' . Jalali::digits((string)$grade['total'])
                        . ' صحیح (' . Jalali::digits((string)$grade['score_pct']) . '٪) • +' . Jalali::digits((string)$grade['xp']) . ' XP'
                );
            }

            if ($action === 'complete_capsule') {
                $res = MicrolearningEngineService::completeCapsuleWithQuiz(
                    $uid,
                    $uname,
                    (int)($_POST['capsule_id'] ?? 1),
                    (string)($_POST['selected_opt'] ?? 'B')
                );
                $verdict = !empty($res['is_correct'])
                    ? ('آفرین! پاسخ کاملاً صحیح بود و کپسول «' . ($res['capsule_code'] ?? '') . '» با موفقیت تثبیت شد (+' . ($res['xp_earned'] ?? 35) . ' XP به کیف پول گیمیفیکیشن اضافه شد).')
                    : ('کپسول مرور شد؛ گزینه صحیح «' . ($res['correct_opt'] ?? 'B') . '» بود (+' . ($res['xp_earned'] ?? 15) . ' XP بابت تلاش ثبت شد).');
                $this->redirect('microlearning?tab=capsules', $verdict);
            }

            if ($action === 'review_flashcard') {
                $res = MicrolearningEngineService::reviewFlashcardSm2(
                    $uid,
                    $uname,
                    (int)($_POST['card_id'] ?? 1),
                    (string)($_POST['quality'] ?? 'easy')
                );
                $this->redirect(
                    'microlearning?tab=leitner',
                    'فلش‌کارت «' . ($res['card_code'] ?? '') . '» با الگوریتم SM-2 به خانه ' . ($res['new_box'] ?? 2) . ' لایتنر منتقل شد (مرور بعدی: ' . ($res['new_interval_days'] ?? 4) . ' روز دیگر | +' . ($res['xp_earned'] ?? 20) . ' XP).'
                );
            }

            if ($action === 'ai_generate_capsule') {
                $res = MicrolearningEngineService::generateMicroCapsuleFromText(
                    (string)($_POST['topic_title'] ?? ''),
                    (string)($_POST['topic_domain'] ?? 'تجارت بین‌الملل'),
                    (string)($_POST['raw_source_text'] ?? ''),
                    (int)($_POST['duration_seconds'] ?? 180)
                );
                $this->redirect(
                    'microlearning?tab=capsules',
                    'بخشنامه/متن شما توسط هوش مصنوعی به کپسول ۳ دقیقه‌ای (' . $res['capsule_code'] . ') و فلش‌کارت مرور فاصله‌دار (' . $res['flashcard_code'] . ') تبدیل شد!'
                );
            }

            if ($action === 'submit_daily_challenge') {
                $res = MicrolearningEngineService::submitDailyMicroChallenge(
                    $uid,
                    $uname,
                    (int)($_POST['challenge_id'] ?? 1),
                    (int)($_POST['picked_option'] ?? 2)
                );
                $this->redirect('microlearning?tab=challenge', ($res['explanation'] ?? '') . ' (+' . ($res['xp_earned'] ?? 50) . ' XP)');
            }

            if ($action === 'create_job_aid') {
                $res = MicrolearningEngineService::saveJobAidCheatSheet($_POST);
                $this->redirect('microlearning?tab=jobaids', 'تقلب‌نامه عملیاتی و اسکریپت میکروپادکست با کد «' . $res['aid_code'] . '» منتشر شد.');
            }
        }

        $hub = MicrolearningEngineService::getMicrolearningHubBundle($uid);
        // ★ v26.8 — بسته مربی هوشمند (فقط برای فراگیر: کارت‌های شخصی، آزمون خودساز، پیش‌بینی فراموشی)
        $isLearnerMicro = ((string)Auth::role()) === 'learner';
        $coach = $isLearnerMicro ? LearnerCoachService::coachBundle($uid, $u ?: []) : [];
        $this->render('growth/microlearning', [
            'pageTitle' => 'پلتفرم جامع میکرولرنینگ (یادگیری خرد ۳ دقیقه‌ای)، جعبه لایتنر SM-2 و کپسول‌ساز AI',
            'activeTab' => $activeTab,
            'hub'       => $hub,
            'isLearnerMicro' => $isLearnerMicro,
            'coach'     => $coach,
            'personalCards' => Database::fetchAllSafe(
                'SELECT * FROM micro_spaced_flashcards WHERE owner_user_id = ? ORDER BY id DESC LIMIT 40',
                [$uid],
                []
            ),
            'quizDraft'   => is_array($_SESSION['self_quiz'] ?? null) ? (array)$_SESSION['self_quiz'] : null,
            'quizResult'  => is_array($_SESSION['self_quiz_result'] ?? null) ? (array)$_SESSION['self_quiz_result'] : null,
            'myCourses'   => Database::fetchAllSafe(
                'SELECT DISTINCT c.id, c.title FROM enrollments e
                 JOIN course_runs r ON r.id = e.run_id JOIN courses c ON c.id = r.course_id
                 WHERE e.user_id = ? ORDER BY c.id DESC LIMIT 12',
                [$uid],
                []
            ),
        ]);
    }
}
