<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;

final class PortalController extends Controller
{
    public function index(): void
    {
        $user = Auth::user();
        $uid = (int)$user['id'];
        $orgId = (int)($user['org_id'] ?? 1);

        if (!empty($_GET['export_ics'])) {
            header('Content-Type: text/calendar; charset=utf-8');
            header('Content-Disposition: attachment; filename="adan-class-schedule.ics"');
            echo "BEGIN:VCALENDAR\r\nVERSION:2.0\r\nPRODID:-//AdanAccountingInstitute//FA\r\nCALSCALE:GREGORIAN\r\n";
            foreach (Database::fetchAll('SELECT r.run_code, r.schedule_text, c.title FROM course_runs r JOIN courses c ON c.id = r.course_id LIMIT 6') as $ev) {
                echo "BEGIN:VEVENT\r\nUID:" . $ev['run_code'] . "@adan.local\r\nDTSTART:20261101T103000Z\r\nDTEND:20261101T143000Z\r\nSUMMARY:" . $ev['title'] . "\r\nDESCRIPTION:" . $ev['schedule_text'] . "\r\nEND:VEVENT\r\n";
            }
            echo "END:VCALENDAR\r\n";
            exit;
        }

        if (!empty($_GET['export_org_report']) && Auth::hasRole(['org_rep', 'super_admin', 'training_expert'])) {
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="adan-student-report-' . $orgId . '.csv"');
            echo "\xEF\xBB\xBFنام دانشجو,وضعیت آموزشی,تلفن همراه,وضعیت حساب\n";
            foreach (Database::fetchAll('SELECT full_name, job_title, mobile, status FROM users WHERE org_id = ?', [$orgId]) as $emp) {
                echo '"' . str_replace('"', '""', (string)$emp['full_name']) . '","' . str_replace('"', '""', (string)$emp['job_title']) . '","' . $emp['mobile'] . '","' . $emp['status'] . "\"\n";
            }
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $action = (string)($_POST['action'] ?? '');

            // این عملیات مدیریتی برای نقش دانشجو مجاز نیست.
            $this->denyLearnerActions($action, ['add_org_employee'], 'portal');

            // نماینده سازمان صرفاً مجاز به افزودن کارمند زیرمجموعه سازمان خودش است
            if ($action === 'add_org_employee' && Auth::hasRole(['org_rep', 'super_admin', 'training_expert'])) {
                $fullName = trim((string)($_POST['full_name'] ?? ''));
                $password = (string)($_POST['password'] ?? '');
                if ($fullName === '' || strlen($password) < 12) {
                    $this->flash('danger', 'نام دانشجو الزامی است و گذرواژه باید حداقل ۱۲ نویسه داشته باشد.');
                    $this->redirect('portal');
                }

                $targetOrg = Auth::role() === 'org_rep' ? $orgId : (int)($_POST['org_id'] ?? $orgId);
                $uname = 'student_' . bin2hex(random_bytes(6));
                $hash = password_hash($password, PASSWORD_DEFAULT);
                Database::insert(
                    'INSERT INTO users (org_id, username, email, mobile, password_hash, full_name, role, job_title)
                     VALUES (?, ?, ?, ?, ?, ?, "learner", ?)',
                    [
                        $targetOrg,
                        $uname,
                        $uname . '@students.adan.local',
                        trim((string)($_POST['mobile'] ?? '')) ?: null,
                        $hash,
                        $fullName,
                        trim((string)($_POST['job_title'] ?? 'دانشجوی حسابداری')),
                    ]
                );
                Auth::audit('PORTAL_ORG', 'ORG_EMPLOYEE_ADDED', 'organization', $targetOrg, ['username' => $uname]);
                $this->flash('success', "دانشجو ثبت شد. نام کاربری ورود: {$uname}");
                $this->redirect('portal');
            }

            if ($action === 'create_ticket') {
                Database::insert(
                    'INSERT INTO support_tickets (user_id, subject, department, message) VALUES (?, ?, ?, ?)',
                    [$uid, trim((string)$_POST['subject']), (string)$_POST['department'], trim((string)$_POST['message'])]
                );
                $this->flash('success', 'تیکت پشتیبانی شما ثبت و به واحد مربوطه ارجاع شد.');
                $this->redirect('portal');
            }
        }

        $myCourses = Database::fetchAll(
            'SELECT e.*, r.run_code, r.start_shamsi, r.schedule_text, c.title AS course_title
             FROM enrollments e
             JOIN course_runs r ON r.id = e.run_id
             JOIN courses c ON c.id = r.course_id
             WHERE e.user_id = ? OR ? IN ("super_admin","org_rep")
             ORDER BY e.id DESC LIMIT 8',
            [$uid, Auth::role()]
        );

        $myCerts = Database::fetchAll(
            'SELECT cert.*, c.title AS course_title
             FROM certificates cert
             JOIN courses c ON c.id = cert.course_id
             WHERE (cert.user_id = ? OR ? = "super_admin") AND cert.status = "valid"',
            [$uid, Auth::role()]
        );

        $orgEmployees = Database::fetchAll('SELECT id, full_name, email, job_title, mobile FROM users WHERE org_id = ?', [$orgId]);
        $orgContracts = Database::fetchAll('SELECT * FROM corporate_contracts WHERE org_id = ?', [$orgId]);
        $tickets = Database::fetchAll(
            'SELECT * FROM support_tickets WHERE user_id = ? OR ? IN ("super_admin","training_expert") ORDER BY id DESC',
            [$uid, Auth::role()]
        );

        $this->render('portal/index', [
            'pageTitle' => 'پرونده آموزشی دانشجوی آدان',
            'myCourses' => $myCourses,
            'myCerts' => $myCerts,
            'orgEmployees' => $orgEmployees,
            'orgContracts' => $orgContracts,
            'tickets' => $tickets,
        ]);
    }

    public function publicHome(): void
    {
        $page = Database::fetchOne('SELECT * FROM portal_pages WHERE slug = "home" AND is_published = 1 ORDER BY version_no DESC LIMIT 1')
            ?: Database::fetchOne('SELECT * FROM portal_pages ORDER BY id DESC LIMIT 1');
        $courses = Database::fetchAll("SELECT * FROM courses WHERE workflow_status = 'published' ORDER BY id ASC LIMIT 6");
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'submit_admission') {
            $fullName = trim((string)($_POST['full_name'] ?? ''));
            $mobile = trim((string)($_POST['mobile'] ?? ''));
            $courseId = (int)($_POST['course_id'] ?? 0);
            $course = Database::fetchOne(
                'SELECT id FROM courses WHERE id = ? AND workflow_status = "published"',
                [$courseId]
            );
            if ($fullName === '' || $mobile === '' || !$course) {
                $this->flash('danger', 'نام، شماره همراه و یک دوره منتشرشده را برای ثبت درخواست انتخاب کنید.');
                $this->redirect('public-home');
            }

            Database::insert(
                'INSERT INTO student_admissions (full_name, mobile, course_id, prior_education)
                 VALUES (?, ?, ?, ?)',
                [
                    $fullName,
                    $mobile,
                    $courseId,
                    trim((string)($_POST['prior_education'] ?? '')) ?: null,
                ]
            );
            $this->redirect('public-home', 'درخواست پذیرش ثبت شد؛ پس از بررسی، کارشناسان آموزشگاه با شما تماس می‌گیرند.');
        }

        $events = Database::fetchAll('SELECT * FROM events ORDER BY id ASC LIMIT 4');
        $publicJobs = Database::fetchAll('SELECT * FROM career_job_ads WHERE ad_status = "active" ORDER BY is_urgent DESC, id DESC LIMIT 4');

        $this->render('portal/public_home', [
            'pageTitle' => 'دوره‌های آموزشگاه حسابداری آدان',
            'page' => $page,
            'courses' => $courses,
            'events' => $events,
            'publicJobs' => $publicJobs,
        ], 'public');
    }

    public function verify(): void
    {
        $code = trim((string)($_GET['code'] ?? ''));
        $cert = null;
        if ($code !== '') {
            $cert = Database::fetchOne(
                'SELECT cert.*, u.full_name, c.title AS course_title, c.code AS course_code
                 FROM certificates cert
                 JOIN users u ON u.id = cert.user_id
                 JOIN courses c ON c.id = cert.course_id
                 WHERE cert.serial_code = ?',
                [$code]
            );
        }

        $batchCodes = trim((string)($_GET['batch_codes'] ?? ''));
        $batchResults = $batchCodes !== '' ? \App\Services\RoleCockpitService::batchVerifyCertificates($batchCodes) : [];

        $this->render('portal/verify', [
            'pageTitle' => 'بررسی وضعیت گواهی‌نامه‌های صادرشده توسط آموزشگاه آدان',
            'code' => $code,
            'cert' => $cert,
            'batchCodes' => $batchCodes,
            'batchResults' => $batchResults,
        ], 'public');
    }

    public function passport(): void
    {
        $slug = trim((string)($_GET['u'] ?? $_GET['username'] ?? 'mehrdad-sharifi'));
        $profile = Database::fetchOne(
            'SELECT u.*, o.name AS org_name
             FROM users u
             LEFT JOIN organizations o ON o.id = u.org_id
             WHERE u.public_passport_slug = ? OR u.username = ?',
            [$slug, $slug]
        );

        if (!empty($_GET['openbadge'])) {
            if (!$profile || (int)$profile['passport_is_public'] !== 1) {
                $this->json(['ok' => false, 'error' => 'public_passport_not_found'], 404);
            }

            $this->json([
                'record_type' => 'adan_local_skill_passport_draft',
                'status' => 'unsigned_local_draft',
                'issuer' => 'آموزشگاه حسابداری آدان',
                'subject' => [
                    'full_name' => $profile['full_name'],
                    'achievement' => 'گذرنامه مهارت‌های حسابداری و مالی',
                ],
                'generated_at' => date('c'),
                'disclaimer' => 'این خروجی پیش‌نویس محلی است؛ امضای رمزنگاری‌شده یا اعتبارسنجی W3C ندارد.',
            ]);
        }

        $badges = [];
        $certs = [];
        if ($profile && (int)$profile['passport_is_public'] === 1) {
            $badges = Database::fetchAll('SELECT * FROM user_badges WHERE user_id = ?', [(int)$profile['id']]);
            $certs = Database::fetchAll(
                "SELECT cert.*, c.title AS course_title FROM certificates cert JOIN courses c ON c.id = cert.course_id WHERE cert.user_id = ? AND cert.status = 'valid'",
                [(int)$profile['id']]
            );
        }

        $hashBlocks = [];
        if ($profile && (int)$profile['passport_is_public'] === 1) {
            $credentialCodes = array_values(array_unique(array_filter(array_merge(
                array_column($certs, 'serial_code'),
                array_column($badges, 'badge_code')
            ), static fn($code): bool => is_string($code) && $code !== '')));
            if ($credentialCodes !== []) {
                $placeholders = implode(',', array_fill(0, count($credentialCodes), '?'));
                $hashBlocks = Database::fetchAll(
                    "SELECT * FROM verifiable_credential_blocks
                     WHERE cert_or_badge_code IN ($placeholders)
                     ORDER BY id DESC LIMIT 10",
                    $credentialCodes
                );
            }
        }

        $this->render('portal/passport', [
            'pageTitle' => 'گذرنامهٔ مهارت و سوابق آموزشی آدان',
            'profile' => $profile,
            'badges' => $badges,
            'certs' => $certs,
            'hashBlocks' => $hashBlocks,
        ], 'public');
    }
}
