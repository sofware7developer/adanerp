<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Core\Jalali;

final class ChamberSecurityBranchController extends Controller
{
    // احراز هویت یکپارچه کشوری، تطبیق شاهکار، OTP و امضای دیجیتال اسناد
    public function ssoPki(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'sign_document') {
            $u = Auth::user();
            $doc = trim((string)($_POST['document_title'] ?? ''));
            if ($doc === '') {
                $this->flash('danger', 'عنوان سند برای ثبت پیش‌نویس محلی الزامی است.');
                $this->redirect('sso-pki');
            }
            $hash = hash('sha256', $doc . '|' . date('c'));

            Database::insert(
                'INSERT INTO sso_pki_logs (user_full_name, national_code, mobile_number, shahkar_status, document_title, pki_hash_sha256, signed_shamsi)
                 VALUES (?, "", "", "شبیه‌سازی محلی - شاهکار و امضای PKI متصل نیست", ?, ?, ?)',
                [$u['full_name'] ?? 'کاربر رسمی', $doc, $hash, Jalali::today() . ' ساعت ' . Jalali::digits(date('H:i'))]
            );
            Auth::audit('SSO_PKI', 'LOCAL_DOCUMENT_DIGEST_CREATED', 'sso_pki_logs', null, ['hash' => substr($hash, 0, 16)]);
            $this->flash('warning', 'فقط چکیدهٔ آزمایشی محلی ثبت شد؛ هویت استعلام نشده و سند با PKI امضا نشده است.');
            $this->redirect('sso-pki');
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'scan_soc_event') {
            $res = \App\Services\DeepModuleSuiteService::evaluateSecuritySocEvent(
                (string)($_POST['actor_username'] ?? 'orgrep'),
                (string)($_POST['client_ip'] ?? '91.214.124.99'),
                (int)($_POST['failed_attempts'] ?? 5)
            );
            $this->redirect('sso-pki', 'ارزیابی نمایشی SOC ثبت شد (' . $res['event_code'] . ' — امتیاز نمونه: ' . $res['risk_score'] . '/100). هیچ IP یا نشستی قرنطینه نشده است.');
        }

        $this->render('secbranch/sso_pki', [
            'pageTitle' => 'آماده‌سازی اتصال شاهکار و امضای PKI (فعلاً شبیه‌ساز محلی)',
            'logs' => Database::fetchAll('SELECT * FROM sso_pki_logs ORDER BY id DESC'),
            'socEvents' => Database::fetchAll('SELECT * FROM security_soc_telemetry ORDER BY id DESC'),
        ]);
    }

    // نظارت هوشمند سلامت آزمون (Online Proctoring) و واترمارک پویا (DRM)
    public function proctoringDrm(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $action = (string)($_POST['action'] ?? '');

            if ($action === 'log_proctoring_event') {
                Database::insert(
                    'INSERT INTO proctoring_events (user_full_name, exam_or_lesson_title, event_type, risk_level, watermark_stamp, reviewer_decision)
                     VALUES (?, ?, ?, ?, ?, "در انتظار بازبینی کمیته")',
                    [
                        trim((string)$_POST['user_full_name']),
                        trim((string)$_POST['exam_or_lesson_title']),
                        (string)$_POST['event_type'],
                        (string)$_POST['risk_level'],
                        'DEMO-LOCAL | حسگر و DRM فعال نیست',
                    ]
                );
                $this->flash('warning', 'رخداد نمایشی به صورت دستی ثبت شد؛ حسگر نظارتی یا DRM واقعی فعال نیست.');
                $this->redirect('proctoring-drm');
            }

            if ($action === 'save_cat_session') {
                $res = \App\Services\DeepModuleSuiteService::recordAdaptiveCatSession(
                    (string)($_POST['candidate_name'] ?? 'داوطلب آزمون تطبیقی'),
                    (string)($_POST['domain_title'] ?? 'آزمون تطبیقی حقوق تجارت بین‌الملل'),
                    (int)($_POST['correct_count'] ?? 5),
                    (int)($_POST['final_level'] ?? 4),
                    (int)($_POST['tab_switches'] ?? 0)
                );
                $this->redirect('proctoring-drm', 'نشست آزمون تطبیقی هوشمند (CAT) با کد «' . $res['session_code'] . '» و تراز توانایی θ=' . $res['theta'] . ' ثبت شد.');
            }

            if ($action === 'adjudicate_event') {
                Database::execute(
                    'UPDATE proctoring_events SET reviewer_decision = ? WHERE id = ?',
                    [trim((string)$_POST['reviewer_decision']), (int)$_POST['event_id']]
                );
                $this->flash('success', 'رای کمیته نظارت بر سلامت آزمون ثبت گردید.');
                $this->redirect('proctoring-drm');
            }
        }

        $this->render('secbranch/proctoring_drm', [
            'pageTitle' => 'پیش‌نمایش CAT و ثبت دستی رخداد (بدون پروکتورینگ/DRM)',
            'events' => Database::fetchAll('SELECT * FROM proctoring_events ORDER BY id DESC'),
            'catSessions' => Database::fetchAll('SELECT * FROM adaptive_cat_sessions ORDER BY id DESC'),
        ]);
    }

}
