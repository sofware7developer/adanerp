<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\App;
use App\Core\Auth;
use App\Core\Controller;

final class AuthController extends Controller
{
    public function login(): void
    {
        if (Auth::check()) {
            $this->redirect('dashboard');
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = trim((string)($_POST['username'] ?? ''));
            $password = (string)($_POST['password'] ?? '');
            $res = Auth::attempt($username, $password);
            if ($res['ok']) {
                $this->flash('success', 'خوش آمدید ' . $res['user']['full_name'] . ' | ورود امن ثبت ممیزی شد.');
                $this->redirect('dashboard');
            }
            $this->flash('danger', $res['message']);
            $this->redirect('login');
        }

        $this->render('auth/login', [
            'pageTitle' => 'ورود به سامانهٔ آموزشگاه حسابداری آدان',
        ], 'public');
    }

    public function logout(): void
    {
        Auth::logout();
        header('Location: ' . App::url('login'));
        exit;
    }
}
