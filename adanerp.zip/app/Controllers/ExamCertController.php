<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Core\Jalali;

final class ExamCertController extends Controller
{
    private function canAccessExam(int $examId, int $userId): bool
    {
        if ($examId < 1 || !Database::fetchOne('SELECT id FROM exams WHERE id = ?', [$examId])) {
            return false;
        }
        $role = (string)Auth::role();
        if ($role === 'learner') {
            return Database::fetchOne(
                'SELECT ex.id
                 FROM exams ex
                 JOIN course_runs r ON r.course_id = ex.course_id
                 JOIN enrollments e ON e.run_id = r.id
                 WHERE ex.id = ? AND ex.is_active = 1 AND e.user_id = ?
                   AND e.status IN ("active", "completed")
                   AND r.status IN ("running", "completed")
                 LIMIT 1',
                [$examId, $userId]
            ) !== null;
        }
        if ($role === 'instructor') {
            return Database::fetchOne(
                'SELECT ex.id
                 FROM exams ex
                 JOIN course_runs r ON r.course_id = ex.course_id
                 WHERE ex.id = ? AND r.instructor_id = ?
                 LIMIT 1',
                [$examId, $userId]
            ) !== null;
        }
        return Auth::hasRole(['super_admin', 'training_expert']);
    }

    private function canManageExam(int $examId, int $userId): bool
    {
        return Auth::hasRole(['super_admin', 'training_expert'])
            || (Auth::role() === 'instructor' && $this->canAccessExam($examId, $userId));
    }

    private function certificateEligibility(int $userId, int $courseId): ?array
    {
        return Database::fetchOne(
            'SELECT e.id AS enrollment_id, c.duration_hours,
                    (a.auto_score + COALESCE(a.descriptive_score, 0)) * 100
                    / NULLIF((SELECT SUM(q.points) FROM exam_questions q WHERE q.exam_id = ex.id), 0) AS final_score,
                    (SELECT COUNT(*) FROM course_sessions s WHERE s.run_id = r.id) AS total_sessions,
                    (SELECT COUNT(DISTINCT sa.session_id)
                     FROM session_attendance sa
                     JOIN course_sessions s ON s.id = sa.session_id
                     WHERE s.run_id = r.id AND sa.user_id = e.user_id AND sa.status IN ("present", "late")) AS attended_sessions
             FROM enrollments e
             JOIN course_runs r ON r.id = e.run_id AND r.course_id = ?
             JOIN courses c ON c.id = r.course_id
             JOIN exams ex ON ex.course_id = c.id AND ex.is_active = 1
             JOIN exam_attempts a ON a.exam_id = ex.id AND a.user_id = e.user_id AND a.status = "finalized"
             WHERE e.user_id = ?
               AND e.status IN ("active", "completed")
               AND e.progress_pct >= 100
               AND r.status = "completed"
               AND (SELECT COUNT(*) FROM course_sessions s WHERE s.run_id = r.id) > 0
               AND (SELECT COUNT(DISTINCT sa.session_id)
                    FROM session_attendance sa
                    JOIN course_sessions s ON s.id = sa.session_id
                    WHERE s.run_id = r.id AND sa.user_id = e.user_id AND sa.status IN ("present", "late")) * 100
                   >= (SELECT COUNT(*) * 80 FROM course_sessions s WHERE s.run_id = r.id)
               AND (a.auto_score + COALESCE(a.descriptive_score, 0)) * 100
                   / NULLIF((SELECT SUM(q.points) FROM exam_questions q WHERE q.exam_id = ex.id), 0) >= ex.pass_score
             ORDER BY a.submitted_at DESC
             LIMIT 1',
            [$courseId, $userId]
        );
    }

    private function recordCourseCompletion(array $eligibility): void
    {
        $attendancePct = (int)round(
            ((int)$eligibility['attended_sessions'] / max(1, (int)$eligibility['total_sessions'])) * 100
        );
        Database::execute(
            'UPDATE enrollments
             SET status = "completed", attendance_pct = ?, final_score = ?
             WHERE id = ?',
            [$attendancePct, (float)$eligibility['final_score'], (int)$eligibility['enrollment_id']]
        );
    }

    public function index(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();
            $action = (string)($_POST['action'] ?? '');

            // ★ v26.6 — قفل سمت سرور: این اکشن‌ها اقدام مدیریتی/مدرسی‌اند و برای نقش فراگیر ۴۰۳ برمی‌گردند
            $this->denyLearnerActions($action, ['create_exam', 'update_exam', 'toggle_exam', 'add_question', 'update_question', 'delete_question', 'clone_standard_to_bank', 'grade_descriptive', 'issue_certificate', 'batch_issue_course', 'revoke_certificate'], 'exams');

            if ($action === 'create_exam' && Auth::hasRole(['super_admin', 'training_expert'])) {
                $courseId = (int)($_POST['course_id'] ?? 0);
                $title = trim((string)($_POST['title'] ?? ''));
                $durationMinutes = (int)($_POST['duration_minutes'] ?? 0);
                $maxAttempts = (int)($_POST['max_attempts'] ?? 0);
                $passScore = (float)($_POST['pass_score'] ?? 0);
                if (
                    !Database::fetchOne('SELECT id FROM courses WHERE id = ?', [$courseId])
                    || $title === '' || mb_strlen($title) > 200
                    || $durationMinutes < 1 || $durationMinutes > 600
                    || $maxAttempts < 1 || $maxAttempts > 10
                    || $passScore < 1 || $passScore > 100
                ) {
                    $this->flash('danger', 'عنوان، دوره، مدت، سقف تلاش یا حدنصاب آزمون معتبر نیست.');
                    $this->redirect('exams');
                }
                $examId = Database::insert(
                    'INSERT INTO exams (course_id, title, duration_minutes, max_attempts, pass_score, is_active)
                     VALUES (?, ?, ?, ?, ?, 0)',
                    [$courseId, $title, $durationMinutes, $maxAttempts, $passScore]
                );
                Auth::audit('EXAMS', 'EXAM_CREATED', 'exam', $examId, ['course_id' => $courseId]);
                $this->flash('success', 'آزمون به‌صورت پیش‌نویس ساخته شد؛ پس از افزودن سؤال، آن را منتشر کنید.');
                $this->redirect('exams', ['exam_id' => $examId]);
            }

            if ($action === 'update_exam' && Auth::hasRole(['super_admin', 'training_expert'])) {
                $examId = (int)($_POST['exam_id'] ?? 0);
                $courseId = (int)($_POST['course_id'] ?? 0);
                $title = trim((string)($_POST['title'] ?? ''));
                $durationMinutes = (int)($_POST['duration_minutes'] ?? 0);
                $maxAttempts = (int)($_POST['max_attempts'] ?? 0);
                $passScore = (float)($_POST['pass_score'] ?? 0);
                $examState = Database::fetchOne('SELECT is_active FROM exams WHERE id = ?', [$examId]);
                $hasAttempts = $examId > 0
                    && (int)Database::scalar('SELECT COUNT(*) FROM exam_attempts WHERE exam_id = ?', [$examId]) > 0;
                if (
                    !$examState || (int)$examState['is_active'] === 1 || $hasAttempts
                    || !Database::fetchOne('SELECT id FROM courses WHERE id = ?', [$courseId])
                    || $title === '' || mb_strlen($title) > 200
                    || $durationMinutes < 1 || $durationMinutes > 600
                    || $maxAttempts < 1 || $maxAttempts > 10
                    || $passScore < 1 || $passScore > 100
                ) {
                    $this->flash('danger', 'ویرایش مشخصات فقط برای آزمون پیش‌نویسِ بدون پاسخ‌نامه و با مقادیر معتبر مجاز است.');
                    $this->redirect('exams', ['exam_id' => $examId]);
                }
                Database::execute(
                    'UPDATE exams SET course_id = ?, title = ?, duration_minutes = ?, max_attempts = ?, pass_score = ? WHERE id = ?',
                    [$courseId, $title, $durationMinutes, $maxAttempts, $passScore, $examId]
                );
                Auth::audit('EXAMS', 'EXAM_UPDATED', 'exam', $examId, ['course_id' => $courseId]);
                $this->flash('success', 'مشخصات آزمون پیش‌نویس ویرایش شد.');
                $this->redirect('exams', ['exam_id' => $examId]);
            }

            if ($action === 'toggle_exam' && Auth::hasRole(['super_admin', 'training_expert'])) {
                $examId = (int)($_POST['exam_id'] ?? 0);
                $examToToggle = Database::fetchOne('SELECT id, is_active FROM exams WHERE id = ?', [$examId]);
                if (!$examToToggle) {
                    $this->flash('danger', 'آزمون انتخاب‌شده یافت نشد.');
                    $this->redirect('exams');
                }
                $nextActive = (int)$examToToggle['is_active'] === 1 ? 0 : 1;
                if ($nextActive === 1) {
                    $questionCount = (int)Database::scalar('SELECT COUNT(*) FROM exam_questions WHERE exam_id = ?', [$examId]);
                    $questionPoints = (float)Database::scalar('SELECT COALESCE(SUM(points), 0) FROM exam_questions WHERE exam_id = ?', [$examId]);
                    if ($questionCount === 0 || $questionPoints <= 0) {
                        $this->flash('danger', 'برای انتشار آزمون، ابتدا دست‌کم یک سؤال دارای بارم ثبت کنید.');
                        $this->redirect('exams', ['exam_id' => $examId]);
                    }
                }
                Database::execute('UPDATE exams SET is_active = ? WHERE id = ?', [$nextActive, $examId]);
                Auth::audit('EXAMS', $nextActive ? 'EXAM_PUBLISHED' : 'EXAM_UNPUBLISHED', 'exam', $examId, []);
                $this->flash('success', $nextActive ? 'آزمون منتشر شد و برای ثبت‌نام‌شدگان دوره قابل‌دسترسی است.' : 'آزمون از دسترس خارج شد.');
                $this->redirect('exams', ['exam_id' => $examId]);
            }

            if ($action === 'run_standard_test') {
                $tCode = trim((string)($_POST['test_code'] ?? 'MBTI'));
                $catalog = \App\Services\StandardizedAssessmentService::getFullCatalog();
                $test = $catalog[$tCode] ?? null;
                $answersComplete = $test !== null;
                if ($test) {
                    foreach ($test['questions'] as $idx => $_question) {
                        $answer = strtoupper(trim((string)($_POST['sq_' . $idx] ?? '')));
                        if (!in_array($answer, ['A', 'B', 'C', 'D'], true)) {
                            $answersComplete = false;
                            break;
                        }
                    }
                }
                if (!$answersComplete) {
                    $this->flash('danger', 'آزمون انتخاب‌شده معتبر نیست یا پاسخ همه سؤال‌ها را ثبت نکرده‌اید.');
                    $this->redirect('exams');
                }
                $res = \App\Services\StandardizedAssessmentService::evaluateAndSave((int)Auth::id(), $tCode, $_POST);
                $this->flash(
                    'success',
                    'کارنامه رسمی آزمون استاندارد «' . $res['title'] . '» با کد «' . $res['report_code']
                    . '» صادر و ثبت شد — نتیجه نهایی: ' . $res['badge'] . ' | دوره پیشنهادی: ' . $res['recommended_course']
                );
                $this->redirect('exams');
            }

            if ($action === 'clone_standard_to_bank' && Auth::hasRole(['super_admin', 'training_expert', 'instructor'])) {
                $tCode = trim((string)($_POST['test_code'] ?? 'MBTI'));
                $examId = (int)($_POST['exam_id'] ?? 0);
                if (!$this->canManageExam($examId, (int)Auth::id())) {
                    $this->flash('danger', 'به بانک سؤال این آزمون دسترسی ندارید.');
                    $this->redirect('exams');
                }
                $examState = Database::fetchOne('SELECT is_active FROM exams WHERE id = ?', [$examId]);
                if (!$examState || (int)$examState['is_active'] === 1
                    || (int)Database::scalar('SELECT COUNT(*) FROM exam_attempts WHERE exam_id = ?', [$examId]) > 0) {
                    $this->flash('danger', 'فقط آزمون پیش‌نویسِ بدون پاسخ‌نامه را می‌توان تغییر داد.');
                    $this->redirect('exams', ['exam_id' => $examId]);
                }
                $added = \App\Services\StandardizedAssessmentService::cloneQuestionsToOfficialExam($tCode, $examId);
                $this->flash(
                    'success',
                    Jalali::digits($added) . ' سؤال استاندارد از آزمون «' . $tCode . '» با یک کلیک به بانک سؤالات آزمون رسمی دوره اضافه شد.'
                );
                $this->redirect('exams', ['exam_id' => $examId]);
            }

            if ($action === 'add_question' && Auth::hasRole(['super_admin', 'training_expert', 'instructor'])) {
                $examId = (int)($_POST['exam_id'] ?? 0);
                $questionType = (string)($_POST['question_type'] ?? '');
                $questionText = trim((string)($_POST['question_text'] ?? ''));
                $points = (float)($_POST['points'] ?? 0);
                $correctOption = strtoupper(trim((string)($_POST['correct_option'] ?? '')));
                $options = [
                    'A' => trim((string)($_POST['opt_a'] ?? '')),
                    'B' => trim((string)($_POST['opt_b'] ?? '')),
                    'C' => trim((string)($_POST['opt_c'] ?? '')),
                    'D' => trim((string)($_POST['opt_d'] ?? '')),
                ];
                $hasAttempts = (int)Database::scalar('SELECT COUNT(*) FROM exam_attempts WHERE exam_id = ?', [$examId]) > 0;
                $examState = Database::fetchOne('SELECT is_active FROM exams WHERE id = ?', [$examId]);
                if (
                    !$this->canManageExam($examId, (int)Auth::id()) || $hasAttempts
                    || !$examState || (int)$examState['is_active'] === 1
                    || !in_array($questionType, ['mcq', 'descriptive'], true)
                    || $questionText === '' || mb_strlen($questionText) > 4000 || $points <= 0 || $points > 100
                    || array_filter($options, static fn(string $option): bool => mb_strlen($option) > 255) !== []
                    || ($questionType === 'mcq' && (
                        !in_array($correctOption, ['A', 'B', 'C', 'D'], true)
                        || in_array('', $options, true)
                    ))
                ) {
                    $this->flash('danger', 'سؤال یا بارم نامعتبر است، یا آزمون قبلاً پاسخ‌نامه دارد و بانک آن قفل شده است.');
                    $this->redirect('exams', ['exam_id' => $examId]);
                }
                Database::insert(
                    'INSERT INTO exam_questions (exam_id, question_type, question_text, option_a, option_b, option_c, option_d, correct_option, points)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
                    [
                        $examId,
                        $questionType,
                        $questionText,
                        $options['A'],
                        $options['B'],
                        $options['C'],
                        $options['D'],
                        $questionType === 'mcq' ? $correctOption : null,
                        $points,
                    ]
                );
                $this->flash('success', 'سؤال جدید با موفقیت به بانک سؤالات آزمون استاندارد افزوده شد.');
                $this->redirect('exams', ['exam_id' => $examId]);
            }

            if ($action === 'update_question' && Auth::hasRole(['super_admin', 'training_expert', 'instructor'])) {
                $examId = (int)($_POST['exam_id'] ?? 0);
                $questionId = (int)($_POST['question_id'] ?? 0);
                $questionType = (string)($_POST['question_type'] ?? '');
                $questionText = trim((string)($_POST['question_text'] ?? ''));
                $options = [
                    'A' => trim((string)($_POST['opt_a'] ?? '')),
                    'B' => trim((string)($_POST['opt_b'] ?? '')),
                    'C' => trim((string)($_POST['opt_c'] ?? '')),
                    'D' => trim((string)($_POST['opt_d'] ?? '')),
                ];
                $points = (float)($_POST['points'] ?? 0);
                $correctOption = strtoupper(trim((string)($_POST['correct_option'] ?? '')));
                $examState = Database::fetchOne('SELECT is_active FROM exams WHERE id = ?', [$examId]);
                $questionExists = Database::fetchOne(
                    'SELECT id FROM exam_questions WHERE id = ? AND exam_id = ?',
                    [$questionId, $examId]
                );
                $hasAttempts = $examId > 0
                    && (int)Database::scalar('SELECT COUNT(*) FROM exam_attempts WHERE exam_id = ?', [$examId]) > 0;
                if (
                    !$this->canManageExam($examId, (int)Auth::id()) || !$questionExists || $hasAttempts
                    || !$examState || (int)$examState['is_active'] === 1
                    || !in_array($questionType, ['mcq', 'descriptive'], true)
                    || $questionText === '' || mb_strlen($questionText) > 4000
                    || $points <= 0 || $points > 100
                    || array_filter($options, static fn(string $option): bool => mb_strlen($option) > 255) !== []
                    || ($questionType === 'mcq' && (
                        !in_array($correctOption, ['A', 'B', 'C', 'D'], true)
                        || in_array('', $options, true)
                    ))
                ) {
                    $this->flash('danger', 'ویرایش سؤال معتبر نیست، یا آزمون منتشرشده/دارای پاسخ‌نامه است.');
                    $this->redirect('exams', ['exam_id' => $examId]);
                }
                Database::execute(
                    'UPDATE exam_questions
                     SET question_type = ?, question_text = ?, option_a = ?, option_b = ?, option_c = ?, option_d = ?, correct_option = ?, points = ?
                     WHERE id = ? AND exam_id = ?',
                    [
                        $questionType,
                        $questionText,
                        $options['A'],
                        $options['B'],
                        $options['C'],
                        $options['D'],
                        $questionType === 'mcq' ? $correctOption : null,
                        $points,
                        $questionId,
                        $examId,
                    ]
                );
                Auth::audit('EXAMS', 'EXAM_QUESTION_UPDATED', 'exam_question', $questionId, ['exam_id' => $examId]);
                $this->flash('success', 'سؤال آزمون با موفقیت ویرایش شد.');
                $this->redirect('exams', ['exam_id' => $examId]);
            }

            if ($action === 'delete_question' && Auth::hasRole(['super_admin', 'training_expert', 'instructor'])) {
                $examId = (int)($_POST['exam_id'] ?? 0);
                $questionId = (int)($_POST['question_id'] ?? 0);
                $examState = Database::fetchOne('SELECT is_active FROM exams WHERE id = ?', [$examId]);
                $questionExists = Database::fetchOne(
                    'SELECT id FROM exam_questions WHERE id = ? AND exam_id = ?',
                    [$questionId, $examId]
                );
                $hasAttempts = $examId > 0
                    && (int)Database::scalar('SELECT COUNT(*) FROM exam_attempts WHERE exam_id = ?', [$examId]) > 0;
                if (
                    !$this->canManageExam($examId, (int)Auth::id()) || !$questionExists || $hasAttempts
                    || !$examState || (int)$examState['is_active'] === 1
                ) {
                    $this->flash('danger', 'حذف سؤال فقط برای آزمون پیش‌نویسِ بدون پاسخ‌نامه مجاز است.');
                    $this->redirect('exams', ['exam_id' => $examId]);
                }
                Database::execute('DELETE FROM exam_questions WHERE id = ? AND exam_id = ?', [$questionId, $examId]);
                Auth::audit('EXAMS', 'EXAM_QUESTION_DELETED', 'exam_question', $questionId, ['exam_id' => $examId]);
                $this->flash('success', 'سؤال از بانک آزمون حذف شد.');
                $this->redirect('exams', ['exam_id' => $examId]);
            }

            if ($action === 'submit_exam') {
                $uid = (int)Auth::id();
                $examId = (int)($_POST['exam_id'] ?? 0);
                $exam = Database::fetchOne('SELECT * FROM exams WHERE id = ? AND is_active = 1', [$examId]);
                if (!$exam || !$this->canAccessExam($examId, $uid)) {
                    $this->flash('danger', 'این آزمون فعال نیست یا برای ثبت‌نام دورهٔ شما تخصیص نیافته است.');
                    $this->redirect('exams');
                }
                $questions = Database::fetchAll(
                    'SELECT id, question_type, correct_option, points FROM exam_questions WHERE exam_id = ? ORDER BY id ASC',
                    [$examId]
                );
                if ($questions === [] || array_sum(array_map(static fn(array $q): float => (float)$q['points'], $questions)) <= 0) {
                    $this->flash('danger', 'این آزمون هنوز بانک سؤال معتبر ندارد.');
                    $this->redirect('exams', ['exam_id' => $examId]);
                }
                $autoScore = 0.0;
                $descAnswers = [];
                $hasDescriptiveQuestion = false;
                foreach ($questions as $q) {
                    $qid = (int)$q['id'];
                    if ($q['question_type'] === 'mcq') {
                        $ans = strtoupper((string)($_POST['q_' . $qid] ?? ''));
                        if ($ans !== '' && $ans === strtoupper((string)$q['correct_option'])) {
                            $autoScore += (float)$q['points'];
                        }
                    } else {
                        $hasDescriptiveQuestion = true;
                        $answer = trim((string)($_POST['q_' . $qid] ?? ''));
                        $descAnswers[] = 'سؤال ' . $qid . ': ' . $answer;
                    }
                }

                $pdo = Database::connection();
                $pdo->beginTransaction();
                try {
                    $lockExam = $pdo->prepare('SELECT max_attempts FROM exams WHERE id = ? AND is_active = 1 FOR UPDATE');
                    $lockExam->execute([$examId]);
                    $lockedExam = $lockExam->fetch(\PDO::FETCH_ASSOC);
                    $attemptCount = $pdo->prepare('SELECT COUNT(*) FROM exam_attempts WHERE exam_id = ? AND user_id = ?');
                    $attemptCount->execute([$examId, $uid]);
                    $usedAttempts = (int)$attemptCount->fetchColumn();
                    if (!$lockedExam || $usedAttempts >= (int)$lockedExam['max_attempts']) {
                        $pdo->rollBack();
                        $this->flash('danger', 'سقف مجاز دفعات شرکت در این آزمون تکمیل شده است.');
                        $this->redirect('exams', ['exam_id' => $examId]);
                    }
                    $saveAttempt = $pdo->prepare(
                        'INSERT INTO exam_attempts (exam_id, user_id, attempt_no, auto_score, descriptive_answer, status)
                         VALUES (?, ?, ?, ?, ?, ?)'
                    );
                    $saveAttempt->execute([
                        $examId,
                        $uid,
                        $usedAttempts + 1,
                        $autoScore,
                        implode("\n", $descAnswers),
                        $hasDescriptiveQuestion ? 'pending_descriptive_review' : 'finalized',
                    ]);
                    $pdo->commit();
                } catch (\Throwable $e) {
                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                    }
                    throw $e;
                }
                Auth::audit('EXAMS', 'EXAM_SUBMITTED', 'exam', $examId, ['auto_score' => $autoScore]);
                $this->flash('success', 'پاسخ‌نامه ثبت شد! نمره خودکار بخش تستی: ' . Jalali::digits($autoScore) . ' | بخش تشریحی در کارتابل استاد قرار گرفت.');
                $this->redirect('exams', ['exam_id' => $examId]);
            }

            if ($action === 'grade_descriptive' && Auth::hasRole(['super_admin', 'training_expert', 'instructor'])) {
                $attId = (int)$_POST['attempt_id'];
                $descScore = (float)$_POST['descriptive_score'];
                $attempt = Database::fetchOne(
                    'SELECT a.id, a.status, e.id AS exam_id
                     FROM exam_attempts a
                     JOIN exams e ON e.id = a.exam_id
                     WHERE a.id = ?',
                    [$attId]
                );
                $maxScore = $attempt
                    ? (float)Database::scalar(
                        'SELECT COALESCE(SUM(points), 0) FROM exam_questions WHERE exam_id = ? AND question_type = "descriptive"',
                        [(int)$attempt['exam_id']]
                    )
                    : 0.0;
                if (
                    !$attempt || !$this->canManageExam((int)$attempt['exam_id'], (int)Auth::id())
                    || $attempt['status'] !== 'pending_descriptive_review'
                    || $descScore < 0 || $descScore > $maxScore
                ) {
                    $this->flash('danger', 'نمره تشریحی نامعتبر است یا این پاسخ‌نامه قبلاً نهایی شده است.');
                    $this->redirect('exams');
                }
                Database::execute(
                    'UPDATE exam_attempts SET descriptive_score = ?, status = "finalized" WHERE id = ?',
                    [$descScore, $attId]
                );
                $this->flash('success', 'نمره سؤال تشریحی ثبت و کارنامه نهایی شد.');
                $this->redirect('exams', ['exam_id' => (int)$attempt['exam_id']]);
            }

            if ($action === 'batch_issue_course' && Auth::hasRole(['super_admin', 'training_expert'])) {
                $cid = (int)$_POST['course_id'];
                $enrollees = Database::fetchAll(
                    'SELECT DISTINCT e.user_id FROM enrollments e JOIN course_runs r ON r.id = e.run_id
                     WHERE r.course_id = ? AND e.status IN ("active", "completed")',
                    [$cid]
                );
                $issuedCount = 0;
                foreach ($enrollees as $enr) {
                    $uid = (int)$enr['user_id'];
                    $eligibility = $this->certificateEligibility($uid, $cid);
                    if ($eligibility && !Database::fetchOne('SELECT id FROM certificates WHERE user_id = ? AND course_id = ? AND status = "valid"', [$uid, $cid])) {
                        $this->recordCourseCompletion($eligibility);
                        $serial = 'CERT-ADN-' . date('Y') . '-' . strtoupper(bin2hex(random_bytes(6)));
                        Database::insert(
                            'INSERT INTO certificates (serial_code, user_id, course_id, issue_shamsi, grade_label, hours_completed, status)
                             VALUES (?, ?, ?, ?, ?, ?, "valid")',
                            [
                                $serial,
                                $uid,
                                $cid,
                                Jalali::today(),
                                'قبول نهایی (' . number_format((float)$eligibility['final_score'], 2) . ' از ۱۰۰)',
                                (int)$eligibility['duration_hours'],
                            ]
                        );
                        $issuedCount++;
                    }
                }
                Auth::audit('CERTIFICATES', 'BATCH_CERTIFICATES_ISSUED', 'course', $cid, ['count' => $issuedCount]);
                $this->flash('success', Jalali::digits($issuedCount) . ' گواهی‌نامه رسمی QR جدید به‌صورت دسته‌ای برای قبول‌شدگان دوره صادر شد.');
                $this->redirect('exams');
            }

            if ($action === 'issue_certificate' && Auth::hasRole(['super_admin', 'training_expert'])) {
                $userId = (int)($_POST['user_id'] ?? 0);
                $courseId = (int)($_POST['course_id'] ?? 0);
                $eligibility = $this->certificateEligibility($userId, $courseId);
                if (!$eligibility) {
                    $this->flash('danger', 'صدور گواهی ممکن نیست: تکمیل دوره، حداقل ۸۰٪ حضور ثبت‌شده، پیشرفت کامل و قبولی آزمون نهایی باید احراز شود.');
                    $this->redirect('exams');
                }
                if (Database::fetchOne('SELECT id FROM certificates WHERE user_id = ? AND course_id = ? AND status = "valid"', [$userId, $courseId])) {
                    $this->flash('warning', 'برای این دانشجو و دوره، گواهی معتبر از قبل وجود دارد.');
                    $this->redirect('exams');
                }

                $this->recordCourseCompletion($eligibility);
                $serial = 'CERT-ADN-' . date('Y') . '-' . strtoupper(bin2hex(random_bytes(6)));
                Database::insert(
                    'INSERT INTO certificates (serial_code, user_id, course_id, issue_shamsi, grade_label, hours_completed, status)
                     VALUES (?, ?, ?, ?, ?, ?, "valid")',
                    [
                        $serial,
                        $userId,
                        $courseId,
                        Jalali::today(),
                        'قبول نهایی (' . number_format((float)$eligibility['final_score'], 2) . ' از ۱۰۰)',
                        (int)$eligibility['duration_hours'],
                    ]
                );
                Auth::audit('CERTIFICATES', 'CERTIFICATE_ISSUED', 'certificate', null, ['serial' => $serial]);
                $this->flash('success', "گواهی‌نامه رسمی دارای کد QR با سریال «{$serial}» صادر شد.");
                $this->redirect('exams');
            }

            if ($action === 'revoke_certificate' && Auth::hasRole(['super_admin', 'training_expert'])) {
                $cid = (int)$_POST['cert_id'];
                Database::execute(
                    'UPDATE certificates SET status = "revoked", revoked_reason = ? WHERE id = ?',
                    [trim((string)$_POST['revoked_reason']), $cid]
                );
                Auth::audit('CERTIFICATES', 'CERTIFICATE_REVOKED', 'certificate', $cid, []);
                $this->flash('warning', 'گواهی‌نامه ابطال شد و وضعیت جدید آن بلافاصله در سامانه استعلام عمومی QR اعمال گردید.');
                $this->redirect('exams');
            }
        }

        // آزمون رسمی فقط برای ثبت‌نام‌شدگان اجرای متناظر نمایش داده می‌شود.
        $isLearnerView = Auth::role() === 'learner';
        $meId = (int)Auth::id();
        $rowScope = $isLearnerView ? [$meId] : [];
        $certWhere = $isLearnerView ? ' WHERE cert.user_id = ?' : '';
        $stdWhere = $isLearnerView ? ' WHERE sr.user_id = ?' : '';

        if ($isLearnerView) {
            $availableExams = Database::fetchAll(
                'SELECT DISTINCT ex.id, ex.course_id, ex.title, ex.duration_minutes, ex.max_attempts,
                        ex.pass_score, ex.is_active, c.title AS course_title
                 FROM exams ex
                 JOIN courses c ON c.id = ex.course_id
                 JOIN course_runs r ON r.course_id = ex.course_id
                 JOIN enrollments e ON e.run_id = r.id
                 WHERE ex.is_active = 1 AND e.user_id = ?
                   AND e.status IN ("active", "completed")
                   AND r.status IN ("running", "completed")
                 ORDER BY ex.id DESC',
                [$meId]
            );
        } elseif (Auth::role() === 'instructor') {
            $availableExams = Database::fetchAll(
                'SELECT DISTINCT ex.id, ex.course_id, ex.title, ex.duration_minutes, ex.max_attempts,
                        ex.pass_score, ex.is_active, c.title AS course_title
                 FROM exams ex
                 JOIN courses c ON c.id = ex.course_id
                 JOIN course_runs r ON r.course_id = ex.course_id
                 WHERE r.instructor_id = ?
                 ORDER BY ex.id DESC',
                [$meId]
            );
        } else {
            $availableExams = Database::fetchAll(
                'SELECT ex.id, ex.course_id, ex.title, ex.duration_minutes, ex.max_attempts,
                        ex.pass_score, ex.is_active, c.title AS course_title
                 FROM exams ex JOIN courses c ON c.id = ex.course_id
                 ORDER BY ex.id DESC'
            );
        }
        $requestedExamId = (int)($_GET['exam_id'] ?? ($availableExams[0]['id'] ?? 0));
        $exam = null;
        foreach ($availableExams as $availableExam) {
            if ((int)$availableExam['id'] === $requestedExamId) {
                $exam = $availableExam;
                break;
            }
        }
        $questions = $exam
            ? Database::fetchAll(
                'SELECT id, exam_id, question_type, question_text, option_a, option_b, option_c, option_d, points
                 FROM exam_questions WHERE exam_id = ? ORDER BY id ASC',
                [(int)$exam['id']]
            )
            : [];
        $canEditBank = $exam
            && (int)$exam['is_active'] === 0
            && Auth::hasRole(['super_admin', 'training_expert', 'instructor'])
            && $this->canManageExam((int)$exam['id'], $meId)
            && (int)Database::scalar('SELECT COUNT(*) FROM exam_attempts WHERE exam_id = ?', [(int)$exam['id']]) === 0;
        $canEditExamSettings = $canEditBank && Auth::hasRole(['super_admin', 'training_expert']);
        $editableQuestions = $canEditBank
            ? Database::fetchAll(
                'SELECT id, question_type, question_text, option_a, option_b, option_c, option_d, correct_option, points
                 FROM exam_questions WHERE exam_id = ? ORDER BY id ASC',
                [(int)$exam['id']]
            )
            : [];
        $descriptiveMax = $exam
            ? (float)Database::scalar(
                'SELECT COALESCE(SUM(points), 0) FROM exam_questions WHERE exam_id = ? AND question_type = "descriptive"',
                [(int)$exam['id']]
            )
            : 0.0;
        if (isset($_GET['shuffle']) && $_GET['shuffle'] === '1') {
            shuffle($questions);
        }

        $attemptParams = $exam ? [(int)$exam['id']] : [-1];
        $attemptWhere = $isLearnerView ? ' AND a.user_id = ?' : '';
        if ($isLearnerView) {
            $attemptParams[] = $meId;
        }
        $attempts = Database::fetchAllSafe(
            'SELECT a.*, u.full_name,
                    (a.auto_score + COALESCE(a.descriptive_score, 0)) * 100
                    / NULLIF((SELECT SUM(q.points) FROM exam_questions q WHERE q.exam_id = a.exam_id), 0) AS score_pct
             FROM exam_attempts a JOIN users u ON u.id = a.user_id
             WHERE a.exam_id = ?' . $attemptWhere . ' ORDER BY a.id DESC',
            $attemptParams
        );
        $certs = Database::fetchAllSafe(
            'SELECT cert.*, u.full_name, c.title AS course_title
             FROM certificates cert
             JOIN users u ON u.id = cert.user_id
             JOIN courses c ON c.id = cert.course_id'
            . $certWhere . '
             ORDER BY cert.id DESC',
            $rowScope
        );
        // فهرست کاربران تنها برای کارتابل‌های مدیریتی/صدور گواهی لازم است
        $users = $isLearnerView ? [] : Database::fetchAll('SELECT id, full_name FROM users ORDER BY id ASC');
        $courses = Database::fetchAll('SELECT id, title FROM courses ORDER BY id ASC');
        $stdCatalog = \App\Services\StandardizedAssessmentService::getFullCatalog();
        $stdResults = Database::fetchAllSafe(
            'SELECT sr.*, u.full_name
             FROM standard_test_results sr
             LEFT JOIN users u ON u.id = sr.user_id'
            . $stdWhere . '
             ORDER BY sr.id DESC',
            $rowScope
        );

        $this->render('exams/index', [
            'pageTitle' => 'مرکز آزمون‌های استاندارد و پیش‌ساخته، بانک سؤال و گواهی‌نامه QR',
            'exam' => $exam,
            'availableExams' => $availableExams,
            'questions' => $questions,
            'editableQuestions' => $editableQuestions,
            'canEditBank' => $canEditBank,
            'canEditExamSettings' => $canEditExamSettings,
            'descriptiveMax' => $descriptiveMax,
            'attempts' => $attempts,
            'certs' => $certs,
            'users' => $users,
            'courses' => $courses,
            'stdCatalog' => $stdCatalog,
            'stdResults' => $stdResults,
            'isLearnerView' => $isLearnerView,
        ]);
    }
}
