<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Services\ContextualHelpEncyclopediaService;

final class HelpEncyclopediaController extends Controller
{
    public function index(): void
    {
        $u = Auth::user();
        $uname = (string)($u['full_name'] ?? 'کاربر مؤسسه آموزشی آدان');
        $activeTab = trim((string)($_GET['tab'] ?? 'catalog'));
        $searchQ = trim((string)($_GET['q'] ?? ''));

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $action = (string)($_POST['action'] ?? '');

            // ★ v26.6 — قفل سمت سرور: این اکشن‌ها اقدام مدیریتی/مدرسی‌اند و برای نقش فراگیر ۴۰۳ برمی‌گردند
            $this->denyLearnerActions($action, ['save_page_sop'], 'help-center');

            if ($action === 'save_page_sop') {
                $res = ContextualHelpEncyclopediaService::saveCustomPageHelpNote(
                    (string)($_POST['route_key'] ?? 'dashboard'),
                    (string)($_POST['local_sop_title'] ?? ''),
                    (string)($_POST['local_sop_body'] ?? ''),
                    (string)($_POST['contact_extension'] ?? 'داخلی ۲۱۰'),
                    $uname
                );
                $this->redirect(
                    'help-center?tab=admin_notes',
                    'یادداشت راهنمای بومی برای مسیر «/' . $res['route_key'] . '» ذخیره شد و هم‌اکنون در پنجره F1 همان صفحه نمایش داده می‌شود.'
                );
            }

            if ($action === 'rate_page_help') {
                $targetRoute = trim((string)($_POST['target_route'] ?? 'dashboard'));
                ContextualHelpEncyclopediaService::recordHelpFeedback(
                    $targetRoute,
                    $uname,
                    !empty($_POST['helpful']),
                    (string)($_POST['suggestion_note'] ?? '')
                );
                $this->redirect($targetRoute, 'سپاسگزاریم! بازخورد شما برای راهنمای اختصاصی این صفحه در مرکز مستندات ثبت شد.');
            }
        }

        $allGuides = ContextualHelpEncyclopediaService::getAllUniquePageGuides();
        if ($searchQ !== '') {
            $allGuides = array_filter($allGuides, static function (array $item, string $rk) use ($searchQ): bool {
                $hay = mb_strtolower($rk . ' ' . $item['title'] . ' ' . $item['category'] . ' ' . $item['mission'] . ' ' . implode(' ', $item['steps']) . ' ' . $item['tables'] . ' ' . $item['golden_tip']);
                return str_contains($hay, mb_strtolower($searchQ));
            }, ARRAY_FILTER_USE_BOTH);
        }

        $this->render('growth/help_center', [
            'pageTitle'    => 'دانشنامه و مرکز راهنمای جامع کل سیستم + فهرست راهنمای یکتای ۷۷ صفحه',
            'activeTab'    => $activeTab,
            'searchQ'      => $searchQ,
            'allGuides'    => $allGuides,
            'totalGuides'  => count(ContextualHelpEncyclopediaService::getAllUniquePageGuides()),
            'playbooks'    => ContextualHelpEncyclopediaService::getRolePlaybooks(),
            'customNotes'  => Database::fetchAll('SELECT * FROM erp_help_custom_notes ORDER BY id DESC'),
            'feedbackLogs' => Database::fetchAll('SELECT * FROM erp_help_feedback_logs ORDER BY id DESC LIMIT 12'),
        ]);
    }

    public function manualPrint(): void
    {
        $this->render('growth/help_manual_print', [
            'pageTitle' => 'کتابچه رسمی راهنمای جامع بهره‌برداری، نقش‌ها و استقرار کل سامانه ERP مؤسسه آموزشی آدان',
            'allGuides' => ContextualHelpEncyclopediaService::getAllUniquePageGuides(),
            'playbooks' => ContextualHelpEncyclopediaService::getRolePlaybooks(),
        ], 'public');
    }
}
