<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Services\AvalAiService;

final class AcademyController extends Controller
{
    public function leadership(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'run_warroom') {
            $res = \App\Services\DeepModuleSuiteService::runExecutiveWarRoomSimulation(
                Auth::user()['full_name'] ?? 'مدیرعامل شرکت عضو',
                (string)($_POST['shock_scenario'] ?? 'شوک ارزی و تعرفه کربن مرزی اروپا'),
                (string)($_POST['chosen_strategy'] ?? 'تنوع‌بخشی صادرات به اوراسیا + قرارداد سلف ارزی')
            );
            $this->redirect('leadership', 'شبیه‌سازی اتاق جنگ بحران هیئت‌مدیره اجرا شد (امتیاز تاب‌آوری: ' . $res['resilience_score'] . ' از ۱۰۰ — کد: ' . $res['sim_code'] . ').');
        }

        $programs = Database::fetchAll('SELECT * FROM leadership_programs ORDER BY id ASC');
        $warSims = Database::fetchAll('SELECT * FROM executive_warroom_simulations ORDER BY id DESC LIMIT 8');
        $this->render('academy/leadership', [
            'pageTitle' => 'مدرسه حکمرانی اقتصادی، اتاق جنگ بحران مدیران عامل و تصمیم‌گیری وزن‌دار',
            'programs' => $programs,
            'warSims' => $warSims,
        ]);
    }

    public function consulting(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $action = (string)($_POST['action'] ?? '');

            if ($action === 'book_session') {
                Database::insert(
                    'INSERT INTO consulting_sessions (consultant_id, client_user_id, topic, slot_label, status, agenda)
                     VALUES (5, ?, ?, ?, "requested", ?)',
                    [
                        Auth::id(),
                        trim((string)$_POST['topic']),
                        (string)$_POST['slot_label'],
                        trim((string)$_POST['agenda']),
                    ]
                );
                $this->flash('success', 'درخواست رزرو جلسه مشاوره تخصصی ثبت گردید.');
                $this->redirect('consulting');
            }

            if ($action === 'save_consultant_notes' && Auth::hasRole(['super_admin', 'instructor', 'training_expert'])) {
                Database::execute(
                    'UPDATE consulting_sessions SET confidential_note = ?, action_items = ?, status = "completed" WHERE id = ?',
                    [
                        trim((string)$_POST['confidential_note']),
                        trim((string)$_POST['action_items']),
                        (int)$_POST['session_id'],
                    ]
                );
                Auth::audit('CONSULTING', 'CONFIDENTIAL_NOTE_SAVED', 'consulting_session', (int)$_POST['session_id'], []);
                $this->flash('success', 'یادداشت محرمانه مشاور و تکالیف پیگیری ذخیره شد.');
                $this->redirect('consulting');
            }
        }

        $canSeeConfidential = Auth::hasRole(['super_admin', 'instructor']);
        $sessions = Database::fetchAll(
            'SELECT cs.*, c.full_name AS consultant_name, cl.full_name AS client_name
             FROM consulting_sessions cs
             JOIN users c ON c.id = cs.consultant_id
             JOIN users cl ON cl.id = cs.client_user_id
             ORDER BY cs.id DESC'
        );

        $this->render('academy/consulting', [
            'pageTitle' => 'کلینیک مشاوره تخصصی و منتورینگ مؤسسه آموزشی آدان',
            'sessions' => $sessions,
            'canSeeConfidential' => $canSeeConfidential,
        ]);
    }
}
