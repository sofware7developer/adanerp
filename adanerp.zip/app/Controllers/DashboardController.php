<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\App;
use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;

final class DashboardController extends Controller
{
    public function index(): void
    {
        $user = Auth::user();
        $userId = (int)Auth::id();
        $orgId = (int)($user['org_id'] ?? 0);
        $role = Auth::role() ?: 'learner';

        $isManagerRole = in_array($role, ['super_admin', 'training_expert', 'finance_manager', 'crm_manager'], true);

        $pageTitleMap = [
            'super_admin'     => 'پیشخوان مدیریت مؤسسه آدان',
            'training_expert' => 'پیشخوان مدیریت آموزشگاه',
            'finance_manager' => 'پیشخوان امور مالی و شهریه',
            'crm_manager'     => 'پیشخوان پذیرش و ارتباط با دانشجویان',
            'instructor'      => 'پیشخوان تدریس و کلاس‌های حسابداری',
            'org_rep'         => 'پیشخوان آموزش و ثبت‌نام',
            'learner'         => 'پیشخوان دانشجو',
        ];

        $kpis = [
            'courses_total'     => (int)Database::scalar('SELECT COUNT(*) FROM courses'),
            'active_runs'       => (int)Database::scalar("SELECT COUNT(*) FROM course_runs WHERE status IN ('registration','running')"),
            'learners_total'    => (int)Database::scalar("SELECT COUNT(*) FROM users WHERE role = 'learner'"),
            'instructors_total' => (int)Database::scalar("SELECT COUNT(*) FROM users WHERE role = 'instructor'"),
            'orgs_total'        => (int)Database::scalar('SELECT COUNT(*) FROM organizations'),
            'revenue_rial'      => $role === 'super_admin' || $role === 'finance_manager'
                ? (int)Database::scalar("SELECT COALESCE(SUM(credit_rial), 0) FROM ledger_entries WHERE entry_type = 'revenue'")
                : 0,
            'valid_certs'       => (int)Database::scalar("SELECT COUNT(*) FROM certificates WHERE status = 'valid'"),
            'ai_drafts_pending' => (int)Database::scalar("SELECT COUNT(*) FROM ai_contents WHERE review_status IN ('ai_draft','in_review')"),
            'bpms_open'         => (int)Database::scalar("SELECT COUNT(*) FROM bpms_workflows WHERE status = 'running'"),
        ];

        $recentRuns = Database::fetchAll(
            'SELECT r.*, c.title AS course_title, c.code AS course_code, u.full_name AS instructor_name
             FROM course_runs r
             JOIN courses c ON c.id = r.course_id
             LEFT JOIN users u ON u.id = r.instructor_id
             ORDER BY r.id ASC LIMIT 5'
        );

        $openWorkflows = $isManagerRole
            ? Database::fetchAll("SELECT * FROM bpms_workflows WHERE status = 'running' ORDER BY id DESC LIMIT 4")
            : [];

        $recentLogs = $role === 'super_admin'
            ? Database::fetchAll('SELECT a.*, u.full_name FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id ORDER BY a.id DESC LIMIT 6')
            : [];

        // ★ v26.8 — «مربی هوشمند یادگیری من»: بریفینگ صوتی، پیش‌بینی فراموشی و برنامه هفتگی (فقط داده‌های خود کاربر)
        $coach = [];
        $coachBriefing = [];
        if ($role === 'learner') {
            $coach = \App\Services\LearnerCoachService::coachBundle($userId, $user ?: []);
            $coachBriefing = \App\Services\LearnerCoachService::briefing($userId, $user ?: []);
        }

        $categoryStats = Database::fetchAll(
            'SELECT cc.title, cc.color, COUNT(c.id) AS cnt
             FROM course_categories cc
             LEFT JOIN courses c ON c.category_id = cc.id
             GROUP BY cc.id, cc.title, cc.color'
        );

        // داده‌های ایزوله اختصاصی هر نقش غیرمدیرکل
        $roleScoped = [
            'my_enrollments' => Database::fetchAll(
                'SELECT e.*, r.run_code, r.start_shamsi, r.schedule_text, c.id AS course_id, c.title AS course_title
                 FROM enrollments e
                 JOIN course_runs r ON r.id = e.run_id
                 JOIN courses c ON c.id = r.course_id
                 WHERE e.user_id = ?
                 ORDER BY e.id DESC',
                [$userId]
            ),
            'my_completed_lessons' => (int)Database::scalar('SELECT COUNT(*) FROM lms_progress WHERE user_id = ? AND is_completed = 1', [$userId]),
            'my_certs_count'       => (int)Database::scalar("SELECT COUNT(*) FROM certificates WHERE user_id = ? AND status = 'valid'", [$userId]),
            'instructor_runs'      => Database::fetchAll(
                'SELECT r.*, c.id AS course_id, c.title AS course_title
                 FROM course_runs r
                 JOIN courses c ON c.id = r.course_id
                 WHERE r.instructor_id = ? OR ? = "instructor"
                 ORDER BY r.id ASC LIMIT 5',
                [$userId, $role]
            ),
            'pending_assignments'  => Database::fetchAll(
                'SELECT a.*, u.full_name FROM lms_assignments a JOIN users u ON u.id = a.user_id ORDER BY a.id DESC LIMIT 5'
            ),
            'org_info'             => $orgId > 0
                ? Database::fetchOne('SELECT * FROM organizations WHERE id = ?', [$orgId])
                : Database::fetchOne('SELECT * FROM organizations ORDER BY id ASC LIMIT 1'),
            'org_enrollments'      => Database::fetchAll(
                'SELECT e.*, u.full_name, c.title AS course_title, r.run_code
                 FROM enrollments e
                 JOIN users u ON u.id = e.user_id
                 JOIN course_runs r ON r.id = e.run_id
                 JOIN courses c ON c.id = r.course_id
                 WHERE e.org_id = ? OR (? = 0 AND e.org_id IS NOT NULL)
                 ORDER BY e.id DESC LIMIT 6',
                [$orgId, $orgId]
            ),
            'org_invoices'         => Database::fetchAll(
                'SELECT * FROM invoices WHERE org_id = ? OR user_id = ? ORDER BY id DESC LIMIT 5',
                [$orgId > 0 ? $orgId : -1, $userId]
            ),
            'finance_invoices'     => $role === 'finance_manager' || $role === 'super_admin'
                ? Database::fetchAll('SELECT i.*, u.full_name FROM invoices i JOIN users u ON u.id = i.user_id ORDER BY i.id DESC LIMIT 5')
                : [],
            'sayad_count'          => $role === 'finance_manager' || $role === 'super_admin'
                ? (int)Database::scalar('SELECT COUNT(*) FROM sayad_cheques')
                : 0,
            'social_posts'         => $role === 'crm_manager' || $role === 'super_admin' || $role === 'training_expert'
                ? Database::fetchAll('SELECT * FROM social_media_posts ORDER BY id DESC LIMIT 5')
                : [],
        ];

        $this->render('dashboard/index', [
            'pageTitle'     => ($pageTitleMap[$role] ?? 'پیشخوان اختصاصی من'),
            'activeRole'    => $role,
            'kpis'          => $kpis,
            'recentRuns'    => $recentRuns,
            'openWorkflows' => $openWorkflows,
            'recentLogs'    => $recentLogs,
            'categoryStats' => $categoryStats,
            'roleScoped'    => $roleScoped,
            'phasesData'    => App::phases(),
            'coach'         => $coach,
            'coachBriefing' => $coachBriefing,
        ]);
    }
}
