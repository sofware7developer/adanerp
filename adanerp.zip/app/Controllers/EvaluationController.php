<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;

final class EvaluationController extends Controller
{
    public function index(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'add_evaluation') {
            Database::insert(
                'INSERT INTO evaluations (course_id, evaluator_id, kirkpatrick_l1_reaction, pre_test_score, post_test_score, kirkpatrick_l3_behavior, transfer_notes, program_cost_rial, estimated_benefit_rial, feedback_360_summary)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
                [
                    (int)$_POST['course_id'],
                    Auth::id(),
                    (float)$_POST['kirkpatrick_l1_reaction'],
                    (float)$_POST['pre_test_score'],
                    (float)$_POST['post_test_score'],
                    (float)$_POST['kirkpatrick_l3_behavior'],
                    trim((string)$_POST['transfer_notes']),
                    (int)$_POST['program_cost_rial'],
                    (int)$_POST['estimated_benefit_rial'],
                    trim((string)$_POST['feedback_360_summary']),
                ]
            );
            Auth::audit('EVALUATION', 'KIRKPATRICK_ROI_SAVED', 'course', (int)$_POST['course_id'], []);
            $this->flash('success', 'ارزیابی ۴ سطحی کرکپاتریک، پیش/پس‌آزمون، ۳۶۰ درجه و محاسبه ROI ثبت شد.');
            $this->redirect('evaluation');
        }

        $evals = Database::fetchAll(
            'SELECT ev.*, c.title AS course_title, c.code AS course_code
             FROM evaluations ev
             JOIN courses c ON c.id = ev.course_id
             ORDER BY ev.id DESC'
        );
        $courses = Database::fetchAll('SELECT id, code, title FROM courses ORDER BY id ASC');

        $this->render('evaluation/index', [
            'pageTitle' => 'ارزیابی اثربخشی، کرکپاتریک، ROI و بازخورد ۳۶۰ درجه',
            'evals' => $evals,
            'courses' => $courses,
        ]);
    }
}
