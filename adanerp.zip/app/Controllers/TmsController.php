<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Core\Jalali;
use App\Models\CourseModel;
use App\Services\WowEnterpriseSuiteService;

final class TmsController extends Controller
{
    private function sessionHasEnded(array $session): bool
    {
        $endTime = substr((string)($session['end_time'] ?? ''), 0, 5);
        if (!preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d$/', $endTime)) {
            return false;
        }
        return $session['session_date'] < date('Y-m-d')
            || (
                $session['session_date'] === date('Y-m-d')
                && $endTime <= date('H:i')
            );
    }

    public function index(): void
    {
        $courseModel = new CourseModel();

        // پشتیبانی از عملیات بدون رفرش (AJAX Drag & Drop کانبان و مسیر یادگیری)
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && (($_POST['ajax'] ?? '') === '1')) {
            while (ob_get_level() > 0) {
                ob_end_clean();
            }
            $op = (string)($_POST['op'] ?? '');
            if ($op === 'kanban_move' && Auth::hasRole(['super_admin', 'training_expert'])) {
                $cid = max(1, (int)($_POST['course_id'] ?? 1));
                $status = (string)($_POST['next_status'] ?? 'published');
                if (in_array($status, ['draft', 'under_review', 'approved', 'published', 'archived'], true)) {
                    Database::execute('UPDATE courses SET workflow_status = ? WHERE id = ?', [$status, $cid]);
                }
                $this->json(['ok' => true, 'course_id' => $cid, 'status' => $status]);
            }
            $this->json(['ok' => false], 400);
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();
            $action = (string)($_POST['action'] ?? '');

            // ★ v26.6 — قفل سمت سرور: این اکشن‌ها اقدام مدیریتی/مدرسی‌اند و برای نقش فراگیر ۴۰۳ برمی‌گردند
            $this->denyLearnerActions($action, ['ai_build_full_course', 'save_learning_path', 'save_pricing_scenario', 'create_course', 'create_run', 'create_session', 'bulk_group_enroll', 'cancel_enrollment', 'record_attendance', 'mark_session_held', 'save_exec_report', 'workflow_transition', 'kanban_move', 'start_run', 'complete_run', 'save_enrollment_api_token', 'disable_enrollment_api'], 'tms');

            if ($action === 'save_enrollment_api_token' && Auth::hasRole(['super_admin'])) {
                $token = trim((string)($_POST['api_token'] ?? ''));
                if (strlen($token) < 32 || strlen($token) > 200) {
                    $this->flash('danger', 'توکن باید بین ۳۲ تا ۲۰۰ نویسه باشد.');
                    $this->redirect('tms');
                }
                Database::saveSetting('enrollment_api_token', $token, 'api');
                Auth::audit('TMS_API', 'ENROLLMENT_API_TOKEN_ROTATED', 'system_setting', null, []);
                $this->flash('success', 'توکن API ثبت شد. آن را فقط در سربرگ X-API-Token سرویس‌گیرنده وارد کنید.');
                $this->redirect('tms');
            }

            if ($action === 'disable_enrollment_api' && Auth::hasRole(['super_admin'])) {
                Database::saveSetting('enrollment_api_token', '', 'api');
                Auth::audit('TMS_API', 'ENROLLMENT_API_DISABLED', 'system_setting', null, []);
                $this->flash('warning', 'API ثبت‌نام غیرفعال شد؛ تا زمان تنظیم توکن جدید درخواست‌ها رد می‌شوند.');
                $this->redirect('tms');
            }

            if ($action === 'ai_build_full_course' && Auth::hasRole(['super_admin', 'training_expert', 'instructor'])) {
                $res = WowEnterpriseSuiteService::aiBuildCompleteCourseBlueprint(
                    (string)($_POST['ai_course_prompt'] ?? ''),
                    (int)Auth::id()
                );
                $this->flash(
                    'success',
                    'دوره کامل «' . $res['title'] . '» با کد «' . $res['course_code'] . '»، اجرای کلاس «' . $res['run_code'] . '»، ۴ جلسه تقویمی و ۴ درس تعاملی در LMS به صورت خودکار ساخته شد!'
                );
                $this->redirect('tms');
            }

            if ($action === 'save_learning_path' && Auth::hasRole(['super_admin', 'training_expert', 'instructor'])) {
                WowEnterpriseSuiteService::saveLearningPath($_POST);
                $this->flash('success', 'مسیر جامع یادگیری (دیپلم مهارتی چنددوره‌ای) با تخفیف بسته در TMS ذخیره شد.');
                $this->redirect('tms');
            }

            if ($action === 'save_pricing_scenario' && Auth::hasRole(['super_admin', 'training_expert', 'finance_manager'])) {
                $res = WowEnterpriseSuiteService::savePricingScenario($_POST);
                $this->flash(
                    'success',
                    'سناریوی قیمت‌گذاری پویا ثبت شد — نقطه سربه‌سر: ' . Jalali::digits($res['breakeven_seats'])
                    . ' نفر | سود خالص پیش‌بینی‌شده: ' . Jalali::digits(number_format($res['net_profit_rial'])) . ' ریال.'
                );
                $this->redirect('tms');
            }

            if ($action === 'create_course' && Auth::hasRole(['super_admin', 'training_expert'])) {
                $code = strtoupper(trim((string)($_POST['code'] ?? '')));
                $title = trim((string)($_POST['title'] ?? ''));
                $categoryId = (int)($_POST['category_id'] ?? 0);
                $durationHours = (int)($_POST['duration_hours'] ?? 0);
                $tuitionRial = (int)($_POST['tuition_rial'] ?? -1);
                $discountPct = (int)($_POST['member_discount_pct'] ?? -1);
                $level = (string)($_POST['level'] ?? 'میانی');
                $deliveryMode = (string)($_POST['delivery_mode'] ?? 'ترکیبی');
                $category = Database::fetchOne('SELECT id FROM course_categories WHERE id = ?', [$categoryId]);
                if (
                    !preg_match('/^[A-Z0-9][A-Z0-9_-]{1,49}$/', $code)
                    || $title === '' || mb_strlen($title) > 220 || !$category
                    || $durationHours < 1 || $durationHours > 1000
                    || $tuitionRial < 0 || $discountPct < 0 || $discountPct > 100
                    || !in_array($level, ['مقدماتی', 'میانی', 'پیشرفته', 'مدیریتی ویژه'], true)
                    || !in_array($deliveryMode, ['حضوری', 'آنلاین همزمان', 'ترکیبی', 'خودآموز LMS'], true)
                    || Database::fetchOne('SELECT id FROM courses WHERE code = ?', [$code])
                ) {
                    $this->flash('danger', 'کد دوره باید یکتا و معتبر باشد؛ عنوان، دپارتمان، مدت و مقادیر شهریه/تخفیف را بررسی کنید.');
                    $this->redirect('tms');
                }
                $id = Database::insert(
                    'INSERT INTO courses (category_id, code, title, level, delivery_mode, duration_hours, tuition_rial, member_discount_pct, prerequisite_text, workflow_status, summary)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, "under_review", ?)',
                    [
                        $categoryId,
                        $code,
                        $title,
                        $level,
                        $deliveryMode,
                        $durationHours,
                        $tuitionRial,
                        $discountPct,
                        trim((string)($_POST['prerequisite_text'] ?? 'ندارد')),
                        trim((string)($_POST['summary'] ?? '')),
                    ]
                );
                Auth::audit('TMS', 'COURSE_CREATED_FOR_REVIEW', 'course', $id, ['code' => $code]);
                $this->flash('success', 'دوره جدید ثبت و وارد گردش بازبینی و تصویب کمیته علمی شد.');
                $this->redirect('tms');
            }

            if ($action === 'start_run' && Auth::hasRole(['super_admin', 'training_expert'])) {
                $runId = (int)($_POST['run_id'] ?? 0);
                $changed = Database::execute(
                    'UPDATE course_runs r
                     JOIN courses c ON c.id = r.course_id
                     SET r.status = "running"
                     WHERE r.id = ? AND r.status IN ("planning", "registration")
                       AND r.start_date <= CURDATE() AND c.workflow_status = "published"',
                    [$runId]
                );
                if ($changed !== 1) {
                    $this->flash('danger', 'شروع اجرا فقط برای اجرای ثبت‌نامی با تاریخ شروع رسیده مجاز است.');
                    $this->redirect('tms');
                }
                Auth::audit('TMS', 'COURSE_RUN_STARTED', 'course_run', $runId, []);
                $this->flash('success', 'اجرای دوره آغاز شد.');
                $this->redirect('tms');
            }

            if ($action === 'complete_run' && Auth::hasRole(['super_admin', 'training_expert'])) {
                $runId = (int)($_POST['run_id'] ?? 0);
                $run = Database::fetchOne('SELECT id, end_date, status FROM course_runs WHERE id = ?', [$runId]);
                $sessionCount = (int)Database::scalar('SELECT COUNT(*) FROM course_sessions WHERE run_id = ?', [$runId]);
                $futureSessions = (int)Database::scalar(
                    'SELECT COUNT(*) FROM course_sessions WHERE run_id = ? AND session_date > CURDATE()',
                    [$runId]
                );
                $courseHours = (int)Database::scalar(
                    'SELECT c.duration_hours FROM course_runs r JOIN courses c ON c.id = r.course_id WHERE r.id = ?',
                    [$runId]
                );
                $scheduledMinutes = (int)Database::scalar(
                    'SELECT COALESCE(SUM(TIME_TO_SEC(TIMEDIFF(end_time, start_time)) / 60), 0)
                     FROM course_sessions WHERE run_id = ?',
                    [$runId]
                );
                $unheldSessions = (int)Database::scalar(
                    'SELECT COUNT(*) FROM course_sessions WHERE run_id = ? AND is_held = 0',
                    [$runId]
                );
                if (
                    !$run || $run['status'] !== 'running' || $run['end_date'] > date('Y-m-d')
                    || $sessionCount === 0 || $futureSessions > 0 || $unheldSessions > 0
                    || $scheduledMinutes < ($courseHours * 60)
                ) {
                    $this->flash('danger', 'پایان اجرا به رسیدن تاریخ پایان، تکمیل ساعات مصوب، ثبت جلسات و تأیید برگزاری و حضور همه جلسات نیاز دارد.');
                    $this->redirect('tms');
                }
                $changed = Database::execute(
                    'UPDATE course_runs SET status = "completed" WHERE id = ? AND status = "running"',
                    [$runId]
                );
                if ($changed !== 1) {
                    $this->flash('danger', 'وضعیت اجرا هنگام ثبت پایان تغییر کرده است؛ صفحه را تازه‌سازی کنید.');
                    $this->redirect('tms');
                }
                Auth::audit('TMS', 'COURSE_RUN_COMPLETED', 'course_run', $runId, ['sessions' => $sessionCount]);
                $this->flash('success', 'اجرای دوره پایان‌یافته ثبت شد. صدور گواهی همچنان به حضور، پیشرفت و قبولی آزمون نیاز دارد.');
                $this->redirect('tms');
            }

            if ($action === 'create_run' && Auth::hasRole(['super_admin', 'training_expert'])) {
                $sDate = (string)($_POST['start_date'] ?? '');
                $eDate = (string)($_POST['end_date'] ?? '');
                $startDate = \DateTimeImmutable::createFromFormat('!Y-m-d', $sDate);
                $endDate = \DateTimeImmutable::createFromFormat('!Y-m-d', $eDate);
                $courseId = (int)($_POST['course_id'] ?? 0);
                $instructorId = (int)($_POST['instructor_id'] ?? 0);
                $capacity = (int)($_POST['capacity'] ?? 0);
                $course = Database::fetchOne(
                    'SELECT id, delivery_mode FROM courses WHERE id = ? AND workflow_status IN ("approved", "published")',
                    [$courseId]
                );
                $instructor = $instructorId > 0
                    ? Database::fetchOne(
                        'SELECT id FROM users WHERE id = ? AND role = "instructor" AND status = "active"',
                        [$instructorId]
                    )
                    : null;
                $classroomId = (int)($_POST['classroom_id'] ?? 0);
                $classroom = $classroomId > 0
                    ? Database::fetchOne('SELECT id, capacity FROM classrooms WHERE id = ? AND maintenance_status = "ready"', [$classroomId])
                    : null;
                $needsClassroom = $course && in_array($course['delivery_mode'], ['حضوری', 'ترکیبی'], true);
                if (
                    !$course || !$instructor || !$startDate || $startDate->format('Y-m-d') !== $sDate
                    || !$endDate || $endDate->format('Y-m-d') !== $eDate || $eDate < $sDate
                    || $sDate <= date('Y-m-d')
                    || $capacity < 1 || trim((string)($_POST['term_label'] ?? '')) === ''
                    || trim((string)($_POST['schedule_text'] ?? '')) === ''
                    || ($needsClassroom && !$classroom)
                    || ($classroomId > 0 && !$classroom)
                    || ($classroom && $capacity > (int)$classroom['capacity'])
                ) {
                    $this->flash('danger', 'دوره باید تصویب‌شده و مدرس فعال باشد؛ بازهٔ شروع و پایان معتبر، آینده‌نگر و ظرفیت سازگار با کلاس انتخاب کنید.');
                    $this->redirect('tms');
                }

                $runCode = 'RUN-' . date('Y') . '-' . strtoupper(bin2hex(random_bytes(4)));
                Database::insert(
                    'INSERT INTO course_runs (course_id, instructor_id, classroom_id, run_code, term_label, start_date, end_date, start_shamsi, schedule_text, capacity, status)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "registration")',
                    [
                        $courseId,
                        $instructorId,
                        $classroomId ?: null,
                        $runCode,
                        trim((string)$_POST['term_label']),
                        $sDate,
                        $eDate,
                        Jalali::fromGregorianString($sDate),
                        trim((string)$_POST['schedule_text']),
                        $capacity,
                    ]
                );
                $this->flash('success', "اجرای جدید دوره با کد «{$runCode}» در تقویم آموزشی تعریف شد.");
                $this->redirect('tms');
            }

            if ($action === 'create_session' && Auth::hasRole(['super_admin', 'training_expert', 'instructor'])) {
                $sDate = (string)($_POST['session_date'] ?? '');
                $sessionDate = \DateTimeImmutable::createFromFormat('!Y-m-d', $sDate);
                $runId = (int)($_POST['run_id'] ?? 0);
                $run = Database::fetchOne(
                    'SELECT r.id, r.start_date, r.end_date, r.status, r.instructor_id, r.classroom_id,
                            c.duration_hours, c.workflow_status
                     FROM course_runs r JOIN courses c ON c.id = r.course_id WHERE r.id = ?',
                    [$runId]
                );
                $startTime = (string)($_POST['start_time'] ?? '');
                $endTime = (string)($_POST['end_time'] ?? '');
                if (
                    !$run || $run['workflow_status'] !== 'published'
                    || !in_array($run['status'], ['registration', 'running'], true)
                    || !$sessionDate || $sessionDate->format('Y-m-d') !== $sDate
                    || $sDate < $run['start_date'] || $sDate > $run['end_date']
                    || $sDate < date('Y-m-d')
                    || ($sDate === date('Y-m-d') && $startTime <= date('H:i'))
                    || (int)($_POST['session_number'] ?? 0) < 1
                    || trim((string)($_POST['title'] ?? '')) === ''
                    || !preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d$/', $startTime)
                    || !preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d$/', $endTime)
                    || $endTime <= $startTime
                    || (Auth::role() === 'instructor' && (int)$run['instructor_id'] !== (int)Auth::id())
                ) {
                    $this->flash('danger', 'جلسه باید به اجرای باز تعلق داشته باشد؛ تاریخ باید در بازه اجرا و ساعت پایان پس از شروع باشد.');
                    $this->redirect('tms');
                }
                $newDurationMinutes = (int)((strtotime($endTime) - strtotime($startTime)) / 60);
                $scheduledMinutes = (int)Database::scalar(
                    'SELECT COALESCE(SUM(TIME_TO_SEC(TIMEDIFF(s.end_time, s.start_time)) / 60), 0)
                     FROM course_sessions s WHERE s.run_id = ?',
                    [$runId]
                );
                $conflict = Database::fetchOne(
                    'SELECT s.id
                     FROM course_sessions s
                     JOIN course_runs other_run ON other_run.id = s.run_id
                     WHERE s.session_date = ?
                       AND s.start_time < ? AND s.end_time > ?
                       AND other_run.status <> "cancelled"
                       AND (other_run.instructor_id = ? OR (? > 0 AND other_run.classroom_id = ?))
                     LIMIT 1',
                    [$sDate, $endTime, $startTime, (int)$run['instructor_id'], (int)$run['classroom_id'], (int)$run['classroom_id']]
                );
                $bookingConflict = $run['classroom_id']
                    ? Database::fetchOne(
                        'SELECT id FROM classroom_bookings
                         WHERE classroom_id = ? AND booking_date = ? AND start_time < ? AND end_time > ?
                         LIMIT 1',
                        [(int)$run['classroom_id'], $sDate, $endTime, $startTime]
                    )
                    : null;
                if (
                    $scheduledMinutes + $newDurationMinutes > ((int)$run['duration_hours'] * 60)
                    || $conflict || $bookingConflict
                ) {
                    $this->flash('danger', 'مدت جلسات از ساعات مصوب دوره بیشتر می‌شود یا زمان مدرس/کلاس با برنامهٔ دیگری تداخل دارد.');
                    $this->redirect('tms');
                }
                if (Database::fetchOne(
                    'SELECT id FROM course_sessions WHERE run_id = ? AND session_number = ?',
                    [$runId, (int)$_POST['session_number']]
                )) {
                    $this->flash('danger', 'شماره جلسه برای این اجرا قبلاً استفاده شده است.');
                    $this->redirect('tms');
                }
                Database::insert(
                    'INSERT INTO course_sessions (run_id, session_number, title, session_date, session_shamsi, start_time, end_time, room_or_link)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                    [
                        $runId,
                        (int)$_POST['session_number'],
                        trim((string)$_POST['title']),
                        $sDate,
                        Jalali::fromGregorianString($sDate),
                        (string)$_POST['start_time'],
                        (string)$_POST['end_time'],
                        trim((string)$_POST['room_or_link']),
                    ]
                );
                $this->flash('success', 'جلسه کلاسی جدید ثبت و به تقویم شمسی سامانه اضافه شد.');
                $this->redirect('tms');
            }

            if ($action === 'mark_session_held' && Auth::hasRole(['super_admin', 'training_expert', 'instructor'])) {
                $sessionId = (int)($_POST['session_id'] ?? 0);
                $session = Database::fetchOne(
                    'SELECT s.id, s.session_date, s.end_time, r.status AS run_status, r.instructor_id
                     FROM course_sessions s JOIN course_runs r ON r.id = s.run_id
                     WHERE s.id = ?',
                    [$sessionId]
                );
                if (
                    !$session || $session['run_status'] !== 'running' || $session['session_date'] > date('Y-m-d')
                    || !$this->sessionHasEnded($session)
                    || (Auth::role() === 'instructor' && (int)$session['instructor_id'] !== (int)Auth::id())
                ) {
                    $this->flash('danger', 'فقط مدرس مسئول یا کارشناس می‌تواند برگزاری جلسهٔ رسیده در اجرای درحال برگزاری را تأیید کند.');
                    $this->redirect('tms');
                }
                $unrecordedAttendance = (int)Database::scalar(
                    'SELECT COUNT(*)
                     FROM enrollments e
                     WHERE e.run_id = (
                         SELECT run_id FROM course_sessions WHERE id = ?
                     ) AND e.status = "active"
                       AND NOT EXISTS (
                           SELECT 1 FROM session_attendance sa
                           WHERE sa.session_id = ? AND sa.user_id = e.user_id
                       )',
                    [$sessionId, $sessionId]
                );
                if ($unrecordedAttendance > 0) {
                    $this->flash('danger', 'پیش از تأیید برگزاری، وضعیت حضور و غیاب همهٔ ثبت‌نام‌شدگان فعال را ثبت کنید.');
                    $this->redirect('tms');
                }
                Database::execute('UPDATE course_sessions SET is_held = 1 WHERE id = ?', [$sessionId]);
                Database::execute(
                    'UPDATE enrollments e
                     SET attendance_pct = (
                         SELECT CASE WHEN COUNT(DISTINCT s.id) = 0 THEN 0
                                     ELSE ROUND(COUNT(DISTINCT CASE WHEN sa.status IN ("present", "late") THEN s.id END) * 100
                                                / COUNT(DISTINCT s.id))
                                END
                         FROM course_sessions s
                         LEFT JOIN session_attendance sa ON sa.session_id = s.id AND sa.user_id = e.user_id
                         WHERE s.run_id = e.run_id AND s.is_held = 1
                     )
                     WHERE e.run_id = (SELECT run_id FROM course_sessions WHERE id = ?)
                       AND e.status IN ("active", "completed")',
                    [$sessionId]
                );
                Auth::audit('TMS', 'SESSION_MARKED_HELD', 'session', $sessionId, []);
                $this->flash('success', 'برگزاری جلسه ثبت شد.');
                $this->redirect('tms');
            }

            if ($action === 'workflow_transition' && Auth::hasRole(['super_admin', 'training_expert'])) {
                $cid = (int)$_POST['course_id'];
                $next = (string)$_POST['next_status'];
                $note = trim((string)($_POST['reviewer_note'] ?? 'بررسی و تایید شد'));
                if (in_array($next, ['draft', 'under_review', 'approved', 'published', 'archived'], true)) {
                    Database::execute(
                        'UPDATE courses SET workflow_status = ?, reviewer_note = ?, approved_by = ? WHERE id = ?',
                        [$next, $note, Auth::id(), $cid]
                    );
                    Auth::audit('TMS', 'COURSE_WORKFLOW_' . strtoupper($next), 'course', $cid, ['note' => $note]);
                    $this->flash('success', 'وضعیت گردش تصویب دوره با موفقیت به «' . $next . '» تغییر یافت.');
                }
                $this->redirect('tms');
            }

            if ($action === 'enroll_single') {
                $runId = (int)($_POST['run_id'] ?? 0);
                $targetUserId = Auth::hasRole(['super_admin', 'training_expert', 'org_rep'])
                    ? (int)($_POST['user_id'] ?? Auth::id())
                    : Auth::id();
                $pdo = Database::connection();
                $pdo->beginTransaction();
                try {
                    $runStmt = $pdo->prepare(
                        'SELECT r.*, c.workflow_status
                         FROM course_runs r JOIN courses c ON c.id = r.course_id
                         WHERE r.id = ? FOR UPDATE'
                    );
                    $runStmt->execute([$runId]);
                    $run = $runStmt->fetch(\PDO::FETCH_ASSOC);
                    $learnerStmt = $pdo->prepare(
                        'SELECT id, org_id FROM users WHERE id = ? AND role = "learner" AND status = "active" FOR UPDATE'
                    );
                    $learnerStmt->execute([$targetUserId]);
                    $learner = $learnerStmt->fetch(\PDO::FETCH_ASSOC);
                    if (
                        !$run || $run['status'] !== 'registration' || $run['workflow_status'] !== 'published'
                        || $run['start_date'] <= date('Y-m-d') || !$learner
                        || (Auth::role() === 'org_rep'
                            && (int)($learner['org_id'] ?? 0) !== (int)(Auth::user()['org_id'] ?? 0))
                    ) {
                        $pdo->rollBack();
                        $this->flash('danger', 'ثبت‌نام فقط برای فراگیر فعال در اجرای باز مجاز است و نماینده سازمان فقط به اعضای سازمان خود دسترسی دارد.');
                        $this->redirect('tms');
                    }

                    $existsStmt = $pdo->prepare('SELECT id FROM enrollments WHERE run_id = ? AND user_id = ?');
                    $existsStmt->execute([$runId, $targetUserId]);
                    if ($existsStmt->fetchColumn() !== false) {
                        $pdo->rollBack();
                        $this->flash('warning', 'این فراگیر پیش‌تر در این اجرای دوره ثبت شده است.');
                        $this->redirect('tms');
                    }

                    $activeCountStmt = $pdo->prepare(
                        'SELECT COUNT(*) FROM enrollments WHERE run_id = ? AND status = "active"'
                    );
                    $activeCountStmt->execute([$runId]);
                    $activeCount = (int)$activeCountStmt->fetchColumn();
                    $status = $activeCount >= (int)$run['capacity'] ? 'waitlist' : 'active';
                    $source = Auth::role() === 'org_rep' ? 'bulk_org' : 'web';
                    $insert = $pdo->prepare(
                        'INSERT INTO enrollments (run_id, user_id, org_id, source, status) VALUES (?, ?, ?, ?, ?)'
                    );
                    $insert->execute([$runId, $targetUserId, $learner['org_id'], $source, $status]);
                    if ($status === 'active') {
                        $pdo->prepare('UPDATE course_runs SET enrolled_count = ? WHERE id = ?')
                            ->execute([$activeCount + 1, $runId]);
                    }
                    $pdo->commit();
                } catch (\Throwable $e) {
                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                    }
                    throw $e;
                }

                if ($status === 'active') {
                    $this->flash('success', 'ثبت‌نام با موفقیت قطعی شد.');
                } else {
                    $this->flash('warning', 'ظرفیت اصلی تکمیل است؛ فراگیر به طور خودکار در «فهرست انتظار (Waitlist)» ثبت شد.');
                }
                Auth::audit('TMS', 'ENROLLMENT_' . strtoupper($status), 'course_run', $runId, ['user_id' => $targetUserId]);
                $this->redirect('tms');
            }

            if ($action === 'bulk_group_enroll' && Auth::hasRole(['super_admin', 'training_expert', 'org_rep'])) {
                $orgId = Auth::role() === 'org_rep' ? (int)(Auth::user()['org_id'] ?? 0) : null;
                if ($orgId === 0) {
                    $this->flash('danger', 'نمایندهٔ سازمان باید به یک سازمان فعال متصل باشد.');
                    $this->redirect('tms');
                }
                $res = $courseModel->importBulkGroupEnrollments(
                    (int)$_POST['run_id'],
                    $orgId,
                    (string)$_POST['csv_lines']
                );
                Auth::audit('TMS', 'BULK_GROUP_ENROLL', 'course_run', (int)$_POST['run_id'], $res);
                $this->flash(
                    'success',
                    'ثبت‌نام گروهی سازمانی انجام شد: ' . Jalali::digits($res['active']) . ' نفر ثبت قطعی و '
                    . Jalali::digits($res['waitlist']) . ' نفر در فهرست انتظار قرار گرفتند؛ '
                    . Jalali::digits($res['rejected']) . ' ردیف به‌دلیل اطلاعات ناقص یا نبود گذرواژه امن برای کاربر جدید رد شد.'
                );
                $this->redirect('tms');
            }

            if ($action === 'cancel_enrollment' && Auth::hasRole(['super_admin', 'training_expert', 'org_rep'])) {
                $enrollmentId = (int)($_POST['enrollment_id'] ?? 0);
                if (Auth::role() === 'org_rep') {
                    $owned = Database::fetchOne(
                        'SELECT id FROM enrollments WHERE id = ? AND (org_id = ? OR user_id = ?)',
                        [$enrollmentId, (int)(Auth::user()['org_id'] ?? 0), (int)Auth::id()]
                    );
                    if (!$owned) {
                        $this->flash('danger', 'امکان لغو ثبت‌نام متعلق به سازمان دیگر وجود ندارد.');
                        $this->redirect('tms');
                    }
                }
                $msg = $courseModel->cancelAndPromoteWaitlist($enrollmentId);
                $this->flash('info', $msg);
                $this->redirect('tms');
            }

            if ($action === 'record_attendance' && Auth::hasRole(['super_admin', 'training_expert', 'instructor'])) {
                $sessionId = (int)($_POST['session_id'] ?? 0);
                $userId = (int)($_POST['user_id'] ?? 0);
                $attStatus = (string)($_POST['att_status'] ?? 'present');
                $note = trim((string)($_POST['note'] ?? ''));
                $session = Database::fetchOne(
                    'SELECT s.id, s.run_id, s.session_date, s.end_time, r.status AS run_status, r.instructor_id
                     FROM course_sessions s JOIN course_runs r ON r.id = s.run_id
                     WHERE s.id = ?',
                    [$sessionId]
                );
                $enrollment = Database::fetchOne(
                    'SELECT id FROM enrollments WHERE run_id = ? AND user_id = ? AND status = "active"',
                    [(int)($session['run_id'] ?? 0), $userId]
                );
                if (
                    !$session || !$enrollment || $session['run_status'] !== 'running'
                    || $session['session_date'] > date('Y-m-d')
                    || !$this->sessionHasEnded($session)
                    || !in_array($attStatus, ['present', 'absent', 'late', 'excused'], true)
                    || (Auth::role() === 'instructor' && (int)$session['instructor_id'] !== (int)Auth::id())
                ) {
                    $this->flash('danger', 'ثبت حضور فقط برای فراگیر ثبت‌نام‌شده، جلسهٔ رسیده و مدرس مسئول مجاز است؛ وضعیت حضور نیز نامعتبر نباشد.');
                    $this->redirect('tms');
                }
                Database::execute(
                    'INSERT INTO session_attendance (session_id, user_id, status, note) VALUES (?, ?, ?, ?)
                     ON DUPLICATE KEY UPDATE status = VALUES(status), note = VALUES(note)',
                    [$sessionId, $userId, $attStatus, $note]
                );
                $attendancePct = (int)Database::scalar(
                    'SELECT CASE WHEN COUNT(DISTINCT s.id) = 0 THEN 0
                                 ELSE ROUND(COUNT(DISTINCT CASE WHEN sa.status IN ("present", "late") THEN s.id END) * 100 / COUNT(DISTINCT s.id))
                            END
                     FROM course_sessions s
                     LEFT JOIN session_attendance sa ON sa.session_id = s.id AND sa.user_id = ?
                     WHERE s.run_id = ? AND s.is_held = 1',
                    [$userId, (int)$session['run_id']]
                );
                Database::execute(
                    'UPDATE enrollments SET attendance_pct = ? WHERE run_id = ? AND user_id = ?',
                    [$attendancePct, (int)$session['run_id'], $userId]
                );
                Auth::audit('TMS', 'ATTENDANCE_RECORDED', 'session', $sessionId, ['user_id' => $userId, 'status' => $attStatus]);
                $this->flash('success', 'وضعیت حضور و غیاب جلسه ثبت و درصد حضور فراگیر به‌روزرسانی شد.');
                $this->redirect('tms');
            }

            if ($action === 'save_exec_report' && Auth::hasRole(['super_admin', 'training_expert', 'instructor'])) {
                $runId = (int)($_POST['run_id'] ?? 0);
                $run = Database::fetchOne('SELECT instructor_id FROM course_runs WHERE id = ?', [$runId]);
                if (!$run || (Auth::role() === 'instructor' && (int)$run['instructor_id'] !== (int)Auth::id())) {
                    $this->flash('danger', 'ثبت گزارش فقط برای مدرس مسئول همان اجرا یا کارشناس مجاز است.');
                    $this->redirect('tms');
                }
                Database::execute('UPDATE course_runs SET execution_report = ? WHERE id = ?', [trim((string)($_POST['execution_report'] ?? '')), $runId]);
                $this->flash('success', 'گزارش اجرای دوره ذخیره شد.');
                $this->redirect('tms');
            }
        }

        $q = trim((string)($_GET['q'] ?? ''));
        $catFilter = (int)($_GET['cat'] ?? 0);
        $statusFilter = trim((string)($_GET['st'] ?? ''));
        $canReviewCourses = Auth::hasRole(['super_admin', 'training_expert']);
        if (!$canReviewCourses) {
            $statusFilter = 'published';
        }

        $categories = Database::fetchAll('SELECT * FROM course_categories ORDER BY id ASC');
        $courses = $courseModel->getFilteredCatalog($q, $catFilter, $statusFilter);
        $allCoursesUnfiltered = $canReviewCourses
            ? $courseModel->getFilteredCatalog('', 0, '')
            : $courseModel->getFilteredCatalog('', 0, 'published');
        $instructorRunFilter = Auth::role() === 'instructor' ? ' WHERE r.instructor_id = ' . (int)Auth::id() : '';
        $runs = Database::fetchAll(
            'SELECT r.*,
                    (SELECT COUNT(*) FROM enrollments e WHERE e.run_id = r.id AND e.status = "active") AS actual_enrolled_count,
                    c.title AS course_title, c.code AS course_code, c.tuition_rial, u.full_name AS instructor_name, cl.name AS room_name
             FROM course_runs r
             JOIN courses c ON c.id = r.course_id
             LEFT JOIN users u ON u.id = r.instructor_id
             LEFT JOIN classrooms cl ON cl.id = r.classroom_id'
             . $instructorRunFilter . ' ORDER BY r.id DESC'
        );
        $sessions = Database::fetchAll(
            'SELECT s.*, r.run_code, r.status AS run_status, r.instructor_id, c.title AS course_title
             FROM course_sessions s
             JOIN course_runs r ON r.id = s.run_id
             JOIN courses c ON c.id = r.course_id'
             . $instructorRunFilter . ' ORDER BY s.session_date ASC'
        );
        $attendanceBySession = [];
        if (Auth::hasRole(['super_admin', 'training_expert', 'instructor'])) {
            $attendanceRows = Database::fetchAll(
                'SELECT s.id AS session_id, e.user_id, u.full_name, sa.status AS attendance_status
                 FROM course_sessions s
                 JOIN course_runs r ON r.id = s.run_id
                 JOIN enrollments e ON e.run_id = r.id AND e.status = "active"
                 JOIN users u ON u.id = e.user_id
                 LEFT JOIN session_attendance sa ON sa.session_id = s.id AND sa.user_id = e.user_id'
                 . $instructorRunFilter . ' ORDER BY s.session_date, u.full_name'
            );
            foreach ($attendanceRows as $attendanceRow) {
                $attendanceBySession[(int)$attendanceRow['session_id']][] = $attendanceRow;
            }
        }
        if (Auth::role() === 'instructor') {
            $enrollments = Database::fetchAll(
                'SELECT e.*, u.full_name, o.name AS org_name, r.run_code, c.title AS course_title
                 FROM enrollments e
                 JOIN users u ON u.id = e.user_id
                 LEFT JOIN organizations o ON o.id = e.org_id
                 JOIN course_runs r ON r.id = e.run_id
                 JOIN courses c ON c.id = r.course_id
                 WHERE r.instructor_id = ?
                 ORDER BY e.id DESC',
                [(int)Auth::id()]
            );
        } elseif (Auth::hasRole(['super_admin', 'training_expert', 'finance_manager'])) {
            $enrollments = Database::fetchAll(
                'SELECT e.*, u.full_name, o.name AS org_name, r.run_code, c.title AS course_title
                 FROM enrollments e
                 JOIN users u ON u.id = e.user_id
                 LEFT JOIN organizations o ON o.id = e.org_id
                 JOIN course_runs r ON r.id = e.run_id
                 JOIN courses c ON c.id = r.course_id
                 ORDER BY e.id DESC',
            );
        } elseif (Auth::role() === 'org_rep') {
            $uOrg = (int)(Auth::user()['org_id'] ?? 0);
            $enrollments = Database::fetchAll(
                'SELECT e.*, u.full_name, o.name AS org_name, r.run_code, c.title AS course_title
                 FROM enrollments e
                 JOIN users u ON u.id = e.user_id
                 LEFT JOIN organizations o ON o.id = e.org_id
                 JOIN course_runs r ON r.id = e.run_id
                 JOIN courses c ON c.id = r.course_id
                 WHERE e.org_id = ? OR e.user_id = ?
                 ORDER BY e.id DESC',
                [$uOrg, (int)Auth::id()]
            );
        } else {
            $enrollments = Database::fetchAll(
                'SELECT e.*, u.full_name, o.name AS org_name, r.run_code, c.title AS course_title
                 FROM enrollments e
                 JOIN users u ON u.id = e.user_id
                 LEFT JOIN organizations o ON o.id = e.org_id
                 JOIN course_runs r ON r.id = e.run_id
                 JOIN courses c ON c.id = r.course_id
                 WHERE e.user_id = ?
                 ORDER BY e.id DESC',
                [(int)Auth::id()]
            );
        }
        $learners = Auth::role() === 'org_rep'
            ? Database::fetchAll(
                'SELECT id, full_name, job_title FROM users
                 WHERE role = "learner" AND status = "active" AND org_id = ?
                 ORDER BY full_name ASC',
                [(int)(Auth::user()['org_id'] ?? 0)]
            )
            : Database::fetchAllSafe(
                'SELECT id, full_name, job_title FROM users WHERE role = "learner" AND status = "active" ORDER BY full_name ASC'
            );
        $classrooms = Database::fetchAllSafe('SELECT id, name, capacity FROM classrooms ORDER BY id ASC');
        $instructors = Database::fetchAllSafe(
            'SELECT id, full_name FROM users WHERE role = "instructor" AND status = "active" ORDER BY full_name ASC'
        );
        $learningPaths = Database::fetchAllSafe('SELECT * FROM tms_learning_paths ORDER BY id DESC');
        $pricingScenarios = Database::fetchAllSafe('SELECT * FROM tms_pricing_scenarios ORDER BY id DESC');

        $calEvents = [];
        foreach ($sessions as $s) {
            $calEvents[$s['session_shamsi']][] = 'جلسه: ' . $s['course_title'];
        }
        foreach (Database::fetchAll('SELECT title, event_shamsi FROM events') as $ev) {
            $calEvents[$ev['event_shamsi']][] = 'همایش: ' . $ev['title'];
        }
        $jy = max(1400, min(1415, (int)($_GET['jy'] ?? 1405)));
        $jm = max(1, min(12, (int)($_GET['jm'] ?? 8)));
        $calendar = Jalali::buildMonthCalendar($jy, $jm, $calEvents);

        $this->render('tms/index', [
            'pageTitle' => 'استودیوی جامع مدیریت آموزش، مسیر یادگیری و قیمت‌گذاری هوشمند (TMS)',
            'categories' => $categories,
            'courses' => $courses,
            'allCoursesUnfiltered' => $allCoursesUnfiltered,
            'runs' => $runs,
            'sessions' => $sessions,
            'attendanceBySession' => $attendanceBySession,
            'enrollments' => $enrollments,
            'learners' => $learners,
            'classrooms' => $classrooms,
            'instructors' => $instructors,
            'learningPaths' => $learningPaths,
            'pricingScenarios' => $pricingScenarios,
            'calendar' => $calendar,
            'jy' => $jy,
            'jm' => $jm,
            'q' => $q,
            'catFilter' => $catFilter,
            'statusFilter' => $statusFilter,
        ]);
    }
}
