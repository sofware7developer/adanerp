<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Core\Jalali;
use App\Models\FinanceModel;

final class FinanceController extends Controller
{
    /**
     * کنترل مالکیت سطری: آیا صورتحساب درخواستی به کاربر/سازمان فعلی تعلق دارد؟
     */
    private function ownsInvoice(int $invoiceId): bool
    {
        if ($invoiceId <= 0) {
            return false;
        }
        $u = Auth::user() ?? [];
        $uid = (int)($u['id'] ?? 0);
        $oid = (int)($u['org_id'] ?? 0);
        $row = Database::fetchOne('SELECT user_id, org_id FROM invoices WHERE id = ?', [$invoiceId]);
        if (!$row) {
            return false;
        }
        return (int)$row['user_id'] === $uid || ($oid > 0 && (int)($row['org_id'] ?? 0) === $oid);
    }

    public function index(): void
    {
        $finModel = new FinanceModel();

        $isFinAdminForActions = Auth::hasRole(['super_admin', 'finance_manager']);
        $canIssueInvoice = $isFinAdminForActions || Auth::hasRole(['training_expert', 'org_rep']);

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $action = (string)($_POST['action'] ?? '');

            // ★ v26.6 — قفل سمت سرور: این اکشن‌ها اقدام مدیریتی/مدرسی‌اند و برای نقش فراگیر ۴۰۳ برمی‌گردند
            $this->denyLearnerActions($action, ['create_invoice', 'add_ledger', 'create_double_voucher', 'register_sayad_cheque', 'clear_sayad_cheque', 'reconcile_bank_csv', 'settle_installment', 'confirm_refund'], 'finance');

            if (!$canIssueInvoice && in_array($action, ['create_invoice'], true)) {
                $this->flash('danger', 'دسترسی غیرمجاز: صدور صورتحساب آموزشی تنها برای واحد مالی، کارشناس آموزش و نماینده سازمان عضو ممکن است.');
                $this->redirect('finance');
            }

            if ($action === 'create_invoice') {
                $sub = (int)($_POST['subtotal_rial'] ?? 0);
                $description = trim((string)($_POST['item_description'] ?? ''));
                $mode = (string)($_POST['payment_mode'] ?? '');
                if ($sub <= 0 || $description === '' || !in_array($mode, ['installment', 'cash_gateway_sim', 'corporate_contract'], true)) {
                    $this->flash('danger', 'مبلغ، شرح و شیوه تسویه صورتحساب معتبر نیست.');
                    $this->redirect('finance');
                }

                $code = strtoupper(trim((string)($_POST['discount_code'] ?? '')));
                $pdo = Database::connection();
                $pdo->beginTransaction();
                try {
                    $discPct = 0;
                    $discountId = null;
                    if ($code !== '') {
                        $discountStmt = $pdo->prepare(
                            'SELECT * FROM discount_codes
                             WHERE code = ? AND is_active = 1 AND (max_uses IS NULL OR used_count < max_uses)
                             FOR UPDATE'
                        );
                        $discountStmt->execute([$code]);
                        $discount = $discountStmt->fetch(\PDO::FETCH_ASSOC);
                        if ($discount) {
                            $discPct = max(0, min(100, (int)$discount['discount_pct']));
                            $discountId = (int)$discount['id'];
                        }
                    }
                    $disc = (int)round(($sub * $discPct) / 100);
                    $vatRate = max(0, min(100, (int)Database::setting('vat_percent', '10')));
                    $vat = (int)round((($sub - $disc) * $vatRate) / 100);
                    $total = ($sub - $disc) + $vat;
                    $invNo = 'INV-ADN-' . date('Y') . '-' . strtoupper(bin2hex(random_bytes(6)));

                    $invoiceStmt = $pdo->prepare(
                        'INSERT INTO invoices (invoice_number, user_id, org_id, item_description, subtotal_rial, discount_rial, vat_rial, total_rial, payment_mode, status)
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, "unpaid")'
                    );
                    $invoiceStmt->execute([
                        $invNo,
                        Auth::id(),
                        Auth::user()['org_id'] ?? null,
                        mb_substr($description, 0, 255),
                        $sub,
                        $disc,
                        $vat,
                        $total,
                        $mode,
                    ]);
                    $invId = (int)$pdo->lastInsertId();

                    if ($discountId !== null) {
                        $pdo->prepare('UPDATE discount_codes SET used_count = used_count + 1 WHERE id = ?')
                            ->execute([$discountId]);
                    }
                    if ($mode === 'installment') {
                        $half = (int)round($total / 2);
                        $installmentStmt = $pdo->prepare(
                            'INSERT INTO invoice_installments (invoice_id, installment_no, due_shamsi, amount_rial) VALUES (?, ?, ?, ?)'
                        );
                        $installmentStmt->execute([$invId, 1, '۱۴۰۵/۰۸/۱۵', $half]);
                        $installmentStmt->execute([$invId, 2, '۱۴۰۵/۰۹/۱۵', $total - $half]);
                    }
                    $pdo->commit();
                } catch (\Throwable $e) {
                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                    }
                    throw $e;
                }

                Auth::audit('FINANCE', 'INVOICE_ISSUED', 'invoice', $invId, ['total' => $total, 'vat' => $vat]);
                $this->flash('success', "فاکتور رسمی شماره {$invNo} با احتساب تخفیف و {$vatRate}٪ مالیات ارزش افزوده صادر شد.");
                $this->redirect('finance');
            }

            if ($action === 'simulate_gateway_pay') {
                $invIdPay = (int)$_POST['invoice_id'];
                if (!$isFinAdminForActions && !$this->ownsInvoice($invIdPay)) {
                    $this->flash('danger', 'دسترسی غیرمجاز: شما تنها مجاز به پرداخت صورتحساب‌های اختصاصی خودتان هستید.');
                    $this->redirect('finance');
                }
                $tx = $finModel->simulateSignedGatewayPayment($invIdPay);
                if ($tx) {
                    $this->flash('warning', 'تراکنش صرفاً آزمایشی با کد ' . $tx['ref_id'] . ' ثبت شد؛ پرداخت واقعی انجام نشده و فاکتور تسویه نشده است.');
                }
                $this->redirect('finance');
            }

            if ($action === 'reconcile_bank_csv' && Auth::hasRole(['super_admin', 'finance_manager'])) {
                $rec = $finModel->reconcileBankCsv((string)$_POST['bank_csv']);
                $this->flash(
                    'info',
                    'آشتی صورت‌حساب بانکی انجام شد: ' . Jalali::digits($rec['matched']) . ' تراکنش منطبق تأیید شد و '
                    . Jalali::digits($rec['unmatched']) . ' ردیف دارای مغایرت شناسایی گردید.'
                );
                $this->redirect('finance');
            }

            if ($action === 'settle_installment') {
                if (!$isFinAdminForActions) {
                    $this->flash('danger', 'تأیید وصول دستی فقط برای مدیر مالی مجاز است.');
                    $this->redirect('finance');
                }
                $insId = (int)$_POST['installment_id'];
                $reference = trim((string)($_POST['payment_reference'] ?? ''));
                if (!preg_match('/^[A-Za-z0-9-]{6,80}$/', $reference)) {
                    $this->flash('danger', 'برای تأیید وصول، شماره پیگیری بانکی معتبر (۶ تا ۸۰ حرف یا رقم) الزامی است.');
                    $this->redirect('finance');
                }
                if ($finModel->settleInstallment($insId, $reference)) {
                    $this->flash('success', 'وصول دستی با شماره پیگیری ثبت شد و سند درآمدی آن در دفترکل درج گردید.');
                } else {
                    $this->flash('warning', 'این قسط قابل تأیید نیست؛ ممکن است قبلاً تسویه یا در انتظار استرداد باشد.');
                }
                $this->redirect('finance');
            }

            if ($action === 'request_refund') {
                $invId = (int)$_POST['invoice_id'];
                if (!$isFinAdminForActions && !$this->ownsInvoice($invId)) {
                    $this->flash('danger', 'دسترسی غیرمجاز: ثبت درخواست استرداد تنها برای صورتحساب‌های اختصاصی شما ممکن است.');
                    $this->redirect('finance');
                }
                $reason = trim((string)($_POST['refund_reason'] ?? ''));
                if ($reason === '') {
                    $this->flash('danger', 'برای درخواست استرداد، ذکر علت الزامی است.');
                    $this->redirect('finance');
                }
                $changed = Database::execute(
                    'UPDATE invoices SET status = "refund_requested", refund_reason = ?
                     WHERE id = ? AND status = "paid" AND refund_payment_reference IS NULL',
                    [$reason, $invId]
                );
                if ($changed !== 1) {
                    $this->flash('warning', 'درخواست استرداد فقط برای صورتحساب کاملاً پرداخت‌شده و با ذکر علت ثبت می‌شود.');
                    $this->redirect('finance');
                }
                Auth::audit('FINANCE', 'REFUND_REQUESTED', 'invoice', $invId, []);
                $this->flash('warning', 'درخواست استرداد وجه ثبت و به کارتابل تأیید دستی مدیر مالی ارجاع شد.');
                $this->redirect('finance');
            }

            if ($action === 'confirm_refund') {
                if (!$isFinAdminForActions) {
                    $this->flash('danger', 'ثبت انجام استرداد فقط برای مدیر مالی مجاز است.');
                    $this->redirect('finance');
                }
                $invId = (int)($_POST['invoice_id'] ?? 0);
                $reference = trim((string)($_POST['refund_payment_reference'] ?? ''));
                if (!preg_match('/^[A-Za-z0-9-]{6,80}$/', $reference)) {
                    $this->flash('danger', 'برای ثبت انجام استرداد، شماره پیگیری بانکی معتبر الزامی است.');
                    $this->redirect('finance');
                }
                if ($finModel->confirmRefund($invId, $reference)) {
                    $this->flash('success', 'استرداد پس از ثبت شماره پیگیری بانکی درج شد و سند معکوس در دفترکل ثبت گردید.');
                } else {
                    $this->flash('warning', 'استرداد انجام نشد؛ بررسی کنید حواله واقعاً پرداخت شده باشد و صورتحساب در انتظار استرداد باشد.');
                }
                $this->redirect('finance');
            }

            if ($action === 'confirm_invoice_payment') {
                if (!$isFinAdminForActions) {
                    $this->flash('danger', 'تأیید وصول فاکتور فقط برای مدیر مالی مجاز است.');
                    $this->redirect('finance');
                }
                $invId = (int)($_POST['invoice_id'] ?? 0);
                $reference = trim((string)($_POST['payment_reference'] ?? ''));
                if (!preg_match('/^[A-Za-z0-9-]{6,80}$/', $reference)) {
                    $this->flash('danger', 'برای تأیید وصول، شماره پیگیری بانکی یا رسید قرارداد معتبر الزامی است.');
                    $this->redirect('finance');
                }
                if ($finModel->confirmInvoicePayment($invId, $reference)) {
                    $this->flash('success', 'وصول پس از بررسی رسید ثبت شد و درآمد متناظر در دفترکل درج گردید.');
                } else {
                    $this->flash('warning', 'این فاکتور قابل وصول نیست؛ فقط فاکتور نقدی/قراردادیِ پرداخت‌نشده را بررسی کنید.');
                }
                $this->redirect('finance');
            }

            if ($action === 'add_ledger' && Auth::hasRole(['super_admin', 'finance_manager'])) {
                $type = (string)$_POST['entry_type'];
                $amt = (int)$_POST['amount_rial'];
                $debit = in_array($type, ['expense', 'refund'], true) ? $amt : 0;
                $credit = in_array($type, ['revenue', 'budget_alloc'], true) ? $amt : 0;
                Database::insert(
                    'INSERT INTO ledger_entries (entry_date, entry_shamsi, account_head, entry_type, debit_rial, credit_rial, description)
                     VALUES (CURDATE(), ?, ?, ?, ?, ?, ?)',
                    [Jalali::today(), trim((string)$_POST['account_head']), $type, $debit, $credit, trim((string)$_POST['description'])]
                );
                $this->flash('success', 'ردیف جدید در دفترکل مالی آموزش ثبت گردید.');
                $this->redirect('finance');
            }

            if ($action === 'register_sayad_cheque' && Auth::hasRole(['super_admin', 'finance_manager'])) {
                $sayad = preg_replace('/\D+/', '', (string)$_POST['sayad_16digit']);
                Database::insert(
                    'INSERT INTO sayad_cheques (sayad_16digit, drawer_company, bank_name, amount_rial, due_shamsi, inquiry_color, clearance_status)
                     VALUES (?, ?, ?, ?, ?, ?, "در جریان وصول")',
                    [
                        substr($sayad . '0000000000000000', 0, 16),
                        trim((string)$_POST['drawer_company']),
                        trim((string)$_POST['bank_name']),
                        max(1, (int)$_POST['amount_rial']),
                        trim((string)$_POST['due_shamsi']),
                        trim((string)($_POST['inquiry_color'] ?? 'سفید - خوش‌حساب')),
                    ]
                );
                $this->flash('success', 'چک صیادی ۱۶ رقمی پس از ثبت وضعیت استعلام در خزانه آموزشی ثبت گردید.');
                $this->redirect('finance');
            }

            if ($action === 'create_double_voucher' && Auth::hasRole(['super_admin', 'finance_manager'])) {
                $deb = max(1, (int)$_POST['debit_rial']);
                $cred = max(1, (int)$_POST['credit_rial']);
                if ($deb !== $cred) {
                    $this->flash('danger', 'خطای استاندارد حسابداری دوبل: جمع گردش بدهکار و بستانکار سند باید دقیقاً برابر و تراز باشد!');
                    $this->redirect('finance');
                }
                $vno = 'VCH-1405-' . rand(500, 999);
                Database::insert(
                    'INSERT INTO accounting_vouchers (voucher_no, voucher_shamsi, group_code, kol_account, moein_account, tafsili_entity, debit_rial, credit_rial, voucher_desc)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
                    [
                        $vno,
                        Jalali::today(),
                        trim((string)$_POST['group_code']),
                        trim((string)$_POST['kol_account']),
                        trim((string)$_POST['moein_account']),
                        trim((string)$_POST['tafsili_entity']),
                        $deb,
                        $cred,
                        trim((string)$_POST['voucher_desc']),
                    ]
                );
                $this->flash('success', "سند حسابداری ۴ سطحی تراز ({$vno}) با موفقیت در دفتر روزنامه و کل ثبت شد.");
                $this->redirect('finance');
            }

            if ($action === 'clear_sayad_cheque' && Auth::hasRole(['super_admin', 'finance_manager'])) {
                $ch = Database::fetchOne('SELECT * FROM sayad_cheques WHERE id = ?', [(int)$_POST['cheque_id']]);
                if ($ch && $ch['clearance_status'] !== 'وصول شده به دفترکل') {
                    Database::execute('UPDATE sayad_cheques SET clearance_status = "وصول شده به دفترکل" WHERE id = ?', [(int)$ch['id']]);
                    Database::insert(
                        'INSERT INTO ledger_entries (entry_date, entry_shamsi, account_head, entry_type, debit_rial, credit_rial, description)
                         VALUES (CURDATE(), ?, "۱۱۴۰ - اسناد دریافتنی و چک صیادی", "revenue", 0, ?, ?)',
                        [Jalali::today(), (int)$ch['amount_rial'], 'وصول چک صیادی ' . $ch['sayad_16digit'] . ' — ' . $ch['drawer_company']]
                    );
                    $this->flash('success', 'چک صیادی وصول و سند درآمدی آن به صورت خودکار در دفترکل ثبت گردید.');
                }
                $this->redirect('finance');
            }
        }

        $isFinAdmin = Auth::hasRole(['super_admin', 'finance_manager']);
        $uid = (int)Auth::id();
        $uOrgId = (int)(Auth::user()['org_id'] ?? 0);

        if ($isFinAdmin || Auth::hasRole(['training_expert'])) {
            $invoices = Database::fetchAll(
                'SELECT i.*, u.full_name, o.name AS org_name,
                        COALESCE((SELECT SUM(ins.amount_rial) FROM invoice_installments ins
                                  WHERE ins.invoice_id = i.id AND ins.status = "paid"), 0) AS paid_installments_rial
                 FROM invoices i
                 JOIN users u ON u.id = i.user_id
                 LEFT JOIN organizations o ON o.id = i.org_id
                 ORDER BY i.id DESC'
            );
            $installments = Database::fetchAll(
                'SELECT ins.*, i.invoice_number FROM invoice_installments ins JOIN invoices i ON i.id = ins.invoice_id ORDER BY ins.id DESC'
            );
            $transactions = Database::fetchAll(
                'SELECT pt.*, i.invoice_number FROM payment_transactions pt JOIN invoices i ON i.id = pt.invoice_id ORDER BY pt.id DESC'
            );
        } else {
            // ایزوله‌سازی سطری (Row-Level Security): فراگیر و نماینده سازمان صرفاً صورتحساب‌ها و اقساط خودشان را می‌بینند
            $invoices = Database::fetchAll(
                'SELECT i.*, u.full_name, o.name AS org_name,
                        COALESCE((SELECT SUM(ins.amount_rial) FROM invoice_installments ins
                                  WHERE ins.invoice_id = i.id AND ins.status = "paid"), 0) AS paid_installments_rial
                 FROM invoices i
                 JOIN users u ON u.id = i.user_id
                 LEFT JOIN organizations o ON o.id = i.org_id
                 WHERE i.user_id = ? OR (? > 0 AND i.org_id = ?)
                 ORDER BY i.id DESC',
                [$uid, $uOrgId, $uOrgId]
            );
            $installments = Database::fetchAll(
                'SELECT ins.*, i.invoice_number FROM invoice_installments ins
                 JOIN invoices i ON i.id = ins.invoice_id
                 WHERE i.user_id = ? OR (? > 0 AND i.org_id = ?)
                 ORDER BY ins.id DESC',
                [$uid, $uOrgId, $uOrgId]
            );
            $transactions = Database::fetchAll(
                'SELECT pt.*, i.invoice_number FROM payment_transactions pt
                 JOIN invoices i ON i.id = pt.invoice_id
                 WHERE i.user_id = ? OR (? > 0 AND i.org_id = ?)
                 ORDER BY pt.id DESC',
                [$uid, $uOrgId, $uOrgId]
            );
        }

        $ledger = $isFinAdmin ? Database::fetchAll('SELECT * FROM ledger_entries ORDER BY id DESC') : [];
        $profitability = ($isFinAdmin || Auth::hasRole(['training_expert'])) ? $finModel->getCourseProfitability() : [];
        $trialBalance = $isFinAdmin ? $finModel->getTrialBalance() : [];

        $sumRev = $isFinAdmin ? (int)Database::scalar("SELECT COALESCE(SUM(credit_rial),0) FROM ledger_entries WHERE entry_type='revenue'") : 0;
        $sumExp = $isFinAdmin ? (int)Database::scalar("SELECT COALESCE(SUM(debit_rial),0) FROM ledger_entries WHERE entry_type='expense'") : 0;
        $sumRefund = $isFinAdmin ? (int)Database::scalar("SELECT COALESCE(SUM(debit_rial),0) FROM ledger_entries WHERE entry_type='refund'") : 0;
        $sumBudget = $isFinAdmin ? (int)Database::scalar("SELECT COALESCE(SUM(credit_rial),0) FROM ledger_entries WHERE entry_type='budget_alloc'") : 0;
        $sayadCheques = $isFinAdmin ? Database::fetchAll('SELECT * FROM sayad_cheques ORDER BY id DESC') : [];
        $vouchers4Level = $isFinAdmin ? Database::fetchAll('SELECT * FROM accounting_vouchers ORDER BY id DESC LIMIT 10') : [];

        $this->render('finance/index', [
            'pageTitle' => $isFinAdmin ? 'مدیریت مالی آموزش، کدینگ ۴ سطحی دوبل، چک صیادی و دفترکل' : 'صورتحساب‌ها، اقساط و پرداخت شهریه من',
            'isFinAdmin' => $isFinAdmin,
            'invoices' => $invoices,
            'installments' => $installments,
            'ledger' => $ledger,
            'profitability' => $profitability,
            'trialBalance' => $trialBalance,
            'transactions' => $transactions,
            'sayadCheques' => $sayadCheques,
            'vouchers4Level' => $vouchers4Level,
            'sumRev' => $sumRev,
            'sumExp' => $sumExp,
            'sumRefund' => $sumRefund,
            'sumBudget' => $sumBudget,
        ]);
    }

    public function printInvoice(): void
    {
        $finModel = new FinanceModel();
        $id = (int)($_GET['id'] ?? 1);
        $invoice = $finModel->getInvoiceDetails($id);
        if (!$invoice) {
            $this->redirect('finance');
        }
        if (!Auth::hasRole(['super_admin', 'finance_manager', 'training_expert']) && !$this->ownsInvoice($id)) {
            $this->requireRole(['super_admin', 'finance_manager'], 'finance');
        }
        $this->render('finance/invoice_print', [
            'pageTitle' => 'چاپ رسمی صورتحساب مالیاتی شماره ' . $invoice['invoice_number'],
            'invoice' => $invoice,
        ]);
    }
}
