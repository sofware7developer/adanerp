<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Core\QrSvg;

/**
 * مرکز چاپ اسناد آموزشی و اداری مؤسسه آدان:
 * ۱. کارت ورود به کلاس گروهی/تکی با QR (/class-card-print)
 * ۲. قرارداد تیپ حق‌التدریس اساتید + گواهی کسر مالیات ماده ۸۶ (/instructor-contract-print)
 * ۳. کارت حضور برنامه آموزشی با کد QR (/event-badge-print)
 * ۴. قرارداد حقوقی تیپ خدمات آموزشی سازمانی (/contract-print)
 */
final class PrintCenterController extends Controller
{
    public function boardReportPrint(): void
    {
        $totalCourses = (int)Database::scalar('SELECT COUNT(*) FROM courses');
        $activeRuns = (int)Database::scalar('SELECT COUNT(*) FROM course_runs');
        $totalEnrolled = (int)Database::scalar('SELECT COUNT(*) FROM enrollments');
        $sumRev = (int)Database::scalar("SELECT COALESCE(SUM(credit_rial),0) FROM ledger_entries WHERE entry_type='revenue'");
        $sumExp = (int)Database::scalar("SELECT COALESCE(SUM(debit_rial),0) FROM ledger_entries WHERE entry_type='expense'");
        $contractsSum = (int)Database::scalar('SELECT COALESCE(SUM(total_amount_rial),0) FROM corporate_contracts');
        $sayadSum = (int)Database::scalar('SELECT COALESCE(SUM(amount_rial),0) FROM sayad_cheques');
        $qr = QrSvg::render('ADAN-REPORT|' . date('Y-m-d') . '|REV:' . $sumRev, 104);

        $this->renderPrintShell('گزارش مدیریتی آموزشگاه آدان', function () use (
            $totalCourses, $activeRuns, $totalEnrolled, $sumRev, $sumExp, $contractsSum, $sayadSum, $qr
        ): void {
            echo '<div class="no-print"><button onclick="window.print()">🖨️ چاپ گزارش مدیریتی آموزشگاه (A4)</button> <a href="' . e(url('dashboard')) . '">بازگشت به پیشخوان</a></div>';
            echo '<div class="print-box">
                <div class="hdr">
                    <div>
                        <h2>گزارش مدیریتی عملکرد آموزشی و مالی مؤسسه آدان</h2>
                        <div class="sub">دوره‌ها، ثبت‌نام‌ها و شاخص‌های مالی آموزشگاه</div>
                    </div>
                    <div>' . $qr . '</div>
                </div>
                <div class="meta-grid">
                    <div>دوره‌ها: <strong>' . fa($totalCourses) . ' عنوان (' . fa($activeRuns) . ' نوبت فعال)</strong></div>
                    <div>ثبت‌نام‌های آموزشی: <strong>' . fa($totalEnrolled) . '</strong></div>
                    <div>درآمد ثبت‌شده در دفترکل: <strong>' . rial($sumRev) . '</strong></div>
                    <div>تراز مازاد عملیاتی (درآمد منهای هزینه): <strong>' . rial($sumRev - $sumExp) . '</strong></div>
                    <div>مبلغ قراردادهای آموزشی سازمانی: <strong>' . rial($contractsSum) . '</strong></div>
                    <div>چک‌های دریافتنی ثبت‌شده: <strong>' . rial($sayadSum) . '</strong></div>
                </div>
                <p style="margin-top:16px;font-size:13px;line-height:1.85"><strong>یادداشت:</strong> این گزارش از سوابق ثبت‌شده در سامانه آدان تهیه شده است و جایگزین صورت‌های مالی تأییدشده یا گزارش حسابرس نیست.</p>
                <div style="display:flex;justify-content:space-between;margin-top:38px;padding-top:14px;border-top:1px dashed #94a3b8">
                    <div>تنظیم: مدیریت آموزشگاه</div>
                    <div>بررسی مالی: مسئول امور مالی</div>
                </div>
            </div>';
        });
    }

    public function classCardPrint(): void
    {
        $runId = max(1, (int)($_GET['run_id'] ?? 1));
        $run = Database::fetchOne(
            'SELECT r.*, c.title AS course_title, c.code AS course_code, c.duration_hours
             FROM course_runs r JOIN courses c ON c.id = r.course_id WHERE r.id = :id',
            ['id' => $runId]
        ) ?: Database::fetchOne(
            'SELECT r.*, c.title AS course_title, c.code AS course_code, c.duration_hours
             FROM course_runs r JOIN courses c ON c.id = r.course_id LIMIT 1'
        );

        $enrollees = Database::fetchAll(
            'SELECT e.id, e.status, u.full_name, u.national_code, u.mobile, o.name AS org_name
             FROM enrollments e
             JOIN users u ON u.id = e.user_id
             LEFT JOIN organizations o ON o.id = u.org_id
             WHERE e.run_id = :rid AND e.status = "enrolled"',
            ['rid' => (int)($run['id'] ?? 1)]
        );

        $this->renderPrintShell('کارت‌های ورود به کلاس — ' . ($run['course_title'] ?? ''), function () use ($run, $enrollees): void {
            $backTms = \App\Core\App::canViewRoute('tms') ? ' <a href="' . e(url('tms')) . '">بازگشت به ثبت‌نام و کلاس‌های من</a>' : '';
            echo '<div class="no-print"><button onclick="window.print()">🖨️ چاپ گروهی کارت‌های شرکت در کلاس</button>' . $backTms . '</div>';
            foreach ($enrollees as $row) {
                $qr = QrSvg::render('CLASS-PASS|' . ($run['course_code'] ?? '') . '|UID:' . $row['id'], 96);
                echo '<div class="print-box">
                    <div class="hdr">
                        <div><strong>کارت شرکت در دوره آموزشی آدان</strong><div class="sub">دوره: ' . e((string)$run['course_title']) . ' (' . e((string)$run['course_code']) . ')</div></div>
                        <div>' . $qr . '</div>
                    </div>
                    <div class="meta-grid">
                        <div>نام و نام خانوادگی: <strong>' . e($row['full_name']) . '</strong></div>
                        <div>کد ملی: <strong>' . fa((string)($row['national_code'] ?? '—')) . '</strong></div>
                        <div>سازمان معرفی‌کننده: <strong>' . e((string)($row['org_name'] ?? 'آدان / ثبت‌نام انفرادی')) . '</strong></div>
                        <div>مدت دوره / ترم: <strong>' . fa($run['duration_hours'] ?? 16) . ' ساعت — ' . e((string)($run['run_code'] ?? 'پاییز ۱۴۰۵')) . '</strong></div>
                    </div>
                </div>';
            }
        });
    }

    public function instructorContractPrint(): void
    {
        $id = max(1, (int)($_GET['id'] ?? 1));
        $ins = Database::fetchOne(
            'SELECT ip.*, u.full_name, u.national_code
             FROM instructor_profiles ip JOIN users u ON u.id = ip.user_id WHERE ip.id = :id',
            ['id' => $id]
        ) ?: Database::fetchOne(
            'SELECT ip.*, u.full_name, u.national_code
             FROM instructor_profiles ip JOIN users u ON u.id = ip.user_id LIMIT 1'
        );
        $hours = max(8, (int)($_GET['hours'] ?? 16));
        $gross = $hours * (int)($ins['hourly_rate_rial'] ?? 8500000);
        $tax86 = (int)round($gross * 0.10);
        $net = $gross - $tax86;
        $qr = QrSvg::render('INS-CONTRACT|' . ($ins['full_name'] ?? '') . '|NET:' . $net, 100);

        $this->renderPrintShell('قرارداد حق‌التدریس و گواهی کسر مالیات ماده ۸۶', function () use ($ins, $hours, $gross, $tax86, $net, $qr): void {
            echo '<div class="no-print"><button onclick="window.print()">🖨️ چاپ قرارداد رسمی حق‌التدریس و گواهی مالیات ماده ۸۶</button> <a href="' . e(url('instructors')) . '">بازگشت به بانک اساتید</a></div>';
            echo '<div class="print-box">
                <div class="hdr">
                    <div>
                        <h2>قرارداد تیپ حق‌التدریس و گواهی کسر مالیات تکلیفی (ماده ۸۶ ق.م.م)</h2>
                        <div class="sub">مؤسسه آموزشی آدان</div>
                    </div>
                    <div>' . $qr . '</div>
                </div>
                <p><strong>ماده ۱ — طرفین قرارداد:</strong> این قرارداد فیمابین مؤسسه آموزشی آدان و استاد ارجمند <strong>' . e($ins['full_name'] ?? '') . '</strong> (حوزه تخصص: ' . e($ins['specialties'] ?? '') . ') منعقد می‌گردد.</p>
                <p><strong>ماده ۲ — موضوع و ساعات تدریس واقعی:</strong> اجرای <strong>' . fa($hours) . ' ساعت</strong> تدریس تخصصی همراه با تحویل طرح درس، محتوای ارائه و سؤالات آزمون استاندارد.</p>
                <div class="meta-grid">
                    <div>نرخ مصوب هر ساعت تدریس: <strong>' . rial($ins['hourly_rate_rial'] ?? 0) . '</strong></div>
                    <div>ناخالص حق‌التدریس (' . fa($hours) . ' ساعت): <strong>' . rial($gross) . '</strong></div>
                    <div>کسور قانونی مالیات تکلیفی ماده ۸۶ (۱۰٪): <strong>' . rial($tax86) . '</strong></div>
                    <div>خالص قابل پرداخت به حساب شبای مدرس: <strong>' . rial($net) . '</strong></div>
                </div>
                <div style="display:flex;justify-content:space-between;margin-top:34px;padding-top:16px;border-top:1px dashed #94a3b8">
                    <div>امضای مدرس طرف قرارداد</div>
                    <div>تأیید مدیریت آموزش</div>
                    <div>تأیید امور مالی آدان</div>
                </div>
            </div>';
        });
    }

    public function eventBadgePrint(): void
    {
        $ticketId = max(0, (int)($_GET['ticket_id'] ?? 0));
        if ($ticketId === 0) {
            http_response_code(400);
            echo 'شناسه بلیت برای چاپ معتبر نیست.';
            return;
        }
        $reg = Database::fetchOne(
            'SELECT et.*, ev.title AS event_title, ev.event_shamsi, ev.venue, u.full_name
             FROM event_tickets et
             JOIN events ev ON ev.id = et.event_id
             JOIN users u ON u.id = et.user_id
             WHERE et.id = :id LIMIT 1',
            ['id' => $ticketId]
        );
        if (!$reg) {
            http_response_code(404);
            echo 'بلیت موردنظر برای چاپ پیدا نشد.';
            return;
        }
        $qr = QrSvg::render((string)$reg['ticket_code'], 112);

        $this->renderPrintShell('کارت حضور آموزشی — ' . $reg['full_name'], function () use ($reg, $qr): void {
            $backEvents = \App\Core\App::canViewRoute('events') ? ' <a href="' . e(url('events')) . '">بازگشت به برنامه‌های آموزشی</a>' : ' <a href="' . e(url('dashboard')) . '">بازگشت به پیشخوان</a>';
            echo '<div class="no-print"><button onclick="window.print()">🖨️ چاپ کارت حضور آموزشی</button>' . $backEvents . '</div>';
            echo '<div class="print-box" style="max-width:440px;margin:20px auto;text-align:center;border:3px solid #0b2545">
                <div style="background:#0b2545;color:#f8d57e;padding:12px;border-radius:10px;margin-bottom:14px">
                    <div style="font-size:12px">آموزشگاه حسابداری آدان</div>
                    <strong style="font-size:16px">' . e((string)$reg['event_title']) . '</strong>
                </div>
                <div style="font-size:22px;font-weight:800;margin:10px 0">' . e((string)$reg['full_name']) . '</div>
                <div style="color:#0f766e;font-weight:700;margin-bottom:12px">شرکت‌کننده در برنامه آموزشی</div>
                <div style="display:inline-block;padding:8px;border:1px solid #cbd5e1;border-radius:10px">' . $qr . '</div>
                <div style="font-family:monospace;margin-top:8px">' . e((string)$reg['ticket_code']) . '</div>
                <div style="margin-top:10px;font-size:12px;color:#475569">' . e((string)$reg['venue']) . ' | ' . e((string)$reg['event_shamsi']) . '</div>
            </div>';
        });
    }

    public function contractPrint(): void
    {
        $id = max(1, (int)($_GET['id'] ?? 1));
        $ctr = Database::fetchOne(
            'SELECT c.*, o.name AS org_name, o.national_id
             FROM corporate_contracts c JOIN organizations o ON o.id = c.org_id WHERE c.id = :id',
            ['id' => $id]
        ) ?: Database::fetchOne(
            'SELECT c.*, o.name AS org_name, o.national_id
             FROM corporate_contracts c JOIN organizations o ON o.id = c.org_id LIMIT 1'
        );
        $qr = QrSvg::render('CORP-CTR|' . ($ctr['contract_no'] ?? 'CTR-1405'), 100);

        $this->renderPrintShell('قرارداد آموزشی سازمانی — ' . ($ctr['contract_no'] ?? ''), function () use ($ctr, $qr): void {
            echo '<div class="no-print"><button onclick="window.print()">🖨️ چاپ قرارداد آموزشی آدان</button> <a href="' . e(url('contracts')) . '">بازگشت به قراردادها</a></div>';
            echo '<div class="print-box">
                <div class="hdr">
                    <div>
                        <h2>قرارداد رسمی ارائه خدمات آموزشی و توانمندسازی سرمایه‌های انسانی بنگاه‌های عضو</h2>
                        <div class="sub">شماره قرارداد: ' . e((string)($ctr['contract_no'] ?? '')) . '</div>
                    </div>
                    <div>' . $qr . '</div>
                </div>
                <p><strong>ماده ۱ (طرفین):</strong> مؤسسه آموزشی آدان و سازمان <strong>' . e((string)($ctr['org_name'] ?? '')) . '</strong> (شناسه ملی: ' . fa((string)($ctr['national_id'] ?? '')) . ').</p>
                <p><strong>ماده ۲ (موضوع و ظرفیت):</strong> اجرای دوره‌های آموزشی و حسابداری تا سقف <strong>' . fa($ctr['seat_quota'] ?? 50) . ' نفر-دوره</strong> (استفاده‌شده تاکنون: ' . fa($ctr['seats_used'] ?? 0) . ' نفر).</p>
                <p><strong>ماده ۳ (مبلغ کل قرارداد و شرایط تسویه):</strong> مبلغ کل قرارداد معادل <strong>' . rial($ctr['total_amount_rial'] ?? 0) . '</strong> بوده و مشمول صدور صورتحساب الکترونیکی سامانه مؤدیان مالیاتی می‌باشد.</p>
                <p><strong>ماده ۴ (مدت اعتبار و محرمانگی):</strong> اعتبار این قرارداد از <strong>' . e((string)($ctr['start_shamsi'] ?? '')) . '</strong> تا تاریخ <strong>' . e((string)($ctr['end_shamsi'] ?? '۱۴۰۵/۱۲/۲۹')) . '</strong> بوده و طرفین متعهد به حفظ اسرار تجاری و داده‌های پرسنلی می‌باشند.</p>
                <div style="display:flex;justify-content:space-between;margin-top:40px;padding-top:16px;border-top:1px dashed #94a3b8">
                    <div>امضای نماینده مجاز سازمان</div>
                    <div>مهر و امضای مؤسسه آموزشی آدان</div>
                </div>
            </div>';
        });
    }

    private function renderPrintShell(string $title, callable $contentRenderer): void
    {
        $curRoute = \App\Core\App::currentRoute() ?: 'board-report-print';
        echo '<!DOCTYPE html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><title>' . e($title) . '</title>
        <link rel="stylesheet" href="' . e(asset('css/app.css')) . '">
        ' . \App\Services\EnterpriseSettingsIamService::renderLiveThemeCssBlock() . '
        <style>
            body{background:#f1f5f9;padding:24px;color:#0f172a}
            .no-print{max-width:860px;margin:0 auto 16px;display:flex;gap:12px;align-items:center}
            .no-print button{background:#0b2545;color:#fff;border:0;padding:9px 18px;border-radius:10px;cursor:pointer;font-family:inherit;font-weight:700}
            .print-box{background:#fff;max-width:860px;margin:0 auto 20px;padding:28px;border-radius:16px;border:2px solid #cbd5e1;box-shadow:0 6px 20px rgba(15,23,42,.06)}
            .hdr{display:flex;justify-content:space-between;border-bottom:2px solid #c99227;padding-bottom:14px;margin-bottom:16px}
            .sub{color:#475569;font-size:13px;margin-top:4px}
            .meta-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;background:#f8fafc;padding:14px;border-radius:12px;margin-top:12px;font-size:13.5px}
            @media print{.no-print,#pageContextualHelpModal,#floatingPageHelpBtn{display:none!important} body{background:#fff;padding:0} .print-box{box-shadow:none;page-break-inside:avoid}}
        </style></head><body>';
        $contentRenderer();
        echo \App\Services\ContextualHelpEncyclopediaService::renderPageHelpModalAndFloatingTrigger($curRoute, \App\Core\Auth::check() ? \App\Core\Auth::roleLabel() : 'کاربر رسمی چاپ اسناد');
        echo '<script src="' . e(asset('js/app.js')) . '"></script></body></html>';
    }
}
