<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Core\Jalali;
use App\Services\WorkflowEngine;

final class OperationsController extends Controller
{
    private const PROCESS_KEYS = ['COURSE_APPROVAL', 'CONTRACT_DISCOUNT', 'EQUIPMENT_PURCHASE'];
    private const ROUTING_ROLES = ['super_admin', 'training_expert', 'finance_manager', 'crm_manager'];

    public function internships(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $action = (string)($_POST['action'] ?? '');
            if ($action === 'submit_milestone') {
                $this->requireRole(['super_admin', 'training_expert', 'learner'], 'internships');
                $id = max(0, (int)($_POST['internship_id'] ?? 0));
                $internship = Database::fetchOne('SELECT id, intern_user_id FROM internships WHERE id = ?', [$id]);
                $stage = trim((string)($_POST['milestone_stage'] ?? ''));
                $deliverable = trim((string)($_POST['deliverable_file'] ?? ''));
                if (!$internship) {
                    $this->redirect('internships', 'پروندهٔ کارآموزی پیدا نشد.', 'danger');
                }
                if ((string)Auth::role() === 'learner' && (int)$internship['intern_user_id'] !== (int)Auth::id()) {
                    $this->requireRole(['super_admin', 'training_expert'], 'internships');
                }
                if ($stage === '' || mb_strlen($stage) > 120 || mb_strlen($deliverable) > 255) {
                    $this->redirect('internships', 'عنوان مرحله الزامی است و طول اطلاعات تحویل معتبر نیست.', 'danger');
                }
                Database::execute(
                    'UPDATE internships SET milestone_stage = ?, deliverable_file = ? WHERE id = ?',
                    [$stage, $deliverable, $id]
                );
                $this->flash('success', 'تحویل مرحله‌ای پروژه کارآموزی با موفقیت ثبت شد.');
                $this->redirect('internships');
            }
            if ($action === 'save_rubric') {
                $this->requireRole(['super_admin', 'training_expert'], 'internships');
                $id = max(0, (int)($_POST['internship_id'] ?? 0));
                if (!Database::fetchOne('SELECT id FROM internships WHERE id = ?', [$id])) {
                    $this->redirect('internships', 'پروندهٔ کارآموزی پیدا نشد.', 'danger');
                }
                $scores = [];
                foreach (['r1', 'r2', 'r3', 'r4'] as $field) {
                    $value = filter_var($_POST[$field] ?? null, FILTER_VALIDATE_INT);
                    if ($value === false || $value < 0 || $value > 25) {
                        $this->redirect('internships', 'هر معیار روبریک باید عددی بین صفر تا ۲۵ باشد.', 'danger');
                    }
                    $scores[] = $value;
                }
                [$r1, $r2, $r3, $r4] = $scores;
                $sum = $r1 + $r2 + $r3 + $r4;
                $rubric = json_encode([
                    'تحلیل داده بازار' => $r1,
                    'تسلط بر قوانین گمرکی' => $r2,
                    'کیفیت مستندسازی تجاری' => $r3,
                    'کار تیمی و نظم حرفه‌ای' => $r4,
                ], JSON_UNESCAPED_UNICODE);
                Database::execute(
                    'UPDATE internships SET rubric_score_json = ?, total_score = ?, status = "evaluated" WHERE id = ?',
                    [$rubric, $sum, $id]
                );
                $this->flash('success', 'ارزیابی استاندارد روبریک (Rubric) ثبت شد؛ نمره کل: ' . Jalali::digits($sum));
                $this->redirect('internships');
            }
            if ($action === 'calc_pooyesh_tax') {
                $this->requireRole(['super_admin', 'training_expert'], 'internships');
                $company = trim((string)($_POST['host_company'] ?? ''));
                $intern = trim((string)($_POST['intern_fullname'] ?? ''));
                $months = filter_var($_POST['duration_months'] ?? null, FILTER_VALIDATE_INT);
                $stipend = filter_var($_POST['monthly_stipend_rial'] ?? null, FILTER_VALIDATE_INT);
                if ($company === '' || mb_strlen($company) > 200 || $intern === '' || mb_strlen($intern) > 180
                    || $months === false || $months < 1 || $months > 12
                    || $stipend === false || $stipend < 10000000 || $stipend > 10000000000) {
                    $this->redirect('internships', 'اطلاعات محاسبهٔ اعتبار مالیاتی معتبر نیست.', 'danger');
                }
                $res = \App\Services\DeepModuleSuiteService::calculatePooyeshTaxCredit(
                    $company,
                    $intern,
                    $months,
                    $stipend
                );
                $this->redirect('internships', 'برآورد محلی ثبت شد (' . $res['claim_code'] . ' — مبلغ محاسباتی: ' . number_format($res['tax_credit_rial']) . ' ریال). این خروجی گواهی رسمی یا تأیید اعتبار مالیاتی نیست.', 'warning');
            }
        }

        $items = Database::fetchAll(
            'SELECT i.*, o.name AS host_org, u.full_name AS intern_name
             FROM internships i
             JOIN organizations o ON o.id = i.host_org_id
             JOIN users u ON u.id = i.intern_user_id
             ' . (Auth::hasRole(['super_admin', 'training_expert']) ? '' : 'WHERE i.intern_user_id = ' . (int)Auth::id() . ' ') . '
             ORDER BY i.id DESC'
        );

        $this->render('operations/internships', [
            'pageTitle' => 'کارآموزی صنعتی (طرح پویش)، ارزیابی Rubric و اعتبار مالیاتی ماده ۱۱ دانش‌بنیان',
            'items' => $items,
            'taxClaims' => Auth::hasRole(['super_admin', 'training_expert'])
                ? Database::fetchAll('SELECT * FROM pooyesh_stipend_claims ORDER BY id DESC')
                : [],
        ]);
    }

    public function competitions(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'run_bizsim') {
            $this->requireRole(['super_admin', 'training_expert', 'learner'], 'competitions');
            $teamName = trim((string)($_POST['team_name'] ?? ''));
            $price = filter_var($_POST['export_pricing_usd'] ?? null, FILTER_VALIDATE_FLOAT);
            $hedge = filter_var($_POST['fx_hedge_ratio_pct'] ?? null, FILTER_VALIDATE_INT);
            $rnd = filter_var($_POST['rnd_investment_pct'] ?? null, FILTER_VALIDATE_INT);
            if ($teamName === '' || mb_strlen($teamName) > 140 || $price === false || $price <= 0 || $price > 1000000
                || $hedge === false || $hedge < 0 || $hedge > 100 || $rnd === false || $rnd < 0 || $rnd > 100) {
                $this->redirect('competitions', 'اطلاعات راند شبیه‌ساز معتبر نیست.', 'danger');
            }
            $res = \App\Services\DeepModuleSuiteService::runBizSimQuarterRound(
                $teamName,
                $price,
                $hedge,
                $rnd
            );
            $this->redirect('competitions', 'فصل جدید شبیه‌ساز استراتژی صادرات اجرا شد (' . $res['round_code'] . ' — سود عملیاتی EBITDA: $' . number_format($res['ebitda_usd']) . ').');
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'score_team') {
            $this->requireRole(['super_admin', 'training_expert'], 'competitions');
            $id = max(0, (int)($_POST['comp_id'] ?? 0));
            $score = filter_var($_POST['jury_score'] ?? null, FILTER_VALIDATE_FLOAT);
            $round = trim((string)($_POST['current_round'] ?? ''));
            $comment = trim((string)($_POST['judge_comment'] ?? ''));
            if (!Database::fetchOne('SELECT id FROM competitions WHERE id = ?', [$id])
                || $score === false || $score < 0 || $score > 100 || $round === '' || mb_strlen($round) > 80
                || mb_strlen($comment) > 300) {
                $this->redirect('competitions', 'تیم یا اطلاعات رأی داوری معتبر نیست.', 'danger');
            }
            $updated = Database::execute(
                'UPDATE competitions SET current_round = ?, jury_score = ?, judge_comment = ? WHERE id = ?',
                [$round, $score, $comment, $id]
            );
            if ($updated !== 1) {
                $this->redirect('competitions', 'رأی ثبت نشد؛ وضعیت تیم را بررسی کنید.', 'danger');
            }
            $this->flash('success', 'امتیاز هیئت داوران و وضعیت راند مسابقه به‌روزرسانی شد.');
            $this->redirect('competitions');
        }

        $teams = Database::fetchAll('SELECT * FROM competitions ORDER BY jury_score DESC');
        $simRounds = Database::fetchAll('SELECT * FROM bizsim_league_rounds ORDER BY simulated_ebitda_usd DESC');
        $this->render('operations/competitions', [
            'pageTitle' => 'مسابقات مهارتی، لیگ شبیه‌ساز فصلی صادرات و داوری وزن‌دار',
            'teams' => $teams,
            'simRounds' => $simRounds,
        ]);
    }

    public function hr(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $action = (string)($_POST['action'] ?? '');
            if ($action === 'create_hr_record') {
                $this->requireRole(['super_admin', 'finance_manager'], 'hr');
                $recordType = (string)($_POST['record_type'] ?? '');
                $title = trim((string)($_POST['title'] ?? ''));
                $details = trim((string)($_POST['details'] ?? ''));
                $kpiScore = ($_POST['kpi_score'] ?? '') === '' ? null : filter_var($_POST['kpi_score'], FILTER_VALIDATE_INT);
                if (!in_array($recordType, ['task', 'leave_request', 'periodic_eval', 'succession', 'payslip_note'], true)
                    || $title === '' || mb_strlen($title) > 200 || mb_strlen($details) > 400
                    || ($kpiScore !== null && ($kpiScore === false || $kpiScore < 0 || $kpiScore > 100))) {
                    $this->redirect('hr', 'نوع پرونده، عنوان یا امتیاز KPI معتبر نیست.', 'danger');
                }
                Database::insert(
                    'INSERT INTO hr_records (staff_user_id, record_type, title, details, kpi_score, status, created_shamsi)
                     VALUES (?, ?, ?, ?, ?, "open", ?)',
                    [
                        Auth::id(),
                        $recordType,
                        $title,
                        $details,
                        $kpiScore,
                        Jalali::today(),
                    ]
                );
                $this->flash('success', 'درخواست / پرونده منابع انسانی داخلی ثبت گردید.');
                $this->redirect('hr');
            }
            if ($action === 'approve_hr') {
                $this->requireRole(['super_admin'], 'hr');
                $changed = Database::execute(
                    'UPDATE hr_records SET status = "approved" WHERE id = ? AND status = "open"',
                    [max(0, (int)($_POST['hr_id'] ?? 0))]
                );
                if ($changed !== 1) {
                    $this->redirect('hr', 'پروندهٔ باز برای تأیید پیدا نشد.', 'danger');
                }
                $this->flash('success', 'درخواست پرسنلی توسط مدیریت تأیید شد.');
                $this->redirect('hr');
            }
        }

        $records = Database::fetchAll(
            'SELECT h.*, u.full_name, u.job_title FROM hr_records h JOIN users u ON u.id = h.staff_user_id ORDER BY h.id DESC'
        );

        $this->render('operations/hr', [
            'pageTitle' => 'منابع انسانی داخلی واحد آموزش مؤسسه آموزشی آدان',
            'records' => $records,
        ]);
    }

    public function bpms(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $action = (string)($_POST['action'] ?? '');

            if ($action === 'run_full_pipeline') {
                $this->requireRole(['super_admin'], 'bpms');
                $userId = max(0, (int)($_POST['user_id'] ?? 0));
                $courseId = max(0, (int)($_POST['course_id'] ?? 0));
                $attendancePct = filter_var($_POST['attendance_pct'] ?? null, FILTER_VALIDATE_INT);
                $examScore = filter_var($_POST['exam_score'] ?? null, FILTER_VALIDATE_FLOAT);
                if ($userId <= 0 || $courseId <= 0 || $attendancePct === false || $attendancePct < 0 || $attendancePct > 100
                    || $examScore === false || $examScore < 0 || $examScore > 100) {
                    $this->redirect('bpms', 'فراگیر، دوره یا نمرهٔ واردشده معتبر نیست.', 'danger');
                }
                $res = \App\Services\AutomationPipelineService::executeFullChain(
                    $userId,
                    $courseId,
                    $attendancePct,
                    $examScore
                );
                if ($res['ok'] ?? false) {
                    $this->flash(
                        'success',
                        '⚡ گردش‌کار آموزشی با موفقیت اجرا شد — سند حسابداری: ' . $res['voucher_no']
                        . ' | گواهی QR: ' . $res['cert_serial']
                        . ' | پرونده BPMS: ' . $res['bpms_code']
                    );
                } else {
                    $this->flash('danger', 'گردش‌کار اجرا نشد: ' . (string)($res['error'] ?? 'اطلاعات آموزشی واجد شرایط نیست.'));
                }
                $this->redirect('bpms');
            }

            if ($action === 'start_workflow') {
                $this->requireRole(self::ROUTING_ROLES, 'bpms');
                $procKey = (string)($_POST['process_key'] ?? '');
                $processTitle = trim((string)($_POST['process_title'] ?? ''));
                $subject = trim((string)($_POST['subject_label'] ?? ''));
                $fallbackRoles = $this->normalizeRoutingRoles((string)($_POST['assigned_role'] ?? ''));
                $fallbackSla = filter_var($_POST['sla_hours'] ?? null, FILTER_VALIDATE_INT);
                if (!in_array($procKey, self::PROCESS_KEYS, true) || $processTitle === '' || mb_strlen($processTitle) > 200
                    || $subject === '' || mb_strlen($subject) > 220 || $fallbackRoles === []
                    || $fallbackSla === false || $fallbackSla < 1 || $fallbackSla > 720) {
                    $this->redirect('bpms', 'اطلاعات آغاز فرایند معتبر نیست.', 'danger');
                }
                $amount = ($_POST['amount_rial'] ?? '') === '' ? null : filter_var($_POST['amount_rial'], FILTER_VALIDATE_INT);
                $discount = ($_POST['discount_pct'] ?? '') === '' ? null : filter_var($_POST['discount_pct'], FILTER_VALIDATE_FLOAT);
                $budgetCategory = trim((string)($_POST['budget_category'] ?? ''));
                if (($amount !== null && ($amount === false || $amount < 0 || $amount > 1000000000000000))
                    || ($discount !== null && ($discount === false || $discount < 0 || $discount > 100))
                    || ($budgetCategory !== '' && preg_match('/^[A-Z0-9_]+$/', $budgetCategory) !== 1)) {
                    $this->redirect('bpms', 'مقادیر زمینهٔ ارزیابی قاعده معتبر نیستند.', 'danger');
                }
                $context = [
                    'amount_rial' => $amount,
                    'discount_pct' => $discount,
                    'budget_category' => $budgetCategory,
                ];
                $rules = Database::fetchAll(
                    'SELECT * FROM bpms_routing_rules WHERE process_key = ? AND is_active = 1 ORDER BY id DESC',
                    [$procKey]
                );
                $matchedRule = null;
                foreach ($rules as $rule) {
                    if (self::matchesRoutingCondition((string)$rule['condition_expr'], $context)) {
                        $matchedRule = $rule;
                        break;
                    }
                }
                $ruleRoles = $matchedRule ? $this->normalizeRoutingRoles((string)$matchedRule['target_roles']) : [];
                if ($matchedRule && $ruleRoles === []) {
                    $this->redirect('bpms', 'قاعدهٔ مسیریابی شامل نقش مقصد نامعتبر است؛ قاعده را اصلاح کنید.', 'danger');
                }
                $targetRoles = $matchedRule ? $ruleRoles : $fallbackRoles;
                $targetRole = implode(' + ', $targetRoles);
                $targetSla = $matchedRule ? max(1, min(720, (int)$matchedRule['sla_hours'])) : $fallbackSla;
                $stepLabel = $matchedRule
                    ? 'مسیر ' . ($matchedRule['routing_mode'] === 'parallel' ? 'موازی هم‌زمان' : 'شرطی') . ' (' . $matchedRule['rule_name'] . ')'
                    : 'بررسی و تأیید مدیر مربوطه';

                $initHist = json_encode([[
                    'step' => 'ثبت اولیه و ارزیابی موتور قواعد BPMS -> ' . $stepLabel,
                    'by' => Auth::user()['full_name'] ?? 'کاربر',
                    'time' => Jalali::today() . ' ' . Jalali::digits(date('H:i')),
                ]], JSON_UNESCAPED_UNICODE);

                Database::insert(
                    'INSERT INTO bpms_workflows (process_key, process_title, subject_label, initiator_id, current_step, assigned_role, sla_hours, elapsed_hours, status, history_json)
                     VALUES (?, ?, ?, ?, ?, ?, ?, 1, "running", ?)',
                    [
                        $procKey,
                        $processTitle,
                        $subject,
                        Auth::id(),
                        $stepLabel,
                        $targetRole,
                        $targetSla,
                        $initHist,
                    ]
                );
                $this->flash('success', $matchedRule
                    ? 'فرایند با قاعدهٔ منطبق و ارجاع به نقش‌های «' . $targetRole . '» آغاز شد.'
                    : 'فرایند بدون قاعدهٔ منطبق، به نقش‌های انتخاب‌شده ارجاع شد.');
                $this->redirect('bpms');
            }

            if ($action === 'add_routing_rule') {
                $this->requireRole(['super_admin', 'training_expert', 'finance_manager'], 'bpms');
                $ruleName = trim((string)($_POST['rule_name'] ?? ''));
                $procKey = (string)($_POST['process_key'] ?? '');
                $condition = trim((string)($_POST['condition_expr'] ?? ''));
                $routingMode = (string)($_POST['routing_mode'] ?? '');
                $targetRoles = $this->normalizeRoutingRoles((string)($_POST['target_roles'] ?? ''));
                $sla = filter_var($_POST['sla_hours'] ?? null, FILTER_VALIDATE_INT);
                if ($ruleName === '' || mb_strlen($ruleName) > 180 || !in_array($procKey, self::PROCESS_KEYS, true)
                    || !self::isSupportedRoutingCondition($condition) || !in_array($routingMode, ['conditional', 'parallel'], true)
                    || $targetRoles === [] || $sla === false || $sla < 1 || $sla > 720) {
                    $this->redirect('bpms', 'قاعدهٔ مسیریابی معتبر نیست؛ شرط، نقش مقصد، نوع مسیر و SLA را بررسی کنید.', 'danger');
                }
                Database::insert(
                    'INSERT INTO bpms_routing_rules (rule_name, process_key, condition_expr, routing_mode, target_roles, sla_hours)
                     VALUES (?, ?, ?, ?, ?, ?)',
                    [
                        $ruleName,
                        $procKey,
                        $condition,
                        $routingMode,
                        implode(' + ', $targetRoles),
                        $sla,
                    ]
                );
                $this->flash('success', 'قاعده مسیریابی شرطی / موازی جدید در موتور BPMS ثبت گردید.');
                $this->redirect('bpms');
            }

            if ($action === 'transition_workflow') {
                $workflowId = max(0, (int)($_POST['workflow_id'] ?? 0));
                $workflow = Database::fetchOne('SELECT assigned_role FROM bpms_workflows WHERE id = ?', [$workflowId]);
                if (!$workflow) {
                    $this->redirect('bpms', 'پروندهٔ گردش‌کار پیدا نشد.', 'danger');
                }
                $this->requireRole($this->normalizeRoutingRoles((string)$workflow['assigned_role']), 'bpms');
                $decision = (string)($_POST['decision'] ?? '');
                if (!in_array($decision, ['approve', 'reject'], true)) {
                    $this->redirect('bpms', 'تصمیم گردش‌کار معتبر نیست.', 'danger');
                }
                $note = trim((string)($_POST['note'] ?? ''));
                if (mb_strlen($note) > 500) {
                    $this->redirect('bpms', 'یادداشت تصمیم حداکثر می‌تواند ۵۰۰ نویسه باشد.', 'danger');
                }
                $changed = WorkflowEngine::transition($workflowId, $decision, $note);
                $this->flash($changed ? 'success' : 'warning', $changed
                    ? 'تصمیم ثبت شد؛ در ارجاع موازی، فرایند پس از تأیید همهٔ نقش‌های مقصد تکمیل می‌شود.'
                    : 'پرونده قبلاً بسته شده یا تصمیم تکراری بوده است.');
                $this->redirect('bpms');
            }
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'bypass_bottleneck') {
            $this->requireRole(['super_admin', 'training_expert'], 'bpms');
            \App\Services\DeepModuleSuiteService::autoBypassBpmsBottleneck((int)($_POST['stage_id'] ?? 2));
            $this->redirect('bpms', 'گلوگاه فرایندی شناسایی‌شده با فعال‌سازی ارجاع موازی و OCR به زیر سقف SLA کاهش یافت.');
        }

        $workflows = Database::fetchAll('SELECT * FROM bpms_workflows ORDER BY id DESC');
        $routingRules = Database::fetchAll('SELECT * FROM bpms_routing_rules ORDER BY id DESC');
        $miningStages = Database::fetchAll('SELECT * FROM bpms_process_mining ORDER BY id ASC');
        $pipelineLearners = Auth::hasRole(['super_admin'])
            ? Database::fetchAll('SELECT id, full_name FROM users WHERE role = "learner" AND status = "active" ORDER BY full_name ASC')
            : [];
        $pipelineCourses = Auth::hasRole(['super_admin'])
            ? Database::fetchAll('SELECT DISTINCT c.id, c.title FROM courses c JOIN course_runs r ON r.course_id = c.id WHERE c.workflow_status IN ("approved", "published") AND r.status IN ("running", "completed") ORDER BY c.title ASC')
            : [];
        $this->render('operations/bpms', [
            'pageTitle' => 'موتور گردش کار (BPMS)، معدن‌کاوی گلوگاه (Process Mining) و پایش SLA',
            'workflows' => $workflows,
            'routingRules' => $routingRules,
            'miningStages' => $miningStages,
            'pipelineLearners' => $pipelineLearners,
            'pipelineCourses' => $pipelineCourses,
        ]);
    }

    private function normalizeRoutingRoles(string $roles): array
    {
        $parsed = preg_split('/[,+]/', $roles) ?: [];
        $normalized = [];
        foreach ($parsed as $role) {
            $role = trim($role);
            if ($role !== '' && !in_array($role, self::ROUTING_ROLES, true)) {
                return [];
            }
            if ($role !== '' && !in_array($role, $normalized, true)) {
                $normalized[] = $role;
            }
        }
        return $normalized;
    }

    private static function isSupportedRoutingCondition(string $condition): bool
    {
        return preg_match('/^\s*(amount_rial|discount_pct)\s*(>=|<=|==|=|>|<)\s*\d+(?:\.\d+)?\s*$/', $condition) === 1
            || preg_match('/^\s*budget_category\s*(==|=)\s*[A-Z0-9_]+\s*$/', $condition) === 1;
    }

    private static function matchesRoutingCondition(string $condition, array $context): bool
    {
        if (!self::isSupportedRoutingCondition($condition)) {
            return false;
        }
        if (preg_match('/^\s*(amount_rial|discount_pct)\s*(>=|<=|==|=|>|<)\s*(\d+(?:\.\d+)?)\s*$/', $condition, $match) === 1) {
            $actual = $context[$match[1]] ?? false;
            if ($actual === false || $actual === null) {
                return false;
            }
            $actual = (float)$actual;
            $expected = (float)$match[3];
            return match ($match[2]) {
                '>' => $actual > $expected,
                '<' => $actual < $expected,
                '>=' => $actual >= $expected,
                '<=' => $actual <= $expected,
                '=', '==' => $actual === $expected,
                default => false,
            };
        }
        if (preg_match('/^\s*budget_category\s*(==|=)\s*([A-Z0-9_]+)\s*$/', $condition, $match) === 1) {
            $actual = (string)($context['budget_category'] ?? '');
            return $actual !== '' && $actual === $match[2];
        }
        return false;
    }
}
