<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\App;
use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Services\BackupService;
use App\Services\CronService;

final class SystemOpsController extends Controller
{
    public function index(): void
    {
        if (isset($_GET['download_sql']) && $_GET['download_sql'] === '1') {
            $dump = BackupService::generateSqlDump();
            Auth::audit('SYSTEM_OPS', 'SQL_BACKUP_DOWNLOADED', 'database', null, ['bytes' => strlen($dump)]);
            header('Content-Type: application/sql; charset=utf-8');
            header('Content-Disposition: attachment; filename="chamber_edu_backup_' . date('Ymd_His') . '.sql"');
            echo $dump;
            exit;
        }

        if (isset($_GET['export_audit']) && $_GET['export_audit'] === '1') {
            $logs = Database::fetchAll(
                'SELECT a.id, a.module, a.action, COALESCE(u.full_name, "مهمان") AS full_name, a.user_role, a.ip_address, a.created_at
                 FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id ORDER BY a.id DESC LIMIT 500'
            );
            $this->exportCsv('chamber_security_audit_logs.csv', ['شناسه','ماژول','عملیات','کاربر','نقش','IP','زمان'], $logs);
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'run_cron_now') {
            $this->requireCsrf();
            try {
                $result = CronService::run();
                Auth::audit('SYSTEM_OPS', 'MANUAL_CRON_EXECUTED', 'cron', null, $result);
                $message = sprintf(
                    'کار Cron پایان یافت: %d کار موفق، %d ناموفق و %d گردش‌کار با زمان واقعی به‌روزرسانی شد.',
                    $result['completed'],
                    $result['failed'],
                    $result['workflow_rows_updated']
                );
                $this->flash($result['failed'] > 0 ? 'danger' : 'success', $message);
            } catch (\Throwable $e) {
                $this->flash('danger', 'اجرای Cron ناموفق بود: ' . $e->getMessage());
            }
            $this->redirect('system-ops');
        }

        $health = BackupService::runHealthChecks();
        $phases = App::phases();
        $stats = [
            'tables' => count(Database::fetchAll('SHOW TABLES')),
            'users' => (int)Database::scalar('SELECT COUNT(*) FROM users'),
            'courses' => (int)Database::scalar('SELECT COUNT(*) FROM courses'),
            'audit_logs' => (int)Database::scalar('SELECT COUNT(*) FROM audit_logs'),
        ];
        $cronJobs = Database::fetchAll(
            "SELECT name, target_url_or_handler, event_trigger, status, last_response, last_run_at
             FROM webhooks_and_jobs
             WHERE entry_kind = 'queue_job'
             ORDER BY id DESC
             LIMIT 10"
        );

        $this->render('bi/system_ops', [
            'pageTitle' => 'مرکز عملیات استقرار، پشتیبان‌گیری SQL، سلامت سرور و ماتریس RBAC',
            'health' => $health,
            'phases' => $phases,
            'stats' => $stats,
            'cronJobs' => $cronJobs,
        ]);
    }
}
