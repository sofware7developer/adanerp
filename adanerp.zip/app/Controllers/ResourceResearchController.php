<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Core\Jalali;
use App\Services\AvalAiService;

final class ResourceResearchController extends Controller
{
    public function classrooms(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $action = (string)($_POST['action'] ?? '');

            if ($action === 'book_room') {
                $roomId = (int)$_POST['classroom_id'];
                $date = (string)$_POST['booking_date'];
                $start = (string)$_POST['start_time'];
                $end = (string)$_POST['end_time'];

                if ($start >= $end) {
                    $this->flash('danger', 'ساعت پایان رزرو باید بزرگ‌تر از ساعت شروع باشد.');
                    $this->redirect('classrooms');
                }

                // کنترل دقیق تداخل زمانی اسلات در سطح SQL
                $conflict = Database::fetchOne(
                    'SELECT * FROM classroom_bookings
                     WHERE classroom_id = ? AND booking_date = ? AND (? < end_time AND ? > start_time)
                     LIMIT 1',
                    [$roomId, $date, $start, $end]
                );

                if ($conflict) {
                    Auth::audit('CLASSROOMS', 'BOOKING_OVERLAP_PREVENTED', 'classroom', $roomId, ['date' => $date]);
                    $this->flash(
                        'danger',
                        'خطای تداخل زمانی: این سالن در بازه ' . $conflict['start_time'] . ' تا ' . $conflict['end_time']
                        . ' برای «' . $conflict['purpose'] . '» قبلاً رزرو شده است!'
                    );
                } else {
                    Database::insert(
                        'INSERT INTO classroom_bookings (classroom_id, booked_by, purpose, booking_date, booking_shamsi, start_time, end_time, catering_request)
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                        [
                            $roomId,
                            Auth::id(),
                            trim((string)$_POST['purpose']),
                            $date,
                            Jalali::fromGregorianString($date),
                            $start,
                            $end,
                            trim((string)($_POST['catering_request'] ?? '')),
                        ]
                    );
                    $this->flash('success', 'رزرو سالن پس از کنترل عدم تداخل زمانی با موفقیت ثبت شد.');
                }
                $this->redirect('classrooms');
            }

            if ($action === 'report_issue') {
                Database::execute(
                    'UPDATE classrooms SET maintenance_status = "service_needed", maintenance_note = ? WHERE id = ?',
                    [trim((string)$_POST['maintenance_note']), (int)$_POST['classroom_id']]
                );
                $this->flash('warning', 'درخواست خدمات فنی / اعلام خرابی تجهیزات سالن ثبت گردید.');
                $this->redirect('classrooms');
            }
        }

        $rooms = Database::fetchAll('SELECT * FROM classrooms ORDER BY id ASC');
        $bookings = Database::fetchAll(
            'SELECT b.*, c.name AS room_name, u.full_name
             FROM classroom_bookings b
             JOIN classrooms c ON c.id = b.classroom_id
             JOIN users u ON u.id = b.booked_by
             ORDER BY b.booking_date DESC, b.start_time ASC'
        );

        $this->render('resources/classrooms', [
            'pageTitle' => 'مدیریت کلاس‌ها، سالن‌ها و رزرو بدون تداخل زمانی',
            'rooms' => $rooms,
            'bookings' => $bookings,
        ]);
    }

    public function research(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'create_research') {
            Database::insert(
                'INSERT INTO research_projects (title, lead_researcher, methodology, budget_rial, progress_pct, form_id, publication_summary, status)
                 VALUES (?, ?, ?, ?, 25, 1, ?, "proposal")',
                [
                    trim((string)$_POST['title']),
                    trim((string)$_POST['lead_researcher']),
                    trim((string)$_POST['methodology']),
                    (int)$_POST['budget_rial'],
                    trim((string)$_POST['publication_summary']),
                ]
            );
            $this->flash('success', 'طرح پژوهشی جدید ثبت و به فرم‌ساز پویا متصل گردید.');
            $this->redirect('research');
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'submit_peer_review') {
            Database::insert(
                'INSERT INTO research_peer_reviews (project_id, reviewer_alias, scientific_score, applicability_score, recommendation, review_comment, reviewed_shamsi)
                 VALUES (?, ?, ?, ?, ?, ?, ?)',
                [
                    (int)$_POST['project_id'],
                    trim((string)$_POST['reviewer_alias']),
                    (int)$_POST['scientific_score'],
                    (int)$_POST['applicability_score'],
                    trim((string)$_POST['recommendation']),
                    trim((string)$_POST['review_comment']),
                    Jalali::today(),
                ]
            );
            Database::execute('UPDATE research_projects SET progress_pct = LEAST(100, progress_pct + 20) WHERE id = ?', [(int)$_POST['project_id']]);
            $this->flash('success', 'داوری همتای دوسوکور (Peer Review) ثبت شد و پیشرفت آزادسازی قسط بودجه طرح پژوهشی به‌روز گردید.');
            $this->redirect('research');
        }

        $projects = Database::fetchAll('SELECT * FROM research_projects ORDER BY id DESC');
        $peerReviews = Database::fetchAll('SELECT r.*, p.title AS project_title FROM research_peer_reviews r LEFT JOIN research_projects p ON p.id = r.project_id ORDER BY r.id DESC');
        $this->render('resources/research', [
            'pageTitle' => 'پژوهش آموزشی، داوری دوسوکور همتا و انتشارات اتاق',
            'projects' => $projects,
            'peerReviews' => $peerReviews,
        ]);
    }

    public function library(): void
    {
        $q = trim((string)($_GET['q'] ?? ''));
        $aiAnswer = null;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $action = (string)($_POST['action'] ?? '');

            if ($action === 'loan_book') {
                $itemId = (int)$_POST['item_id'];
                Database::execute('UPDATE library_items SET available_copies = GREATEST(0, available_copies - 1), downloads_count = downloads_count + 1 WHERE id = ?', [$itemId]);
                Database::insert(
                    'INSERT INTO library_loans (item_id, user_id, loan_shamsi, due_shamsi, review_note)
                     VALUES (?, ?, ?, "۱۴۰۵/۰۸/۲۰", ?)',
                    [$itemId, Auth::id(), Jalali::today(), trim((string)($_POST['review_note'] ?? 'درخواست مطالعه تخصصی'))]
                );
                $this->flash('success', 'امانت / دریافت منبع دانشی ثبت گردید.');
                $this->redirect('library');
            }

            if ($action === 'return_loan') {
                $loan = Database::fetchOne('SELECT * FROM library_loans WHERE id = ?', [(int)$_POST['loan_id']]);
                if ($loan && !$loan['returned_at']) {
                    Database::execute('UPDATE library_loans SET returned_at = NOW() WHERE id = ?', [(int)$loan['id']]);
                    Database::execute('UPDATE library_items SET available_copies = available_copies + 1 WHERE id = ?', [(int)$loan['item_id']]);
                    $this->flash('success', 'بازگشت منبع به کتابخانه ثبت و موجودی افزایش یافت.');
                }
                $this->redirect('library');
            }

            if ($action === 'ai_library_assist') {
                $query = trim((string)$_POST['ai_query']);
                $itemsText = implode("\n", array_map(
                    static fn($it) => "{$it['title']}: {$it['abstract_text']}",
                    Database::fetchAll('SELECT title, abstract_text FROM library_items')
                ));
                $aiAnswer = AvalAiService::generate(
                    "جست‌وجوی کمکی کتابخانه مؤسسه آموزشی آدان برای پرسش «{$query}» بر اساس چکیده منابع موجود:\n{$itemsText}",
                    'Library Knowledge'
                );
            }
        }

        $items = $q !== ''
            ? Database::fetchAll('SELECT l.*, c.title AS course_title FROM library_items l LEFT JOIN courses c ON c.id = l.course_id WHERE l.title LIKE ? OR l.abstract_text LIKE ?', ['%' . $q . '%', '%' . $q . '%'])
            : Database::fetchAll('SELECT l.*, c.title AS course_title FROM library_items l LEFT JOIN courses c ON c.id = l.course_id ORDER BY l.id ASC');

        $loans = Database::fetchAll(
            'SELECT ln.*, li.title, u.full_name
             FROM library_loans ln
             JOIN library_items li ON li.id = ln.item_id
             JOIN users u ON u.id = ln.user_id
             ORDER BY ln.id DESC'
        );

        $this->render('resources/library', [
            'pageTitle' => 'کتابخانه تخصصی و مرکز دانش بازرگانی',
            'items' => $items,
            'loans' => $loans,
            'q' => $q,
            'aiAnswer' => $aiAnswer,
        ]);
    }
}
