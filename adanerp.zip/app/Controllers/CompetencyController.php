<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Services\AvalAiService;

final class CompetencyController extends Controller
{
    public function index(): void
    {
        $aiReport = null;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $action = (string)($_POST['action'] ?? '');

            // ★ v26.6 — قفل سمت سرور: این اکشن‌ها اقدام مدیریتی/مدرسی‌اند و برای نقش فراگیر ۴۰۳ برمی‌گردند
            $this->denyLearnerActions($action, ['review_proposal', 'run_ai_gap_summary'], 'competency');

            if ($action === 'add_assessment') {
                $uid = Auth::hasRole(['super_admin', 'training_expert', 'org_rep'])
                    ? (int)($_POST['user_id'] ?? Auth::id())
                    : Auth::id();
                $compId = (int)$_POST['competency_id'];
                $cur = max(1, min(5, (int)$_POST['current_level']));
                $tar = max(1, min(5, (int)$_POST['target_level']));
                $gap = max(0, $tar - $cur);
                $rec = $gap >= 2
                    ? 'شکاف مهارتی قابل توجه (' . $gap . ' سطح)؛ گذراندن دوره کاربردی مرتبط در ترم جاری اکیداً پیشنهاد می‌شود.'
                    : 'شکاف محدود؛ مرور منابع کتابخانه و خردآموزی کافی است.';

                Database::insert(
                    'INSERT INTO competency_assessments (user_id, competency_id, target_role_title, current_level, target_level, priority, ai_recommendation)
                     VALUES (?, ?, ?, ?, ?, ?, ?)',
                    [$uid, $compId, trim((string)($_POST['target_role_title'] ?? 'کارشناس ارشد صادرات')), $cur, $tar, (string)($_POST['priority'] ?? 'مهم'), $rec]
                );
                Auth::audit('TNA', 'COMPETENCY_ASSESSMENT_SAVED', 'competency', $compId, ['gap' => $gap]);
                $this->flash('success', 'ارزیابی ماتریس شایستگی و محاسبه شکاف ذخیره گردید.');
                $this->redirect('competency');
            }

            if ($action === 'propose_course') {
                $title = trim((string)$_POST['proposed_title']);
                $problem = trim((string)($_POST['business_problem'] ?? ''));
                $ai = AvalAiService::generate(
                    "پیشنهاد دوره آموزشی جدید توسط دانش‌پذیر آدان: «{$title}». چالش کسب‌وکار: {$problem}. امکان‌سنجی، مخاطبان و سرفصل پیشنهادی را بنویس.",
                    'Competency TNA'
                );
                $id = Database::insert(
                    'INSERT INTO course_proposals (user_id, org_id, proposed_title, target_audience, estimated_learners, business_problem, status, ai_analysis_note)
                     VALUES (?, ?, ?, ?, ?, ?, "ai_analyzed", ?)',
                    [
                        Auth::id(),
                        Auth::user()['org_id'] ?? null,
                        $title,
                        trim((string)($_POST['target_audience'] ?? 'کارشناسان بنگاه‌های عضو')),
                        (int)($_POST['estimated_learners'] ?? 20),
                        $problem,
                        mb_substr($ai['content'], 0, 900),
                    ]
                );
                Auth::audit('TNA', 'COURSE_PROPOSAL_SUBMITTED', 'proposal', $id, ['title' => $title]);
                $this->flash('success', 'پیشنهاد دوره ثبت و تحلیل اولیه هوش مصنوعی (AI) روی آن الصاق شد.');
                $this->redirect('competency');
            }

            if ($action === 'review_proposal' && Auth::hasRole(['super_admin', 'training_expert'])) {
                $pid = (int)$_POST['proposal_id'];
                $st = (string)$_POST['status'];
                Database::execute('UPDATE course_proposals SET status = ?, reviewer_comment = ? WHERE id = ?', [$st, trim((string)$_POST['reviewer_comment']), $pid]);
                $this->flash('success', 'نظر کارشناسی بر روی پیشنهاد دوره ثبت شد.');
                $this->redirect('competency');
            }

            if ($action === 'run_ai_gap_summary') {
                $rows = Database::fetchAll(
                    'SELECT ca.*, c.title AS comp_title, u.full_name
                     FROM competency_assessments ca
                     JOIN competencies c ON c.id = ca.competency_id
                     JOIN users u ON u.id = ca.user_id'
                );
                $summaryInput = implode(' | ', array_map(
                    static fn($r) => "{$r['full_name']} در «{$r['comp_title']}»: فعلی {$r['current_level']} از هدف {$r['target_level']}",
                    $rows
                ));
                $aiReport = AvalAiService::generate(
                    'بر اساس داده‌های ماتریس شکاف شایستگی واحد آموزش مؤسسه آموزشی آدان: ' . $summaryInput . ' نقشه اولویت آموزشی فصل آینده را تدوین کن.',
                    'Competency TNA'
                );
            }
        }

        $competencies = Database::fetchAll(
            'SELECT comp.*, c.title AS course_title, c.code AS course_code
             FROM competencies comp
             LEFT JOIN courses c ON c.id = comp.recommended_course_id
             ORDER BY comp.id ASC'
        );
        // ★ v26.6 — حریم داده در ماتریس شایستگی: فراگیر فقط ارزیابی‌ها و پیشنهاد خودش را می‌بیند
        $isLearnerTna = Auth::role() === 'learner';
        $meTna = (int)Auth::id();

        $matrix = Database::fetchAllSafe(
            'SELECT ca.*, u.full_name, comp.title AS comp_title, comp.domain, comp.weight, c.title AS rec_course
             FROM competency_assessments ca
             JOIN users u ON u.id = ca.user_id
             JOIN competencies comp ON comp.id = ca.competency_id
             LEFT JOIN courses c ON c.id = comp.recommended_course_id'
            . ($isLearnerTna ? ' WHERE ca.user_id = ?' : '') . '
             ORDER BY (ca.target_level - ca.current_level) * comp.weight DESC',
            $isLearnerTna ? [$meTna] : []
        );
        $proposals = Database::fetchAllSafe(
            'SELECT cp.*, u.full_name, o.name AS org_name
             FROM course_proposals cp
             JOIN users u ON u.id = cp.user_id
             LEFT JOIN organizations o ON o.id = cp.org_id'
            . ($isLearnerTna ? ' WHERE cp.user_id = ?' : '') . '
             ORDER BY cp.id DESC',
            $isLearnerTna ? [$meTna] : []
        );
        $users = $isLearnerTna ? [] : Database::fetchAll("SELECT id, full_name, job_title FROM users ORDER BY id ASC");

        // رادار مهارت نیز برای فراگیر قفل روی پروفایل خودش است (جلوگیری از خواندن پروفایل دیگران با ?radar_user=)
        $radarUser = $isLearnerTna ? $meTna : (int)($_GET['radar_user'] ?? 0);
        $this->render('competency/index', [
            'pageTitle' => 'نیازسنجی آموزشی، بانک شایستگی و تحلیل شکاف هوشمند',
            'competencies' => $competencies,
            'matrix' => $matrix,
            'proposals' => $proposals,
            'users' => $users,
            'aiReport' => $aiReport,
            'radarUser' => $radarUser,
            'radar' => \App\Models\AnalyticsModel::buildCompetencyRadarSvgData(160, 150, 105, $radarUser),
        ]);
    }
}
