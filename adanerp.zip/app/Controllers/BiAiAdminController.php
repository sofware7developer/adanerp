<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Services\AvalAiService;
use App\Services\EnterpriseBiStudioService;

final class BiAiAdminController extends Controller
{
    public function reports(): void
    {
        $u = Auth::user();
        $actor = (string)($u['full_name'] ?? 'مدیرکل آموزش');
        $activeTab = trim((string)($_GET['tab'] ?? 'dashboards'));
        $dashboardId = max(1, (int)($_GET['dashboard_id'] ?? 1));

        // پشتیبانی هم‌زمان از پارامترهای جدید semantic و پارامترهای قبلی dataset
        $legacyMap = [
            'courses_summary'     => ['dataset_key' => 'courses_mart',  'dimension_field' => 'level',        'metric_field' => 'tuition_rial',        'agg_func' => 'SUM'],
            'crm_pipeline'        => ['dataset_key' => 'crm_mart',      'dimension_field' => 'stage',        'metric_field' => 'estimated_value_rial','agg_func' => 'SUM'],
            'finance_ledger'      => ['dataset_key' => 'invoices_mart', 'dimension_field' => 'status',       'metric_field' => 'total_rial',          'agg_func' => 'SUM'],
            'vouchers_4level'     => ['dataset_key' => 'vouchers_mart', 'dimension_field' => 'kol_account',  'metric_field' => 'debit_rial',          'agg_func' => 'SUM'],
        ];
        $legacyKey = (string)($_GET['dataset'] ?? '');
        $defaultSpec = $legacyMap[$legacyKey] ?? [
            'dataset_key'     => (string)($_GET['dataset_key'] ?? 'courses_mart'),
            'dimension_field' => (string)($_GET['dimension_field'] ?? 'level'),
            'metric_field'    => (string)($_GET['metric_field'] ?? 'tuition_rial'),
            'agg_func'        => (string)($_GET['agg_func'] ?? 'SUM'),
            'filter_field'    => (string)($_GET['filter_field'] ?? ''),
            'filter_op'       => (string)($_GET['filter_op'] ?? '='),
            'filter_val'      => (string)($_GET['filter_val'] ?? ''),
            'sort_dir'        => (string)($_GET['sort_dir'] ?? 'DESC'),
            'row_limit'       => (int)($_GET['row_limit'] ?? 25),
            'chart_type'      => (string)($_GET['chart_type'] ?? 'bar'),
        ];

        // خروجی فوری CSV سازگار با اکسل فارسی (UTF-8 BOM) یا JSON
        if (isset($_GET['export'])) {
            $qRes = EnterpriseBiStudioService::executeSemanticQuery($defaultSpec);
            if ($_GET['export'] === 'json') {
                $this->json($qRes);
            }
            $csvRows = [];
            foreach ($qRes['rows'] as $r) {
                $csvRows[] = [
                    'رتبه'       => $r['rank'],
                    $qRes['dimension_label'] => $r['label'],
                    $qRes['metric_label']    => $r['value'],
                    'تعداد رکورد'            => $r['records_cnt'],
                    'سهم درصدی'              => $r['share_pct'] . '%',
                ];
            }
            $headers = !empty($csvRows) ? array_keys($csvRows[0]) : ['ردیف', 'عنوان', 'مقدار'];
            $this->exportCsv('chamber_bi_' . $qRes['dataset_key'] . '.csv', $headers, $csvRows);
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $action = (string)($_POST['action'] ?? '');

            if ($action === 'create_dashboard') {
                $res = EnterpriseBiStudioService::createDashboard($_POST, $actor, true);
                $this->redirect('bi?tab=dashboards&dashboard_id=' . $res['id'], 'داشبورد جدید به همراه ویجت‌های تحلیلی زنده ساخته شد و آماده چیدمان است.');
            }

            if ($action === 'add_widget') {
                $targetBoard = max(1, (int)($_POST['dashboard_id'] ?? $dashboardId));
                $res = EnterpriseBiStudioService::addWidgetToDashboard($targetBoard, $_POST);
                $this->redirect('bi?tab=dashboards&dashboard_id=' . $targetBoard, 'ویجت تحلیلی جدید (' . $res['widget_code'] . ') به داشبورد اضافه شد.');
            }

            if ($action === 'delete_widget') {
                $targetBoard = max(1, (int)($_POST['dashboard_id'] ?? $dashboardId));
                EnterpriseBiStudioService::deleteWidget((int)($_POST['widget_id'] ?? 0));
                $this->redirect('bi?tab=dashboards&dashboard_id=' . $targetBoard, 'ویجت انتخاب‌شده از صفحه داشبورد حذف شد.');
            }

            if ($action === 'save_custom_report' || $action === 'save_report_with_ai') {
                $res = EnterpriseBiStudioService::saveCustomReport($_POST, $actor);
                $this->redirect(
                    'bi?tab=builder&dataset_key=' . urlencode($res['query']['dataset_key'])
                    . '&dimension_field=' . urlencode($res['query']['dimension_field'])
                    . '&metric_field=' . urlencode($res['query']['metric_field'])
                    . '&agg_func=' . urlencode($res['query']['agg_func'])
                    . '&chart_type=' . urlencode($res['query']['chart_type']),
                    'گزارش تحلیلی با کد «' . $res['report_code'] . '» ذخیره شد و روایت مدیریتی AI برای آن ثبت گردید.'
                );
            }

            if ($action === 'nl_or_voice_build') {
                $mode = ($_POST['build_mode'] ?? 'text') === 'voice' ? 'voice' : 'text';
                $prompt = trim((string)($_POST['natural_prompt'] ?? ''));
                $res = EnterpriseBiStudioService::compileNaturalLanguageOrVoice($prompt, $mode, $dashboardId, $actor, true);
                if (($res['intent'] ?? '') === 'dashboard_created') {
                    $this->redirect('bi?tab=dashboards&dashboard_id=' . (int)$res['dashboard_id'], $res['spoken_text']);
                }
                if (($res['intent'] ?? '') === 'goal_created') {
                    $this->redirect('bi?tab=goals', $res['spoken_text']);
                }
                if (($res['intent'] ?? '') === 'widget_pinned') {
                    $this->redirect('bi?tab=dashboards&dashboard_id=' . $dashboardId, 'ویجت درخواستی ساخته شد و مستقیماً روی داشبورد قرار گرفت.');
                }
                $q = $res['query'];
                $this->redirect(
                    'bi?tab=builder&dataset_key=' . urlencode($q['dataset_key'])
                    . '&dimension_field=' . urlencode($q['dimension_field'])
                    . '&metric_field=' . urlencode($q['metric_field'])
                    . '&agg_func=' . urlencode($q['agg_func'])
                    . '&chart_type=' . urlencode($q['chart_type']),
                    $res['spoken_text']
                );
            }

            if ($action === 'create_goal') {
                $res = EnterpriseBiStudioService::createGoal($_POST);
                $this->redirect('bi?tab=goals', 'هدف راهبردی جدید با کد «' . $res['goal_code'] . '» ثبت شد و به شاخص زنده متصل گردید.');
            }

            if ($action === 'checkin_goal') {
                EnterpriseBiStudioService::checkInGoalProgress(
                    (int)($_POST['goal_id'] ?? 1),
                    (float)($_POST['progress_delta'] ?? 0),
                    (string)($_POST['progress_note'] ?? '')
                );
                $this->redirect('bi?tab=goals', 'پیشرفت دوره‌ای جدید ثبت شد و درصد تحقق هدف بروزرسانی گردید.');
            }

            if ($action === 'save_whatif') {
                $res = EnterpriseBiStudioService::saveWhatIfScenario($_POST, $actor);
                $this->redirect('bi?tab=whatif', 'سناریوی پیش‌بینی «' . $res['scenario_code'] . '» در آرشیو تحلیل حساسیت ذخیره شد.');
            }

            if ($action === 'save_schedule') {
                $res = EnterpriseBiStudioService::saveReportSchedule($_POST);
                $this->redirect('bi?tab=whatif', 'زمان‌بندی ارسال خودکار گزارش (' . $res['schedule_code'] . ') ثبت و فعال شد.');
            }
        }

        $workspace = EnterpriseBiStudioService::getFullStudioWorkspace($dashboardId, $defaultSpec);

        $this->render('bi/reports', [
            'pageTitle'   => 'سامانه جامع هوش تجاری (BI)، گزارش‌ساز، داشبوردساز و هدف‌گذاری راهبردی',
            'activeTab'   => $activeTab,
            'dashboardId' => (int)$workspace['active_dashboard']['id'],
            'workspace'   => $workspace,
        ]);
    }

    /**
     * نسخه چاپی رسمی A4 داشبورد مدیریتی و گزارش تحلیلی به همراه نمودار برداری و رمزینه QR
     */
    public function biReportPrint(): void
    {
        $dashboardId = max(1, (int)($_GET['dashboard_id'] ?? 1));
        $spec = [
            'dataset_key'     => (string)($_GET['dataset_key'] ?? 'courses_mart'),
            'dimension_field' => (string)($_GET['dimension_field'] ?? 'level'),
            'metric_field'    => (string)($_GET['metric_field'] ?? 'tuition_rial'),
            'agg_func'        => (string)($_GET['agg_func'] ?? 'SUM'),
            'chart_type'      => (string)($_GET['chart_type'] ?? 'bar'),
        ];
        $workspace = EnterpriseBiStudioService::getFullStudioWorkspace($dashboardId, $spec);
        $this->render('bi/bi_report_print', [
            'pageTitle' => 'گزارش چاپی رسمی هوش تجاری و شاخص‌های کلیدی عملکرد',
            'workspace' => $workspace,
        ], 'public');
    }

    /**
     * وب‌سرویس بلادرنگ JSON برای گزارش‌ساز بدون رفرش، درگ‌انددراپ ویجت‌ها و فرمان متنی/صوتی
     */
    public function biStudioApi(): void
    {
        $raw = json_decode((string)file_get_contents('php://input'), true);
        $payload = is_array($raw) ? $raw : $_POST;
        $u = Auth::user();
        $actor = (string)($u['full_name'] ?? 'کاربر سامانه');
        $op = (string)($payload['op'] ?? 'query');

        if ($op === 'nl_voice') {
            $res = EnterpriseBiStudioService::compileNaturalLanguageOrVoice(
                (string)($payload['prompt'] ?? ''),
                ($payload['mode'] ?? 'text') === 'voice' ? 'voice' : 'text',
                max(1, (int)($payload['dashboard_id'] ?? 1)),
                $actor,
                !empty($payload['persist'])
            );
            $this->json($res);
        }

        if ($op === 'reorder_widgets') {
            $res = EnterpriseBiStudioService::saveDashboardWidgetLayout(
                (array)($payload['ordered_ids'] ?? []),
                (array)($payload['updates'] ?? [])
            );
            $this->json($res);
        }

        if ($op === 'drop_new_widget') {
            $boardId = max(1, (int)($payload['dashboard_id'] ?? 1));
            $added = EnterpriseBiStudioService::addWidgetToDashboard($boardId, $payload);
            $widgetRow = Database::fetchOne('SELECT * FROM bi_dashboard_widgets WHERE id = ?', [$added['id']]);
            if ($widgetRow) {
                $widgetRow['live_data'] = EnterpriseBiStudioService::executeSemanticQuery($widgetRow);
            }
            $this->json(['ok' => true, 'widget' => $widgetRow]);
        }

        if ($op === 'drop_new_goal') {
            $g = EnterpriseBiStudioService::createGoal($payload);
            $this->json(['ok' => true, 'goal' => $g, 'goals' => EnterpriseBiStudioService::getEnrichedGoals()]);
        }

        $qRes = EnterpriseBiStudioService::executeSemanticQuery($payload);
        $this->json(['ok' => true, 'query' => $qRes]);
    }

    public function aiGovernance(): void
    {
        $pingResult = null;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $action = (string)($_POST['action'] ?? '');

            if ($action === 'save_gateway') {
                Database::saveSetting('active_ai_provider', (string)($_POST['active_ai_provider'] ?? 'ai'), 'ai');
                Database::saveSetting('ai_base_url', trim((string)($_POST['ai_base_url'] ?? $_POST['avalai_base_url'] ?? 'https://api.openai.com/v1')), 'ai');
                Database::saveSetting('ai_default_model', trim((string)($_POST['ai_default_model'] ?? $_POST['avalai_default_model'] ?? 'gpt-4o-mini')), 'ai');
                Database::saveSetting('ollama_base_url', trim((string)($_POST['ollama_base_url'] ?? 'http://127.0.0.1:11434/v1')), 'ai');

                $newKey = trim((string)($_POST['ai_api_key'] ?? $_POST['avalai_api_key'] ?? ''));
                if ($newKey !== '' && !str_contains($newKey, '••••')) {
                    Database::saveSetting('ai_api_key', $newKey, 'ai');
                }
                Auth::audit('AI_GOVERNANCE', 'GATEWAY_SETTINGS_UPDATED', 'settings', null, ['provider' => $_POST['active_ai_provider'] ?? 'ai']);
                $this->flash('success', 'تنظیمات درگاه AI (سمت سرور) با موفقیت ذخیره شد.');
                $this->redirect('ai-governance');
            }

            if ($action === 'test_live_ai') {
                $pingResult = AvalAiService::generate('سلام! در یک جمله کوتاه آمادگی دروازه هوشمند واحد آموزش مؤسسه آموزشی آدان را اعلام کن.', 'Gateway Ping Test');
            }

            if ($action === 'save_prompt_template') {
                Database::execute(
                    'INSERT INTO ai_prompts (prompt_key, title, model_name, system_prompt, daily_token_quota)
                     VALUES (?, ?, ?, ?, ?)
                     ON DUPLICATE KEY UPDATE title = VALUES(title), model_name = VALUES(model_name), system_prompt = VALUES(system_prompt), daily_token_quota = VALUES(daily_token_quota)',
                    [
                        strtoupper(trim((string)$_POST['prompt_key'])),
                        trim((string)$_POST['title']),
                        trim((string)$_POST['model_name']),
                        trim((string)$_POST['system_prompt']),
                        (int)$_POST['daily_token_quota'],
                    ]
                );
                $this->flash('success', 'پرامپت سازمانی و سقف سهمیه روزانه توکن ذخیره شد.');
                $this->redirect('ai-governance');
            }

            if ($action === 'add_rag_doc') {
                Database::insert(
                    'INSERT INTO rag_documents (title, category, keywords, chunk_text) VALUES (?, ?, ?, ?)',
                    [
                        trim((string)$_POST['title']),
                        trim((string)$_POST['category']),
                        trim((string)$_POST['keywords']),
                        trim((string)$_POST['chunk_text']),
                    ]
                );
                $this->flash('success', 'سند دانشی جدید به مخزن RAG همراه هوشمند اضافه شد.');
                $this->redirect('ai-governance');
            }

            if ($action === 'add_webhook') {
                $name = trim((string)($_POST['name'] ?? ''));
                $targetUrl = trim((string)($_POST['target_url'] ?? ''));
                $parsedUrl = filter_var($targetUrl, FILTER_VALIDATE_URL) !== false ? parse_url($targetUrl) : false;
                if ($name === '' || !is_array($parsedUrl) || strtolower((string)($parsedUrl['scheme'] ?? '')) !== 'https' || empty($parsedUrl['host'])) {
                    $this->flash('danger', 'نام مقصد و نشانی HTTPS معتبر برای ثبت پیش‌نویس لازم است.');
                    $this->redirect('ai-governance');
                }
                Database::insert(
                    'INSERT INTO webhooks_and_jobs (entry_kind, name, target_url_or_handler, event_trigger, status)
                     VALUES ("webhook", ?, ?, ?, "draft_local")',
                    [$name, $targetUrl, (string)($_POST['event_trigger'] ?? 'enrollment.created')]
                );
                $this->flash('warning', 'پیش‌نویس وب‌هوک ثبت شد؛ هیچ درخواست یا ارسال بیرونی انجام نمی‌شود.');
                $this->redirect('ai-governance');
            }
        }

        $storedKey = Database::setting('ai_api_key', Database::setting('avalai_api_key', ''));
        $maskedKey = $storedKey !== '' ? substr($storedKey, 0, 6) . '••••••••••••' : '';

        $prompts = Database::fetchAll('SELECT * FROM ai_prompts ORDER BY id ASC');
        $usageLogs = Database::fetchAll(
            'SELECT l.*, u.full_name FROM ai_usage_logs l LEFT JOIN users u ON u.id = l.user_id ORDER BY l.id DESC LIMIT 12'
        );
        $ragDocs = Database::fetchAll('SELECT * FROM rag_documents ORDER BY id DESC');
        $webhooks = Database::fetchAll('SELECT * FROM webhooks_and_jobs ORDER BY id DESC');
        $costByModule = Database::fetchAll(
            'SELECT module_name, COUNT(*) AS calls_cnt, SUM(prompt_tokens + completion_tokens) AS total_tokens
             FROM ai_usage_logs GROUP BY module_name ORDER BY total_tokens DESC'
        );

        $this->render('bi/ai_governance', [
            'pageTitle' => 'تنظیمات درگاه هوش مصنوعی (AI)، حسابداری توکن، پرامپت، RAG و وب‌هوک',
            'provider' => Database::setting('active_ai_provider', 'ai'),
            'aiUrl' => Database::setting('ai_base_url', Database::setting('avalai_base_url', 'https://api.openai.com/v1')),
            'aiModel' => Database::setting('ai_default_model', Database::setting('avalai_default_model', 'gpt-4o-mini')),
            'ollamaUrl' => Database::setting('ollama_base_url', 'http://127.0.0.1:11434/v1'),
            'hasLiveKey' => $storedKey !== '',
            'maskedKey' => $maskedKey,
            'prompts' => $prompts,
            'usageLogs' => $usageLogs,
            'costByModule' => $costByModule,
            'ragDocs' => $ragDocs,
            'webhooks' => $webhooks,
            'pingResult' => $pingResult,
            'readinessMatrix' => \App\Models\AnalyticsModel::getIntegrationReadiness(),
        ]);
    }
}
