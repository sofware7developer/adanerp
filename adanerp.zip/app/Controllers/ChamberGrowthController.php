<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Core\Jalali;

final class ChamberGrowthController extends Controller
{
    // تضمین کیفیت، ممیزی استاندارد ISO 21001 / ISO 10015 و CAPA
    public function isoQa(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'add_qa_record') {
            Database::insert(
                'INSERT INTO iso_qa_records (standard_code, clause_title, finding_type, capa_action, owner_unit, status, audit_shamsi)
                 VALUES (?, ?, ?, ?, ?, "اقدام اصلاحی انجام شد", ?)',
                [
                    (string)$_POST['standard_code'],
                    trim((string)$_POST['clause_title']),
                    (string)$_POST['finding_type'],
                    trim((string)$_POST['capa_action']),
                    trim((string)$_POST['owner_unit']),
                    Jalali::today(),
                ]
            );
            $this->flash('success', 'پرونده ممیزی استاندارد ایزو و اقدام اصلاحی (CAPA) ثبت شد.');
            $this->redirect('iso-qa');
        }

        $this->render('growth/iso_qa', [
            'pageTitle' => 'تضمین کیفیت آموزش، استاندارد ISO 21001 / ISO 10015 و ممیزی CAPA',
            'records' => Database::fetchAll('SELECT * FROM iso_qa_records ORDER BY id DESC'),
        ]);
    }

    // بازارگاه اشتغال تخصصی و همرسانی نیروی ماهر به صنایع عضو
    public function jobBoard(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $action = (string)($_POST['action'] ?? '');

            if ($action === 'post_job') {
                Database::insert(
                    'INSERT INTO job_board_listings (org_name, job_title, required_cert_code, city, salary_range, matched_candidates, posted_shamsi)
                     VALUES (?, ?, ?, ?, ?, ?, ?)',
                    [
                        trim((string)$_POST['org_name']),
                        trim((string)$_POST['job_title']),
                        trim((string)$_POST['required_cert_code']),
                        trim((string)$_POST['city']),
                        trim((string)$_POST['salary_range']),
                        rand(2, 8),
                        Jalali::today(),
                    ]
                );
                $this->flash('success', 'فرصت شغلی جدید ثبت و به دانش‌آموختگان دارای گواهی مرتبط معرفی شد.');
                $this->redirect('job-board');
            }

            if ($action === 'apply_job') {
                Database::execute('UPDATE job_board_listings SET matched_candidates = matched_candidates + 1 WHERE id = ?', [(int)$_POST['job_id']]);
                $this->flash('success', 'گذرنامه مهارت و گواهی‌نامه‌های اتاق شما برای کارفرمای عضو ارسال گردید.');
                $this->redirect('job-board');
            }

            if ($action === 'ai_cv_interview') {
                $res = \App\Services\DeepModuleSuiteService::matchCvAndGenerateInterview(
                    (string)($_POST['candidate_name'] ?? 'مهندس نیما فرهادی'),
                    (string)($_POST['target_company'] ?? 'مجتمع پتروشیمی استان'),
                    (string)($_POST['target_role'] ?? 'کارشناس صادرات و اعتبارات اسنادی'),
                    (string)($_POST['verified_certs_summary'] ?? 'گواهی Incoterms 2020 + UCP600')
                );
                $this->redirect('job-board', 'تطبیق برداری رزومه و راهنمای مصاحبه تخصصی صادر شد (' . $res['match_code'] . ' — تشابه مهارتی: ' . $res['similarity_pct'] . '٪).');
            }
        }

        $this->render('growth/job_board', [
            'pageTitle' => 'بازارگاه اشتغال تخصصی، تطبیق برداری رزومه و راهنمای مصاحبه هوشمند',
            'jobs' => Database::fetchAll('SELECT * FROM job_board_listings ORDER BY id DESC'),
            'cvMatches' => Database::fetchAll('SELECT * FROM ai_cv_match_interviews ORDER BY id DESC'),
        ]);
    }

    // مدیریت تفاهم‌نامه‌ها (MoU)، یارانه‌های آموزشی SMEها و اسپانسرینگ
    public function grantsMou(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'create_grant') {
            Database::insert(
                'INSERT INTO grants_and_mous (record_category, partner_organization, title, subsidy_percent, allocated_budget_rial, utilized_rial, expiry_shamsi)
                 VALUES (?, ?, ?, ?, ?, 0, ?)',
                [
                    (string)$_POST['record_category'],
                    trim((string)$_POST['partner_organization']),
                    trim((string)$_POST['title']),
                    (int)$_POST['subsidy_percent'],
                    (int)$_POST['allocated_budget_rial'],
                    trim((string)$_POST['expiry_shamsi']),
                ]
            );
            $this->flash('success', 'ردیف جدید یارانه آموزشی / تفاهم‌نامه مشترک ثبت گردید.');
            $this->redirect('grants-mou');
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'score_sme_subsidy') {
            $res = \App\Services\DeepModuleSuiteService::evaluateSmeSubsidyAllocation(
                (string)($_POST['sme_company_name'] ?? 'واحد صنعتی متقاضی'),
                (int)($_POST['employees_count'] ?? 40),
                (int)($_POST['export_readiness_idx'] ?? 75),
                (int)($_POST['requested_subsidy_pct'] ?? 45)
            );
            $this->redirect('grants-mou', 'تخصیص هوشمند یارانه SME محاسبه شد: سهم مصوب ' . $res['approved_pct'] . '٪ (ضریب بازگشت اقتصادی: ' . $res['roi_multiplier'] . ' برابر).');
        }

        $this->render('growth/grants_mou', [
            'pageTitle' => 'تفاهم‌نامه‌ها (MoU)، بهینه‌ساز هوشمند یارانه‌های SME و حامیان مالی',
            'items' => Database::fetchAll('SELECT * FROM grants_and_mous ORDER BY id DESC'),
            'allocations' => Database::fetchAll('SELECT * FROM sme_subsidy_allocations ORDER BY economic_roi_multiplier DESC'),
        ]);
    }

    // باشگاه دانش‌آموختگان و سازنده هوشمند کنسرسیوم‌های صادراتی سه‌جانبه
    public function alumniClub(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'build_consortium') {
            $res = \App\Services\DeepModuleSuiteService::buildExportConsortium(
                (string)($_POST['target_market'] ?? 'اتحادیه اوراسیا و روسیه'),
                (string)($_POST['hs_cluster'] ?? 'HS 0802 / صنایع غذایی و خشکبار'),
                (string)($_POST['lead_org'] ?? 'مجتمع کشت و صنعت نمونه استان')
            );
            $this->redirect('alumni-club', 'کنسرسیوم صادراتی سه‌جانبه با کد «' . $res['consortium_code'] . '» و هم‌افزایی ' . $res['synergy_pct'] . '٪ تشکیل شد.');
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'post_collaboration') {
            Database::insert(
                'INSERT INTO alumni_network_posts (author_name, company_and_role, graduated_course, collaboration_type, proposal_body, responses_count, posted_shamsi)
                 VALUES (?, ?, ?, ?, ?, 1, ?)',
                [
                    Auth::user()['full_name'] ?? 'عضو باشگاه دانش‌آموختگان',
                    trim((string)$_POST['company_and_role']),
                    trim((string)$_POST['graduated_course']),
                    (string)$_POST['collaboration_type'],
                    trim((string)$_POST['proposal_body']),
                    Jalali::today(),
                ]
            );
            $this->flash('success', 'پیشنهاد همکاری تجاری در باشگاه دانش‌آموختگان اتاق منتشر شد.');
            $this->redirect('alumni-club');
        }

        $this->render('growth/alumni_club', [
            'pageTitle' => 'باشگاه دانش‌آموختگان اتاق و سازنده هوشمند کنسرسیوم‌های صادراتی',
            'posts' => Database::fetchAll('SELECT * FROM alumni_network_posts ORDER BY id DESC'),
            'consortiums' => Database::fetchAll('SELECT * FROM export_consortium_groups ORDER BY id DESC'),
        ]);
    }
}
