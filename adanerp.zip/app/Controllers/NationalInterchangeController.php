<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Services\DeepModuleSuiteService;

final class NationalInterchangeController extends Controller
{
    public function index(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'preview_identifier') {
            $systemType = (string)($_POST['system_type'] ?? '');
            if (!in_array($systemType, ['NTSW', 'SSAA', 'EPL'], true)) {
                $this->flash('danger', 'قالب انتخاب‌شده برای پیش‌نمایش محلی معتبر نیست.');
                $this->redirect('national-interchange');
            }
            $res = DeepModuleSuiteService::previewNationalIdentifier(
                $systemType,
                (string)($_POST['identifier'] ?? '')
            );
            $this->redirect(
                'national-interchange',
                'پیش‌نمایش محلی ثبت شد (' . $res['trace_code'] . '): ' . $res['summary']
            );
        }

        $inquiries = Database::fetchAll('SELECT * FROM national_bus_inquiries ORDER BY id DESC LIMIT 15');
        $blocks = Database::fetchAll('SELECT * FROM verifiable_credential_blocks ORDER BY id DESC LIMIT 6');

        $this->render('statutory/national_interchange', [
            'pageTitle' => 'پیش‌نمایش اعتبارسنجی محلی شناسه‌ها و آماده‌سازی اتصال‌های ملی',
            'inquiries' => $inquiries,
            'blocks' => $blocks,
        ]);
    }
}
