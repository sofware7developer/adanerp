<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Services\MarketRadarService;
use App\Services\WowEnterpriseSuiteService;

final class MarketRadarController extends Controller
{
    public function index(): void
    {
        $this->requireRole(['super_admin', 'training_expert', 'crm_manager', 'finance_manager']);

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();
            $action = $_POST['action'] ?? '';

            if (in_array($action, ['launch_closed_loop_gtm', 'launch_to_tms'], true)) {
                $this->requireRole(['super_admin', 'training_expert', 'crm_manager'], 'market-radar');
            }

            if ($action === 'launch_closed_loop_gtm') {
                $topic = trim($_POST['topic_title'] ?? 'هوش مصنوعی در صادرات و لجستیک بین‌الملل');
                $tuition = max(20000000, (int)($_POST['suggested_tuition_rial'] ?? 56000000));
                $persona = trim($_POST['target_persona'] ?? 'مدیران صادرات و بازرگانی خارجی');
                $res = WowEnterpriseSuiteService::executeFullGoToMarketFromResearch($topic, $tuition, $persona, (int)Auth::id());
                $this->flash(
                    'success',
                    'چرخه بسته ورود به بازار (GTM) با ۱ کلیک اجرا شد: دوره «' . $res['course_title'] . '» (' . $res['course_code'] . ') در TMS، '
                    . $res['lessons_created'] . ' درس تعاملی در LMS و ' . $res['social_posts_created'] . ' پیش‌نویس کمپین ایجاد شد؛ انتشار در شبکه‌های اجتماعی متصل نیست.'
                );
                $this->redirect('market-radar');
            }

            if ($action === 'save_survey_insight') {
                $title = trim((string)($_POST['survey_title'] ?? ''));
                $sector = trim((string)($_POST['industry_sector'] ?? ''));
                $channel = trim((string)($_POST['survey_source'] ?? ''));
                $sampleSize = filter_var($_POST['sample_size_orgs'] ?? null, FILTER_VALIDATE_INT);
                $urgency = filter_var($_POST['demand_urgency_pct'] ?? null, FILTER_VALIDATE_INT);
                $sentiment = filter_var($_POST['positive_sentiment_pct'] ?? null, FILTER_VALIDATE_INT);
                $tam = filter_var($_POST['tam_learners'] ?? null, FILTER_VALIDATE_INT);
                $sam = filter_var($_POST['sam_learners'] ?? null, FILTER_VALIDATE_INT);
                $som = filter_var($_POST['som_learners'] ?? null, FILTER_VALIDATE_INT);
                $wtp = filter_var($_POST['avg_willingness_to_pay_rial'] ?? null, FILTER_VALIDATE_INT);
                $skill = trim((string)($_POST['top_requested_skill'] ?? ''));
                $painPoint = trim((string)($_POST['key_pain_point'] ?? ''));
                if (
                    $title === '' || mb_strlen($title, 'UTF-8') > 190
                    || $sector === '' || mb_strlen($sector, 'UTF-8') > 120
                    || $channel === '' || mb_strlen($channel, 'UTF-8') > 90
                    || $sampleSize === false || $sampleSize < 1 || $sampleSize > 100000
                    || $urgency === false || $urgency < 0 || $urgency > 100
                    || $sentiment === false || $sentiment < 0 || $sentiment > 100
                    || $tam === false || $tam < 1 || $tam > 100000000
                    || $sam === false || $sam < 1 || $sam > $tam
                    || $som === false || $som < 1 || $som > $sam
                    || $wtp === false || $wtp < 1 || $wtp > 1000000000
                    || $skill === '' || mb_strlen($skill, 'UTF-8') > 220
                    || $painPoint === '' || mb_strlen($painPoint, 'UTF-8') > 5000
                ) {
                    $this->flash('danger', 'اطلاعات پژوهش را کامل کنید؛ درصدها باید ۰ تا ۱۰۰ و اندازه بازار باید TAM ≥ SAM ≥ SOM باشد.');
                    $this->redirect('market-radar');
                }
                $insCode = 'MKT-' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 5));

                Database::insert(
                    'INSERT INTO market_surveys_insights
                     (insight_code, research_title, industry_segment, social_source, sample_size_orgs, demand_urgency_pct, positive_sentiment_pct, willingness_to_pay_rial, tam_provincial_rial, sam_reachable_rial, som_target_rial, key_pain_point, ai_gtm_strategy, launched_to_tms, created_shamsi)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?)',
                    [
                        $insCode,
                        $title,
                        $sector,
                        $channel,
                        $sampleSize,
                        $urgency,
                        $sentiment,
                        $wtp,
                        $tam * $wtp,
                        $sam * $wtp,
                        $som * $wtp,
                        $painPoint,
                        'مهارت اولویت‌دار: ' . $skill . '؛ کانال پیشنهادی بر پایه ورودی پژوهش: ' . $channel,
                        \App\Core\Jalali::today(),
                    ]
                );
                $this->flash('success', 'پژوهش با اعداد و منبع واردشده ثبت شد؛ صحت منبع بیرونی به‌صورت خودکار تأیید نمی‌شود.');
                $this->redirect('market-radar');
            }

            if ($action === 'save_competitor') {
                $name = trim((string)($_POST['competitor_name'] ?? ''));
                $category = trim((string)($_POST['category'] ?? ''));
                $website = trim((string)($_POST['website_url'] ?? ''));
                $cityScope = trim((string)($_POST['city_scope'] ?? ''));
                $deliveryModel = trim((string)($_POST['delivery_model'] ?? ''));
                $hourlyRateInput = trim((string)($_POST['avg_hourly_rate_rial'] ?? ''));
                $hourlyRate = $hourlyRateInput === '' ? null : filter_var($hourlyRateInput, FILTER_VALIDATE_INT);
                $strengths = trim((string)($_POST['key_strengths'] ?? ''));
                $weaknesses = trim((string)($_POST['key_weaknesses'] ?? ''));
                if (
                    $name === '' || mb_strlen($name, 'UTF-8') > 180
                    || $category === '' || mb_strlen($category, 'UTF-8') > 90
                    || strlen($website) > 255 || !MarketRadarService::isSafePublicUrl($website)
                    || mb_strlen($cityScope, 'UTF-8') > 80
                    || mb_strlen($deliveryModel, 'UTF-8') > 90
                    || mb_strlen($strengths, 'UTF-8') > 5000
                    || mb_strlen($weaknesses, 'UTF-8') > 5000
                    || ($hourlyRate !== null && ($hourlyRate === false || $hourlyRate < 0))
                ) {
                    $this->flash('danger', 'اطلاعات رقیب معتبر نیست؛ نشانی باید یک URL عمومی HTTP/HTTPS باشد.');
                    $this->redirect('market-radar');
                }

                $existing = Database::fetchOne('SELECT id FROM rd_competitors WHERE name = ? ORDER BY id ASC LIMIT 1', [$name]);
                if ($existing) {
                    Database::execute(
                        'UPDATE rd_competitors
                         SET category = ?, website_url = ?, city_scope = ?, avg_hourly_rate_rial = ?,
                             delivery_model = ?, key_strengths = ?, key_weaknesses = ?
                         WHERE id = ?',
                        [$category, $website, $cityScope, $hourlyRate, $deliveryModel, $strengths, $weaknesses, (int)$existing['id']]
                    );
                } else {
                    Database::insert(
                        'INSERT INTO rd_competitors
                         (name, category, website_url, city_scope, avg_hourly_rate_rial, delivery_model, key_strengths, key_weaknesses, last_crawled_at)
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, "پایش نشده")',
                        [$name, $category, $website, $cityScope, $hourlyRate, $deliveryModel, $strengths, $weaknesses]
                    );
                }
                $this->flash('success', 'پروفایل رقیب در فهرست داخلی ذخیره شد؛ اطلاعات آن باید با منبع و تاریخ پایش بررسی شود.');
                $this->redirect('market-radar');
            }

            if ($action === 'save_competitor_course') {
                $competitorId = filter_var($_POST['competitor_id'] ?? null, FILTER_VALIDATE_INT);
                $courseTitle = trim((string)($_POST['course_title'] ?? ''));
                $durationInput = trim((string)($_POST['duration_hours'] ?? ''));
                $tuitionInput = trim((string)($_POST['tuition_rial'] ?? ''));
                $deliveryFormat = trim((string)($_POST['delivery_format'] ?? ''));
                $sourceUrl = trim((string)($_POST['source_url'] ?? ''));
                $duration = $durationInput === '' ? null : filter_var($durationInput, FILTER_VALIDATE_INT);
                $tuition = $tuitionInput === '' ? null : filter_var($tuitionInput, FILTER_VALIDATE_INT);
                if (
                    $competitorId === false || $competitorId < 1
                    || !Database::fetchOne('SELECT id FROM rd_competitors WHERE id = ?', [$competitorId])
                    || $courseTitle === '' || mb_strlen($courseTitle, 'UTF-8') > 220
                    || ($duration !== null && ($duration === false || $duration < 1 || $duration > 1000))
                    || ($tuition !== null && ($tuition === false || $tuition < 1))
                    || mb_strlen($deliveryFormat, 'UTF-8') > 60
                    || strlen($sourceUrl) > 500 || !MarketRadarService::isSafePublicUrl($sourceUrl)
                ) {
                    $this->flash('danger', 'اطلاعات دوره رقیب معتبر نیست؛ منبع باید URL عمومی HTTP/HTTPS و قیمت/مدت در صورت ورود عددی معتبر باشد.');
                    $this->redirect('market-radar');
                }

                $catalogStatus = MarketRadarService::checkCatalogGap($courseTitle);
                $existingCourse = Database::fetchOne(
                    'SELECT id FROM rd_competitor_courses WHERE competitor_id = ? AND course_title = ? LIMIT 1',
                    [$competitorId, $courseTitle]
                );
                if ($existingCourse) {
                    Database::execute(
                        'UPDATE rd_competitor_courses
                         SET duration_hours = ?, tuition_rial = ?, delivery_format = ?, source_url = ?,
                             our_catalog_status = ?, captured_shamsi = ?
                         WHERE id = ?',
                        [$duration, $tuition, $deliveryFormat, $sourceUrl, $catalogStatus, \App\Core\Jalali::today(), (int)$existingCourse['id']]
                    );
                } else {
                    Database::insert(
                        'INSERT INTO rd_competitor_courses
                         (competitor_id, course_title, duration_hours, tuition_rial, delivery_format, source_url, our_catalog_status, captured_shamsi)
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                        [$competitorId, $courseTitle, $duration, $tuition, $deliveryFormat, $sourceUrl, $catalogStatus, \App\Core\Jalali::today()]
                    );
                }
                $this->flash('success', 'دوره رقیب همراه با منبع و داده‌های واردشده ثبت شد؛ مقادیر قیمت/مدت خالی به‌عنوان نامشخص باقی می‌مانند.');
                $this->redirect('market-radar');
            }

            if ($action === 'scan_live_web') {
                $kw = trim((string)($_POST['keyword_query'] ?? ''));
                if ($kw === '' || mb_strlen($kw, 'UTF-8') > 160) {
                    $this->flash('danger', 'عبارت پایش وب را وارد کنید؛ حداکثر طول آن ۱۶۰ نویسه است.');
                    $this->redirect('market-radar');
                }
                $res = MarketRadarService::scanLiveWebDemand($kw);
                $this->flash(
                    ($res['mode'] ?? '') === 'live_web' ? 'success' : 'warning',
                    ($res['mode'] ?? '') === 'live_web'
                        ? 'کاوش زنده روندهای بازار انجام شد (' . ($res['discovered_count'] ?? 0) . ' سیگنال تحلیل گردید).'
                        : 'این سرور به وب زنده دسترسی نداشت؛ نتیجهٔ جایگزین محلی ثبت شد.'
                );
                $this->redirect('market-radar');
            }

            if ($action === 'crawl_competitor') {
                $competitorName = trim((string)($_POST['competitor_name'] ?? ''));
                $url = trim($_POST['website_url'] ?? '');
                if (
                    $competitorName === '' || mb_strlen($competitorName, 'UTF-8') > 180
                    || strlen($url) > 255 || !MarketRadarService::isSafePublicUrl($url)
                ) {
                    $this->flash('danger', 'نام رقیب یا نشانی وب معتبر نیست؛ خزش فقط برای نشانی عمومی HTTP/HTTPS انجام می‌شود.');
                    $this->redirect('market-radar');
                }

                $competitor = Database::fetchOne(
                    'SELECT id FROM rd_competitors WHERE name = ? ORDER BY id ASC LIMIT 1',
                    [$competitorName]
                );
                if ($competitor) {
                    $compId = (int)$competitor['id'];
                    Database::execute('UPDATE rd_competitors SET website_url = ? WHERE id = ?', [$url, $compId]);
                } else {
                    $compId = Database::insert(
                        'INSERT INTO rd_competitors (name, category, website_url, avg_hourly_rate_rial, last_crawled_at)
                         VALUES (?, "موسسه آموزشی", ?, NULL, "پایش نشده")',
                        [$competitorName, $url]
                    );
                }

                $res = MarketRadarService::crawlCompetitorWebsite($compId, $url);
                if (empty($res['ok'])) {
                    $this->flash('danger', $res['error'] ?? 'خزش وب‌سایت رقیب انجام نشد.');
                } elseif ((int)($res['courses_extracted'] ?? 0) === 0) {
                    $this->flash('warning', 'صفحه دریافت شد، اما عنوان دوره‌ای از آن استخراج نشد.');
                } else {
                    $this->flash('success', 'وب‌سایت رقیب با موفقیت خزش شد (' . $res['courses_extracted'] . ' عنوان دوره تحلیل گردید).');
                }
                $this->redirect('market-radar');
            }

            if ($action === 'generate_ai_recommendations') {
                $topic = trim($_POST['topic_focus'] ?? 'هوش مصنوعی در صادرات، تهاتر ارزی و لجستیک بین‌الملل');
                MarketRadarService::generateAiRdProposal($topic, 24);
                $this->flash('success', 'پیشنهادهای جدید اقیانوس آبی با هوش مصنوعی تولید شد.');
                $this->redirect('market-radar');
            }

            if ($action === 'launch_to_tms') {
                $propId = (int)($_POST['proposal_id'] ?? 0);
                if ($propId > 0) {
                    $res = MarketRadarService::approveAndLaunchToTms($propId, (int)Auth::id());
                    if (!empty($res['ok'])) {
                        $this->flash(
                            'success',
                            'پیشنهاد تحقیق و توسعه به دوره TMS و ' . (int)($res['lessons_created'] ?? 0) . ' درس LMS تبدیل شد.'
                        );
                    } else {
                        $this->flash('danger', $res['error'] ?? 'انتشار پیشنهاد در TMS انجام نشد.');
                    }
                } else {
                    $this->flash('danger', 'پیشنهاد معتبر برای انتشار انتخاب نشده است.');
                }
                $this->redirect('market-radar');
            }
        }

        $signals = Database::fetchAll('SELECT * FROM rd_web_signals ORDER BY demand_score DESC, id DESC LIMIT 30');
        $competitors = Database::fetchAll('SELECT * FROM rd_competitors ORDER BY id ASC');
        $competitorCourses = Database::fetchAll(
            'SELECT cc.*, c.name AS competitor_name
             FROM rd_competitor_courses cc
             LEFT JOIN rd_competitors c ON c.id = cc.competitor_id
             ORDER BY cc.id DESC LIMIT 30'
        );
        $recommendations = Database::fetchAll('SELECT * FROM rd_course_proposals ORDER BY id DESC LIMIT 15');
        $surveyInsights = Database::fetchAll('SELECT * FROM market_surveys_insights ORDER BY id DESC');
        $competitorSummary = Database::fetchAll(
            'SELECT c.id, c.name, c.category, c.website_url, c.city_scope, c.avg_hourly_rate_rial,
                    c.delivery_model, c.key_strengths, c.key_weaknesses, c.last_crawled_at,
                    COALESCE(cc.courses_count, 0) AS courses_count,
                    cc.avg_course_tuition_rial
             FROM rd_competitors c
             LEFT JOIN (
                 SELECT competitor_id, COUNT(*) AS courses_count, AVG(tuition_rial) AS avg_course_tuition_rial
                 FROM rd_competitor_courses
                 GROUP BY competitor_id
             ) cc ON cc.competitor_id = c.id
             ORDER BY c.name ASC'
        );
        $campaignSummary = Database::fetchOne(
            'SELECT COUNT(*) AS campaigns_count,
                    SUM(CASE WHEN status = "awaiting_approval" THEN 1 ELSE 0 END) AS awaiting_approval_count,
                    SUM(CASE WHEN status = "scheduled" THEN 1 ELSE 0 END) AS scheduled_count
             FROM marketing_campaigns'
        ) ?: [];
        $manualMarketingTotals = Database::fetchOne(
            'SELECT COALESCE(SUM(impressions_count), 0) AS impressions,
                    COALESCE(SUM(clicks_count), 0) AS clicks,
                    COALESCE(SUM(leads_generated), 0) AS leads,
                    COALESCE(SUM(enrollments_converted), 0) AS enrollments
             FROM social_media_posts WHERE publish_status = "metrics_manual"'
        ) ?: [];

        $blueOceanCount = 0;
        foreach ($signals as $s) {
            if (str_contains((string)($s['catalog_gap_status'] ?? ''), 'شکاف') || ($s['catalog_gap_status'] ?? '') === 'blue_ocean') {
                $blueOceanCount++;
            }
        }

        $this->render('growth/market_radar', [
            'pageTitle'         => 'میزکار بازاریابی و رادار بازار',
            'signals'           => $signals,
            'competitors'       => $competitors,
            'competitorCourses' => $competitorCourses,
            'recommendations'   => $recommendations,
            'blueOceanCount'    => $blueOceanCount,
            'surveyInsights'    => $surveyInsights,
            'competitorSummary' => $competitorSummary,
            'campaignSummary'   => $campaignSummary,
            'manualMarketingTotals' => $manualMarketingTotals,
        ]);
    }
}
