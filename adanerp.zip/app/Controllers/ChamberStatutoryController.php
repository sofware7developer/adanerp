<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\App;
use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Core\Jalali;

final class ChamberStatutoryController extends Controller
{
    // کلاس آنلاین زنده و وبینار (Skyroom / Adobe Connect / BigBlueButton)
    public function virtualClass(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $action = (string)($_POST['action'] ?? '');

            // ★ v26.6 — قفل سمت سرور: این اکشن‌ها اقدام مدیریتی/مدرسی‌اند و برای نقش فراگیر ۴۰۳ برمی‌گردند
            $this->denyLearnerActions($action, ['create_room', 'sync_attendance'], 'virtual-class');

            if ($action === 'create_room') {
                $slug = 'live-' . strtolower(bin2hex(random_bytes(3)));
                Database::insert(
                    'INSERT INTO virtual_class_rooms
                     (run_id, provider, room_title, sso_slug, online_participants, synced_attendance_count, recording_url, connection_mode)
                     VALUES (?, ?, ?, ?, 0, 0, NULL, "not_configured")',
                    [(int)$_POST['run_id'], (string)$_POST['provider'], trim((string)$_POST['room_title']), $slug]
                );
                $this->flash('warning', 'فقط رکورد داخلی اتاق ساخته شد؛ اتصال به سرویس کلاس آنلاین هنوز پیکربندی نشده است.');
                $this->redirect('virtual-class');
            }

            if ($action === 'sync_attendance') {
                $this->flash('warning', 'همگام‌سازی در دسترس نیست؛ تا زمان اتصال به سرویس واقعی، آمار حضور تغییری نکرده است.');
                $this->redirect('virtual-class');
            }
        }

        $this->render('statutory/virtual_class', [
            'pageTitle' => 'پیش‌نویس اتصال کلاس آنلاین (بدون سرویس زنده)',
            'rooms' => Database::fetchAll('SELECT * FROM virtual_class_rooms ORDER BY id DESC'),
            'runs' => Database::fetchAll('SELECT id, run_code, term_label FROM course_runs ORDER BY id ASC'),
            'ssoSecret' => substr(hash('sha256', (string)App::config('app_secret', 'chamber')), 0, 16),
        ]);
    }

    // سامانه مؤدیان مالیاتی و پل نرم‌افزارهای حسابداری ایران
    public function taxMoadian(): void
    {
        if (isset($_GET['export_accounting'])) {
            $target = (string)$_GET['export_accounting'];
            $rows = Database::fetchAll(
                'SELECT id AS ردیف, entry_shamsi AS تاریخ, account_head AS معین, debit_rial AS بدهکار, credit_rial AS بستانکار, description AS شرح_سند
                 FROM ledger_entries ORDER BY id ASC'
            );
            $this->exportCsv('chamber_accounting_' . $target . '.csv', ['ردیف','تاریخ','معین','بدهکار','بستانکار','شرح_سند'], $rows);
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'generate_moadian_packet') {
            $invId = (int)$_POST['invoice_id'];
            $inv = Database::fetchOne('SELECT * FROM invoices WHERE id = ?', [$invId]);
            if ($inv) {
                $hash = hash('sha256', json_encode($inv, JSON_UNESCAPED_UNICODE));
                Database::insert(
                    'INSERT INTO tax_moadian_packets (invoice_id, tax_unique_id_22, accounting_target, payload_sha256, submission_status)
                     VALUES (?, "", ?, ?, "پیش‌نویس محلی - ارسال نشده")',
                    [$invId, (string)$_POST['accounting_target'], $hash]
                );
                $this->flash('warning', 'پیش‌نویس محلی ثبت شد؛ شناسه مالیاتی صادر نشده و صورتحساب به سامانه مؤدیان ارسال نشده است.');
            }
            $this->redirect('tax-moadian');
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'scan_receipt_ocr') {
            \App\Services\DeepModuleSuiteService::previewFinancialReceiptText(
                (string)($_POST['raw_receipt_text'] ?? ''),
                (string)($_POST['doc_type'] ?? 'چک صیادی / رسید بانکی')
            );
            $this->flash('warning', 'فقط پیش‌نمایش محلی متن ذخیره شد؛ هیچ سندی در دفترکل ثبت و هیچ اطلاعاتی به سامانه مؤدیان ارسال نشد.');
            $this->redirect('tax-moadian');
        }

        $this->render('statutory/tax_moadian', [
            'pageTitle' => 'پیش‌نویس مالیاتی و پیش‌نمایش محلی متن رسید',
            'packets' => Database::fetchAll(
                'SELECT p.*, i.invoice_number, i.total_rial FROM tax_moadian_packets p JOIN invoices i ON i.id = p.invoice_id ORDER BY p.id DESC'
            ),
            'invoices' => Database::fetchAll('SELECT id, invoice_number, total_rial FROM invoices ORDER BY id DESC'),
            'ocrScans' => Database::fetchAll('SELECT * FROM ocr_financial_scans ORDER BY id DESC'),
        ]);
    }

    // درگاه پیامک بومی ایران و بازوهای پیام‌رسان بله و ایتا
    public function iranMessengers(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $action = (string)($_POST['action'] ?? '');

            // ★ v26.6 — قفل سمت سرور: این اکشن‌ها اقدام مدیریتی/مدرسی‌اند و برای نقش فراگیر ۴۰۳ برمی‌گردند
            $this->denyLearnerActions($action, ['save_credentials', 'dispatch_message', 'generate_moadian_packet'], 'iran-messengers');

            if ($action === 'save_credentials') {
                Database::saveSetting('kavenegar_api_key', trim((string)$_POST['kavenegar_api_key']), 'messaging');
                Database::saveSetting('bale_bot_token', trim((string)$_POST['bale_bot_token']), 'messaging');
                Database::saveSetting('eitaa_bot_token', trim((string)$_POST['eitaa_bot_token']), 'messaging');
                $this->flash('success', 'تنظیمات کلیدهای درگاه پیامک ایرانی و بازوهای بله و ایتا در سمت سرور ذخیره شد.');
                $this->redirect('iran-messengers');
            }

            if ($action === 'dispatch_message') {
                Database::insert(
                    'INSERT INTO iran_messenger_dispatches (channel, recipient_group, message_text, sent_count, sent_shamsi, delivery_mode)
                     VALUES (?, ?, ?, 0, ?, "ثبت محلی - ارسال نشده")',
                    [(string)$_POST['channel'], trim((string)$_POST['recipient_group']), trim((string)$_POST['message_text']), Jalali::today()]
                );
                $this->flash('warning', 'پیام فقط در سامانه ثبت شد؛ درگاه ارسال واقعی هنوز پیاده‌سازی/پیکربندی نشده است.');
                $this->redirect('iran-messengers');
            }
        }

        $this->render('statutory/iran_messengers', [
            'pageTitle' => 'درگاه پیامک بومی (کاوه‌نگار/ملی‌پیامک) و بازوهای بله و ایتا',
            'dispatches' => Database::fetchAll('SELECT * FROM iran_messenger_dispatches ORDER BY id DESC'),
            'hasSmsKey' => Database::setting('kavenegar_api_key', '') !== '',
            'hasBaleKey' => Database::setting('bale_bot_token', '') !== '',
            'hasEitaaKey' => Database::setting('eitaa_bot_token', '') !== '',
        ]);
    }
}
