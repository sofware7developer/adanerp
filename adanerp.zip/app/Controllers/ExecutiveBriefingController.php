<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Services\DeepModuleSuiteService;

final class ExecutiveBriefingController extends Controller
{
    public function index(): void
    {
        $ragQuery = trim((string)($_GET['q'] ?? $_POST['q'] ?? 'معافیت مالیات ارزش افزوده آموزش ماده ۱۲'));
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'recalc_yield_pricing') {
            $cnt = DeepModuleSuiteService::recalculateDynamicCoursePricing();
            $this->redirect('digital-twin-bi', 'موتور قیمت‌گذاری پویا صندلی‌ها (Dynamic Yield Pricing) برای ' . $cnt . ' دوره بازمحاسبه شد.');
        }

        $briefing = DeepModuleSuiteService::generateExecutiveMorningBriefing();
        $ragResults = DeepModuleSuiteService::searchSemanticKnowledgeBase($ragQuery);
        $pricingRules = Database::fetchAll('SELECT * FROM tms_dynamic_pricing_rules ORDER BY projected_revenue_gain_pct DESC');

        $this->render('growth/executive_briefing', [
            'pageTitle' => 'بولتن سخنگوی صبحگاهی مدیرعامل، جست‌وجوی معنایی قوانین (RAG) و قیمت‌گذاری پویا',
            'briefing' => $briefing,
            'ragQuery' => $ragQuery,
            'ragResults' => $ragResults,
            'pricingRules' => $pricingRules,
        ]);
    }
}
