<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\App;
use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Services\AvalAiService;

final class PluginsController extends Controller
{
    public function workspaceTools(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $action = (string)($_POST['action'] ?? '');

            if ($action === 'upload_doc') {
                $safeName = 'doc_' . time() . '.txt';
                $path = 'storage/uploads/docs/' . $safeName;
                if (!empty($_FILES['doc_file']['tmp_name']) && is_uploaded_file($_FILES['doc_file']['tmp_name'])) {
                    $safeName = preg_replace('/[^a-zA-Z0-9._-]/', '_', basename((string)$_FILES['doc_file']['name']));
                    $path = 'storage/uploads/docs/' . time() . '_' . $safeName;
                    move_uploaded_file($_FILES['doc_file']['tmp_name'], App::rootPath($path));
                } else {
                    file_put_contents(App::rootPath($path), trim((string)($_POST['inline_text'] ?? 'محتوای سند رسمی')));
                }
                Database::insert(
                    'INSERT INTO documents (title, doc_category, file_name, file_path, uploaded_by, access_scope)
                     VALUES (?, ?, ?, ?, ?, ?)',
                    [trim((string)$_POST['title']), trim((string)$_POST['doc_category']), $safeName, $path, Auth::id(), (string)$_POST['access_scope']]
                );
                $this->flash('success', 'سند جدید در مخزن اسناد سازمانی بارگذاری شد.');
                $this->redirect('workspace-tools');
            }

            if ($action === 'create_dynamic_form' && Auth::hasRole(['super_admin', 'training_expert', 'instructor'])) {
                $schema = [
                    ['name' => 'f1', 'label' => trim((string)$_POST['field1_label']), 'type' => 'text'],
                    ['name' => 'f2', 'label' => trim((string)$_POST['field2_label']), 'type' => 'select', 'options' => ['عالی', 'مطلوب', 'متوسط', 'نیاز به بازنگری']],
                    ['name' => 'f3', 'label' => trim((string)$_POST['field3_label']), 'type' => 'textarea'],
                ];
                Database::insert(
                    'INSERT INTO dynamic_forms (title, module_link, fields_json) VALUES (?, ?, ?)',
                    [
                        trim((string)$_POST['title']),
                        trim((string)$_POST['module_link']),
                        json_encode($schema, JSON_UNESCAPED_UNICODE),
                    ]
                );
                $this->flash('success', 'فرم پویای جدید بدون کدنویسی طراحی و منتشر گردید.');
                $this->redirect('workspace-tools');
            }

            if ($action === 'submit_dynamic_form') {
                $formId = (int)$_POST['form_id'];
                unset($_POST['_csrf'], $_POST['action'], $_POST['form_id']);
                Database::insert(
                    'INSERT INTO form_submissions (form_id, user_id, payload_json) VALUES (?, ?, ?)',
                    [$formId, Auth::id(), json_encode($_POST, JSON_UNESCAPED_UNICODE)]
                );
                Database::execute('UPDATE dynamic_forms SET submissions_count = submissions_count + 1 WHERE id = ?', [$formId]);
                $this->flash('success', 'پاسخ فرم پویا با موفقیت ذخیره شد.');
                $this->redirect('workspace-tools');
            }
        }

        if (isset($_GET['download_doc'])) {
            $doc = Database::fetchOne('SELECT * FROM documents WHERE id = ?', [(int)$_GET['download_doc']]);
            if ($doc && is_file(App::rootPath($doc['file_path']))) {
                header('Content-Type: application/octet-stream');
                header('Content-Disposition: attachment; filename="' . basename($doc['file_name']) . '"');
                readfile(App::rootPath($doc['file_path']));
                exit;
            }
        }

        $docs = Database::fetchAll('SELECT * FROM documents ORDER BY id DESC');
        $forms = Database::fetchAll('SELECT * FROM dynamic_forms ORDER BY id DESC');
        $auditLogs = Database::fetchAll(
            'SELECT a.*, u.full_name FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id ORDER BY a.id DESC LIMIT 15'
        );

        $this->render('plugins/workspace', [
            'pageTitle' => 'اسناد، فرم‌ساز پویا، RBAC و لاگ ممیزی امنیتی',
            'docs' => $docs,
            'forms' => $forms,
            'auditLogs' => $auditLogs,
        ]);
    }

    public function portalBuilder(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $action = (string)($_POST['action'] ?? '');

            if ($action === 'create_version') {
                $maxV = (int)Database::scalar('SELECT COALESCE(MAX(version_no), 1) FROM portal_pages WHERE slug = "home"');
                $boxes = array_values(array_filter(array_map('trim', explode(',', (string)$_POST['boxes_csv']))));
                Database::execute('UPDATE portal_pages SET is_published = 0 WHERE slug = "home"');
                Database::insert(
                    'INSERT INTO portal_pages (slug, version_no, hero_title, hero_subtitle, announcement_bar, featured_boxes_json, is_published, edited_by)
                     VALUES ("home", ?, ?, ?, ?, ?, 1, ?)',
                    [
                        $maxV + 1,
                        trim((string)$_POST['hero_title']),
                        trim((string)$_POST['hero_subtitle']),
                        trim((string)$_POST['announcement_bar']),
                        json_encode($boxes, JSON_UNESCAPED_UNICODE),
                        Auth::id(),
                    ]
                );
                Auth::audit('PORTAL_BUILDER', 'NEW_PORTAL_VERSION_PUBLISHED', 'portal_page', $maxV + 1, []);
                $this->flash('success', 'نسخه جدید پورتال (v' . ($maxV + 1) . ') ذخیره و منتشر شد!');
                $this->redirect('portal-builder');
            }

            if ($action === 'rollback_version') {
                $id = (int)$_POST['page_id'];
                Database::execute('UPDATE portal_pages SET is_published = 0 WHERE slug = "home"');
                Database::execute('UPDATE portal_pages SET is_published = 1 WHERE id = ?', [$id]);
                Auth::audit('PORTAL_BUILDER', 'PORTAL_ROLLBACK', 'portal_page', $id, []);
                $this->flash('info', 'بازگردانی نسخه (Rollback) پورتال عمومی با موفقیت انجام شد.');
                $this->redirect('portal-builder');
            }
        }

        $pages = Database::fetchAll(
            'SELECT p.*, u.full_name FROM portal_pages p JOIN users u ON u.id = p.edited_by ORDER BY p.version_no DESC'
        );

        $this->render('plugins/builder', [
            'pageTitle' => 'وب‌سایت‌ساز، پیش‌نمایش، نسخه‌بندی و Rollback پورتال',
            'pages' => $pages,
        ]);
    }

    public function marketingIntel(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && (($_POST['ajax'] ?? '') === '1')) {
            while (ob_get_level() > 0) {
                ob_end_clean();
            }
            $pack = \App\Services\WowEnterpriseSuiteService::generateMultiPlatformSocialPack(
                (string)($_POST['course_title'] ?? 'دوره کاربردی حسابداری'),
                (string)($_POST['persona'] ?? 'هنرجویان حسابداری')
            );
            $this->json(['ok' => true, 'pack' => $pack]);
            return;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();
            $action = (string)($_POST['action'] ?? '');

            if (in_array($action, [
                'launch_full_social_pack', 'launch_360_social_campaign', 'save_social_post',
                'create_social_post', 'publish_social_post', 'update_social_metrics', 'create_ab_campaign',
                'update_ab_campaign', 'approve_campaign', 'approve_and_send',
            ], true)) {
                $this->requireRole(['super_admin', 'crm_manager', 'training_expert'], 'marketing-intel');
            }

            if ($action === 'launch_full_social_pack' || $action === 'launch_360_social_campaign') {
                $platforms = $_POST['platforms'] ?? ['instagram', 'linkedin', 'telegram', 'whatsapp', 'eitaa_bale'];
                if (!is_array($platforms)) {
                    $platforms = ['instagram', 'linkedin', 'telegram', 'whatsapp'];
                }
                $res = \App\Services\WowEnterpriseSuiteService::launchFullSocialCampaignPack(
                    (string)($_POST['campaign_title'] ?? 'کمپین یکپارچه شبکه‌های اجتماعی'),
                    (string)($_POST['course_title'] ?? 'دوره کاربردی حسابداری'),
                    (string)($_POST['target_persona'] ?? $_POST['persona'] ?? 'هنرجویان حسابداری'),
                    $platforms,
                    (int)(Auth::id() ?? 1)
                );
                $this->flash(
                    'warning',
                    $res['posts_created'] . ' پیش‌نویس محلی شبکه‌های اجتماعی ساخته شد؛ هیچ پستی منتشر یا زمان‌بندی بیرونی نشد.'
                );
                $this->redirect('marketing-intel');
            }

            if ($action === 'save_social_post' || $action === 'create_social_post') {
                $plat = (string)($_POST['platform'] ?? 'instagram');
                $campaignId = filter_var($_POST['campaign_id'] ?? 0, FILTER_VALIDATE_INT);
                $contentFormat = trim((string)($_POST['content_format'] ?? 'پست شبکه‌های اجتماعی'));
                $courseTitle = trim((string)($_POST['target_course_title'] ?? ''));
                $headline = trim((string)($_POST['hook_headline'] ?? ''));
                $caption = trim((string)($_POST['caption_body'] ?? ''));
                $hashtags = trim((string)($_POST['hashtags'] ?? '#آموزش_حسابداری #آدان'));
                $utmUrl = trim((string)($_POST['utm_url'] ?? 'courses?utm_source=' . $plat));
                $promoCode = trim((string)($_POST['promo_code'] ?? ''));
                $scheduled = trim((string)($_POST['scheduled_shamsi'] ?? ''));
                $platformsMeta = WowEnterpriseSuiteService::socialPlatformsMeta();
                if (
                    !isset($platformsMeta[$plat]) || $campaignId === false || $campaignId < 0
                    || $contentFormat === '' || mb_strlen($contentFormat, 'UTF-8') > 60
                    || $courseTitle === '' || mb_strlen($courseTitle, 'UTF-8') > 190
                    || $headline === '' || mb_strlen($headline, 'UTF-8') > 220
                    || $caption === '' || mb_strlen($caption, 'UTF-8') > 10000
                    || mb_strlen($hashtags, 'UTF-8') > 255 || mb_strlen($utmUrl, 'UTF-8') > 255
                    || mb_strlen($promoCode, 'UTF-8') > 40 || mb_strlen($scheduled, 'UTF-8') > 60
                ) {
                    $this->flash('danger', 'اطلاعات پیش‌نویس محتوا معتبر نیست یا از طول مجاز بیشتر است.');
                    $this->redirect('marketing-intel');
                }
                if ($campaignId > 0 && !Database::fetchOne('SELECT id FROM marketing_campaigns WHERE id = ?', [$campaignId])) {
                    $this->flash('danger', 'کمپین انتخاب‌شده معتبر نیست.');
                    $this->redirect('marketing-intel');
                }
                Database::insert(
                    'INSERT INTO social_media_posts
                    (post_code, campaign_id, platform, content_format, target_course_title, hook_headline, caption_body, hashtags, utm_url, promo_code, scheduled_shamsi, impressions_count, engagements_count, clicks_count, leads_generated, enrollments_converted, spend_rial, revenue_rial, publish_status)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
                    [
                        'SOC-' . strtoupper(substr($plat, 0, 2)) . '-' . strtoupper(bin2hex(random_bytes(4))),
                        $campaignId > 0 ? $campaignId : null,
                        $plat,
                        $contentFormat,
                        $courseTitle,
                        $headline,
                        $caption,
                        $hashtags,
                        $utmUrl,
                        $promoCode,
                        $scheduled !== '' ? $scheduled : 'زمان‌بندی نشده',
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        'scheduled_local',
                    ]
                );
                $this->flash('warning', 'پیش‌نویس در سامانه ثبت شد؛ انتشار و آمار بیرونی متصل نیست.');
                $this->redirect('marketing-intel');
            }

            if ($action === 'update_social_metrics') {
                $postId = filter_var($_POST['post_id'] ?? null, FILTER_VALIDATE_INT);
                $metricNames = [
                    'impressions_count', 'engagements_count', 'clicks_count',
                    'leads_generated', 'enrollments_converted', 'spend_rial', 'revenue_rial',
                ];
                $countMetricNames = ['impressions_count', 'engagements_count', 'clicks_count', 'leads_generated', 'enrollments_converted'];
                $metrics = [];
                foreach ($metricNames as $metricName) {
                    $value = filter_var($_POST[$metricName] ?? null, FILTER_VALIDATE_INT);
                    if (
                        $value === false || $value < 0
                        || (in_array($metricName, $countMetricNames, true) && $value > 2147483647)
                    ) {
                        $this->flash('danger', 'شاخص‌ها باید عدد صحیح و غیرمنفی باشند و شمارنده‌ها نباید از ظرفیت سامانه بیشتر شوند.');
                        $this->redirect('marketing-intel');
                    }
                    $metrics[$metricName] = $value;
                }

                if ($postId === false || $postId < 1 || !Database::fetchOne('SELECT id FROM social_media_posts WHERE id = ?', [$postId])) {
                    $this->flash('danger', 'محتوای انتخاب‌شده برای ثبت آمار معتبر نیست.');
                    $this->redirect('marketing-intel');
                }

                Database::execute(
                    'UPDATE social_media_posts
                     SET impressions_count = ?, engagements_count = ?, clicks_count = ?, leads_generated = ?,
                         enrollments_converted = ?, spend_rial = ?, revenue_rial = ?, publish_status = "metrics_manual"
                     WHERE id = ?',
                    [
                        $metrics['impressions_count'],
                        $metrics['engagements_count'],
                        $metrics['clicks_count'],
                        $metrics['leads_generated'],
                        $metrics['enrollments_converted'],
                        $metrics['spend_rial'],
                        $metrics['revenue_rial'],
                        $postId,
                    ]
                );
                $this->flash('success', 'آمار به‌صورت دستی ثبت شد؛ این اعداد از اتصال مستقیم شبکه‌های اجتماعی دریافت نشده‌اند.');
                $this->redirect('marketing-intel');
            }

            if ($action === 'publish_social_post') {
                $changed = Database::execute(
                    'UPDATE social_media_posts SET publish_status = "scheduled_local"
                     WHERE id = ? AND publish_status NOT IN ("published", "simulated_published")',
                    [(int)($_POST['post_id'] ?? 0)]
                );
                $this->flash(
                    $changed === 1 ? 'warning' : 'info',
                    $changed === 1
                        ? 'محتوا فقط در تقویم محلی ثبت شد؛ انتشار در شبکه اجتماعی انجام نشده است.'
                        : 'این محتوا تغییر نکرد؛ وضعیت آن را بررسی کنید.'
                );
                $this->redirect('marketing-intel');
            }

            if ($action === 'create_ab_campaign' || $action === 'update_ab_campaign') {
                $rawCh = (string)($_POST['channel'] ?? 'telegram_sandbox');
                if (!in_array($rawCh, ['sms_sandbox', 'email_sandbox', 'telegram_sandbox'], true)) {
                    $this->flash('danger', 'کانال کمپین معتبر نیست.');
                    $this->redirect('marketing-intel');
                }
                $safeCh = $rawCh;
                $title = trim((string)($_POST['title'] ?? ''));
                $segment = trim((string)($_POST['segment_name'] ?? ''));
                $variantA = trim((string)($_POST['variant_a_text'] ?? ''));
                $variantB = trim((string)($_POST['variant_b_text'] ?? ''));
                $scheduled = trim((string)($_POST['scheduled_shamsi'] ?? ''));
                if (
                    $title === '' || mb_strlen($title, 'UTF-8') > 200
                    || $segment === '' || mb_strlen($segment, 'UTF-8') > 140
                    || $variantA === '' || mb_strlen($variantA, 'UTF-8') > 400
                    || $variantB === '' || mb_strlen($variantB, 'UTF-8') > 400
                    || mb_strlen($scheduled, 'UTF-8') > 40
                ) {
                    $this->flash('danger', 'عنوان، بخش مخاطب و هر دو متن کمپین را کامل و در محدوده مجاز وارد کنید.');
                    $this->redirect('marketing-intel');
                }
                $scheduled = $scheduled !== '' ? $scheduled : 'زمان‌بندی نشده';
                if ($action === 'update_ab_campaign') {
                    $campaignId = filter_var($_POST['campaign_id'] ?? null, FILTER_VALIDATE_INT);
                    if (
                        $campaignId === false || $campaignId < 1
                        || !Database::fetchOne('SELECT id FROM marketing_campaigns WHERE id = ? AND status = "awaiting_approval"', [$campaignId])
                    ) {
                        $this->flash('danger', 'فقط پیش‌نویس‌های در انتظار تأیید قابل ویرایش هستند.');
                        $this->redirect('marketing-intel');
                    }
                    Database::execute(
                        'UPDATE marketing_campaigns
                         SET title = ?, segment_name = ?, channel = ?, variant_a_text = ?, variant_b_text = ?, scheduled_shamsi = ?
                         WHERE id = ? AND status = "awaiting_approval"',
                        [$title, $segment, $safeCh, $variantA, $variantB, $scheduled, $campaignId]
                    );
                    $this->flash('success', 'پیش‌نویس کمپین به‌روزرسانی شد.');
                } else {
                    Database::insert(
                        'INSERT INTO marketing_campaigns
                         (title, segment_name, channel, variant_a_text, variant_b_text, human_approved, scheduled_shamsi, status)
                         VALUES (?, ?, ?, ?, ?, 0, ?, "awaiting_approval")',
                        [$title, $segment, $safeCh, $variantA, $variantB, $scheduled]
                    );
                    $this->flash('success', 'کمپین A/B ایجاد شد و در صف «تأیید الزامی انسانی» قرار گرفت.');
                }
                $this->redirect('marketing-intel');
            }

            if ($action === 'approve_campaign' || $action === 'approve_and_send') {
                $changed = Database::execute(
                    'UPDATE marketing_campaigns SET human_approved = 1, status = "scheduled"
                     WHERE id = ? AND status = "awaiting_approval"',
                    [(int)$_POST['campaign_id']]
                );
                if ($changed === 1) {
                    Auth::audit('MARKETING', 'CAMPAIGN_HUMAN_APPROVED', 'campaign', (int)$_POST['campaign_id'], []);
                }
                $this->flash(
                    $changed === 1 ? 'warning' : 'info',
                    $changed === 1
                        ? 'کمپین تأیید و فقط در وضعیت محلی زمان‌بندی شد؛ ارسال خودکار فعال نیست.'
                        : 'کمپین در انتظار تأیید نیست یا قبلاً تغییر کرده است.'
                );
                $this->redirect('marketing-intel');
            }

            if ($action === 'toggle_consent') {
                $cur = (int)(Auth::user()['marketing_opt_in'] ?? 1);
                $next = $cur === 1 ? 0 : 1;
                Database::execute('UPDATE users SET marketing_opt_in = ? WHERE id = ?', [$next, Auth::id()]);
                $this->flash('info', $next === 1 ? 'رضایت‌نامه دریافت اطلاع‌رسانی آموزشی فعال شد.' : 'لغو اشتراک (Unsubscribe) شما ثبت گردید.');
                $this->redirect('marketing-intel');
            }

            if ($action === 'analyze_competitor') {
                $region = (string)$_POST['region'];
                $url = trim((string)$_POST['source_url']);
                $topic = trim((string)$_POST['trend_topic']);
                $ai = AvalAiService::generate(
                    "تحلیل بازار و رقبای آموزشی در منطقه «{$region}» برای موضوع «{$topic}» (نشانی دستی مرجع: {$url}): شکاف سبد آموزشی آدان و فرصت درآمدی را بنویس.",
                    'Market Intelligence'
                );
                Database::insert(
                    'INSERT INTO market_intel (region, competitor_or_source, source_url, trend_topic, ai_gap_summary)
                     VALUES (?, ?, ?, ?, ?)',
                    [$region, trim((string)$_POST['competitor_or_source']), $url, $topic, $ai['content']]
                );
                $this->flash('success', 'تحلیل بازار ثبت و در رصدخانه رقبا ذخیره شد.');
                $this->redirect('marketing-intel');
            }
        }

        $campaigns = Database::fetchAll(
            'SELECT c.*,
                    (SELECT COUNT(*) FROM social_media_posts sp WHERE sp.campaign_id = c.id) AS social_posts_count
             FROM marketing_campaigns c ORDER BY c.id DESC'
        );
        $socialPosts = Database::fetchAll(
            'SELECT sp.*, c.title AS campaign_title
             FROM social_media_posts sp
             LEFT JOIN marketing_campaigns c ON c.id = sp.campaign_id
             ORDER BY sp.id DESC'
        );
        $platformStats = Database::fetchAll(
            'SELECT platform, COUNT(*) AS posts_cnt, COALESCE(SUM(impressions_count), 0) AS imp, COALESCE(SUM(engagements_count), 0) AS eng,
                    COALESCE(SUM(clicks_count), 0) AS clk,
                    SUM(leads_generated) AS lds, SUM(enrollments_converted) AS conv, SUM(spend_rial) AS spend, SUM(revenue_rial) AS rev
             FROM social_media_posts WHERE publish_status = "metrics_manual"
             GROUP BY platform ORDER BY rev DESC'
        );
        $marketingTotals = Database::fetchOne(
            'SELECT COUNT(*) AS posts_count,
                    COALESCE(SUM(impressions_count), 0) AS impressions,
                    COALESCE(SUM(engagements_count), 0) AS engagements,
                    COALESCE(SUM(clicks_count), 0) AS clicks,
                    COALESCE(SUM(leads_generated), 0) AS leads,
                    COALESCE(SUM(enrollments_converted), 0) AS enrollments,
                    COALESCE(SUM(spend_rial), 0) AS spend,
                    COALESCE(SUM(revenue_rial), 0) AS revenue
             FROM social_media_posts WHERE publish_status = "metrics_manual"'
        ) ?: [];
        $coursesList = Database::fetchAll('SELECT id, code, title, tuition_rial FROM courses ORDER BY id DESC');
        $intel = Database::fetchAll('SELECT * FROM market_intel ORDER BY id DESC');
        $optedInCount = (int)Database::scalar('SELECT COUNT(*) FROM users WHERE marketing_opt_in = 1');

        $this->render('plugins/marketing', [
            'pageTitle' => 'استودیوی کمپین، محتوا و قیف بازاریابی',
            'campaigns' => $campaigns,
            'socialPosts' => $socialPosts,
            'platformStats' => $platformStats,
            'marketingTotals' => $marketingTotals,
            'socialMeta' => \App\Services\WowEnterpriseSuiteService::socialPlatformsMeta(),
            'platformsMeta' => \App\Services\WowEnterpriseSuiteService::socialPlatformsMeta(),
            'coursesList' => $coursesList,
            'allCourses' => $coursesList,
            'intel' => $intel,
            'optedInCount' => $optedInCount,
        ]);
    }

    public function talentPsych(): void
    {
        $botOutput = null;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $action = (string)($_POST['action'] ?? '');

            // نمره‌دهی ۱۰۰٪ قطعی و ریاضی آزمون سبک مذاکره تجاری (بدون اتکا به حدس AI)
            if ($action === 'run_psychometric') {
                $a = max(1, min(5, (int)$_POST['q_analytical'])) * 20;
                $c = max(1, min(5, (int)$_POST['q_collaborative'])) * 20;
                $d = max(1, min(5, (int)$_POST['q_decisive'])) * 20;
                $r = max(1, min(5, (int)$_POST['q_resilience'])) * 20;

                $scores = [
                    'مذاکره‌گر تحلیلی و داده‌محور' => $a,
                    'مذاکره‌گر تعاملی برد-برد بین‌المللی' => $c,
                    'تصمیم‌گیرنده نتیجه‌گرا و قاطع' => $d,
                    'مدیریت تاب‌آور در شرایط بحران ارزی/تجاری' => $r,
                ];
                arsort($scores);
                $dominant = (string)array_key_first($scores);

                Database::insert(
                    'INSERT INTO psychometric_results (user_id, analytical_score, collaborative_score, decisive_score, resilience_score, dominant_style)
                     VALUES (?, ?, ?, ?, ?, ?)',
                    [Auth::id(), $a, $c, $d, $r, $dominant]
                );
                $this->flash('success', 'کارنامه روان‌سنجی شغلی با فرمول قطعی محاسبه شد: «' . $dominant . '»');
                $this->redirect('talent-psych');
            }

            if ($action === 'toggle_passport_privacy') {
                $cur = (int)(Auth::user()['passport_is_public'] ?? 0);
                $next = $cur === 1 ? 0 : 1;
                Database::execute('UPDATE users SET passport_is_public = ? WHERE id = ?', [$next, Auth::id()]);
                $this->flash('info', $next === 1 ? 'پروفایل گذرنامه استعداد شما عمومی شد.' : 'گذرنامه استعداد شما به حالت خصوصی تغییر یافت.');
                $this->redirect('talent-psych');
            }

            if ($action === 'simulate_telegram') {
                $cmd = trim((string)$_POST['bot_command']);
                $botOutput = "پاسخ شبیه‌ساز وب‌هوک ربات تلگرام به دستور «{$cmd}»:\n"
                    . "این فقط پاسخ نمایشی است؛ هیچ ربات، API یا سرویس استعلام بیرونی متصل نیست.";
            }
        }

        $psychResults = Database::fetchAll(
            'SELECT p.*, u.full_name FROM psychometric_results p JOIN users u ON u.id = p.user_id WHERE p.user_id = ? OR ? = "super_admin" ORDER BY p.id DESC',
            [Auth::id(), Auth::role()]
        );
        $badges = Database::fetchAll('SELECT * FROM user_badges ORDER BY id DESC');

        $this->render('plugins/talent', [
            'pageTitle' => 'روان‌سنجی قطعی، گذرنامه استعداد، نشان‌ها، تلگرام و PWA',
            'psychResults' => $psychResults,
            'badges' => $badges,
            'botOutput' => $botOutput,
        ]);
    }
}
