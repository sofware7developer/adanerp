<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Services\AcademicErpCoreService;
use App\Services\EnterpriseSettingsIamService;

final class EnterpriseAdminSuiteController extends Controller
{
    /**
     * استودیو زنده تم، فونت، برندینگ سازمان و تنظیمات جامع نرم‌افزار ERP
     */
    public function systemSettings(): void
    {
        $u = Auth::user();
        $actor = (string)($u['full_name'] ?? 'مدیرکل آموزش');
        $activeTab = trim((string)($_GET['tab'] ?? 'theme'));

        if (isset($_GET['export_json']) && $_GET['export_json'] === '1') {
            header('Content-Type: application/json; charset=utf-8');
            header('Content-Disposition: attachment; filename="chamber-erp-settings-v19.json"');
            echo json_encode([
                'version' => 'v19.0',
                'active_theme' => EnterpriseSettingsIamService::getActiveThemeProfile(true),
                'software_settings' => Database::fetchAll('SELECT setting_group, setting_key, setting_label, setting_value FROM erp_system_settings ORDER BY id ASC'),
            ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $action = (string)($_POST['action'] ?? '');

            // ★ v26.6 — قفل سمت سرور: این اکشن‌ها اقدام مدیریتی/مدرسی‌اند و برای نقش فراگیر ۴۰۳ برمی‌گردند
            $this->denyLearnerActions($action, ['activate_preset', 'save_custom_theme', 'save_software_settings'], 'system-settings');

            if ($action === 'activate_preset' || $action === 'save_custom_theme') {
                $res = EnterpriseSettingsIamService::saveAndActivateThemeStudio($_POST, $actor);
                $this->redirect(
                    'system-settings?tab=' . ($action === 'activate_preset' ? 'theme' : 'font'),
                    'پوسته، پالت رنگی، فونت (' . ($res['theme']['font_family_key'] ?? 'Vazirmatn') . ' — ' . ($res['theme']['base_font_px'] ?? 14) . 'px) و برندینگ سازمان در کل صفحات سامانه فعال شد.'
                );
            }

            if ($action === 'save_software_settings') {
                $cnt = EnterpriseSettingsIamService::saveSoftwareSettingsBatch((array)($_POST['cfg'] ?? []), $actor);
                $this->redirect('system-settings?tab=software', 'تنظیمات هسته نرم‌افزار ERP (' . $cnt . ' پارامتر آموزشی، مالی، هوش مصنوعی و امنیتی) ذخیره و در لاگ ممیزی ثبت شد.');
            }
        }

        $bundle = EnterpriseSettingsIamService::getSettingsAndIamBundle();
        $this->render('growth/system_settings', [
            'pageTitle' => 'استودیو زنده تم و فونت، برندینگ سازمان و تنظیمات جامع نرم‌افزار ERP',
            'activeTab' => $activeTab,
            'bundle'    => $bundle,
        ]);
    }

    /**
     * مرکز جامع مدیریت کاربران، نقش‌های سفارشی، ماتریس سطوح دسترسی (RBAC) و ممیزی امنیتی
     */
    public function iamAccess(): void
    {
        $u = Auth::user();
        $actor = (string)($u['full_name'] ?? 'مدیرکل آموزش');
        $selectedRole = trim((string)($_GET['role'] ?? 'training_expert'));
        $activeTab = trim((string)($_GET['tab'] ?? 'matrix'));

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $action = (string)($_POST['action'] ?? '');

            // ★ v26.6 — قفل سمت سرور: این اکشن‌ها اقدام مدیریتی/مدرسی‌اند و برای نقش فراگیر ۴۰۳ برمی‌گردند
            $this->denyLearnerActions(
                $action,
                ['save_role_matrix', 'create_custom_role', 'update_managed_role', 'delete_custom_role', 'upsert_user', 'add_override'],
                'iam-access'
            );

            if ($action === 'save_role_matrix') {
                $targetRole = trim((string)($_POST['role_slug'] ?? 'training_expert'));
                $res = EnterpriseSettingsIamService::saveRolePermissionsMatrix($targetRole, (array)($_POST['perm'] ?? []));
                $this->redirect('iam-access?tab=matrix&role=' . urlencode($res['role_slug']), 'ماتریس ۶گانه سطوح دسترسی نقش «' . $res['role_slug'] . '» در پایگاه‌داده ذخیره شد.');
            }

            if ($action === 'create_custom_role') {
                $res = EnterpriseSettingsIamService::createCustomRole(
                    (string)($_POST['role_slug'] ?? ''),
                    (string)($_POST['role_title_fa'] ?? ''),
                    (string)($_POST['data_scope'] ?? 'branch_only'),
                    (string)($_POST['description_note'] ?? '')
                );
                $this->redirect(
                    'iam-access?tab=roles',
                    !empty($res['ok'])
                        ? 'نقش سازمانی جدید «' . $res['role_slug'] . '» ایجاد شد.'
                        : (string)$res['message'],
                    !empty($res['ok']) ? 'success' : 'danger'
                );
            }

            if ($action === 'update_managed_role') {
                $res = EnterpriseSettingsIamService::updateManagedRole(
                    (string)($_POST['role_slug'] ?? ''),
                    (string)($_POST['role_title_fa'] ?? ''),
                    (string)($_POST['data_scope'] ?? ''),
                    (string)($_POST['description_note'] ?? '')
                );
                $this->redirect(
                    'iam-access?tab=roles',
                    !empty($res['ok'])
                        ? 'اطلاعات نقش «' . $res['role_slug'] . '» ذخیره شد.'
                        : (string)$res['message'],
                    !empty($res['ok']) ? 'success' : 'danger'
                );
            }

            if ($action === 'delete_custom_role') {
                $res = EnterpriseSettingsIamService::deleteCustomRole((string)($_POST['role_slug'] ?? ''));
                $this->redirect(
                    'iam-access?tab=roles',
                    !empty($res['ok'])
                        ? 'نقش سفارشی «' . $res['role_slug'] . '» حذف شد.'
                        : (string)$res['message'],
                    !empty($res['ok']) ? 'success' : 'danger'
                );
            }

            if ($action === 'upsert_user') {
                $res = EnterpriseSettingsIamService::createOrUpdateManagedUser($_POST);
                $this->redirect(
                    'iam-access?tab=users',
                    !empty($res['ok'])
                        ? ((int)($_POST['user_id'] ?? 0) > 0
                            ? 'اطلاعات حساب «' . $res['username'] . '» به‌روزرسانی شد.'
                                . ((string)($_POST['password'] ?? '') !== '' ? ' گذرواژه نیز بازنشانی شد.' : '')
                            : 'حساب کاربری «' . $res['username'] . '» با نقش «' . $res['role'] . '» ایجاد شد.')
                        : (string)$res['message']
                );
            }

            if ($action === 'add_override') {
                EnterpriseSettingsIamService::addUserPermissionOverride(
                    (int)($_POST['user_id'] ?? 2),
                    (string)($_POST['route_or_perm'] ?? 'system-settings'),
                    (string)($_POST['effect_type'] ?? 'allow'),
                    (string)($_POST['reason_note'] ?? ''),
                    $actor
                );
                $this->redirect('iam-access?tab=users', 'استثنای سطح دسترسی موردی کاربر ثبت و هم‌زمان به نگهبان مسیرها متصل شد.');
            }
        }

        $bundle = EnterpriseSettingsIamService::getSettingsAndIamBundle($selectedRole);
        $editRoleSlug = trim((string)($_GET['edit_role'] ?? ''));
        $editingRole = null;
        if ($editRoleSlug !== '') {
            foreach ($bundle['roles'] as $managedRole) {
                if ((string)$managedRole['role_slug'] === $editRoleSlug) {
                    $editingRole = $managedRole;
                    break;
                }
            }
        }
        $editUserId = max(0, (int)($_GET['edit_user'] ?? 0));
        $selectedUser = null;
        if ($editUserId > 0) {
            foreach ($bundle['users'] as $managedUser) {
                if ((int)$managedUser['id'] === $editUserId) {
                    $selectedUser = $managedUser;
                    break;
                }
            }
        }
        $this->render('growth/iam_access', [
            'pageTitle'    => 'مدیریت کاربران، نقش‌های پویا، ماتریس سطوح دسترسی (RBAC) و ممیزی امنیتی',
            'activeTab'    => $activeTab,
            'selectedRole' => $selectedRole,
            'editingRole'  => $editingRole,
            'selectedUser' => $selectedUser,
            'bundle'       => $bundle,
        ]);
    }

    /**
     * هسته استاندارد عملیات آموزشی ERP (تقویم و ترم‌ها، حضور و غیاب، لیست نمرات، پیش‌نیاز و لیست انتظار)
     */
    public function academicErpCore(): void
    {
        $activeTab = trim((string)($_GET['tab'] ?? 'gradebook'));

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $action = (string)($_POST['action'] ?? '');

            // ★ v26.6 — قفل سمت سرور: این اکشن‌ها اقدام مدیریتی/مدرسی‌اند و برای نقش فراگیر ۴۰۳ برمی‌گردند
            $this->denyLearnerActions($action, ['create_term', 'record_attendance_grade', 'promote_waitlist'], 'academic-erp-core');

            if ($action === 'create_term') {
                $res = AcademicErpCoreService::createAcademicTerm($_POST);
                $this->redirect('academic-erp-core?tab=terms', 'نیمسال آموزشی جدید با کد «' . $res['term_code'] . '» در تقویم رسمی مرکز ثبت شد.');
            }

            if ($action === 'record_attendance_grade') {
                $res = AcademicErpCoreService::recordAttendanceAndGrade($_POST);
                $this->redirect(
                    'academic-erp-core?tab=gradebook',
                    'کارنامه و حضور کلاسی ثبت شد (' . $res['record_serial'] . ' | حضور: ' . $res['attendance_pct'] . '٪ | نمره کل وزن‌دار: ' . $res['weighted_score'] . ' — ' . $res['standing'] . ').'
                );
            }

            if ($action === 'promote_waitlist') {
                $res = AcademicErpCoreService::promoteWaitlistApplicant((int)$_POST['queue_id']);
                $this->redirect('academic-erp-core?tab=prereq', 'متقاضی لیست انتظار «' . ($res['applicant'] ?? '') . '» به ثبت‌نام قطعی کلاس ارتقا یافت.');
            }
        }

        // ★ v26.6 — سطح‌ردیف: فراگیر فقط کارنامه و حضور «خودش» را می‌بیند
        $learnerScope = Auth::role() === 'learner' ? (array)Auth::user() : null;
        $data = AcademicErpCoreService::getAcademicCoreBundle($learnerScope);
        $this->render('growth/academic_erp_core', [
            'pageTitle' => 'هسته استاندارد عملیات آموزشی ERP (تقویم ترم، حضور و غیاب، کارنامه و پیش‌نیازها)',
            'activeTab' => $activeTab,
            'data'      => $data,
        ]);
    }

    /**
     * چاپ رسمی کارنامه جامع تحصیلی-مهارتی فراگیر (A4 Transcript with QR)
     */
    public function transcriptPrint(): void
    {
        // ★ v26.6 — چاپ کارنامه برای فراگیر فقط شامل رکوردهای خودش است (نه کل دفتر نمرات)
        $isLearnerPrint = Auth::role() === 'learner';
        $printScope = $isLearnerPrint ? AcademicErpCoreService::publicSelfScope((array)Auth::user(), 'learner_name', 'national_id') : null;
        $where = $printScope !== null ? ' WHERE ' . $printScope['sql'] : '';
        $params = $printScope['params'] ?? [];
        $records = Database::fetchAllSafe('SELECT * FROM academic_attendance_gradebook' . $where . ' ORDER BY id ASC', $params);
        $avgScore = (int)Database::scalarSafe('SELECT COALESCE(ROUND(AVG(weighted_total_score)), 90) FROM academic_attendance_gradebook'
            . ($where !== '' ? ' WHERE ' . $printScope['sql'] : ''), $params);
        $avgAtt = (int)Database::scalarSafe('SELECT COALESCE(ROUND(AVG(attendance_pct)), 90) FROM academic_attendance_gradebook'
            . ($where !== '' ? ' WHERE ' . $printScope['sql'] : ''), $params);

        $this->render('growth/transcript_print', [
            'pageTitle' => 'کارنامه رسمی آموزشی و ریزنمرات مرکز آموزش مؤسسه آموزشی آدان',
            'records'   => $records,
            'avgScore'  => $avgScore,
            'avgAtt'    => $avgAtt,
        ], 'public');
    }

    /**
     * میز خدمت و تیکتینگ SLA، درخواست‌های اداری فراگیران و قالب‌های اعلان خودکار
     */
    public function helpdeskSla(): void
    {
        $activeTab = trim((string)($_GET['tab'] ?? 'tickets'));

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $action = (string)($_POST['action'] ?? '');

            // ★ v26.6 — قفل سمت سرور: این اکشن‌ها اقدام مدیریتی/مدرسی‌اند و برای نقش فراگیر ۴۰۳ برمی‌گردند
            $this->denyLearnerActions($action, ['reply_ticket', 'save_admin_entry', 'notif_template'], 'helpdesk-sla');

            if ($action === 'create_ticket') {
                $res = AcademicErpCoreService::createSupportTicket($_POST);
                $this->redirect('helpdesk-sla?tab=tickets', 'تیکت پشتیبانی با شماره «' . $res['ticket_no'] . '» و تعهد پاسخگویی SLA حداکثر ' . $res['sla_hours'] . ' ساعته ثبت شد.');
            }

            if ($action === 'reply_ticket') {
                $res = AcademicErpCoreService::replySupportTicket((int)$_POST['ticket_id'], (string)($_POST['official_reply'] ?? ''));
                $this->redirect('helpdesk-sla?tab=tickets', 'پاسخ رسمی کارشناس برای تیکت «' . ($res['ticket_no'] ?? '') . '» ثبت و وضعیت پرونده بسته شد.');
            }

            if ($action === 'save_admin_entry') {
                $res = AcademicErpCoreService::saveAdminRequestOrTemplate($_POST);
                $tab = $res['category'] === 'notif_template' ? 'templates' : 'requests';
                $this->redirect('helpdesk-sla?tab=' . $tab, 'رکورد رسمی با کد «' . $res['entry_code'] . '» با موفقیت ثبت و فعال گردید.');
            }
        }

        $hd = AcademicErpCoreService::getHelpdeskBundle(
            Auth::role() === 'learner' ? (array)Auth::user() : null
        );
        $this->render('growth/helpdesk_sla', [
            'pageTitle' => 'میز خدمت و تیکتینگ SLA، درخواست‌های اداری فراگیران و قالب‌های پیامک خودکار',
            'activeTab' => $activeTab,
            'hd'        => $hd,
        ]);
    }
}
