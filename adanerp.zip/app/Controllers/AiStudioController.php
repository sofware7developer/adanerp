<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Services\AvalAiService;
use App\Services\OoxmlExportService;

final class AiStudioController extends Controller
{
    public function index(): void
    {
        if (!empty($_GET['download_docx'])) {
            $doc = Database::fetchOne('SELECT title, body_markdown FROM ai_contents WHERE id = ?', [(int)$_GET['download_docx']]);
            if ($doc) {
                OoxmlExportService::downloadDocx((string)$doc['title'], (string)$doc['body_markdown'], 'chamber-ai-content-' . (int)$_GET['download_docx'] . '.docx');
            }
        }
        if (!empty($_GET['download_pptx'])) {
            $doc = Database::fetchOne('SELECT title, body_markdown FROM ai_contents WHERE id = ?', [(int)$_GET['download_pptx']]);
            if ($doc) {
                OoxmlExportService::downloadPptx((string)$doc['title'], (string)$doc['body_markdown'], 'chamber-slides-' . (int)$_GET['download_pptx'] . '.pptx');
            }
        }
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $action = (string)($_POST['action'] ?? '');

            if ($action === 'generate_draft') {
                $kind = (string)($_POST['content_kind'] ?? 'course_draft');
                $title = trim((string)$_POST['title']);
                $topicPrompt = trim((string)$_POST['prompt_brief']);
                $extracted = AvalAiService::extractTextFromUpload($_FILES['source_file'] ?? []);
                $fullPrompt = "نوع محتوای درخواستی: {$kind}\nعنوان: {$title}\nشرح نیاز: {$topicPrompt}"
                    . ($extracted !== '' ? "\n\nمتن مستخرج از فایل پیوست:\n{$extracted}" : '');

                $ai = AvalAiService::generate($fullPrompt, 'AI Studio');
                $newId = Database::insert(
                    'INSERT INTO ai_contents (course_id, creator_id, content_kind, title, source_excerpt, current_version, body_markdown, model_used, review_status)
                     VALUES (?, ?, ?, ?, ?, 1, ?, ?, "ai_draft")',
                    [
                        !empty($_POST['course_id']) ? (int)$_POST['course_id'] : null,
                        Auth::id(),
                        $kind,
                        $title,
                        $extracted !== '' ? mb_substr($extracted, 0, 1000) : null,
                        $ai['content'],
                        $ai['model'],
                    ]
                );
                Database::insert(
                    'INSERT INTO ai_content_versions (ai_content_id, version_no, editor_id, change_note, body_snapshot)
                     VALUES (?, 1, ?, "نسخه ۱: تولید پیش‌نویس اولیه توسط هوش مصنوعی (نیازمند بازبینی انسانی)", ?)',
                    [$newId, Auth::id(), $ai['content']]
                );
                Auth::audit('AI_STUDIO', 'DRAFT_GENERATED', 'ai_content', $newId, ['kind' => $kind, 'mode' => $ai['mode']]);
                $this->flash('success', 'پیش‌نویس هوشمند تولید و با وضعیت «پیش‌نویس AI (در انتظار بازبینی انسانی)» ذخیره شد.');
                $this->redirect('ai-studio');
            }

            if ($action === 'save_human_revision') {
                $id = (int)$_POST['ai_content_id'];
                $item = Database::fetchOne('SELECT * FROM ai_contents WHERE id = ?', [$id]);
                if ($item) {
                    $nextVer = (int)$item['current_version'] + 1;
                    $body = trim((string)$_POST['body_markdown']);
                    $decision = (string)($_POST['decision'] ?? 'human_approved');

                    // گاردریل سخت سمت سرور: انتشار بدون تایید انسانی مجاز نیست
                    if ($decision === 'published' && $item['review_status'] === 'ai_draft') {
                        $decision = 'human_approved';
                    }

                    Database::execute(
                        'UPDATE ai_contents SET body_markdown = ?, current_version = ?, review_status = ?, approved_by = ?, approved_at = NOW() WHERE id = ?',
                        [$body, $nextVer, $decision, Auth::id(), $id]
                    );
                    Database::insert(
                        'INSERT INTO ai_content_versions (ai_content_id, version_no, editor_id, change_note, body_snapshot)
                         VALUES (?, ?, ?, ?, ?)',
                        [$id, $nextVer, Auth::id(), trim((string)($_POST['change_note'] ?? 'بازبینی و ویرایش انسانی')), $body]
                    );
                    Auth::audit('AI_STUDIO', 'HUMAN_REVIEW_' . strtoupper($decision), 'ai_content', $id, ['version' => $nextVer]);
                    $this->flash('success', 'نسخه جدید (v' . $nextVer . ') ثبت و وضعیت بازبینی انسانی به‌روزرسانی شد.');
                }
                $this->redirect('ai-studio');
            }
        }

        $items = Database::fetchAll(
            'SELECT a.*, u.full_name AS creator_name, ap.full_name AS approver_name
             FROM ai_contents a
             JOIN users u ON u.id = a.creator_id
             LEFT JOIN users ap ON ap.id = a.approved_by
             ORDER BY a.id DESC'
        );
        $versions = Database::fetchAll(
            'SELECT v.*, u.full_name FROM ai_content_versions v JOIN users u ON u.id = v.editor_id ORDER BY v.id DESC LIMIT 12'
        );
        $courses = Database::fetchAll('SELECT id, code, title FROM courses ORDER BY id ASC');

        $this->render('aistudio/index', [
            'pageTitle' => 'استودیوی تولید محتوا با AI ( بازبینی انسانی)',
            'items' => $items,
            'versions' => $versions,
            'courses' => $courses,
        ]);
    }
}
