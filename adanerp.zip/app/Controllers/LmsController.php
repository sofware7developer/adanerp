<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Services\WowEnterpriseSuiteService;
use ZipArchive;

final class LmsController extends Controller
{
    public function index(): void
    {
        $userId = (int)Auth::id();
        $isLearner = Auth::role() === 'learner';
        $allCourses = $isLearner
            ? Database::fetchAll(
                'SELECT DISTINCT c.id, c.code, c.title, c.delivery_mode
                 FROM courses c
                 JOIN course_runs r ON r.course_id = c.id
                 JOIN enrollments e ON e.run_id = r.id
                 WHERE e.user_id = ? AND e.status IN ("active", "completed")
                 ORDER BY c.id ASC',
                [$userId]
            )
            : Database::fetchAll('SELECT id, code, title, delivery_mode FROM courses ORDER BY id ASC');
        $accessibleCourseIds = array_map(static fn(array $course): int => (int)$course['id'], $allCourses);
        $requestedCourseId = (int)($_GET['course_id'] ?? $_POST['course_id'] ?? ($allCourses[0]['id'] ?? 0));
        if (!in_array($requestedCourseId, $accessibleCourseIds, true)) {
            if ($_SERVER['REQUEST_METHOD'] === 'POST' && (($_POST['ajax'] ?? '') === '1')) {
                $this->json(['ok' => false, 'error' => 'course_not_accessible'], 403);
            }
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $this->flash('danger', 'به این دوره دسترسی ندارید یا در آن ثبت‌نام نشده‌اید.');
                $this->redirect('lms', $allCourses ? ['course_id' => (int)$allCourses[0]['id']] : []);
            }
        }
        $activeCourseId = in_array($requestedCourseId, $accessibleCourseIds, true)
            ? $requestedCourseId
            : (int)($allCourses[0]['id'] ?? 0);

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['ajax'] ?? '') === '1') {
            $op = (string)($_POST['op'] ?? '');
            if ($op === 'quiz_answer') {
                $xp = max(15, min(60, (int)($_POST['xp'] ?? 35)));
                $this->json(['ok' => true, 'xp_awarded' => $xp]);
                return;
            }
            if ($op === 'ai_grade_submission') {
                if (!Auth::hasRole(['super_admin', 'training_expert', 'instructor'])) {
                    $this->json(['ok' => false, 'error' => 'forbidden'], 403);
                }
                $submissionId = (int)($_POST['submission_id'] ?? 0);
                if (Auth::role() === 'instructor' && !$this->instructorCanAccessSubmission($submissionId, $userId)) {
                    $this->json(['ok' => false, 'error' => 'submission_not_assigned'], 403);
                }
                $res = WowEnterpriseSuiteService::aiAutoGradeAssignment($submissionId);
                $this->json($res);
                return;
            }
            $this->json(['ok' => false]);
            return;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();
            $action = $_POST['action'] ?? '';

            // ★ v26.6 — قفل سمت سرور: این اکشن‌ها اقدام مدیریتی/مدرسی‌اند و برای نقش فراگیر ۴۰۳ برمی‌گردند
            $this->denyLearnerActions($action, ['ai_generate_lesson_pack', 'ai_auto_grade_submission', 'ai_grade_submission', 'grade_submission', 'upload_scorm'], 'lms');

            if ($action === 'ai_generate_lesson_pack' || $action === 'ai_auto_grade_submission') {
                $this->requireRole(['super_admin', 'training_expert', 'instructor'], 'lms');
            }

            if ($action === 'ai_generate_lesson_pack') {
                $topic = trim($_POST['lesson_topic'] ?? 'استراتژی‌های نوین مذاکره و مدیریت ریسک قرارداد');
                $res = WowEnterpriseSuiteService::aiGenerateInteractiveLessonPackage($activeCourseId, $topic);
                $this->flash('success', 'بسته هوشمند درس تعاملی «' . $res['topic'] . '» شامل متن درس، آزمونک درون‌ویدئویی و فلش‌کارت مرور در LMS ساخته شد.');
                $this->redirect('lms', ['course_id' => $activeCourseId, 'lesson' => $res['lesson_id']]);
            }

            if ($action === 'ai_auto_grade_submission') {
                $subId = (int)($_POST['submission_id'] ?? 0);
                if (Auth::role() === 'instructor' && !$this->instructorCanAccessSubmission($subId, $userId)) {
                    $this->flash('danger', 'این تکلیف به اجرای دورهٔ شما تعلق ندارد.');
                    $this->redirect('lms', ['course_id' => $activeCourseId]);
                }
                $res = WowEnterpriseSuiteService::aiAutoGradeAssignment($subId);
                if (!empty($res['ok'])) {
                    $this->flash('success', 'تصحیح هوشمند تکلیف با روبریک ۴ محوره AI انجام شد — نمره ثبت‌شده: ' . $res['score'] . ' از ۱۰۰.');
                }
                $this->redirect('lms', ['course_id' => $activeCourseId]);
            }

            if ($action === 'complete_lesson') {
                $lessonId = (int)($_POST['lesson_id'] ?? 0);
                $this->requireLessonInCourse($lessonId, $activeCourseId);
                $minutes = max(5, (int)($_POST['spent_minutes'] ?? 20));
                Database::execute(
                    'INSERT INTO lms_progress (user_id, lesson_id, is_completed, spent_minutes, completed_at)
                     VALUES (?, ?, 1, ?, NOW())
                     ON DUPLICATE KEY UPDATE is_completed = 1, spent_minutes = spent_minutes + VALUES(spent_minutes), completed_at = NOW()',
                    [$userId, $lessonId, $minutes]
                );
                $this->flash('success', 'مطالعه درس ثبت شد و قفل مرحله‌ای درس بعدی باز گردید (+۳۰ XP).');
                $this->redirect('lms', ['course_id' => $activeCourseId, 'lesson' => $lessonId]);
            }

            if ($action === 'save_note') {
                $lessonId = (int)($_POST['lesson_id'] ?? 1);
                $this->requireLessonInCourse($lessonId, $activeCourseId);
                $sec = max(0, (int)($_POST['video_second'] ?? 0));
                $ts = sprintf('%02d:%02d', intdiv($sec, 60), $sec % 60);
                $note = trim($_POST['note_text'] ?? '');
                if ($note !== '') {
                    Database::insert(
                        'INSERT INTO lms_learner_notes (user_id, lesson_id, video_timestamp, note_body) VALUES (?, ?, ?, ?)',
                        [$userId, $lessonId, $ts, $note]
                    );
                    $this->flash('success', 'یادداشت ثانیه‌ای شما در تایم‌لاین ویدئو (' . $ts . ') ذخیره شد.');
                }
                $this->redirect('lms', ['course_id' => $activeCourseId, 'lesson' => $lessonId]);
            }

            if ($action === 'post_discussion') {
                $lessonId = (int)($_POST['lesson_id'] ?? 1);
                $this->requireLessonInCourse($lessonId, $activeCourseId);
                $question = trim($_POST['question_text'] ?? '');
                if ($question !== '') {
                    Database::insert(
                        'INSERT INTO lms_discussions (course_id, lesson_id, user_id, message) VALUES (?, ?, ?, ?)',
                        [$activeCourseId, $lessonId, $userId, $question]
                    );
                    $this->flash('success', 'پرسش علمی شما در تالار گفت‌وگوی درس ثبت گردید.');
                }
                $this->redirect('lms', ['course_id' => $activeCourseId, 'lesson' => $lessonId]);
            }

            if ($action === 'submit_assignment') {
                $title = trim($_POST['assignment_title'] ?? 'پروژه عملیاتی دوره');
                $answerText = trim($_POST['submission_text'] ?? '');
                $savedFile = null;
                if (!empty($_FILES['submission_file']['tmp_name']) && is_uploaded_file($_FILES['submission_file']['tmp_name'])) {
                    $origName = basename((string)$_FILES['submission_file']['name']);
                    $ext = strtolower(pathinfo($origName, PATHINFO_EXTENSION));
                    if (in_array($ext, ['pdf', 'zip', 'docx', 'xlsx', 'png', 'jpg'], true)) {
                        $destDir = dirname(__DIR__, 2) . '/storage/submissions';
                        if (!is_dir($destDir)) {
                            mkdir($destDir, 0775, true);
                        }
                        $safeName = 'sub_' . $userId . '_' . time() . '.' . $ext;
                        if (move_uploaded_file($_FILES['submission_file']['tmp_name'], $destDir . '/' . $safeName)) {
                            $savedFile = 'storage/submissions/' . $safeName;
                        }
                    }
                }
                Database::insert(
                    'INSERT INTO lms_assignments (course_id, user_id, title, submission_text, file_path, status)
                     VALUES (?, ?, ?, ?, ?, "submitted")',
                    [$activeCourseId, $userId, $title, $answerText, $savedFile]
                );
                $this->flash('success', 'تکلیف شما ثبت شد و آماده ارزیابی استاد یا روبریک هوشمند AI است.');
                $this->redirect('lms', ['course_id' => $activeCourseId]);
            }

            if ($action === 'grade_submission' && Auth::hasRole(['super_admin', 'training_expert', 'instructor'])) {
                $subId = (int)($_POST['submission_id'] ?? 0);
                if (Auth::role() === 'instructor' && !$this->instructorCanAccessSubmission($subId, $userId)) {
                    $this->flash('danger', 'این تکلیف به اجرای دورهٔ شما تعلق ندارد.');
                    $this->redirect('lms', ['course_id' => $activeCourseId]);
                }
                $score = min(100, max(0, (float)($_POST['score'] ?? 85)));
                $feedback = trim($_POST['feedback'] ?? '');
                Database::execute('UPDATE lms_assignments SET grade = ?, feedback = ?, status = "graded" WHERE id = ?', [$score, $feedback, $subId]);
                $this->flash('success', 'نمره و بازخورد تشریحی تکلیف ثبت گردید.');
                $this->redirect('lms', ['course_id' => $activeCourseId]);
            }

            if ($action === 'upload_scorm' && Auth::hasRole(['super_admin', 'training_expert', 'instructor'])) {
                $title = trim($_POST['title'] ?? 'بسته استاندارد SCORM');
                if (!empty($_FILES['scorm_zip']['tmp_name']) && is_uploaded_file($_FILES['scorm_zip']['tmp_name'])) {
                    $zip = new ZipArchive();
                    $launchHref = 'index.html';
                    if ($zip->open($_FILES['scorm_zip']['tmp_name']) === true) {
                        $manifestXml = $zip->getFromName('imsmanifest.xml');
                        if (is_string($manifestXml) && preg_match('/href=["\']([^"\']+)["\']/', $manifestXml, $m)) {
                            $launchHref = $m[1];
                        }
                        $zip->close();
                    }
                    $ch = Database::fetchOneSafe('SELECT id FROM lms_chapters WHERE course_id = ? ORDER BY sort_order ASC LIMIT 1', [$activeCourseId]);
                    $chId = $ch ? (int)$ch['id'] : 1;
                    Database::insert(
                        'INSERT INTO lms_lessons (chapter_id, course_id, sort_order, title, content_type, estimated_minutes, sequential_lock, scorm_manifest_path, scorm_version, body_html)
                         VALUES (?, ?, 10, ?, "scorm", 30, 0, ?, "SCORM 1.2", "بسته استاندارد تعاملی SCORM")',
                        [$chId, $activeCourseId, $title, $launchHref]
                    );
                    $this->flash('success', 'بسته SCORM بررسی و مسیر «' . $launchHref . '» در دروس دوره ثبت گردید.');
                }
                $this->redirect('lms', ['course_id' => $activeCourseId]);
            }
        }

        $chapters = Database::fetchAllSafe('SELECT * FROM lms_chapters WHERE course_id = ? ORDER BY sort_order ASC', [$activeCourseId]);
        $progressRows = Database::fetchAllSafe('SELECT lesson_id, is_completed, spent_minutes FROM lms_progress WHERE user_id = ?', [$userId]);
        $completedMap = [];
        $totalMinutes = 0;
        foreach ($progressRows as $pr) {
            if ((int)$pr['is_completed'] === 1) {
                $completedMap[(int)$pr['lesson_id']] = true;
            }
            $totalMinutes += (int)$pr['spent_minutes'];
        }

        $flatLessons = [];
        foreach ($chapters as &$ch) {
            $lessons = Database::fetchAllSafe('SELECT * FROM lms_lessons WHERE chapter_id = ? ORDER BY sort_order ASC', [(int)$ch['id']]);
            $prevCompleted = true;
            foreach ($lessons as &$ls) {
                $id = (int)$ls['id'];
                $ls['is_locked'] = ((int)($ls['sequential_lock'] ?? 0) === 1) && !$prevCompleted;
                $prevCompleted = !empty($completedMap[$id]);
                $flatLessons[$id] = $ls;
            }
            unset($ls);
            $ch['lessons'] = $lessons;
        }
        unset($ch);

        $requestedLesson = (int)($_GET['lesson'] ?? 0);
        $activeLesson = ($requestedLesson && isset($flatLessons[$requestedLesson]) && !$flatLessons[$requestedLesson]['is_locked'])
            ? $flatLessons[$requestedLesson]
            : (reset($flatLessons) ?: null);

        $totalCount = count($flatLessons);
        $doneCount = count(array_intersect_key($completedMap, $flatLessons));
        $progressPct = $totalCount > 0 ? (int)round(($doneCount / $totalCount) * 100) : 0;
        Database::execute(
            'UPDATE enrollments
             SET progress_pct = ?
             WHERE user_id = ? AND status IN ("active", "completed")
               AND run_id IN (SELECT id FROM course_runs WHERE course_id = ?)',
            [$progressPct, $userId, $activeCourseId]
        );

        $activeLessonId = $activeLesson ? (int)$activeLesson['id'] : 0;
        $interactiveQuizzes = Database::fetchAllSafe(
            'SELECT * FROM lms_interactive_quizzes WHERE lesson_id = ? ORDER BY id DESC LIMIT 4',
            [$activeLessonId]
        );
        $studyCards = Database::fetchAllSafe(
            'SELECT * FROM lms_ai_study_cards WHERE course_id = ? ORDER BY id DESC LIMIT 6',
            [$activeCourseId]
        );

        $this->render('lms/index', [
            'pageTitle'          => 'کلاس هوشمند تعاملی (LMS)، آزمونک درون‌ویدئویی و همیار AI',
            'allCourses'         => $allCourses,
            'activeCourseId'     => $activeCourseId,
            'chapters'           => $chapters,
            'activeLesson'       => $activeLesson,
            'completedMap'       => $completedMap,
            'progressPct'        => $progressPct,
            'totalMinutes'       => $totalMinutes,
            'myNotes'            => Database::fetchAllSafe(
                'SELECT * FROM lms_learner_notes WHERE user_id = ? AND lesson_id = ? ORDER BY id DESC',
                [$userId, $activeLessonId]
            ),
            'discussions'        => Database::fetchAllSafe(
                'SELECT d.*, u.full_name FROM lms_discussions d JOIN users u ON u.id = d.user_id WHERE d.lesson_id = ? ORDER BY d.id DESC',
                [$activeLessonId]
            ),
            'submissions'        => Auth::hasRole(['super_admin', 'training_expert'])
                ? Database::fetchAllSafe('SELECT a.*, u.full_name FROM lms_assignments a JOIN users u ON u.id = a.user_id ORDER BY a.id DESC LIMIT 10')
                : (Auth::role() === 'instructor'
                    ? Database::fetchAllSafe(
                        'SELECT DISTINCT a.*, u.full_name
                         FROM lms_assignments a
                         JOIN users u ON u.id = a.user_id
                         JOIN course_runs r ON r.course_id = a.course_id
                         WHERE r.instructor_id = ?
                         ORDER BY a.id DESC LIMIT 10',
                        [$userId]
                    )
                    : Database::fetchAllSafe(
                        'SELECT a.*, u.full_name FROM lms_assignments a JOIN users u ON u.id = a.user_id WHERE a.user_id = ? ORDER BY a.id DESC LIMIT 10',
                        [$userId]
                    )),
            'scormTracks'        => Database::fetchAllSafe('SELECT * FROM scorm_cmi_tracks ORDER BY id DESC LIMIT 6'),
            'interactiveQuizzes' => $interactiveQuizzes,
            'studyCards'         => $studyCards,
        ]);
    }

    private function requireLessonInCourse(int $lessonId, int $courseId): void
    {
        if (
            $lessonId < 1 || $courseId < 1
            || !Database::fetchOne(
                'SELECT id FROM lms_lessons WHERE id = ? AND course_id = ?',
                [$lessonId, $courseId]
            )
        ) {
            $this->flash('danger', 'درس انتخاب‌شده متعلق به این دوره نیست یا در دسترس شما قرار ندارد.');
            $this->redirect('lms', $courseId > 0 ? ['course_id' => $courseId] : []);
        }
    }

    private function instructorCanAccessSubmission(int $submissionId, int $instructorId): bool
    {
        return Database::fetchOne(
            'SELECT a.id
             FROM lms_assignments a
             JOIN course_runs r ON r.course_id = a.course_id
             WHERE a.id = ? AND r.instructor_id = ?
             LIMIT 1',
            [$submissionId, $instructorId]
        ) !== null;
    }
}
