<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Services\ErpIntelligenceService;

final class ErpIntelligenceController extends Controller
{
    public function index(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $action = (string)($_POST['action'] ?? '');
            if ($action === 'run_scheduler') {
                $res = ErpIntelligenceService::runConstraintAutoScheduler();
                $this->redirect(
                    'erp-intelligence',
                    'بهینه‌ساز ریاضی زمان‌بندی اجرا شد: ' . $res['scheduled_count'] . ' دوره با میانگین بهره‌وری ' . $res['avg_utilization'] . '٪ و صفر تداخل چیده شد.'
                );
            } elseif ($action === 'run_rfm') {
                $res = ErpIntelligenceService::recalculateCrmRfm();
                $this->redirect(
                    'erp-intelligence',
                    'ماتریس RFM و پیش‌بینی ریزش برای ' . $res['orgs_scored'] . ' بنگاه عضو بازمحاسبه شد (' . $res['high_risk_count'] . ' بنگاه نیازمند مداخله فوری).'
                );
            } elseif ($action === 'run_matchmaker') {
                $cnt = ErpIntelligenceService::runSkillToIndustryMatchmaker();
                $this->redirect(
                    'erp-intelligence',
                    'گراف تطبیق هوشمند مهارت، روان‌سنجی و صنعت اجرا شد و ' . $cnt . ' معرفی‌نامه شغلی جدید صادر گردید.'
                );
            } elseif ($action === 'trigger_rule') {
                $res = ErpIntelligenceService::triggerAutonomousRule((int)($_POST['rule_id'] ?? 1));
                $this->redirect(
                    'erp-intelligence',
                    'قانون خودران ' . ($res['rule_code'] ?? '') . ' با شماره پیگیری ' . ($res['wf_serial'] ?? '') . ' با موفقیت اجرا شد.'
                );
            } elseif ($action === 'resolve_alert') {
                $res = ErpIntelligenceService::resolveSmartAlert((int)($_POST['alert_id'] ?? 1));
                $this->redirect(
                    'erp-intelligence',
                    'اقدام اصلاحی خودکار برای هشدار ' . ($res['alert_code'] ?? '') . ' اجرا و بسته شد.'
                );
            }
        }

        $scorecard = ErpIntelligenceService::getExecutiveScorecard();
        $alerts = Database::fetchAll('SELECT * FROM erp_smart_alerts ORDER BY status ASC, financial_impact_rial DESC');
        $rules = Database::fetchAll('SELECT * FROM erp_automation_rules ORDER BY id ASC');
        $rfmRows = Database::fetchAll('SELECT * FROM crm_rfm_scores ORDER BY churn_probability_pct DESC, monetary_rial DESC');
        $schedules = Database::fetchAll('SELECT * FROM ai_schedule_optimizations ORDER BY utilization_pct DESC');
        $matches = Database::fetchAll('SELECT * FROM ai_skill_job_matches ORDER BY match_score_pct DESC LIMIT 8');

        $this->render('growth/erp_intelligence', [
            'pageTitle' => 'هسته مرکزی ERP هوشمند، پیش‌بینی مالی، زمان‌بند خودکار و قوانین خودران',
            'scorecard' => $scorecard,
            'alerts'    => $alerts,
            'rules'     => $rules,
            'rfmRows'   => $rfmRows,
            'schedules' => $schedules,
            'matches'   => $matches,
        ]);
    }
}
