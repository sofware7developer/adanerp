<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;

final class InstructorController extends Controller
{
    public function index(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $action = (string)($_POST['action'] ?? '');

            if ($action === 'update_profile') {
                Database::execute(
                    'UPDATE instructor_profiles
                     SET specialties = ?, hourly_rate_rial = ?, availability_slots = ?, qualification_status = ?
                     WHERE user_id = ?',
                    [
                        trim((string)$_POST['specialties']),
                        (int)$_POST['hourly_rate_rial'],
                        trim((string)$_POST['availability_slots']),
                        (string)($_POST['qualification_status'] ?? 'committee_approved'),
                        (int)$_POST['instructor_user_id'],
                    ]
                );
                Auth::audit('INSTRUCTORS', 'PROFILE_UPDATED', 'instructor', (int)$_POST['instructor_user_id'], []);
                $this->flash('success', 'پرونده مدرس، نرخ ساعتی، زمان‌های آزاد و وضعیت صلاحیت به‌روزرسانی شد.');
                $this->redirect('instructors');
            }

            if ($action === 'create_payout' && Auth::hasRole(['super_admin', 'finance_manager', 'training_expert'])) {
                $hours = max(1, (int)$_POST['hours_taught']);
                $rate = (int)$_POST['hourly_rate'];
                $gross = $hours * $rate;
                $tax = (int)round($gross * 0.10);
                $net = $gross - $tax;
                $id = Database::insert(
                    'INSERT INTO instructor_payouts (instructor_user_id, run_id, hours_taught, gross_amount_rial, tax_deduction_rial, net_amount_rial, status, payment_ref)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                    [
                        (int)$_POST['instructor_user_id'],
                        (int)$_POST['run_id'],
                        $hours,
                        $gross,
                        $tax,
                        $net,
                        (string)($_POST['status'] ?? 'approved_finance'),
                        'PAY-1405-' . rand(2000, 9999),
                    ]
                );
                Auth::audit('INSTRUCTORS', 'PAYOUT_CREATED', 'payout', $id, ['net' => $net]);
                $this->flash('success', 'سند حق‌التدریس با کسر مالیات تکلیفی ۱۰٪ ثبت گردید.');
                $this->redirect('instructors');
            }
        }

        $instructors = Database::fetchAll(
            'SELECT ip.*, u.full_name, u.email, u.mobile
             FROM instructor_profiles ip
             JOIN users u ON u.id = ip.user_id'
        );
        $courses = Database::fetchAll('SELECT id, code, title, level FROM courses ORDER BY id ASC');
        $runs = Database::fetchAll('SELECT r.id, r.run_code, c.title FROM course_runs r JOIN courses c ON c.id = r.course_id');
        $payouts = Database::fetchAll(
            'SELECT p.*, u.full_name, r.run_code
             FROM instructor_payouts p
             JOIN users u ON u.id = p.instructor_user_id
             LEFT JOIN course_runs r ON r.id = p.run_id
             ORDER BY p.id DESC'
        );

        // موتور تطبیق هوشمند مدرس با دوره
        $matches = [];
        foreach ($courses as $c) {
            foreach ($instructors as $ins) {
                $overlap = (mb_stripos($c['title'] . ' ' . $ins['specialties'], 'صادرات') !== false || mb_stripos($ins['specialties'], 'CBAM') !== false) ? 97 : 86;
                $matches[] = [
                    'course' => $c['title'],
                    'code' => $c['code'],
                    'instructor' => $ins['full_name'],
                    'score' => $overlap,
                    'slots' => $ins['availability_slots'],
                ];
            }
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'recalc_impact') {
            $cnt = \App\Services\DeepModuleSuiteService::computeInstructorImpactMatrix();
            $this->redirect('instructors', 'شاخص ترکیبی مرجعیت علمی و نرخ پیشنهادی حق‌التدریس برای ' . $cnt . ' استاد بازمحاسبه شد.');
        }

        $impactScores = Database::fetchAll('SELECT * FROM instructor_impact_scores ORDER BY composite_impact_score DESC');

        $this->render('instructors/index', [
            'pageTitle' => 'بانک جامع مدرسان، شاخص مرجعیت علمی و تعیین هوشمند حق‌التدریس',
            'instructors' => $instructors,
            'runs' => $runs,
            'payouts' => $payouts,
            'matches' => array_slice($matches, 0, 5),
            'impactScores' => $impactScores,
        ]);
    }
}
