<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\App;
use App\Core\Database;

final class ScormService
{
    public static function getCmiState(int $userId, int $lessonId = 3): array
    {
        $row = Database::fetchOne(
            'SELECT * FROM scorm_cmi_tracks WHERE user_id = ? AND lesson_id = ? LIMIT 1',
            [$userId, $lessonId]
        );
        if (!$row) {
            return [
                'cmi.core.lesson_status' => 'not attempted',
                'cmi.core.score.raw' => '0',
                'cmi.core.score.max' => '100',
                'cmi.core.session_time' => '00:00:00',
                'cmi.core.lesson_location' => 'start',
                'cmi.suspend_data' => '',
                'commit_count' => 0,
            ];
        }

        return [
            'cmi.core.lesson_status' => (string)$row['lesson_status'],
            'cmi.core.score.raw' => (string)$row['score_raw'],
            'cmi.core.score.max' => (string)$row['score_max'],
            'cmi.core.session_time' => (string)$row['session_time'],
            'cmi.core.lesson_location' => (string)$row['lesson_location'],
            'cmi.suspend_data' => (string)($row['suspend_data'] ?? ''),
            'commit_count' => (int)$row['commit_count'],
        ];
    }

    public static function saveCmiState(int $userId, int $lessonId, array $cmi): array
    {
        $status = (string)($cmi['cmi.core.lesson_status'] ?? 'incomplete');
        if (!in_array($status, ['not attempted', 'incomplete', 'completed', 'passed', 'failed', 'browsed'], true)) {
            $status = 'incomplete';
        }
        $scoreRaw = max(0.0, min(100.0, (float)($cmi['cmi.core.score.raw'] ?? 0)));
        $scoreMax = max(1.0, (float)($cmi['cmi.core.score.max'] ?? 100));
        $sessionTime = substr((string)($cmi['cmi.core.session_time'] ?? '00:05:00'), 0, 30);
        $location = substr((string)($cmi['cmi.core.lesson_location'] ?? 'slide_1'), 0, 120);
        $suspend = (string)($cmi['cmi.suspend_data'] ?? '');

        Database::execute(
            'INSERT INTO scorm_cmi_tracks (user_id, lesson_id, lesson_status, score_raw, score_max, session_time, lesson_location, suspend_data, cmi_json, commit_count)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
             ON DUPLICATE KEY UPDATE
               lesson_status = VALUES(lesson_status),
               score_raw = VALUES(score_raw),
               score_max = VALUES(score_max),
               session_time = VALUES(session_time),
               lesson_location = VALUES(lesson_location),
               suspend_data = VALUES(suspend_data),
               cmi_json = VALUES(cmi_json),
               commit_count = commit_count + 1',
            [
                $userId,
                $lessonId,
                $status,
                $scoreRaw,
                $scoreMax,
                $sessionTime,
                $location,
                $suspend,
                json_encode($cmi, JSON_UNESCAPED_UNICODE),
            ]
        );

        if (in_array($status, ['completed', 'passed'], true)) {
            Database::execute(
                'INSERT INTO lms_progress (user_id, lesson_id, is_completed, spent_minutes, completed_at)
                 VALUES (?, ?, 1, 20, NOW())
                 ON DUPLICATE KEY UPDATE is_completed = 1, spent_minutes = GREATEST(spent_minutes, 20), completed_at = NOW()',
                [$userId, $lessonId]
            );
        }

        return self::getCmiState($userId, $lessonId);
    }

    public static function inspectAndStore(array $file): array
    {
        if (empty($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
            return ['ok' => false, 'message' => 'فایلی انتخاب نشده است.'];
        }
        $ext = strtolower(pathinfo((string)$file['name'], PATHINFO_EXTENSION));
        if ($ext !== 'zip') {
            return ['ok' => false, 'message' => 'بسته SCORM باید با فرمت استاندارد .zip بارگذاری شود.'];
        }
        if (!class_exists(\ZipArchive::class)) {
            return ['ok' => false, 'message' => 'افزونه ZipArchive در PHP فعال نیست.'];
        }

        $zip = new \ZipArchive();
        if ($zip->open($file['tmp_name']) !== true) {
            return ['ok' => false, 'message' => 'بازگشایی فایل فشرده SCORM ناموفق بود.'];
        }

        $manifestXml = false;
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $entry = (string)$zip->getNameIndex($i);
            if (str_contains($entry, '..') || preg_match('/\.(php|phtml|phar|htaccess)$/i', $entry)) {
                $zip->close();
                return ['ok' => false, 'message' => 'بسته حاوی پسوند غیرمجاز اجرایی است و به دلایل امنیتی رد شد.'];
            }
            if (strtolower(basename($entry)) === 'imsmanifest.xml') {
                $manifestXml = $zip->getFromIndex($i);
            }
        }

        if ($manifestXml === false) {
            $zip->close();
            return ['ok' => false, 'message' => 'فایل استاندارد imsmanifest.xml در بسته یافت نشد.'];
        }

        $folder = 'scorm_' . date('Ymd_His') . '_' . bin2hex(random_bytes(3));
        $destDir = App::rootPath('storage/uploads/scorm/' . $folder);
        if (!is_dir($destDir)) {
            mkdir($destDir, 0755, true);
        }
        $zip->extractTo($destDir);
        $zip->close();

        $version = 'SCORM 1.2';
        $launch = 'index.html';
        $pkgTitle = 'بسته تعاملی SCORM';

        $xml = @simplexml_load_string((string)$manifestXml);
        if ($xml !== false) {
            $version = 'SCORM ' . ((string)($xml['version'] ?? '1.2'));
            if (isset($xml->organizations->organization->title)) {
                $pkgTitle = (string)$xml->organizations->organization->title;
            }
            if (isset($xml->resources->resource['href'])) {
                $launch = (string)$xml->resources->resource['href'];
            }
        }

        return [
            'ok' => true,
            'title' => $pkgTitle,
            'version' => $version . ' (Runtime آزمایشی CMI)',
            'manifest_path' => 'storage/uploads/scorm/' . $folder . '/imsmanifest.xml',
            'launch_href' => $launch,
            'message' => 'بسته SCORM با موفقیت بارگذاری و مانیفست (' . $version . ') اعتبارسنجی شد. یادآوری: انطباق کامل با کلیه ابزارهای خارجی تدوین محتوا در محیط عملیاتی نیازمند تأیید نهایی است.',
        ];
    }
}
