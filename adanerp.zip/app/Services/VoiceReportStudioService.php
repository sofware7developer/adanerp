<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Auth;
use App\Core\Database;
use App\Core\Jalali;

/**
 * ★ v26.8 — استودیوی گزارش‌ساز صوتی هوشمند (Voice Report Studio)
 *
 * کاتالوگ گزارش‌های سخنگو (TTS) که با یک کلیک یا با فرمان صوتی فارسی تولید، بایگانی و پخش می‌شوند.
 * هر گزارش سه بخش دارد: شاخص‌های زنده SQL روایت دقیق فارسی توصیه اجرایی.
 *
 * نکات ایمنی/دسترسی:
 *  - هر نوع گزارش فقط برای نقش‌های مجازش در کاتالوگ تعریف شده و در `generate()` هم سمت سرور کنترل می‌شود.
 *  - گزارش‌های نقش فراگیر کاملاً «خودی» هستند: کوئری‌ها با نشانه‌های {uid} و {uname} به رکوردهای خود کاربر محدود می‌شوند.
 *  - همه پرس‌وجوها با *Safe (مقاوم در برابر نبود جدول/ستون) اجرا می‌شوند تا هیچ صفحه‌ای با خطا نکند.
 *  - بایگانی بر اساس نقش فیلتر می‌شود: هر نقش ردیف‌های خودش + ردیف‌های هم‌نقش خود را می‌بیند؛ مدیر کل همه را.
 */
final class VoiceReportStudioService
{
    /** نقش‌های ستون (هر چیزی جز فراگیر) */
    private const STAFF_ROLES = ['super_admin', 'training_expert', 'finance_manager', 'crm_manager', 'instructor', 'org_rep'];

    /** سرعت خوانش گفتار فارسی: تقریباً ۱۳ نویسه در ثانیه */
    private const CHARS_PER_SECOND = 13;

    /**
     * کاتالوگ کامل گزارش‌های صوتی. هر ورودی:
     *  title/group/icon/roles/open/advice/metrics
     * و برای نقش فراگیر: learner => true (خودکار با {uid} و {uname} محدود می‌شود)
     */
    public static function catalog(): array
    {
        return [
            // ══════════════════ ۱. گزارش‌های فرماندهی و هیئت‌رئیسه ══════════════════
            'daily_digest' => [
                'title' => 'دی‌جست روزانه فرماندهی (۵ بند)',
                'group' => 'فرماندهی',
                'icon' => '🌅',
                'roles' => ['super_admin', 'training_expert'],
                'open' => 'گزارش روزانه آموزشگاه آدان:',
                'advice' => 'پیشنهاد اجرایی: سه ردیف برتر جدول منتظر اقدام را امروز ببندید و خروجی چاپی را برای دبیرخانه ارسال کنید.',
                'metrics' => [
                    ['label' => 'کل دوره‌های کاتالوگ', 'sql' => 'SELECT COUNT(*) FROM courses'],
                    ['label' => 'ثبت‌نام‌های ۲۴ ساعت اخیر', 'sql' => 'SELECT COUNT(*) FROM enrollments WHERE created_at >= DATE_SUB(NOW(), INTERVAL 1 DAY)'],
                    ['label' => 'فاکتورهای هنوز تسویه‌نشده', 'sql' => 'SELECT COUNT(*) FROM invoices WHERE status IN ("unpaid", "partial")'],
                    ['label' => 'گواهی‌نامه‌های ۷ روز اخیر', 'sql' => 'SELECT COUNT(*) FROM certificates WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)'],
                    ['label' => 'تیکت‌های پشتیبانی باز', 'sql' => 'SELECT COUNT(*) FROM erp_helpdesk_tickets WHERE official_reply IS NULL OR official_reply = ""'],
                ],
            ],
            'board_weekly' => [
                'title' => 'نامه هفتگی هیئت‌رئیسه (روایت مدیریتی)',
                'group' => 'فرماندهی',
                'icon' => '🏛️',
                'roles' => ['super_admin', 'training_expert'],
                'open' => 'نامه هفتگی هیئت‌رئیسه، روایت مدیریتی هفت روز گذشته:',
                'advice' => 'پیشنهاد اجرایی: این گزارش را در «گزارش چاپی هیئت‌رئیسه» به قالب آچهار رسمی تبدیل و با رمزینه اصالت امضا کنید.',
                'metrics' => [
                    ['label' => 'درآمد محقق‌شده هفته (ریال)', 'sql' => 'SELECT COALESCE(SUM(credit_rial),0) FROM ledger_entries WHERE entry_type = "revenue"'],
                    ['label' => 'هزینه ثبت‌شده هفته (ریال)', 'sql' => 'SELECT COALESCE(SUM(debit_rial),0) FROM ledger_entries WHERE entry_type = "expense"'],
                    ['label' => 'میانگین رضایت شرکت‌کنندگان', 'sql' => 'SELECT COALESCE(ROUND(AVG(kirkpatrick_l1_reaction),1),0) FROM evaluations'],
                    ['label' => 'پیشرفت آموزشی (میانگین درصد)', 'sql' => 'SELECT COALESCE(ROUND(AVG(post_test_score - pre_test_score),1),0) FROM evaluations'],
                    ['label' => 'بنگاه‌های عضو فعال', 'sql' => 'SELECT COUNT(*) FROM organizations'],
                    ['label' => 'مکاتبات منتظر امضا', 'sql' => 'SELECT COUNT(*) FROM oa_letters WHERE sign_status <> "signed"'],
                ],
            ],
            'capacity_fill' => [
                'title' => 'نرخ تکمیل ظرفیت کلاس‌ها و صندلی‌های بی‌استفاده',
                'group' => 'آموزش',
                'icon' => '🏟️',
                'roles' => ['super_admin', 'training_expert', 'instructor'],
                'open' => 'گزارش زنده بهره‌وری ظرفیت آموزشی:',
                'advice' => 'پیشنهاد اجرایی: گروه‌های با تکمیل زیر شصت درصد را ادغام و گروه‌های پرتقاضا را بازگشایی کنید.',
                'metrics' => [
                    ['label' => 'کل ظرفیت صندلی (نفر)', 'sql' => 'SELECT COALESCE(SUM(capacity),0) FROM course_runs'],
                    ['label' => 'نفرات ثبت‌نام‌شده در گروه‌ها', 'sql' => 'SELECT COALESCE(SUM(enrolled_count),0) FROM course_runs'],
                    ['label' => 'نرخ تکمیل ظرفیت (درصد)', 'sql' => 'SELECT COALESCE(ROUND(100 * SUM(enrolled_count) / NULLIF(SUM(capacity),0),1),0) FROM course_runs'],
                    ['label' => 'میانگین اشغال هر فضا (درصد)', 'sql' => 'SELECT COALESCE(ROUND(AVG(100 * enrolled_count / NULLIF(capacity,0)),1),0) FROM course_runs WHERE capacity > 0'],
                    ['label' => 'فضاهای آموزشی در حال تعمیر', 'sql' => 'SELECT COUNT(*) FROM classrooms WHERE maintenance_status <> "active"'],
                ],
            ],
            'enrollment_funnel' => [
                'title' => 'قیف ثبت‌نام و سلامت کاتالوگ دوره‌ها',
                'group' => 'آموزش',
                'icon' => '🪄',
                'roles' => ['super_admin', 'training_expert', 'crm_manager'],
                'open' => 'گزارش قیف ثبت‌نام و وضعیت کاتالوگ:',
                'advice' => 'پیشنهاد اجرایی: دوره‌های منتظر تصویب را در کانبان تصویب تعیین تکلیف کنید تا ظرفیت فصل آینده قفل نشود.',
                'metrics' => [
                    ['label' => 'کل ثبت‌نام‌ها', 'sql' => 'SELECT COUNT(*) FROM enrollments'],
                    ['label' => 'میانگین درصد پیشرفت فراگیران', 'sql' => 'SELECT COALESCE(ROUND(AVG(progress_pct),1),0) FROM enrollments'],
                    ['label' => 'میانگین درصد حضور', 'sql' => 'SELECT COALESCE(ROUND(AVG(attendance_pct),1),0) FROM enrollments'],
                    ['label' => 'توزیع وضعیت ثبت‌نام (ردیف‌ها)', 'sql' => 'SELECT COUNT(*) AS تعداد_وضعیت FROM enrollments'],
                    ['label' => 'دوره‌های منتظر تصویب', 'sql' => 'SELECT COUNT(*) FROM courses WHERE workflow_status <> "published"'],
                    ['label' => 'دوره‌های منتشرشده', 'sql' => 'SELECT COUNT(*) FROM courses WHERE workflow_status = "published"'],
                ],
            ],
            'attendance_risk' => [
                'title' => 'پایش غیبت و فراگیران در معرض افت',
                'group' => 'آموزش',
                'icon' => '🚨',
                'roles' => ['super_admin', 'training_expert', 'instructor', 'org_rep'],
                'open' => 'گزارش هشدار زودهنگام غیبت و افت تحصیلی:',
                'advice' => 'پیشنهاد اجرایی: برای ردیف‌های زیر هشتاد درصد حضور، پیام اطلاع‌رسانی رسمی پیش از آزمون پایانی ارسال کنید.',
                'metrics' => [
                    ['label' => 'نفرات دارای کسری حضور (زیر ۸۰٪)', 'sql' => 'SELECT COUNT(*) FROM academic_attendance_gradebook WHERE attendance_pct < 80'],
                    ['label' => 'میانگین درصد حضور کل', 'sql' => 'SELECT COALESCE(ROUND(AVG(attendance_pct),1),0) FROM academic_attendance_gradebook'],
                    ['label' => 'میانگین نمره نهایی کارنامه‌ها', 'sql' => 'SELECT COALESCE(ROUND(AVG(weighted_total_score),1),0) FROM academic_attendance_gradebook'],
                    ['label' => 'کارنامه‌های دارای اعتراض', 'sql' => 'SELECT COUNT(*) FROM academic_attendance_gradebook WHERE appeal_status <> "" AND appeal_status IS NOT NULL'],
                    ['label' => 'جلسات غیبت ثبت‌شده (نفر-جلسه)', 'sql' => 'SELECT COALESCE(SUM(sessions_total - sessions_attended),0) FROM academic_attendance_gradebook'],
                ],
            ],
            'exam_integrity' => [
                'title' => 'سلامت آزمون، پایش تقلب و صحت‌سنجی گواهی',
                'group' => 'آزمون',
                'icon' => '🛡️',
                'roles' => ['super_admin', 'training_expert', 'instructor'],
                'open' => 'گزارش سلامت آزمون و گواهی‌نامه‌ها:',
                'advice' => 'پیشنهاد اجرایی: رویدادهای پرریسک را بازبینی و برای داوطلبان دارای پرچم قرمز، جلسه جبرانی حضوری تعیین کنید.',
                'metrics' => [
                    ['label' => 'کل تلاش‌های آزمون', 'sql' => 'SELECT COUNT(*) FROM exam_attempts'],
                    ['label' => 'میانگین نمره خودکار', 'sql' => 'SELECT COALESCE(ROUND(AVG(auto_score),1),0) FROM exam_attempts'],
                    ['label' => 'آزمون‌های منتظر تصحیح دستی', 'sql' => 'SELECT COUNT(*) FROM exam_attempts WHERE descriptive_score IS NULL'],
                    ['label' => 'رویدادهای مشکوک پایش', 'sql' => 'SELECT COUNT(*) FROM proctoring_events'],
                    ['label' => 'گواهی‌نامه‌های معتبر', 'sql' => 'SELECT COUNT(*) FROM certificates'],
                    ['label' => 'گواهی‌نامه‌های باطل‌شده', 'sql' => 'SELECT COUNT(*) FROM certificates WHERE status <> "valid"'],
                ],
            ],
            'revenue_pulse' => [
                'title' => 'ضربان درآمد، هزینه و تراز دفتر کل',
                'group' => 'مالی',
                'icon' => '💰',
                'roles' => ['super_admin', 'finance_manager', 'training_expert'],
                'open' => 'گزارش زنده مالی آموزشگاه آدان:',
                'advice' => 'پیشنهاد اجرایی: فاکتورهای باز را با تخفیف تسویه نقدی کوتاه‌مدت جمع کنید و تراز سند دوبل را کنترل نهایی نمایید.',
                'metrics' => [
                    ['label' => 'جمع درآمد (ریال)', 'sql' => 'SELECT COALESCE(SUM(credit_rial),0) FROM ledger_entries WHERE entry_type = "revenue"'],
                    ['label' => 'جمع هزینه‌ها (ریال)', 'sql' => 'SELECT COALESCE(SUM(debit_rial),0) FROM ledger_entries WHERE entry_type = "expense"'],
                    ['label' => 'مازاد عملیاتی (ریال)', 'sql' => 'SELECT COALESCE(SUM(credit_rial) - SUM(debit_rial),0) FROM ledger_entries'],
                    ['label' => 'جمع صورتحساب‌ها (ریال)', 'sql' => 'SELECT COALESCE(SUM(total_rial),0) FROM invoices'],
                    ['label' => 'میانگین مبلغ فاکتور (ریال)', 'sql' => 'SELECT COALESCE(ROUND(AVG(total_rial),0),0) FROM invoices'],
                    ['label' => 'اختلاف تراز اسناد (ریال)', 'sql' => 'SELECT COALESCE(SUM(debit_rial) - SUM(credit_rial),0) FROM accounting_vouchers'],
                ],
            ],
            'sayad_receivables' => [
                'title' => 'چک‌های صیادی، مطالبات و وضعیت وصول',
                'group' => 'مالی',
                'icon' => '',
                'roles' => ['super_admin', 'finance_manager'],
                'open' => 'گزارش زنده خزانه و چک‌های صیادی:',
                'advice' => 'پیشنهاد اجرایی: چک‌های نزدیک سررسید را استعلام و برای بدهکاران معوق، اخطار رسمی ثبتی صادر کنید.',
                'metrics' => [
                    ['label' => 'تعداد چک‌های ثبت‌شده', 'sql' => 'SELECT COUNT(*) FROM sayad_cheques'],
                    ['label' => 'جمع مبلغ چک‌ها (ریال)', 'sql' => 'SELECT COALESCE(SUM(amount_rial),0) FROM sayad_cheques'],
                    ['label' => 'میانگین مبلغ هر چک (ریال)', 'sql' => 'SELECT COALESCE(ROUND(AVG(amount_rial),0),0) FROM sayad_cheques'],
                    ['label' => 'فاکتورهای معوق (ریال)', 'sql' => 'SELECT COALESCE(SUM(CASE WHEN payment_mode = "installment" THEN GREATEST(total_rial - COALESCE((SELECT SUM(ins.amount_rial) FROM invoice_installments ins WHERE ins.invoice_id = invoices.id AND ins.status = "paid"), 0), 0) ELSE total_rial END), 0) FROM invoices WHERE status IN ("unpaid", "partial")'],
                    ['label' => 'تعداد فاکتورهای معوق', 'sql' => 'SELECT COUNT(*) FROM invoices WHERE status IN ("unpaid", "partial")'],
                ],
            ],
            'crm_pipeline' => [
                'title' => 'پایپ‌لاین فروش سازمانی و فرصت‌های قراردادها',
                'group' => 'بازاریابی',
                'icon' => '🤝',
                'roles' => ['super_admin', 'crm_manager'],
                'open' => 'گزارش زنده پایپ‌لاین مشتریان سازمانی:',
                'advice' => 'پیشنهاد اجرایی: فرصت‌های با احتمال بالای پنجاه درصد را در همین هفته به مرحله قرارداد ببرید.',
                'metrics' => [
                    ['label' => 'تعداد فرصت‌های باز', 'sql' => 'SELECT COUNT(*) FROM crm_deals'],
                    ['label' => 'ارزش پایپ‌لاین (ریال)', 'sql' => 'SELECT COALESCE(SUM(estimated_value_rial),0) FROM crm_deals'],
                    ['label' => 'میانگین احتمال موفقیت (درصد)', 'sql' => 'SELECT COALESCE(ROUND(AVG(probability_pct),1),0) FROM crm_deals'],
                    ['label' => 'بنگاه‌های عضو', 'sql' => 'SELECT COUNT(*) FROM organizations'],
                    ['label' => 'سهمیه مصرفی بنگاه‌ها (نفر-ساعت)', 'sql' => 'SELECT COALESCE(SUM(used_quota_hours),0) FROM organizations'],
                ],
            ],
            'marketing_recap' => [
                'title' => 'بازخورد کمپین‌ها و شبکه‌های اجتماعی',
                'group' => 'بازاریابی',
                'icon' => '📣',
                'roles' => ['super_admin', 'crm_manager', 'training_expert'],
                'open' => 'گزارش بازخورد کمپین‌های آموزشی و شبکه‌های اجتماعی:',
                'advice' => 'پیشنهاد اجرایی: واریانت برنده هر کمپین را به‌عنوان استاندارد جایگزین کنید و بودجه را به کانال پربازده منتقل نمایید.',
                'metrics' => [
                    ['label' => 'تعداد کمپین‌ها', 'sql' => 'SELECT COUNT(*) FROM marketing_campaigns'],
                    ['label' => 'کمپین‌های تأییدشده انسانی', 'sql' => 'SELECT COUNT(*) FROM marketing_campaigns WHERE human_approved = 1'],
                    ['label' => 'بهترین نرخ تبدیل A (درصد)', 'sql' => 'SELECT COALESCE(MAX(conversion_a_pct),0) FROM marketing_campaigns'],
                    ['label' => 'تعداد پست‌های رسانه‌ای', 'sql' => 'SELECT COUNT(*) FROM social_media_posts'],
                    ['label' => 'جمع بازدیدها', 'sql' => 'SELECT COALESCE(SUM(impressions_count),0) FROM social_media_posts'],
                    ['label' => 'جمع لیدهای تولیدشده', 'sql' => 'SELECT COALESCE(SUM(leads_generated),0) FROM social_media_posts'],
                    ['label' => 'ثبت‌نام‌های مستقیم از پست‌ها', 'sql' => 'SELECT COALESCE(SUM(enrollments_converted),0) FROM social_media_posts'],
                    ['label' => 'جمع هزینه رسانه (ریال)', 'sql' => 'SELECT COALESCE(SUM(spend_rial),0) FROM social_media_posts'],
                    ['label' => 'درصد بازگشت هزینه رسانه', 'sql' => 'SELECT COALESCE(ROUND(100 * SUM(revenue_rial) / NULLIF(SUM(spend_rial),0),1),0) FROM social_media_posts'],
                ],
            ],
            'market_radar' => [
                'title' => 'رادار بازار، رقبا و فرصت‌های اقیانوس آبی',
                'group' => 'پژوهش',
                'icon' => '🛰️',
                'roles' => ['super_admin', 'training_expert', 'crm_manager'],
                'open' => 'گزارش زنده رادار بازار و تحقیق و توسعه:',
                'advice' => 'پیشنهاد اجرایی: دو سیگنال برتر را به شناسنامه دوره تبدیل و در کانبان تصویب قرار دهید.',
                'metrics' => [
                    ['label' => 'سیگنال‌های کشف‌شده وب', 'sql' => 'SELECT COUNT(*) FROM rd_web_signals'],
                    ['label' => 'میانگین شاخص جذابیت', 'sql' => 'SELECT COALESCE(ROUND(AVG(opportunity_index),1),0) FROM rd_web_signals'],
                    ['label' => 'داغ‌ترین موضوع بازار', 'sql' => 'SELECT keyword_query FROM rd_web_signals ORDER BY opportunity_index DESC LIMIT 1'],
                    ['label' => 'میانگین اشباع رقابت', 'sql' => 'SELECT COALESCE(ROUND(AVG(competition_saturation),1),0) FROM rd_web_signals'],
                ],
            ],
            'office_backlog' => [
                'title' => 'گلوگاه کارتابل اداری و مکاتبات معوق',
                'group' => 'اتوماسیون',
                'icon' => '📮',
                'roles' => ['super_admin', 'training_expert'],
                'open' => 'گزارش اتوماسیون اداری و کارتابل:',
                'advice' => 'پیشنهاد اجرایی: نامه‌های فوری/بسیalfوری را امروز امضا و ارجاع‌های بدون پاسخ را پیگیری کنید.',
                'metrics' => [
                    ['label' => 'کل مکاتبات', 'sql' => 'SELECT COUNT(*) FROM oa_letters'],
                    ['label' => 'منتظر امضا', 'sql' => 'SELECT COUNT(*) FROM oa_letters WHERE sign_status <> "signed"'],
                    ['label' => 'فوریت بالا و خیلی زیاد', 'sql' => 'SELECT COUNT(*) FROM oa_letters WHERE priority_level IN ("urgent","very_urgent")'],
                    ['label' => 'درخواست‌های اداری ثبت‌شده', 'sql' => 'SELECT COUNT(*) FROM erp_admin_requests_templates'],
                    ['label' => 'تعداد کاربران سامانه', 'sql' => 'SELECT COUNT(*) FROM users'],
                ],
            ],
            'helpdesk_sla' => [
                'title' => 'وضعیت SLA میز خدمت و رضایت ارباب‌رجوع',
                'group' => 'خدمات',
                'icon' => '🎧',
                'roles' => ['super_admin', 'training_expert', 'org_rep'],
                'open' => 'گزارش وضعیت میز خدمت و تعهدات زمانی:',
                'advice' => 'پیشنهاد اجرایی: تیکت‌های عبور‌کرده از SLA را به واحد مربوطه ارجاع فوری کنید.',
                'metrics' => [
                    ['label' => 'کل تیکت‌ها', 'sql' => 'SELECT COUNT(*) FROM erp_helpdesk_tickets'],
                    ['label' => 'تیکت‌های بی‌پاسخ', 'sql' => 'SELECT COUNT(*) FROM erp_helpdesk_tickets WHERE official_reply IS NULL OR official_reply = ""'],
                    ['label' => 'میانگین مهلت SLA (ساعت)', 'sql' => 'SELECT COALESCE(ROUND(AVG(sla_hours),1),0) FROM erp_helpdesk_tickets'],
                    ['label' => 'تعداد واحد درگیر', 'sql' => 'SELECT COUNT(DISTINCT department_unit) FROM erp_helpdesk_tickets'],
                    ['label' => 'تیکت‌های اولویت بالا', 'sql' => 'SELECT COUNT(*) FROM erp_helpdesk_tickets WHERE priority_level IN ("urgent","high")'],
                ],
            ],
            'ai_usage_cost' => [
                'title' => 'مصرف و هزینه هوش مصنوعی، تاخیر و سکه‌ها',
                'group' => 'هوش مصنوعی',
                'icon' => '🤖',
                'roles' => ['super_admin', 'training_expert'],
                'open' => 'گزارش مصرف و هزینه موتورهای هوش مصنوعی:',
                'advice' => 'پیشنهاد اجرایی: ماژول‌های پرمصرف را روی مدل محلی Ollama ببرید و سقف توکن روزانه را بازبینی کنید.',
                'metrics' => [
                    ['label' => 'کل فراخوانی‌های AI', 'sql' => 'SELECT COUNT(*) FROM ai_usage_logs'],
                    ['label' => 'جمع توکن ورودی', 'sql' => 'SELECT COALESCE(SUM(prompt_tokens),0) FROM ai_usage_logs'],
                    ['label' => 'جمع توکن خروجی', 'sql' => 'SELECT COALESCE(SUM(completion_tokens),0) FROM ai_usage_logs'],
                    ['label' => 'میانگین تاخیر (میلی‌ثانیه)', 'sql' => 'SELECT COALESCE(ROUND(AVG(latency_ms),0),0) FROM ai_usage_logs'],
                    ['label' => 'فراخوانی‌های ۷ روز اخیر', 'sql' => 'SELECT COUNT(*) FROM ai_usage_logs WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)'],
                    ['label' => 'پرمصرف‌ترین ماژول', 'sql' => 'SELECT module_name FROM ai_usage_logs GROUP BY module_name ORDER BY COUNT(*) DESC LIMIT 1'],
                ],
            ],
            'instructor_quality' => [
                'title' => 'عملکرد و کیفیت تدریس اساتید',
                'group' => 'آموزش',
                'icon' => '🎓',
                'roles' => ['super_admin', 'training_expert'],
                'open' => 'گزارش عملکرد و کیفیت تدریس اعضای هیئت علمی:',
                'advice' => 'پیشنهاد اجرایی: برای اساتید با میانگین رضایت پایین، کارگاه تکنولوژی آموزشی و بازنگری سرفصل برنامه‌ریزی شود.',
                'metrics' => [
                    ['label' => 'تعداد اساتید در بانک', 'sql' => 'SELECT COUNT(*) FROM instructor_profiles'],
                    ['label' => 'میانگین امتیاز رضایت', 'sql' => 'SELECT COALESCE(ROUND(AVG(avg_rating),2),0) FROM instructor_profiles'],
                    ['label' => 'میانگین نرخ ساعت تدریس (ریال)', 'sql' => 'SELECT COALESCE(ROUND(AVG(hourly_rate_rial),0),0) FROM instructor_profiles'],
                    ['label' => 'تعداد سال تجربه (مجموع)', 'sql' => 'SELECT COALESCE(SUM(teaching_years),0) FROM instructor_profiles'],
                    ['label' => 'اساتید دارای صلاحیت تأییدشده', 'sql' => 'SELECT COUNT(*) FROM instructor_profiles WHERE qualification_status <> "pending"'],
                    ['label' => 'میانگین رضایت دوره‌ها (L1)', 'sql' => 'SELECT COALESCE(ROUND(AVG(kirkpatrick_l1_reaction),1),0) FROM evaluations'],
                ],
            ],
            'library_usage' => [
                'title' => 'بهره‌وری کتابخانه دیجیتال و منابع درسی',
                'group' => 'آموزش',
                'icon' => '📚',
                'roles' => ['super_admin', 'training_expert'],
                'open' => 'گزارش بهره‌وری کتابخانه دیجیتال:',
                'advice' => 'پیشنهاد اجرایی: منابع کم‌مصرف را با کپسول‌های میکرولرنینگ پیوند دهید تا دیده شوند.',
                'metrics' => [
                    ['label' => 'کل منابع کتابخانه', 'sql' => 'SELECT COUNT(*) FROM library_items'],
                    ['label' => 'میانگین دانلود هر منبع', 'sql' => 'SELECT COALESCE(ROUND(AVG(downloads_count),1),0) FROM library_items'],
                    ['label' => 'جمع نسخه‌های در دسترس', 'sql' => 'SELECT COALESCE(SUM(available_copies),0) FROM library_items'],
                    ['label' => 'پرمطلب‌ترین منبع', 'sql' => 'SELECT title FROM library_items ORDER BY downloads_count DESC LIMIT 1'],
                ],
            ],
            'org_member_brief' => [
                'title' => 'گزارش ویژه نماینده سازمان (وضعیت پرسنل من)',
                'group' => 'کیفیت آموزشی',
                'icon' => '🏢',
                'roles' => ['org_rep', 'super_admin', 'crm_manager'],
                'open' => 'گزارش وضعیت آموزش بنگاه شما:',
                'advice' => 'پیشنهاد اجرایی: سهمیه مصرف‌نشده را پیش از پایان نیمسال با ثبت‌نام گروهی تبدیل به صرفهجویی کنید.',
                'metrics' => [
                    ['label' => 'تعداد فراگیران سازمان شما', 'sql' => 'SELECT COUNT(*) FROM users WHERE role = "learner" AND org_id = {orgid}'],
                    ['label' => 'سهمیه مصوب (نفر-ساعت)', 'sql' => 'SELECT COALESCE(MAX(annual_quota_hours),0) FROM organizations WHERE id = {orgid}'],
                    ['label' => 'سهمیه مصرف‌شده (نفر-ساعت)', 'sql' => 'SELECT COALESCE(MAX(used_quota_hours),0) FROM organizations WHERE id = {orgid}'],
                    ['label' => 'درصد بهره‌مندی از سهمیه', 'sql' => 'SELECT COALESCE(ROUND(100 * MAX(used_quota_hours) / NULLIF(MAX(annual_quota_hours),0),1),0) FROM organizations WHERE id = {orgid}'],
                    ['label' => 'گواهی‌نامه‌های صادرشده پرسنل', 'sql' => 'SELECT COUNT(*) FROM certificates c JOIN users u ON u.id = c.user_id WHERE u.org_id = {orgid}'],
                ],
            ],
            'learner_ai_adoption' => [
                'title' => 'نرخ پذیرش قابلیت‌های هوشمند در فضای فراگیر',
                'group' => 'هوش مصنوعی',
                'icon' => '',
                'roles' => ['super_admin', 'training_expert', 'instructor'],
                'open' => 'گزارش پذیرش قابلیت‌های هوشمند یادگیری توسط فراگیران:',
                'advice' => 'پیشنهاد اجرایی: قابلیت پراستفاده را به همه گروه‌ها ابلاغ و قابلیت کم‌استفاده را در صفحه فرود آموزش دهید.',
                'metrics' => [
                    ['label' => 'کل رویدادهای هوشمند فراگیران', 'sql' => 'SELECT COUNT(*) FROM learner_ai_telemetry'],
                    ['label' => 'فراگیران فعال با AI', 'sql' => 'SELECT COUNT(DISTINCT user_id) FROM learner_ai_telemetry'],
                    ['label' => 'کارت شخصی ساخته‌شده با AI', 'sql' => 'SELECT COUNT(*) FROM micro_spaced_flashcards WHERE owner_user_id IS NOT NULL'],
                    ['label' => 'میانگین آزمون خودساز هر فراگیر', 'sql' => 'SELECT COALESCE(ROUND(COUNT(*) / NULLIF(COUNT(DISTINCT user_id),0),1),0) FROM learner_ai_telemetry WHERE feature_key = "self_quiz"'],
                    ['label' => 'بریفینگ‌های صوتی پخش‌شده', 'sql' => 'SELECT COUNT(*) FROM voice_report_archive WHERE report_kind LIKE "my_%"'],
                    ['label' => 'پرتکرارترین قابلیت', 'sql' => 'SELECT feature_key FROM learner_ai_telemetry GROUP BY feature_key ORDER BY COUNT(*) DESC LIMIT 1'],
                    ['label' => 'میانگین نمره آزمون‌های خودساز', 'sql' => 'SELECT COALESCE(ROUND(AVG(score_value),1),0) FROM learner_ai_telemetry WHERE feature_key = "self_quiz"'],
                ],
            ],
            'compliance_card' => [
                'title' => 'کیفیت آموزشی و ممیزی داخلی',
                'group' => 'اعضا',
                'icon' => '⚖️',
                'roles' => ['super_admin', 'training_expert'],
                'open' => 'گزارش کیفیت آموزشی و ممیزی داخلی:',
                'advice' => 'پیشنهاد اجرایی: یافته‌های باز ممیزی را به اقدام اصلاحی دارای مسئول و مهلت پیگیری تبدیل کنید.',
                'metrics' => [
                    ['label' => 'نمونه‌های ممیزی ISO 21001', 'sql' => 'SELECT COUNT(*) FROM iso_qa_records'],
                    ['label' => 'یافته‌های باز ممیزی', 'sql' => 'SELECT COUNT(*) FROM iso_qa_records WHERE status <> "closed"'],
                ],
            ],

            // ══════════════════ ۲. گزارش‌های صوتی شخصی فراگیر (کاملاً خودکار و محدود به داده خودش) ══════════════════
            'my_daily_brief' => [
                'title' => 'بریفینگ صوتی امروز من',
                'group' => 'فراگیر',
                'icon' => '☀️',
                'learner' => true,
                'roles' => ['learner', 'super_admin', 'training_expert'],
                'open' => 'بریفینگ صوتی امروز شما:',
                'advice' => 'پیشنهاد مربی: بیست دقیقه مرور امروز، فردا به‌جای دو ساعت مرور جبرانی است.',
                'metrics' => [
                    ['label' => 'کارت‌های آماده مرور امروز', 'sql' => 'SELECT COUNT(*) FROM micro_spaced_flashcards WHERE (owner_user_id IS NULL OR owner_user_id = {uid}) AND leitner_box <= 2'],
                    ['label' => 'کارت‌های شخصی من', 'sql' => 'SELECT COUNT(*) FROM micro_spaced_flashcards WHERE owner_user_id = {uid}'],
                    ['label' => 'یادداشت‌های درس من', 'sql' => 'SELECT COUNT(*) FROM lms_learner_notes WHERE user_id = {uid}'],
                    ['label' => 'درس‌های تکمیل‌شده من', 'sql' => 'SELECT COUNT(*) FROM lms_progress WHERE user_id = {uid} AND is_completed = 1'],
                    ['label' => 'میانگین درصد پیشرفت دوره‌هایم', 'sql' => 'SELECT COALESCE(ROUND(AVG(progress_pct),1),0) FROM enrollments WHERE user_id = {uid}'],
                    ['label' => 'میانگین درصد حضور من', 'sql' => 'SELECT COALESCE(ROUND(AVG(attendance_pct),1),0) FROM enrollments WHERE user_id = {uid}'],
                ],
            ],
            'my_progress' => [
                'title' => 'گزارش پیشرفت دوره‌های من',
                'group' => 'فراگیر',
                'icon' => '📈',
                'learner' => true,
                'roles' => ['learner'],
                'open' => 'گزارش پیشرفت دوره‌های شما:',
                'advice' => 'پیشنهاد مربی: یک درس عقب‌افتاده را امروز ببندید تا قفل ترتیب درس‌ها باز بماند.',
                'metrics' => [
                    ['label' => 'تعداد دوره‌های من', 'sql' => 'SELECT COUNT(*) FROM enrollments WHERE user_id = {uid}'],
                    ['label' => 'میانگین پیشرفت (درصد)', 'sql' => 'SELECT COALESCE(ROUND(AVG(progress_pct),1),0) FROM enrollments WHERE user_id = {uid}'],
                    ['label' => 'میانگین نمره پایانی من', 'sql' => 'SELECT COALESCE(ROUND(AVG(final_score),1),0) FROM enrollments WHERE user_id = {uid}'],
                    ['label' => 'گواهی‌نامه‌های من', 'sql' => 'SELECT COUNT(*) FROM certificates WHERE user_id = {uid}'],
                    ['label' => 'تلاش‌های آزمون من', 'sql' => 'SELECT COUNT(*) FROM exam_attempts WHERE user_id = {uid}'],
                ],
            ],
            'my_leitner_risk' => [
                'title' => 'ریسک فراموشی و وضعیت جعبه لایتنر من',
                'group' => 'فراگیر',
                'icon' => '🧠',
                'learner' => true,
                'roles' => ['learner'],
                'open' => 'گزارش ریسک فراموشی شما:',
                'advice' => 'پیشنهاد مربی: کارت‌های خانه یک و دو را امروز مرور کنید؛ بازگشت آن‌ها به خانه چهار، بار مرور هفتۀ بعد را نصف می‌کند.',
                'metrics' => [
                    ['label' => 'کل کارت‌های من', 'sql' => 'SELECT COUNT(*) FROM micro_spaced_flashcards WHERE owner_user_id IS NULL OR owner_user_id = {uid}'],
                    ['label' => 'کارت‌های در معرض فراموشی (خانه ۱ و ۲)', 'sql' => 'SELECT COUNT(*) FROM micro_spaced_flashcards WHERE (owner_user_id IS NULL OR owner_user_id = {uid}) AND leitner_box <= 2'],
                    ['label' => 'کارت‌های تثبیت‌شده (خانه ۴ و ۵)', 'sql' => 'SELECT COUNT(*) FROM micro_spaced_flashcards WHERE (owner_user_id IS NULL OR owner_user_id = {uid}) AND leitner_box >= 4'],
                    ['label' => 'میانگین ضریب آسانی', 'sql' => 'SELECT COALESCE(ROUND(AVG(ease_factor),2),0) FROM micro_spaced_flashcards WHERE owner_user_id IS NULL OR owner_user_id = {uid}'],
                    ['label' => 'میانگین فاصله مرور (روز)', 'sql' => 'SELECT COALESCE(ROUND(AVG(interval_days),1),0) FROM micro_spaced_flashcards WHERE owner_user_id IS NULL OR owner_user_id = {uid}'],
                    ['label' => 'مجموع مرورهای انجام‌شده', 'sql' => 'SELECT COALESCE(SUM(reviews_count),0) FROM micro_spaced_flashcards WHERE owner_user_id IS NULL OR owner_user_id = {uid}'],
                ],
            ],
            'my_tuition' => [
                'title' => 'وضعیت شهریه و فاکتورهای من',
                'group' => 'فراگیر',
                'icon' => '💳',
                'learner' => true,
                'roles' => ['learner'],
                'open' => 'گزارش مالی شخصی شما:',
                'advice' => 'پیشنهاد مربی: تسویه پیش از سررسید، تخفیف عضویت و اولویت ثبت‌نام گروه بعدی را حفظ می‌کند.',
                'metrics' => [
                    ['label' => 'جمع فاکتورهای من (ریال)', 'sql' => 'SELECT COALESCE(SUM(total_rial),0) FROM invoices WHERE user_id = {uid}'],
                    ['label' => 'تعداد فاکتورهای من', 'sql' => 'SELECT COUNT(*) FROM invoices WHERE user_id = {uid}'],
                    ['label' => 'مانده تسویه (ریال)', 'sql' => 'SELECT COALESCE(SUM(CASE WHEN payment_mode = "installment" THEN GREATEST(total_rial - COALESCE((SELECT SUM(ins.amount_rial) FROM invoice_installments ins WHERE ins.invoice_id = invoices.id AND ins.status = "paid"), 0), 0) ELSE total_rial END), 0) FROM invoices WHERE user_id = {uid} AND status IN ("unpaid", "partial")'],
                    ['label' => 'جمع تخفیف‌های دریافتی (ریال)', 'sql' => 'SELECT COALESCE(SUM(discount_rial),0) FROM invoices WHERE user_id = {uid}'],
                    ['label' => 'مالیات و عوارض من (ریال)', 'sql' => 'SELECT COALESCE(SUM(vat_rial),0) FROM invoices WHERE user_id = {uid}'],
                ],
            ],
        ];
    }

    /** کاتالوگ فیلترشده بر اساس نقش (منبع یکتای نمایش و اجرا) */
    public static function catalogForRole(string $role): array
    {
        $out = [];
        foreach (self::catalog() as $kind => $def) {
            if (in_array($role, $def['roles'], true)) {
                $out[$kind] = $def + ['kind' => $kind];
            }
        }
        return $out;
    }

    public static function isAllowedKind(string $kind, string $role): bool
    {
        $def = self::catalog()[$kind] ?? null;
        return $def !== null && in_array($role, $def['roles'], true);
    }

    public static function titleOf(string $kind): string
    {
        return (string)(self::catalog()[$kind]['title'] ?? $kind);
    }

    /** گروه‌بندی کاتالوگ برای رندر کارت‌ها */
    public static function groupsForRole(string $role): array
    {
        $groups = [];
        foreach (self::catalogForRole($role) as $kind => $def) {
            $groups[$def['group']][] = $def;
        }
        return $groups;
    }

    /**
     * تولید گزارش: شاخص‌های زنده روایت فارسی توصیه بایگانی.
     * برای نقش فراگیر، پرس‌وجوها به رکوردهای خودش محدود می‌شود.
     */
    public static function generate(string $kind, ?array $user = null, string $deliveryMode = 'browser_tts'): array
    {
        $user = $user ?? (Auth::user() ?: []);
        $role = (string)($user['role'] ?? Auth::role() ?? 'super_admin');
        $catalog = self::catalog();
        if (!isset($catalog[$kind])) {
            return ['ok' => false, 'message' => 'نوع گزارش درخواستی در کاتالوگ استودیوی گزارش صوتی وجود ندارد.'];
        }
        $def = $catalog[$kind] + ['kind' => $kind];
        if (!in_array($role, $def['roles'], true)) {
            try {
                Auth::audit('VOICE_REPORT', 'ROLE_FORBIDDEN_REPORT', 'voice_report_archive', null, ['kind' => $kind, 'role' => $role]);
            } catch (\Throwable) {
            }
            return [
                'ok' => false,
                'message' => 'نقش سازمانی «' . (Auth::roleLabel($role) ?: $role) . '» مجاز به تولید این گزارش نیست. فهرست مجاز خودتان را از کارت‌های همین صفحه انتخاب کنید.',
            ];
        }

        $tokens = self::tokens($user, $role);
        $metrics = [];
        foreach ($def['metrics'] as $m) {
            $label = (string)$m['label'];
            $sql = self::applyTokens((string)$m['sql'], $tokens);
            $row = Database::fetchOneSafe($sql, $tokens['params']);
            $value = null;
            if (is_array($row) && $row !== []) {
                $vals = array_values($row);
                $value = count($vals) === 1 ? $vals[0] : implode(' / ', array_map(
                    static fn($k, $v) => $k . ': ' . self::format($v),
                    array_slice(array_keys($row), 0, 3),
                    array_slice($vals, 0, 3)
                ));
            }
            $metrics[] = ['label' => $label, 'value' => self::format($value ?? 0), 'raw' => $value ?? 0];
        }

        // روایت فارسی (متن آماده خوانش با TTS)
        $lines = [];
        $lines[] = $def['open'];
        foreach ($metrics as $i => $m) {
            $lines[] = ($i + 1) . '. ' . $m['label'] . ': ' . $m['value'];
        }
        $lines[] = $def['advice'];
        $narrative = implode("\n", $lines);
        $speech = preg_replace('/\s+/u', ' ', strip_tags($narrative)) ?? $narrative;
        $chars = mb_strlen($speech, 'UTF-8');
        $duration = max(20, (int)ceil($chars / self::CHARS_PER_SECOND));

        $reportCode = 'VRA-' . date('ymdHis') . '-' . strtoupper(substr(md5($kind . '|' . ($user['id'] ?? 0) . microtime()), 0, 5));
        $metricsJson = json_encode($metrics, JSON_UNESCAPED_UNICODE);
        $uid = (int)($user['id'] ?? 0);
        try {
            Database::insert(
                'INSERT INTO voice_report_archive
                    (report_code, report_kind, audience_role, user_id, user_name, report_title, narrative_text, speech_text, metrics_json, speech_chars, est_duration_sec, delivery_mode, visibility_scope, created_shamsi)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
                [
                    $reportCode, $kind, $role, $uid,
                    (string)($user['full_name'] ?? 'سامانه'),
                    (string)$def['title'], $narrative, $speech, $metricsJson,
                    $chars, $duration, $deliveryMode,
                    (($def['learner'] ?? false) && $role === 'learner') ? 'self_only' : 'own_role',
                    Jalali::today(),
                ]
            );
        } catch (\Throwable) {
            // بایگانی نباید تولید گزارش را متوقف کند
        }

        return [
            'ok' => true,
            'kind' => $kind,
            'report_code' => $reportCode,
            'title' => (string)$def['title'],
            'group' => (string)$def['group'],
            'icon' => (string)$def['icon'],
            'metrics' => $metrics,
            'narrative' => $narrative,
            'speech_text' => $speech,
            'speech_chars' => $chars,
            'est_duration_sec' => $duration,
            'delivery_mode' => $deliveryMode,
            'audience_role' => $role,
            'created_shamsi' => Jalali::today(),
        ];
    }

    /** بایگانی با احترام به سطح دسترسی: فراگیر فقط خودش، نقش‌های ستون: خودش + هم‌نقش‌ها، مدیر کل: همه */
    public static function archive(?array $user = null, int $limit = 12): array
    {
        $user = $user ?? (Auth::user() ?: []);
        $role = (string)($user['role'] ?? Auth::role() ?? 'super_admin');
        $uid = (int)($user['id'] ?? 0);
        $limit = max(1, min(50, $limit));

        if ($role === 'learner') {
            return Database::fetchAllSafe(
                'SELECT * FROM voice_report_archive WHERE user_id = ? AND (visibility_scope = "self_only" OR audience_role = "learner")
                 ORDER BY id DESC LIMIT ' . $limit,
                [$uid]
            );
        }
        if ($role === 'super_admin') {
            return Database::fetchAllSafe('SELECT * FROM voice_report_archive ORDER BY id DESC LIMIT ' . $limit);
        }
        return Database::fetchAllSafe(
            'SELECT * FROM voice_report_archive WHERE user_id = ? OR audience_role = ? ORDER BY id DESC LIMIT ' . $limit,
            [$uid, $role]
        );
    }

    public static function archiveById(int $id): ?array
    {
        $row = Database::fetchOneSafe('SELECT * FROM voice_report_archive WHERE id = ?', [$id]);
        if (!is_array($row)) {
            return null;
        }
        $user = Auth::user() ?: [];
        $role = (string)($user['role'] ?? Auth::role() ?? 'super_admin');
        $uid = (int)($user['id'] ?? 0);
        $own = ((int)($row['user_id'] ?? 0) === $uid) || $role === 'super_admin';
        $peer = $role !== 'learner' && (string)($row['audience_role'] ?? '') === $role;
        if (!$own && !$peer) {
            return null;
        }
        return $row;
    }

    /** آمار KPI استودیو برای صفحه گزارش‌ها */
    public static function stats(): array
    {
        $user = Auth::user() ?: [];
        $role = (string)($user['role'] ?? Auth::role() ?? 'super_admin');
        $catalog = self::catalogForRole($role);

        $kinds = [];
        foreach ($catalog as $def) {
            $kinds[] = (string)$def['title'];
        }
        return [
            'kinds_available' => count($catalog),
            'groups' => array_keys(self::groupsForRole($role)),
            'generated_total' => (int)Database::scalarSafe('SELECT COUNT(*) FROM voice_report_archive'),
            'generated_today' => (int)Database::scalarSafe('SELECT COUNT(*) FROM voice_report_archive WHERE created_at >= CURDATE()'),
            'speech_minutes' => (int)round(((float)Database::scalarSafe('SELECT COALESCE(SUM(est_duration_sec),0) FROM voice_report_archive')) / 60, 0),
            'top_kind' => (string)(Database::fetchOneSafe('SELECT report_kind FROM voice_report_archive GROUP BY report_kind ORDER BY COUNT(*) DESC LIMIT 1')['report_kind'] ?? '—'),
            'sample_titles' => array_slice($kinds, 0, 4),
        ];
    }

    /** بسته پذیرش قابلیت‌های هوشمند فراگیر (برای کارت مدیران و گزارش learner_ai_adoption) */
    public static function adoptionBundle(): array
    {
        $rows = Database::fetchAllSafe(
            'SELECT feature_key, COUNT(*) AS uses, COUNT(DISTINCT user_id) AS learners, COALESCE(ROUND(AVG(score_value),1),0) AS avg_score
             FROM learner_ai_telemetry GROUP BY feature_key ORDER BY uses DESC LIMIT 8'
        );
        $labels = [
            'coach_briefing' => 'پخش بریفینگ صوتی روزانه',
            'personal_cards' => 'کارت مرور شخصی‌سازی‌شده با AI',
            'self_quiz' => 'آزمون خودساز از محتوای درس',
            'forgetting_scan' => 'پایش ریسک فراموشی',
            'voice_command' => 'فرمان صوتی یادگیری',
            'weekly_plan' => 'برنامه هفتگی تطبیقی',
        ];
        $items = [];
        foreach ($rows as $r) {
            $key = (string)($r['feature_key'] ?? '');
            $items[] = [
                'label' => $labels[$key] ?? $key,
                'uses' => (int)($r['uses'] ?? 0),
                'learners' => (int)($r['learners'] ?? 0),
                'avg_score' => (float)($r['avg_score'] ?? 0),
            ];
        }
        return [
            'items' => $items,
            'total_events' => (int)Database::scalarSafe('SELECT COUNT(*) FROM learner_ai_telemetry'),
            'active_learners' => (int)Database::scalarSafe('SELECT COUNT(DISTINCT user_id) FROM learner_ai_telemetry'),
            'personal_cards' => (int)Database::scalarSafe('SELECT COUNT(*) FROM micro_spaced_flashcards WHERE owner_user_id IS NOT NULL'),
        ];
    }

    /** متن آماده دانلود/چاپ برای یک گزارش بایگانی‌شده */
    public static function asTextFile(array $row): string
    {
        $metrics = json_decode((string)($row['metrics_json'] ?? '[]'), true) ?: [];
        $lines = [];
        $lines[] = 'مؤسسه آموزشی آدان — گزارش‌ساز صوتی هوشمند';
        $lines[] = 'کد گزارش: ' . ($row['report_code'] ?? '-');
        $lines[] = 'عنوان: ' . ($row['report_title'] ?? '-');
        $lines[] = 'تاریخ تولید: ' . ($row['created_shamsi'] ?? '-') . ' | نقش مخاطب: ' . ($row['audience_role'] ?? '-') . ' | خواننده: ' . ($row['user_name'] ?? '-');
        $lines[] = 'مدت تقریبی خوانش صوتی: ' . Jalali::digits((string)(int)ceil(((int)($row['est_duration_sec'] ?? 60)) / 60)) . ' دقیقه (' . Jalali::digits((string)($row['speech_chars'] ?? 0)) . ' نویسه)';
        $lines[] = '';
        $lines[] = '═══ شاخص‌های زنده ═══';
        foreach ($metrics as $m) {
            $lines[] = '• ' . ($m['label'] ?? '') . ': ' . ($m['value'] ?? '');
        }
        $lines[] = '';
        $lines[] = '═══ روایت سخنگو ═══';
        $lines[] = (string)($row['narrative_text'] ?? '');
        return implode("\n", $lines) . "\n";
    }

    /** نشانه‌های امن برای محدودسازی پرس‌وجو */
    private static function tokens(array $user, string $role): array
    {
        $uid = (int)($user['id'] ?? 0);
        $orgId = (int)($user['org_id'] ?? 0);
        $fullName = trim((string)($user['full_name'] ?? ''));
        $short = preg_replace('/^(جناب\s آقای|سرکار\s خانم|جناب\s آقای|دکتر|مهندس|استاد)\s+/u', '', $fullName) ?? $fullName;
        return [
            'uid' => $uid,
            'orgid' => $orgId > 0 ? $orgId : 1,
            'uname' => $short,
            'params' => [],
        ];
    }

    /** جای‌گذاری نشانه‌ها با مقادیر امن (عدد صحیح و رشته فرار‌شده) */
    private static function applyTokens(string $sql, array $tokens): string
    {
        $clean = str_replace(chr(92), '', (string)$tokens['uname']);
        $clean = str_replace(chr(39), chr(39) . chr(39), $clean);
        $quoted = chr(39) . $clean . chr(39);
        $out = str_replace(
            ['{uid}', '{orgid}', '{uname}'],
            [(int)$tokens['uid'], (int)$tokens['orgid'], $clean === '' ? "''" : $quoted],
            $sql
        );
        // جداول نام‌محور (کارنامه آکادمیک) برای فراگیر با تطبیق نرم نام محدود می‌شود
        if ($tokens['uid'] > 0 && str_contains($sql, 'academic_attendance_gradebook') && !str_contains($sql, 'learner_name')) {
            $scope = $clean === ''
                ? 'FROM academic_attendance_gradebook WHERE 1 = 0'
                : 'FROM academic_attendance_gradebook WHERE learner_name LIKE ' . chr(39) . '%' . $clean . '%' . chr(39);
            $out = str_replace('FROM academic_attendance_gradebook', $scope, $out);
        }
        return $out;
    }

    private static function format(mixed $v): string
    {
        if ($v === null || $v === '') {
            return '—';
        }
        if (is_numeric($v)) {
            $num = (float)$v;
            if (abs($num) >= 1000) {
                return Jalali::digits(number_format($num));
            }
            if (abs($num - round($num)) < 0.0001) {
                return Jalali::digits((string)(int)round($num));
            }
            return Jalali::digits(rtrim(rtrim(number_format($num, 2, '.', ''), '0'), '.'));
        }
        return Jalali::digits((string)$v);
    }
}
