<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database;
use RuntimeException;
use Throwable;

final class CronService
{
    public static function run(): array
    {
        $result = [
            'completed' => 0,
            'failed' => 0,
            'workflow_rows_updated' => 0,
        ];

        while (true) {
            unset($job);
            $pdo = Database::connection();
            $pdo->beginTransaction();

            try {
                $stmt = $pdo->query(
                    "SELECT id, target_url_or_handler
                     FROM webhooks_and_jobs
                     WHERE entry_kind = 'queue_job' AND status = 'queued'
                     ORDER BY id ASC
                     LIMIT 1
                     FOR UPDATE"
                );
                $job = $stmt->fetch();
                if ($job === false) {
                    $pdo->commit();
                    break;
                }

                $response = self::executeHandler((string)$job['target_url_or_handler']);
                $update = $pdo->prepare(
                    "UPDATE webhooks_and_jobs
                     SET status = 'completed', last_response = ?, last_run_at = NOW()
                     WHERE id = ? AND entry_kind = 'queue_job' AND status = 'queued'"
                );
                $update->execute([$response, (int)$job['id']]);
                $pdo->commit();
                $result['completed']++;
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }

                if (!isset($job) || !is_array($job)) {
                    throw $e;
                }

                $message = mb_substr('خطای اجرا: ' . $e->getMessage(), 0, 255);
                Database::execute(
                    "UPDATE webhooks_and_jobs
                     SET status = 'failed', last_response = ?, last_run_at = NOW()
                     WHERE id = ? AND entry_kind = 'queue_job' AND status = 'queued'",
                    [$message, (int)$job['id']]
                );
                $result['failed']++;
                unset($job);
            }
        }

        $result['workflow_rows_updated'] = Database::execute(
            "UPDATE bpms_workflows
             SET elapsed_hours = GREATEST(0, TIMESTAMPDIFF(HOUR, created_at, NOW()))
             WHERE status = 'running'"
        );

        return $result;
    }

    private static function executeHandler(string $handler): string
    {
        if ($handler !== 'BiScheduledReportJob::handle') {
            throw new RuntimeException('پردازشگر پشتیبانی نمی‌شود: ' . $handler);
        }

        $report = EnterpriseBiStudioService::executeSemanticQuery([
            'dataset_key' => 'enrollments_mart',
            'dimension_field' => 'source',
            'metric_field' => 'final_score',
            'agg_func' => 'AVG',
            'chart_type' => 'bar',
            'row_limit' => 20,
        ]);
        $summary = $report['summary'];

        return sprintf(
            'گزارش میانگین نمره به تفکیک کانال جذب تولید شد؛ %d گروه، میانگین کل گروه‌ها: %s | %s',
            (int)$summary['groups_count'],
            (string)$summary['average_val'],
            date('Y-m-d H:i:s')
        );
    }
}
