<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database;
use App\Core\Jalali;

/**
 * هسته استاندارد عملیات آموزشی ERP (تقویم و ترم‌ها، حضور و غیاب، لیست نمرات و کارنامه، پیش‌نیاز/لیست انتظار، تیکتینگ SLA و قالب‌های اعلان)
 */
final class AcademicErpCoreService
{
    /**
     * ۱. تعریف نیمسال / ترم آموزشی جدید در تقویم رسمی مرکز آموزش
     */
    public static function createAcademicTerm(array $input): array
    {
        $code = strtoupper(preg_replace('/[^A-Za-z0-9\-]/', '', (string)($input['term_code'] ?? ''))) ?: ('TERM-1405-' . random_int(10, 99));
        $title = trim((string)($input['term_title'] ?? 'نیمسال ویژه دوره‌های تخصصی بازرگانی'));
        Database::execute(
            'INSERT INTO academic_terms_calendar (term_code, term_title, registration_window, add_drop_deadline, exams_window, target_capacity, term_status)
             VALUES (?, ?, ?, ?, ?, ?, "فعال — آماده ثبت‌نام")
             ON DUPLICATE KEY UPDATE
               term_title = VALUES(term_title),
               registration_window = VALUES(registration_window),
               add_drop_deadline = VALUES(add_drop_deadline),
               exams_window = VALUES(exams_window),
               target_capacity = VALUES(target_capacity),
               term_status = VALUES(term_status)',
            [
                $code,
                $title,
                trim((string)($input['registration_window'] ?? '۱۴۰۵/۰۸/۰۵ لغایت ۱۴۰۵/۰۸/۲۰')),
                trim((string)($input['add_drop_deadline'] ?? 'تا ۷۲ ساعت پیش از شروع کلاس')),
                trim((string)($input['exams_window'] ?? '۱۴۰۵/۱۰/۲۰ لغایت ۱۴۰۵/۱۰/۳۰')),
                max(30, (int)($input['target_capacity'] ?? 500)),
            ]
        );
        return ['ok' => true, 'term_code' => $code];
    }

    /**
     * ۲. ثبت حضور و غیاب جلسات + نمره مستمر/پروژه/پایانی با کنترل خودکار حدنصاب حضور و قبولی از تنظیمات نرم‌افزار!
     */
    public static function recordAttendanceAndGrade(array $input): array
    {
        $minAtt = (int)EnterpriseSettingsIamService::getSetting('min_attendance_pct', '80');
        $minPass = (int)EnterpriseSettingsIamService::getSetting('passing_grade_min', '70');

        $totalSess = max(1, (int)($input['sessions_total'] ?? 10));
        $attSess = max(0, min($totalSess, (int)($input['sessions_attended'] ?? 9)));
        $attPct = (int)round(($attSess / $totalSess) * 100);

        $quiz = max(0, min(100, (int)($input['quiz_activity_score'] ?? 85)));
        $proj = max(0, min(100, (int)($input['practical_project_score'] ?? 90)));
        $final = max(0, min(100, (int)($input['final_exam_score'] ?? 88)));
        $weighted = (int)round(($quiz * 0.20) + ($proj * 0.30) + ($final * 0.50));

        if ($attPct < $minAtt) {
            $standing = "توقف صدور گواهی ⛔ (حضور {$attPct}٪ کمتر از حدنصاب {$minAtt}٪)";
        } elseif ($weighted < $minPass) {
            $standing = "مردود علمی — نیازمند آزمون مجدد (نمره {$weighted} کمتر از {$minPass})";
        } elseif ($weighted >= 90) {
            $standing = 'قبول ممتاز — مجاز به صدور گواهی QR ✅';
        } else {
            $standing = 'قبول — مجاز به صدور گواهی QR ✅';
        }

        $serial = 'GRD-1405-' . random_int(2000, 8999);
        $learner = trim((string)($input['learner_name'] ?? 'مهندس مهرداد شریفی'));
        Database::insert(
            'INSERT INTO academic_attendance_gradebook
             (record_serial, term_code, learner_name, national_id, course_title, sessions_total, sessions_attended,
              attendance_pct, quiz_activity_score, practical_project_score, final_exam_score, weighted_total_score,
              academic_standing, appeal_status, updated_shamsi)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "تأیید اولیه استاد", ?)',
            [
                $serial,
                trim((string)($input['term_code'] ?? 'TERM-1405-FALL')),
                $learner,
                trim((string)($input['national_id'] ?? '1079025413')),
                trim((string)($input['course_title'] ?? 'جامع قوانین اینکوترمز ۲۰۲۰ و UCP600')),
                $totalSess,
                $attSess,
                $attPct,
                $quiz,
                $proj,
                $final,
                $weighted,
                $standing,
                Jalali::today(),
            ]
        );

        LearnerBehaviorGamificationService::recordTelemetryAndAwardXp(7, $learner, 'academic-erp-core', 'ثبت کارنامه و حضور کلاسی ' . $serial, 420, $weighted, 35);
        return [
            'ok' => true,
            'record_serial' => $serial,
            'attendance_pct' => $attPct,
            'weighted_score' => $weighted,
            'eligible_for_cert' => ($attPct >= $minAtt && $weighted >= $minPass),
            'standing' => $standing,
        ];
    }

    /**
     * ۳. رسیدگی به اعتراض نمره فراگیر یا ارتقای نفر اول صف انتظار (Waitlist Promotion)
     */
    public static function promoteWaitlistApplicant(int $id): array
    {
        $row = Database::fetchOne('SELECT * FROM academic_prereq_waitlist WHERE id = ?', [$id]);
        if (!$row) {
            return ['ok' => false];
        }
        Database::execute(
            'UPDATE academic_prereq_waitlist SET queue_status = "ارتقایافته به ثبت‌نام قطعی و ارسال پیامک ✅" WHERE id = ?',
            [$id]
        );
        return ['ok' => true, 'rule_code' => $row['rule_or_queue_code'], 'applicant' => $row['waitlist_applicant_name']];
    }

    /**
     * ۴. ثبت تیکت جدید در میز خدمت SLA و پاسخ رسمی کارشناس واحد مربوطه
     */
    public static function createSupportTicket(array $input): array
    {
        $no = 'TKT-1405-' . random_int(500, 999);
        $prio = trim((string)($input['priority_level'] ?? 'بالا (فوری)'));
        $sla = str_contains($prio, 'فوری') ? 4 : 8;
        Database::insert(
            'INSERT INTO erp_helpdesk_tickets
             (ticket_no, requester_name, requester_role, department_unit, priority_level, sla_hours, subject_line, ticket_status, created_shamsi)
             VALUES (?, ?, ?, ?, ?, ?, ?, "در انتظار پاسخ کارشناس", ?)',
            [
                $no,
                trim((string)($input['requester_name'] ?? 'مهندس مهرداد شریفی')),
                trim((string)($input['requester_role'] ?? 'فراگیر دانش‌پذیر آدان')),
                trim((string)($input['department_unit'] ?? 'آموزش و کلاس‌ها')),
                $prio,
                $sla,
                trim((string)($input['subject_line'] ?? 'درخواست راهنمایی آموزشی')),
                Jalali::today(),
            ]
        );
        return ['ok' => true, 'ticket_no' => $no, 'sla_hours' => $sla];
    }

    public static function replySupportTicket(int $ticketId, string $replyText): array
    {
        $t = Database::fetchOne('SELECT * FROM erp_helpdesk_tickets WHERE id = ?', [$ticketId]);
        if (!$t) {
            return ['ok' => false];
        }
        Database::execute(
            'UPDATE erp_helpdesk_tickets SET official_reply = ?, ticket_status = "پاسخ داده و بسته شد ✅" WHERE id = ?',
            [trim($replyText) ?: 'پاسخ کارشناسی ثبت و اقدام لازم انجام شد.', $ticketId]
        );
        return ['ok' => true, 'ticket_no' => $t['ticket_no']];
    }

    /**
     * ۵. ثبت درخواست اداری فراگیر (گواهی اشتغال به تحصیل/دوره، معادل‌سازی، مرخصی) یا ویرایش قالب پیامک خودکار
     */
    public static function saveAdminRequestOrTemplate(array $input): array
    {
        $cat = ($input['record_category'] ?? 'student_request') === 'notif_template' ? 'notif_template' : 'student_request';
        $prefix = $cat === 'notif_template' ? 'TPL-SMS-' : 'ADM-REQ-';
        $code = $prefix . random_int(200, 999);
        Database::insert(
            'INSERT INTO erp_admin_requests_templates
             (entry_code, record_category, applicant_or_event, request_type_or_channel, body_or_template, approval_state, updated_shamsi)
             VALUES (?, ?, ?, ?, ?, ?, ?)',
            [
                $code,
                $cat,
                trim((string)($input['applicant_or_event'] ?? 'مهندس مهرداد شریفی')),
                trim((string)($input['request_type_or_channel'] ?? 'گواهی اشتغال به دوره رسمی')),
                trim((string)($input['body_or_template'] ?? 'متن درخواست یا قالب اعلان سیستمی')),
                $cat === 'notif_template' ? 'قالب فعال سیستمی ✅' : 'تأیید و صادرشده ✅',
                Jalali::today(),
            ]
        );
        return ['ok' => true, 'entry_code' => $code, 'category' => $cat];
    }

    /**
     * ★ v26.6 — محدوده‌سازی سطح‌ردیف برای نقش فراگیر: رکورد «خودش» با تطبیق نام (بدون القاب رایج)
     * و یا کد ملی شناسایی می‌شود؛ به همین دلیل فراگیر نه کارنامه دیگران، نه تیکت دیگران را می‌بیند.
     *
     * @return array{sql:string,params:array}
     */
    public static function publicSelfScope(array $user, string $nameCol, string $natCol = ''): ?array
    {
        return self::selfScopeSql($user, $nameCol, $natCol);
    }

    private static function selfScopeSql(?array $user, string $nameCol, string $natCol = ''): ?array
    {
        $name = trim((string)($user['full_name'] ?? ''));
        if ($name === '') {
            return null;
        }
        $short = (string)preg_replace('/^(جناب\s+آقای|سرکار\s+خانم|سرکار\s+آقای|آقای|خانم|مهندس|دکتر|استاد|مهندس\s+خانم)\s+/u', '', $name);
        $sql = "(<name> = ? OR <name> LIKE ? OR ? LIKE CONCAT('%', <name>, '%'))";
        $sql = str_replace('<name>', $nameCol, $sql);
        $params = [$name, '%' . $short . '%', $short];
        $nat = trim((string)($user['national_code'] ?? ''));
        if ($natCol !== '' && $nat !== '') {
            $sql .= ' OR ' . $natCol . ' = ?';
            $params[] = $nat;
        }
        return ['sql' => $sql, 'params' => $params];
    }

    public static function getAcademicCoreBundle(?array $learnerUser = null): array
    {
        $scope = self::selfScopeSql($learnerUser, 'learner_name', 'national_id');
        if ($scope !== null) {
            // ★ v26.6 — دید سطح‌ردیف برای فراگیر: فقط حضور، نمره و صف انتظار «خودش»
            return [
                'terms'     => Database::fetchAllSafe('SELECT * FROM academic_terms_calendar ORDER BY id ASC'),
                'gradebook' => Database::fetchAllSafe('SELECT * FROM academic_attendance_gradebook WHERE ' . $scope['sql'] . ' ORDER BY id DESC', $scope['params']),
                'waitlist'  => Database::fetchAllSafe('SELECT * FROM academic_prereq_waitlist WHERE ' . self::selfScopeSql($learnerUser, 'waitlist_applicant_name')['sql'] . ' ORDER BY applicant_priority_score DESC, id ASC', self::selfScopeSql($learnerUser, 'waitlist_applicant_name')['params']),
                'min_att'   => (int)EnterpriseSettingsIamService::getSetting('min_attendance_pct', '80'),
                'min_pass'  => (int)EnterpriseSettingsIamService::getSetting('passing_grade_min', '70'),
                'self_view' => true,
            ];
        }
        return [
            'terms'     => Database::fetchAllSafe('SELECT * FROM academic_terms_calendar ORDER BY id ASC'),
            'gradebook' => Database::fetchAllSafe('SELECT * FROM academic_attendance_gradebook ORDER BY id DESC'),
            'waitlist'  => Database::fetchAllSafe('SELECT * FROM academic_prereq_waitlist ORDER BY applicant_priority_score DESC, id ASC'),
            'min_att'   => (int)EnterpriseSettingsIamService::getSetting('min_attendance_pct', '80'),
            'min_pass'  => (int)EnterpriseSettingsIamService::getSetting('passing_grade_min', '70'),
            'self_view' => false,
        ];
    }

    public static function getHelpdeskBundle(?array $requesterUser = null): array
    {
        $scope = self::selfScopeSql($requesterUser, 'requester_name');
        if ($scope !== null) {
            // ★ v26.6 — فراگیر تنها تیکت‌ها و درخواست‌های اداری خودش را می‌بیند (نه پرونده دیگران)
            $reqScope = self::selfScopeSql($requesterUser, 'applicant_or_event');
            return [
                'tickets'   => Database::fetchAllSafe('SELECT * FROM erp_helpdesk_tickets WHERE ' . $scope['sql'] . ' ORDER BY id DESC', $scope['params']),
                'requests'  => Database::fetchAllSafe('SELECT * FROM erp_admin_requests_templates WHERE record_category = "student_request" AND ' . $reqScope['sql'] . ' ORDER BY id DESC', $reqScope['params']),
                'templates' => [],
                'self_view' => true,
            ];
        }
        return [
            'tickets'   => Database::fetchAll('SELECT * FROM erp_helpdesk_tickets ORDER BY id DESC'),
            'requests'  => Database::fetchAll('SELECT * FROM erp_admin_requests_templates WHERE record_category = "student_request" ORDER BY id DESC'),
            'templates' => Database::fetchAll('SELECT * FROM erp_admin_requests_templates WHERE record_category = "notif_template" ORDER BY id DESC'),
            'self_view' => false,
        ];
    }
}
