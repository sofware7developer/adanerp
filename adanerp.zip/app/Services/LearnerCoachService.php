<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Auth;
use App\Core\Database;
use App\Core\Jalali;

/**
 * ★ v26.8 — مربی هوشمند فضای یادگیری فراگیر (Learner AI Coach)
 *
 * پنج قابلیت هوشمند که فقط روی داده‌های خودِ فراگیر کار می‌کند و هیچ اقدام مدیریتی/مدرسی ندارد:
 *  ۱) بریفینگ صوتی روزانه   ۲) پیش‌بینی منحنی فراموشی   ۳) کارت مرور شخصی‌سازی‌شده از یادداشت‌های من
 *  ۴) آزمون خودساز از درس  ۵) برنامه هفتگی تطبیقی (به‌همراه فرمان‌های صوتی یادگیری)
 *
 * همه پرس‌وجوها *Safe هستند (نبود جدول/ستون صفحه را نمی‌شکند) و همه نوشتن‌ها
 * با شرط مالکیت (owner_user_id) انجام می‌شود تا هیچ کاربری روی کارت دیگری اثر نگذارد.
 */
final class LearnerCoachService
{
    /** نرخ فرسودگی حافظه: نیمه‌عمر تقریبی = فاصله مرور × ضریب آسانی */
    private const DECAY_UNIT_DAYS = 1.0;

    /** ═══════════════ ۱. بریفینگ صوتی روزانه ═══════════════ */
    public static function briefing(int $uid, ?array $user = null): array
    {
        $user = $user ?? (Auth::user() ?: ['id' => $uid, 'role' => 'learner', 'full_name' => 'فراگیر']);
        $rep = VoiceReportStudioService::generate('my_daily_brief', $user, 'browser_tts');
        $forecast = self::forgettingForecast($uid);
        $plan = self::weeklyPlan($uid);

        $due = (int)($forecast['due_today'] ?? 0);
        $nextAction = $due > 0
            ? ('امروز ' . Jalali::digits((string)$due) . ' کارت در انتظار مرور است؛ یک نشست ۱۵ دقیقه‌ای لایتنر، بار فردا را نصف می‌کند.')
            : ('مروری سررسیدشده ندارید — بهترین زمان برای دیدن درس بعدی یا ساخت آزمون خودساز همین حالا است.');
        if (!empty($plan['tomorrow_lessons'])) {
            $nextAction .= ' در برنامه فردا: ' . Jalali::digits((string)$plan['tomorrow_lessons']) . ' درس عقب‌افتاده دارید.';
        }

        $chips = [
            ' ' . Jalali::digits((string)$due) . ' کارت مرور امروز',
            '🧠 حفظ ' . Jalali::digits((string)(int)round($forecast['retention_pct'])) . '٪',
            '️ ' . Jalali::digits((string)count($plan['days'])) . ' روز برنامه',
            '🎙️ ' . Jalali::digits((string)(int)ceil(((int)($rep['est_duration_sec'] ?? 45)) / 15)) . ' ثانیه گفتار',
        ];

        return [
            'ok' => (bool)($rep['ok'] ?? false),
            'title' => 'بریفینگ صوتی امروز من',
            'speech_text' => trim((string)($rep['speech_text'] ?? $nextAction) . ' ' . $nextAction),
            'narrative' => (string)($rep['narrative'] ?? $nextAction),
            'metrics' => $rep['metrics'] ?? [],
            'report_code' => (string)($rep['report_code'] ?? ''),
            'est_duration_sec' => (int)($rep['est_duration_sec'] ?? 45),
            'chips' => $chips,
            'next_action' => $nextAction,
            'forecast' => $forecast,
            'plan' => $plan,
            'created_shamsi' => (string)($rep['created_shamsi'] ?? Jalali::today()),
        ];
    }

    /** ═══════════════ ۲. پیش‌بینی منحنی فراموشی (R(t)=e^(-t/S)) ═══════════════ */
    public static function forgettingForecast(int $uid, int $horizonDays = 14): array
    {
        $horizonDays = max(7, min(30, $horizonDays));
        $cards = self::coachCards($uid);

        $dueToday = 0;
        $fading = [];
        $retentions = [];
        foreach ($cards as $c) {
            $interval = max(0.5, (float)($c['interval_days'] ?? 1));
            $ease = max(1.3, (float)($c['ease_factor'] ?? 2.5));
            $box = max(1, (int)($c['leitner_box'] ?? 1));
            $stability = max(1.0, $interval * $ease * self::DECAY_UNIT_DAYS);
            $elapsed = max(0, (5 - $box) * 0.9);
            $r = exp(-$elapsed / $stability);
            $retentions[] = $r;
            if ($box <= 2) {
                $dueToday++;
            }
            if ($r < 0.86 && count($fading) < 4) {
                $fading[] = [
                    'id' => (int)$c['id'],
                    'prompt' => mb_substr((string)$c['front_prompt'], 0, 74, 'UTF-8'),
                    'box' => $box,
                    'retention_pct' => (int)round($r * 100),
                    'personal' => ((int)($c['owner_user_id'] ?? 0)) === $uid,
                ];
            }
        }
        $avg = $retentions === [] ? 0.0 : array_sum($retentions) / count($retentions);

        // منحنی ۳۰ روزه: میانگین حفظ کل دسته در روزهای آینده (برای رسم SVG)
        $series = [];
        $peak = max(1, count($cards));
        for ($d = 0; $d <= $horizonDays; $d++) {
            $sum = 0.0;
            foreach ($cards as $c) {
                $interval = max(0.5, (float)($c['interval_days'] ?? 1));
                $ease = max(1.3, (float)($c['ease_factor'] ?? 2.5));
                $box = max(1, (int)($c['leitner_box'] ?? 1));
                $stability = max(1.0, $interval * $ease * self::DECAY_UNIT_DAYS);
                $elapsed = max(0, (5 - $box) * 0.9) + $d;
                $sum += exp(-$elapsed / $stability);
            }
            $series[] = $peak > 0 ? round(100 * $sum / $peak, 1) : 100.0;
        }

        $savedMinutes = (int)round($peak * 1.1);
        return [
            'cards_total' => $peak,
            'due_today' => $dueToday,
            'retention_pct' => round($avg * 100, 1),
            'fading' => $fading,
            'series' => $series,
            'horizon_days' => $horizonDays,
            'sparkline' => self::sparklinePath($series),
            'advice' => $avg > 0.9
                ? 'وضعیت تثبیت عالی است؛ فاصله مرورها را دو برابر کنید تا وقتتان آزاد شود.'
                : ($avg > 0.8
                    ? 'یک مرور کوتاه ۱۵ دقیقه‌ای کافی است تا منحنی حفظ بالای خط هشتاد‌وپنج درصد بماند.'
                    : 'هشدار: منحنی حفظ شما شیب افت دارد. امروز فقط کارت‌های خانه ۱ و ۲ را مرور کنید.'),
            'saved_minutes' => $savedMinutes,
            'saved_note' => 'مرور به‌موقع امروز، حدود ' . Jalali::digits((string)$savedMinutes) . ' دقیقه جبرانی در هفته بعد صرفه‌جویی می‌کند.',
        ];
    }

    /** ═══════════════ ۳. ساخت کارت مرور شخصی از یادداشت‌ها و درس‌های خودم ═══════════════ */
    public static function generatePersonalCards(int $uid, int $want = 6): array
    {
        $want = max(1, min(12, $want));
        $made = [];
        $skipped = 0;

        $notes = Database::fetchAllSafe(
            'SELECT n.id, n.note_body, n.video_timestamp, l.title AS lesson_title, c.title AS course_title
             FROM lms_learner_notes n
             LEFT JOIN lms_lessons l ON l.id = n.lesson_id
             LEFT JOIN courses c ON c.id = l.course_id
             WHERE n.user_id = ?
             ORDER BY n.id DESC LIMIT 24',
            [$uid]
        );
        foreach ($notes as $n) {
            if (count($made) >= $want) {
                break;
            }
            $body = trim((string)($n['note_body'] ?? ''));
            if (mb_strlen($body, 'UTF-8') < 8) {
                continue;
            }
            $lesson = trim((string)($n['lesson_title'] ?? '')) ?: 'درس من';
            $ts = trim((string)($n['video_timestamp'] ?? '')) ?: '۰۰:۰۰';
            $cue = $body;
            if (mb_strlen($cue, 'UTF-8') > 88) {
                $cue = mb_substr($cue, 0, 88, 'UTF-8') . '…';
            }
            $front = '🎬 یادداشت من در «' . $lesson . '» (دقیقه ' . $ts . '): ' . $cue . ' — کاملش را بگویید';
            $back = $body . ' (منبع: یادداشت ثانیه‌ای خودتان در ' . ($n['course_title'] ?? 'دوره من') . ')';
            $res = self::insertPersonalCard($uid, $front, $back, 'شخصی · یادداشت‌های من', 'note:' . (int)$n['id']);
            if ($res === 'duplicated') {
                $skipped++;
                continue;
            }
            $made[] = $res;
        }

        // اگر یادداشت کم بود، از شناسنامه خود دوره‌ها کارت تحکیمی می‌سازیم
        if (count($made) < $want) {
            $lessons = Database::fetchAllSafe(
                'SELECT l.id, l.title, l.content_type, l.estimated_minutes, c.title AS course_title, c.duration_hours, c.level
                 FROM lms_lessons l
                 JOIN courses c ON c.id = l.course_id
                 JOIN enrollments e ON e.run_id IN (SELECT id FROM course_runs WHERE course_id = c.id)
                 WHERE e.user_id = ?
                 ORDER BY l.id DESC LIMIT 24',
                [$uid]
            );
            if ($lessons === []) {
                $lessons = Database::fetchAllSafe(
                    'SELECT l.id, l.title, l.content_type, l.estimated_minutes, c.title AS course_title, c.duration_hours, c.level
                     FROM lms_lessons l JOIN courses c ON c.id = l.course_id ORDER BY l.id DESC LIMIT 12'
                );
            }
            foreach ($lessons as $l) {
                if (count($made) >= $want) {
                    break;
                }
                $front = '📌 در دوره «' . (string)$l['course_title'] . '»؛ درس «' . (string)$l['title'] . '» چه قالبی دارد و چند دقیقه زمان می‌برد؟';
                $back = 'قالب: ' . self::humanType((string)($l['content_type'] ?? 'video')) . ' • زمان: '
                    . Jalali::digits((string)(int)($l['estimated_minutes'] ?? 25)) . ' دقیقه • سطح دوره: '
                    . self::humanLevel((string)($l['level'] ?? 'mid')) . ' • بار کل دوره: '
                    . Jalali::digits((string)(int)($l['duration_hours'] ?? 12)) . ' ساعت';
                $res = self::insertPersonalCard($uid, $front, $back, 'شخصی · درس‌های من', 'lesson:' . (int)$l['id']);
                if ($res === 'duplicated') {
                    $skipped++;
                    continue;
                }
                $made[] = $res;
            }
        }

        self::recordFeature($uid, 'personal_cards', 'ساخت ' . count($made) . ' کارت شخصی', count($made));
        return [
            'created' => count($made),
            'skipped' => $skipped,
            'codes' => array_column($made, 'card_code'),
            'message' => $made === []
                ? ($skipped > 0
                    ? 'همه کارت‌های ممکن از پیش در جعبه لایتنر شخصی شما هستند (' . Jalali::digits((string)$skipped) . ' مورد تکراری رد شد) — همین‌ها را مرور کنید'
                    : 'شما هنوز یادداشت یا درس دسترسی‌پذیری ندارید که به کارت تبدیل شود — یک یادداشت ثانیه‌ای در LMS بنویسید و دوباره بزنید.')
                : (Jalali::digits((string)count($made)) . ' کارت شخصی جدید در خانه ۱ جعبه لایتنر شما ساخته شد' . ($skipped ? ' (' . Jalali::digits((string)$skipped) . ' کارت تکراری رد شد)' : '') . '.'),
        ];
    }

    private static function insertPersonalCard(int $uid, string $front, string $back, string $category, string $sourceRef): array|string
    {
        $dup = Database::fetchOneSafe(
            'SELECT id, card_code FROM micro_spaced_flashcards WHERE owner_user_id = ? AND source_ref = ? LIMIT 1',
            [$uid, $sourceRef]
        );
        if (is_array($dup)) {
            return 'duplicated';
        }
        $seq = (int)Database::scalarSafe('SELECT COALESCE(MAX(id),0) FROM micro_spaced_flashcards') + 1;
        $code = 'PFC-' . $uid . '-' . str_pad((string)$seq, 4, '0', STR_PAD_LEFT);
        try {
            Database::insert(
                'INSERT INTO micro_spaced_flashcards
                    (card_code, deck_category, front_prompt, back_answer, leitner_box, ease_factor, interval_days, next_review_label, reviews_count, owner_user_id, source_kind, source_ref)
                 VALUES (?,?,?,?,1,2.50,1,?,0,?,?,?)',
                [
                    $code, mb_substr($category, 0, 88, 'UTF-8'), mb_substr($front, 0, 900, 'UTF-8'), mb_substr($back, 0, 1400, 'UTF-8'),
                    'موعد مرور: امروز 🔥', $uid, 'ai_personal', $sourceRef,
                ]
            );
        } catch (\Throwable) {
            return 'duplicated';
        }
        return ['card_code' => $code, 'front_prompt' => $front];
    }

    public static function deletePersonalCard(int $uid, int $cardId): bool
    {
        return Database::execute('DELETE FROM micro_spaced_flashcards WHERE id = ? AND owner_user_id = ?', [$cardId, $uid]) > 0;
    }

    /** دسته مرور فراگیر = کارت‌های عمومی کاتالوگ + کارت‌های شخصی خودش */
    public static function coachCards(int $uid): array
    {
        return Database::fetchAllSafe(
            'SELECT * FROM micro_spaced_flashcards
             WHERE owner_user_id IS NULL OR owner_user_id = ?
             ORDER BY (owner_user_id IS NOT NULL) DESC, leitner_box ASC, id DESC',
            [$uid]
        );
    }

    /** ═══════════════ ۴. آزمون خودساز از محتوای دوره (نسل خودکار و تصحیح آنی) ═══════════════ */
    public static function buildSelfQuiz(int $uid, int $courseId): array
    {
        $course = Database::fetchOneSafe('SELECT * FROM courses WHERE id = ?', [$courseId])
            ?? Database::fetchOneSafe('SELECT * FROM courses ORDER BY id ASC LIMIT 1') ?? [];
        if ($course === []) {
            return ['ok' => false, 'questions' => [], 'message' => 'دوره‌ای برای ساخت سؤال پیدا نشد.'];
        }
        $cid = (int)($course['id'] ?? 1);
        $title = (string)($course['title'] ?? 'دوره من');
        $lessons = Database::fetchAllSafe('SELECT * FROM lms_lessons WHERE course_id = ? ORDER BY sort_order ASC, id ASC LIMIT 12', [$cid]);
        $levels = array_values(array_unique(array_column(
            Database::fetchAllSafe('SELECT DISTINCT level FROM courses WHERE level IS NOT NULL AND level <> "" LIMIT 8'),
            'level'
        )));
        $types = array_values(array_unique(array_column(
            Database::fetchAllSafe('SELECT DISTINCT content_type FROM lms_lessons WHERE content_type IS NOT NULL LIMIT 8'),
            'content_type'
        )));
        $tuitions = array_values(array_filter(array_map('intval', array_column(
            Database::fetchAllSafe('SELECT tuition_rial FROM courses ORDER BY id ASC LIMIT 8'),
            'tuition_rial'
        ))));

        $q = [];
        // ۱) بار ساعتی دوره
        $realHours = (int)($course['duration_hours'] ?? 12);
        $q[] = self::mcq(
            'دوره «' . $title . '» چند ساعت بار آموزشی دارد؟',
            self::numericOptions($realHours, [2, 4, 8], 1, ' ساعت'),
            Jalali::digits((string)$realHours) . ' ساعت',
            'این عدد از شناسنامه رسمی دوره در سامانه آموزش گرفته شده است.'
        );
        // ۲) سطح دوره
        $realLevel = self::humanLevel((string)($course['level'] ?? 'mid'));
        $levelOpts = array_values(array_unique(array_merge([$realLevel], array_map([self::class, 'humanLevel'], $levels))));
        $q[] = self::mcq('سطح آموزشی دوره «' . $title . '» کدام است؟',
            self::padOptions($levelOpts, $realLevel, ['مقدماتی', 'میانی', 'پیشرفته', 'مدیریتی ویژه', 'تخصصی ارشد']), $realLevel,
            'انتخاب دوره هم‌سطح، احتمال تکمیل دوره را به‌طور معناداری بالا می‌برد.');
        // ۳) قالب تدریس
        $mode = self::humanMode((string)($course['delivery_mode'] ?? 'hybrid'));
        $q[] = self::mcq('شیوه ارائه دوره «' . $title . '» چیست؟',
            self::padOptions([$mode], $mode, ['حضوری', 'آنلاین همزمان', 'ترکیبی', 'خودگردان (فایل و متن)']), $mode,
            'شیوه ارائه در تقویم گروه‌های اجراشده قابل مشاهده است.');
        // ۴) تخفیف اعضا
        $disc = (int)($course['member_discount_pct'] ?? 0);
        $q[] = self::mcq('تخفیف ویژه فراگیران آدان برای این دوره چند درصد است؟',
            self::numericOptions($disc, [5, 10, 15], 1, '٪'), Jalali::digits((string)$disc) . '٪',
            'کد تخفیف اعضا هنگام ثبت‌نام به‌صورت خودکار اعمال می‌شود.');
        // ۵) از درس‌ها
        if ($lessons !== []) {
            $ls = $lessons[array_rand($lessons)];
            $askMinutes = ((int)($ls['id'] ?? 0) % 2 === 0);
            if ($askMinutes) {
                $real = (int)($ls['estimated_minutes'] ?? 25);
                $q[] = self::mcq('دیدن درس «' . (string)$ls['title'] . '» حداقل چند دقیقه زمان می‌برد؟',
                    self::numericOptions($real, [5, 10, 15], 5, ' دقیقه'), Jalali::digits((string)$real) . ' دقیقه',
                    'برنامه‌ریزی زمان مطالعه بر پایه زمان واقعی درس، ریسک عقب‌ماندگی را کم می‌کند.');
            } else {
                $t = self::humanType((string)($ls['content_type'] ?? 'video'));
                $typeOpts = array_values(array_unique(array_merge([$t], array_map([self::class, 'humanType'], $types))));
                $q[] = self::mcq('قالب محتوای درس «' . (string)$ls['title'] . '» کدام است؟',
                    self::padOptions($typeOpts, $t, ['ویدئوی سینمایی با آزمونک', 'میکروپادکست صوتی', 'جزوه PDF', 'بسته SCORM تعاملی', 'متن آموزشی']), $t,
                    'قالب درس از فهرست سرفصل‌های LMS قابل مشاهده است.');
            }
        }
        // ۶) مقایسه شهریه با دوره دیگر (تحلیل داده)
        $othersRows = array_values(array_filter(
            Database::fetchAllSafe('SELECT id, title, tuition_rial FROM courses WHERE id <> ? AND tuition_rial > 0 ORDER BY id ASC LIMIT 4', [$cid]),
            static fn($r) => (int)($r['tuition_rial'] ?? 0) !== (int)($course['tuition_rial'] ?? 0)
        ));
        $others = array_column($othersRows, 'tuition_rial');
        $othersTitles = array_column($othersRows, 'title');
        if ($others !== []) {
            $real = (int)($course['tuition_rial'] ?? 0);
            $other = (int)$others[0];
            $verdict = $real > $other ? 'بالاتر' : ($real < $other ? 'پایین‌تر' : 'برابر');
            $q[] = self::mcq('نسبت به دوره «' . (string)($othersTitles[0] ?? 'دیگر دوره‌ها') . '»، شهریه این دوره … است.',
                self::padOptions(['بالاتر', 'پایین‌تر', 'برابر', 'نامعلوم'], $verdict), $verdict,
                'مقایسه شهریه با سایر دوره‌ها در ویترین کاتالوگ TMS امکان‌پذیر است.');
        }

        return [
            'ok' => true,
            'course_id' => $cid,
            'course_title' => $title,
            'token' => substr(md5($uid . '|' . $cid . microtime()), 0, 10),
            'questions' => array_slice($q, 0, 6),
            'created_shamsi' => Jalali::today(),
        ];
    }

    public static function gradeSelfQuiz(int $uid, string $userName, array $quiz, array $answers): array
    {
        $questions = $quiz['questions'] ?? [];
        $total = count($questions);
        if ($total === 0) {
            return ['ok' => false, 'score_pct' => 0, 'rows' => [], 'message' => 'سؤالی برای تصحیح وجود نداشت.'];
        }
        $rows = [];
        $right = 0;
        foreach ($questions as $i => $qq) {
            $picked = trim((string)($answers[$i] ?? ''));
            $correct = (string)($qq['correct'] ?? '');
            $isRight = $picked !== '' && $picked === $correct;
            if ($isRight) {
                $right++;
            }
            $rows[] = [
                'n' => $i + 1,
                'q' => (string)($qq['q'] ?? ''),
                'picked' => $picked === '' ? '—' : $picked,
                'correct' => $correct,
                'ok' => $isRight,
                'why' => (string)($qq['why'] ?? ''),
            ];
        }
        $pct = (int)round(100 * $right / $total);
        $xp = 20 + 12 * $right;
        $verdict = $pct >= 85
            ? 'عالی! این بخش را می‌توانید تثبیت‌شده علامت بزنید و به درس بعدی بروید.'
            : ($pct >= 60
                ? 'خوب است؛ فقط ردیف‌های اشتباه را امروز یک بار دیگر مرور کنید.'
                : 'این بخش هنوز ناپایدار است — پیشنهاد مربی: درس را یک بار دیگر ببینید و یادداشت ثانیه‌ای بزنید.');

        try {
            LearnerBehaviorGamificationService::recordTelemetryAndAwardXp(
                $uid, $userName, 'microlearning&tab=selfquiz', 'آزمون خودساز از محتوای دوره (' . $pct . '٪)', 180, 100, $xp
            );
        } catch (\Throwable) {
            // ثبت XP نباید نتیجه آزمون را از بین ببرد
        }
        self::recordFeature($uid, 'self_quiz', (string)($quiz['course_title'] ?? 'دوره من'), $pct, ['right' => $right, 'total' => $total, 'xp' => $xp]);

        return [
            'ok' => true,
            'score_pct' => $pct,
            'right' => $right,
            'total' => $total,
            'xp' => $xp,
            'rows' => $rows,
            'verdict' => $verdict,
            'next_step' => $pct >= 85
                ? 'کارت‌های این بخش را با «یادم هست» مرور کنید تا از جعبه لایتنر خارج شوند.'
                : 'برای این بخش کارت مرور شخصی بسازید؛ فردا یک بار مرور، همین اشتباه‌ها را حذف می‌کند.',
        ];
    }

    /** ═══════════════ ۵. برنامه هفتگی تطبیقی ═══════════════ */
    public static function weeklyPlan(int $uid): array
    {
        $forecast = self::forgettingForecast($uid, 7);
        $due = (int)$forecast['due_today'];
        $pendingLessons = (int)Database::scalarSafe(
            'SELECT COUNT(*) FROM lms_lessons l
             WHERE l.id NOT IN (SELECT lesson_id FROM lms_progress WHERE user_id = ? AND is_completed = 1)',
            [$uid]
        );
        $openInvoices = (int)Database::scalarSafe('SELECT COUNT(*) FROM invoices WHERE user_id = ? AND status IN ("unpaid", "partial")', [$uid]);
        $myNotes = (int)Database::scalarSafe('SELECT COUNT(*) FROM lms_learner_notes WHERE user_id = ?', [$uid]);

        $labels = ['امروز 🔥', 'فردا', '۲ روز بعد', '۳ روز بعد', '۴ روز بعد', '۵ روز بعد', 'پایان هفته 🎉'];
        $cardsLeft = max(0, $due);
        $lessonsLeft = max(0, $pendingLessons);
        $days = [];
        foreach ($labels as $i => $lab) {
            $perDay = $cardsLeft > 0 ? (int)ceil($cardsLeft / max(1, 7 - $i)) : 0;
            $cardsLeft -= $perDay;
            $lPerDay = $lessonsLeft > 0 ? (int)ceil($lessonsLeft / max(1, 7 - $i)) : 0;
            $lessonsLeft -= $lPerDay;
            $items = [];
            if ($perDay > 0) {
                $items[] = Jalali::digits((string)$perDay) . ' کارت لایتنر (' . ($i === 0 ? 'مرور فوری' : 'مرور تثبیت') . ')';
            }
            if ($lPerDay > 0) {
                $items[] = Jalali::digits((string)$lPerDay) . ' درس عقب‌افتاده LMS';
            }
            if ($i === 2 && $myNotes > 0) {
                $items[] = 'بازخوانی یادداشت‌های من و ساخت کارت جدید';
            }
            if ($i === 5 && $openInvoices > 0) {
                $items[] = 'تسویه ' . Jalali::digits((string)$openInvoices) . ' فاکتور باز (برای حفظ تخفیف اعضا)';
            }
            if ($items === []) {
                $items[] = 'استراحت فعال: یک میکروکپسول ۳ دقیقه‌ای';
            }
            $days[] = ['label' => $lab, 'minutes' => 15 + 12 * count($items), 'items' => $items];
        }
        return [
            'days' => $days,
            'total_minutes' => array_sum(array_column($days, 'minutes')),
            'pending_lessons' => $pendingLessons,
            'tomorrow_lessons' => 0,
            'open_invoices' => $openInvoices,
            'notes_count' => $myNotes,
            'print_note' => 'این برنامه را می‌توانید با کلید چاپ مرورگر (Ctrl+P) روی کاغذ A4 نگه دارید.',
        ];
    }

    /** ثبت تله‌متری قابلیت (برای گزارش پذیرش مدیران) */
    public static function recordFeature(int $uid, string $featureKey, string $refLabel, int $score = 0, array $detail = []): void
    {
        try {
            Database::insert(
                'INSERT INTO learner_ai_telemetry (user_id, feature_key, ref_label, score_value, detail_json, created_shamsi) VALUES (?,?,?,?,?,?)',
                [$uid, mb_substr($featureKey, 0, 58, 'UTF-8'), mb_substr($refLabel, 0, 230, 'UTF-8'), $score,
                 $detail === [] ? null : json_encode($detail, JSON_UNESCAPED_UNICODE), Jalali::today()]
            );
        } catch (\Throwable) {
            // تله‌متری هیچ‌وقت جریان کار کاربر را نمی‌شکند
        }
    }

    /** بسته کامل برای پیشخوان فراگیر (یک‌بار محاسبه، چند کارت) */
    public static function coachBundle(int $uid, ?array $user = null): array
    {
        $forecast = self::forgettingForecast($uid);
        $plan = self::weeklyPlan($uid);
        $personal = (int)Database::scalarSafe('SELECT COUNT(*) FROM micro_spaced_flashcards WHERE owner_user_id = ?', [$uid]);
        $notes = (int)Database::scalarSafe('SELECT COUNT(*) FROM lms_learner_notes WHERE user_id = ?', [$uid]);
        $courses = Database::fetchAllSafe(
            'SELECT DISTINCT c.id, c.title, c.level FROM enrollments e
             JOIN course_runs r ON r.id = e.run_id JOIN courses c ON c.id = r.course_id
             WHERE e.user_id = ? ORDER BY c.id DESC LIMIT 6',
            [$uid]
        );
        if ($courses === []) {
            $courses = Database::fetchAllSafe('SELECT id, title, level FROM courses ORDER BY id ASC LIMIT 6');
        }
        $features = [
            ['key' => 'voice_briefing', 'title' => 'بریفینگ صوتی امروز', 'icon' => '🎙️', 'state' => $forecast['due_today'] . ' کارت آماده', 'hint' => 'با یک کلیک، وضعیت امروزتان را بشنوید'],
            ['key' => 'personal_cards', 'title' => 'کارت‌سازی خودکار از یادداشت‌ها', 'icon' => '🃏', 'state' => $personal . ' کارت شخصی از ' . $notes . ' یادداشت', 'hint' => 'یادداشت‌های ثانیه‌ای شما به جعبه لایتنر تبدیل می‌شوند'],
            ['key' => 'self_quiz', 'title' => 'آزمون خودساز از همین درس', 'icon' => '🎯', 'state' => '۶ سؤال چهارگزینه‌ای، تصحیح آنی', 'hint' => 'بدون نیاز به استاد، خودتان بسنجید و XP بگیرید'],
            ['key' => 'forgetting', 'title' => 'پیش‌بینی منحنی فراموشی', 'icon' => '🧠', 'state' => 'حفظ فعلی ' . round($forecast['retention_pct'], 1) . '٪', 'hint' => 'کدام کارت‌ها تا ۴۸ ساعت آینده کمرنگ می‌شوند'],
            ['key' => 'weekly_plan', 'title' => 'برنامه هفتگی تطبیقی', 'icon' => '🗓️', 'state' => $plan['total_minutes'] . ' دقیقه در ۷ روز', 'hint' => 'قابل چاپ روی A4 و خودکار در تقویم شمسی'],
        ];
        foreach ($features as &$f) {
            $f['state'] = Jalali::digits((string)$f['state']);
        }
        unset($f);
        return [
            'forecast' => $forecast,
            'plan' => $plan,
            'features' => $features,
            'courses' => $courses,
            'personal_cards' => $personal,
            'notes_count' => $notes,
            'deck' => self::coachCards($uid),
        ];
    }

    // ───────────────────────── کمک‌متدها ─────────────────────────
    private static function mcq(string $q, array $options, string $correct, string $why): array
    {
        shuffle($options);
        return ['q' => $q, 'options' => array_values($options), 'correct' => $correct, 'why' => $why];
    }

    /** سه‌کننده گزینه‌های چهارگزینه‌ای: پاسخ صحیح + گزینه‌های واقع‌یافتنی (بدون متن ساختگی) */
    private static function padOptions(array $options, string $must, array $fillers = []): array
    {
        $pool = array_values(array_unique(array_filter(array_map('strval', $options), static fn($v) => $v !== '')));
        if (!in_array($must, $pool, true)) {
            array_unshift($pool, $must);
        }
        foreach ($fillers as $filler) {
            if (count($pool) >= 4) {
                break;
            }
            $f = trim((string)$filler);
            if ($f !== '' && !in_array($f, $pool, true)) {
                $pool[] = $f;
            }
        }
        foreach (['هیچ‌کدام از موارد', 'نامشخص', 'در متن نیامده'] as $lastResort) {
            if (count($pool) >= 4) {
                break;
            }
            if (!in_array($lastResort, $pool, true)) {
                $pool[] = $lastResort;
            }
        }
        return array_slice($pool, 0, 4);
    }

    /** گزینه‌های عددی: پاسخ صحیح و نزدیک‌ترین انحراف‌ها (زیر و بالایی) */
    private static function numericOptions(int $real, array $offsets, int $multiplier = 1, string $suffix = ''): array
    {
        $opts = [Jalali::digits((string)$real) . $suffix];
        $signs = [1, -1, 1, -1];
        foreach ($offsets as $i => $off) {
            $delta = (int)round($off * $multiplier * ($signs[$i] ?? 1));
            $v = $real + $delta;
            if ($v <= 0 || $v === $real) {
                $v = $real + abs($delta);
            }
            $txt = Jalali::digits((string)$v) . $suffix;
            if (!in_array($txt, $opts, true)) {
                $opts[] = $txt;
            }
            if (count($opts) >= 4) {
                break;
            }
        }
        return array_slice($opts, 0, 4);
    }

    private static function humanLevel(string $l): string
    {
        if (preg_match('/[\x{0600}-\x{06FF}]/u', $l) === 1) {
            return $l !== '' ? $l : 'میانی';
        }
        return match ($l) {
            'intro', 'beginner' => 'مقدماتی',
            'advanced' => 'پیشرفته',
            'expert' => 'تخصصی ارشد',
            default => 'میانی',
        };
    }

    private static function humanMode(string $m): string
    {
        if (preg_match('/[\x{0600}-\x{06FF}]/u', $m) === 1) {
            return $m !== '' ? $m : 'ترکیبی';
        }
        return match ($m) {
            'onsite', 'in_person' => 'حضوری در کارگاه',
            'online' => 'وبینار زنده + فایل',
            'self_paced' => 'خودگردان (فایل و متن)',
            default => 'ترکیبی (حاضر + مجازی)',
        };
    }

    private static function humanType(string $t): string
    {
        return match ($t) {
            'video' => 'ویدئوی سینمایی با آزمونک',
            'audio' => 'میکروپادکست صوتی',
            'pdf' => 'جزوه PDF',
            'scorm' => 'بسته SCORM تعاملی',
            'article' => 'متن آموزشی',
            default => 'ویدئوی سینمایی با آزمونک',
        };
    }

    /** مسیر SVG برای اسپارک‌لاین منحنی حفظ */
    private static function sparklinePath(array $series): string
    {
        $n = count($series);
        if ($n < 2) {
            return '';
        }
        $w = 300;
        $h = 74;
        $pts = [];
        foreach ($series as $i => $v) {
            $x = $n > 1 ? round($i * $w / ($n - 1), 1) : 0;
            $y = round($h - (max(0, min(100, (float)$v)) / 100) * $h, 1);
            $pts[] = $x . ',' . $y;
        }
        return 'M ' . implode(' L ', $pts);
    }
}
