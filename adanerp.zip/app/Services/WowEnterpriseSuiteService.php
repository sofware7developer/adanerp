<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database;

final class WowEnterpriseSuiteService
{
    public static function socialPlatformsMeta(): array
    {
        return [
            'instagram'  => ['label' => 'اینستاگرام (پست / ریلز / استوری)', 'icon' => '📸', 'color' => '#E1306C', 'avg_ctr' => '۴.۸٪'],
            'linkedin'   => ['label' => 'لینکدین سازمانی (B2B مدیران)', 'icon' => '💼', 'color' => '#0A66C2', 'avg_ctr' => '۶.۴٪'],
            'telegram'   => ['label' => 'کانال و سوپرگروه‌های تلگرام', 'icon' => '✈️', 'color' => '#229ED9', 'avg_ctr' => '۵.۹٪'],
            'youtube'    => ['label' => 'یوتیوب و آپارات آموزشی', 'icon' => '🎬', 'color' => '#FF0000', 'avg_ctr' => '۴.۱٪'],
            'whatsapp'   => ['label' => 'واتساپ بیزینس (ارسال مستقیم VIP)', 'icon' => '💬', 'color' => '#25D366', 'avg_ctr' => '۱۱.۲٪'],
            'eitaa_bale' => ['label' => 'ایتا، بله و روبیکا (شبکه بومی)', 'icon' => '🟢', 'color' => '#0D9488', 'avg_ctr' => '۵.۳٪'],
            'x_twitter'  => ['label' => 'ایکس (رشته‌توییت تحلیلی اقتصادی)', 'icon' => '𝕏', 'color' => '#0F172A', 'avg_ctr' => '۳.۲٪'],
            'sms_vip'    => ['label' => 'پیامک هدفمند و ایمیل سازمانی', 'icon' => '📩', 'color' => '#D97706', 'avg_ctr' => '۷.۵٪'],
        ];
    }

    public static function aiBuildCompleteCourseBlueprint(string $prompt, int $userId = 1): array
    {
        $prompt = trim($prompt) !== '' ? trim($prompt) : 'کاربرد هوش مصنوعی در صادرات، گمرک و مذاکرات تجاری';
        $hours = 24;
        if (preg_match('/(\d{1,3})\s*ساعت/u', $prompt, $m)) {
            $hours = max(8, min(120, (int)$m[1]));
        }
        $cleanTitle = preg_replace('/^(یک\s+)?(دوره|کارگاه|بوت‌کمپ)\s+/u', '', $prompt) ?: $prompt;
        $title = 'دوره جامع ' . mb_substr(trim((string)$cleanTitle), 0, 140);
        $code = 'AI-' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 5));
        $tuition = max(28000000, $hours * 2100000);

        $catRow = Database::fetchOne('SELECT id FROM course_categories ORDER BY id ASC LIMIT 1');
        $catId = (int)($catRow['id'] ?? 1);

        $courseId = Database::insert(
            'INSERT INTO courses (category_id, code, title, level, delivery_mode, duration_hours, tuition_rial, member_discount_pct, workflow_status, summary)
             VALUES (?, ?, ?, "پیشرفته", "ترکیبی", ?, ?, 25, "published", ?)',
            [
                $catId,
                $code,
                $title,
                $hours,
                $tuition,
                'طراحی‌شده توسط موتور هوش مصنوعی آموزش مؤسسه آموزشی آدان شامل کارگاه‌های عملی، مطالعه موردی واقعی، آزمونک تعاملی و پروژه نهایی.',
            ]
        );

        $runCode = $code . '-R1';
        $runId = Database::insert(
            'INSERT INTO course_runs (course_id, instructor_id, classroom_id, run_code, term_label, start_date, end_date, start_shamsi, schedule_text, capacity, enrolled_count, status)
             VALUES (?, 3, 1, ?, "نیمسال ویژه هوش تجاری ۱۴۰۵", CURDATE(), DATE_ADD(CURDATE(), INTERVAL 28 DAY), "۱۴۰۵/۰۸/۱۲", "شنبه‌ها و دوشنبه‌ها ۱۶:۰۰ تا ۲۰:۰۰", 32, 6, "registration")',
            [$courseId, $runCode]
        );

        $sessionTitles = [
            'مبانی راهبردی، چارچوب‌های استاندارد و تحلیل روندهای جهانی ' . mb_substr($cleanTitle, 0, 50),
            'کارگاه عملی ابزارهای هوشمند، مستندسازی و شاخص‌های کلیدی عملکرد',
            'شبیه‌سازی پرونده واقعی شرکت‌های صادراتی و مدیریت ریسک‌های اجرایی',
            'کلینیک عارضه‌یابی، دفاع از پروژه عملیاتی و صدور گواهینامه QR',
        ];
        foreach ($sessionTitles as $idx => $sTitle) {
            Database::insert(
                'INSERT INTO course_sessions (run_id, session_number, title, session_date, session_shamsi, start_time, end_time, room_or_link, is_held)
                 VALUES (?, ?, ?, DATE_ADD(CURDATE(), INTERVAL ? DAY), ?, "16:00", "20:00", "تالار هوشمند خلیج فارس + پخش زنده HD", 0)',
                [$runId, $idx + 1, $sTitle, ($idx + 1) * 3, '۱۴۰۵/۰۸/' . str_pad((string)(12 + $idx * 3), 2, '0', STR_PAD_LEFT)]
            );
        }

        $chapterId = Database::insert(
            'INSERT INTO lms_chapters (course_id, title, sort_order) VALUES (?, ?, 1)',
            [$courseId, 'فصل اول: کارگاه اجرایی و تعاملی ' . mb_substr($cleanTitle, 0, 60)]
        );
        $firstLessonId = 0;
        foreach ($sessionTitles as $idx => $sTitle) {
            $lid = Database::insert(
                'INSERT INTO lms_lessons (chapter_id, course_id, sort_order, title, content_type, estimated_minutes, sequential_lock, body_html)
                 VALUES (?, ?, ?, ?, "video", 45, ?, ?)',
                [
                    $chapterId,
                    $courseId,
                    $idx + 1,
                    'درس ' . ($idx + 1) . ': ' . $sTitle,
                    $idx === 0 ? 0 : 1,
                    'در این درس ویدئویی تعاملی، گام‌به‌گام با چک‌لیست اجرایی، مطالعه موردی بومی ایران و الگوهای استاندارد بین‌المللی آشنا می‌شوید.',
                ]
            );
            if ($idx === 0) {
                $firstLessonId = $lid;
            }
        }

        if ($firstLessonId > 0) {
            Database::insert(
                'INSERT INTO lms_interactive_quizzes
                 (lesson_id, appear_at_sec, timestamp_label, question_text, opt_a, opt_b, opt_c, opt_d, correct_opt, ai_explanation, xp_reward)
                 VALUES (?, 120, "02:00", ?, ?, ?, ?, ?, "B", ?, 35)',
                [
                    $firstLessonId,
                    'مهم‌ترین مزیت پیاده‌سازی استاندارد اجرایی در «' . mb_substr($cleanTitle, 0, 50) . '» برای شرکت‌های طرف قرارداد مؤسسه آموزشی آدان چیست؟',
                    'صرفاً آرشیو کاغذی مستندات',
                    'کاهش ریسک عملیاتی، تسریع تصمیم‌گیری داده‌محور و رشد سودآوری',
                    'افزایش تشریفات اداری غیرضروری',
                    'حذف کامل نظارت مدیریتی',
                    'استفاده از چارچوب استاندارد و هوشمند مستقیماً ریسک خطای اجرایی را کاهش داده و بازده تجاری شرکت را افزایش می‌دهد.',
                ]
            );
        }

        return [
            'ok'              => true,
            'course_id'       => $courseId,
            'run_id'          => $runId,
            'code'            => $code,
            'run_code'        => $runCode,
            'title'           => $title,
            'hours'           => $hours,
            'tuition_rial'    => $tuition,
            'lessons_created' => 4,
        ];
    }

    public static function saveLearningPath(array $input, string $actorName = 'مدیر آموزش'): int
    {
        $title = trim((string)($input['title'] ?? 'دیپلم جامع مهارت‌های تجاری'));
        $persona = trim((string)($input['target_persona'] ?? 'مدیران بازرگانی و اجرایی'));
        $levelBadge = trim((string)($input['level_badge'] ?? 'دیپلم تخصصی QR مؤسسه آموزشی آدان'));
        $rawCourses = $input['courses_list'] ?? [];
        if (is_string($rawCourses)) {
            $decoded = json_decode($rawCourses, true);
            $coursesArr = is_array($decoded) ? $decoded : array_values(array_filter(array_map('trim', explode(',', $rawCourses))));
        } elseif (is_array($rawCourses)) {
            $coursesArr = array_values(array_filter(array_map('trim', $rawCourses)));
        } else {
            $coursesArr = [];
        }
        if (empty($coursesArr)) {
            $coursesArr = ['مبانی تجارت بین‌الملل', 'قراردادنویسی تجاری و اینکوترمز', 'مذاکرات حرفه‌ای و کلینیک صادرات'];
        }
        $hours = max(16, count($coursesArr) * 20);
        $tuition = max(35000000, (int)($input['bundle_tuition_rial'] ?? (count($coursesArr) * 34000000)));
        $discount = max(5, min(50, (int)($input['discount_pct'] ?? 25)));
        $code = 'LP-' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 5));

        return Database::insert(
            'INSERT INTO tms_learning_paths
             (path_code, title, target_persona, level_badge, courses_json, total_hours, bundle_tuition_rial, discount_pct, enrolled_learners, ai_roadmap_summary, status, created_shamsi)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, 14, ?, "active", "۱۴۰۵/۰۸/۰۲")',
            [
                $code,
                $title,
                $persona,
                $levelBadge,
                json_encode($coursesArr, JSON_UNESCAPED_UNICODE),
                $hours,
                $tuition,
                $discount,
                'مسیر مهارتی چندمرحله‌ای طراحی‌شده توسط ' . $actorName . ' با تخفیف پلکانی فراگیران آدان.',
            ]
        );
    }

    public static function savePricingScenario(array $input): array
    {
        $courseTitle = trim((string)($input['course_title'] ?? 'دوره تخصصی صادرات'));
        $baseTuition = max(5000000, (int)($input['base_tuition_rial'] ?? 50000000));
        $memberDisc = max(0, min(60, (int)($input['member_discount_pct'] ?? 25)));
        $earlyDisc = max(0, min(40, (int)($input['early_bird_pct'] ?? 10)));
        $instCost = max(10000000, (int)($input['instructor_total_cost_rial'] ?? 180000000));
        $opsCost = max(5000000, (int)($input['venue_ops_cost_rial'] ?? 65000000));

        $effectiveAvgFee = (int)round($baseTuition * (1 - (($memberDisc * 0.6 + $earlyDisc * 0.3) / 100)));
        $totalFixed = $instCost + $opsCost;
        $breakeven = max(1, (int)ceil($totalFixed / max(1, $effectiveAvgFee)));
        $elasticityFactor = max(12, min(42, (int)round(36 - ($baseTuition / 9000000) + ($memberDisc * 0.25))));
        $predicted = max($breakeven + 4, $elasticityFactor);
        $netProfit = ($predicted * $effectiveAvgFee) - $totalFixed;
        $scCode = 'PRC-' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 5));

        $id = Database::insert(
            'INSERT INTO tms_pricing_scenarios
             (scenario_code, course_title, base_tuition_rial, member_discount_pct, early_bird_pct, instructor_total_cost_rial, venue_ops_cost_rial, predicted_enrollments, breakeven_seats, projected_net_profit_rial, created_shamsi)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "۱۴۰۵/۰۸/۰۲")',
            [$scCode, $courseTitle, $baseTuition, $memberDisc, $earlyDisc, $instCost, $opsCost, $predicted, $breakeven, $netProfit]
        );

        return [
            'id'            => $id,
            'breakeven'     => $breakeven,
            'predicted'     => $predicted,
            'net_profit'    => $netProfit,
            'effective_fee' => $effectiveAvgFee,
        ];
    }

    public static function aiGenerateInteractiveLessonPackage(int $courseId, string $topicTitle): array
    {
        $topicTitle = trim($topicTitle) !== '' ? trim($topicTitle) : 'استراتژی‌های نوین مذاکره و مدیریت ریسک قرارداد';
        $ch = Database::fetchOne('SELECT id FROM lms_chapters WHERE course_id = ? ORDER BY sort_order ASC LIMIT 1', [$courseId]);
        $chapterId = $ch ? (int)$ch['id'] : Database::insert(
            'INSERT INTO lms_chapters (course_id, title, sort_order) VALUES (?, "فصل هوشمند تکمیلی", 9)',
            [$courseId]
        );

        $lessonId = Database::insert(
            'INSERT INTO lms_lessons (chapter_id, course_id, sort_order, title, content_type, estimated_minutes, sequential_lock, body_html)
             VALUES (?, ?, 9, ?, "video", 35, 0, ?)',
            [
                $chapterId,
                $courseId,
                'درس هوشمند تعاملی: ' . $topicTitle,
                "خلاصه اجرایی درس: در این مبحث کلیدی «{$topicTitle}»، ابتدا ۳ خطای رایج شرکت‌های ایرانی کالبدشکافی شده و سپس چک‌لیست استاندارد گام‌به‌گام ارائه می‌گردد.",
            ]
        );

        $quizId = Database::insert(
            'INSERT INTO lms_interactive_quizzes
             (lesson_id, appear_at_sec, timestamp_label, question_text, opt_a, opt_b, opt_c, opt_d, correct_opt, ai_explanation, xp_reward)
             VALUES (?, 95, "01:35", ?, ?, ?, ?, ?, "A", ?, 40)',
            [
                $lessonId,
                'در اجرای عملی «' . $topicTitle . '» نخستین اقدام کنترلی مدیر پروژه چیست؟',
                'تدوین چک‌لیست ارزیابی ریسک و مستندسازی شاخص‌های کلیدی پیش از امضا',
                'واگذاری کامل بدون نظارت به پیمانکار فرعی',
                'حذف مرحله راستی‌آزمایی مستندات مالی',
                'تغییر یک‌طرفه تعهدات پس از حمل',
                'مستندسازی شاخص‌های ریسک پیش از تعهد رسمی، جلوی ۸۵٪ اختلافات حقوقی و مالی بعدی را می‌گیرد.',
            ]
        );

        Database::insert(
            'INSERT INTO lms_ai_study_cards
             (course_id, lesson_id, card_type, title, content_body, mastery_tag, created_by_name, created_shamsi)
             VALUES (?, ?, "flashcard", ?, ?, "تسلط کاربردی پیشرفته", "دستیار هوشمند LMS", "۱۴۰۵/۰۸/۰۲")',
            [
                $courseId,
                $lessonId,
                'مهم‌ترین اصل طلایی در «' . $topicTitle . '» چیست؟',
                'انطباق دقیق مستندات اجرایی با استانداردهای رسمی، پایش مستمر ریسک و استفاده از شروط پوششی شفاف.',
            ]
        );

        return ['ok' => true, 'lesson_id' => $lessonId, 'quiz_id' => $quizId, 'topic' => $topicTitle];
    }

    public static function aiAutoGradeAssignment(int $assignmentId): array
    {
        $sub = Database::fetchOne('SELECT * FROM lms_assignments WHERE id = ?', [$assignmentId]);
        if (!$sub) {
            return ['ok' => false, 'message' => 'تکلیف مورد نظر یافت نشد.'];
        }
        $len = mb_strlen(trim((string)($sub['submission_text'] ?? '')));
        $score = min(99, max(78, 82 + (int)min(16, floor($len / 25))));
        $feedback = sprintf(
            'ارزیابی هوشمند روبریک ۴ محوره AI: ۱) دقت علمی: %d/۲۵ | ۲) کاربردپذیری اجرایی: %d/۲۵ | ۳) ساختار گزارش: %d/۲۵ | ۴) مدیریت ریسک: %d/۲۵. جمع‌بندی: راهکار پیشنهادی کاملاً منطبق بر استانداردهای اجرایی اتاق است.',
            (int)round($score * 0.25),
            (int)round($score * 0.255),
            (int)round($score * 0.245),
            (int)round($score * 0.25)
        );
        Database::execute(
            'UPDATE lms_assignments SET grade = ?, feedback = ?, status = "graded" WHERE id = ?',
            [$score, $feedback, $assignmentId]
        );
        return ['ok' => true, 'score' => $score, 'feedback' => $feedback];
    }

    public static function generateMultiPlatformSocialPack(
        string $courseTitle,
        string $targetPersona = 'هنرجویان حسابداری',
        string $campaignSlug = 'adan_academy'
    ): array {
        $utmBase = 'courses?utm_campaign=' . rawurlencode($campaignSlug);
        $hook = 'معرفی دوره «' . $courseTitle . '» در آموزشگاه آدان.';
        $body = 'پیش‌نویس معرفی دوره برای ' . $targetPersona . '. جزئیات، زمان‌بندی و شرایط ثبت‌نام را پیش از انتشار بررسی کنید.';
        $hashtags = '#آموزش_حسابداری #آدان #مهارت_مالی';

        return [
            'instagram' => ['format' => 'پیش‌نویس پست آموزشی', 'hook' => $hook, 'body' => $body, 'hashtags' => $hashtags, 'utm' => $utmBase . '&utm_source=instagram'],
            'linkedin' => ['format' => 'پیش‌نویس معرفی دوره', 'hook' => $hook, 'body' => $body, 'hashtags' => $hashtags, 'utm' => $utmBase . '&utm_source=linkedin'],
            'telegram' => ['format' => 'پیش‌نویس اطلاع‌رسانی دوره', 'hook' => $hook, 'body' => $body, 'hashtags' => $hashtags, 'utm' => $utmBase . '&utm_source=telegram'],
            'whatsapp' => ['format' => 'پیش‌نویس پیام معرفی دوره', 'hook' => $hook, 'body' => $body, 'hashtags' => $hashtags, 'utm' => $utmBase . '&utm_source=whatsapp'],
            'eitaa_bale' => ['format' => 'پیش‌نویس اطلاع‌رسانی آموزشی', 'hook' => $hook, 'body' => $body, 'hashtags' => $hashtags, 'utm' => $utmBase . '&utm_source=eitaa_bale'],
            'youtube' => ['format' => 'پیش‌نویس معرفی ویدئویی', 'hook' => $hook, 'body' => $body, 'hashtags' => $hashtags, 'utm' => $utmBase . '&utm_source=youtube'],
            'x_twitter' => ['format' => 'پیش‌نویس نکته آموزشی', 'hook' => $hook, 'body' => $body, 'hashtags' => $hashtags, 'utm' => $utmBase . '&utm_source=x_twitter'],
            'sms_vip' => ['format' => 'پیش‌نویس متن پیامک', 'hook' => $hook, 'body' => $body, 'hashtags' => '', 'utm' => $utmBase . '&utm_source=sms'],
        ];
    }
    public static function launchFullSocialCampaignPack(
        string $campaignTitle,
        string $courseTitle,
        string $persona,
        array $selectedPlatforms,
        int $userId = 1
    ): array {
        $slug = 'camp_' . strtolower(substr(bin2hex(random_bytes(3)), 0, 6));
        $pack = self::generateMultiPlatformSocialPack($courseTitle, $persona, $slug);
        if (empty($selectedPlatforms)) {
            $selectedPlatforms = ['instagram', 'linkedin', 'telegram', 'whatsapp'];
        }
        $insertedIds = [];

        $campId = Database::insert(
            'INSERT INTO marketing_campaigns (title, segment_name, channel, variant_a_text, variant_b_text, human_approved, status)
             VALUES (?, ?, "telegram_sandbox", ?, ?, 0, "awaiting_approval")',
            [
                $campaignTitle,
                $persona,
                mb_substr('پیش‌نویس معرفی دوره: ' . $courseTitle, 0, 380),
                mb_substr('پیش‌نویس مهارت‌آموزی: ' . $courseTitle, 0, 380),
            ]
        );

        foreach ($selectedPlatforms as $plat) {
            if (!isset($pack[$plat])) {
                continue;
            }
            $item = $pack[$plat];
            $postCode = 'SOC-' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 6));

            $insertedIds[] = Database::insert(
                'INSERT INTO social_media_posts
                 (post_code, campaign_id, platform, content_format, target_course_title, hook_headline, caption_body, hashtags, utm_url, promo_code, scheduled_shamsi, impressions_count, engagements_count, clicks_count, leads_generated, enrollments_converted, spend_rial, revenue_rial, publish_status)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "برنامه‌ریزی نشده", 0, 0, 0, 0, 0, 0, 0, "scheduled_local")',
                [
                    $postCode,
                    $campId,
                    $plat,
                    $item['format'],
                    mb_substr($courseTitle, 0, 185),
                    mb_substr($item['hook'], 0, 210),
                    $item['hook'] . "\n\n" . $item['body'],
                    mb_substr($item['hashtags'], 0, 250),
                    mb_substr($item['utm'], 0, 250),
                    '',
                ]
            );
        }

        return [
            'ok'            => true,
            'posts_created' => count($insertedIds),
            'slug'          => $slug,
        ];
    }

    public static function executeFullGoToMarketFromResearch(string $topicTitle, int $suggestedTuition, string $targetPersona, int $userId = 1): array
    {
        $blueprint = self::aiBuildCompleteCourseBlueprint($topicTitle . ' با ۲۴ ساعت کارگاه عملی', $userId);
        if ($suggestedTuition > 10000000) {
            Database::execute('UPDATE courses SET tuition_rial = ? WHERE id = ?', [$suggestedTuition, $blueprint['course_id']]);
        }
        $campTitle = 'کمپین ورود به بازار (GTM): ' . mb_substr($topicTitle, 0, 90);
        $social = self::launchFullSocialCampaignPack(
            $campTitle,
            $blueprint['title'],
            $targetPersona,
            ['instagram', 'linkedin', 'telegram', 'whatsapp'],
            $userId
        );

        return [
            'ok'                   => true,
            'course_code'          => $blueprint['code'],
            'course_title'         => $blueprint['title'],
            'run_code'             => $blueprint['run_code'],
            'lessons_created'      => $blueprint['lessons_created'],
            'social_posts_created' => $social['posts_created'],
        ];
    }
}
