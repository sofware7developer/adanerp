<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\App;
use App\Core\Auth;
use App\Core\Database;
use App\Core\Jalali;

/**
 * سرویس مرکزی استودیو زنده تم و فونت، تنظیمات جامع هسته نرم‌افزار ERP و مدیریت پویا و ریزدانه سطوح دسترسی (IAM / RBAC)
 */
final class EnterpriseSettingsIamService
{
    public const FONT_STACKS = [
        'Vazirmatn'       => "'Vazirmatn', Tahoma, 'Segoe UI', sans-serif",
        'Shabnam_Modern'  => "'Shabnam', 'Vazirmatn', Tahoma, sans-serif",
        'Sahel_Modern'    => "'Sahel', 'Vazirmatn', Tahoma, sans-serif",
        'Samim_Editorial' => "'Samim', 'Vazirmatn', Georgia, Tahoma, sans-serif",
        'Tahoma_Formal'   => "Tahoma, 'Vazirmatn', Arial, sans-serif",
        'System_Clean'    => "system-ui, -apple-system, 'Vazirmatn', 'Segoe UI', Tahoma, sans-serif",
    ];

    public const FONT_LABELS = [
        'Vazirmatn'       => 'وزیرمتن مدرن هندسی (پیشنهادی)',
        'Shabnam_Modern'  => 'شبنم (گرد و دلنشین مدیریتی)',
        'Sahel_Modern'    => 'ساحل (خوانای مطبوعاتی و مستندات)',
        'Samim_Editorial' => 'صمیم (کلاسیک رسمی و مکاتبات)',
        'Tahoma_Formal'   => 'تاهوما (فشرده اداری و جداول مالی)',
        'System_Clean'    => 'قلم پیش‌فرض سیستم‌عامل',
    ];

    public const PERMISSION_DOMAINS = [
        'academic_tms_lms'          => 'مدیریت دوره‌ها، تقویم آموزشی، حضور و غیاب و کارنامه',
        'finance_tax_ledger'        => 'امور مالی، دفترکل ۴ سطحی، استرداد و سامانه مؤدیان',
        'exams_certificates_qr'     => 'بانک سؤالات، قرنطینه آزمون و صدور/ابطال گواهی QR',
        'crm_campaigns_contracts'   => 'CRM سازمانی، قراردادها و کمپین‌های بازاریابی',
        'career_ats_recruitment'    => 'کاریابی جامع، انتشار آگهی، پایپ‌لاین ATS و نامه پیشنهاد شغلی',
        'system_theme_iam_security' => 'تنظیمات هسته ERP، تم و فونت، کاربران و ماتریس سطح دسترسی',
    ];

    /**
     * دریافت پروفایل تم، فونت و برندینگ فعال کل سامانه (با کش حافظه در طول درخواست)
     */
    public static function getActiveThemeProfile(?bool $forceReload = false): array
    {
        static $cached = null;
        if ($cached !== null && !$forceReload) {
            return $cached;
        }
        try {
            $row = Database::fetchOne('SELECT * FROM erp_ui_theme_profiles WHERE is_active = 1 ORDER BY id ASC LIMIT 1');
            if ($row) {
                $cached = $row;
                return $row;
            }
        } catch (\Throwable $e) {
            // سازگاری ایمن هنگام نصب اولیه
        }

        return [
            'id' => 1,
            'theme_slug' => 'emerald_gold',
            'theme_title' => 'سبز آدان (پوسته پیش‌فرض)',
            'color_mode' => 'light',
            'primary_hex' => '#0f766e',
            'gold_accent_hex' => '#c99227',
            'sidebar_bg_hex' => '#0b1f3a',
            'font_family_key' => 'Vazirmatn',
            'base_font_px' => 14,
            'line_height_val' => '1.75',
            'border_radius_px' => 16,
            'ui_density' => 'comfortable',
            'brand_org_title' => 'مؤسسه آموزشی آدان',
            'brand_unit_subtitle' => 'آموزش تخصصی حسابداری و امور مالی',
            'brand_monogram' => 'آدان',
        ];
    }

    /**
     * کلید نسخه یکتای پروفایل ظاهری جهت همگام‌سازی خودکار کش مرورگر با تغییرات دیتابیس
     */
    public static function getThemeRevisionHash(): string
    {
        $t = self::getActiveThemeProfile();
        return substr(md5(json_encode($t)), 0, 8);
    }

    /**
     * تولید بلوک CSS پویا + بارگذاری قطعی و ضدخطای فونت‌های فارسی محلی (WOFF2/TTF) در هر مسیر و زیرپوشه XAMPP/cPanel
     */
    public static function renderLiveThemeCssBlock(): string
    {
        $t = self::getActiveThemeProfile();
        $primary = preg_match('/^#[0-9a-fA-F]{6}$/', (string)$t['primary_hex']) ? $t['primary_hex'] : '#0f766e';
        $gold = preg_match('/^#[0-9a-fA-F]{6}$/', (string)$t['gold_accent_hex']) ? $t['gold_accent_hex'] : '#d97706';
        $sidebar = preg_match('/^#[0-9a-fA-F]{6}$/', (string)$t['sidebar_bg_hex']) ? $t['sidebar_bg_hex'] : '#0f172a';
        $fontStack = self::FONT_STACKS[$t['font_family_key'] ?? 'Vazirmatn'] ?? self::FONT_STACKS['Vazirmatn'];
        $fontPx = max(12, min(18, (int)($t['base_font_px'] ?? 14)));
        $lh = in_array((string)$t['line_height_val'], ['1.65', '1.75', '1.80', '1.85', '1.95'], true) ? $t['line_height_val'] : '1.75';
        $radius = max(6, min(26, (int)($t['border_radius_px'] ?? 16)));
        $radiusSm = max(6, (int)round($radius * 0.65));
        $cellPad = match ($t['ui_density'] ?? 'comfortable') {
            'compact' => '8px 11px',
            'spacious' => '14px 18px',
            default => '11px 14px',
        };

        $fBase = htmlspecialchars(\App\Core\App::asset('fonts'), ENT_QUOTES, 'UTF-8');
        $fontFaces = "
@font-face { font-family: 'Vazirmatn'; src: url('{$fBase}/Vazirmatn-Light.woff2') format('woff2'); font-weight: 300; font-style: normal; font-display: swap; }
@font-face { font-family: 'Vazirmatn'; src: url('{$fBase}/Vazirmatn-Regular.woff2') format('woff2'), url('{$fBase}/Vazirmatn-Regular.ttf') format('truetype'); font-weight: 400; font-style: normal; font-display: swap; }
@font-face { font-family: 'Vazirmatn'; src: url('{$fBase}/Vazirmatn-Medium.woff2') format('woff2'); font-weight: 500; font-style: normal; font-display: swap; }
@font-face { font-family: 'Vazirmatn'; src: url('{$fBase}/Vazirmatn-SemiBold.woff2') format('woff2'); font-weight: 600; font-style: normal; font-display: swap; }
@font-face { font-family: 'Vazirmatn'; src: url('{$fBase}/Vazirmatn-Bold.woff2') format('woff2'), url('{$fBase}/Vazirmatn-Bold.ttf') format('truetype'); font-weight: 700; font-style: normal; font-display: swap; }
@font-face { font-family: 'Vazirmatn'; src: url('{$fBase}/Vazirmatn-ExtraBold.woff2') format('woff2'); font-weight: 800 900; font-style: normal; font-display: swap; }
@font-face { font-family: 'Shabnam'; src: url('{$fBase}/Shabnam-Regular.woff2') format('woff2'); font-weight: 400; font-style: normal; font-display: swap; }
@font-face { font-family: 'Shabnam'; src: url('{$fBase}/Shabnam-Bold.woff2') format('woff2'); font-weight: 700; font-style: normal; font-display: swap; }
@font-face { font-family: 'Sahel'; src: url('{$fBase}/Sahel-Regular.woff2') format('woff2'); font-weight: 400; font-style: normal; font-display: swap; }
@font-face { font-family: 'Sahel'; src: url('{$fBase}/Sahel-Bold.woff2') format('woff2'); font-weight: 700; font-style: normal; font-display: swap; }
@font-face { font-family: 'Samim'; src: url('{$fBase}/Samim-Regular.woff2') format('woff2'); font-weight: 400; font-style: normal; font-display: swap; }
@font-face { font-family: 'Samim'; src: url('{$fBase}/Samim-Bold.woff2') format('woff2'); font-weight: 700; font-style: normal; font-display: swap; }";

        return "<style id=\"erpLiveThemeEngine\">{$fontFaces}\n"
            . ":root {\n"
            . "  --primary: {$primary};\n"
            . "  --primary-hover: color-mix(in srgb, {$primary} 88%, #000000);\n"
            . "  --primary-soft: color-mix(in srgb, {$primary} 11%, transparent);\n"
            . "  --gold: {$gold};\n"
            . "  --gold-soft: color-mix(in srgb, {$gold} 13%, transparent);\n"
            . "  --navy-900: {$sidebar};\n"
            . "  --navy-950: color-mix(in srgb, {$sidebar} 82%, #020617);\n"
            . "  --navy-800: color-mix(in srgb, {$sidebar} 78%, {$primary});\n"
            . "  --radius: {$radius}px;\n"
            . "  --radius-sm: {$radiusSm}px;\n"
            . "  --radius-lg: " . ($radius + 6) . "px;\n"
            . "  --erp-font-stack: {$fontStack};\n"
            . "}\n"
            . "html { font-size: {$fontPx}px; }\n"
            . "html, body, button, input, select, textarea, h1, h2, h3, h4, h5, h6, table, th, td { font-family: var(--erp-font-stack) !important; }\n"
            . "body { font-size: {$fontPx}px; line-height: {$lh}; }\n"
            . "table th, table td { padding: {$cellPad}; }\n"
            . "</style>";
    }

    /**
     * بروزرسانی آنی بدون رفرش ظاهر، فونت، سایز و رنگ از منوی سریع بالای تمام صفحات (AJAX)
     */
    public static function quickUpdateAppearance(array $input, string $actorName = 'کاربر سامانه'): array
    {
        $cur = self::getActiveThemeProfile(true);
        if (!empty($input['activate_preset_id'])) {
            return self::saveAndActivateThemeStudio($input, $actorName);
        }
        $merged = [
            'primary_hex'         => $input['primary_hex'] ?? $cur['primary_hex'],
            'gold_accent_hex'     => $input['gold_accent_hex'] ?? $cur['gold_accent_hex'],
            'sidebar_bg_hex'      => $input['sidebar_bg_hex'] ?? $cur['sidebar_bg_hex'],
            'color_mode'          => $input['color_mode'] ?? $cur['color_mode'],
            'font_family_key'     => $input['font_family_key'] ?? $cur['font_family_key'],
            'base_font_px'        => $input['base_font_px'] ?? $cur['base_font_px'],
            'line_height_val'     => $input['line_height_val'] ?? $cur['line_height_val'],
            'ui_density'          => $input['ui_density'] ?? $cur['ui_density'],
            'border_radius_px'    => $input['border_radius_px'] ?? $cur['border_radius_px'],
            'brand_monogram'      => $input['brand_monogram'] ?? $cur['brand_monogram'],
            'brand_org_title'     => $input['brand_org_title'] ?? $cur['brand_org_title'],
            'brand_unit_subtitle' => $input['brand_unit_subtitle'] ?? $cur['brand_unit_subtitle'],
        ];
        return self::saveAndActivateThemeStudio($merged, $actorName);
    }

    /**
     * فعال‌سازی یکی از پوسته‌های آماده یا ذخیره سفارشی پالت رنگ، فونت، سایز و برندینگ سازمان
     */
    public static function saveAndActivateThemeStudio(array $input, string $actorName = 'مدیرکل آموزش'): array
    {
        $presetId = (int)($input['activate_preset_id'] ?? 0);
        if ($presetId > 0) {
            Database::execute('UPDATE erp_ui_theme_profiles SET is_active = 0');
            Database::execute('UPDATE erp_ui_theme_profiles SET is_active = 1, updated_shamsi = ? WHERE id = ?', [Jalali::today(), $presetId]);
            $active = self::getActiveThemeProfile(true);
            Auth::audit('SETTINGS', 'ACTIVATE_THEME_PRESET', 'erp_ui_theme_profiles', $presetId, ['slug' => $active['theme_slug']]);
            return ['ok' => true, 'theme' => $active];
        }

        $primary = preg_match('/^#[0-9a-fA-F]{6}$/', (string)($input['primary_hex'] ?? '')) ? $input['primary_hex'] : '#0f766e';
        $gold = preg_match('/^#[0-9a-fA-F]{6}$/', (string)($input['gold_accent_hex'] ?? '')) ? $input['gold_accent_hex'] : '#c99227';
        $sidebar = preg_match('/^#[0-9a-fA-F]{6}$/', (string)($input['sidebar_bg_hex'] ?? '')) ? $input['sidebar_bg_hex'] : '#0b1f3a';
        $mode = ($input['color_mode'] ?? 'light') === 'dark' ? 'dark' : 'light';
        $fontKey = isset(self::FONT_STACKS[$input['font_family_key'] ?? '']) ? $input['font_family_key'] : 'Vazirmatn';
        $fontPx = max(12, min(18, (int)($input['base_font_px'] ?? 14)));
        $lh = in_array((string)($input['line_height_val'] ?? '1.75'), ['1.65', '1.75', '1.80', '1.85', '1.95'], true) ? $input['line_height_val'] : '1.75';
        $radius = max(4, min(26, (int)($input['border_radius_px'] ?? 16)));
        $density = in_array((string)($input['ui_density'] ?? 'comfortable'), ['compact', 'comfortable', 'spacious'], true) ? $input['ui_density'] : 'comfortable';
        $orgTitle = trim((string)($input['brand_org_title'] ?? '')) ?: 'مؤسسه آموزشی آدان';
        $unitSub = trim((string)($input['brand_unit_subtitle'] ?? '')) ?: 'آموزش تخصصی حسابداری و امور مالی';
        $mono = mb_substr(trim((string)($input['brand_monogram'] ?? '')) ?: 'آدان', 0, 8);

        $custom = Database::fetchOne('SELECT id FROM erp_ui_theme_profiles WHERE theme_slug = "custom_enterprise"');
        Database::execute('UPDATE erp_ui_theme_profiles SET is_active = 0');
        if ($custom) {
            Database::execute(
                'UPDATE erp_ui_theme_profiles
                 SET theme_title = ?, color_mode = ?, primary_hex = ?, gold_accent_hex = ?, sidebar_bg_hex = ?,
                     font_family_key = ?, base_font_px = ?, line_height_val = ?, border_radius_px = ?, ui_density = ?,
                     brand_org_title = ?, brand_unit_subtitle = ?, brand_monogram = ?, is_active = 1, updated_shamsi = ?
                 WHERE id = ?',
                ['پوسته اختصاصی سفارشی سازمان (' . $actorName . ')', $mode, $primary, $gold, $sidebar, $fontKey, $fontPx, $lh, $radius, $density, $orgTitle, $unitSub, $mono, Jalali::today(), (int)$custom['id']]
            );
        } else {
            Database::insert(
                'INSERT INTO erp_ui_theme_profiles
                 (theme_slug, theme_title, color_mode, primary_hex, gold_accent_hex, sidebar_bg_hex, font_family_key,
                  base_font_px, line_height_val, border_radius_px, ui_density, brand_org_title, brand_unit_subtitle, brand_monogram, is_active, updated_shamsi)
                 VALUES ("custom_enterprise", ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)',
                ['پوسته اختصاصی سفارشی سازمان (' . $actorName . ')', $mode, $primary, $gold, $sidebar, $fontKey, $fontPx, $lh, $radius, $density, $orgTitle, $unitSub, $mono, Jalali::today()]
            );
        }

        Auth::audit('SETTINGS', 'SAVE_CUSTOM_THEME_FONT', 'erp_ui_theme_profiles', 0, ['font' => $fontKey, 'size' => $fontPx, 'primary' => $primary]);
        return ['ok' => true, 'theme' => self::getActiveThemeProfile(true)];
    }

    /**
     * خواندن مقدار یک کلید تنظیمات هسته نرم‌افزار با مقدار پیش‌فرض ایمن
     */
    public static function getSetting(string $key, string $default = ''): string
    {
        try {
            $val = Database::scalar('SELECT setting_value FROM erp_system_settings WHERE setting_key = ? LIMIT 1', [$key]);
            return ($val !== false && $val !== null && $val !== '') ? (string)$val : $default;
        } catch (\Throwable $e) {
            return $default;
        }
    }

    /**
     * ذخیره دسته‌ای تنظیمات نرم‌افزار در پایگاه‌داده همراه با ثبت لاگ ممیزی
     */
    public static function saveSoftwareSettingsBatch(array $settingsMap, string $actorName = 'مدیرکل آموزش'): int
    {
        $updated = 0;
        foreach ($settingsMap as $key => $val) {
            if (!is_string($key) || !preg_match('/^[a-z0-9_]+$/', $key)) {
                continue;
            }
            Database::execute(
                'UPDATE erp_system_settings SET setting_value = ?, updated_by = ?, updated_shamsi = ? WHERE setting_key = ?',
                [trim((string)$val), $actorName, Jalali::today(), $key]
            );
            $updated++;
        }
        Auth::audit('SETTINGS', 'UPDATE_ERP_SOFTWARE_SETTINGS', 'erp_system_settings', 0, ['updated_keys' => $updated]);
        return $updated;
    }

    /**
     * ذخیره ماتریس ریزدانه سطوح دسترسی (View / Create / Edit / Delete / Approve / Export) برای یک نقش
     */
    public static function saveRolePermissionsMatrix(string $roleSlug, array $matrixInput): array
    {
        $cleanRole = preg_replace('/[^a-z0-9_]/', '', strtolower($roleSlug)) ?: 'training_expert';
        $savedDomains = 0;

        foreach (self::PERMISSION_DOMAINS as $domainKey => $domainLabel) {
            // حفاظت امنیتی مصوب اتاق: نماینده شرکت عضو (org_rep) مجاز به ایجاد/حذف/ارسال کمپین انبوه بازاریابی نیست
            $rowIn = $matrixInput[$domainKey] ?? [];
            $v = !empty($rowIn['view']) ? 1 : 0;
            $c = !empty($rowIn['create']) ? 1 : 0;
            $e = !empty($rowIn['edit']) ? 1 : 0;
            $d = !empty($rowIn['delete']) ? 1 : 0;
            $a = !empty($rowIn['approve']) ? 1 : 0;
            $x = !empty($rowIn['export']) ? 1 : 0;

            if ($cleanRole === 'org_rep' && $domainKey === 'crm_campaigns_contracts') {
                $c = 0;
                $d = 0;
                $a = 0;
            }

            $existing = Database::fetchOne('SELECT id FROM iam_role_permissions WHERE role_slug = ? AND module_domain = ?', [$cleanRole, $domainKey]);
            if ($existing) {
                Database::execute(
                    'UPDATE iam_role_permissions
                     SET can_view = ?, can_create = ?, can_edit = ?, can_delete = ?, can_approve = ?, can_export = ?, updated_shamsi = ?
                     WHERE id = ?',
                    [$v, $c, $e, $d, $a, $x, Jalali::today(), (int)$existing['id']]
                );
            } else {
                Database::insert(
                    'INSERT INTO iam_role_permissions
                     (role_slug, module_domain, module_label_fa, can_view, can_create, can_edit, can_delete, can_approve, can_export, updated_shamsi)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
                    [$cleanRole, $domainKey, $domainLabel, $v, $c, $e, $d, $a, $x, Jalali::today()]
                );
            }
            $savedDomains++;
        }

        Auth::audit('IAM_RBAC', 'SAVE_ROLE_MATRIX', 'iam_role_permissions', 0, ['role' => $cleanRole, 'domains' => $savedDomains]);
        return ['ok' => true, 'role_slug' => $cleanRole, 'saved_domains' => $savedDomains];
    }

    /**
     * ایجاد نقش سازمانی سفارشی جدید همراه با محدوده دید داده (Row-Level Data Scope)
     */
    public static function createCustomRole(string $slug, string $titleFa, string $dataScope, string $note): array
    {
        $cleanSlug = strtolower(trim($slug));
        $title = trim($titleFa);
        $allowedScopes = ['global_province', 'branch_only', 'organization_only', 'own_records'];
        if (
            !preg_match('/^[a-z][a-z0-9_]{2,59}$/', $cleanSlug)
            || $title === '' || mb_strlen($title, 'UTF-8') > 160
            || !in_array($dataScope, $allowedScopes, true)
            || mb_strlen(trim($note), 'UTF-8') > 240
        ) {
            return ['ok' => false, 'message' => 'شناسه، عنوان، محدودهٔ داده یا شرح نقش معتبر نیست.'];
        }
        if (Database::fetchOne('SELECT id FROM iam_custom_roles WHERE role_slug = ?', [$cleanSlug])) {
            return ['ok' => false, 'message' => 'این شناسهٔ نقش قبلاً ثبت شده است.'];
        }

        Database::insert(
            'INSERT INTO iam_custom_roles (role_slug, role_title_fa, data_scope, badge_color, is_system_builtin, description_note, created_shamsi)
             VALUES (?, ?, ?, "info", 0, ?, ?)',
            [$cleanSlug, $title, $dataScope, trim($note), Jalali::today()]
        );
        Auth::audit('IAM_RBAC', 'CREATE_CUSTOM_ROLE', 'iam_custom_roles', 0, ['slug' => $cleanSlug, 'scope' => $dataScope]);
        return ['ok' => true, 'role_slug' => $cleanSlug, 'data_scope' => $dataScope];
    }

    /**
     * ویرایش عنوان و محدودهٔ دادهٔ نقش؛ شناسهٔ فنی برای حفظ ارتباط‌ها ثابت می‌ماند.
     */
    public static function updateManagedRole(string $slug, string $titleFa, string $dataScope, string $note): array
    {
        $title = trim($titleFa);
        $allowedScopes = ['global_province', 'branch_only', 'organization_only', 'own_records'];
        if (
            $title === '' || mb_strlen($title, 'UTF-8') > 160
            || !in_array($dataScope, $allowedScopes, true)
            || mb_strlen(trim($note), 'UTF-8') > 240
        ) {
            return ['ok' => false, 'message' => 'عنوان، محدودهٔ داده یا شرح نقش معتبر نیست.'];
        }

        $role = Database::fetchOne('SELECT id, role_slug FROM iam_custom_roles WHERE role_slug = ?', [$slug]);
        if (!$role) {
            return ['ok' => false, 'message' => 'نقش برای ویرایش پیدا نشد.'];
        }
        Database::execute(
            'UPDATE iam_custom_roles
             SET role_title_fa = ?, data_scope = ?, description_note = ?
             WHERE id = ?',
            [$title, $dataScope, trim($note), (int)$role['id']]
        );
        Auth::audit('IAM_RBAC', 'UPDATE_MANAGED_ROLE', 'iam_custom_roles', (int)$role['id'], [
            'slug' => $slug,
            'data_scope' => $dataScope,
        ]);
        return ['ok' => true, 'role_slug' => $slug, 'data_scope' => $dataScope];
    }

    /**
     * حذف نقش سفارشی فقط وقتی هیچ حساب کاربری از آن استفاده نمی‌کند.
     */
    public static function deleteCustomRole(string $slug): array
    {
        $pdo = Database::connection();
        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare('SELECT id, is_system_builtin FROM iam_custom_roles WHERE role_slug = ? FOR UPDATE');
            $stmt->execute([$slug]);
            $role = $stmt->fetch(\PDO::FETCH_ASSOC);
            if (!$role) {
                $pdo->rollBack();
                return ['ok' => false, 'message' => 'نقش برای حذف پیدا نشد.'];
            }
            if ((int)$role['is_system_builtin'] === 1) {
                $pdo->rollBack();
                return ['ok' => false, 'message' => 'نقش‌های اصلی سامانه قابل حذف نیستند.'];
            }

            $userStmt = $pdo->prepare('SELECT COUNT(*) FROM users WHERE role = ?');
            $userStmt->execute([$slug]);
            if ((int)$userStmt->fetchColumn() > 0) {
                $pdo->rollBack();
                return ['ok' => false, 'message' => 'این نقش به کاربران منتسب است؛ ابتدا نقش کاربران را تغییر دهید.'];
            }

            $pdo->prepare('DELETE FROM iam_role_permissions WHERE role_slug = ?')->execute([$slug]);
            $pdo->prepare('DELETE FROM iam_custom_roles WHERE id = ?')->execute([(int)$role['id']]);
            $pdo->commit();
            Auth::audit('IAM_RBAC', 'DELETE_CUSTOM_ROLE', 'iam_custom_roles', (int)$role['id'], ['slug' => $slug]);
            return ['ok' => true, 'role_slug' => $slug];
        } catch (\Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }
    }

    /**
     * ایجاد کاربر جدید یا به‌روزرسانی نقش کاربر به همراه ثبت مجوز موردی (Per-User Override)
     */
    public static function createOrUpdateManagedUser(array $input): array
    {
        $userId = max(0, (int)($input['user_id'] ?? 0));
        $username = strtolower(trim((string)($input['username'] ?? '')));
        $fullName = trim((string)($input['full_name'] ?? 'کارشناس جدید مؤسسه آموزشی آدان'));
        $email = strtolower(trim((string)($input['email'] ?? '')));
        $role = trim((string)($input['role'] ?? 'training_expert'));
        $rawPass = (string)($input['password'] ?? '');
        $mobile = trim((string)($input['mobile'] ?? ''));
        $orgId = max(0, (int)($input['org_id'] ?? 0));
        $status = (string)($input['status'] ?? 'active');
        if (
            !preg_match('/^[a-z0-9_]{3,100}$/', $username)
            || $fullName === '' || mb_strlen($fullName, 'UTF-8') > 180
            || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190
            || mb_strlen($mobile, 'UTF-8') > 25
        ) {
            return ['ok' => false, 'message' => 'نام کاربری، نام کامل، ایمیل یا شماره همراه معتبر نیست.'];
        }

        if (!in_array($status, ['active', 'locked', 'inactive'], true)) {
            return ['ok' => false, 'message' => 'وضعیت انتخاب‌شده برای حساب کاربری معتبر نیست.'];
        }
        if (!Database::fetchOne('SELECT role_slug FROM iam_custom_roles WHERE role_slug = ?', [$role])) {
            return ['ok' => false, 'message' => 'نقش انتخاب‌شده در سامانه تعریف نشده است.'];
        }
        if ($orgId > 0 && !Database::fetchOne('SELECT id FROM organizations WHERE id = ?', [$orgId])) {
            return ['ok' => false, 'message' => 'سازمان انتخاب‌شده پیدا نشد.'];
        }

        if ($userId > 0) {
            $current = Database::fetchOne('SELECT id, role, status FROM users WHERE id = ?', [$userId]);
            if (!$current) {
                return ['ok' => false, 'message' => 'کاربر برای ویرایش پیدا نشد.'];
            }
            if ($rawPass !== '' && strlen($rawPass) < 12) {
                return ['ok' => false, 'message' => 'گذرواژه جدید باید حداقل ۱۲ نویسه داشته باشد.'];
            }
            if ($userId === Auth::id() && $status !== 'active') {
                return ['ok' => false, 'message' => 'نمی‌توانید حسابی را که هم‌اکنون با آن وارد شده‌اید غیرفعال یا قفل کنید.'];
            }
            if ($userId === Auth::id() && $current['role'] === 'super_admin' && $role !== 'super_admin') {
                return ['ok' => false, 'message' => 'نمی‌توانید نقش مدیرکلِ حسابی را که هم‌اکنون با آن وارد شده‌اید تغییر دهید.'];
            }
            if (
                $current['role'] === 'super_admin' && $current['status'] === 'active'
                && ($status !== 'active' || $role !== 'super_admin')
            ) {
                $activeAdmins = (int)Database::scalar(
                    'SELECT COUNT(*) FROM users WHERE role = "super_admin" AND status = "active"'
                );
                if ($activeAdmins <= 1) {
                    return ['ok' => false, 'message' => 'غیرفعال‌کردن آخرین مدیرکل فعال مجاز نیست.'];
                }
            }
            $duplicate = Database::fetchOne(
                'SELECT id FROM users WHERE (username = ? OR email = ?) AND id <> ? LIMIT 1',
                [$username, $email, $userId]
            );
            if ($duplicate) {
                return ['ok' => false, 'message' => 'نام کاربری یا ایمیل واردشده قبلاً برای کاربر دیگری ثبت شده است.'];
            }

            if ($rawPass !== '') {
                Database::execute(
                    'UPDATE users
                     SET username = ?, email = ?, full_name = ?, role = ?, mobile = ?, org_id = ?, status = ?, password_hash = ?
                     WHERE id = ?',
                    [$username, $email, $fullName, $role, $mobile !== '' ? $mobile : null, $orgId > 0 ? $orgId : null, $status, password_hash($rawPass, PASSWORD_DEFAULT), $userId]
                );
                Auth::audit('IAM_RBAC', 'MANAGED_USER_UPDATED_AND_PASSWORD_RESET', 'users', $userId, ['username' => $username, 'role' => $role, 'status' => $status]);
            } else {
                Database::execute(
                    'UPDATE users
                     SET username = ?, email = ?, full_name = ?, role = ?, mobile = ?, org_id = ?, status = ?
                     WHERE id = ?',
                    [$username, $email, $fullName, $role, $mobile !== '' ? $mobile : null, $orgId > 0 ? $orgId : null, $status, $userId]
                );
                Auth::audit('IAM_RBAC', 'MANAGED_USER_UPDATED', 'users', $userId, ['username' => $username, 'role' => $role, 'status' => $status]);
            }
            $uid = $userId;
        } else {
            if (strlen($rawPass) < 12) {
                return ['ok' => false, 'message' => 'برای کاربر جدید گذرواژهٔ اولیه باید حداقل ۱۲ نویسه داشته باشد.'];
            }
            $duplicate = Database::fetchOne('SELECT id FROM users WHERE username = ? OR email = ? LIMIT 1', [$username, $email]);
            if ($duplicate) {
                return ['ok' => false, 'message' => 'نام کاربری یا ایمیل واردشده قبلاً ثبت شده است.'];
            }
            $uid = (int)Database::insert(
                'INSERT INTO users (username, email, password_hash, full_name, role, mobile, org_id, national_code, status)
                 VALUES (?, ?, ?, ?, ?, ?, ?, NULL, "active")',
                [$username, $email, password_hash($rawPass, PASSWORD_DEFAULT), $fullName, $role, $mobile !== '' ? $mobile : null, $orgId > 0 ? $orgId : null]
            );
            Auth::audit('IAM_RBAC', 'MANAGED_USER_CREATED', 'users', $uid, ['username' => $username, 'role' => $role]);
        }

        return ['ok' => true, 'user_id' => $uid, 'username' => $username, 'role' => $role];
    }

    /**
     * ثبت استثنای دسترسی سطح تک‌کاربر (Allow / Deny) و بررسی زنده آن در Router
     */
    public static function addUserPermissionOverride(int $userId, string $routeOrPerm, string $effect, string $reason, string $actorName = 'مدیرکل آموزش'): array
    {
        $u = Database::fetchOne('SELECT full_name FROM users WHERE id = ?', [$userId]);
        $eff = $effect === 'deny' ? 'deny' : 'allow';
        Database::insert(
            'INSERT INTO iam_user_overrides (user_id, user_fullname, route_or_perm, effect_type, reason_note, expires_shamsi, granted_by)
             VALUES (?, ?, ?, ?, ?, "۱۴۰۵/۱۲/۲۹", ?)',
            [$userId, $u['full_name'] ?? 'کاربر سامانه', trim($routeOrPerm), $eff, trim($reason) ?: 'مجوز موردی مدیریتی', $actorName]
        );
        Auth::audit('IAM_RBAC', 'ADD_USER_OVERRIDE', 'iam_user_overrides', $userId, ['route' => $routeOrPerm, 'effect' => $eff]);
        return ['ok' => true, 'effect' => $eff];
    }

    /**
     * ارزیابی یکپارچه مجوز مسیر در زمان اجرا: نقش پایه + استثنای تک‌کاربره + قفل ایمنی نماینده شرکت
     */
    public static function checkDynamicRouteAccess(int $userId, string $userRole, string $route, array $staticAllowedRoles): bool
    {
        if ($userRole === 'super_admin') {
            return true;
        }
        // ★ v26.9 — سیاست تفکیک نقش‌ها (config/rbac_policy.php): خط سرخ + منوی فشردهٔ هر نقش.
        // این وتو پیش از استثناهای کاربر اعمال می‌شود؛ یعنی مدیرکل هم با «استثنای موردی»
        // نمی‌تواند بی‌رویه نقش را به ماژول بی‌ربط برساند (برای آن کار، نقش را تغییر دهید).
        if (App::rbacRouteVeto($userRole, $route) === true) {
            return false;
        }
        // ★ سیاست v26.6 — «فضای یادگیری ساده فراگیر»: کاربر فراگیر تنها دوره و امور مستقیماً مرتبط با
        // یادگیری خود را می‌بیند؛ تمام داشبوردهای مدیریتی، ERP، مالی سازمانی و IAM برای او مسدود است.
        if ($userRole === 'learner' && !\App\Core\App::isLearnerRouteAllowed($route)) {
            // تنها راه عبور: استثنای صریح «allow» ثبت‌شده توسط مدیرکل در مرکز سطوح دسترسی
            try {
                $learnerOverride = Database::fetchOne(
                    'SELECT effect_type FROM iam_user_overrides WHERE user_id = ? AND route_or_perm = ? ORDER BY id DESC LIMIT 1',
                    [$userId, $route]
                );
                if ($learnerOverride && $learnerOverride['effect_type'] === 'allow') {
                    return true;
                }
            } catch (\Throwable $e) {
                // بدون استثنا: مسیر مسدود می‌ماند (fail-safe)
            }
            return false;
        }
        // مرز امنیتی غیرقابل‌عبور مصوب اتاق: عدم دسترسی نماینده شرکت (org_rep) به کمپین بازاریابی انبوه
        if ($userRole === 'org_rep' && in_array($route, ['marketing-intel', 'marketing', 'market-intel'], true)) {
            return false;
        }
        // کش درون‌درخواستی (مهم): منوی سایدبار این تابع را برای ۶۰+ مسیر صدا می‌زند
        static $memo = [];
        $memoKey = $userId . '|' . $route;
        if (isset($memo[$memoKey])) {
            return $memo[$memoKey];
        }
        $decision = null;
        try {
            $override = Database::fetchOne(
                'SELECT effect_type FROM iam_user_overrides WHERE user_id = ? AND route_or_perm = ? ORDER BY id DESC LIMIT 1',
                [$userId, $route]
            );
            if ($override) {
                $decision = $override['effect_type'] === 'allow';
            }
        } catch (\Throwable $e) {
            // سازگاری با نصب‌های قدیمی که جدول استثنا هنوز پر نشده است
            $decision = null;
        }
        if ($decision === null) {
            $decision = in_array($userRole, $staticAllowedRoles, true);
        }
        $memo[$memoKey] = $decision;
        return $decision;
    }

    public static function getSettingsAndIamBundle(string $selectedRole = 'training_expert'): array
    {
        $settingsRows = Database::fetchAll('SELECT * FROM erp_system_settings ORDER BY id ASC');
        $grouped = [];
        foreach ($settingsRows as $r) {
            $grouped[$r['setting_group']][] = $r;
        }

        $permRows = Database::fetchAll('SELECT * FROM iam_role_permissions WHERE role_slug = ?', [$selectedRole]);
        $permMap = [];
        foreach ($permRows as $pr) {
            $permMap[$pr['module_domain']] = $pr;
        }

        return [
            'active_theme'   => self::getActiveThemeProfile(true),
            'theme_presets'  => Database::fetchAll('SELECT * FROM erp_ui_theme_profiles ORDER BY id ASC'),
            'settings_groups'=> $grouped,
            'roles'          => Database::fetchAll('SELECT * FROM iam_custom_roles ORDER BY id ASC'),
            'selected_role'  => $selectedRole,
            'perm_map'       => $permMap,
            'users'          => Database::fetchAll('SELECT u.id, u.org_id, u.username, u.email, u.mobile, u.full_name, u.role, u.status, o.name AS org_name FROM users u LEFT JOIN organizations o ON o.id = u.org_id ORDER BY u.id ASC'),
            'organizations'  => Database::fetchAll('SELECT id, name FROM organizations ORDER BY name ASC'),
            'overrides'      => Database::fetchAll('SELECT * FROM iam_user_overrides ORDER BY id DESC LIMIT 15'),
            'audit_logs'     => Database::fetchAll('SELECT * FROM audit_logs ORDER BY id DESC LIMIT 15'),
        ];
    }
}
