<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\App;
use App\Core\Database;
use App\Core\Jalali;

/**
 * موتور سراسری فرماندهی صوتی، درک زبان طبیعی فارسی و اجرای خودکار دستورات (Global Persian Voice Action OS )
 * پوشش کامل هر ۴ محور درخواستی در سطح کل سامانه (تمامی بخش‌های سامانه و ۵۵ مسیر):
 * ۱. ناوبری صوتی هوشمند به تمامی ماژول‌ها، زیربخش‌ها و گزارش‌های چاپی
 * ۲. گزارش‌گیری زنده مدیریتی از جداول MariaDB + خروجی صوتی/تصویری و اکسل CSV
 * ۳. راهنمای صوتی هوشمند حساس به صفحه فعلی کاربر + تور گام‌به‌گام سامانه
 * ۴. اجرای واقعی دستورات عملیاتی (زنجیره بخش‌های سامانه کارت بازرگانی، اسکن زنده اینترنت، ساخت دوره R&D، اجرای آزمون‌های استاندارد، تغییر پوسته و خروجی اکسل)
 */
final class VoiceCommandService
{
    public static function normalizePersian(string $text): string
    {
        $map = [
            'ي' => 'ی', 'ك' => 'ک', 'ۀ' => 'ه', 'ة' => 'ه', 'ؤ' => 'و', 'إ' => 'ا', 'أ' => 'ا',
            '۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4',
            '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
        ];
        $clean = mb_strtolower(strtr(trim($text), $map), 'UTF-8');
        return (string)preg_replace('/\s+/u', ' ', $clean);
    }

    public static function processCommand(int $userId, string $rawText, string $currentRoute = 'dashboard'): array
    {
        $text = self::normalizePersian($rawText);
        if ($text === '') {
            return [
                'ok' => false,
                'intent' => 'EMPTY',
                'spoken_reply' => 'صدایی دریافت نشد. لطفاً دکمه میکروفون را بزنید و فرمان خود را به فارسی بیان فرمایید.',
            ];
        }

        // ★ v26.8 — تراز نقش: فضای فراگیر فقط فرمان‌های یادگیری را می‌شنود و هیچ اقدام
        // مدیریتی/سازمانی (زنجیره کارت بازرگانی، ساخت دوره R&D، RFM، زمان‌بندی، گزارش‌های کل‌نگر) اجرا نمی‌شود.
        $role = self::roleOf($userId);
        if ($role === 'learner') {
            return self::processLearnerCommand($userId, $rawText, $text, $currentRoute);
        }

        // ★ v26.8 — گزارش‌ساز صوتی هوشمند: هر گزارشِ مجاز برای این نقش، با گفتن نامش تولید و خوانده می‌شود
        $studioKind = self::matchStudioKind($text, $role);
        if ($studioKind !== '' && self::hasAny($text, ['گزارش', 'خلاصه', 'وضعیت', 'بگو', 'بده', 'ده', 'بخوان', 'آمار', 'استودیو'])) {
            $rep = VoiceReportStudioService::generate($studioKind, self::userOf($userId));
            if (empty($rep['ok'])) {
                return self::logAndReturn($userId, $rawText, 'LIVE_REPORT', 'voice-assistant', 'درخواست گزارش صوتی نامجاز: ' . $studioKind, [
                    'ok' => false,
                    'intent' => 'LIVE_REPORT',
                    'title' => 'این گزارش برای نقش شما قابل تولید نیست',
                    'spoken_reply' => (string)($rep['message'] ?? 'دسترسی به این گزارش برای نقش سازمانی شما مجاز نیست.'),
                ]);
            }
            return self::logAndReturn($userId, $rawText, 'LIVE_REPORT', 'voice-assistant', 'تولید گزارش صوتی استودیو: ' . $rep['title'], [
                'ok' => true,
                'intent' => 'LIVE_REPORT',
                'navigate_to' => 'voice-assistant',
                'report_code' => $rep['report_code'],
                'title' => $rep['icon'] . ' ' . $rep['title'] . ' (بایگانی شد)',
                'spoken_reply' => $rep['speech_text'],
                'metrics' => self::metricsForVoice($rep['metrics'] ?? []),
                'details' => $rep['narrative'],
            ]);
        }

        if (self::hasAny($text, ['گزارش‌های صوتی من', 'لیست گزارش‌های صوتی', 'چه گزارش‌هایی', 'کاتالوگ گزارش'])
            && self::hasAny($text, ['گزارش', 'کاتالوگ', 'لیست'])) {
            $cat = VoiceReportStudioService::catalogForRole($role);
            $titles = array_slice(array_column($cat, 'title'), 0, 8);
            $list = [];
            foreach ($titles as $i => $t) {
                $list[] = ($i + 1) . '- ' . $t;
            }
            $reply = 'استودیوی گزارش‌ساز صوتی برای نقش شما ' . Jalali::digits((string)count($cat))
                . ' گزارش آماده دارد. برخی از آن‌ها: ' . implode(' | ', $list)
                . ' — کافی است بگویید «گزارش » و نام گزارش را؛ یا از کارت‌های همین صفحه استفاده کنید.';
            return self::logAndReturn($userId, $rawText, 'LIVE_REPORT', 'voice-assistant', 'معرفی کاتالوگ گزارش‌های صوتی نقش ' . $role, [
                'ok' => true,
                'intent' => 'LIVE_REPORT',
                'navigate_to' => 'voice-assistant',
                'title' => 'کاتالوگ گزارش‌های صوتی مجاز برای نقش شما',
                'spoken_reply' => $reply,
                'metrics' => ['تعداد گزارش‌های مجاز' => Jalali::digits((string)count($cat)) . ' گزارش', 'گروه‌ها' => implode(' / ', array_keys(VoiceReportStudioService::groupsForRole($role)))],
            ]);
        }

        // ==================== ۱. تشخیص دستورات اجرایی واقعی در پایگاه‌داده (EXECUTE_ACTION) ====================
        // تغییر پوسته تاریک/روشن یا خروجی اکسل صفحه جاری
        if (self::hasAny($text, ['زمان بندی خودکار', 'زمان‌بندی خودکار', 'چیدمان کلاس', 'بدون تداخل'])) {
            $sched = ErpIntelligenceService::runConstraintAutoScheduler();
            return self::logAndReturn($userId, $rawText, 'EXECUTE_ACTION', 'erp-intelligence', 'اجرای حل‌کننده زمان‌بندی خودکار بدون تداخل کلاس‌ها', [
                'ok' => true,
                'intent' => 'EXECUTE_ACTION',
                'navigate_to' => 'erp-intelligence',
                'title' => 'زمان‌بندی هوشمند بدون تداخل اجرا شد',
                'spoken_reply' => 'زمان‌بند خودکار محدودیت‌محور اجرا شد و ' . $sched['scheduled_count'] . ' دوره با میانگین بهره‌وری ' . $sched['avg_utilization'] . ' درصد بدون هیچ تداخلی چیده شد.',
                'metrics' => [
                    'دوره‌های زمان‌بندی‌شده' => $sched['scheduled_count'] . ' دوره',
                    'میانگین اشغال صندلی' => $sched['avg_utilization'] . ' درصد',
                    'تداخل استاد و سالن' => '۰ مورد',
                ],
            ]);
        }

        if (self::hasAny($text, ['ریزش مشتری', 'تحلیل rfm', 'ماتریس rfm', 'اعضای در معرض ریزش'])) {
            $rfm = ErpIntelligenceService::recalculateCrmRfm();
            return self::logAndReturn($userId, $rawText, 'EXECUTE_ACTION', 'erp-intelligence', 'بازمحاسبه هوشمند RFM و احتمال ریزش فراگیران آدان', [
                'ok' => true,
                'intent' => 'EXECUTE_ACTION',
                'navigate_to' => 'erp-intelligence',
                'title' => 'ماتریس پیش‌بینی ریزش (Churn) و RFM بازمحاسبه شد',
                'spoken_reply' => 'امتیاز وفاداری و احتمال ریزش برای ' . $rfm['orgs_scored'] . ' بنگاه اقتصادی عضو بازمحاسبه شد و پیشنهاد دوره بعدی برای هر شرکت صادر گردید.',
                'metrics' => [
                    'بنگاه‌های تحلیل‌شده' => $rfm['orgs_scored'] . ' شرکت',
                    'نیازمند مداخله ضدریزش' => $rfm['high_risk_count'] . ' شرکت',
                ],
            ]);
        }
        if (self::hasAny($text, ['پوسته', 'حالت شب', 'تم تاریک', 'تم روشن', 'دارک مود', 'تغییر رنگ'])) {
            return self::logAndReturn($userId, $rawText, 'EXECUTE_ACTION', $currentRoute, 'تغییر حالت نمایش روز/شب سامانه', [
                'ok' => true,
                'intent' => 'EXECUTE_ACTION',
                'client_action' => 'toggle_theme',
                'title' => 'تغییر آنی پوسته گرافیکی سامانه',
                'spoken_reply' => 'پوسته نمایش سامانه با فرمان صوتی شما تغییر یافت.',
                'details' => 'حالت نمایش روز/شب بلافاصله روی مرورگر اعمال شد.',
            ]);
        }

        if (self::hasAny($text, ['خروجی اکسل', 'دانلود اکسل', 'فایل csv', 'اکسل جدول', 'اکسل بگیر'])) {
            return self::logAndReturn($userId, $rawText, 'EXECUTE_ACTION', $currentRoute, 'استخراج خودکار فایل اکسل CSV از جدول صفحه فعال', [
                'ok' => true,
                'intent' => 'EXECUTE_ACTION',
                'client_action' => 'export_csv',
                'title' => 'دانلود خودکار خروجی اکسل (UTF-8 CSV)',
                'spoken_reply' => 'فایل اکسل جدول فعال این صفحه آماده و دانلود شد.',
                'details' => 'خروجی استاندارد CSV سازگار با Microsoft Excel با رمزگذاری UTF-8 BOM استخراج گردید.',
            ]);
        }

        // ب) اجرای زنجیره ثبت‌نام و تکمیل دوره آموزشی
        if (self::hasAny($text, ['زنجیره آموزشی', 'تکمیل خودکار دوره'])
            && self::hasAny($text, ['اجرا', 'بزن', 'انجام', 'شروع', 'فعال', 'صادر'])) {
            $pipe = AutomationPipelineService::executeFullChain(max(1, $userId), 1, 95, 93.0);
            $reply = 'گردش‌کار آموزشی اجرا شد. سند حسابداری شماره ' . ($pipe['voucher_no'] ?? '')
                . '، گواهی ثبت‌شده ' . ($pipe['cert_serial'] ?? 'صادر نشد')
                . ' و پرونده گردش‌کار ' . ($pipe['bpms_code'] ?? '') . ' ثبت گردید.';
            return self::logAndReturn($userId, $rawText, 'EXECUTE_ACTION', 'bpms', 'اجرای تراکنشی زنجیره بخش‌های سامانهه: ' . ($pipe['cert_serial'] ?? ''), [
                'ok' => true,
                'intent' => 'EXECUTE_ACTION',
                'navigate_to' => 'bpms',
                'title' => 'اجرای گردش‌کار آموزشی در MariaDB',
                'spoken_reply' => $reply,
                'metrics' => [
                    'سند دوبل ۴ سطحی' => $pipe['voucher_no'] ?? '-',
                    'سریال گواهی QR' => $pipe['cert_serial'] ?? '-',
                    'کد پرونده BPMS' => $pipe['bpms_code'] ?? '-',
                ],
            ]);
        }

        // ج) اسکن زنده اینترنت برای کشف دوره‌های پرتقاضا
        if (self::hasAny($text, ['اسکن اینترنت', 'کاوش وب', 'اینترنت رو بگرد', 'جستجو در اینترنت', 'اسکن وب', 'ترندهای روز وب'])) {
            $topic = 'هوش مصنوعی در صادرات و قراردادهای بین‌المللی';
            if (preg_match('/(?:برای|درباره|موضوع)\s+(.+)$/u', $text, $m)) {
                $topic = trim($m[1]);
            }
            $scan = MarketRadarService::scanLiveWebDemand($topic);
            $reply = 'کاوش زنده اینترنت برای موضوع ' . $topic . ' انجام شد و '
                . Jalali::digits((string)($scan['discovered_count'] ?? 0)) . ' سیگنال واقعی بازار تحلیل و ثبت گردید.';
            return self::logAndReturn($userId, $rawText, 'EXECUTE_ACTION', 'market-radar', 'کاوش زنده اینترنت با فرمان صوتی برای: ' . $topic, [
                'ok' => true,
                'intent' => 'EXECUTE_ACTION',
                'navigate_to' => 'market-radar',
                'title' => 'کاوش زنده اینترنت (DuckDuckGo + Google News RSS) انجام شد',
                'spoken_reply' => $reply,
                'metrics' => [
                    'موضوع کاوش' => $topic,
                    'سیگنال‌های کشف‌شده' => ($scan['discovered_count'] ?? 0) . ' مورد',
                    'حالت اتصال' => ($scan['mode'] ?? '') === 'live_web' ? 'اینترنت زنده واقعی' : 'هوش پشتیبان آفلاین',
                ],
            ]);
        }

        // د) طراحی خودکار دوره جدید در واحد R&D با فرمان صوتی
        if (self::hasAny($text, ['دوره جدید بساز', 'طراحی دوره', 'پیشنهاد دوره', 'شناسنامه دوره جدید'])
            && !self::hasAny($text, ['راهنما', 'گزارش'])) {
            $topic = 'صادرات هوشمند با ابزارهای هوش مصنوعی و تسویه ارزی';
            if (preg_match('/(?:درباره|برای|با موضوع|دوره)\s+(.+?)(?:\s+بساز|\s+طراحی|\s+تولید|$)/u', $text, $m) && mb_strlen(trim($m[1]), 'UTF-8') > 4) {
                $topic = trim($m[1]);
            }
            $prop = MarketRadarService::generateAiRdProposal($topic, 20);
            $reply = 'شناسنامه کامل دوره جدید با کد ' . ($prop['proposal_code'] ?? '') . ' همراه با قیمت‌گذاری رقابتی، نقطه سربه‌سر و سرفصل شش ماژوله در واحد تحقیق و توسعه ایجاد شد.';
            return self::logAndReturn($userId, $rawText, 'EXECUTE_ACTION', 'market-radar', 'ساخت صوتی پیشنهاد دوره R&D: ' . ($prop['proposal_code'] ?? ''), [
                'ok' => true,
                'intent' => 'EXECUTE_ACTION',
                'navigate_to' => 'market-radar',
                'title' => 'شناسنامه دوره جدید R&D تولید و ذخیره شد',
                'spoken_reply' => $reply,
                'metrics' => [
                    'کد پیشنهاد R&D' => $prop['proposal_code'] ?? '-',
                    'عنوان پیشنهادی' => $prop['title'] ?? '-',
                ],
            ]);
        }

        // هـ) اجرای آزمون‌های استاندارد روان‌شناسی، شغلی و زبان با فرمان صوتی
        $testVoiceMap = self::standardTestMap();
        foreach ($testVoiceMap as $tCode => $phrases) {
            if (self::hasAny($text, $phrases)) {
                $instant = self::hasAny($text, ['کارنامه', 'فوری', 'تصحیح', 'نتیجه', 'اجرا کن']);
                $reply = $instant
                    ? 'برای صدور کارنامه واقعی باید به سؤال‌های آزمون پاسخ دهید؛ پنل پاسخ‌ها باز می‌شود.'
                    : ('در حال باز کردن سؤالات تعاملی آزمون استاندارد ' . $tCode . ' برای شما.');
                return self::logAndReturn($userId, $rawText, 'EXECUTE_ACTION', 'exams', 'بازگشایی/اجرای صوتی آزمون استاندارد ' . $tCode, [
                    'ok' => true,
                    'intent' => 'EXECUTE_ACTION',
                    'navigate_to' => 'exams',
                    'open_std_test' => $tCode,
                    'instant_score' => false,
                    'title' => 'اجرای صوتی آزمون استاندارد ' . $tCode,
                    'spoken_reply' => $reply,
                    'metrics' => ['آزمون انتخاب‌شده' => $tCode, 'وضعیت' => 'پاسخ به سؤال‌ها برای صدور کارنامه الزامی است'],
                ]);
            }
        }

        // ==================== ۲. گزارش‌گیری زنده مدیریتی از MariaDB با فرمان صوتی (LIVE_REPORT) ====================
        if (self::hasAny($text, ['گزارش', 'آمار', 'چقدر', 'چند تا', 'وضعیت کلی', 'خلاصه وضعیت', 'تراز', 'درآمد'])) {
            if (self::hasAny($text, ['مالی', 'درآمد', 'هزینه', 'حسابداری', 'تراز', 'چک', 'صیادی'])) {
                $rev = (int)Database::scalar("SELECT COALESCE(SUM(credit_rial),0) FROM ledger_entries WHERE entry_type='revenue'");
                $exp = (int)Database::scalar("SELECT COALESCE(SUM(debit_rial),0) FROM ledger_entries WHERE entry_type='expense'");
                $vchCnt = (int)Database::scalar('SELECT COUNT(*) FROM accounting_vouchers');
                $cheqCnt = (int)Database::scalar('SELECT COUNT(*) FROM sayad_cheques');
                $reply = 'گزارش زنده مالی آموزشگاه آدان: مجموع درآمد ثبت‌شده ' . number_format($rev) . ' ریال، مجموع هزینه‌ها '
                    . number_format($exp) . ' ریال، تعداد اسناد حسابداری چهارسطحی تراز ' . Jalali::digits((string)$vchCnt)
                    . ' فقره با اختلاف تراز صفر ریال، و ' . Jalali::digits((string)$cheqCnt) . ' فقره چک صیادی در خزانه ثبت است.';
                return self::logAndReturn($userId, $rawText, 'LIVE_REPORT', 'finance', 'گزارش صوتی زنده مالی و تراز ۴ سطحی', [
                    'ok' => true,
                    'intent' => 'LIVE_REPORT',
                    'suggested_route' => 'finance',
                    'title' => 'گزارش زنده مالی، خزانه صیادی و دفترکل',
                    'spoken_reply' => $reply,
                    'metrics' => [
                        'جمع درآمد محقق‌شده' => number_format($rev) . ' ریال',
                        'جمع هزینه‌های مستقیم' => number_format($exp) . ' ریال',
                        'مازاد / سود خالص' => number_format($rev - $exp) . ' ریال',
                        'اسناد دوبل ۴ سطحی' => Jalali::digits((string)$vchCnt) . ' سند (تراز صفر)',
                        'چک‌های صیادی ثبت‌شده' => Jalali::digits((string)$cheqCnt) . ' فقره',
                    ],
                ]);
            }

            if (self::hasAny($text, ['بازار', 'رقبا', 'پرمتقاضی', 'اقیانوس آبی', 'تحقیق و توسعه', 'r&d'])) {
                $sigCnt = (int)Database::scalar('SELECT COUNT(*) FROM rd_web_signals');
                $topSig = Database::fetchOne('SELECT keyword_query, opportunity_index FROM rd_web_signals ORDER BY opportunity_index DESC LIMIT 1');
                $propCnt = (int)Database::scalar('SELECT COUNT(*) FROM rd_course_proposals');
                $compCnt = (int)Database::scalar('SELECT COUNT(*) FROM rd_competitor_courses');
                $reply = 'گزارش زنده رادار بازار و تحقیق و توسعه: تا این لحظه ' . Jalali::digits((string)$sigCnt)
                    . ' سیگنال پرتقاضا در اینترنت و ' . Jalali::digits((string)$compCnt) . ' دوره از موسسات رقیب رصد شده است. '
                    . 'جذاب‌ترین فرصت فعلی موضوع «' . ($topSig['keyword_query'] ?? 'هوش مصنوعی صادرات') . '» با امتیاز جذابیت '
                    . Jalali::digits((string)($topSig['opportunity_index'] ?? 95)) . ' از صد است.';
                return self::logAndReturn($userId, $rawText, 'LIVE_REPORT', 'market-radar', 'گزارش صوتی زنده رادار بازار و رقبا', [
                    'ok' => true,
                    'intent' => 'LIVE_REPORT',
                    'suggested_route' => 'market-radar',
                    'title' => 'گزارش زنده رادار بازار، رقبا و R&D',
                    'spoken_reply' => $reply,
                    'metrics' => [
                        'سیگنال‌های وب کشف‌شده' => Jalali::digits((string)$sigCnt) . ' روند داغ',
                        'دوره‌های رصدشده رقبا' => Jalali::digits((string)$compCnt) . ' دوره واقعی',
                        'برترین فرصت اقیانوس آبی' => ($topSig['keyword_query'] ?? '-') . ' (امتیاز ' . ($topSig['opportunity_index'] ?? 95) . ')',
                        'شناسنامه‌های آماده R&D' => Jalali::digits((string)$propCnt) . ' دوره',
                    ],
                ]);
            }

            // گزارش جامع مدیریتی کل سامانه
            $coursesCnt = (int)Database::scalar('SELECT COUNT(*) FROM courses');
            $certsCnt = (int)Database::scalar('SELECT COUNT(*) FROM certificates');
            $stdResCnt = (int)Database::scalar('SELECT COUNT(*) FROM standard_test_results');
            $reply = 'خلاصه مدیریتی زنده آموزشگاه حسابداری آدان: در حال حاضر ' . Jalali::digits((string)$coursesCnt)
                . ' دوره تخصصی در کاتالوگ فعال، ' . Jalali::digits((string)$certsCnt) . ' گواهی‌نامه معتبر دارای کیوآر کد، '
                . Jalali::digits((string)$stdResCnt) . ' کارنامه آموزشی و سوابق ثبت‌نام در دسترس هستند.';
            return self::logAndReturn($userId, $rawText, 'LIVE_REPORT', 'bi', 'گزارش کلان مدیریتی زنده کل سامانه', [
                'ok' => true,
                'intent' => 'LIVE_REPORT',
                'suggested_route' => 'board-report-print',
                'title' => 'گزارش کلان مدیریتی زنده کل سامانه (۹۵ جدول MariaDB)',
                'spoken_reply' => $reply,
                'metrics' => [
                    'دوره‌های فعال کاتالوگ TMS' => Jalali::digits((string)$coursesCnt) . ' دوره',
                    'گواهی‌نامه‌های معتبر QR' => Jalali::digits((string)$certsCnt) . ' فقره',
                    'کارنامه‌های آزمون آموزشی' => Jalali::digits((string)$stdResCnt) . ' کارنامه',
                ],
            ]);
        }

        // ==================== ۳. راهنمای هوشمند و تور صوتی حساس به صفحه (SYSTEM_GUIDE) ====================
        if (self::hasAny($text, ['راهنما', 'کمک', 'چطور', 'چگونه', 'چیکار کنم', 'چی کار کنم', 'تور سیستم', 'آموزش کار با سیستم', 'چه دستوراتی'])) {
            $guideMap = [
                'dashboard' => 'شما در پیشخوان آموزشگاه آدان هستید. از منوی سامانه به دوره‌ها، امور مالی، پذیرش و سایر بخش‌های مجاز نقش خود بروید یا گزارش مدیریتی آموزشگاه را چاپ کنید.',
                'market-radar' => 'شما در ماژول سی و نه، رادار بازار و تحقیق و توسعه هستید. در کارت اول کلیدواژه دلخواه را در اینترنت زنده اسکن کنید، در کارت دوم سایت مؤسسات رقیب را کالبدشکافی کنید، در کارت سوم با هوش مصنوعی شناسنامه دوره و نقطه سربه‌سر بسازید و با یک کلیک آن را وارد کاتالوگ اصلی دوره‌ها نمایید.',
                'exams' => 'شما در مرکز جامع آزمون و گواهی‌نامه هستید. در بالای صفحه شانزده آزمون استاندارد جهانی شخصیت‌شناسی، شغلی، زبان و مهارت بازرگانی آماده است؛ روی کارنامه فوری یک‌کلیکی یا شروع تعاملی کلیک کنید تا نیمرخ کامل صادر شود.',
                'finance' => 'شما در ماژول مالی و حسابداری هستید. در این صفحه می‌توانید فاکتور صادر کنید، چک صیادی شانزده رقمی ثبت نمایید، صورت‌حساب بانکی را آشتی دهید و سند حسابداری چهارسطحی تراز صادر کنید.',
            ];
            $msg = $guideMap[$currentRoute] ?? ('شما هم‌اکنون در بخش «' . $currentRoute . '» قرار دارید. در بالای هر جدول می‌توانید جست‌وجوی آنی، مرتب‌سازی ستونی و خروجی اکسل بگیرید، از نوار مشاور هوشمند بالای صفحه تحلیل داده‌های زنده بخواهید، یا با گفتن عبارت «برو به ...» به هر ماژول دیگری منتقل شوید.');
            return self::logAndReturn($userId, $rawText, 'SYSTEM_GUIDE', $currentRoute, 'ارائه راهنمای صوتی گام‌به‌گام صفحه ' . $currentRoute, [
                'ok' => true,
                'intent' => 'SYSTEM_GUIDE',
                'client_action' => self::hasAny($text, ['تور']) ? 'start_tour' : '',
                'title' => 'راهنمای هوشمند گام‌به‌گام بخش فعال (' . $currentRoute . ')',
                'spoken_reply' => $msg,
                'metrics' => [
                    'نمونه فرمان ناوبری' => '«برو به دوره‌ها» یا «برو به مالی»',
                    'نمونه فرمان گزارش' => '«گزارش کامل مالی بده» یا «خروجی اکسل بگیر»',
                    'نمونه فرمان عملیاتی' => '«زنجیره آموزشی رو اجرا کن» یا «خروجی اکسل بگیر»',
                ],
            ]);
        }

        // ==================== ۴. ناوبری صوتی طبیعی (NAVIGATION) — با مرز نقش v26.9 ====================
        $navRoutes = self::getNavigationDictionary();
        foreach ($navRoutes as $route => $entry) {
            // اگر نقش کاربر به آن بخش کارش را نداشته باشد، فرمان «برو به …» اجرا نمی‌شود
            if (!self::routeAllowedForRole($role, (string)$route)) {
                if (self::hasAny($text, $entry['keywords'])) {
                    return self::logAndReturn($userId, $rawText, 'NAVIGATION', 'dashboard',
                        'درخواست ناوبری به بخش خارج از سطح دسترسی: ' . $route, [
                            'ok' => false,
                            'intent' => 'NAVIGATION',
                            'navigate_to' => 'dashboard',
                            'title' => 'این بخش در سطح دسترسی شما نیست',
                            'spoken_reply' => 'بخش «' . $entry['label'] . '» با نقش سازمانی '
                                . \App\Core\Auth::roleLabel() . ' باز نمی‌شود؛ شما را در پیشخوان نگه داشتم.',
                            'metrics' => [],
                        ]);
                }
                continue;
            }
            if (self::hasAny($text, $entry['keywords'])) {
                $reply = 'در حال انتقال فوری شما به بخش «' . $entry['label'] . '».';
                return self::logAndReturn($userId, $rawText, 'NAVIGATION', $route, 'انتقال صوتی به ' . $entry['label'], [
                    'ok' => true,
                    'intent' => 'NAVIGATION',
                    'navigate_to' => $route,
                    'title' => 'انتقال صوتی به: ' . $entry['label'],
                    'spoken_reply' => $reply,
                ]);
            }
        }

        // ==================== ۵. پاسخ هوشمند آزاد با AI API متصل به داده‌های زنده ====================
        $ai = ModuleAiAdvisorService::analyzeModule($currentRoute, $rawText);
        $cleanAi = trim((string)preg_replace('/[*#>`\-]+/u', ' ', (string)($ai['content'] ?? 'پاسخ تحلیلی آماده شد.')));
        $shortSpoken = mb_substr($cleanAi, 0, 290, 'UTF-8');
        return self::logAndReturn($userId, $rawText, 'AI_ANALYSIS', $currentRoute, 'تحلیل هوشمند آزاد AI برای فرمان صوتی', [
            'ok' => true,
            'intent' => 'AI_ANALYSIS',
            'title' => 'پاسخ تحلیلی دستیار هوشمند صوتی (AI)',
            'spoken_reply' => $shortSpoken,
            'details' => $ai['content'] ?? $cleanAi,
        ]);
    }

    /**
     * تبدیل صوت ضبط‌شده میکروفون به متن فارسی از طریق AI Whisper API (ویژه مرورگرهای فاقد Web Speech)
     */
    public static function transcribeAudioFile(string $tmpFilePath, string $mimeType = 'audio/webm'): array
    {
        $apiKey = trim((string)(App::config('avalai')['api_key'] ?? ''));
        $baseUrl = rtrim((string)(App::config('avalai')['base_url'] ?? 'https://api.openai.com/v1'), '/');

        if ($apiKey === '' || $apiKey === 'YOUR_AVALAI_API_KEY_HERE' || !is_file($tmpFilePath)) {
            return [
                'ok' => false,
                'mode' => 'browser_speech_recommended',
                'message' => 'کلید AI در تنظیمات ثبت نشده است؛ از تشخیص گفتار مستقیم مرورگر (Web Speech fa-IR) یا نوار فرمان سریع استفاده نمایید.',
            ];
        }

        $ch = curl_init($baseUrl . '/audio/transcriptions');
        $cfile = new \CURLFile($tmpFilePath, $mimeType, 'voice_command.webm');
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 20,
            CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $apiKey],
            CURLOPT_POSTFIELDS => [
                'file' => $cfile,
                'model' => 'whisper-1',
                'language' => 'fa',
            ],
        ]);
        $resp = (string)curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        $json = json_decode($resp, true);
        if ($code >= 200 && $code < 300 && !empty($json['text'])) {
            return ['ok' => true, 'mode' => 'avalai_whisper', 'text' => trim((string)$json['text'])];
        }
        return ['ok' => false, 'message' => 'خطا در تبدیل صوت درگاه Whisper.'];
    }

    /** نقش کاربر فرمان‌دهنده (برای تراز دسترسی فرمان‌های صوتی) */
    /**
     * ★ v26.9 — آیا این نقش می‌تواند این مسیر را باز کند؟ (منبع: همان موتور RBAC + سیاست)
     */
    public static function routeAllowedForRole(string $role, string $route): bool
    {
        $route = trim($route, "/ \t");
        if ($route === '' || $role === 'super_admin') {
            return true;
        }
        if (str_contains($route, '&') || str_contains($route, '?')) {
            $route = explode('&', explode('?', $route)[0])[0];
        }
        $modules = [];
        foreach ((\App\Core\App::phases()['modules'] ?? []) as $m) {
            if (isset($m['route'])) {
                $modules[(string)$m['route']] = (array)($m['roles'] ?? []);
            }
        }
        if (!isset($modules[$route])) {
            return true;   // مسیر کمکی (چاپ/استعلام) — گیت خودش را در روتر دارد
        }
        return \App\Services\EnterpriseSettingsIamService::checkDynamicRouteAccess(
            0, $role, $route, $modules[$route]
        );
    }

    public static function roleOf(int $userId): string
    {
        try {
            $r = (string)\App\Core\Auth::role();
            if ($r !== '') {
                return $r;
            }
        } catch (\Throwable) {
        }
        $row = Database::fetchOneSafe('SELECT role FROM users WHERE id = ? LIMIT 1', [max(1, $userId)]);
        return (string)($row['role'] ?? 'super_admin');
    }

    public static function userOf(int $userId): array
    {
        try {
            $u = \App\Core\Auth::user();
            if (is_array($u) && $u !== []) {
                return $u;
            }
        } catch (\Throwable) {
        }
        $row = Database::fetchOneSafe('SELECT id, full_name, role, org_id FROM users WHERE id = ? LIMIT 1', [max(1, $userId)]);
        return is_array($row) ? $row : ['id' => max(1, $userId), 'role' => self::roleOf($userId), 'full_name' => 'کاربر سامانه'];
    }

    /** تطبیق نرم «نام گزارش استودیو» با متن گفتاری: بیشترین شباهت کلمات کلیدی عنوان */
    private static function matchStudioKind(string $spokenText, string $role): string
    {
        $stop = ['گزارش', 'وضعیت', 'خلاصه', 'زنده', 'من', 'کل', 'و', 'در', 'از', 'به', 'برای', 'کامل', 'بگو', 'بده', 'ده', 'خوان', 'استودیو', 'صوتی', 'این', 'های'];
        $textWords = array_values(array_filter(self::wordsOf($spokenText), static fn($w) => !in_array($w, $stop, true)));
        if (count($textWords) < 2) {
            return '';
        }
        $best = '';
        $bestScore = 0.0;
        foreach (VoiceReportStudioService::catalogForRole($role) as $kind => $def) {
            $headWords = array_values(array_filter(self::wordsOf((string)($def['title'] ?? '')), static fn($w) => !in_array($w, $stop, true)));
            if ($headWords === []) {
                continue;
            }
            $hit = count(array_intersect($headWords, $textWords));
            $score = $hit / max(1, count($headWords));
            if ($score > $bestScore || ($score === $bestScore && $score > 0 && count($headWords) > 2)) {
                if ($hit >= 2 || ($hit >= 1 && count($headWords) <= 2)) {
                    $bestScore = $score;
                    $best = (string)$kind;
                }
            }
        }
        return $bestScore >= 0.5 ? $best : '';
    }

    /** نرمال‌سازی فارسی و تبدیل به مجموعه واژه (بدون نشانه و ZWNJ) */
    private static function wordsOf(string $txt): array
    {
        $t = mb_strtolower($txt, 'UTF-8');
        $t = strtr($t, ['ي' => 'ی', 'ك' => 'ک', 'أ' => 'ا', 'إ' => 'ا', 'آ' => 'آ', 'ة' => 'ه', 'ۀ' => 'ه']);
        $t = str_replace(['‌', '‍', '،', '؛', '.', ':', '،', '(', ')', '«', '»', '"', "'", '-', '/', '،'], ' ', $t);
        $t = (string)preg_replace('/[^\p{L}\p{N}\s]+/u', ' ', $t);
        $words = preg_split('/\s+/u', trim($t)) ?: [];
        return array_values(array_filter(array_map('strval', $words), static fn($w) => mb_strlen($w, 'UTF-8') >= 3));
    }

    /** آرایه شاخص‌ها برای خوانش صوتی (برچسب: مقدار) */
    private static function metricsForVoice(array $metrics): array
    {
        $out = [];
        foreach (array_slice($metrics, 0, 8) as $m) {
            $out[(string)($m['label'] ?? 'شاخص')] = (string)($m['value'] ?? '');
        }
        return $out;
    }

    public static function standardTestMap(): array
    {
        return [
            'MBTI' => ['mbti', 'ام بی تی آی', 'مایرز', 'تیپ شخصیت', 'شخصیت شناسی'],
            'DISC' => ['disc', 'دیسک', 'سبک رفتاری'],
            'NEO_BIG5' => ['neo', 'نئو', 'پنج عامل', 'big five'],
            'EQ_BARON' => ['هوش هیجانی', 'eq', 'بارآن'],
            'HOLLAND' => ['هالند', 'holland', 'رغبت شغلی', 'استعدادیابی شغلی'],
            'CLIFTON' => ['کلیفتون', 'گالوپ', 'نقاط قوت', 'clifton'],
            'TKI_CONFLICT' => ['توماس', 'تعارض', 'tki'],
            'SCHEIN' => ['شاین', 'لنگرگاه'],
            'GMAT_APTITUDE' => ['gmat', 'ریون', 'هوش تحلیلی', 'استدلال منطقی'],
            'CEFR_EN' => ['تعیین سطح زبان', 'زبان انگلیسی', 'cefr', 'کمبریج', 'آکسفورد'],
            'BEC_BUSINESS_EN' => ['انگلیسی تجاری', 'انگلیسی بازرگانی', 'bec', 'مکاتبات انگلیسی'],
            'ARABIC_TRADE' => ['زبان عربی', 'عربی تجاری'],
            'EURASIA_TR_RU' => ['زبان ترکی', 'زبان روسی', 'ترکی و روسی'],
            'INCOTERMS_PRO' => ['آزمون اینکوترمز', 'صلاحیت صادرات', 'ucp'],
            'ICDL_AI_WORK' => ['icdl', 'مهارت دیجیتال', 'اکسل و هوش مصنوعی'],
            'TAX_FINANCE_IR' => ['آزمون مالیاتی', 'آزمون حسابداری', 'صلاحیت مالی'],
        ];
    }

    /**
     * ★ v26.8 — فرمان‌های صوتی فضای فراگیر: فقط یادگیری شخصی، ناوبری مجاز و سنجش خودی.
     * هیچ زنجیره تراکنشی، ساخت دوره، گزارش مالی کل، RFM یا کاوش وب از این مسیر اجرا نمی‌شود.
     */
    private static function processLearnerCommand(int $userId, string $rawText, string $text, string $currentRoute): array
    {
        $user = self::userOf($userId);

        // ۱) تغییر پوسته (بی‌ضرر و محلی)
        if (self::hasAny($text, ['پوسته', 'تم', 'حالت شب', 'حالت روز', 'دارک مود', 'رنگ'])) {
            return self::logAndReturn($userId, $rawText, 'EXECUTE_ACTION', $currentRoute, 'تغییر پوسته توسط فراگیر', [
                'ok' => true,
                'intent' => 'EXECUTE_ACTION',
                'client_action' => 'toggle_theme',
                'title' => 'تغییر پوسته نمایش',
                'spoken_reply' => 'پوسته سامانه با فرمان صوتی شما تغییر کرد.',
            ]);
        }

        // ۲) بریفینگ صوتی و گزارش‌های شخصی
        if (self::hasAny($text, ['گزارش', 'وضعیت', 'خلاصه', 'پیشرفت', 'آمار', 'چیکار', 'چی کار', 'امروز', 'بریفینگ', 'منحنی', 'فراموشی', 'حفظم'])) {
            if (self::hasAny($text, ['فراموشی', 'حفظ', 'مرور', 'کارت', 'لایتنر'])) {
                $f = \App\Services\LearnerCoachService::forgettingForecast($userId);
                \App\Services\LearnerCoachService::recordFeature($userId, 'voice_command', 'پیش‌بینی فراموشی با صدا', $f['due_today']);
                return self::logAndReturn($userId, $rawText, 'LIVE_REPORT', 'microlearning', 'خوانش ریسک فراموشی فراگیر', [
                    'ok' => true,
                    'intent' => 'LIVE_REPORT',
                    'navigate_to' => 'microlearning&tab=leitner',
                    'title' => '🧠 پیش‌بینی منحنی فراموشی شما',
                    'spoken_reply' => 'میانگین حفظ فعلی شما ' . Jalali::digits((string)round($f['retention_pct'])) . ' درصد است. '
                        . $f['due_today'] . ' کارت امروز سررسید مرور دارد. ' . $f['advice'] . ' ' . $f['saved_note'],
                    'metrics' => [
                        'کل کارت‌ها' => Jalali::digits((string)$f['cards_total']) . ' کارت',
                        'سررسید امروز' => Jalali::digits((string)$f['due_today']) . ' کارت',
                        'میانگین حفظ' => Jalali::digits((string)round($f['retention_pct'])) . ' درصد',
                        'کارت‌های در معرض فراموشی' => Jalali::digits((string)count($f['fading'])) . ' کارت',
                    ],
                ]);
            }
            if (self::hasAny($text, ['شهریه', 'فاکتور', 'پرداخت', 'تسویه'])) {
                $rep = VoiceReportStudioService::generate('my_tuition', $user);
                return self::logAndReturn($userId, $rawText, 'LIVE_REPORT', 'finance', 'خوانش وضعیت مالی شخصی فراگیر', [
                    'ok' => true,
                    'intent' => 'LIVE_REPORT',
                    'navigate_to' => 'finance',
                    'title' => '💳 ' . (string)($rep['title'] ?? 'وضعیت مالی من'),
                    'spoken_reply' => (string)($rep['speech_text'] ?? ''),
                    'metrics' => self::metricsForVoice($rep['metrics'] ?? []),
                ]);
            }
            $b = \App\Services\LearnerCoachService::briefing($userId, $user);
            \App\Services\LearnerCoachService::recordFeature($userId, 'voice_command', 'بریفینگ صوتی با فرمان صدا', (int)$b['forecast']['due_today']);
            return self::logAndReturn($userId, $rawText, 'LIVE_REPORT', 'dashboard', 'خوانش بریفینگ صوتی روزانه فراگیر', [
                'ok' => true,
                'intent' => 'LIVE_REPORT',
                'navigate_to' => 'dashboard',
                'title' => '☀️ بریفینگ صوتی امروز من',
                'spoken_reply' => (string)$b['speech_text'],
                'details' => (string)$b['narrative'],
                'metrics' => self::metricsForVoice($b['metrics'] ?? []),
            ]);
        }

        // ۳) ساخت کارت از یادداشت‌ها (اثر فقط روی جعبه لایتنر خود کاربر)
        if (self::hasAny($text, ['کارت بساز', 'کارت بسازد', 'کارت‌سازی', 'از یادداشت', 'فلش کارت بساز', 'کارت مرور بساز', 'کارت من'])) {
            $res = \App\Services\LearnerCoachService::generatePersonalCards($userId, 6);
            return self::logAndReturn($userId, $rawText, 'EXECUTE_ACTION', 'microlearning', 'تبدیل یادداشت‌ها به کارت مرور شخصی', [
                'ok' => true,
                'intent' => 'EXECUTE_ACTION',
                'navigate_to' => 'microlearning&tab=mycards',
                'title' => '🃏 کارت‌های مرور شخصی شما',
                'spoken_reply' => $res['message'] . ' برای دیدن و مرور آن‌ها به بخش مرور سریع بروید.',
                'metrics' => [
                    'کارت‌های ساخته‌شده' => Jalali::digits((string)$res['created']) . ' کارت',
                    'موارّد تکراری ردشده' => Jalali::digits((string)$res['skipped']) . ' مورد',
                ],
            ]);
        }

        // ۴) برنامه هفتگی
        if (self::hasAny($text, ['برنامه', 'هفته', 'زمان‌بندی', 'کی', 'اولویت'])) {
            $plan = \App\Services\LearnerCoachService::weeklyPlan($userId);
            $days = [];
            foreach (array_slice($plan['days'], 0, 4) as $d) {
                $days[] = $d['label'] . ': ' . implode(' و ', $d['items']);
            }
            return self::logAndReturn($userId, $rawText, 'LIVE_REPORT', 'dashboard', 'تولید برنامه هفتگی تطبیقی فراگیر', [
                'ok' => true,
                'intent' => 'LIVE_REPORT',
                'navigate_to' => 'dashboard',
                'title' => '🗓️ برنامه هفتگی تطبیقی من',
                'spoken_reply' => 'برنامه هفتگی شما با مجموع ' . Jalali::digits((string)$plan['total_minutes']) . ' دقیقه چیده شد. ' . implode(' — ', $days) . '.',
                'metrics' => [
                    'درس‌های عقب‌افتاده' => Jalali::digits((string)$plan['pending_lessons']) . ' درس',
                    'فاکتور باز' => Jalali::digits((string)$plan['open_invoices']) . ' مورد',
                    'یادداشت‌های من' => Jalali::digits((string)$plan['notes_count']) . ' یادداشت',
                    'زمان کل' => Jalali::digits((string)$plan['total_minutes']) . ' دقیقه',
                ],
            ]);
        }

        // ۵) راهنمای صوتی اختصاصی فضای فراگیر
        if (self::hasAny($text, ['راهنما', 'کمک', 'چطور', 'چگونه', 'چه کار', 'تور'])) {
            $msg = 'در فضای یادگیری شما دستیار هوشمند فقط کارهای شخصی انجام می‌دهد: «بریفینگ امروز من را بگو»، '
                . '«کدام کارت‌ها فراموش می‌شوند»، «از یادداشت‌هایم کارت بساز»، «برنامه هفتگی من»، '
                . '«یک آزمون خودساز بساز» یا «برو به درس‌های من». کارهای مدیریتی مانند صدور فاکتور، ثبت‌نام انبوه یا گزارش مالی کل سامانه در این نقش اجرا نمی‌شود.';
            return self::logAndReturn($userId, $rawText, 'SYSTEM_GUIDE', $currentRoute, 'راهنمای صوتی فضای فراگیر', [
                'ok' => true,
                'intent' => 'SYSTEM_GUIDE',
                'title' => 'راهنمای فرمان‌های صوتی فراگیر',
                'spoken_reply' => $msg,
            ]);
        }

        // ۶) اجرای آزمون استاندارد برای خود کاربر (سنجش خودی — مجاز)
        foreach (self::standardTestMap() as $tCode => $phrases) {
            if (self::hasAny($text, $phrases)) {
                $instant = self::hasAny($text, ['کارنامه', 'فوری', 'تصحیح', 'نتیجه', 'اجرا کن', 'بده']);
                $reply = $instant
                    ? 'برای صدور کارنامه واقعی باید به سؤال‌های آزمون پاسخ دهید؛ پنل پاسخ‌ها باز می‌شود.'
                    : ('سؤالات تعاملی آزمون استاندارد ' . $tCode . ' برای شما باز می‌شود.');
                return self::logAndReturn($userId, $rawText, 'EXECUTE_ACTION', 'exams', 'سنجش خودی با صدا: ' . $tCode, [
                    'ok' => true,
                    'intent' => 'EXECUTE_ACTION',
                    'navigate_to' => 'exams',
                    'open_std_test' => $tCode,
                    'instant_score' => false,
                    'title' => 'اجرای صوتی آزمون استاندارد ' . $tCode,
                    'spoken_reply' => $reply,
                    'metrics' => ['آزمون انتخاب‌شده' => $tCode, 'وضعیت' => 'پاسخ به سؤال‌ها برای صدور کارنامه الزامی است'],
                ]);
            }
        }

        // ۷) ناوبری — فقط مسیرهایی که نقش فراگیر مجاز است باز کند
        foreach (self::getNavigationDictionary() as $route => $entry) {
            if (!\App\Core\App::isLearnerRouteAllowed((string)$route)) {
                continue;
            }
            if (self::hasAny($text, $entry['keywords'])) {
                return self::logAndReturn($userId, $rawText, 'NAVIGATION', (string)$route, 'انتقال صوتی فراگیر به ' . $entry['label'], [
                    'ok' => true,
                    'intent' => 'NAVIGATION',
                    'navigate_to' => (string)$route,
                    'title' => 'انتقال به: ' . $entry['label'],
                    'spoken_reply' => 'در حال انتقال شما به «' . $entry['label'] . '».',
                ]);
            }
        }

        // ۸) پاسخ مربی هوشمند (همواره روی داده‌های خود کاربر)
        $ai = ModuleAiAdvisorService::analyzeModule($currentRoute, $rawText);
        $clean = trim((string)preg_replace('/[*#>`]+/u', ' ', (string)($ai['content'] ?? 'پاسخ آماده شد.')));
        return self::logAndReturn($userId, $rawText, 'AI_ANALYSIS', $currentRoute, 'تحلیل مربی یادگیری از فرمان صوتی فراگیر', [
            'ok' => true,
            'intent' => 'AI_ANALYSIS',
            'title' => '🎓 پاسخ مربی هوشمند یادگیری',
            'spoken_reply' => mb_substr($clean, 0, 300, 'UTF-8'),
            'details' => $clean,
        ]);
    }

    public static function getNavigationDictionary(): array
    {
        return [
            'help-center' => ['label' => 'دانشنامه جامع کل سیستم و راهنمای اختصاصی ۷۷ صفحه', 'keywords' => ['راهنما', 'هلپ', 'آموزش سیستم', 'مستندات', 'کتابچه راهنما', 'نصب سیستم', 'سوالات متداول']],
            'microlearning' => ['label' => 'پلتفرم جامع میکرولرنینگ (یادگیری خرد ۳ دقیقه‌ای)، لایتنر SM-2 و کپسول‌ساز AI', 'keywords' => ['میکرولرنینگ', 'یادگیری خرد', 'کپسول آموزشی', 'لایتنر', 'فلش کارت', 'مرور فاصله دار', 'میکروپادکست']],
            'system-settings' => ['label' => 'استودیو زنده تم و فونت، برندینگ سازمان و تنظیمات جامع نرم‌افزار ERP', 'keywords' => ['تنظیمات', 'تم', 'فونت', 'سایز فونت', 'حالت شب', 'دارک مود', 'پوسته', 'پالت رنگ', 'برندینگ']],
            'iam-access' => ['label' => 'مدیریت کاربران، نقش‌های سفارشی و ماتریس سطوح دسترسی RBAC', 'keywords' => ['سطح دسترسی', 'مجوز', 'نقش کاربری', 'مدیریت کاربران', 'rbac', 'ماتریس دسترسی', 'امنیت']],
            'academic-erp-core' => ['label' => 'تقویم و ترم‌های آموزشی، حضور و غیاب، لیست نمرات، کارنامه و پیش‌نیازها', 'keywords' => ['تقویم آموزشی', 'ترم', 'حضور و غیاب', 'غیبت', 'لیست نمرات', 'کارنامه', 'پیش نیاز', 'لیست انتظار']],
            'helpdesk-sla' => ['label' => 'میز خدمت و تیکتینگ SLA، گواهی اشتغال به دوره و قالب پیامک', 'keywords' => ['تیکت', 'پشتیبانی', 'میز خدمت', 'اشتغال به تحصیل', 'قالب پیامک', 'معادل سازی']],
            'career-hub' => ['label' => 'سامانه جامع کاریابی، ثبت آگهی هوشمند با AI، رزومه‌ساز رسمی و پایپ‌لاین ATS', 'keywords' => ['کاریابی', 'آگهی استخدام', 'ثبت آگهی', 'رزومه ساز', 'جویای کار', 'استخدام فوری', 'ats', 'نامه پیشنهاد شغلی']],
            'role-workstations' => ['label' => 'میزکارهای اختصاصی نقش‌محور ۸گانه (امضای مدیرکل، ویزارد گروهی، استرداد مالی و IDP)', 'keywords' => ['میزکار نقش', 'میزکار اختصاصی', 'استرداد شهریه', 'ثبت نام گروهی', 'توصیه نامه استاد', 'برنامه توسعه فردی']],
            'gamification-analytics' => ['label' => 'رصدخانه تحلیل رفتار فراگیران (LBA)، پیش‌بینی ریزش و گیمیفیکیشن سازمانی', 'keywords' => ['گیمیفیکیشن', 'تحلیل رفتار', 'امتیاز تجربه', 'سکه مهارت', 'فروشگاه جوایز', 'ماموریت ها', 'ترک دوره']],
            'national-interchange' => ['label' => 'پیش‌نمایش محلی شناسه‌ها و آمادگی اتصال سامانه‌های ملی', 'keywords' => ['گذرگاه ملی', 'سامانه جامع تجارت', 'ntsw', 'ثبت شرکت', 'کد تعرفه گمرکی']],
            'digital-twin-bi' => ['label' => 'اتاق وضعیت مدیرعامل، بریفینگ صوتی صبحگاهی، RAG حقوقی و قیمت‌گذاری پویا', 'keywords' => ['اتاق وضعیت', 'بریفینگ صبحگاهی', 'جستجوی قوانین', 'قیمت گذاری پویا', 'خلاصه صبحگاهی']],
            'erp-intelligence' => ['label' => 'هسته مرکزی ERP هوشمند، پیش‌بینی مالی و قوانین خودران', 'keywords' => ['مغز متفکر', 'اتوپایلوت', 'هسته هوشمند', 'پیش بینی نقدینگی', 'هشدارهای هوشمند', 'erp']],
            'market-radar' => ['label' => 'رادار هوشمند بازار، پایش رقبا و تحقیق و توسعه (R&D)', 'keywords' => ['رادار بازار', 'رصد رقبا', 'تحلیل رقبا', 'تحقیق و توسعه', 'پرمتقاضی']],
            'voice-assistant' => ['label' => 'مرکز فرماندهی صوتی و لاگ دستورات', 'keywords' => ['فرماندهی صوتی', 'مرکز صوتی', 'دستیار صوتی', 'تاریخچه صوتی']],
            'board-report-print' => ['label' => 'گزارش مدیریتی آموزشگاه آدان', 'keywords' => ['گزارش مدیریتی', 'گزارش آموزشگاه']],
            'exams' => ['label' => 'مرکز آزمون‌های استاندارد، بانک سؤال و گواهی QR', 'keywords' => ['آزمون', 'امتحان', 'گواهی', 'بانک سوال', 'بانک سؤال', 'سنجش']],
            'tms' => ['label' => 'مدیریت جامع آموزش و کاتالوگ دوره‌ها (TMS)', 'keywords' => ['کاتالوگ دوره', 'مدیریت آموزش', 'تقویم آموزشی', 'ثبت نام دوره', 'tms']],
            'competency' => ['label' => 'نیازسنجی آموزشی و ماتریس شایستگی', 'keywords' => ['نیازسنجی', 'شایستگی', 'شکاف مهارت']],
            'lms' => ['label' => 'سامانه یادگیری الکترونیکی (LMS و SCORM)', 'keywords' => ['یادگیری الکترونیکی', 'درس آنلاین', 'اسکورم', 'lms']],
            'ai-studio' => ['label' => 'استودیوی تولید محتوای آموزشی با هوش مصنوعی', 'keywords' => ['استودیو محتوا', 'تولید محتوا', 'جزوه ساز']],
            'instructors' => ['label' => 'بانک مدرسان، ارزیابی و حق‌التدریس ماده ۸۶', 'keywords' => ['مدرسان', 'اساتید', 'حق التدریس', 'ماده 86']],
            'events' => ['label' => 'کارگاه‌ها و برنامه‌های آموزشی آدان', 'keywords' => ['کارگاه', 'برنامه آموزشی', 'نشست تخصصی', 'همایش', 'رویداد']],
            'finance' => ['label' => 'مدیریت مالی، حسابداری ۴ سطحی دوبل و چک صیادی', 'keywords' => ['بخش مالی', 'امور مالی', 'دفترکل', 'حسابداری', 'چک صیادی', 'فاکتور']],
            'evaluation' => ['label' => 'ارزشیابی اثربخشی کرکپاتریک و بازگشت سرمایه (ROI)', 'keywords' => ['کرکپاتریک', 'اثربخشی', 'بازگشت سرمایه', 'roi']],
            'portal' => ['label' => 'پورتال اختصاصی فراگیران و بنگاه‌های عضو', 'keywords' => ['پورتال اعضا', 'پورتال فراگیر', 'میز خدمت عضو']],
            'crm' => ['label' => 'مدیریت ارتباط با اعضا و قیف فروش سازمانی (CRM)', 'keywords' => ['سی آر ام', 'crm', 'قیف فروش', 'سرنخ فروش']],
            'contracts' => ['label' => 'قراردادهای آموزشی سازمانی B2B', 'keywords' => ['قرارداد سازمانی', 'قراردادهای شرکتی', 'سهمیه شرکت']],
            'leadership' => ['label' => 'آکادمی توسعه رهبری مدیران صنایع', 'keywords' => ['توسعه رهبری', 'مدیران صنایع']],
            'consulting' => ['label' => 'کلینیک مشاوره و منتورینگ تخصصی', 'keywords' => ['مشاوره', 'منتورینگ']],
            'classrooms' => ['label' => 'مدیریت کلاس‌ها، سالن‌ها و تجهیزات فیزیکی', 'keywords' => ['رزرو کلاس', 'سالن ها', 'تالار']],
            'research' => ['label' => 'پژوهش‌های آموزشی و داوری علمی استان', 'keywords' => ['پژوهش', 'طرح پژوهشی']],
            'library' => ['label' => 'کتابخانه دیجیتال و مخزن دانش تجاری', 'keywords' => ['کتابخانه', 'مرکز دانش']],
            'internships' => ['label' => 'کارآموزی صنعتی و طرح پویش دانشگاه-صنعت', 'keywords' => ['کارآموزی', 'طرح پویش']],
            'competitions' => ['label' => 'مسابقات تجاری و شبیه‌سازهای کسب‌وکار', 'keywords' => ['مسابقات', 'رقابت تجاری']],
            'hr' => ['label' => 'منابع انسانی داخلی واحد آموزش', 'keywords' => ['منابع انسانی', 'پرسنل آموزش']],
            'bpms' => ['label' => 'موتور گردش کار (BPMS) و زنجیره خودکار', 'keywords' => ['گردش کار', 'کارتابل فرایند', 'bpms']],
            'bi' => ['label' => 'هوش تجاری (BI)، گزارش‌ساز پویا و نمودارها', 'keywords' => ['هوش تجاری', 'گزارش ساز', 'نمودارها', 'bi']],
            'ai-governance' => ['label' => 'حکمرانی هوش مصنوعی، دروازه AI و هزینه توکن', 'keywords' => ['دروازه هوش مصنوعی', 'مدیریت هوش مصنوعی', 'هزینه توکن', 'avalai']],
            'virtual-class' => ['label' => 'کلاس آنلاین زنده (اسکای‌روم و بیگ‌بلوباتن)', 'keywords' => ['کلاس آنلاین', 'وبینار', 'اسکای روم', 'بیگ بلو باتن']],
            'tax-moadian' => ['label' => 'سامانه مؤدیان مالیاتی و پل حسابداری سپیدار', 'keywords' => ['سامانه مودیان', 'سامانه مؤدیان', 'سپیدار', 'همکاران سیستم']],
            'iso-qa' => ['label' => 'تضمین کیفیت آموزشی ایزو ۲۱۰۰۱ و ریشه‌یابی ۵ چرا', 'keywords' => ['ایزو', 'تضمین کیفیت', 'عدم انطباق', 'capa']],
            'job-board' => ['label' => 'بازارگاه اشتغال و کاریابی تخصصی صنایع عضو', 'keywords' => ['بازارگاه اشتغال', 'کاریابی', 'استخدام صنایع']],
            'grants-mou' => ['label' => 'یارانه‌های آموزشی SME و تفاهم‌نامه‌ها', 'keywords' => ['یارانه', 'تفاهم نامه']],
            'sso-pki' => ['label' => 'احراز هویت شاهکار و امضای دیجیتال PKI', 'keywords' => ['شاهکار', 'امضای دیجیتال', 'pki']],
            'proctoring-drm' => ['label' => 'نظارت هوشمند سلامت آزمون و محافظت محتوا (DRM)', 'keywords' => ['سلامت آزمون', 'تقلب', 'drm']],
            'alumni-club' => ['label' => 'باشگاه دانش‌آموختگان و کنسرسیوم‌های صادراتی', 'keywords' => ['دانش آموختگان', 'فارغ التحصیلان', 'کنسرسیوم']],
            'iran-messengers' => ['label' => 'درگاه پیامک بومی و بازوهای بله و ایتا', 'keywords' => ['پیامک', 'پیام رسان', 'بله و ایتا']],
            'system-ops' => ['label' => 'پشتیبان‌گیری SQL، سلامت سرور XAMPP/cPanel و Cron', 'keywords' => ['پشتیبان', 'بکاپ', 'سلامت سرور', 'سی پنل']],
            'verify' => ['label' => 'استعلام برخط اصالت گواهی‌نامه با کد QR', 'keywords' => ['استعلام گواهی', 'بررسی اصالت']],
            'passport' => ['label' => 'گذرنامه مهارتی دیجیتال فراگیر', 'keywords' => ['گذرنامه مهارتی', 'پاسپورت مهارتی']],
            'public-home' => ['label' => 'پورتال عمومی و ویترین دوره‌های آدان', 'keywords' => ['سایت عمومی', 'ویترین عمومی', 'پورتال عمومی']],
            'workspace-tools' => ['label' => 'میزکار بهره‌وری، کانبان وظایف و تقویم اجرایی', 'keywords' => ['میزکار', 'کانبان', 'وظایف تیمی']],
            'portal-builder' => ['label' => 'صفحه‌ساز بصری پورتال آموزش', 'keywords' => ['صفحه ساز', 'سایت ساز']],
            'marketing-intel' => ['label' => 'هوش بازاریابی و تحلیل قیف جذب فراگیر', 'keywords' => ['هوش بازاریابی', 'تحلیل بازاریابی']],
            'talent-psych' => ['label' => 'استعدادیابی سازمانی و نیمرخ‌های روان‌شناختی', 'keywords' => ['استعدادیابی', 'روانشناختی']],
            'invoice-print' => ['label' => 'پیش‌نمایش چاپ فاکتور رسمی ریالی', 'keywords' => ['چاپ فاکتور', 'صورت حساب چاپی']],
            'contract-print' => ['label' => 'نسخه چاپی قرارداد آموزشی سازمانی', 'keywords' => ['چاپ قرارداد']],
            'class-card-print' => ['label' => 'کارت ورود به کلاس و لیست حضور و غیاب چاپی', 'keywords' => ['کارت کلاس', 'لیست حضور و غیاب']],
            'instructor-contract-print' => ['label' => 'نسخه چاپی قرارداد حق‌التدریس و گواهی ماده ۸۶', 'keywords' => ['قرارداد استاد', 'چاپ حق التدریس']],
            'event-badge-print' => ['label' => 'کارت سینه چاپی همایش با کد QR', 'keywords' => ['کارت سینه', 'بج همایش']],
            'dashboard' => ['label' => 'پیشخوان مدیریت آموزشگاه آدان', 'keywords' => ['پیشخوان', 'داشبورد', 'صفحه اصلی مدیریت', 'خانه']],
        ];
    }

    private static function hasAny(string $haystack, array $needles): bool
    {
        foreach ($needles as $n) {
            if (mb_strpos($haystack, self::normalizePersian($n)) !== false) {
                return true;
            }
        }
        return false;
    }

    private static function logAndReturn(int $userId, string $spokenText, string $intent, string $targetRoute, string $summary, array $payload): array
    {
        // ★ v26.9 — آخرین حلقۀ ایمنی: هر پاسخ صوتی که مقصدش خارج از سطح دسترسی نقش باشد،
        //             به پیشخوان تبدیل می‌شود (نه لینک مرده، نه افشای داده).
        $roleForClamp = self::roleOf($userId);
        foreach (['navigate_to'] as $k) {
            if (isset($payload[$k]) && is_string($payload[$k]) && !self::routeAllowedForRole($roleForClamp, $payload[$k])) {
                $payload[$k] = 'dashboard';
                $payload['role_clamped'] = true;
            }
        }
        if ($targetRoute !== '' && !self::routeAllowedForRole($roleForClamp, $targetRoute)) {
            $targetRoute = 'dashboard';
        }

        try {
            Database::insert(
                'INSERT INTO voice_command_logs (user_id, spoken_text, detected_intent, target_route, action_summary, spoken_response, created_shamsi)
                 VALUES (?, ?, ?, ?, ?, ?, ?)',
                [
                    max(1, $userId),
                    mb_substr(trim($spokenText), 0, 490, 'UTF-8'),
                    $intent,
                    $targetRoute,
                    mb_substr($summary, 0, 250, 'UTF-8'),
                    (string)($payload['spoken_reply'] ?? ''),
                    Jalali::today(),
                ]
            );
        } catch (\Throwable) {
            // حفظ پایداری پاسخ صوتی حتی در صورت خطای لاگ
        }
        return $payload;
    }
}
