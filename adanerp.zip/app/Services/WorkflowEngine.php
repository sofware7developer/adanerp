<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Auth;
use App\Core\Database;
use App\Core\Jalali;

final class WorkflowEngine
{
    public static function transition(int $workflowId, string $decision, string $note = ''): bool
    {
        if (!in_array($decision, ['approve', 'reject'], true)) {
            throw new \InvalidArgumentException('تصمیم گردش‌کار معتبر نیست.');
        }
        $pdo = Database::connection();
        $pdo->beginTransaction();
        try {
            $wf = Database::fetchOne('SELECT * FROM bpms_workflows WHERE id = ? FOR UPDATE', [$workflowId]);
            if (!$wf || $wf['status'] !== 'running') {
                $pdo->commit();
                return false;
            }
            $user = Auth::user();
            $role = (string)Auth::role();
            $assignedRoles = array_values(array_filter(array_map('trim', preg_split('/[,+]/', (string)$wf['assigned_role']) ?: [])));
            if (!in_array($role, $assignedRoles, true)) {
                throw new \DomainException('نقش فعلی مسئول تأیید این گردش‌کار نیست.');
            }
            $history = json_decode((string)$wf['history_json'], true);
            if (!is_array($history)) {
                $history = [];
            }
            $approvedRoles = [];
            foreach ($history as $entry) {
                if (($entry['decision'] ?? '') === 'approve' && isset($entry['role'])) {
                    $approvedRoles[] = (string)$entry['role'];
                }
            }
            if ($decision === 'approve' && in_array($role, $approvedRoles, true)) {
                $pdo->commit();
                return false;
            }

            $label = $decision === 'approve' ? 'تأیید مرحله' : 'رد / بازگشت جهت اصلاح';
            $history[] = [
                'step' => $label . ($note !== '' ? ' (' . $note . ')' : ''),
                'by' => $user['full_name'] ?? 'مدیر سیستم',
                'role' => $role,
                'decision' => $decision,
                'time' => Jalali::today() . ' ' . Jalali::digits(date('H:i')),
            ];

            if ($decision === 'approve') {
                $approvedRoles[] = $role;
                $remainingRoles = array_values(array_diff($assignedRoles, array_unique($approvedRoles)));
                $newStatus = $remainingRoles === [] ? 'approved' : 'running';
                $nextStep = $remainingRoles === []
                    ? 'تأیید نهایی و ابلاغ سیستمی'
                    : 'در انتظار تأیید: ' . implode(' + ', $remainingRoles);
            } else {
                $newStatus = 'rejected';
                $nextStep = 'بازگشت به کارشناس آغازگر';
            }

            $updated = Database::execute(
                'UPDATE bpms_workflows SET status = ?, current_step = ?, history_json = ? WHERE id = ? AND status = "running"',
                [$newStatus, $nextStep, json_encode($history, JSON_UNESCAPED_UNICODE), $workflowId]
            );
            if ($updated !== 1) {
                $pdo->rollBack();
                return false;
            }

            Auth::audit('BPMS', 'WORKFLOW_' . strtoupper($decision), 'bpms_workflow', $workflowId, ['note' => $note]);
            $pdo->commit();
            return true;
        } catch (\Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }
    }
}
