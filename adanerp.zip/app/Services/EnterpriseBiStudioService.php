<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Auth;
use App\Core\Database;
use App\Core\Jalali;

/**
 * موتور جامع هوش تجاری (Enterprise BI Studio)، گزارش‌ساز چندحالته (کلیک، درگ‌انددراپ، متنی، صوتی)،
 * داشبوردساز تعاملی، هدف‌گذاری راهبردی (OKR / KPI Targets)، شبیه‌ساز سناریو (What-If) و کشف ناهنجاری
 */
final class EnterpriseBiStudioService
{
    public const CHART_TYPES = [
        'bar'     => 'نمودار ستونی عمودی',
        'hbar'    => 'نمودار میله‌ای افقی',
        'line'    => 'نمودار خطی و مساحتی روند',
        'donut'   => 'نمودار حلقوی سهم بازار',
        'funnel'  => 'نمودار قیفی تبدیل',
        'radar'   => 'نمودار راداری چندبعدی',
        'gauge'   => 'عقربه تحقق هدف (Gauge)',
        'heatmap' => 'ماتریس حرارتی شدت',
        'table'   => 'جدول پیوت تحلیلی',
    ];

    public const AGG_FUNCS = [
        'SUM'   => 'مجموع کل (SUM)',
        'AVG'   => 'میانگین (AVG)',
        'COUNT' => 'تعداد رکورد (COUNT)',
        'MAX'   => 'بیشترین مقدار (MAX)',
        'MIN'   => 'کمترین مقدار (MIN)',
    ];

    public const DATA_MARTS = [
        'courses_mart' => [
            'label' => 'دوره‌های آموزشی، شهریه و رضایت',
            'table' => 'courses',
            'unit'  => 'ریال',
            'dimensions' => [
                'level'           => 'سطح دوره',
                'delivery_mode'   => 'شیوه برگزاری',
                'workflow_status' => 'وضعیت انتشار',
                'title'           => 'عنوان دوره',
                'code'            => 'کد دوره',
            ],
            'metrics' => [
                'tuition_rial'        => 'شهریه مصوب (ریال)',
                'duration_hours'      => 'مدت آموزش (ساعت)',
                'rating'              => 'امتیاز رضایت فراگیران',
                'member_discount_pct' => 'درصد تخفیف اعضا',
                'id'                  => 'تعداد دوره‌ها',
            ],
        ],
        'invoices_mart' => [
            'label' => 'صورت‌حساب‌ها، مالیات ارزش افزوده و وصولی',
            'table' => 'invoices',
            'unit'  => 'ریال',
            'dimensions' => [
                'status'           => 'وضعیت پرداخت',
                'payment_mode'     => 'روش تسویه',
                'item_description' => 'شرح خدمت آموزشی',
            ],
            'metrics' => [
                'total_rial'    => 'مبلغ قابل پرداخت (ریال)',
                'subtotal_rial' => 'مبلغ پایه قبل از تخفیف',
                'vat_rial'      => 'مالیات ارزش افزوده (ریال)',
                'discount_rial' => 'تخفیف اعطایی (ریال)',
                'id'            => 'تعداد فاکتورها',
            ],
        ],
        'vouchers_mart' => [
            'label' => 'دفترکل و اسناد حسابداری چهارسطحی',
            'table' => 'accounting_vouchers',
            'unit'  => 'ریال',
            'dimensions' => [
                'kol_account'    => 'حساب کل',
                'moein_account'  => 'حساب معین',
                'group_code'     => 'گروه حساب',
                'tafsili_entity' => 'تفصیلی شناور',
                'voucher_shamsi' => 'تاریخ سند',
            ],
            'metrics' => [
                'debit_rial'  => 'گردش بدهکار (ریال)',
                'credit_rial' => 'گردش بستانکار (ریال)',
                'id'          => 'تعداد آرتیکل سند',
            ],
        ],
        'crm_mart' => [
            'label' => 'قیف فروش سازمانی و مذاکرات CRM',
            'table' => 'crm_deals',
            'unit'  => 'ریال',
            'dimensions' => [
                'stage'                => 'مرحله قیف فروش',
                'title'                => 'عنوان قرارداد پیشنهادی',
                'next_followup_shamsi' => 'تاریخ پیگیری بعدی',
            ],
            'metrics' => [
                'estimated_value_rial' => 'ارزش برآوردی قرارداد (ریال)',
                'probability_pct'      => 'احتمال عقد قرارداد (٪)',
                'id'                   => 'تعداد پرونده فروش',
            ],
        ],
        'orgs_mart' => [
            'label' => 'سازمان‌های طرف قرارداد آموزشی',
            'table' => 'organizations',
            'unit'  => 'ساعت',
            'dimensions' => [
                'industry'        => 'بخش صنعتی / صنفی',
                'membership_tier' => 'گروه سازمانی',
                'city'            => 'شهر مستقر',
                'name'            => 'نام شرکت / کارخانه',
            ],
            'metrics' => [
                'used_quota_hours'   => 'سهمیه آموزشی مصرف‌شده (ساعت)',
                'annual_quota_hours' => 'کل سهمیه سالانه (ساعت)',
                'id'                 => 'تعداد سازمان',
            ],
        ],
        'enrollments_mart' => [
            'label' => 'ثبت‌نام، حضور کلاسی و نمرات فراگیران',
            'table' => 'enrollments',
            'unit'  => 'امتیاز',
            'dimensions' => [
                'source' => 'کانال ثبت‌نام',
                'status' => 'وضعیت تحصیلی',
            ],
            'metrics' => [
                'final_score'    => 'نمره پایانی',
                'attendance_pct' => 'درصد حضور در کلاس',
                'progress_pct'   => 'درصد پیشرفت محتوا',
                'id'             => 'تعداد ثبت‌نام',
            ],
        ],
        'oa_mart' => [
            'label' => 'اتوماسیون اداری، مکاتبات و دبیرخانه',
            'table' => 'oa_letters',
            'unit'  => 'فقره',
            'dimensions' => [
                'letter_type'     => 'نوع مکاتبه (وارده / صادره / داخلی)',
                'priority_level'  => 'فوریت نامه',
                'confidentiality' => 'سطح محرمانگی',
                'sign_status'     => 'وضعیت امضا',
                'sender_unit'     => 'واحد فرستنده',
            ],
            'metrics' => [
                'id' => 'تعداد نامه‌های ثبت‌شده',
            ],
        ],
        'career_mart' => [
            'label' => 'کاریابی تخصصی، آگهی‌های استخدام و ATS',
            'table' => 'career_job_ads',
            'unit'  => 'نفر',
            'dimensions' => [
                'city_location'    => 'شهر / قطب صنعتی',
                'category_slug'    => 'گروه شغلی',
                'seniority_level'  => 'سطح ارشدیت',
                'cooperation_type' => 'نوع همکاری',
                'company_name'     => 'کارفرمای عضو',
            ],
            'metrics' => [
                'applicants_count'   => 'تعداد رزومه دریافتی',
                'views_count'        => 'بازدید آگهی شغلی',
                'salary_max_million' => 'سقف حقوق پیشنهادی (میلیون تومان)',
                'salary_min_million' => 'کف حقوق پیشنهادی (میلیون تومان)',
            ],
        ],
    ];

    public const LIVE_GOAL_SOURCES = [
        'invoices_total_rial'    => ['label' => 'مجموع کل صورت‌حساب‌های آموزشی (ریال)', 'unit' => 'ریال'],
        'crm_pipeline_rial'      => ['label' => 'ارزش کل پایپ‌لاین قراردادهای سازمانی (ریال)', 'unit' => 'ریال'],
        'courses_avg_rating_pct' => ['label' => 'شاخص رضایت کیفی فراگیران از دوره‌ها (٪)', 'unit' => 'درصد'],
        'branches_learners_sum'  => ['label' => 'مجموع مهارت‌آموختگان دفاتر شهرستان‌ها (نفر)', 'unit' => 'نفر'],
        'oa_letters_count'       => ['label' => 'تعداد مکاتبات رسمی ثبت‌شده در اتوماسیون', 'unit' => 'فقره نامه'],
        'career_applicants_sum'  => ['label' => 'کل کارجویان معرفی‌شده در سامانه کاریابی', 'unit' => 'متقاضی'],
        'enrollments_avg_score'  => ['label' => 'میانگین نمره کارنامه پایانی فراگیران', 'unit' => 'نمره'],
        'certificates_count'     => ['label' => 'تعداد گواهی‌نامه‌های رسمی QR صادرشده', 'unit' => 'گواهی'],
    ];

    public const PRESET_REPORT_CATALOG = [
        ['code' => 'CAT-01', 'group' => 'مالی و حسابداری', 'title' => 'تحلیل صورت‌حساب‌ها و مالیات ارزش افزوده به تفکیک وضعیت تسویه', 'dataset' => 'invoices_mart', 'dim' => 'status', 'metric' => 'total_rial', 'agg' => 'SUM', 'chart' => 'donut'],
        ['code' => 'CAT-02', 'group' => 'مالی و حسابداری', 'title' => 'گردش بدهکار و تراز حساب‌های کل در اسناد چهارسطحی', 'dataset' => 'vouchers_mart', 'dim' => 'kol_account', 'metric' => 'debit_rial', 'agg' => 'SUM', 'chart' => 'bar'],
        ['code' => 'CAT-03', 'group' => 'مالی و حسابداری', 'title' => 'مقایسه روش‌های تسویه نقدی، اقساطی و سازمانی', 'dataset' => 'invoices_mart', 'dim' => 'payment_mode', 'metric' => 'subtotal_rial', 'agg' => 'SUM', 'chart' => 'hbar'],
        ['code' => 'CAT-04', 'group' => 'آموزش و کیفیت', 'title' => 'ظرفیت شهریه دوره‌ها بر اساس سطح تخصصی', 'dataset' => 'courses_mart', 'dim' => 'level', 'metric' => 'tuition_rial', 'agg' => 'SUM', 'chart' => 'bar'],
        ['code' => 'CAT-05', 'group' => 'آموزش و کیفیت', 'title' => 'مقایسه ساعات آموزشی دوره‌ها بر پایه شیوه برگزاری', 'dataset' => 'courses_mart', 'dim' => 'delivery_mode', 'metric' => 'duration_hours', 'agg' => 'SUM', 'chart' => 'donut'],
        ['code' => 'CAT-06', 'group' => 'آموزش و کیفیت', 'title' => 'میانگین نمره پایانی فراگیران بر حسب کانال جذب', 'dataset' => 'enrollments_mart', 'dim' => 'source', 'metric' => 'final_score', 'agg' => 'AVG', 'chart' => 'line'],
        ['code' => 'CAT-07', 'group' => 'فروش سازمانی و اعضا', 'title' => 'قیف تبدیل مذاکرات فروش سازمانی و ارزش ریالی هر مرحله', 'dataset' => 'crm_mart', 'dim' => 'stage', 'metric' => 'estimated_value_rial', 'agg' => 'SUM', 'chart' => 'funnel'],
        ['code' => 'CAT-08', 'group' => 'فروش سازمانی و اعضا', 'title' => 'مصرف سهمیه آموزشی بنگاه‌ها به تفکیک صنعت', 'dataset' => 'orgs_mart', 'dim' => 'industry', 'metric' => 'used_quota_hours', 'agg' => 'SUM', 'chart' => 'radar'],
        ['code' => 'CAT-09', 'group' => 'فروش سازمانی و اعضا', 'title' => 'توزیع جغرافیایی شرکت‌های طرف قرارداد مؤسسه آموزشی آدان', 'dataset' => 'orgs_mart', 'dim' => 'city', 'metric' => 'annual_quota_hours', 'agg' => 'SUM', 'chart' => 'bar'],
        ['code' => 'CAT-10', 'group' => 'کارت بازرگانی و شعب', 'title' => 'میانگین نمره آزمون متقاضیان کارت بازرگانی بر اساس وضعیت تأیید', 'dataset' => 'cards_mart', 'dim' => 'clearance_status', 'metric' => 'exam_score', 'agg' => 'AVG', 'chart' => 'bar'],
        ['code' => 'CAT-11', 'group' => 'کارت بازرگانی و شعب', 'title' => 'مقایسه عملکرد بودجه دفاتر نمایندگی شهرستان‌های استان', 'dataset' => 'branches_mart', 'dim' => 'county_name', 'metric' => 'spent_budget_rial', 'agg' => 'SUM', 'chart' => 'radar'],
        ['code' => 'CAT-12', 'group' => 'کارت بازرگانی و شعب', 'title' => 'آمار تربیت فراگیران مهارتی در شعب شهرستان‌ها', 'dataset' => 'branches_mart', 'dim' => 'county_name', 'metric' => 'trained_learners_count', 'agg' => 'SUM', 'chart' => 'hbar'],
        ['code' => 'CAT-13', 'group' => 'اتوماسیون اداری و اشتغال', 'title' => 'ترکیب نامه‌های وارده، صادره و داخلی در دبیرخانه', 'dataset' => 'oa_mart', 'dim' => 'letter_type', 'metric' => 'id', 'agg' => 'COUNT', 'chart' => 'donut'],
        ['code' => 'CAT-14', 'group' => 'اتوماسیون اداری و اشتغال', 'title' => 'پایش مکاتبات اداری بر اساس درجه فوریت و وضعیت امضا', 'dataset' => 'oa_mart', 'dim' => 'priority_level', 'metric' => 'id', 'agg' => 'COUNT', 'chart' => 'heatmap'],
        ['code' => 'CAT-15', 'group' => 'اتوماسیون اداری و اشتغال', 'title' => 'تقاضای جذب نیرو و تعداد رزومه دریافتی به تفکیک قطب صنعتی', 'dataset' => 'career_mart', 'dim' => 'city_location', 'metric' => 'applicants_count', 'agg' => 'SUM', 'chart' => 'bar'],
        ['code' => 'CAT-16', 'group' => 'اتوماسیون اداری و اشتغال', 'title' => 'مقایسه سقف حقوق پیشنهادی کارفرمایان بر اساس سطح ارشدیت', 'dataset' => 'career_mart', 'dim' => 'seniority_level', 'metric' => 'salary_max_million', 'agg' => 'AVG', 'chart' => 'line'],
    ];

    /**
     * اجرای امن و ضدتزریق SQL روی یکی از ۱۰ مخزن داده تحلیلی به همراه محاسبه سهم درصدی و شاخص‌های خلاصه
     */
    public static function executeSemanticQuery(array $spec): array
    {
        $dsKey = isset(self::DATA_MARTS[$spec['dataset_key'] ?? '']) ? (string)$spec['dataset_key'] : 'courses_mart';
        $mart = self::DATA_MARTS[$dsKey];
        $table = $mart['table'];

        $dims = $mart['dimensions'];
        $metrics = $mart['metrics'];

        $dim = isset($dims[$spec['dimension_field'] ?? '']) ? (string)$spec['dimension_field'] : (string)array_key_first($dims);
        $metric = isset($metrics[$spec['metric_field'] ?? '']) ? (string)$spec['metric_field'] : (string)array_key_first($metrics);

        $agg = strtoupper((string)($spec['agg_func'] ?? 'SUM'));
        if (!isset(self::AGG_FUNCS[$agg])) {
            $agg = 'SUM';
        }
        if ($metric === 'id' && $agg !== 'COUNT') {
            $agg = 'COUNT';
        }

        $sortDir = strtoupper((string)($spec['sort_dir'] ?? 'DESC')) === 'ASC' ? 'ASC' : 'DESC';
        $limit = max(3, min(100, (int)($spec['row_limit'] ?? 20)));
        $chartType = isset(self::CHART_TYPES[$spec['chart_type'] ?? '']) ? (string)$spec['chart_type'] : 'bar';

        $whereSql = '';
        $params = [];
        $filterField = (string)($spec['filter_field'] ?? '');
        $filterVal = trim((string)($spec['filter_val'] ?? ''));
        $filterOp = (string)($spec['filter_op'] ?? '=');

        $allAllowedCols = array_merge($dims, $metrics);
        if ($filterField !== '' && $filterVal !== '' && isset($allAllowedCols[$filterField])) {
            if ($filterOp === 'CONTAINS') {
                $whereSql = " WHERE `{$filterField}` LIKE ?";
                $params[] = '%' . $filterVal . '%';
            } elseif (in_array($filterOp, ['=', '!=', '>', '<', '>=', '<='], true)) {
                $whereSql = " WHERE `{$filterField}` {$filterOp} ?";
                $params[] = is_numeric($filterVal) ? (float)$filterVal : $filterVal;
            }
        }

        $aggExpr = $agg === 'COUNT' ? "COUNT(`{$metric}`)" : "ROUND(COALESCE({$agg}(`{$metric}`), 0), 2)";
        $sql = "SELECT COALESCE(CAST(`{$dim}` AS CHAR), 'نامشخص') AS dim_label, "
             . "{$aggExpr} AS metric_val, "
             . "COUNT(*) AS records_cnt "
             . "FROM `{$table}`{$whereSql} "
             . "GROUP BY `{$dim}` "
             . "ORDER BY metric_val {$sortDir} "
             . "LIMIT {$limit}";

        $rawRows = Database::fetchAll($sql, $params);
        $grandTotal = 0.0;
        $maxVal = 0.0;
        foreach ($rawRows as $r) {
            $v = (float)($r['metric_val'] ?? 0);
            $grandTotal += $v;
            if ($v > $maxVal) {
                $maxVal = $v;
            }
        }

        $enriched = [];
        foreach ($rawRows as $idx => $r) {
            $v = (float)($r['metric_val'] ?? 0);
            $share = $grandTotal > 0 ? round(($v / $grandTotal) * 100, 1) : 0.0;
            $enriched[] = [
                'rank'        => $idx + 1,
                'label'       => (string)$r['dim_label'],
                'value'       => $v,
                'records_cnt' => (int)$r['records_cnt'],
                'share_pct'   => $share,
            ];
        }

        return [
            'dataset_key'     => $dsKey,
            'dataset_label'   => $mart['label'],
            'dimension_field' => $dim,
            'dimension_label' => $dims[$dim],
            'metric_field'    => $metric,
            'metric_label'    => $metrics[$metric],
            'agg_func'        => $agg,
            'agg_label'       => self::AGG_FUNCS[$agg],
            'chart_type'      => $chartType,
            'chart_label'     => self::CHART_TYPES[$chartType],
            'unit'            => $agg === 'COUNT' ? 'مورد' : $mart['unit'],
            'sql_preview'     => $sql,
            'rows'            => $enriched,
            'summary'         => [
                'groups_count' => count($enriched),
                'grand_total'  => round($grandTotal, 2),
                'average_val'  => count($enriched) > 0 ? round($grandTotal / count($enriched), 2) : 0.0,
                'max_val'      => round($maxVal, 2),
                'top_item'     => $enriched[0]['label'] ?? '—',
            ],
        ];
    }

    /**
     * مترجم هوشمند دستور متنی و فرمان صوتی فارسی به گزارش، ویجت داشبورد، داشبورد جدید یا هدف کمی (OKR)
     */
    public static function compileNaturalLanguageOrVoice(
        string $rawPrompt,
        string $mode = 'text',
        int $targetDashboardId = 1,
        string $actorName = 'مدیرکل آموزش',
        bool $persistArtifact = false
    ): array {
        $norm = self::normalizePersianDigits(trim($rawPrompt));
        if ($norm === '') {
            $norm = 'گزارش شهریه دوره‌ها بر اساس سطح دوره با نمودار ستونی';
        }

        // تشخیص نوع نمودار از متن طبیعی یا صدای کاربر
        $chart = 'bar';
        if (preg_match('/(حلقوی|دایره|کیکی|سهم|درصد ترکیب)/u', $norm)) {
            $chart = 'donut';
        } elseif (preg_match('/(قیف|قیفی|تبدیل مراحل)/u', $norm)) {
            $chart = 'funnel';
        } elseif (preg_match('/(خطی|روند|منحنی|زمانی)/u', $norm)) {
            $chart = 'line';
        } elseif (preg_match('/(رادار|راداری|عنکبوتی|چندبعدی)/u', $norm)) {
            $chart = 'radar';
        } elseif (preg_match('/(افقی|میله‌ای افقی|رتبه‌بندی)/u', $norm)) {
            $chart = 'hbar';
        } elseif (preg_match('/(گیج|عقربه|سرعت‌سنج|تحقق)/u', $norm)) {
            $chart = 'gauge';
        } elseif (preg_match('/(حرارتی|ماتریس|شدت)/u', $norm)) {
            $chart = 'heatmap';
        } elseif (preg_match('/(جدول|فهرست|لیست)/u', $norm)) {
            $chart = 'table';
        }

        // تشخیص مخزن داده، بُعد و شاخص از کلیدواژه‌های تخصصی فارسی
        $dataset = 'courses_mart';
        $dim = 'level';
        $metric = 'tuition_rial';
        $agg = 'SUM';

        if (preg_match('/(فاکتور|صورتحساب|صورت‌حساب|مالیات|ارزش افزوده|وصولی)/u', $norm)) {
            $dataset = 'invoices_mart';
            $dim = preg_match('/(روش|نقد|اقساط)/u', $norm) ? 'payment_mode' : 'status';
            $metric = preg_match('/مالیات|ارزش افزوده/u', $norm) ? 'vat_rial' : 'total_rial';
        } elseif (preg_match('/(سند حسابداری|دفترکل|بدهکار|بستانکار|معین|حساب کل)/u', $norm)) {
            $dataset = 'vouchers_mart';
            $dim = preg_match('/معین/u', $norm) ? 'moein_account' : 'kol_account';
            $metric = preg_match('/بستانکار/u', $norm) ? 'credit_rial' : 'debit_rial';
        } elseif (preg_match('/(قیف فروش|مذاکره|crm|فرصت فروش|قرارداد پیشنهادی)/iu', $norm)) {
            $dataset = 'crm_mart';
            $dim = 'stage';
            $metric = preg_match('/احتمال/u', $norm) ? 'probability_pct' : 'estimated_value_rial';
            if ($chart === 'bar' && str_contains($norm, 'قیف')) {
                $chart = 'funnel';
            }
        } elseif (preg_match('/(شرکت|کارخانه|بنگاه|صنعت|سهمیه اعضا)/u', $norm)) {
            $dataset = 'orgs_mart';
            $dim = preg_match('/شهر/u', $norm) ? 'city' : (preg_match('/رتبه/u', $norm) ? 'membership_tier' : 'industry');
            $metric = 'used_quota_hours';
        } elseif (preg_match('/(ثبت‌نام|حضور|نمره|کارنامه|پیشرفت فراگیر)/u', $norm)) {
            $dataset = 'enrollments_mart';
            $dim = preg_match('/وضعیت/u', $norm) ? 'status' : 'source';
            $metric = preg_match('/حضور/u', $norm) ? 'attendance_pct' : 'final_score';
            $agg = 'AVG';
        } elseif (preg_match('/(کارت بازرگانی|تأییدیه قانونی|متقاضیان کارت)/u', $norm)) {
            $dataset = 'cards_mart';
            $dim = preg_match('/نوع/u', $norm) ? 'card_request_type' : 'clearance_status';
            $metric = 'exam_score';
            $agg = 'AVG';
        } elseif (preg_match('/(شهرستان|شعبه|شعب|دفاتر نمایندگی|بودجه استان)/u', $norm)) {
            $dataset = 'branches_mart';
            $dim = 'county_name';
            $metric = preg_match('/فراگیر|نفر/u', $norm) ? 'trained_learners_count' : 'spent_budget_rial';
        } elseif (preg_match('/(نامه|مکاتبات|اتوماسیون|دبیرخانه|وارده|صادره)/u', $norm)) {
            $dataset = 'oa_mart';
            $dim = preg_match('/فوریت|فوری/u', $norm) ? 'priority_level' : (preg_match('/امضا/u', $norm) ? 'sign_status' : 'letter_type');
            $metric = 'id';
            $agg = 'COUNT';
        } elseif (preg_match('/(کاریابی|استخدام|شغل|رزومه|حقوق)/u', $norm)) {
            $dataset = 'career_mart';
            $dim = preg_match('/ارشدیت/u', $norm) ? 'seniority_level' : 'city_location';
            $metric = preg_match('/حقوق/u', $norm) ? 'salary_max_million' : 'applicants_count';
        } else {
            if (preg_match('/(شیوه|آنلاین|حضوری)/u', $norm)) {
                $dim = 'delivery_mode';
            } elseif (preg_match('/وضعیت/u', $norm)) {
                $dim = 'workflow_status';
            }
            if (preg_match('/ساعت|مدت/u', $norm)) {
                $metric = 'duration_hours';
            } elseif (preg_match('/رضایت|امتیاز/u', $norm)) {
                $metric = 'rating';
                $agg = 'AVG';
            }
        }

        if (preg_match('/میانگین/u', $norm)) {
            $agg = 'AVG';
        } elseif (preg_match('/تعداد|شمارش/u', $norm)) {
            $agg = 'COUNT';
        } elseif (preg_match('/بیشترین|سقف/u', $norm)) {
            $agg = 'MAX';
        }

        // ۱. اگر دستور کاربر برای «هدف‌گذاری / تارگت / OKR» باشد
        if (preg_match('/(هدف|تارگت|okr)/iu', $norm) && $persistArtifact) {
            $targetNum = self::extractSpokenMagnitude($norm, 500000000.0);
            $source = match ($dataset) {
                'crm_mart'         => 'crm_pipeline_rial',
                'branches_mart'    => 'branches_learners_sum',
                'oa_mart'          => 'oa_letters_count',
                'career_mart'      => 'career_applicants_sum',
                'enrollments_mart' => 'enrollments_avg_score',
                default            => 'invoices_total_rial',
            };
            $goalRes = self::createGoal([
                'title'              => mb_substr($rawPrompt, 0, 175),
                'department_owner'   => str_contains($norm, 'مالی') ? 'مدیریت امور مالی' : (str_contains($norm, 'فروش') ? 'واحد توسعه بازار و CRM' : 'معاونت آموزش'),
                'horizon_label'      => 'دوره جاری ۱۴۰۵',
                'live_metric_source' => $source,
                'target_value'       => $targetNum,
                'unit_label'         => self::LIVE_GOAL_SOURCES[$source]['unit'],
                'key_results_note'   => 'ثبت هوشمند از طریق فرمان ' . ($mode === 'voice' ? 'صوتی' : 'متنی'),
                'created_via'        => $mode,
            ]);
            return [
                'ok'          => true,
                'intent'      => 'goal_created',
                'mode'        => $mode,
                'goal'        => $goalRes,
                'spoken_text' => 'هدف راهبردی جدید با موفقیت ثبت شد و پایش زنده آن روی عقربه هدف‌گذاری فعال گردید.',
            ];
        }

        // ۲. اگر دستور کاربر برای ساخت «داشبورد جدید» باشد
        if (preg_match('/(داشبورد جدید|بساز داشبورد|ایجاد داشبورد|داشبورد اختصاصی)/u', $norm) && $persistArtifact) {
            $cleanTitle = trim((string)preg_replace('/^(یک\s+)?(داشبورد\s+جدید\s+(به\s+نام|با\s+عنوان)?)/u', '', $rawPrompt)) ?: 'داشبورد تحلیلی هوشمند';
            $dashRes = self::createDashboard([
                'title'       => 'داشبورد ' . mb_substr($cleanTitle, 0, 120),
                'subtitle'    => 'ساخته‌شده به صورت خودکار از فرمان ' . ($mode === 'voice' ? 'صوتی' : 'متنی') . ' با ویجت‌های زنده',
                'category'    => 'داشبورد هوشمند سفارشی',
                'created_via' => $mode,
            ], $actorName, true);
            return [
                'ok'           => true,
                'intent'       => 'dashboard_created',
                'mode'         => $mode,
                'dashboard_id' => $dashRes['id'],
                'spoken_text'  => 'داشبورد جدید به همراه چهار ویجت تحلیلی زنده ساخته شد و آماده بهره‌برداری است.',
            ];
        }

        $queryResult = self::executeSemanticQuery([
            'dataset_key'     => $dataset,
            'dimension_field' => $dim,
            'metric_field'    => $metric,
            'agg_func'        => $agg,
            'chart_type'      => $chart,
        ]);

        $aiGen = AvalAiService::generate(
            "بر اساس خروجی زنده BI با موضوع «{$rawPrompt}»، بیشترین مقدار مربوط به «"
            . ($queryResult['summary']['top_item'] ?? '') . "» با جمع کل «"
            . number_format((float)$queryResult['summary']['grand_total'])
            . "» است. در ۲ جمله کوتاه مدیریتی تحلیل و پیشنهاد اجرایی ارائه بده.",
            'Enterprise BI Studio'
        );
        $narrative = trim((string)($aiGen['content'] ?? ''));

        $savedWidgetId = null;
        $savedReportId = null;
        if ($persistArtifact) {
            if (preg_match('/(ویجت|به داشبورد|روی داشبورد)/u', $norm)) {
                $w = self::addWidgetToDashboard($targetDashboardId, [
                    'title'           => mb_substr($rawPrompt, 0, 140),
                    'subtitle'        => $queryResult['dataset_label'],
                    'dataset_key'     => $dataset,
                    'dimension_field' => $dim,
                    'metric_field'    => $metric,
                    'agg_func'        => $agg,
                    'chart_type'      => $chart,
                    'col_span'        => 6,
                    'created_via'     => $mode,
                ]);
                $savedWidgetId = $w['id'];
            } else {
                $rep = self::saveCustomReport([
                    'title'              => mb_substr($rawPrompt, 0, 160),
                    'category'           => $mode === 'voice' ? 'گزارش فرمان صوتی' : 'گزارش تحلیلی متنی',
                    'dataset_key'        => $dataset,
                    'dimension_field'    => $dim,
                    'metric_field'       => $metric,
                    'agg_func'           => $agg,
                    'chart_type'         => $chart,
                    'natural_query_text' => $rawPrompt,
                    'ai_narrative'       => $narrative,
                    'created_via'        => $mode,
                ], $actorName);
                $savedReportId = $rep['id'];
            }
        }

        $spokenSummary = sprintf(
            'گزارش %s آماده شد. در مجموع %s ردیف دسته‌بندی استخراج گردید و «%s» با سهم صدرنشین در رتبه نخست قرار دارد.',
            $queryResult['dataset_label'],
            (string)$queryResult['summary']['groups_count'],
            (string)$queryResult['summary']['top_item']
        );

        return [
            'ok'              => true,
            'intent'          => $savedWidgetId ? 'widget_pinned' : 'report_built',
            'mode'            => $mode,
            'query'           => $queryResult,
            'ai_narrative'    => $narrative,
            'saved_widget_id' => $savedWidgetId,
            'saved_report_id' => $savedReportId,
            'spoken_text'     => $spokenSummary,
        ];
    }

    public static function createDashboard(array $input, string $actorName, bool $seedStarterWidgets = true): array
    {
        $slug = 'board-' . strtolower(substr(md5(uniqid('', true)), 0, 8));
        $title = trim((string)($input['title'] ?? '')) ?: 'داشبورد مدیریتی سفارشی';
        $subtitle = trim((string)($input['subtitle'] ?? '')) ?: 'چیدمان تعاملی شاخص‌های کلیدی عملکرد و نمودارهای زنده';
        $accent = preg_match('/^#[0-9a-fA-F]{6}$/', (string)($input['accent_color'] ?? '')) ? (string)$input['accent_color'] : '#4f46e5';
        $via = in_array($input['created_via'] ?? '', ['click', 'drag_drop', 'text', 'voice'], true) ? (string)$input['created_via'] : 'click';

        $id = Database::insert(
            'INSERT INTO bi_dashboards (slug, title, subtitle, category, accent_color, layout_density, created_via, is_default, created_by_name, updated_shamsi)
             VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?, ?)',
            [
                $slug,
                $title,
                $subtitle,
                trim((string)($input['category'] ?? 'مدیریتی سفارشی')),
                $accent,
                in_array($input['layout_density'] ?? '', ['compact', 'balanced', 'spacious'], true) ? $input['layout_density'] : 'balanced',
                $via,
                $actorName,
                Jalali::today(),
            ]
        );

        if ($seedStarterWidgets) {
            self::addWidgetToDashboard($id, [
                'title' => 'درآمد و وضعیت تسویه صورت‌حساب‌ها', 'dataset_key' => 'invoices_mart',
                'dimension_field' => 'status', 'metric_field' => 'total_rial', 'agg_func' => 'SUM',
                'chart_type' => 'bar', 'col_span' => 6, 'created_via' => $via,
            ]);
            self::addWidgetToDashboard($id, [
                'title' => 'قیف قراردادهای سازمانی CRM', 'dataset_key' => 'crm_mart',
                'dimension_field' => 'stage', 'metric_field' => 'estimated_value_rial', 'agg_func' => 'SUM',
                'chart_type' => 'funnel', 'col_span' => 6, 'created_via' => $via,
            ]);
            self::addWidgetToDashboard($id, [
                'title' => 'عملکرد دفاتر نمایندگی شهرستان‌ها', 'dataset_key' => 'branches_mart',
                'dimension_field' => 'county_name', 'metric_field' => 'spent_budget_rial', 'agg_func' => 'SUM',
                'chart_type' => 'donut', 'col_span' => 6, 'created_via' => $via,
            ]);
            self::addWidgetToDashboard($id, [
                'title' => 'وضعیت مکاتبات رسمی دبیرخانه', 'dataset_key' => 'oa_mart',
                'dimension_field' => 'letter_type', 'metric_field' => 'id', 'agg_func' => 'COUNT',
                'chart_type' => 'hbar', 'col_span' => 6, 'created_via' => $via,
            ]);
        }

        Auth::audit('BI_STUDIO', 'CREATE_DASHBOARD', 'bi_dashboards', $id, ['via' => $via]);
        return ['ok' => true, 'id' => $id, 'slug' => $slug];
    }

    public static function addWidgetToDashboard(int $dashboardId, array $input): array
    {
        $dsKey = isset(self::DATA_MARTS[$input['dataset_key'] ?? '']) ? (string)$input['dataset_key'] : 'courses_mart';
        $mart = self::DATA_MARTS[$dsKey];
        $dim = isset($mart['dimensions'][$input['dimension_field'] ?? '']) ? (string)$input['dimension_field'] : (string)array_key_first($mart['dimensions']);
        $metric = isset($mart['metrics'][$input['metric_field'] ?? '']) ? (string)$input['metric_field'] : (string)array_key_first($mart['metrics']);
        $agg = isset(self::AGG_FUNCS[strtoupper((string)($input['agg_func'] ?? ''))]) ? strtoupper((string)$input['agg_func']) : 'SUM';
        $chart = isset(self::CHART_TYPES[$input['chart_type'] ?? '']) ? (string)$input['chart_type'] : 'bar';
        $span = in_array((int)($input['col_span'] ?? 6), [3, 4, 6, 8, 12], true) ? (int)$input['col_span'] : 6;
        $via = in_array($input['created_via'] ?? '', ['click', 'drag_drop', 'text', 'voice'], true) ? (string)$input['created_via'] : 'drag_drop';

        $code = 'WDG-' . strtoupper(substr(md5(uniqid('', true)), 0, 7));
        $maxSort = (int)Database::scalar('SELECT COALESCE(MAX(sort_order), 0) FROM bi_dashboard_widgets WHERE dashboard_id = ?', [$dashboardId]);
        $title = trim((string)($input['title'] ?? '')) ?: ($mart['metrics'][$metric] . ' بر اساس ' . $mart['dimensions'][$dim]);

        $id = Database::insert(
            'INSERT INTO bi_dashboard_widgets
             (dashboard_id, widget_code, title, subtitle, dataset_key, dimension_field, metric_field, agg_func, filter_field, filter_op, filter_val, chart_type, col_span, sort_order, color_palette, created_via, updated_shamsi)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [
                max(1, $dashboardId),
                $code,
                $title,
                trim((string)($input['subtitle'] ?? $mart['label'])),
                $dsKey,
                $dim,
                $metric,
                $agg,
                trim((string)($input['filter_field'] ?? '')),
                trim((string)($input['filter_op'] ?? '=')),
                trim((string)($input['filter_val'] ?? '')),
                $chart,
                $span,
                $maxSort + 10,
                in_array($input['color_palette'] ?? '', ['indigo', 'emerald', 'amber', 'violet', 'cyan'], true) ? $input['color_palette'] : 'indigo',
                $via,
                Jalali::today(),
            ]
        );

        return ['ok' => true, 'id' => $id, 'widget_code' => $code];
    }

    public static function saveDashboardWidgetLayout(array $orderedIds, array $widgetUpdates = []): array
    {
        $pos = 10;
        foreach ($orderedIds as $wid) {
            $id = (int)$wid;
            if ($id > 0) {
                Database::execute('UPDATE bi_dashboard_widgets SET sort_order = ?, updated_shamsi = ? WHERE id = ?', [$pos, Jalali::today(), $id]);
                $pos += 10;
            }
        }
        foreach ($widgetUpdates as $wid => $patch) {
            $id = (int)$wid;
            if ($id <= 0 || !is_array($patch)) {
                continue;
            }
            if (!empty($patch['col_span']) && in_array((int)$patch['col_span'], [3, 4, 6, 8, 12], true)) {
                Database::execute('UPDATE bi_dashboard_widgets SET col_span = ? WHERE id = ?', [(int)$patch['col_span'], $id]);
            }
            if (!empty($patch['chart_type']) && isset(self::CHART_TYPES[$patch['chart_type']])) {
                Database::execute('UPDATE bi_dashboard_widgets SET chart_type = ? WHERE id = ?', [(string)$patch['chart_type'], $id]);
            }
        }
        return ['ok' => true, 'updated_count' => count($orderedIds)];
    }

    public static function deleteWidget(int $widgetId): array
    {
        Database::execute('DELETE FROM bi_dashboard_widgets WHERE id = ?', [$widgetId]);
        return ['ok' => true];
    }

    public static function saveCustomReport(array $input, string $actorName): array
    {
        $queryRes = self::executeSemanticQuery($input);
        $code = 'RPT-' . strtoupper(substr(md5(uniqid('', true)), 0, 7));
        $title = trim((string)($input['title'] ?? '')) ?: ('گزارش ' . $queryRes['metric_label'] . ' بر اساس ' . $queryRes['dimension_label']);
        $via = in_array($input['created_via'] ?? '', ['click', 'drag_drop', 'text', 'voice'], true) ? (string)$input['created_via'] : 'click';

        $narrative = trim((string)($input['ai_narrative'] ?? ''));
        if ($narrative === '') {
            $ai = AvalAiService::generate(
                "گزارش مدیریتی BI با عنوان «{$title}» نشان می‌دهد بیشترین سهم مربوط به «"
                . ($queryRes['summary']['top_item'] ?? '') . "» است. در ۲ جمله راهکار عملیاتی بنویس.",
                'BI Custom Report'
            );
            $narrative = trim((string)($ai['content'] ?? ''));
        }

        $id = Database::insert(
            'INSERT INTO bi_custom_reports
             (report_code, title, category, dataset_key, dimension_field, metric_field, secondary_metric, agg_func, filter_field, filter_op, filter_val, sort_dir, row_limit, chart_type, natural_query_text, ai_narrative, created_via, created_by_name, created_shamsi)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [
                $code,
                $title,
                trim((string)($input['category'] ?? 'گزارش سفارشی سازمانی')),
                $queryRes['dataset_key'],
                $queryRes['dimension_field'],
                $queryRes['metric_field'],
                trim((string)($input['secondary_metric'] ?? $queryRes['metric_field'])),
                $queryRes['agg_func'],
                trim((string)($input['filter_field'] ?? '')),
                trim((string)($input['filter_op'] ?? '=')),
                trim((string)($input['filter_val'] ?? '')),
                strtoupper((string)($input['sort_dir'] ?? 'DESC')) === 'ASC' ? 'ASC' : 'DESC',
                max(3, min(100, (int)($input['row_limit'] ?? 25))),
                $queryRes['chart_type'],
                trim((string)($input['natural_query_text'] ?? $title)),
                $narrative,
                $via,
                $actorName,
                Jalali::today(),
            ]
        );

        // سازگاری کامل با جدول گزارش‌های ذخیره‌شده قبلی
        Database::insert(
            'INSERT INTO saved_reports (title, dataset_key, filter_expr, cron_schedule, ai_insight, created_by)
             VALUES (?, ?, ?, ?, ?, ?)',
            [
                $title,
                $queryRes['dataset_key'],
                $queryRes['dimension_field'] . ':' . $queryRes['agg_func'] . '(' . $queryRes['metric_field'] . ')',
                trim((string)($input['cron_schedule'] ?? '0 8 * * 6')),
                $narrative,
                Auth::id() ?: 1,
            ]
        );

        return ['ok' => true, 'id' => $id, 'report_code' => $code, 'query' => $queryRes, 'ai_narrative' => $narrative];
    }

    /**
     * محاسبه زنده شاخص‌های واقعی دیتابیس برای سنجش لحظه‌ای تحقق اهداف (OKR / KPI Targets)
     */
    public static function computeLiveKpiValues(): array
    {
        $avgRating5 = (float)Database::scalar('SELECT COALESCE(AVG(rating), 4.6) FROM courses');
        return [
            'invoices_total_rial'    => (float)Database::scalar('SELECT COALESCE(SUM(total_rial), 0) FROM invoices'),
            'crm_pipeline_rial'      => (float)Database::scalar('SELECT COALESCE(SUM(estimated_value_rial), 0) FROM crm_deals'),
            'courses_avg_rating_pct' => round($avgRating5 * 19.2, 1),
            'oa_letters_count'       => (float)Database::scalar('SELECT COUNT(*) FROM oa_letters'),
            'career_applicants_sum'  => (float)Database::scalar('SELECT COALESCE(SUM(applicants_count), 0) FROM career_job_ads'),
            'enrollments_avg_score'  => round((float)Database::scalar('SELECT COALESCE(AVG(final_score), 84) FROM enrollments'), 1),
            'certificates_count'     => (float)Database::scalar('SELECT COUNT(*) FROM certificates'),
        ];
    }

    public static function getEnrichedGoals(): array
    {
        $liveMap = self::computeLiveKpiValues();
        $rows = Database::fetchAll('SELECT * FROM bi_goals_okrs ORDER BY id DESC');
        $out = [];
        foreach ($rows as $g) {
            $src = (string)$g['live_metric_source'];
            $liveVal = (float)($liveMap[$src] ?? 0);
            $actual = round($liveVal + (float)$g['manual_boost_value'], 1);
            $target = max(1.0, (float)$g['target_value']);
            $pct = round(min(135.0, ($actual / $target) * 100.0), 1);
            $alertAt = (int)$g['alert_threshold_pct'];

            if ($pct >= 90.0) {
                $rag = 'success';
                $statusLabel = 'محقق / جلوتر از برنامه';
            } elseif ($pct >= $alertAt) {
                $rag = 'gold';
                $statusLabel = 'در مسیر هدف — نیازمند شتاب';
            } else {
                $rag = 'danger';
                $statusLabel = 'انحراف از هدف — نیازمند اقدام فوری';
            }

            $g['live_db_component'] = $liveVal;
            $g['current_actual'] = $actual;
            $g['achievement_pct'] = $pct;
            $g['gap_to_target'] = round(max(0.0, $target - $actual), 1);
            $g['rag_badge'] = $rag;
            $g['status_label'] = $statusLabel;
            $g['source_label'] = self::LIVE_GOAL_SOURCES[$src]['label'] ?? $src;
            $out[] = $g;
        }
        return $out;
    }

    public static function createGoal(array $input): array
    {
        $src = isset(self::LIVE_GOAL_SOURCES[$input['live_metric_source'] ?? ''])
            ? (string)$input['live_metric_source']
            : 'invoices_total_rial';
        $code = 'OKR-' . random_int(1000, 9999);
        $via = in_array($input['created_via'] ?? '', ['click', 'drag_drop', 'text', 'voice'], true) ? (string)$input['created_via'] : 'click';

        $id = Database::insert(
            'INSERT INTO bi_goals_okrs
             (goal_code, title, department_owner, horizon_label, live_metric_source, baseline_value, manual_boost_value, target_value, unit_label, weight_pct, alert_threshold_pct, key_results_note, created_via, updated_shamsi)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [
                $code,
                trim((string)($input['title'] ?? '')) ?: 'هدف عملکردی جدید واحد آموزش',
                trim((string)($input['department_owner'] ?? '')) ?: 'معاونت آموزش',
                trim((string)($input['horizon_label'] ?? '')) ?: 'نیمسال جاری ۱۴۰۵',
                $src,
                (float)($input['baseline_value'] ?? 0),
                (float)($input['manual_boost_value'] ?? 0),
                max(1.0, (float)($input['target_value'] ?? 100)),
                trim((string)($input['unit_label'] ?? '')) ?: self::LIVE_GOAL_SOURCES[$src]['unit'],
                max(5, min(100, (int)($input['weight_pct'] ?? 20))),
                max(20, min(95, (int)($input['alert_threshold_pct'] ?? 70))),
                trim((string)($input['key_results_note'] ?? '')) ?: 'پایش مستمر شاخص در داشبورد مدیریتی',
                $via,
                Jalali::today(),
            ]
        );
        return ['ok' => true, 'id' => $id, 'goal_code' => $code];
    }

    public static function checkInGoalProgress(int $goalId, float $deltaAdd, string $note = ''): array
    {
        Database::execute(
            'UPDATE bi_goals_okrs
             SET manual_boost_value = manual_boost_value + ?,
                 key_results_note = CASE WHEN ? != "" THEN ? ELSE key_results_note END,
                 updated_shamsi = ?
             WHERE id = ?',
            [$deltaAdd, trim($note), trim($note), Jalali::today(), $goalId]
        );
        return ['ok' => true];
    }

    public static function saveWhatIfScenario(array $input, string $actorName): array
    {
        $baseRev = max(250000000.0, (float)Database::scalar('SELECT COALESCE(SUM(total_rial), 0) FROM invoices'));
        $tDelta = max(-40, min(80, (int)($input['tuition_delta_pct'] ?? 10)));
        $eGrowth = max(-30, min(150, (int)($input['enrollment_growth_pct'] ?? 25)));
        $b2bConv = max(0, min(100, (int)($input['b2b_conversion_pct'] ?? 25)));
        $cChange = max(-40, min(60, (int)($input['cost_change_pct'] ?? -5)));

        $projRev = (int)round($baseRev * (1 + ($tDelta / 100)) * (1 + ($eGrowth / 100)) * (1 + ($b2bConv / 250)));
        $baseCost = $baseRev * 0.58;
        $projCost = $baseCost * (1 + ($cChange / 100)) * (1 + ($eGrowth * 0.35 / 100));
        $projSurplus = (int)round($projRev - $projCost);

        $code = 'SCN-' . random_int(100, 999);
        $rec = sprintf(
            'با تغییر شهریه %s٪، رشد جذب %s٪ و تبدیل سازمانی %s٪، درآمد پیش‌بینی‌شده به %s ریال و مازاد خالص عملیاتی به %s ریال خواهد رسید.',
            (string)$tDelta,
            (string)$eGrowth,
            (string)$b2bConv,
            number_format($projRev),
            number_format($projSurplus)
        );

        $id = Database::insert(
            'INSERT INTO bi_whatif_scenarios
             (scenario_code, title, tuition_delta_pct, enrollment_growth_pct, b2b_conversion_pct, cost_change_pct, projected_revenue_rial, projected_surplus_rial, ai_recommendation, created_by_name, created_shamsi)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [
                $code,
                trim((string)($input['title'] ?? '')) ?: 'سناریوی شبیه‌سازی بودجه و شهریه',
                $tDelta,
                $eGrowth,
                $b2bConv,
                $cChange,
                $projRev,
                $projSurplus,
                $rec,
                $actorName,
                Jalali::today(),
            ]
        );

        return ['ok' => true, 'id' => $id, 'scenario_code' => $code, 'projected_revenue_rial' => $projRev, 'projected_surplus_rial' => $projSurplus];
    }

    public static function saveReportSchedule(array $input): array
    {
        $code = 'SCH-' . random_int(100, 999);
        $ds = isset(self::DATA_MARTS[$input['dataset_key'] ?? '']) ? (string)$input['dataset_key'] : 'invoices_mart';
        $id = Database::insert(
            'INSERT INTO bi_report_schedules
             (schedule_code, report_title, dataset_key, frequency_label, cron_expr, delivery_channel, recipients_list, export_format, is_active, last_run_shamsi)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?)',
            [
                $code,
                trim((string)($input['report_title'] ?? '')) ?: 'گزارش دوره‌ای خودکار مدیریت',
                $ds,
                trim((string)($input['frequency_label'] ?? '')) ?: 'هفتگی — شنبه‌ها ساعت ۰۸:۰۰',
                trim((string)($input['cron_expr'] ?? '')) ?: '0 8 * * 6',
                trim((string)($input['delivery_channel'] ?? '')) ?: 'کارتابل اتوماسیون + ایمیل',
                trim((string)($input['recipients_list'] ?? '')) ?: 'مدیرکل آموزش، مدیر مالی',
                trim((string)($input['export_format'] ?? '')) ?: 'PDF A4 + CSV',
                Jalali::today(),
            ]
        );
        return ['ok' => true, 'id' => $id, 'schedule_code' => $code];
    }

    /**
     * پایش هوشمند ناهنجاری‌ها و هشدارهای عملیاتی زنده روی داده‌های واقعی سامانه
     */
    public static function detectLiveAnomalies(): array
    {
        $unpaidInv = (int)Database::scalar('SELECT COUNT(*) FROM invoices WHERE status IN ("unpaid", "partial")');
        $unsignedLetters = (int)Database::scalar('SELECT COUNT(*) FROM oa_letters WHERE sign_status LIKE "%پیش‌نویس%"');
        $lowAttStudents = (int)Database::scalar('SELECT COUNT(*) FROM academic_attendance_gradebook WHERE attendance_pct < 80');
        $openTickets = (int)Database::scalar('SELECT COUNT(*) FROM erp_helpdesk_tickets WHERE ticket_status NOT LIKE "%بسته%"');

        return [
            [
                'severity' => $unpaidInv > 0 ? 'warning' : 'success',
                'domain'   => 'خزانه و صورت‌حساب‌ها',
                'title'    => $unpaidInv . ' صورت‌حساب آموزشی در وضعیت تسویه‌نشده / اقساطی',
                'action'   => 'ارسال یادآور تسویه خودکار از واحد مالی',
                'route'    => 'finance',
            ],
            [
                'severity' => $lowAttStudents > 0 ? 'danger' : 'success',
                'domain'   => 'کنترل کیفیت و حضور کلاسی',
                'title'    => $lowAttStudents . ' پرونده آموزشی زیر حدنصاب ۸۰٪ حضور الزامی',
                'action'   => 'برنامه‌ریزی جلسه جبرانی پیش از آزمون پایانی',
                'route'    => 'academic-erp-core',
            ],
            [
                'severity' => $unsignedLetters > 0 ? 'warning' : 'success',
                'domain'   => 'اتوماسیون اداری و دبیرخانه',
                'title'    => $unsignedLetters . ' پیش‌نویس نامه اداری منتظر امضای مقام مسئول',
                'action'   => 'ورود به کارتابل مکاتبات و درج امضای دیجیتال',
                'route'    => 'office-automation',
            ],
            [
                'severity' => $openTickets > 0 ? 'info' : 'success',
                'domain'   => 'میز خدمت و تیکتینگ SLA',
                'title'    => $openTickets . ' تیکت پشتیبانی باز در صف پاسخگویی کارشناسان',
                'action'   => 'بررسی مهلت قانونی SLA در میز خدمت',
                'route'    => 'helpdesk-sla',
            ],
        ];
    }

    /**
     * بسته کامل داده‌های میزکار جامع BI برای رندر فوری بدون کوچک‌ترین تأخیر
     */
    public static function getFullStudioWorkspace(int $activeDashboardId = 0, array $activeQuerySpec = []): array
    {
        $dashboards = Database::fetchAll('SELECT * FROM bi_dashboards ORDER BY id ASC');
        if (empty($dashboards)) {
            self::createDashboard(['title' => 'داشبورد جامع فرماندهی مؤسسه آموزشی آدان'], 'مدیرکل آموزش', true);
            $dashboards = Database::fetchAll('SELECT * FROM bi_dashboards ORDER BY id ASC');
        }

        $selectedBoard = $dashboards[0];
        foreach ($dashboards as $b) {
            if ((int)$b['id'] === $activeDashboardId) {
                $selectedBoard = $b;
                break;
            }
        }
        $boardId = (int)$selectedBoard['id'];

        $rawWidgets = Database::fetchAll(
            'SELECT * FROM bi_dashboard_widgets WHERE dashboard_id = ? ORDER BY sort_order ASC, id ASC',
            [$boardId]
        );
        $hydratedWidgets = [];
        foreach ($rawWidgets as $w) {
            $w['live_data'] = self::executeSemanticQuery($w);
            $hydratedWidgets[] = $w;
        }

        $liveBuilderResult = self::executeSemanticQuery($activeQuerySpec);
        $goals = self::getEnrichedGoals();
        $liveKpis = self::computeLiveKpiValues();

        $avgGoalPct = 0.0;
        if (!empty($goals)) {
            $avgGoalPct = round(array_sum(array_column($goals, 'achievement_pct')) / count($goals), 1);
        }

        return [
            'dashboards'         => $dashboards,
            'active_dashboard'   => $selectedBoard,
            'widgets'            => $hydratedWidgets,
            'builder_result'     => $liveBuilderResult,
            'custom_reports'     => Database::fetchAll('SELECT * FROM bi_custom_reports ORDER BY id DESC'),
            'legacy_reports'     => Database::fetchAll('SELECT * FROM saved_reports ORDER BY id DESC LIMIT 8'),
            'preset_catalog'     => self::PRESET_REPORT_CATALOG,
            'goals'              => $goals,
            'scenarios'          => Database::fetchAll('SELECT * FROM bi_whatif_scenarios ORDER BY id DESC'),
            'schedules'          => Database::fetchAll('SELECT * FROM bi_report_schedules ORDER BY id DESC'),
            'anomalies'          => self::detectLiveAnomalies(),
            'data_marts'         => self::DATA_MARTS,
            'chart_types'        => self::CHART_TYPES,
            'agg_funcs'          => self::AGG_FUNCS,
            'goal_sources'       => self::LIVE_GOAL_SOURCES,
            'executive_kpis'     => [
                'total_revenue_rial' => $liveKpis['invoices_total_rial'],
                'crm_pipeline_rial'  => $liveKpis['crm_pipeline_rial'],
                'avg_goal_pct'       => $avgGoalPct,
                'courses_satisfaction_pct' => $liveKpis['courses_avg_rating_pct'],
                'total_dashboards'   => count($dashboards),
                'total_reports'      => count(self::PRESET_REPORT_CATALOG) + (int)Database::scalar('SELECT COUNT(*) FROM bi_custom_reports'),
            ],
        ];
    }

    private static function normalizePersianDigits(string $str): string
    {
        return strtr($str, [
            '۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4',
            '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
            '٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4',
            '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9',
            ',' => '', '٬' => '',
        ]);
    }

    private static function extractSpokenMagnitude(string $norm, float $fallback): float
    {
        if (preg_match('/(\d+(?:\.\d+)?)\s*(میلیارد|میلیون|هزار)?/u', $norm, $m)) {
            $val = (float)$m[1];
            $mult = match ($m[2] ?? '') {
                'میلیارد' => 1000000000.0,
                'میلیون'  => 1000000.0,
                'هزار'    => 1000.0,
                default   => 1.0,
            };
            return max(1.0, $val * $mult);
        }
        return $fallback;
    }
}
