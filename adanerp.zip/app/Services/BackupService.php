<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\App;
use App\Core\Database;

final class BackupService
{
    /**
     * تولید پشتیبان کامل UTF-8mb4 پایگاه‌داده MariaDB فقط با PDO خالص PHP
     * بدون نیاز به exec() یا mysqldump — صددرصد سازگار با هاست‌های محدود اشتراکی cPanel و XAMPP
     */
    public static function generateSqlDump(): string
    {
        $pdo = Database::connection();
        $out = [];
        $out[] = '-- Adan Accounting Institute Education Platform — Pure PDO SQL Backup';
        $out[] = '-- Generated at: ' . date('Y-m-d H:i:s');
        $out[] = 'SET NAMES utf8mb4;';
        $out[] = 'SET FOREIGN_KEY_CHECKS = 0;';
        $out[] = '';

        $tablesRows = Database::fetchAll('SHOW TABLES');
        foreach ($tablesRows as $tRow) {
            $table = (string)reset($tRow);
            $createRow = Database::fetchOne("SHOW CREATE TABLE `{$table}`");
            $createSql = (string)($createRow['Create Table'] ?? '');
            if ($createSql === '') {
                continue;
            }

            $out[] = "-- Table structure for `{$table}`";
            $out[] = "DROP TABLE IF EXISTS `{$table}`;";
            $out[] = $createSql . ';';
            $out[] = '';

            $rows = Database::fetchAll("SELECT * FROM `{$table}`");
            if (!empty($rows)) {
                $cols = array_map(static fn(string $c): string => "`{$c}`", array_keys($rows[0]));
                $colList = implode(', ', $cols);

                foreach ($rows as $row) {
                    $vals = [];
                    foreach ($row as $v) {
                        if ($v === null) {
                            $vals[] = 'NULL';
                        } else {
                            $vals[] = $pdo->quote((string)$v);
                        }
                    }
                    $out[] = "INSERT INTO `{$table}` ({$colList}) VALUES (" . implode(', ', $vals) . ");";
                }
                $out[] = '';
            }
        }

        $out[] = 'SET FOREIGN_KEY_CHECKS = 1;';
        return implode("\n", $out);
    }

    public static function runHealthChecks(): array
    {
        $dbVersion = (string)Database::scalar('SELECT VERSION()');
        $tableCount = count(Database::fetchAll('SHOW TABLES'));
        $uploadWritable = is_writable(App::rootPath('storage/uploads'));

        return [
            [
                'check' => 'نسخه موتور PHP سرور',
                'value' => PHP_VERSION,
                'ok' => version_compare(PHP_VERSION, '8.1.0', '>='),
                'hint' => 'نیازمند PHP 8.1+ در XAMPP یا MultiPHP Manager در cPanel',
            ],
            [
                'check' => 'موتور پایگاه‌داده MariaDB / MySQL',
                'value' => $dbVersion . ' (' . $tableCount . ' جدول فعال)',
                'ok' => $tableCount >= 60,
                'hint' => 'کلیه جداول با کدگذاری utf8mb4_unicode_ci بارگذاری شده‌اند',
            ],
            [
                'check' => 'افزونه‌های کلیدی PHP (PDO, mbstring, cURL, Zip, OpenSSL)',
                'value' => implode(', ', array_filter(['pdo_mysql', 'mbstring', 'curl', 'zip', 'openssl'], 'extension_loaded')),
                'ok' => extension_loaded('pdo_mysql') && extension_loaded('mbstring') && extension_loaded('curl'),
                'hint' => 'برای ارتباط امن با AI API و بارگذاری بسته‌های ZIP/SCORM',
            ],
            [
                'check' => 'دسترسی نوشتن پوشه ذخیره‌سازی (storage/uploads)',
                'value' => $uploadWritable ? 'قابل نوشتن (0755)' : 'فقط خواندنی',
                'ok' => $uploadWritable,
                'hint' => 'محل نگهداری اسناد، تکالیف و بسته‌های SCORM',
            ],
            [
                'check' => 'محافظت امنیتی توکن CSRF و نشست‌ها',
                'value' => 'فعال در کلیه درخواست‌های تغییردهنده (POST)',
                'ok' => true,
                'hint' => 'همراه با قفل موقت ضد حملات Brute Force در ورود',
            ],
        ];
    }
}
