<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database;
use App\Core\Jalali;

/**
 * موتور جامع یادگیری خرد (Microlearning)، مرور فاصله‌دار علمی (SM-2 / Leitner)، چالش ۶۰ ثانیه‌ای و تبدیل متن به میکرودرس با AI
 */
final class MicrolearningEngineService
{
    /**
     * ۱. تکمیل کپسول ۳ دقیقه‌ای + تصحیح آنی سؤال تثبیت + اعطای XP و ثبت تله‌متری xAPI در کل سامانه
     */
    public static function completeCapsuleWithQuiz(int $userId, string $userName, int $capsuleId, string $selectedOpt): array
    {
        $cap = Database::fetchOne('SELECT * FROM micro_learning_capsules WHERE id = ?', [$capsuleId]);
        if (!$cap) {
            return ['ok' => false, 'message' => 'کپسول آموزشی یافت نشد.'];
        }

        $choice = strtoupper(trim($selectedOpt));
        if (!in_array($choice, ['A', 'B', 'C'], true)) {
            $choice = 'B';
        }
        $isCorrect = ($choice === strtoupper((string)$cap['correct_opt']));
        $xpEarned = $isCorrect ? (int)$cap['xp_reward'] : (int)max(10, round((int)$cap['xp_reward'] * 0.4));

        Database::insert(
            'INSERT INTO micro_capsule_progress (user_id, capsule_id, selected_opt, is_mastered, xp_earned, completed_shamsi)
             VALUES (?, ?, ?, ?, ?, ?)',
            [max(1, $userId), $capsuleId, $choice, $isCorrect ? 1 : 0, $xpEarned, Jalali::today()]
        );
        Database::execute('UPDATE micro_learning_capsules SET completions_count = completions_count + 1 WHERE id = ?', [$capsuleId]);

        LearnerBehaviorGamificationService::recordTelemetryAndAwardXp(
            max(1, $userId),
            $userName ?: 'فراگیر مؤسسه آموزشی آدان',
            'microlearning',
            'تکمیل کپسول میکرولرنینگ ' . $cap['capsule_code'],
            (int)$cap['duration_seconds'],
            $isCorrect ? 100 : 60,
            $xpEarned
        );

        return [
            'ok' => true,
            'capsule_code' => $cap['capsule_code'],
            'is_correct' => $isCorrect,
            'correct_opt' => $cap['correct_opt'],
            'xp_earned' => $xpEarned,
        ];
    }

    /**
     * ۲. الگوریتم علمی مرور فاصله‌دار (SM-2 / 5-Box Leitner) جهت انتقال دانش به حافظه بلندمدت
     * quality: 'again' (فراموشی -> بازگشت به خانه ۱) | 'good' (یادآوری با مکث) | 'easy' (تسلط آنی -> ضریب SM-2)
     */
    public static function reviewFlashcardSm2(int $userId, string $userName, int $cardId, string $quality): array
    {
        $card = Database::fetchOneSafe('SELECT * FROM micro_spaced_flashcards WHERE id = ?', [$cardId]);
        if (!$card) {
            return ['ok' => false];
        }
        // ★ v26.8 — کارت‌های مرور شخصی فقط توسط مالکش قابل مرورند (نمای شخصی، نه دفتر کل)
        $ownerId = (int)($card['owner_user_id'] ?? 0);
        if ($ownerId > 0 && $ownerId !== max(1, $userId)) {
            try {
                \App\Core\Auth::audit('MICROLEARNING', 'PERSONAL_DECK_ACCESS_DENIED', 'micro_spaced_flashcards', $cardId, [
                    'owner' => $ownerId, 'actor' => $userId,
                ]);
            } catch (\Throwable) {
            }
            return ['ok' => false, 'blocked' => true, 'message' => 'این کارت شخصی است و فقط توسط سازنده‌اش مرور می‌شود.'];
        }

        $curBox = (int)$card['leitner_box'];
        $ef = (float)$card['ease_factor'];
        $curInterval = max(1, (int)$card['interval_days']);

        if ($quality === 'again') {
            $newBox = 1;
            $newEf = max(1.30, round($ef - 0.20, 2));
            $newInterval = 1;
            $label = 'موعد مرور مجدد: فردا 🔄';
            $xp = 10;
        } elseif ($quality === 'good') {
            $newBox = min(5, $curBox + 1);
            $newEf = round($ef, 2);
            $newInterval = max(2, (int)round($curInterval * 1.8));
            $label = 'مرور بعدی: ' . Jalali::digits((string)$newInterval) . ' روز دیگر';
            $xp = 18;
        } else {
            $newBox = min(5, $curBox + 1);
            $newEf = min(3.00, round($ef + 0.15, 2));
            $newInterval = max(4, (int)round($curInterval * $newEf));
            $label = 'تثبیت بلندمدت: ' . Jalali::digits((string)$newInterval) . ' روز دیگر ✅';
            $xp = 25;
        }

        Database::execute(
            'UPDATE micro_spaced_flashcards
             SET leitner_box = ?, ease_factor = ?, interval_days = ?, next_review_label = ?, reviews_count = reviews_count + 1
             WHERE id = ?',
            [$newBox, $newEf, $newInterval, $label, $cardId]
        );

        LearnerBehaviorGamificationService::recordTelemetryAndAwardXp(max(1, $userId), $userName, 'microlearning', 'مرور فاصله‌دار لایتنر ' . $card['card_code'], 90, 95, $xp);
        return [
            'ok' => true,
            'card_code' => $card['card_code'],
            'new_box' => $newBox,
            'new_interval_days' => $newInterval,
            'ease_factor' => $newEf,
            'xp_earned' => $xp,
        ];
    }

    /**
     * ۳. استودیو هوش مصنوعی تبدیل بخشنامه / جزوه طولانی به «کپسول ۳ دقیقه‌ای + فلش‌کارت لایتنر»
     */
    public static function generateMicroCapsuleFromText(string $topicTitle, string $domain, string $rawSourceText, int $durationSec = 180): array
    {
        $title = trim($topicTitle) ?: 'خلاصه اجرایی بخشنامه جدید ارزی و گمرکی';
        $cleanDomain = trim($domain) ?: 'تجارت بین‌الملل';
        $snippet = mb_substr(trim($rawSourceText) ?: 'ضوابط جدید رفع تعهد ارزی صادرکنندگان نمونه و تهاتر واردات مواد اولیه تولیدی', 0, 220);

        $code = 'MIC-AI-' . random_int(100, 999);
        $slide1 = '⚡ چالش کلیدی مدیران در «' . $title . '»: عدم اشراف سریع بر نکات اجرایی این مصوبه می‌تواند منجر به توقف پرونده یا هزینه اضافی گردد.';
        $slide2 = '✅ عصاره عملیاتی (تولیدشده توسط AI): ' . $snippet;
        $slide3 = '🛠️ اقدام فوری ۳ دقیقه‌ای روی میز کار: تطبیق پرونده‌های جاری واحد با شروط جدید و ثبت مستندات در کارپوشه رسمی پیش از سررسید.';

        $capId = (int)Database::insert(
            'INSERT INTO micro_learning_capsules
             (capsule_code, title, topic_domain, duration_seconds, difficulty_tag, slide_1_hook, slide_2_rule, slide_3_example,
              quiz_question, quiz_opt_a, quiz_opt_b, quiz_opt_c, correct_opt, xp_reward, completions_count, created_shamsi)
             VALUES (?, ?, ?, ?, "تولیدشده با AI", ?, ?, ?, ?, ?, ?, ?, "B", 40, 1, ?)',
            [
                $code,
                $title,
                $cleanDomain,
                max(90, min(300, $durationSec)),
                $slide1,
                $slide2,
                $slide3,
                'مهم‌ترین گام اجرایی فوری در موضوع «' . $title . '» چیست؟',
                'تعویق بررسی تا پایان سال مالی',
                'انطباق فوری پرونده‌های جاری با ضابطه کلیدی و مستندسازی پیش از مهلت مقرر',
                'حذف کامل مستندات قبلی',
                Jalali::today(),
            ]
        );

        $fcCode = 'FC-AI-' . random_int(100, 999);
        Database::insert(
            'INSERT INTO micro_spaced_flashcards
             (card_code, deck_category, front_prompt, back_answer, leitner_box, ease_factor, interval_days, next_review_label, reviews_count)
             VALUES (?, ?, ?, ?, 1, 2.50, 1, "موعد مرور: امروز 🔥", 0)',
            [$fcCode, $cleanDomain, 'نکته طلایی ۳ دقیقه‌ای در مورد «' . $title . '» چیست؟', $snippet]
        );

        return ['ok' => true, 'capsule_id' => $capId, 'capsule_code' => $code, 'flashcard_code' => $fcCode];
    }

    /**
     * ۴. پاسخ به چالش روزانه ۶۰ ثانیه‌ای مدیران
     */
    public static function submitDailyMicroChallenge(int $userId, string $userName, int $challengeId, int $pickedOption): array
    {
        $ch = Database::fetchOne('SELECT * FROM micro_daily_challenges WHERE id = ?', [$challengeId]);
        if (!$ch) {
            return ['ok' => false];
        }
        $won = ($pickedOption === (int)$ch['correct_choice']);
        $xp = $won ? (int)$ch['bonus_xp'] : 15;
        Database::execute('UPDATE micro_daily_challenges SET participants_today = participants_today + 1 WHERE id = ?', [$challengeId]);
        LearnerBehaviorGamificationService::recordTelemetryAndAwardXp(max(1, $userId), $userName, 'microlearning', 'چالش ۶۰ ثانیه‌ای ' . $ch['challenge_code'], 60, $won ? 100 : 55, $xp);

        return [
            'ok' => true,
            'won' => $won,
            'explanation' => $ch['explanation_key'],
            'xp_earned' => $xp,
        ];
    }

    /**
     * ۵. افزودن برگه راهنمای سریع رومیزی / میکروپادکست (Job-Aid Cheat Sheet)
     */
    public static function saveJobAidCheatSheet(array $input): array
    {
        $code = 'AID-CHB-' . random_int(100, 999);
        Database::insert(
            'INSERT INTO micro_job_aids (aid_code, aid_title, target_desk, format_type, key_steps_summary, audio_script_summary, downloads_count, created_shamsi)
             VALUES (?, ?, ?, "تقلب‌نامه ۱ صفحه‌ای + میکروپادکست", ?, ?, 1, ?)',
            [
                $code,
                trim((string)($input['aid_title'] ?? 'راهنمای سریع بازرگانی')),
                trim((string)($input['target_desk'] ?? 'میز کارشناس صادرات')),
                trim((string)($input['key_steps_summary'] ?? 'گام‌های کلیدی کنترلی')),
                trim((string)($input['audio_script_summary'] ?? 'متن صوتی مرور سریع ۳ دقیقه‌ای')),
                Jalali::today(),
            ]
        );
        return ['ok' => true, 'aid_code' => $code];
    }

    public static function getMicrolearningHubBundle(int $userId = 7): array
    {
        $capsules = Database::fetchAll('SELECT * FROM micro_learning_capsules ORDER BY id DESC');
        $masteredIds = array_column(
            Database::fetchAll('SELECT DISTINCT capsule_id FROM micro_capsule_progress WHERE user_id = ? AND is_mastered = 1', [max(1, $userId)]),
            'capsule_id'
        );

        return [
            'capsules'        => $capsules,
            'mastered_ids'    => array_map('intval', $masteredIds),
            // ★ v26.8 — دسته لایتنر = کارت‌های عمومی کاتالوگ + کارت‌های شخصی خود کاربر (نه دیگران)
            'flashcards'      => Database::fetchAllSafe(
                'SELECT * FROM micro_spaced_flashcards
                 WHERE owner_user_id IS NULL OR owner_user_id = ?
                 ORDER BY (owner_user_id IS NOT NULL) DESC, leitner_box ASC, id DESC',
                [max(1, $userId)],
                []
            ),
            'challenges'      => Database::fetchAll('SELECT * FROM micro_daily_challenges ORDER BY id DESC'),
            'job_aids'        => Database::fetchAll('SELECT * FROM micro_job_aids ORDER BY id DESC'),
            'gap_links'       => Database::fetchAll('SELECT * FROM micro_skill_gap_links ORDER BY id DESC'),
            'due_today_cnt'   => (int)Database::scalarSafe(
                'SELECT COUNT(*) FROM micro_spaced_flashcards WHERE leitner_box <= 2 AND (owner_user_id IS NULL OR owner_user_id = ?)',
                [max(1, $userId)]
            ),
            'total_completions'=> (int)Database::scalar('SELECT COALESCE(SUM(completions_count), 0) FROM micro_learning_capsules'),
        ];
    }
}
