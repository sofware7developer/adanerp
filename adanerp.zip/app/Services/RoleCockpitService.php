<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\App;
use App\Core\Database;
use App\Core\IranValidator;
use App\Core\Jalali;

/**
 * موتور پیشخوان‌های اختصاصی نقش‌محور ۸گانه و گردش‌کارهای تکمیلی هر نقش در مؤسسه آموزشی آدان (v17.0)
 */
final class RoleCockpitService
{
    /**
     * ۱. مدیرکل / دبیرکل (super_admin): امضای دیجیتال ۱-کلیکی کارتابل مدیریتی با هش SHA-256
     */
    public static function signExecutiveItem(int $itemId, string $signerName = 'دکتر کیارش رادمهر'): array
    {
        $row = Database::fetchOne('SELECT * FROM executive_signoff_queue WHERE id = ?', [$itemId]);
        if (!$row) {
            return ['ok' => false, 'message' => 'ردیف کارتابل یافت نشد.'];
        }
        $sig = hash_hmac('sha256', $row['doc_ref_no'] . '|' . $row['subject_title'] . '|' . microtime(true), (string)App::config('app_secret', 'chamber1405'));
        Database::execute(
            'UPDATE executive_signoff_queue SET sign_status = "signed", signature_sha256 = ?, signed_by_name = ?, signed_shamsi = ? WHERE id = ?',
            [$sig, $signerName, Jalali::today(), $itemId]
        );
        return ['ok' => true, 'doc_ref_no' => $row['doc_ref_no'], 'signature_sha256' => $sig];
    }

    /**
     * ۲. کارشناس مسئول آموزش (training_expert): ویزارد ثبت‌نام گروهی کارمندان سازمان با کنترل Mod-11 + تکمیل چک‌لیست اجرا
     */
    public static function runBulkEnrollmentAndChecklist(string $runCode, string $csvLines): array
    {
        $lines = array_filter(array_map('trim', preg_split('/\R+/', trim($csvLines)) ?: []));
        $validCount = 0;
        $rejectedCount = 0;
        foreach ($lines as $ln) {
            $parts = array_map('trim', explode(',', $ln));
            $nid = preg_replace('/\D+/', '', $parts[1] ?? '') ?? '';
            if (IranValidator::isValidNationalCode($nid)) {
                $validCount++;
            } else {
                $rejectedCount++;
            }
        }

        Database::execute(
            'UPDATE class_runbook_checklists
             SET skyroom_link_ready = 1, slides_uploaded = 1, sms_24h_sent = 1, hall_catering_ok = 1,
                 bulk_enrolled_count = bulk_enrolled_count + ?, readiness_pct = 100, updated_shamsi = ?
             WHERE run_code = ?',
            [$validCount, Jalali::today(), $runCode]
        );

        return [
            'ok' => true,
            'run_code' => $runCode,
            'valid_enrolled' => $validCount,
            'rejected_invalid_melli' => $rejectedCount,
            'readiness_pct' => 100,
        ];
    }

    /**
     * ۳. مدیر مالی و ذی‌حساب (finance_manager): محاسبه استرداد طبق آیین‌نامه داخلی مؤسسه + صدور سند حسابداری دوبل تراز (۰ ریال اختلاف)
     */
    public static function processStatutoryTuitionRefund(string $applicant, string $courseTitle, int $paidRial, int $hoursBeforeStart): array
    {
        $deductionPct = match (true) {
            $hoursBeforeStart >= 72 => 0,
            $hoursBeforeStart >= 24 => 15,
            default                 => 30,
        };
        $paid = max(1000000, $paidRial);
        $netRefund = (int)round($paid * ((100 - $deductionPct) / 100));
        $rfdCode = 'RFD-1405-' . random_int(300, 999);
        $vchBase = 'VCH-RFD-' . random_int(1000, 9999);

        Database::insert(
            'INSERT INTO tuition_refund_requests (refund_code, applicant_name, course_title, paid_tuition_rial, hours_before_start, deduction_pct, net_refund_rial, reversal_voucher_no, processed_shamsi)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [$rfdCode, trim($applicant), trim($courseTitle), $paid, $hoursBeforeStart, $deductionPct, $netRefund, $vchBase, Jalali::today()]
        );

        // ثبت زوج آرتیکل بدهکار و بستانکار کاملاً تراز در دفترکل ۴ سطحی
        Database::insert(
            'INSERT INTO accounting_vouchers (voucher_no, voucher_shamsi, group_code, kol_account, moein_account, tafsili_entity, debit_rial, credit_rial, voucher_desc)
             VALUES (?, ?, "۴۰-برگشت درآمد", "۴۰۲-برگشت از شهریه مصوب", "۴۰۲۰۱-استرداد آیین‌نامه‌ای دوره", ?, ?, 0, ?)',
            [$vchBase . '-D', Jalali::today(), trim($applicant), $netRefund, "سند بدهکار استرداد شهریه {$rfdCode} (کسر آیین‌نامه‌ای {$deductionPct}٪)"]
        );
        Database::insert(
            'INSERT INTO accounting_vouchers (voucher_no, voucher_shamsi, group_code, kol_account, moein_account, tafsili_entity, debit_rial, credit_rial, voucher_desc)
             VALUES (?, ?, "۱۰-دارایی جاری", "۱۰۱-بانک و خزانه اتاق", "۱۰۱۰۲-حساب پشتیبان استرداد شبا", ?, 0, ?, ?)',
            [$vchBase . '-C', Jalali::today(), trim($applicant), $netRefund, "سند بستانکار پرداخت شبا بابت استرداد شهریه {$rfdCode}"]
        );

        return [
            'ok' => true,
            'refund_code' => $rfdCode,
            'deduction_pct' => $deductionPct,
            'net_refund_rial' => $netRefund,
            'voucher_base' => $vchBase,
        ];
    }

    /**
     * ۴. مدیر CRM و بازاریابی (crm_manager): ثبت پیگیری ۳۶۰ درجه بنگاه و صدور پروپوزال اختصاصی مدیرعامل
     */
    public static function createB2bProposalTouchpoint(string $company, string $channel, int $packageRial, string $summary): array
    {
        $code = 'PRP-1405-' . random_int(600, 999);
        $winProb = $packageRial >= 500000000 ? 82 : 88;
        Database::insert(
            'INSERT INTO b2b_account_touchpoints (proposal_code, company_name, channel_source, contact_summary, proposed_package_rial, win_probability_pct, next_followup_shamsi)
             VALUES (?, ?, ?, ?, ?, ?, ?)',
            [$code, trim($company), trim($channel), trim($summary), max(50000000, $packageRial), $winProb, Jalali::today()]
        );
        return ['ok' => true, 'proposal_code' => $code, 'win_probability_pct' => $winProb];
    }

    /**
     * ۵. مدرس و مشاور ارشد (instructor): ثبت زمان‌های آزاد تدریس + صدور توصیه‌نامه مهارتی رسمی برای فراگیر برتر
     */
    public static function saveInstructorEndorsementAndSlots(string $instructorName, string $slots, string $learnerName, string $skillBadge, string $note): array
    {
        $code = 'END-1405-' . random_int(400, 999);
        Database::insert(
            'INSERT INTO instructor_availability_endorsements (record_code, instructor_name, free_weekly_slots, endorsed_learner_name, endorsed_skill_badge, recommendation_note, created_shamsi)
             VALUES (?, ?, ?, ?, ?, ?, ?)',
            [$code, trim($instructorName), trim($slots), trim($learnerName), trim($skillBadge), trim($note), Jalali::today()]
        );
        return ['ok' => true, 'record_code' => $code, 'endorsed_learner' => trim($learnerName)];
    }

    /**
     * ۶. نماینده آموزش کارخانه عضو (org_rep): تأیید درخواست دوره کارمند و کسر خودکار از سهمیه قرارداد سازمانی
     */
    public static function approveEmployeeQuotaRequest(int $requestId): array
    {
        $req = Database::fetchOne('SELECT * FROM org_employee_training_requests WHERE id = ?', [$requestId]);
        if (!$req) {
            return ['ok' => false];
        }
        if ((int)$req['contract_quota_deducted'] === 0) {
            Database::execute(
                'UPDATE org_employee_training_requests SET hr_approval_status = "تأیید نهایی نماینده سازمان — کسر از سهمیه قرارداد", contract_quota_deducted = 1 WHERE id = ?',
                [$requestId]
            );
            Database::execute('UPDATE corporate_contracts SET seats_used = LEAST(seat_quota, seats_used + 1) WHERE id = 1');
        }
        return ['ok' => true, 'req_code' => $req['req_code'], 'employee' => $req['employee_fullname']];
    }

    /**
     * ۷. فراگیر (learner): تکمیل گام برنامه توسعه فردی ۹۰ روزه (IDP) + واریز خودکار XP و سکه به کیف پول گیمیفیکیشن
     */
    public static function completeLearnerIdpStep(int $stepId, int $userId = 7): array
    {
        $step = Database::fetchOne('SELECT * FROM learner_personal_idp_steps WHERE id = ?', [$stepId]);
        if (!$step) {
            return ['ok' => false];
        }
        $xp = (int)$step['xp_bonus'];
        if ((int)$step['is_done'] === 0) {
            Database::execute('UPDATE learner_personal_idp_steps SET is_done = 1 WHERE id = ?', [$stepId]);
            LearnerBehaviorGamificationService::recordTelemetryAndAwardXp(
                max(1, $userId),
                (string)$step['learner_name'],
                'role-workstations',
                'تکمیل گام برنامه توسعه فردی ۹۰ روزه: ' . $step['milestone_title'],
                600,
                95,
                $xp
            );
        }
        return ['ok' => true, 'xp_awarded' => $xp, 'milestone' => $step['milestone_title']];
    }

    /**
     * نمایش گروهی وضعیت محلی گواهی‌نامه‌ها؛ این نتیجه امضای بیرونی یا تطبیق زنجیره نیست.
     */
    public static function batchVerifyCertificates(string $rawSerials): array
    {
        $codes = array_values(array_unique(array_filter(array_map('trim', preg_split('/[\s,;]+/', trim($rawSerials)) ?: []))));
        $results = [];
        foreach ($codes as $serial) {
            $cert = Database::fetchOne(
                'SELECT cert.*, u.full_name, c.title AS course_title
                 FROM certificates cert
                 JOIN users u ON u.id = cert.user_id
                 JOIN courses c ON c.id = cert.course_id
                 WHERE cert.serial_code = ?',
                [$serial]
            );
            $block = Database::fetchOne(
                'SELECT block_height, block_sha256_hash FROM verifiable_credential_blocks WHERE cert_or_badge_code = ? LIMIT 1',
                [$serial]
            );
            if (!$cert) {
                $results[] = ['serial' => $serial, 'state' => 'not_found', 'holder' => '-', 'course' => '-', 'hash' => null];
            } else {
                $results[] = [
                    'serial' => $serial,
                    'state' => $cert['status'],
                    'holder' => $cert['full_name'],
                    'course' => $cert['course_title'],
                    'hours' => (int)$cert['hours_completed'],
                    'hash' => $block['block_sha256_hash'] ?? null,
                ];
            }
        }
        return $results;
    }

    /**
     * گردآوری یکپارچه داده‌های میزکار اختصاصی هر ۸ نقش برای نمایش در داشبورد نقش‌محور و بخش تخصصی
     */
    public static function getAllRoleWorkstationData(): array
    {
        return [
            'exec_queue' => Database::fetchAll('SELECT * FROM executive_signoff_queue ORDER BY id ASC'),
            'runbooks' => Database::fetchAll('SELECT * FROM class_runbook_checklists ORDER BY id ASC'),
            'refunds' => Database::fetchAll('SELECT * FROM tuition_refund_requests ORDER BY id DESC LIMIT 6'),
            'touchpoints' => Database::fetchAll('SELECT * FROM b2b_account_touchpoints ORDER BY id DESC LIMIT 6'),
            'endorsements' => Database::fetchAll('SELECT * FROM instructor_availability_endorsements ORDER BY id DESC LIMIT 6'),
            'org_requests' => Database::fetchAll('SELECT * FROM org_employee_training_requests ORDER BY id ASC'),
            'idp_steps' => Database::fetchAll('SELECT * FROM learner_personal_idp_steps ORDER BY step_order ASC'),
            'due_cheques' => Database::fetchAll('SELECT * FROM sayad_cheques ORDER BY id DESC LIMIT 4'),
        ];
    }
}
