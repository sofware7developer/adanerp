<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Auth;
use App\Core\App;
use App\Core\Database;
use App\Core\Jalali;

/**
 * سرویس جامع اتوماسیون اداری، دبیرخانه مکاتبات رسمی، گردش ارجاعات (پاراف)، درخواست‌های پرسنلی و صورت‌جلسات
 */
final class OfficeAutomationService
{
    private const STAFF_ROLES = ['super_admin', 'training_expert', 'finance_manager', 'crm_manager', 'instructor'];
    private const MANAGER_ROLES = ['super_admin', 'training_expert', 'finance_manager', 'crm_manager'];

    public const LETTER_TEMPLATES = [
        'customs_intro' => [
            'label'     => 'معرفی‌نامه آموزشی به سازمان / شرکت همکار',
            'type'      => 'صادره',
            'priority'  => 'فوری',
            'recipient' => 'مدیریت محترم منابع انسانی شرکت همکار',
            'subject'   => 'معرفی‌نامه پایان دوره حسابداری',
            'body'      => "با سلام و احترام؛\nبدین‌وسیله گواهی می‌شود جناب آقای / سرکار خانم .......................... دوره تخصصی حسابداری را با موفقیت گذرانده‌اند. این معرفی‌نامه بنا به درخواست ایشان و جهت ارائه به آن سازمان صادر می‌شود.",
        ],
        'mission_order' => [
            'label'     => 'ابلاغیه حکم مأموریت اداری و آموزشی',
            'type'      => 'داخلی',
            'priority'  => 'عادی',
            'recipient' => 'همکار گرامی — واحد آموزش و پژوهش',
            'subject'   => 'ابلاغ مأموریت اداری نظارت بر برگزاری کارگاه آموزشی',
            'body'      => "با سلام و احترام؛\nبه موجب این ابلاغ، به جنابعالی مأموریت داده می‌شود در تاریخ مقرر جهت هماهنگی اجرایی، نظارت بر آزمون و تحویل صورت‌جلسات آموزشی به واحد مربوطه عزیمت نموده و گزارش عملکرد را پس از خاتمه مأموریت ارائه فرمایید.",
        ],
        'committee_invite' => [
            'label'     => 'دعوت‌نامه جلسه برنامه‌ریزی آموزشی',
            'type'      => 'صادره',
            'priority'  => 'فوری',
            'recipient' => 'اعضای محترم شورای برنامه‌ریزی آموزشی آدان',
            'subject'   => 'دعوت به جلسه برنامه‌ریزی دوره‌های حسابداری',
            'body'      => "با سلام و احترام؛\nاز جنابعالی دعوت می‌شود در جلسه برنامه‌ریزی دوره‌های حسابداری، مالیات و امور مالی حضور به هم رسانید.\nدستور جلسه: بررسی تقویم آموزشی، سرفصل‌ها و ظرفیت برگزاری دوره‌ها.",
        ],
        'payment_memo' => [
            'label'     => 'نامه داخلی دستور پرداخت و تسویه حساب مالی',
            'type'      => 'داخلی',
            'priority'  => 'فوری',
            'recipient' => 'مدیریت محترم امور مالی و ذی‌حسابی',
            'subject'   => 'درخواست بررسی اسناد مثبته و صدور حواله تسویه حساب',
            'body'      => "احتراماً به پیوست مدارک، صورت‌وضعیت تأییدشده و فرم تحویل خدمات ایفاد می‌گردد. خواهشمند است دستور فرمایید پس از کنترل ضوابط مالی و کسر کسور قانونی، نسبت به تسویه حساب اقدام مقتضی به عمل آید.",
        ],
    ];

    public static function getStaffRecipients(): array
    {
        $rolePlaceholders = implode(',', array_fill(0, count(self::STAFF_ROLES), '?'));
        $recipients = Database::fetchAll(
            "SELECT id, full_name, role, job_title
             FROM users
             WHERE status = 'active' AND role IN ({$rolePlaceholders})
             ORDER BY full_name",
            self::STAFF_ROLES
        );
        foreach ($recipients as &$recipient) {
            $recipient['role_label'] = Auth::roleLabel((string)$recipient['role']);
        }
        unset($recipient);
        return $recipients;
    }

    public static function getWorkspaceBundle(
        string $typeFilter,
        int $userId,
        bool $canViewAll,
        bool $canManageRequests,
        string $box = 'inbox'
    ): array {
        $where = [];
        $params = [];
        if ($box === 'all' && $canViewAll) {
            $where[] = '1 = 1';
        } elseif ($box === 'sent') {
            $where[] = 'l.sender_user_id = ?';
            $params[] = $userId;
        } elseif ($box === 'archived') {
            $where[] = 'l.recipient_user_id = ? AND l.archived_at IS NOT NULL';
            $params[] = $userId;
        } elseif ($canViewAll) {
            $where[] = '(l.recipient_user_id = ? OR l.recipient_user_id IS NULL) AND l.archived_at IS NULL';
            $params[] = $userId;
        } else {
            $where[] = 'l.recipient_user_id = ? AND l.archived_at IS NULL';
            $params[] = $userId;
        }

        if (in_array($typeFilter, ['وارده', 'صادره', 'داخلی'], true)) {
            $where[] = 'l.letter_type = ?';
            $params[] = $typeFilter;
        } elseif ($typeFilter === 'urgent') {
            $where[] = 'l.priority_level IN ("فوری", "آنی")';
        } elseif ($typeFilter === 'unsigned') {
            $where[] = 'l.sign_status LIKE "%پیش‌نویس%"';
        }
        $letters = Database::fetchAll(
            'SELECT l.*, su.full_name AS sender_name, ru.full_name AS recipient_name
             FROM oa_letters l
             LEFT JOIN users su ON su.id = l.sender_user_id
             LEFT JOIN users ru ON ru.id = l.recipient_user_id
             WHERE ' . implode(' AND ', $where) . '
             ORDER BY l.id DESC',
            $params
        );

        $referralWhere = $canViewAll ? '1 = 1' : '(r.to_user_id = ? OR r.from_user_id = ?)';
        $referralParams = $canViewAll ? [] : [$userId, $userId];
        $referrals = Database::fetchAll(
            'SELECT r.*, l.indicator_no, l.subject_title,
                    fu.full_name AS from_user_name, tu.full_name AS to_user_name
             FROM oa_letter_referrals r
             JOIN oa_letters l ON l.id = r.letter_id
             LEFT JOIN users fu ON fu.id = r.from_user_id
             LEFT JOIN users tu ON tu.id = r.to_user_id
             WHERE ' . $referralWhere . '
             ORDER BY r.id DESC',
            $referralParams
        );
        $adminRequests = $canManageRequests
            ? Database::fetchAll('SELECT * FROM oa_admin_requests ORDER BY id DESC')
            : Database::fetchAll('SELECT * FROM oa_admin_requests WHERE requester_user_id = ? ORDER BY id DESC', [$userId]);
        $minutes = Database::fetchAll('SELECT * FROM oa_meeting_minutes ORDER BY id DESC');
        $openReferrals = $canViewAll
            ? (int)Database::scalar('SELECT COUNT(*) FROM oa_letter_referrals WHERE referral_status NOT LIKE "%مختومه%"')
            : (int)Database::scalar(
                'SELECT COUNT(*) FROM oa_letter_referrals WHERE to_user_id = ? AND referral_status NOT LIKE "%مختومه%"',
                [$userId]
            );

        return [
            'kpis' => [
                'total_letters'     => count($letters),
                'unread_letters'    => (int)Database::scalar(
                    'SELECT COUNT(*) FROM oa_letters WHERE recipient_user_id = ? AND archived_at IS NULL AND read_at IS NULL',
                    [$userId]
                ),
                'open_referrals'    => $openReferrals,
                'pending_requests'  => $canManageRequests
                    ? (int)Database::scalar('SELECT COUNT(*) FROM oa_admin_requests WHERE approval_status LIKE "%منتظر%"')
                    : count(array_filter($adminRequests, static fn(array $request): bool => str_contains((string)$request['approval_status'], 'منتظر'))),
                'minutes_count'     => (int)Database::scalar('SELECT COUNT(*) FROM oa_meeting_minutes'),
            ],
            'letters'        => $letters,
            'referrals'      => $referrals,
            'admin_requests' => $adminRequests,
            'minutes'        => $minutes,
            'templates'      => self::LETTER_TEMPLATES,
            'recipients'     => self::getStaffRecipients(),
            'today'          => Jalali::today(),
        ];
    }

    public static function composeLetter(array $input, int $actorId, string $actorName, string $actorRole): array
    {
        if ($actorId < 1) {
            return ['ok' => false, 'error' => 'نشست کاربری معتبر نیست؛ دوباره وارد سامانه شوید.'];
        }

        $recipientId = (int)($input['recipient_user_id'] ?? 0);
        $recipient = Database::fetchOne(
            "SELECT id, full_name, role FROM users
             WHERE id = ? AND status = 'active' AND role IN ('super_admin','training_expert','finance_manager','crm_manager','instructor')
             LIMIT 1",
            [$recipientId]
        );
        if (!$recipient) {
            return ['ok' => false, 'error' => 'گیرنده معتبر انتخاب نشده است؛ یک همکار فعال را از فهرست گیرندگان انتخاب کنید.'];
        }

        $type = in_array($input['letter_type'] ?? '', ['وارده', 'صادره', 'داخلی'], true) ? $input['letter_type'] : 'داخلی';
        $prio = in_array($input['priority_level'] ?? '', ['عادی', 'فوری', 'آنی'], true) ? $input['priority_level'] : 'عادی';
        $conf = in_array($input['confidentiality'] ?? '', ['عادی', 'محرمانه', 'خیلی محرمانه'], true) ? $input['confidentiality'] : 'عادی';
        $subject = trim((string)($input['subject_title'] ?? ''));
        if ($subject === '') {
            return ['ok' => false, 'error' => 'موضوع نامه را وارد کنید.'];
        }

        $body = trim((string)($input['letter_body'] ?? ''));
        $externalRecipient = trim((string)($input['external_recipient'] ?? ''));
        if (!empty($input['use_ai_polish']) || $body === '') {
            $ai = AvalAiService::generate(
                "متن یک نامه رسمی و محترمانه اداری ایرانی برای موضوع «{$subject}» خطاب به «{$recipient['full_name']}» در ۴ سطر رسمی بنویس.",
                'Office Automation Letter'
            );
            if (!empty($ai['content'])) {
                $body = trim((string)$ai['content']);
            }
        }
        if ($body === '') {
            return ['ok' => false, 'error' => 'متن نامه خالی است و نگارش خودکار نیز متنی تولید نکرد؛ متن را وارد یا دوباره تلاش کنید.'];
        }

        $signNow = !empty($input['sign_immediately']);
        $status = $signNow ? 'امضاشده و ثبت در دبیرخانه' : 'پیش‌نویس منتظر امضا';
        $senderUnit = $type === 'وارده'
            ? trim((string)($input['sender_unit'] ?? ''))
            : $actorName . ' — ' . Auth::roleLabel($actorRole);
        if ($senderUnit === '') {
            return ['ok' => false, 'error' => 'نام فرستنده بیرونی نامه وارده را وارد کنید.'];
        }
        $parentId = max(0, (int)($input['reply_to_letter_id'] ?? 0));
        if ($parentId > 0 && empty(self::getLetterWithReferrals(
            $parentId,
            $actorId,
            in_array($actorRole, self::MANAGER_ROLES, true)
        )['letter'])) {
            return ['ok' => false, 'error' => 'نامه مرجع برای پاسخ یافت نشد یا دسترسی به آن ندارید.'];
        }

        $pdo = Database::connection();
        $pdo->beginTransaction();
        try {
            $newId = Database::insert(
                'INSERT INTO oa_letters
                 (indicator_no, letter_type, priority_level, confidentiality, sender_unit, recipient_org, subject_title, letter_body, attachment_note, signatory_name, sign_status, qr_verify_code, created_shamsi, sender_user_id, recipient_user_id, reply_to_letter_id, recipient_status, external_recipient)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "خوانده‌نشده", ?)',
                [
                    'OA-TMP-' . bin2hex(random_bytes(6)),
                    $type,
                    $prio,
                    $conf,
                    mb_substr($senderUnit, 0, 140),
                    mb_substr((string)$recipient['full_name'], 0, 160),
                    mb_substr($subject, 0, 220),
                    $body,
                    mb_substr(trim((string)($input['attachment_note'] ?? '')) ?: 'ندارد', 0, 160),
                    $actorName,
                    $status,
                    'OA-PENDING',
                    Jalali::today(),
                    $actorId,
                    $recipientId,
                    $parentId > 0 ? $parentId : null,
                    mb_substr($externalRecipient, 0, 160) ?: null,
                ]
            );
            $today = Jalali::today();
            $year = mb_substr($today, 0, 4);
            $indicator = $year . '/د/' . (1043 + $newId);
            $qrCode = 'OA-VERIFY-' . $year . '-' . $newId;
            Database::execute(
                'UPDATE oa_letters SET indicator_no = ?, qr_verify_code = ? WHERE id = ?',
                [$indicator, $qrCode, $newId]
            );
            Database::insert(
                'INSERT INTO notifications (user_id, target_role, title, body, type, link)
                 VALUES (?, NULL, ?, ?, ?, ?)',
                [
                    $recipientId,
                    'نامه جدید در کارتابل شما',
                    'نامه «' . $subject . '» از ' . $actorName . ' به کارتابل شما ارسال شد.',
                    $prio === 'عادی' ? 'info' : 'urgent',
                    App::url('office-automation', ['tab' => 'inbox']),
                ]
            );
            $pdo->commit();
        } catch (\Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }

        Auth::audit('OFFICE_AUTO', 'CREATE_LETTER', 'oa_letters', $newId, ['indicator' => $indicator]);
        return [
            'ok' => true,
            'id' => $newId,
            'indicator_no' => $indicator,
            'recipient' => (string)$recipient['full_name'],
        ];
    }

    public static function signAndSealLetter(int $letterId, int $signerId, string $signerName, bool $canManage): bool
    {
        $updated = Database::execute(
            'UPDATE oa_letters
             SET sign_status = "امضاشده و ثبت در دبیرخانه", signatory_name = ?
             WHERE id = ? AND sign_status LIKE "%پیش‌نویس%"
               AND (sender_user_id = ? OR ? = 1)',
            [$signerName, $letterId, $signerId, $canManage ? 1 : 0]
        );
        if ($updated < 1) {
            return false;
        }
        Auth::audit('OFFICE_AUTO', 'SIGN_LETTER', 'oa_letters', $letterId);
        return true;
    }

    public static function markLetterRead(int $letterId, int $userId): bool
    {
        $updated = Database::execute(
            'UPDATE oa_letters SET recipient_status = "خوانده‌شده", read_at = NOW()
             WHERE id = ? AND recipient_user_id = ? AND archived_at IS NULL AND read_at IS NULL',
            [$letterId, $userId]
        );
        return $updated > 0;
    }

    public static function archiveLetter(int $letterId, int $userId): bool
    {
        $updated = Database::execute(
            'UPDATE oa_letters SET recipient_status = "بایگانی‌شده", archived_at = NOW()
             WHERE id = ? AND recipient_user_id = ? AND archived_at IS NULL',
            [$letterId, $userId]
        );
        if ($updated > 0) {
            Auth::audit('OFFICE_AUTO', 'ARCHIVE_LETTER', 'oa_letters', $letterId);
        }
        return $updated > 0;
    }

    public static function referLetter(array $input, int $fromUserId, string $fromActor, bool $canViewAll): array
    {
        $letterId = max(0, (int)($input['letter_id'] ?? 0));
        $toUserId = max(0, (int)($input['to_user_id'] ?? 0));
        $recipient = Database::fetchOne(
            "SELECT id, full_name FROM users WHERE id = ? AND status = 'active'
             AND role IN ('super_admin','training_expert','finance_manager','crm_manager','instructor') LIMIT 1",
            [$toUserId]
        );
        if (!$recipient) {
            return ['ok' => false, 'error' => 'گیرنده ارجاع معتبر نیست؛ همکار فعال را از فهرست انتخاب کنید.'];
        }
        if (empty(self::getLetterWithReferrals($letterId, $fromUserId, $canViewAll)['letter'])) {
            return ['ok' => false, 'error' => 'نامه برای ارجاع یافت نشد یا دسترسی به آن ندارید.'];
        }

        $cmd = trim((string)($input['action_command'] ?? 'جهت اقدام مقتضی'));
        $note = trim((string)($input['paraph_margin_note'] ?? ''));
        if ($note === '') {
            return ['ok' => false, 'error' => 'دستور پاراف و توضیح ارجاع را وارد کنید.'];
        }
        $deadline = trim((string)($input['deadline_shamsi'] ?? '')) ?: Jalali::today();

        Database::insert(
            'INSERT INTO oa_letter_referrals
             (letter_id, from_person, to_person_unit, action_command, paraph_margin_note, deadline_shamsi, referral_status, created_shamsi, from_user_id, to_user_id)
             VALUES (?, ?, ?, ?, ?, ?, "در دست اقدام", ?, ?, ?)',
            [$letterId, $fromActor, (string)$recipient['full_name'], $cmd, $note, $deadline, Jalali::today(), $fromUserId, $toUserId]
        );
        Database::insert(
            'INSERT INTO notifications (user_id, target_role, title, body, type, link)
             VALUES (?, NULL, ?, ?, "warning", ?)',
            [
                $toUserId,
                'ارجاع جدید در کارتابل شما',
                'یک نامه برای اقدام به شما ارجاع شد: ' . $note,
                App::url('office-automation', ['tab' => 'referrals']),
            ]
        );
        Auth::audit('OFFICE_AUTO', 'REFER_LETTER', 'oa_letters', $letterId, ['to_user_id' => $toUserId]);
        return ['ok' => true, 'to' => (string)$recipient['full_name']];
    }

    public static function completeReferral(int $referralId, int $userId, bool $canManage): bool
    {
        $updated = Database::execute(
            'UPDATE oa_letter_referrals SET referral_status = "اقدام و مختومه شد"
             WHERE id = ? AND referral_status NOT LIKE "%مختومه%"
               AND (to_user_id = ? OR ? = 1)',
            [$referralId, $userId, $canManage ? 1 : 0]
        );
        if ($updated > 0) {
            Auth::audit('OFFICE_AUTO', 'COMPLETE_REFERRAL', 'oa_letter_referrals', $referralId);
        }
        return $updated > 0;
    }

    public static function submitAdminRequest(array $input, int $requesterId, string $requesterName): array
    {
        $code = 'OA-REQ-' . mb_substr(Jalali::today(), 0, 4) . '-' . strtoupper(bin2hex(random_bytes(4)));
        $pdo = Database::connection();
        $pdo->beginTransaction();
        try {
            Database::insert(
                'INSERT INTO oa_admin_requests
                 (req_code, requester_name, unit_name, req_category, date_range_or_amount, description_note, approval_status, approver_note, created_shamsi, requester_user_id)
                 VALUES (?, ?, ?, ?, ?, ?, "منتظر تأیید مدیریت", "—", ?, ?)',
                [
                    $code,
                    $requesterName,
                    trim((string)($input['unit_name'] ?? 'واحد آموزش')),
                    trim((string)($input['req_category'] ?? 'مرخصی استحقاقی / ساعتی')),
                    trim((string)($input['date_range_or_amount'] ?? '۱ روز کاری')),
                    trim((string)($input['description_note'] ?? 'ثبت درخواست اداری در کارتابل')),
                    Jalali::today(),
                    $requesterId,
                ]
            );
            $managers = Database::fetchAll(
                "SELECT id FROM users WHERE status = 'active' AND role IN ('super_admin','training_expert','finance_manager')"
            );
            foreach ($managers as $manager) {
                Database::insert(
                    'INSERT INTO notifications (user_id, target_role, title, body, type, link)
                     VALUES (?, NULL, ?, ?, "warning", ?)',
                    [
                        (int)$manager['id'],
                        'درخواست اداری جدید',
                        $requesterName . ' یک درخواست «' . trim((string)($input['req_category'] ?? 'اداری')) . '» ثبت کرد.',
                        App::url('office-automation', ['tab' => 'requests']),
                    ]
                );
            }
            $pdo->commit();
        } catch (\Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }
        Auth::audit('OFFICE_AUTO', 'SUBMIT_ADMIN_REQUEST', 'oa_admin_requests', null, ['req_code' => $code]);
        return ['ok' => true, 'req_code' => $code];
    }

    public static function decideAdminRequest(int $reqId, string $decision, string $approverName): bool
    {
        $status = $decision === 'reject' ? 'مخالفت شد' : 'تأیید نهایی مدیریت';
        $note = $decision === 'reject'
            ? 'به دلیل هم‌زمانی با برنامه اجرایی، نیاز به هماهنگی مجدد دارد (' . $approverName . ').'
            : 'مورد تأیید مدیریت قرار گرفت (' . $approverName . ').';
        $request = Database::fetchOne(
            'SELECT requester_user_id, req_code FROM oa_admin_requests
             WHERE id = ? AND approval_status LIKE "%منتظر%" LIMIT 1',
            [$reqId]
        );
        if (!$request) {
            return false;
        }
        $updated = Database::execute(
            'UPDATE oa_admin_requests SET approval_status = ?, approver_note = ?
             WHERE id = ? AND approval_status LIKE "%منتظر%"',
            [$status, $note, $reqId]
        );
        if ($updated > 0) {
            if ((int)($request['requester_user_id'] ?? 0) > 0) {
                Database::insert(
                    'INSERT INTO notifications (user_id, target_role, title, body, type, link)
                     VALUES (?, NULL, ?, ?, ?, ?)',
                    [
                        (int)$request['requester_user_id'],
                        'نتیجه درخواست اداری',
                        'درخواست ' . $request['req_code'] . ' ' . $status . ' شد.',
                        $decision === 'reject' ? 'warning' : 'success',
                        App::url('office-automation', ['tab' => 'requests']),
                    ]
                );
            }
            Auth::audit('OFFICE_AUTO', 'DECIDE_ADMIN_REQUEST', 'oa_admin_requests', $reqId, ['decision' => $decision]);
        }
        return $updated > 0;
    }

    public static function recordMeetingMinutes(array $input, string $chairName): array
    {
        $code = 'MIN-' . mb_substr(Jalali::today(), 0, 4) . '-' . strtoupper(bin2hex(random_bytes(4)));
        Database::insert(
            'INSERT INTO oa_meeting_minutes
             (minute_code, meeting_title, chairperson, attendees_summary, key_resolutions, responsible_owner, due_shamsi, execution_status, created_shamsi)
             VALUES (?, ?, ?, ?, ?, ?, ?, "ابلاغ‌شده — در حال پیگیری", ?)',
            [
                $code,
                trim((string)($input['meeting_title'] ?? 'نشست هماهنگی اداری و آموزشی')),
                trim((string)($input['chairperson'] ?? '')) ?: $chairName,
                trim((string)($input['attendees_summary'] ?? 'اعضای واحد مربوطه')),
                trim((string)($input['key_resolutions'] ?? 'مصوبات جلسه ثبت گردید.')),
                trim((string)($input['responsible_owner'] ?? 'کارشناس مسئول پیگیری')),
                trim((string)($input['due_shamsi'] ?? '۱۴۰۵/۰۸/۲۰')),
                Jalali::today(),
            ]
        );
        return ['ok' => true, 'minute_code' => $code];
    }

    public static function getLetterWithReferrals(int $letterId, int $userId, bool $canViewAll): array
    {
        $accessWhere = $canViewAll
            ? 'l.id = ?'
            : 'l.id = ? AND (
                 l.sender_user_id = ? OR l.recipient_user_id = ?
                 OR EXISTS (
                     SELECT 1 FROM oa_letter_referrals ar
                     WHERE ar.letter_id = l.id AND (ar.from_user_id = ? OR ar.to_user_id = ?)
                 )
             )';
        $params = $canViewAll
            ? [$letterId]
            : [$letterId, $userId, $userId, $userId, $userId];
        $letter = Database::fetchOne(
            'SELECT l.*, su.full_name AS sender_name, ru.full_name AS recipient_name
             FROM oa_letters l
             LEFT JOIN users su ON su.id = l.sender_user_id
             LEFT JOIN users ru ON ru.id = l.recipient_user_id
             WHERE ' . $accessWhere . ' LIMIT 1',
            $params
        );
        $refs = [];
        if ($letter) {
            $refs = Database::fetchAll('SELECT * FROM oa_letter_referrals WHERE letter_id = ? ORDER BY id ASC', [(int)$letter['id']]);
        }
        return ['letter' => $letter, 'referrals' => $refs];
    }
}
