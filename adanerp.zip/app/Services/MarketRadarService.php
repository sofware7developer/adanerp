<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database;
use App\Core\Jalali;

/**
 * موتور هوشمند رادار بازار آموزش، پایش زنده وب‌سایت رقبا و تحقیق و توسعه (Market Radar & R&D Engine )
 * دارای ۴ موتور عملیاتی واقعی و ایمن ویژه XAMPP / cPanel:
 * ۱. موتور کاوشگر زنده تقاضای وب (DuckDuckGo HTML + Google News RSS) با تطبیق خودکار شکاف کاتالوگ SQL
 * ۲. موتور خزشگر دو مرحله‌ای وب‌سایت رقبا (Direct HTTPS cURL + Jina Reader Fallback + محافظت کامل ضد SSRF)
 * ۳. موتور طراحی هوشمند شناسنامه دوره جدید R&D با AI + محاسبه قیمت رقابتی و نقطه سربه‌سر (Break-Even)
 * ۴. موتور تراکنشی ۱-کلیکی تصویب شورای R&D و انتشار مستقیم دوره در کاتالوگ رسمی TMS + سرفصل LMS + کارتابل BPMS
 */
final class MarketRadarService
{
    /**
     * بررسی امنیتی سخت‌گیرانه ضد SSRF پیش از هرگونه درخواست خروجی به URL دلخواه کاربر
     */
    public static function isSafePublicUrl(string $url): bool
    {
        $parts = parse_url(trim($url));
        if (!$parts || empty($parts['scheme']) || empty($parts['host'])) {
            return false;
        }
        $scheme = strtolower((string)$parts['scheme']);
        if (!in_array($scheme, ['http', 'https'], true)) {
            return false;
        }
        $host = strtolower((string)$parts['host']);
        if (in_array($host, ['localhost', '127.0.0.1', '0.0.0.0', '::1'], true)) {
            return false;
        }
        $ips = @gethostbynamel($host);
        if (!$ips || !is_array($ips)) {
            return false;
        }
        foreach ($ips as $ip) {
            if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === false) {
                return false;
            }
        }
        return true;
    }

    /**
     * تطبیق هوشمند عنوان کشف‌شده در اینترنت با کاتالوگ فعلی دوره‌های آدان (جدول زنده courses)
     */
    public static function checkCatalogGap(string $topicTitle): string
    {
        $courses = Database::fetchAll('SELECT title, summary FROM courses');
        $cleanTopic = mb_strtolower($topicTitle, 'UTF-8');
        $words = preg_split('/[\s،,\-\(\)\/]+/u', $cleanTopic) ?: [];
        $keywords = array_values(array_filter($words, static fn(string $w): bool => mb_strlen($w, 'UTF-8') >= 4
            && !in_array($w, ['دوره', 'آموزش', 'آموزشی', 'جامع', 'کارگاه', 'تخصصی', 'آنلاین', 'حضوری', 'ایران', 'اتاق', 'بازرگانی', 'بین‌الملل', 'بین‌المللی'], true)));

        foreach ($courses as $c) {
            $haystack = mb_strtolower($c['title'] . ' ' . ($c['summary'] ?? ''), 'UTF-8');
            $hits = 0;
            foreach ($keywords as $kw) {
                if (mb_strpos($haystack, $kw) !== false) {
                    $hits++;
                }
            }
            if ($hits >= 2) {
                return 'پوشش فعلی در کاتالوگ آدان (' . $c['title'] . ')';
            }
        }
        return 'شکاف طلایی کاتالوگ (اقیانوس آبی — پیشنهاد ساخت)';
    }

    /**
     * کاوش زنده اینترنت (DuckDuckGo HTML + Google News RSS) برای کشف دوره‌های پرتقاضا و سیگنال‌های روز بازار
     */
    public static function scanLiveWebDemand(string $query): array
    {
        $q = trim($query) !== '' ? trim($query) : 'دوره آموزشی صادرات هوش مصنوعی گمرک بازرگانی';
        $inserted = 0;
        $mode = 'live_web';
        $shamsi = Jalali::today();
        $foundItems = [];

        // ۱. کاوش زنده نتایج وب فارسی/انگلیسی در DuckDuckGo HTML
        $ddgUrl = 'https://html.duckduckgo.com/html/?q=' . urlencode('دوره آموزشی ' . $q);
        $ddgHtml = self::httpGet($ddgUrl, 7);
        if ($ddgHtml !== '' && preg_match_all('#<a[^>]*class="result__a"[^>]*href="([^"]+)"[^>]*>(.*?)</a>#si', $ddgHtml, $matches, PREG_SET_ORDER)) {
            foreach (array_slice($matches, 0, 5) as $idx => $m) {
                $rawHref = html_entity_decode((string)$m[1], ENT_QUOTES | ENT_HTML5, 'UTF-8');
                if (preg_match('/uddg=([^&]+)/', $rawHref, $um)) {
                    $rawHref = urldecode($um[1]);
                }
                $title = trim((string)preg_replace('/\s+/u', ' ', html_entity_decode(strip_tags((string)$m[2]), ENT_QUOTES | ENT_HTML5, 'UTF-8')));
                if (mb_strlen($title, 'UTF-8') >= 12) {
                    $foundItems[] = [
                        'title' => mb_substr($title, 0, 240, 'UTF-8'),
                        'url' => substr($rawHref, 0, 550),
                        'engine' => 'DuckDuckGo Live Web',
                        'demand' => max(78, 95 - ($idx * 3)),
                        'sat' => min(65, 24 + ($idx * 7)),
                    ];
                }
            }
        }

        // ۲. کاوش زنده اخبار و روندهای روز تجارت جهانی از Google News RSS
        $rssUrl = 'https://news.google.com/rss/search?q=' . urlencode($q . ' trade export training') . '&hl=en-US&gl=US&ceid=US:en';
        $rssXml = self::httpGet($rssUrl, 6);
        if ($rssXml !== '') {
            $sx = @simplexml_load_string($rssXml);
            if ($sx && isset($sx->channel->item)) {
                $rIdx = 0;
                foreach ($sx->channel->item as $it) {
                    $t = trim((string)$it->title);
                    $lnk = trim((string)$it->link);
                    if ($t !== '') {
                        $foundItems[] = [
                            'title' => mb_substr($t, 0, 240, 'UTF-8'),
                            'url' => substr($lnk, 0, 550),
                            'engine' => 'Google News Global RSS',
                            'demand' => 91 - ($rIdx * 3),
                            'sat' => 18 + ($rIdx * 5),
                        ];
                    }
                    if (++$rIdx >= 3) {
                        break;
                    }
                }
            }
        }

        // پشتیبان هوشمند آفلاین اگر سرور XAMPP کاملاً بدون اینترنت باشد
        if (empty($foundItems)) {
            $mode = 'offline_intelligence_fallback';
            $foundItems[] = [
                'title' => 'روند پرمتقاضی بازار: کارگاه عملی ' . $q . ' ویژه مدیران صادرات و بازرگانی استان',
                'url' => 'https://itecc.tccim.ir/',
                'engine' => 'موتور هوش بازار آفلاین (شبکه محدود)',
                'demand' => 92,
                'sat' => 26,
            ];
        }

        foreach ($foundItems as $item) {
            $gap = self::checkCatalogGap($item['title']);
            $gapBonus = str_contains($gap, 'شکاف') ? 20 : 8;
            $opp = (int)min(99, round(0.45 * $item['demand'] + 0.35 * (100 - $item['sat']) + $gapBonus));

            $exists = Database::fetchOne('SELECT id FROM rd_web_signals WHERE signal_title = ? LIMIT 1', [$item['title']]);
            if (!$exists) {
                Database::insert(
                    'INSERT INTO rd_web_signals (keyword_query, signal_title, source_engine, source_url, demand_score, competition_saturation, opportunity_index, catalog_gap_status, discovered_shamsi)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
                    [$q, $item['title'], $item['engine'], $item['url'], $item['demand'], $item['sat'], $opp, $gap, $shamsi]
                );
                $inserted++;
            }
        }

        return ['ok' => true, 'mode' => $mode, 'discovered_count' => count($foundItems), 'inserted_count' => $inserted];
    }

    /**
     * خزش و کالبدشکافی زنده وب‌سایت رقیب آموزشی با استخراج خودکار عناوین دوره‌ها و شهریه (Direct cURL + Jina Fallback)
     */
    public static function crawlCompetitorWebsite(int $competitorId, string $targetUrl): array
    {
        if (!self::isSafePublicUrl($targetUrl)) {
            return ['ok' => false, 'error' => 'آدرس واردشده نامعتبر است یا به دلایل امنیتی ضد SSRF (آی‌پی داخلی/لوکال) مسدود شد.'];
        }

        $body = self::httpGet($targetUrl, 4);
        $via = 'اتصال مستقیم HTTPS cURL';

        // اگر سایت رقیب ایرانی روی IP خارج کشور فایروال داشت، عبور هوشمند از ریدر استاندارد
        if (strlen($body) < 400) {
            $body = self::httpGet('https://r.jina.ai/' . $targetUrl, 9);
            $via = 'گذرگاه خوانشگر هوشمند وب (Jina Live Reader)';
        }

        $extractedCourses = [];
        if ($body !== '') {
            // استخراج عناوین از HTML یا Markdown
            if (preg_match_all('/(?:###\s+|##\s+|<h[234][^>]*>)(.*?)(?:\n|<\/h[234]>)/iu', $body, $hm)) {
                foreach ($hm[1] as $rawHeading) {
                    $clean = trim((string)preg_replace('/\s+/u', ' ', strip_tags(html_entity_decode($rawHeading, ENT_QUOTES | ENT_HTML5, 'UTF-8'))));
                    $clean = trim($clean, '#*- []()');
                    if (mb_strlen($clean, 'UTF-8') >= 14 && mb_strlen($clean, 'UTF-8') <= 160
                        && !preg_match('/(درباره|تماس با|منو|ورود|ثبت نام|لینک|دانلود|اخبار)/u', $clean)) {
                        $extractedCourses[] = $clean;
                    }
                    if (count($extractedCourses) >= 5) {
                        break;
                    }
                }
            }
        }

        $detectedRial = null;
        $normBody = \App\Core\IranValidator::normalizeDigits($body);
        $priceMatches = [];
        if (
            count(array_unique($extractedCourses)) === 1
            && preg_match_all('/((?:\d{1,3}(?:,\d{3})+)|(?:\d{5,}))\s*(تومان|ریال)/u', $normBody, $priceMatches, PREG_SET_ORDER) === 1
        ) {
            $pm = $priceMatches[0];
            $num = filter_var(str_replace(',', '', $pm[1]), FILTER_VALIDATE_INT);
            if ($num !== false && ($pm[2] !== 'تومان' || $num <= intdiv(PHP_INT_MAX, 10))) {
                $detectedRial = $pm[2] === 'تومان' ? $num * 10 : $num;
            }
        }

        $shamsi = Jalali::today();
        Database::execute('UPDATE rd_competitors SET last_crawled_at = ? WHERE id = ?', [$shamsi . ' (زنده)', $competitorId]);

        $saved = 0;
        foreach (array_unique($extractedCourses) as $cTitle) {
            $exists = Database::fetchOne(
                'SELECT id FROM rd_competitor_courses WHERE competitor_id = ? AND course_title = ? LIMIT 1',
                [$competitorId, $cTitle]
            );
            if (!$exists) {
                $gap = self::checkCatalogGap($cTitle);
                Database::insert(
                    'INSERT INTO rd_competitor_courses (competitor_id, course_title, duration_hours, tuition_rial, delivery_format, source_url, our_catalog_status, captured_shamsi)
                     VALUES (?, ?, ?, ?, "استخراج زنده وب", ?, ?, ?)',
                    [$competitorId, $cTitle, null, $detectedRial, $targetUrl, $gap, $shamsi]
                );
                $saved++;
            }
        }

        return [
            'ok' => true,
            'channel' => $via,
            'bytes_fetched' => strlen($body),
            'courses_extracted' => count($extractedCourses),
            'saved_new' => $saved,
        ];
    }

    /**
     * طراحی هوشمند شناسنامه دوره جدید تحقیق و توسعه (R&D) بر پایه شکاف رقبا + سیگنال‌های وب + AI
     */
    public static function generateAiRdProposal(string $topicFocus, int $hours = 20): array
    {
        $hours = max(8, min(80, $hours));
        $avgHourly = (int)Database::scalar('SELECT COALESCE(AVG(avg_hourly_rate_rial), 3200000) FROM rd_competitors WHERE id <= 4');
        $compAvgTotal = $avgHourly * $hours;
        // استراتژی قیمت‌گذاری بهینه اتاق: ۱۵٪ مزیت رقابتی برای فراگیران آدان با حفظ حاشیه سود بالای ۵۰٪
        $suggestedTuition = (int)(round(($compAvgTotal * 0.85) / 1000000) * 1000000);
        $directCost = ($hours * 4200000) + 95000000; // حق‌التدریس استاد تراز اول + پذیرایی، گواهی دوزبانه و زیرساخت
        $breakEven = max(5, (int)ceil($directCost / max(1, $suggestedTuition)));
        $projectedNet22 = (22 * $suggestedTuition) - $directCost;

        $topSignals = Database::fetchAll('SELECT signal_title, opportunity_index FROM rd_web_signals ORDER BY opportunity_index DESC LIMIT 3');
        $sigSummary = implode(' | ', array_map(static fn(array $s): string => $s['signal_title'] . ' (امتیاز ' . $s['opportunity_index'] . ')', $topSignals));

        $aiPrompt = "بر اساس موضوع «{$topicFocus}» با مدت {$hours} ساعت برای مرکز آموزش مؤسسه آموزشی آدان و سیگنال‌های روز بازار ({$sigSummary}): "
            . "۱) در ۳ خط استدلال استراتژیک برتری رقابتی این دوره نسبت به موسسات رقیب تهران را بنویس. "
            . "۲) ۶ سرفصل عملیاتی و کارگاهی دقیق را با جداکننده | بنویس.";
        $aiRes = AvalAiService::generate(
            $aiPrompt,
            'MarketRadar:RD',
            'شما مدیر ارشد تحقیق و توسعه (R&D) و استراتژیست آموزشی مؤسسه آموزشی آدان هستید. پاسخ فشرده، اجرایی و فارسی رسمی بدهید.'
        );

        $rationale = 'تحلیل ترکیبی رادار بازار و رقبا نشان می‌دهد موضوع «' . $topicFocus . '» دارای شکاف عرضه مستقیم در استان است. '
            . 'با تعیین شهریه رقابتی ' . number_format($suggestedTuition) . ' ریال (۱۵٪ پایین‌تر از میانگین رقبا: ' . number_format($compAvgTotal) . ' ریال)، '
            . 'نقطه سربه‌سر دوره تنها با ' . $breakEven . ' نفر پوشش یافته و در ظرفیت ۲۲ نفر سود خالص ' . number_format($projectedNet22) . ' ریال ایجاد می‌کند.';
        $syllabus = 'مبانی قانونی، مقررات روز ۱۴۰۵ و استانداردهای بین‌المللی ' . $topicFocus
            . ' | ۲. تحلیل خطاهای رایج بنگاه‌های صادراتی و مطالعه موردی واقعی'
            . ' | ۳. کارگاه عملی کار با سامانه‌ها و مستندات اجرایی'
            . ' | ۴. بهینه‌سازی مالی، ارزی و مدیریت ریسک قراردادی'
            . ' | ۵. به‌کارگیری ابزارهای هوش مصنوعی و داده‌کاوی بازار هدف'
            . ' | ۶. پروژه عملیاتی تدوین نقشه راه ویژه شرکت‌های طرف قرارداد مؤسسه آموزشی آدان';

        if (($aiRes['mode'] ?? '') === 'live_api' && !empty($aiRes['content'])) {
            $rationale = mb_substr(trim((string)$aiRes['content']), 0, 650, 'UTF-8');
        }

        $code = 'RD-1405-' . rand(200, 999);
        $title = 'دوره تخصصی-کاربردی ' . $topicFocus . ' (ویژه بنگاه‌های صادراتی و صنعتی دانش‌پذیر آدان)';
        $id = Database::insert(
            'INSERT INTO rd_course_proposals (proposal_code, proposed_title, target_audience, recommended_hours, competitor_avg_rial, suggested_tuition_rial, breakeven_learners, projected_net_rial, strategic_rationale, syllabus_outline, ai_confidence_score, status, created_shamsi)
             VALUES (?, ?, "مدیران عامل، بازرگانی و صادرات شرکت‌های طرف قرارداد مؤسسه آموزشی آدان", ?, ?, ?, ?, ?, ?, ?, 93, "آماده طرح در شورای R&D", ?)',
            [$code, $title, $hours, $compAvgTotal, $suggestedTuition, $breakEven, $projectedNet22, $rationale, $syllabus, Jalali::today()]
        );

        return ['ok' => true, 'id' => $id, 'proposal_code' => $code, 'title' => $title];
    }

    /**
     * تبدیل ۱-کلیکی پیشنهاد مصوب R&D به دوره رسمی فعال در کاتالوگ TMS + سرفصل‌های LMS + پرونده BPMS
     */
    public static function approveAndLaunchToTms(int $proposalId, int $initiatorId): array
    {
        $pdo = Database::connection();
        $pdo->beginTransaction();

        try {
            $prop = Database::fetchOne('SELECT * FROM rd_course_proposals WHERE id = ?', [$proposalId]);
            if (!$prop) {
                throw new \RuntimeException('پیشنهاد موردنظر یافت نشد.');
            }
            if (!empty($prop['launched_course_id'])) {
                $pdo->commit();
                return ['ok' => true, 'already_launched' => true, 'course_id' => (int)$prop['launched_course_id']];
            }

            $courseCode = 'TRD-RD-' . rand(300, 999);
            $newCourseId = Database::insert(
                'INSERT INTO courses (category_id, code, title, duration_hours, tuition_rial, member_discount_pct, workflow_status, summary)
                 VALUES (1, ?, ?, ?, ?, 20, "published", ?)',
                [
                    $courseCode,
                    $prop['proposed_title'],
                    (int)$prop['recommended_hours'],
                    (int)$prop['suggested_tuition_rial'],
                    $prop['strategic_rationale'],
                ]
            );

            Database::insert(
                'INSERT INTO course_runs (course_id, instructor_id, classroom_id, run_code, term_label, start_date, end_date, start_shamsi, schedule_text, capacity, status)
                 VALUES (?, 5, 1, ?, "ترم پاییز ۱۴۰۵ (مصوب R&D)", "2026-11-11", "2026-12-06", "۱۴۰۵/۰۸/۲۰", "دوشنبه و چهارشنبه ۱۶ الی ۲۰", 28, "registration")',
                [$newCourseId, 'RUN-' . $courseCode]
            );

            $chapterId = Database::insert(
                'INSERT INTO lms_chapters (course_id, sort_order, title) VALUES (?, 1, ?)',
                [$newCourseId, 'فصل اول: سرفصل‌های تخصصی مصوب واحد تحقیق و توسعه (R&D)']
            );

            $modules = array_filter(array_map('trim', explode('|', (string)$prop['syllabus_outline'])));
            $order = 1;
            foreach ($modules as $modTitle) {
                Database::insert(
                    'INSERT INTO lms_lessons (chapter_id, course_id, sort_order, title, content_type, estimated_minutes, sequential_lock, body_html)
                     VALUES (?, ?, ?, ?, "article", 90, 1, ?)',
                    [$chapterId, $newCourseId, $order++, $modTitle, '<p>سرفصل مصوب واحد تحقیق و توسعه (R&amp;D) مبتنی بر نیازسنجی زنده بازار: ' . htmlspecialchars($modTitle, ENT_QUOTES, 'UTF-8') . '</p>']
                );
            }

            Database::insert(
                'INSERT INTO bpms_workflows (process_key, process_title, subject_label, initiator_id, current_step, assigned_role, sla_hours, elapsed_hours, status, history_json)
                 VALUES (?, "تصویب و انتشار دوره جدید واحد R&D در کاتالوگ TMS", ?, ?, "ابلاغ و شروع ثبت‌نام ترم جاری", "training_expert", 24, 2, "approved", ?)',
                [
                    'WF-' . $prop['proposal_code'],
                    $courseCode . ' — ' . $prop['proposed_title'],
                    max(1, $initiatorId),
                    json_encode([['step' => 'تصویب در کمیته R&D و ایجاد خودکار در TMS/LMS', 'course_code' => $courseCode]], JSON_UNESCAPED_UNICODE),
                ]
            );

            Database::execute(
                'UPDATE rd_course_proposals SET status = "منتشرشده در کاتالوگ TMS", launched_course_id = ? WHERE id = ?',
                [$newCourseId, $proposalId]
            );

            $pdo->commit();
            return ['ok' => true, 'course_id' => $newCourseId, 'course_code' => $courseCode, 'lessons_created' => $order - 1];
        } catch (\Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            return ['ok' => false, 'error' => $e->getMessage()];
        }
    }

    private static function httpGet(string $url, int $timeoutSec = 7): string
    {
        if (!function_exists('curl_init')) {
            return '';
        }
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 4,
            CURLOPT_CONNECTTIMEOUT => min(4, $timeoutSec),
            CURLOPT_TIMEOUT => $timeoutSec,
            CURLOPT_HTTPHEADER => ['Accept-Language: fa-IR,fa;q=0.9,en-US;q=0.8,en;q=0.7'],
            CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/125.0.0.0 Safari/537.36',
        ]);
        $res = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        return (is_string($res) && $code >= 200 && $code < 400) ? $res : '';
    }
}
