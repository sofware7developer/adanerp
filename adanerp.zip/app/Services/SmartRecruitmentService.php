<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database;
use App\Core\Jalali;

/**
 * موتور جامع هوشمند کاریابی، استودیو آگهی شغلی با AI، رزومه‌ساز تاییدشده و پایپ‌لاین ۶ مرحله‌ای ATS (v18.0)
 */
final class SmartRecruitmentService
{
    public const ATS_STAGES = [
        'new_cv'      => 'دریافت رزومه جدید',
        'ai_screened' => 'غربالگری هوشمند AI',
        'skill_test'  => 'آزمون عملی مهارتی',
        'interview'   => 'مصاحبه تخصصی',
        'offer_sent'  => 'ارسال پیشنهاد حقوق (Offer)',
        'hired'       => 'استخدام نهایی در کارخانه ✅',
    ];

    public const JOB_CATEGORIES = [
        'export_trade'      => 'صادرات، قراردادها و بازرگانی خارجی',
        'customs_logistics' => 'ثبت سفارش NTSW، ترخیص و گمرک EPL',
        'finance_tax'       => 'حسابداری، مالیات و سامانه مؤدیان',
        'ai_marketing'      => 'بازاریابی بین‌الملل و هوش مصنوعی تجاری',
        'industrial_mgmt'   => 'مدیریت صنعتی، زنجیره تأمین و کیفیت',
    ];

    /**
     * ۱. تولید خودکار شرح شغل حرفه‌ای، شرایط احراز و شاخص‌های عملکرد ۹۰ روزه (AI Job Ad Writer)
     */
    public static function generateAiJobDescription(string $jobTitle, string $categorySlug, string $seniority): array
    {
        $cleanTitle = trim($jobTitle) ?: 'کارشناس ارشد بازرگانی خارجی';
        $certMap = [
            'export_trade'      => 'گواهی جامع آکادمی تجارت بین‌الملل و UCP 600 مؤسسه آموزشی آدان',
            'customs_logistics' => 'گواهی تخصصی ثبت سفارش NTSW و اظهار گمرکی EPL اتاق',
            'finance_tax'       => 'گواهی عملیاتی سامانه مؤدیان مالیاتی و ارزش افزوده صادرات',
            'ai_marketing'      => 'گواهی شکار مشتریان صادراتی با هوش مصنوعی و TradeMap',
            'industrial_mgmt'   => 'گواهی مدیریت زنجیره تأمین و تضمین کیفیت ISO اتاق',
        ];
        $skillMap = [
            'export_trade'      => 'Incoterms 2020, UCP 600, مذاکره B2B بین‌المللی, قراردادهای صادراتی ICC, رفع تعهد ارزی',
            'customs_logistics' => 'سامانه جامع تجارت NTSW, سامانه EPL گمرک, طبقه‌بندی تعرفه HS Code, حمل ترکیبی و بیمه کلوز A',
            'finance_tax'       => 'سامانه مؤدیان, پایانه فروشگاهی, ماده ۱۶۹ مکرر, سپیدار/همکاران سیستم, بهای تمام‌شده',
            'ai_marketing'      => 'ITC TradeMap, کشف لید صادراتی با AI, مکاتبات انگلیسی تجاری BEC, مذاکره نمایشگاهی',
            'industrial_mgmt'   => 'برنامه‌ریزی تولید و صادرات, مدیریت پروژه, استاندارد ISO, تحلیل بهره‌وری',
        ];

        $cert = $certMap[$categorySlug] ?? $certMap['export_trade'];
        $skills = $skillMap[$categorySlug] ?? $skillMap['export_trade'];
        $desc = "🎯 مأموریت کلیدی سمت «{$cleanTitle}» ({$seniority}):\n"
            . "• راهبری اجرایی پرونده‌های تخصصی واحد مربوطه با رعایت کامل مقررات جاری تجارت، گمرک و مالیات کشور.\n"
            . "• شاخص کلیدی عملکرد ۹۰ روز نخست (90-Day KPI): کاهش ۲۵٪ زمان چرخه عملیاتی پرونده‌ها و مستندسازی استاندارد فرایندها.\n"
            . "• مزیت رقابتی ویژه در جذب: دارندگان «{$cert}» و گذرنامه مهارتی تاییدشده مؤسسه آموزشی آدان بدون نوبت وارد مرحله مصاحبه تخصصی می‌شوند.";

        return [
            'recommended_cert' => $cert,
            'recommended_skills' => $skills,
            'ai_description' => $desc,
        ];
    }

    /**
     * ۲. ثبت و انتشار آگهی شغلی کامل توسط کارفرمای دانش‌پذیر آدان
     */
    public static function publishRichJobAd(array $input): array
    {
        $code = 'JOB-1405-' . random_int(100, 899);
        $title = trim((string)($input['job_title'] ?? 'کارشناس بازرگانی خارجی'));
        $company = trim((string)($input['company_name'] ?? 'واحد صنعتی دانش‌پذیر آدان'));
        $cat = trim((string)($input['category_slug'] ?? 'export_trade'));
        $seniority = trim((string)($input['seniority_level'] ?? 'کارشناس ارشد'));
        $ai = self::generateAiJobDescription($title, $cat, $seniority);

        $desc = trim((string)($input['job_description_ai'] ?? '')) ?: $ai['ai_description'];
        $skills = trim((string)($input['required_skills_tags'] ?? '')) ?: $ai['recommended_skills'];
        $cert = trim((string)($input['required_chamber_cert'] ?? '')) ?: $ai['recommended_cert'];
        $minSal = max(15, (int)($input['salary_min_million'] ?? 45));
        $maxSal = max($minSal + 5, (int)($input['salary_max_million'] ?? 65));

        Database::insert(
            'INSERT INTO career_job_ads
             (ad_code, company_name, is_verified_member, job_title, category_slug, cooperation_type, seniority_level,
              city_location, salary_min_million, salary_max_million, perks_badges, required_skills_tags,
              required_chamber_cert, job_description_ai, is_urgent, views_count, applicants_count, ad_status, posted_shamsi)
             VALUES (?, ?, 1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 0, "active", ?)',
            [
                $code,
                $company,
                $title,
                $cat,
                trim((string)($input['cooperation_type'] ?? 'تمام‌وقت')),
                $seniority,
                trim((string)($input['city_location'] ?? 'مرکز استان')),
                $minSal,
                $maxSal,
                trim((string)($input['perks_badges'] ?? 'بیمه تکمیلی، پاداش عملکرد صادراتی، کمک‌هزینه آموزش آدان')),
                $skills,
                $cert,
                $desc,
                !empty($input['is_urgent']) ? 1 : 0,
                Jalali::today(),
            ]
        );

        // همگام‌سازی خودکار با جدول پایه بازارگاه اشتغال برای سازگاری کامل عقب‌رو
        Database::insert(
            'INSERT INTO job_board_listings (org_name, job_title, required_cert_code, city, salary_range, matched_candidates, posted_shamsi)
             VALUES (?, ?, ?, ?, ?, 3, ?)',
            [$company, $title, $cert, trim((string)($input['city_location'] ?? 'مرکز استان')), Jalali::digits("{$minSal} تا {$maxSal} میلیون تومان"), Jalali::today()]
        );

        return ['ok' => true, 'ad_code' => $code, 'job_title' => $title];
    }

    /**
     * ۳. ذخیره / همگام‌سازی خودکار رزومه حرفه‌ای کارجو با گواهی‌های QR، آزمون‌های استاندارد و امتیاز گیمیفیکیشن
     */
    public static function saveOrSyncCandidateCv(int $userId, array $input): array
    {
        $uid = max(1, $userId);
        $hud = LearnerBehaviorGamificationService::getUserHudSnapshot($uid, (string)($input['full_name'] ?? 'کارجوی دانش‌پذیر آدان'));
        $certRow = Database::fetchOne(
            'SELECT cert.serial_code, c.title FROM certificates cert JOIN courses c ON c.id = cert.course_id WHERE cert.status = "valid" ORDER BY cert.id ASC LIMIT 1'
        );
        $certSummary = $certRow
            ? ('گواهی رسمی تاییدشده ' . $certRow['title'] . ' (' . $certRow['serial_code'] . ')')
            : 'گذرنامه مهارت فعال مؤسسه آموزشی آدان';

        $xpBadge = 'سطح ' . Jalali::digits((string)$hud['level_num']) . ' — ' . $hud['rank_title'] . ' (' . Jalali::digits(number_format($hud['xp_points'])) . ' XP)';
        $fullName = trim((string)($input['full_name'] ?? 'مهندس مهرداد شریفی'));
        $headline = trim((string)($input['headline_title'] ?? 'کارشناس ارشد بازرگانی خارجی و امور گمرکی'));
        $expYears = max(0, (int)($input['experience_years'] ?? 5));
        $expSal = max(15, (int)($input['expected_salary_million'] ?? 58));
        $city = trim((string)($input['city_preference'] ?? 'مرکز استان / هیبرید'));
        $langs = trim((string)($input['foreign_languages'] ?? 'انگلیسی تجاری C1 | عربی بازرگانی B2'));
        $skills = trim((string)($input['core_skills_csv'] ?? 'Incoterms 2020, UCP 600, سامانه جامع تجارت NTSW, مذاکره صادراتی'));

        $exists = Database::fetchOne('SELECT id FROM career_candidate_profiles WHERE user_id = ?', [$uid]);
        if ($exists) {
            Database::execute(
                'UPDATE career_candidate_profiles
                 SET full_name = ?, headline_title = ?, experience_years = ?, expected_salary_million = ?,
                     city_preference = ?, foreign_languages = ?, core_skills_csv = ?, synced_certs_summary = ?,
                     gamification_xp_badge = ?, updated_shamsi = ?
                 WHERE user_id = ?',
                [$fullName, $headline, $expYears, $expSal, $city, $langs, $skills, $certSummary, $xpBadge, Jalali::today(), $uid]
            );
        } else {
            Database::insert(
                'INSERT INTO career_candidate_profiles
                 (user_id, full_name, headline_title, experience_years, expected_salary_million, city_preference,
                  foreign_languages, core_skills_csv, synced_certs_summary, gamification_xp_badge, updated_shamsi)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
                [$uid, $fullName, $headline, $expYears, $expSal, $city, $langs, $skills, $certSummary, $xpBadge, Jalali::today()]
            );
        }

        LearnerBehaviorGamificationService::recordTelemetryAndAwardXp($uid, $fullName, 'career-hub', 'تکمیل رزومه تاییدشده متصل به گواهی QR آدان', 480, 95, 45);
        return ['ok' => true, 'synced_certs' => $certSummary, 'xp_badge' => $xpBadge];
    }

    /**
     * ۴. ارسال ۱-کلیکی رزومه و گذرنامه مهارت برای آگهی + امتیازدهی تطابق هوش مصنوعی در پایپ‌لاین ATS
     */
    public static function submitSmartApplication(int $jobAdId, int $userId, string $candidateName, string $pitchNote = ''): array
    {
        $ad = Database::fetchOne('SELECT * FROM career_job_ads WHERE id = ?', [$jobAdId]);
        if (!$ad) {
            return ['ok' => false, 'message' => 'آگهی شغلی یافت نشد.'];
        }
        $tracking = 'APP-1405-' . random_int(1000, 9999);
        $cv = Database::fetchOne('SELECT * FROM career_candidate_profiles WHERE user_id = ?', [max(1, $userId)]);

        // محاسبه امتیاز تطابق واقعی بر اساس اشتراک کلیدواژه‌های مهارتی + گواهی رسمی اتاق
        $adTokens = preg_split('/[\s,،]+/u', mb_strtolower($ad['required_skills_tags'] . ' ' . $ad['job_title'])) ?: [];
        $cvBlob = mb_strtolower(($cv['core_skills_csv'] ?? 'Incoterms UCP600 NTSW') . ' ' . ($cv['synced_certs_summary'] ?? 'گواهی'));
        $hits = 0;
        foreach (array_filter($adTokens, fn($t) => mb_strlen($t) >= 3) as $tok) {
            if (str_contains($cvBlob, $tok)) {
                $hits++;
            }
        }
        $score = min(98, 82 + ($hits * 4));
        $gapNote = $score >= 92
            ? "تطابق ممتاز ({$score}٪) با گواهی رسمی اتاق — پیشنهاد ورود مستقیم به مرحله مصاحبه تخصصی."
            : "امتیاز تطابق {$score}٪ — پیشنهاد گذراندن ۱ کارگاه تکمیلی تخصصی اتاق برای رسیدن به تطابق ۱۰۰٪.";

        Database::insert(
            'INSERT INTO career_ats_applications
             (tracking_code, job_ad_id, job_title_snapshot, company_snapshot, candidate_name, ats_stage, ai_match_score_pct, skill_gap_prescription, candidate_note, applied_shamsi)
             VALUES (?, ?, ?, ?, ?, "ai_screened", ?, ?, ?, ?)',
            [
                $tracking,
                $jobAdId,
                $ad['job_title'],
                $ad['company_name'],
                trim($candidateName) ?: 'مهندس مهرداد شریفی',
                $score,
                $gapNote,
                trim($pitchNote) ?: 'ارسال رزومه رسمی تاییدشده همراه با گذرنامه مهارت مؤسسه آموزشی آدان',
                Jalali::today(),
            ]
        );
        Database::execute('UPDATE career_job_ads SET applicants_count = applicants_count + 1 WHERE id = ?', [$jobAdId]);
        LearnerBehaviorGamificationService::recordTelemetryAndAwardXp(max(1, $userId), $candidateName, 'career-hub', 'ارسال رزومه تاییدشده برای فرصت شغلی ' . $ad['ad_code'], 300, 90, 40);

        return ['ok' => true, 'tracking_code' => $tracking, 'match_score_pct' => $score];
    }

    /**
     * ۵. ارتقای مرحله پرونده کارجو در کانبان ۶ مرحله‌ای ATS کارفرما
     */
    public static function advanceAtsStage(int $applicationId): array
    {
        $app = Database::fetchOne('SELECT * FROM career_ats_applications WHERE id = ?', [$applicationId]);
        if (!$app) {
            return ['ok' => false];
        }
        $keys = array_keys(self::ATS_STAGES);
        $idx = array_search($app['ats_stage'], $keys, true);
        $nextStage = $keys[min(count($keys) - 1, ($idx === false ? 0 : $idx + 1))];

        Database::execute('UPDATE career_ats_applications SET ats_stage = ? WHERE id = ?', [$nextStage, $applicationId]);
        return ['ok' => true, 'tracking_code' => $app['tracking_code'], 'new_stage' => $nextStage, 'stage_label' => self::ATS_STAGES[$nextStage]];
    }

    /**
     * ۶. زمان‌بندی جلسه مصاحبه تخصصی + تولید خودکار سؤالات فنی اختصاصی شغل
     */
    public static function scheduleSmartInterview(string $candidate, string $company, string $jobTitle, string $mode, string $whenShamsi): array
    {
        $code = 'INT-1405-' . random_int(600, 999);
        $questions = "۱) تشریح یک پرونده عملیاتی واقعی در حوزه «{$jobTitle}» و نحوه کنترل ریسک حقوقی/مالی آن برای «{$company}».\n"
            . "۲) نحوه استفاده از ابزارهای دیجیتال، سامانه‌های رسمی (NTSW / EPL / مؤدیان) و هوش مصنوعی برای افزایش سرعت واحد.\n"
            . "۳) برنامه پیشنهادی ۹۰ روز اول پس از شروع همکاری.";

        Database::insert(
            'INSERT INTO career_interview_schedules
             (interview_code, candidate_name, company_name, job_title, interview_mode, scheduled_shamsi, interviewer_panel, ai_tailored_questions, technical_score, interview_outcome)
             VALUES (?, ?, ?, ?, ?, ?, "مدیر منابع انسانی + مدیر تخصصی واحد", ?, 90, "دعوت‌نامه رسمی جلسه مصاحبه ارسال شد")',
            [$code, trim($candidate), trim($company), trim($jobTitle), trim($mode), trim($whenShamsi), $questions]
        );
        return ['ok' => true, 'interview_code' => $code, 'questions' => $questions];
    }

    /**
     * ۷. صدور رسمی «نامه پیشنهاد شغلی و بسته حقوق و مزایا» (Official Offer Letter)
     */
    public static function issueOfficialJobOffer(string $candidate, string $company, string $position, int $baseMillion, string $commissionNote): array
    {
        $serial = 'OFR-1405-' . random_int(400, 999);
        Database::insert(
            'INSERT INTO career_job_offers
             (offer_serial, candidate_name, company_name, position_title, base_monthly_million, export_commission_note, start_date_shamsi, offer_status, created_shamsi)
             VALUES (?, ?, ?, ?, ?, ?, "۱۴۰۵/۰۹/۰۱", "صادر و ارسال‌شده به کارجو — آماده امضای دیجیتال", ?)',
            [$serial, trim($candidate), trim($company), trim($position), max(18, $baseMillion), trim($commissionNote), Jalali::today()]
        );
        return ['ok' => true, 'offer_serial' => $serial];
    }

    /**
     * ۸. رزرو نوبت مصاحبه ده دقیقه‌ای سریع در غرفه نمایشگاه کار مؤسسه آموزشی آدان
     */
    public static function reserveJobFairSlot(int $boothId): array
    {
        $booth = Database::fetchOne('SELECT * FROM career_job_fair_booths WHERE id = ?', [$boothId]);
        if (!$booth || (int)$booth['speed_interview_slots_left'] <= 0) {
            return ['ok' => false, 'message' => 'ظرفیت نوبت مصاحبه فوری این غرفه تکمیل شده است.'];
        }
        Database::execute('UPDATE career_job_fair_booths SET speed_interview_slots_left = speed_interview_slots_left - 1 WHERE id = ?', [$boothId]);
        return ['ok' => true, 'booth_code' => $booth['booth_code'], 'company_name' => $booth['company_name'], 'slots_left' => (int)$booth['speed_interview_slots_left'] - 1];
    }

    /**
     * گردآوری کامل داده‌های مرکز جامع کاریابی، فیلتر آگهی‌ها و آمار بازار کار استان
     */
    public static function getFullHubData(string $searchQuery = '', string $catFilter = ''): array
    {
        $sql = 'SELECT * FROM career_job_ads WHERE ad_status = "active"';
        $params = [];
        if ($catFilter !== '' && $catFilter !== 'all') {
            $sql .= ' AND category_slug = ?';
            $params[] = $catFilter;
        }
        if ($searchQuery !== '') {
            $like = '%' . $searchQuery . '%';
            $sql .= ' AND (job_title LIKE ? OR company_name LIKE ? OR required_skills_tags LIKE ? OR city_location LIKE ?)';
            array_push($params, $like, $like, $like, $like);
        }
        $sql .= ' ORDER BY is_urgent DESC, id DESC';

        $ads = Database::fetchAll($sql, $params);
        $apps = Database::fetchAll('SELECT * FROM career_ats_applications ORDER BY ai_match_score_pct DESC, id DESC');

        $byStage = [];
        foreach (array_keys(self::ATS_STAGES) as $stKey) {
            $byStage[$stKey] = array_values(array_filter($apps, static fn($r) => $r['ats_stage'] === $stKey));
        }

        return [
            'ads'        => $ads,
            'all_ads_cnt'=> (int)Database::scalar('SELECT COUNT(*) FROM career_job_ads WHERE ad_status = "active"'),
            'urgent_cnt' => (int)Database::scalar('SELECT COUNT(*) FROM career_job_ads WHERE is_urgent = 1'),
            'hired_cnt'  => (int)Database::scalar('SELECT COUNT(*) FROM career_ats_applications WHERE ats_stage = "hired"'),
            'avg_match'  => (int)Database::scalar('SELECT COALESCE(ROUND(AVG(ai_match_score_pct)), 93) FROM career_ats_applications'),
            'apps'       => $apps,
            'kanban'     => $byStage,
            'profiles'   => Database::fetchAll('SELECT * FROM career_candidate_profiles ORDER BY id ASC'),
            'interviews' => Database::fetchAll('SELECT * FROM career_interview_schedules ORDER BY id DESC'),
            'offers'     => Database::fetchAll('SELECT * FROM career_job_offers ORDER BY id DESC'),
            'benchmarks' => Database::fetchAll('SELECT * FROM career_salary_benchmarks ORDER BY max_top_decile_million DESC'),
            'booths'     => Database::fetchAll('SELECT * FROM career_job_fair_booths ORDER BY id ASC'),
        ];
    }
}
