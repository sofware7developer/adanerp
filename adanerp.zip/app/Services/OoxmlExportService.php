<?php
declare(strict_types=1);

namespace App\Services;

use ZipArchive;

/**
 * موتور خالص PHP تولید اسناد استاندارد آفیس (Microsoft Word .docx و PowerPoint .pptx)
 * بدون نیاز به هیچ کتابخانه Composer خارجی — کاملاً سازگار با cPanel اشتراکی و XAMPP
 */
final class OoxmlExportService
{
    public static function downloadDocx(string $title, string $body, string $filename = 'chamber-document.docx'): never
    {
        $tmp = tempnam(sys_get_temp_dir(), 'chb_docx_');
        $zip = new ZipArchive();
        $zip->open($tmp, ZipArchive::OVERWRITE);

        $zip->addFromString('[Content_Types].xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
</Types>');

        $zip->addFromString('_rels/.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>');

        $lines = preg_split('/\R/u', trim($body)) ?: [];
        $paragraphsXml = self::docxParagraph('مؤسسه آموزشی آدان — مرکز هوشمند آموزش (ناب)', true, '28')
            . self::docxParagraph($title, true, '32');

        foreach ($lines as $line) {
            $clean = trim($line);
            if ($clean === '') {
                continue;
            }
            $isHeading = str_starts_with($clean, '#') || str_starts_with($clean, 'فصل') || str_starts_with($clean, 'بخش');
            $paragraphsXml .= self::docxParagraph(ltrim($clean, "#* \t"), $isHeading, $isHeading ? '26' : '22');
        }

        $zip->addFromString('word/document.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:body>' . $paragraphsXml . '<w:sectPr/></w:body>
</w:document>');

        $zip->close();

        header('Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document');
        header('Content-Disposition: attachment; filename="' . basename($filename) . '"');
        header('Content-Length: ' . (string)filesize($tmp));
        readfile($tmp);
        @unlink($tmp);
        exit;
    }

    public static function downloadPptx(string $title, string $body, string $filename = 'chamber-slides.pptx'): never
    {
        $chunks = array_values(array_filter(array_map('trim', preg_split('/\R{2,}/u', trim($body)) ?: [])));
        if (empty($chunks)) {
            $chunks = [$body];
        }
        $slides = array_slice($chunks, 0, 8);
        array_unshift($slides, $title . "\nارائه‌دهنده: مرکز آموزش مؤسسه آموزشی آدان");

        $tmp = tempnam(sys_get_temp_dir(), 'chb_pptx_');
        $zip = new ZipArchive();
        $zip->open($tmp, ZipArchive::OVERWRITE);

        $ctOverrides = '';
        $presRels = '';
        $sldIdLst = '';

        foreach ($slides as $idx => $slideText) {
            $num = $idx + 1;
            $ctOverrides .= '<Override PartName="/ppt/slides/slide' . $num . '.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>';
            $presRels .= '<Relationship Id="rId' . $num . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide" Target="slides/slide' . $num . '.xml"/>';
            $sldIdLst .= '<p:sldId id="' . (255 + $num) . '" r:id="rId' . $num . '"/>';

            $lines = array_slice(array_values(array_filter(array_map('trim', preg_split('/\R/u', $slideText) ?: []))), 0, 7);
            $paras = '';
            foreach ($lines as $li => $ln) {
                $sz = ($num === 1 && $li === 0) ? '3200' : ($li === 0 ? '2600' : '1900');
                $paras .= '<a:p><a:pPr rtl="1" algn="r"/><a:r><a:rPr lang="fa-IR" sz="' . $sz . '" b="' . ($li === 0 ? '1' : '0') . '"/>'
                    . '<a:t>' . htmlspecialchars(ltrim($ln, "#-* \t"), ENT_XML1 | ENT_QUOTES, 'UTF-8') . '</a:t></a:r></a:p>';
            }

            $zip->addFromString("ppt/slides/slide{$num}.xml", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<p:sld xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main">
  <p:cSld>
    <p:spTree>
      <p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>
      <p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>
      <p:sp>
        <p:nvSpPr><p:cNvPr id="2" name="ContentBox"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>
        <p:spPr>
          <a:xfrm><a:off x="685800" y="571500"/><a:ext cx="7772400" cy="5715000"/></a:xfrm>
          <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
        </p:spPr>
        <p:txBody><a:bodyPr wrap="square" rtlCol="1"/><a:lstStyle/>' . $paras . '</p:txBody>
      </p:sp>
    </p:spTree>
  </p:cSld>
</p:sld>');
        }

        $zip->addFromString('[Content_Types].xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/ppt/presentation.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"/>
  ' . $ctOverrides . '
</Types>');

        $zip->addFromString('_rels/.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="ppt/presentation.xml"/>
</Relationships>');

        $zip->addFromString('ppt/_rels/presentation.xml.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' . $presRels . '</Relationships>');

        $zip->addFromString('ppt/presentation.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<p:presentation xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" rtl="1">
  <p:sldIdLst>' . $sldIdLst . '</p:sldIdLst>
  <p:sldSz cx="9144000" cy="6858000"/>
  <p:notesSz cx="6858000" cy="9144000"/>
</p:presentation>');

        $zip->close();

        header('Content-Type: application/vnd.openxmlformats-officedocument.presentationml.presentation');
        header('Content-Disposition: attachment; filename="' . basename($filename) . '"');
        header('Content-Length: ' . (string)filesize($tmp));
        readfile($tmp);
        @unlink($tmp);
        exit;
    }

    private static function docxParagraph(string $text, bool $bold, string $halfPts): string
    {
        $escaped = htmlspecialchars($text, ENT_XML1 | ENT_QUOTES, 'UTF-8');
        $bTag = $bold ? '<w:b/><w:bCs/>' : '';
        return '<w:p>
          <w:pPr><w:bidi/><w:jc w:val="right"/></w:pPr>
          <w:r>
            <w:rPr><w:rFonts w:ascii="Vazirmatn" w:hAnsi="Vazirmatn" w:cs="Tahoma"/>' . $bTag . '<w:sz w:val="' . $halfPts . '"/><w:szCs w:val="' . $halfPts . '"/><w:rtl/></w:rPr>
            <w:t xml:space="preserve">' . $escaped . '</w:t>
          </w:r>
        </w:p>';
    }
}
