<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database;
use App\Core\Jalali;

/**
 * موتور زنجیره خودکار سرتاسری میان‌ماژولی (End-to-End Event-Driven Automation Pipeline)
 * اجرای تراکنشی یکپارچه ۷ مرحله‌ای در یک تراکنش اتمیک (ACID Transaction):
 * ثبت‌نام، پیشرفت یادگیری، ثبت مالی و گردش‌کار آموزشی در یک تراکنش.
 */
final class AutomationPipelineService
{
    public static function executeFullChain(int $userId, int $courseId, int $attendancePct = 92, float $examScore = 88.5): array
    {
        if ($userId <= 0 || $courseId <= 0 || $attendancePct < 0 || $attendancePct > 100 || $examScore < 0 || $examScore > 100) {
            return ['ok' => false, 'error' => 'شناسه یا نمرهٔ ورودی خارج از محدودهٔ مجاز است.'];
        }

        $pdo = Database::connection();
        $pdo->beginTransaction();

        try {
            $user = Database::fetchOne('SELECT * FROM users WHERE id = ? AND role = "learner" AND status = "active"', [$userId]);
            $course = Database::fetchOne('SELECT * FROM courses WHERE id = ? AND workflow_status IN ("approved", "published")', [$courseId]);
            if (!$user || !$course) {
                throw new \DomainException('فراگیر یا دورهٔ فعال و تأییدشده پیدا نشد.');
            }
            $run = Database::fetchOne(
                'SELECT * FROM course_runs WHERE course_id = ? AND status IN ("running", "completed") ORDER BY id ASC LIMIT 1',
                [(int)$course['id']]
            );
            if (!$run) {
                throw new \DomainException('برای این دوره اجرای در حال برگزاری یا تکمیل‌شده وجود ندارد.');
            }

            $uid = (int)$user['id'];
            $cid = (int)$course['id'];
            $rid = (int)$run['id'];
            $existsEnr = Database::fetchOne(
                'SELECT id, status FROM enrollments WHERE run_id = ? AND user_id = ?',
                [$rid, $uid]
            );
            if (!$existsEnr || !in_array((string)$existsEnr['status'], ['active', 'completed'], true)) {
                throw new \DomainException('فراگیر در اجرای این دوره ثبت‌نام فعال ندارد.');
            }
            $shamsiToday = Jalali::today();

            // گام ۱: کسر سهمیه قرارداد سازمانی + ثبت سند حسابداری ۴ سطحی دوبل
            $contract = Database::fetchOne('SELECT * FROM corporate_contracts WHERE org_id = ? AND approval_stage = "approved_active" LIMIT 1', [(int)($user['org_id'] ?? 1)]);
            if ($contract) {
                Database::execute('UPDATE corporate_contracts SET seats_used = LEAST(seat_quota, seats_used + 1) WHERE id = ?', [(int)$contract['id']]);
            }
            $vchNo = 'VCH-AUTO-' . rand(1000, 9999);
            Database::insert(
                'INSERT INTO accounting_vouchers (voucher_no, voucher_shamsi, group_code, kol_account, moein_account, tafsili_entity, debit_rial, credit_rial, voucher_desc)
                 VALUES (?, ?, "۱-دارایی جاری", "۱۱۴۰-حساب‌های دریافتنی", "۱۱۴۰۱-شهریه دوره‌های آموزشی", ?, ?, ?, ?)',
                [$vchNo, $shamsiToday, $user['full_name'], (int)$course['tuition_rial'], (int)$course['tuition_rial'], 'ثبت خودکار زنجیره سرتاسری دوره ' . $course['title']]
            );

            // گام ۲: ثبت‌نام قطعی و ثبت نمره/حضور در TMS
            Database::execute(
                'UPDATE enrollments SET attendance_pct = ?, progress_pct = 100, final_score = ?, status = "completed" WHERE id = ?',
                [$attendancePct, $examScore, (int)$existsEnr['id']]
            );

            // گام ۳: تکمیل دروس LMS دوره
            foreach (Database::fetchAll('SELECT id FROM lms_lessons WHERE course_id = ? LIMIT 5', [$cid]) as $les) {
                Database::execute(
                    'INSERT INTO lms_progress (user_id, lesson_id, is_completed, spent_minutes, completed_at)
                     VALUES (?, ?, 1, 30, NOW())
                     ON DUPLICATE KEY UPDATE is_completed = 1',
                    [$uid, (int)$les['id']]
                );
            }

            // ثبت نتیجه آموزشی و ایجاد نشان مهارت داخلی
            $certSerial = null;
            if ($attendancePct >= 80 && $examScore >= 70.0) {
                $certSerial = 'CERT-PIPE-' . rand(10000, 99999);
                Database::insert(
                    'INSERT INTO certificates (serial_code, user_id, course_id, issue_shamsi, grade_label, hours_completed, status)
                     VALUES (?, ?, ?, ?, ?, ?, "valid")',
                    [$certSerial, $uid, $cid, $shamsiToday, 'عالی (' . $examScore . ')', (int)$course['duration_hours']]
                );

                Database::insert(
                    'INSERT INTO user_badges (user_id, badge_code, badge_title, skill_domain, issued_shamsi)
                     VALUES (?, ?, ?, "حسابداری و امور مالی", ?)',
                    [$uid, 'BDG-AUTO-' . rand(1000, 9999), 'تکمیل زنجیره مهارت: ' . $course['title'], $shamsiToday]
                );
            }

            $bpmsCode = 'WF-PIPE-' . rand(100, 999);
            Database::insert(
                'INSERT INTO bpms_workflows (process_key, process_title, subject_label, initiator_id, current_step, assigned_role, sla_hours, elapsed_hours, status, history_json)
                 VALUES (?, "گردش‌کار ثبت‌نام و تکمیل دوره آموزشی", ?, ?, "بایگانی سوابق آموزشی", "super_admin", 24, 1, "approved", ?)',
                [
                    $bpmsCode,
                    $user['full_name'] . ' — ' . $course['title'],
                    $uid,
                    json_encode([['step' => 'تکمیل گردش‌کار آموزشی', 'voucher' => $vchNo, 'cert' => $certSerial]], JSON_UNESCAPED_UNICODE),
                ]
            );

            $pdo->commit();
            return [
                'ok' => true,
                'learner' => $user['full_name'],
                'course' => $course['title'],
                'voucher_no' => $vchNo,
                'cert_serial' => $certSerial,
                'bpms_code' => $bpmsCode,
            ];
        } catch (\Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            return ['ok' => false, 'error' => $e->getMessage()];
        }
    }
}
