<?php
declare(strict_types=1);

namespace App\Services;

/**
 * ماشین‌حساب تخصصی قیمت‌گذاری صادراتی (اینکوترمز ۲۰۲۰) و محاسبه حقوق ورودی گمرک ایران
 */
final class TradeCalculatorService
{
    public static function calculateExportIncotermLadder(
        float $exwTotalUsd,
        float $packagingAndInlandUsd,
        float $customsOriginAndThcUsd,
        float $oceanFreightUsd,
        float $insuranceRatePct = 0.35,
        float $destDutyAndDeliveryUsd = 1450.0,
        int $fxNimaRial = 595000
    ): array {
        $exw = round($exwTotalUsd, 2);
        $fca = round($exw + $packagingAndInlandUsd, 2);
        $fob = round($fca + $customsOriginAndThcUsd, 2);
        $cfr = round($fob + $oceanFreightUsd, 2);
        // طبق قاعده استاندارد ICC بیمه کلوز A/C بر روی ۱۱۰٪ ارزش سیف محاسبه می‌گردد
        $insuranceUsd = round(($cfr * 1.10) * ($insuranceRatePct / 100.0), 2);
        $cif = round($cfr + $insuranceUsd, 2);
        $ddp = round($cif + $destDutyAndDeliveryUsd, 2);

        return [
            'EXW (تحویل درب کارخانه استان)' => $exw,
            'FCA (تحویل به حمل‌کننده داخلی)' => $fca,
            'FOB Bandar Abbas (تحویل روی عرشه شهید رجایی)' => $fob,
            'CFR (هزینه و کرایه حمل تا بندر مقصد)' => $cfr,
            'CIF (هزینه، بیمه ۱۱۰٪ ICC و کرایه حمل)' => $cif,
            'DDP (تحویل ترخیص‌شده در انبار خریدار خارجی)' => $ddp,
            'insurance_usd' => $insuranceUsd,
            'cif_rial_equivalent' => (int)round($cif * $fxNimaRial),
        ];
    }

    public static function calculateIranCustomsImportLevies(
        float $cifForeignAmount,
        int $customsFxRateRial,
        float $tariffRatePct,
        float $vatRatePct = 10.0
    ): array {
        $cifRial = (int)round($cifForeignAmount * $customsFxRateRial);
        $importDuty = (int)round($cifRial * ($tariffRatePct / 100.0));
        $redCrescent = (int)round($importDuty * 0.01); // ۱٪ هلال احمر
        $vatBase = $cifRial + $importDuty + $redCrescent;
        $vatAmount = (int)round($vatBase * ($vatRatePct / 100.0));
        $advanceTax4Pct = (int)round(($cifRial + $importDuty) * 0.04); // ۴٪ مالیات علی‌الحساب واردات
        $totalCustomsPayable = $importDuty + $redCrescent + $vatAmount + $advanceTax4Pct;

        return [
            'cif_rial' => $cifRial,
            'import_duty_rial' => $importDuty,
            'red_crescent_rial' => $redCrescent,
            'vat_rial' => $vatAmount,
            'advance_tax_4pct_rial' => $advanceTax4Pct,
            'total_customs_payable_rial' => $totalCustomsPayable,
        ];
    }
}
